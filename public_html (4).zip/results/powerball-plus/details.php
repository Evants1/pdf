<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Africa/Johannesburg');

// 1. Connect to Database (UPDATED PATH for new folder location)
require_once __DIR__ . '/../../db.php';

// --- HELPER FUNCTIONS FOR STRICT FORMATTING ---
function formatMoney($val) {
    if ($val === null || $val === '') {
        return 'R 0.00';
    }
    // Remove existing 'R', spaces, or commas to prevent double formatting
    $cleanVal = str_replace(['R', ' ', ','], '', (string)$val);
    if (!is_numeric($cleanVal)) {
        return 'R 0.00';
    }
    return 'R ' . number_format((float)$cleanVal, 2);
}

function formatNumber($val) {
    if ($val === null || $val === '') {
        return '0';
    }
    $cleanVal = str_replace([',', ' '], '', (string)$val);
    if (!is_numeric($cleanVal)) {
        return '0';
    }
    return number_format((int)$cleanVal);
}

// 2. Get the slug from the URL (e.g., "17-april-2026")
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';

// 3. Convert the slug back to a MySQL date format (YYYY-MM-DD)
$cleanDateString = str_replace('-', ' ', $slug);
$timestamp = strtotime($cleanDateString);

$drawFound = false;
$row = [];

if ($timestamp) {
    $dbDate = date('Y-m-d', $timestamp);
    
    // 4. Query the database for this specific date
    $stmt = $pdo->prepare("SELECT * FROM powerball_plus_results WHERE draw_date = :draw_date LIMIT 1");
    $stmt->execute(['draw_date' => $dbDate]);
    $row = $stmt->fetch();
    
    if ($row) {
        $drawFound = true;
    }
}

// --- FIX: Define base breadcrumbs unconditionally so they always exist ---
$breadcrumbs = [
    [
        "name" => "Home",
        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"
    ],
    [
        "name" => "PowerBall Plus",
        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/powerball-plus"
    ]
];

// 5. Handle 404 if Draw is Not Found
if (!$drawFound) {
    header("HTTP/1.0 404 Not Found");
    $pageTitle = "Draw Not Found | NextDrawLogic";
} else {
    // Format dates for UI
    $dateObj = new DateTime($row['draw_date']);
    $displayDate = $dateObj->format('l, j F Y');
    $breadcrumbDate = $dateObj->format('j F Y');
    
    $currentUrl = "https://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];

    // Add the specific date to the breadcrumbs ONLY if the draw exists
    $breadcrumbs[] = [
        "name" => $breadcrumbDate,
        "url" => $currentUrl
    ];
    
    // SAFELY Calculate Advanced Analytics for this specific draw (Main 5 Balls)
    $balls = [
        (string)($row['ball_1'] ?? ''), 
        (string)($row['ball_2'] ?? ''), 
        (string)($row['ball_3'] ?? ''), 
        (string)($row['ball_4'] ?? ''), 
        (string)($row['ball_5'] ?? '')
    ];
    
    $sum = 0;
    $odds = 0; $evens = 0;
    $highs = 0; $lows = 0; // PowerBall Plus is 1-50. Low is 1-25, High is 26-50
    
    foreach($balls as $b) {
        // Prevent fatal math errors on null/empty values
        if (is_numeric($b) && (int)$b > 0) {
            $val = (int)$b;
            $sum += $val;
            if ($val % 2 == 0) { $evens++; } else { $odds++; }
            if ($val >= 26) { $highs++; } else { $lows++; }
        }
    }
    
    // --- DYNAMIC CALCULATIONS ---
    
    // Calculate exact total winners and total paid out by summing all 9 divisions for PowerBall Plus
    $totalWinnersCalc = 0;
    $totalPayoutCalc = 0;
    for ($i = 1; $i <= 9; $i++) {
        $w = (int)str_replace([',', ' '], '', (string)($row["div{$i}_winners"] ?? 0));
        $p = (float)str_replace(['R', ' ', ','], '', (string)($row["div{$i}_amount"] ?? 0));
        
        $totalWinnersCalc += $w;
        $totalPayoutCalc += ($w * $p);
    }
    
    // Ensure we use the calculated values or database fallback for maximum accuracy
    $finalTotalWinners = formatNumber($totalWinnersCalc > 0 ? $totalWinnersCalc : ($row['total_winners'] ?? 0));
    $formattedTotalPayout = formatMoney($totalPayoutCalc);
    
    $pageTitle = "PowerBall Plus Results for $displayDate (Winning Numbers)";
    $metaDesc = "In-depth analytics and prize divisions for the SA PowerBall Plus draw on $displayDate. View winning numbers, PowerBall, payouts, and machine data.";
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo isset($metaDesc) ? $metaDesc : 'Get the latest PowerBall Plus results in South Africa, including winning numbers, payouts, and historical data.'; ?>">
    <meta name="keywords" content="PowerBall Plus results, South Africa lotto, SA PowerBall Plus numbers, powerball plus results today, lottery results SA, PowerBall Plus history">
    <meta name="robots" content="index, follow">
    <meta name="author" content="YourBrand">

    <link rel="canonical" href="<?php echo "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>">

    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <meta name="language" content="en-ZA">

    <meta property="og:title" content="<?php echo $pageTitle; ?> | PowerBall Plus Results South Africa">
    <meta property="og:description" content="<?php echo isset($metaDesc) ? $metaDesc : 'Latest PowerBall Plus results, winning numbers and payouts in South Africa.'; ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>">
    <meta property="og:image" content="https://yourdomain.co.za/assets/og-image.jpg">
    <meta property="og:site_name" content="YourBrand">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $pageTitle; ?> | PowerBall Plus Results South Africa">
    <meta name="twitter:description" content="<?php echo isset($metaDesc) ? $metaDesc : 'Check PowerBall Plus results and stats in South Africa.'; ?>">
    <meta name="twitter:image" content="https://yourdomain.co.za/assets/og-image.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        <?php echo file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/style/style.css'); ?>
        .card-grid {
            display: grid;
            grid-template-columns: 1fr !important;
        }
    </style>

    <link rel="icon" href="/favicon.ico" type="image/x-icon">

    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            <?php foreach ($breadcrumbs as $index => $crumb): ?>
            {
              "@type": "ListItem",
              "position": <?php echo $index + 1; ?>,
              "name": "<?php echo $crumb['name']; ?>",
              "item": "<?php echo $crumb['url']; ?>"
            }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
            <?php endforeach; ?>
          ]
        }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "headline": "<?php echo $pageTitle; ?>",
      "description": "<?php echo isset($metaDesc) ? $metaDesc : 'Latest PowerBall Plus results South Africa.'; ?>",
      "author": {
        "@type": "Organization",
        "name": "YourBrand"
      },
      "publisher": {
        "@type": "Organization",
        "name": "YourBrand",
        "logo": {
          "@type": "ImageObject",
          "url": "https://yourdomain.co.za/assets/logo.png"
        }
      },
      "datePublished": "<?php echo date('c'); ?>",
      "dateModified": "<?php echo date('c'); ?>",
      "mainEntityOfPage": "<?php echo "https://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]"; ?>"
    }
    </script>
    
    <?php if ($drawFound): ?>
    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "FAQPage",
          "mainEntity": [{
            "@type": "Question",
            "name": "What were the PowerBall Plus results for <?php echo $displayDate; ?>?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "The winning numbers for <?php echo $displayDate; ?> were <?php echo implode(', ', array_filter($balls)); ?>, and the PowerBall was <?php echo htmlspecialchars((string)($row['powerball'] ?? '')); ?>."
            }
          },{
            "@type": "Question",
            "name": "How much was paid out in total for the PowerBall Plus on <?php echo $displayDate; ?>?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "The total prize payout across all winning divisions for this draw was <?php echo $formattedTotalPayout; ?>."
            }
          },{
            "@type": "Question",
            "name": "How many people won the PowerBall Plus on <?php echo $displayDate; ?>?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "There were a total of <?php echo $finalTotalWinners; ?> winners across all divisions for this specific draw."
            }
          },{
            "@type": "Question",
            "name": "What time is PowerBall Plus drawn in South Africa?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "The PowerBall Plus is drawn every Tuesday and Friday evening at 21:00 (9:00 PM) SAST, immediately following the main PowerBall draw."
            }
          }]
        }
    </script>
    <?php endif; ?>

</head>
<body>
    <?php include __DIR__ . '/../../static/nav.php'; ?>
    <main class="container">
        
        <nav class="breadcrumb">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link">
                                <?php echo $crumb['name']; ?>
                            </a>
                        <?php else: ?>
                            <span class="breadcrumb-current">
                                <?php echo $crumb['name']; ?>
                            </span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>
        
        <?php if ($drawFound): ?>
        
        <div class="layout-with-sidebar">
            
            <div class="content-area">
                
                <div class="detail-card" style="margin: 0;"> 
                    <h1>PowerBall Plus Results for <?php echo $displayDate; ?> (South Africa)</h1>
                    <p class="last-updated">
                        Last updated: <?php echo date('j F Y'); ?>
                    </p>
                    
                    <?php if(!empty($row['draw_number'])): ?>
                        <div class="draw-number-tag">Draw Number: <strong><?php echo htmlspecialchars((string)($row['draw_number'] ?? '')); ?></strong></div>
                    <?php endif; ?>
                    
                    <ul class="balls-row">
                        <li class="ball"><?php echo htmlspecialchars((string)($row['ball_1'] ?? '')); ?></li>
                        <li class="ball"><?php echo htmlspecialchars((string)($row['ball_2'] ?? '')); ?></li>
                        <li class="ball"><?php echo htmlspecialchars((string)($row['ball_3'] ?? '')); ?></li>
                        <li class="ball"><?php echo htmlspecialchars((string)($row['ball_4'] ?? '')); ?></li>
                        <li class="ball"><?php echo htmlspecialchars((string)($row['ball_5'] ?? '')); ?></li>
                        <li class="ball" style="background-color: #ef4444; color: #fff; border-color: #dc2626; margin-left: 4px;" title="PowerBall"><?php echo htmlspecialchars((string)($row['powerball'] ?? '')); ?></li>
                    </ul>
                    
                    <div class="analytics-grid">
                        <div class="stat-box">
                            <span class="fin-lbl">Sum of Numbers</span>
                            <strong><?php echo $sum; ?></strong>
                        </div>
                        <div class="stat-box">
                            <span class="fin-lbl">Odd / Even Split</span>
                            <strong><?php echo $odds; ?> / <?php echo $evens; ?></strong>
                        </div>
                        <div class="stat-box">
                            <span class="fin-lbl">High / Low Split</span>
                            <strong><?php echo $highs; ?> / <?php echo $lows; ?></strong>
                        </div>
                    </div>

                    <?php if(!empty($row['draw_number'])): ?>
                    <div class="card-grid">
                        
                        <div>
                            <h2 class="section-title">Prize Divisions</h2>
                            <table class="data-table">
                                <thead>
                                    <tr>
                                        <th>Division</th>
                                        <th class="num-col">Winners</th>
                                        <th class="num-col">Amount</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>5 Numbers + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div1_winners'] ?? 0); ?></td>
                                        <td class="num-col" style="color: var(--accent-gold); font-weight: 600;"><?php echo formatMoney($row['div1_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>5 Numbers</td>
                                        <td class="num-col"><?php echo formatNumber($row['div2_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div2_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>4 Numbers + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div3_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div3_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>4 Numbers</td>
                                        <td class="num-col"><?php echo formatNumber($row['div4_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div4_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>3 Numbers + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div5_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div5_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>3 Numbers</td>
                                        <td class="num-col"><?php echo formatNumber($row['div6_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div6_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>2 Numbers + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div7_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div7_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>1 Number + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div8_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div8_amount'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>0 Numbers + PowerBall</td>
                                        <td class="num-col"><?php echo formatNumber($row['div9_winners'] ?? 0); ?></td>
                                        <td class="num-col"><?php echo formatMoney($row['div9_amount'] ?? 0); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                        <div style="margin-top: 32px;">
                            <h2 class="section-title">Draw Information</h2>
                            <table class="data-table">
                                <tbody>
                                    <tr>
                                        <td>Total Division Winners</td>
                                        <td class="num-col" style="font-weight: 600;"><?php echo $finalTotalWinners; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Total Paid Out</td>
                                        <td class="num-col" style="font-weight: 600; color: var(--accent-gold);"><?php echo $formattedTotalPayout; ?></td>
                                    </tr>
                                    <tr>
                                        <td>Rollover Number</td>
                                        <td class="num-col"><?php echo htmlspecialchars((string)($row['rollover_number'] ?? '0')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Prize Pool</td>
                                        <td class="num-col"><?php echo formatMoney($row['total_pool_size'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Total Sales</td>
                                        <td class="num-col"><?php echo formatMoney($row['total_sales'] ?? 0); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Machine Name</td>
                                        <td class="num-col"><?php echo htmlspecialchars((string)($row['machine_name'] ?? 'N/A')); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>

                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 24px; border-top: 1px solid var(--border); margin-top: 32px;">
                        <p style="font-size: 1.1rem; color: var(--text-muted);">Total Winners: <strong><?php echo $finalTotalWinners; ?></strong> | Total Payout: <strong style="color: var(--accent-gold);"><?php echo $formattedTotalPayout; ?></strong></p>
                    </div>
                    <?php endif; ?>
                    
                    <div style="margin-top: 10px; text-align: center;">
                        <a href="https://affiliates.hollywoodbets.net/" target="_blank" rel="noopener nofollow" class="btn" style="background: var(--accent-gold); color: #ffffff;">Bet on the Next Draw</a>
                    </div>

                </div> 
                
                <article class="seo-article">
                    
                    <div class="seo-card" style="margin-bottom: 32px;">
                        <h2 style="font-size: 1.6rem; font-weight: 800; margin-bottom: 16px; color: var(--text-main); line-height: 1.3;">PowerBall Plus Results for <?php echo $displayDate; ?> – Full Breakdown &amp; Insights</h2>
                        <p style="color: var(--text-muted);">On <strong><?php echo $displayDate; ?></strong>, South African lottery fans tuned in for the PowerBall Plus draw, the exciting add-on game to the main PowerBall. The official main winning numbers were <strong style="color: var(--primary);"><?php echo implode(', ', array_map('htmlspecialchars', array_filter($balls))); ?></strong>, and the Bonus PowerBall was <strong style="color: #ef4444;"><?php echo htmlspecialchars((string)($row['powerball'] ?? '')); ?></strong>. With a total sum of <?php echo $sum; ?> (excluding the PowerBall), this draw featured a mix of <?php echo $odds; ?> odd numbers and <?php echo $evens; ?> even numbers on the main grid, plus <?php echo $highs; ?> high balls (26–50) and <?php echo $lows; ?> low balls (1–25).</p>
                        
                        <p>Official lottery results are published by the South African National Lottery operator, which you can verify on their official site: <a href="https://www.nationallottery.co.za/home" target="_blank" rel="noopener nofollow">National Lottery South Africa</a>.</p>
                        <p style="color: var(--text-muted);">These statistics are exactly why thousands of players visit NextDrawLogic every week. Whether you’re looking for today’s PowerBall Plus results, past winning numbers, or trying to spot patterns for your next ticket, our detailed analytics give you the edge. The <?php echo $displayDate; ?> draw produced <strong><?php echo $finalTotalWinners; ?></strong> winners across all 9 divisions.</p>
                        
                        <p style="color: var(--text-muted);">
                        This draw had a <?php echo $odds > $evens ? 'higher odd number bias' : 'more even numbers than usual'; ?>,
                        which is interesting compared to recent PowerBall Plus trends.
                        </p>
                    </div>

                    <div class="card-grid" style="margin-top: 0; padding-top: 0; border-top: none;">
                        
                        <div class="seo-card" style="background: linear-gradient(135deg, #ffffff, #f8fafc);">
                            <h3 class="section-title">Key Highlights from This Draw</h3>
                            <ul class="highlight-list">
                                <li><strong>Main Numbers:</strong> <span><?php echo implode(', ', array_map('htmlspecialchars', array_filter($balls))); ?></span></li>
                                <li><strong>PowerBall:</strong> <span style="color: #ef4444; font-weight: 700;"><?php echo htmlspecialchars((string)($row['powerball'] ?? '')); ?></span></li>
                                <li><strong>Sum of Main Balls:</strong> <span><?php echo $sum; ?></span></li>
                                <li><strong>Odd/Even Split:</strong> <span><?php echo $odds; ?> Odd / <?php echo $evens; ?> Even</span></li>
                                <li><strong>High/Low Split:</strong> <span><?php echo $highs; ?> High / <?php echo $lows; ?> Low</span></li>
                                <li><strong>Total Paid Out:</strong> <span style="color: var(--accent-gold); font-weight: 700;"><?php echo $formattedTotalPayout; ?></span></li>
                                <li><strong>Rollovers:</strong> <span><?php echo htmlspecialchars((string)($row['rollover_number'] ?? '0')); ?></span></li>
                                <li><strong>Machine Used:</strong> <span><?php echo htmlspecialchars((string)($row['machine_name'] ?? 'N/A')); ?></span></li>
                                <?php if(!empty($row['draw_number'])): ?>
                                <li><strong>Official Draw Number:</strong> <span><?php echo htmlspecialchars((string)($row['draw_number'] ?? '')); ?></span></li>
                                <?php endif; ?>
                            </ul>
                            
                            <div style="margin-top: 24px; padding-top: 20px; border-top: 1px dashed var(--border);">
                                <p style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.6;">If you matched any of the numbers, congratulations! The top Division 1 prize paid out <strong><?php echo formatMoney($row['div1_amount'] ?? 0); ?></strong>. PowerBall Plus gives you a second chance to win big right after the main draw. Even if you didn’t win this time, the next Tuesday or Friday draw is a fresh opportunity.</p>
                            </div>
                        </div>

                        <div style="display: flex; flex-direction: column; gap: 24px;">
                            
                            <div class="seo-card">
                                <h3 class="section-title" style="font-size: 1.15rem;">Why Players Love SA PowerBall Plus</h3>
                                <p style="font-size: 0.95rem; color: var(--text-muted); margin-bottom: 12px; line-height: 1.6;">PowerBall Plus acts as a second chance to win big right after the main PowerBall draw. For a small extra fee, your same set of chosen numbers are entered into this completely separate draw with its own independent, rolling jackpot!</p>
                                <p style="font-size: 0.95rem; color: var(--text-muted); line-height: 1.6;">Searching for “PowerBall Plus results <?php echo strtolower($displayDate); ?>” or “latest PowerBall Plus winning numbers”? Bookmark this page and come back after every draw for accurate, fast-loading results.</p>
                            </div>

                            <div class="seo-card" style="border-left: 4px solid var(--accent-gold); background: #fffbeb;">
                                <h3 class="section-title" style="font-size: 1.15rem; color: #92400e;">Quick Tips for Next Time</h3>
                                <p style="font-size: 0.95rem; color: #92400e; line-height: 1.6;">Looking at past results can help you spot patterns, but remember – every draw is completely random. Mix high and low numbers across the 1-50 grid, balance odds and evens, and remember to select a strong PowerBall from 1-20. Play responsibly!</p>
                            </div>
                            
                        </div>
                    </div>
                    
                    <div class="related-links">
                        <h3>More PowerBall Plus Results</h3>
                        <ul>
                            <li><a href="/results/powerball-plus/history">View Full History</a></li>
                            <li><a href="/results/powerball-plus">Latest Results</a></li>
                        </ul>
                    </div>

                    <div class="faq-section">
                        <h3>Frequently Asked Questions</h3>
                        
                        <details class="faq-item">
                            <summary>What were the PowerBall Plus results for <?php echo $displayDate; ?>?</summary>
                            <p>The winning numbers for <?php echo $displayDate; ?> were <strong><?php echo implode(', ', array_filter($balls)); ?></strong>, and the PowerBall was <strong><?php echo htmlspecialchars((string)($row['powerball'] ?? '')); ?></strong>.</p>
                        </details>
                        
                        <details class="faq-item">
                            <summary>How much was paid out in total for the PowerBall Plus on <?php echo $displayDate; ?>?</summary>
                            <p>The total prize payout across all winning divisions for this draw was <strong><?php echo $formattedTotalPayout; ?></strong>.</p>
                        </details>
                        
                        <details class="faq-item">
                            <summary>How many people won the PowerBall Plus on <?php echo $displayDate; ?>?</summary>
                            <p>There were a total of <strong><?php echo $finalTotalWinners; ?></strong> winners across all divisions for this specific draw.</p>
                        </details>
                        
                        <details class="faq-item">
                            <summary>What time is PowerBall Plus drawn in South Africa?</summary>
                            <p>The PowerBall Plus is drawn every Tuesday and Friday evening at 21:00 (9:00 PM) SAST, immediately following the main PowerBall draw.</p>
                        </details>
                    </div>
                    <div style="margin: 40px 0; text-align: center;">
                        <a href="/results/powerball-plus/history/" class="btn" style="background: var(--text-main); color: #ffffff;">Browse Full PowerBall Plus History Archive</a>
                    </div>

                </article>
            </div> 

            <aside class="lotto-sidebar">
            <nav class="sidebar-menu" aria-label="PowerBall Plus navigation">
                <div class="sidebar-menu-header">PowerBall Plus Guide</div>
                
                <ul class="sidebar-links">
                    <li>
                        <a href="/results/powerball-plus">
                            Latest PowerBall Plus Results
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/history" class="active">
                            PowerBall Plus Draw History
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/predictions">
                            PowerBall Plus Predictions
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/hot-cold">
                            Hot & Cold Numbers
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/check-tickets">
                            Check PowerBall Plus Tickets
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/payouts">
                            Prize Breakdown & Payouts
                        </a>
                    </li>
        
                    <li>
                        <a href="/results/powerball-plus/generator">
                            Number Generator Tool
                        </a>
                    </li>
        
                    <li>
                        <a href="/how-to-play-powerball-plus">
                            How to Play PowerBall Plus
                        </a>
                    </li>
        
                    <li>
                        <a href="/faqs">
                            Lottery FAQs
                        </a>
                    </li>
        
                    <li>
                        <a href="https://affiliates.hollywoodbets.net/"
                           class="highlight"
                           target="_blank"
                           rel="noopener nofollow">
                            Play PowerBall Online →
                        </a>
                    </li>
                </ul>
            </nav>
        </aside>
            
        </div> <?php else: ?>
        
        <div class="error-state">
            <h1>404</h1>
            <h2>Draw Not Found</h2>
            <p style="margin: 16px 0 32px; color: var(--text-muted);">We couldn't find a draw in our database for the date you requested.</p>
            <a href="/results/powerball-plus/history/" class="btn">Return to History Archive</a>
            
            <div style="margin-top: 60px; max-width: 620px; margin-left: auto; margin-right: auto; text-align: center; font-size: 0.95rem; color: var(--text-muted);">
                <p>Looking for recent PowerBall Plus results in South Africa? Try our full <a href="/results/powerball-plus/history/" style="color: var(--accent-gold);">PowerBall Plus history archive</a> or check today’s draw on the homepage.</p>
            </div>
        </div>
        
        <?php endif; ?>
    </main>
    <?php include __DIR__ . '/../../static/footer.php'; ?>
</body>
</html>