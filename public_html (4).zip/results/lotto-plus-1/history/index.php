<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// BULLETPROOF PATH: Connect to your database
require_once __DIR__ . '/../../../db.php';

// --- SEARCH FILTER DATE LOGIC START ---
// Get min and max dates from database to restrict the date picker
$boundsStmt = $pdo->query("SELECT MIN(draw_date) as min_d, MAX(draw_date) as max_d FROM lotto_plus_1_results");
$bounds = $boundsStmt->fetch();
$minDbDate = $bounds['min_d'] ?? date('Y-m-d');
$maxDbDate = $bounds['max_d'] ?? date('Y-m-d');

$startDate = isset($_GET['start_date']) && !empty($_GET['start_date']) ? $_GET['start_date'] : null;
$endDate = isset($_GET['end_date']) && !empty($_GET['end_date']) ? $_GET['end_date'] : null;

$whereSql = "";
$params = [];

if ($startDate && $endDate) {
    $whereSql = " WHERE draw_date BETWEEN :start AND :end ";
    $params[':start'] = $startDate;
    $params[':end'] = $endDate;
}
// --- SEARCH FILTER DATE LOGIC END ---

// --- PAGINATION LOGIC START ---
$recordsPerPage = 7;

// Get the current page from the URL (e.g., domain.com/history/?page=2), default to 1
$page = isset($_GET['page']) && is_numeric($_GET['page']) ? (int)$_GET['page'] : 1;
if ($page < 1) { $page = 1; }

// Count the total number of draws in the database (Included $whereSql for search)
$countQuery = "SELECT COUNT(*) FROM lotto_plus_1_results" . $whereSql;
$totalStmt = $pdo->prepare($countQuery);
$totalStmt->execute($params);
$totalRecords = $totalStmt->fetchColumn();

// Calculate total pages needed
$totalPages = ceil($totalRecords / $recordsPerPage);

// Ensure the user doesn't go past the last page
if ($page > $totalPages && $totalPages > 0) {
    $page = $totalPages;
}

// Calculate the SQL OFFSET (where to start fetching records)
$offset = ($page - 1) * $recordsPerPage;

// FETCH HISTORY FOR THE CURRENT PAGE ONLY (ORDER BY draw_date DESC pulls newest first)
$historyQuery = "SELECT * FROM lotto_plus_1_results" . $whereSql . " ORDER BY draw_date DESC, id DESC LIMIT :limit OFFSET :offset";
$historyStmt = $pdo->prepare($historyQuery);
foreach ($params as $key => $val) {
    $historyStmt->bindValue($key, $val);
}
$historyStmt->bindValue(':limit', $recordsPerPage, PDO::PARAM_INT);
$historyStmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$historyStmt->execute();
$historyResults = $historyStmt->fetchAll();
// --- PAGINATION LOGIC END ---

// --- FRESHNESS SIGNAL: Get the exact update time of the newest record ---
$lastUpdatedText = date('F j, Y \a\t g:i A'); // Fallback
if (!empty($historyResults) && $page === 1) {
    // Pull the exact time directly from the database 'created_at' column of the newest row
    if (!empty($historyResults[0]['created_at'])) {
        $dbDate = new DateTime($historyResults[0]['created_at']);
        // Format to match 12-hour time cleanly (e.g., April 19, 2026 at 9:27 AM)
        $lastUpdatedText = $dbDate->format('F j, Y \a\t g:i A'); 
    } else {
        // Safe fallback if the column is ever missing
        $lastUpdatedText = date('F j, Y', strtotime($historyResults[0]['draw_date'])) . ' at 09:15 PM';
    }
}

// --- GET "YESTERDAY'S" SLUG FOR THE SEO BLOCK ---
$latestSlug = '';
if (!empty($historyResults)) {
    $latestDrawDate = new DateTime($historyResults[0]['draw_date']);
    $latestSlug = strtolower($latestDrawDate->format('d-F-Y'));
}

// --- DYNAMIC LOTTERY DRAW SCHEMA BUILDER ---
// This builds an SEO-friendly ItemList of Events representing each draw on this page
$schemaItemList = [
    "@context" => "https://schema.org",
    "@type" => "ItemList",
    "itemListElement" => []
];

foreach ($historyResults as $index => $row) {
    $drawDateObj = new DateTime($row['draw_date']);
    $drawUrl = "https://" . $_SERVER['HTTP_HOST'] . "/results/lotto-plus-1/" . strtolower($drawDateObj->format('d-F-Y'));
    
    // SAFETY FIX: Added ?? '' to gracefully handle empty values
    $winningNumbersStr = implode(', ', [
        $row['ball_1'] ?? '', 
        $row['ball_2'] ?? '', 
        $row['ball_3'] ?? '', 
        $row['ball_4'] ?? '', 
        $row['ball_5'] ?? '', 
        $row['ball_6'] ?? ''
    ]) . ". Bonus Ball: " . ($row['bonus_ball'] ?? '');

    // DYNAMIC SCHEMA: Calculate Top Prize for Schema
    $schemaTopPrize = "Rollover";
    if (!empty($row['div1_winners']) && $row['div1_winners'] > 0) {
        $schemaTopPrize = 'R ' . number_format((float)($row['div1_amount'] ?? 0), 2);
    } elseif (!empty($row['jackpot_amount'])) {
        $schemaTopPrize = is_numeric($row['jackpot_amount']) ? 'R ' . number_format((float)$row['jackpot_amount'], 2) : $row['jackpot_amount'];
    }
    
    $schemaItemList["itemListElement"][] = [
        "@type" => "ListItem",
        "position" => $index + 1,
        "item" => [
            "@type" => "Event", // Google prefers Event for dated occurrences
            "additionalType" => "http://schema.org/LotteryDraw", // Custom identifier for AI
            "name" => "Lotto Plus 1 Draw - " . $drawDateObj->format('d M Y'),
            "startDate" => $drawDateObj->format('Y-m-d\T20:57:00+02:00'), // Standard SAST draw time for Plus 1
            "url" => $drawUrl,
            "description" => "Official winning numbers: " . $winningNumbersStr . ". Top Prize: " . $schemaTopPrize . "."
        ]
    ];
}
$dynamicLotterySchemaJSON = json_encode($schemaItemList, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);


// --- SEO METADATA FIXES ---
if ($page === 1) {
    $pageTitle = "Past Lotto Plus 1 Results & History Archive | LottoGenius SA";
    $metaDesc = "Check past South African Lotto Plus 1 results, previous winning numbers, and official historical archives. Database updated after every Wednesday and Saturday draw.";
} else {
    $pageTitle = "Past Lotto Plus 1 Results - Page " . $page . " | LottoGenius SA";
    $metaDesc = "Page " . $page . " of the official South African Lotto Plus 1 results history and past winning numbers archive.";
}

$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    [
        "name" => "Home",
        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"
    ],
    [
        "name" => "Lotto Plus 1",
        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/lotto-plus-1"
    ],
    [
        "name" => "History",
        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/lotto-plus-1/history"
    ]
];

if ($page > 1) {
    $breadcrumbs[] = [
        "name" => "Page " . $page,
        "url" => $currentUrl . '?page=' . $page
    ];
}

// --- PAGE SPECIFIC FAQs (For HTML and JSON-LD Schema) ---
$pageFaqs = [
    [
        "question" => "What time are the Lotto Plus 1 results updated?",
        "answer" => "The official Lotto Plus 1 draw takes place every Wednesday and Saturday night immediately after the main Lotto draw (around 20:57 SAST). Our archive is updated as soon as the numbers are confirmed by Ithuba."
    ],
    [
        "question" => "Can I play Lotto Plus 1 on its own?",
        "answer" => "No, Lotto Plus 1 is an add-on game. To enter the Lotto Plus 1 draw, you must first purchase a standard Lotto ticket and check the 'Lotto Plus 1' option on your bet slip."
    ],
    [
        "question" => "Does the Lotto Plus 1 jackpot roll over?",
        "answer" => "Yes! Just like the main Lotto, if no one matches all 6 numbers in the Lotto Plus 1 draw, the jackpot amount rolls over and increases for the next draw."
    ],
    [
        "question" => "Are these past Lotto Plus 1 numbers verified?",
        "answer" => "Yes, our database is a comprehensive, verified archive. Every set of historical winning numbers and bonus balls is carefully cross-referenced with the official South African National Lottery data."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="keywords" content="past lotto plus 1 results, lotto plus 1 results yesterday, previous lotto plus 1 results South Africa, lotto plus 1 archive, lotto plus 1 history">
    
    <?php if($page > 1): ?>
        <meta name="robots" content="noindex, follow">
    <?php else: ?>
        <meta name="robots" content="index, follow">
    <?php endif; ?>

    <link rel="canonical" href="<?php echo $currentUrl . ($page > 1 ? '?page=' . $page : ''); ?>">

    <?php if($page > 1): ?>
        <link rel="prev" href="<?php echo $currentUrl . '?page=' . ($page - 1); ?>">
    <?php endif; ?>

    <?php if($page < $totalPages): ?>
        <link rel="next" href="<?php echo $currentUrl . '?page=' . ($page + 1); ?>">
    <?php endif; ?>

    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <meta name="language" content="en-ZA">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $currentUrl . ($page > 1 ? '?page=' . $page : ''); ?>">
    <meta property="og:image" content="https://yourdomain.co.za/assets/og-image.jpg">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $pageTitle; ?>">
    <meta name="twitter:description" content="<?php echo $metaDesc; ?>">
    <meta name="twitter:image" content="https://yourdomain.co.za/assets/og-image.jpg">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">

    <style>
        <?php echo file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/style/style.css'); ?>
        
        /* --- CENTERING FIX --- */
        .container {
            max-width: 1323px;
            margin: 0 auto;
            padding: 0 20px;
            width: 100%;
            box-sizing: border-box;
        }

        /* --- SIDEBAR PAGE LAYOUT STYLES --- */
        .layout-with-sidebar {
            display: grid;
            /* CRITICAL FIX: minmax(0, 1fr) forces the content area to not push the sidebar out of bounds */
            grid-template-columns: minmax(0, 1fr) 280px; 
            gap: 40px;
            align-items: start;
            margin-top: 24px;
        }
        
        .content-area {
            min-width: 0; /* Magic CSS Grid bullet: allows child elements to shrink properly */
            width: 100%;
        }

        .lotto-sidebar {
            position: sticky;
            top: 100px;
            z-index: 10;
        }

        .sidebar-menu {
            background: #ffffff;
            border-radius: var(--radius-md, 8px);
            overflow: hidden;
            box-shadow: var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, 0.1));
            border: 1px solid var(--border, #e2e8f0);
        }

        .sidebar-menu-header {
            background: linear-gradient(135deg, var(--primary, #2563eb), #9333ea);
            color: #ffffff;
            padding: 20px 24px;
            font-weight: 800;
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .sidebar-links {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .sidebar-links li {
            border-bottom: 1px solid #f1f5f9;
        }

        .sidebar-links li:last-child {
            border-bottom: none;
        }

        .sidebar-links a {
            display: flex;
            align-items: center;
            padding: 16px 24px;
            color: var(--text-muted, #64748b);
            font-weight: 600;
            font-size: 0.95rem;
            border-left: 4px solid transparent; 
            transition: all 0.2s ease;
            background: #ffffff;
            text-decoration: none;
        }

        .sidebar-links a:hover {
            background: #f8fafc;
            color: var(--text-main, #0f172a);
            border-left-color: #cbd5e1; 
        }

        .sidebar-links a.active {
            background: #f8fafc;
            color: var(--primary, #2563eb);
            border-left-color: var(--primary, #2563eb); 
            font-weight: 800;
        }

        .sidebar-links a.highlight {
            color: #d97706;
            font-weight: 700;
        }
        
        /* --- MODERN DISCLAIMER STYLES --- */
        .modern-disclaimer {
            display: flex;
            align-items: flex-start;
            gap: 16px;
            margin-top: 32px;
            margin-bottom: 40px;
            padding: 24px;
            background: linear-gradient(145deg, #f8fafc, #f1f5f9);
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            border-left: 2px solid #6a3ee7;
            box-shadow: inset 0 2px 4px rgba(255, 255, 255, 0.5), 0 2px 4px rgba(0, 0, 0, 0.02);
        }

        .disclaimer-icon {
            flex-shrink: 0;
            width: 22px;
            height: 22px;
            color: #94a3b8;
            margin-top: 2px;
        }

        .disclaimer-content {
            flex: 1;
        }

        .modern-disclaimer strong {
            display: block;
            color: #475569;
            font-weight: 700;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.8px;
            margin-bottom: 6px;
        }

        .modern-disclaimer p {
            margin: 0;
            font-size: 0.85rem;
            color: #64748b;
            line-height: 1.6;
            text-align: left;
        }

        @media(max-width: 480px) {
            .modern-disclaimer {
                padding: 20px;
                gap: 12px;
            }
            .disclaimer-icon {
                width: 18px;
                height: 18px;
            }
        }
        
        .sidebar-links a.highlight:hover {
            border-left-color: #d97706;
        }

        /* --- FRESHNESS BADGE STYLES --- */
        .freshness-badge {
            display: inline-flex;
            align-items: center;
            background: #ecfdf5;
            color: #059669;
            padding: 6px 12px;
            border-radius: 999px;
            font-size: 0.85rem;
            font-weight: 600;
            margin-top: 12px;
            border: 1px solid #a7f3d0;
        }
        .freshness-dot {
            width: 8px;
            height: 8px;
            background-color: #10b981;
            border-radius: 50%;
            margin-right: 8px;
            box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.2);
            animation: pulse-green 2s infinite;
        }
        @keyframes pulse-green {
            0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); }
            70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); }
            100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); }
        }

        /* --- SEO RICH CONTENT STYLES --- */
        .seo-rich-content {
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            border: 1px solid var(--border, #e2e8f0);
            margin-top: 40px;
        }
        
        .seo-rich-content h2 {
            font-size: 1.4rem;
            margin-top: 0;
            margin-bottom: 16px;
            color: var(--text-main);
        }
        
        .seo-rich-content h3 {
            font-size: 1.15rem;
            margin-top: 24px;
            margin-bottom: 12px;
            color: var(--text-main);
        }

        .seo-rich-content p {
            color: var(--text-muted);
            line-height: 1.7;
            font-size: 0.95rem;
            margin-bottom: 16px;
        }

        /* --- FAQ ACCORDION STYLES --- */
        .faq-section {
            margin-top: 40px;
            margin-bottom: 24px;
        }

        .faq-header {
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--text-main, #0f172a);
            margin-bottom: 24px;
            padding-left: 14px;
            border-left: 5px solid var(--primary, #4f46e5); 
            line-height: 1.2;
        }

        .faq-item {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 10px;
            margin-bottom: 14px;
            overflow: hidden;
            transition: box-shadow 0.2s ease;
        }

        .faq-item:hover {
            box-shadow: 0 2px 8px rgba(0,0,0,0.03);
        }

        .faq-question {
            width: 100%;
            text-align: left;
            background: transparent;
            border: none;
            padding: 20px 24px;
            font-size: 1.05rem;
            font-weight: 600;
            color: #1e293b;
            cursor: pointer;
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-family: inherit;
        }

        .faq-icon {
            color: var(--primary, #4f46e5);
            font-size: 1.6rem;
            line-height: 1;
            font-weight: 400;
            transition: transform 0.3s ease;
        }

        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height 0.3s ease, padding 0.3s ease;
            background: #ffffff;
        }

        .faq-answer-inner {
            padding: 0 24px 20px 24px;
            color: #475569;
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .faq-answer-inner p {
            margin: 0;
        }

        .faq-item.active .faq-icon {
            transform: rotate(45deg); 
        }
        
        .faq-item.active .faq-answer {
            max-height: 500px; 
        }

        /* --- RELATED CARDS STYLES --- */
        .related-cards-section {
            margin-top: 40px;
            margin-bottom: 24px;
        }

        .related-cards-header {
            font-size: 1.5rem;
            font-weight: 800;
            color: var(--text-main, #0f172a);
            margin-bottom: 20px;
        }

        .related-cards-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .related-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 24px 20px;
            border: 1px solid var(--border, #e2e8f0);
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .related-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 20px -8px rgba(0, 0, 0, 0.12);
        }

        .related-card-icon {
            font-size: 2.2rem;
            margin-bottom: 16px;
        }

        .related-card h3 {
            margin: 0 0 10px 0;
            font-size: 1.1rem;
            font-weight: 700;
            color: var(--text-main, #0f172a);
        }

        .related-card p {
            margin: 0 0 16px 0;
            font-size: 0.9rem;
            color: var(--text-muted, #64748b);
            line-height: 1.5;
        }

        .related-card a {
            display: inline-block;
            font-weight: 600;
            font-size: 0.95rem;
            color: var(--primary, #2563eb);
            text-decoration: none;
            transition: opacity 0.2s ease;
        }

        .related-card a:hover {
            text-decoration: underline;
            opacity: 0.8;
        }

        /* Ensure responsive shrinking */
        .table-responsive {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        @media(max-width: 1024px) {
            .layout-with-sidebar {
                grid-template-columns: 1fr;
            }
            .lotto-sidebar {
                position: relative;
                top: 0;
            }
        }
        
        @media(max-width: 768px) {
            .related-cards-grid {
                grid-template-columns: 1fr; 
            }
            .seo-rich-content {
                padding: 24px;
            }
            .faq-question {
                font-size: 1rem;
                padding: 16px;
            }
            .faq-answer-inner {
                padding: 0 16px 16px 16px;
            }
        }
        
        /* --- MODERN 2-COLUMN SEO CARDS STYLES --- */
        .seo-cards-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr); 
            gap: 24px;
            margin-top: 40px;
            margin-bottom: 32px;
        }

        .seo-card {
            background-color: #ffffff;
            background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='1.5' fill='%2364748b' fill-opacity='0.06'/%3E%3C/svg%3E");
            background-position: center top;
            border-radius: 12px;
            padding: 32px 28px;
            border: 1px solid var(--border, #e2e8f0);
            border-top: 4px solid var(--primary, #2563eb); 
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05), 0 2px 4px -1px rgba(0, 0, 0, 0.03);
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        .seo-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            background-image: url("data:image/svg+xml,%3Csvg width='24' height='24' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg'%3E%3Ccircle cx='2' cy='2' r='1.5' fill='%2364748b' fill-opacity='0.12'/%3E%3C/svg%3E");
        }

        .seo-card-icon {
            font-size: 2rem;
            margin-bottom: 16px;
            line-height: 1;
        }

        .seo-card h2, 
        .seo-card h3 {
            font-size: 1.25rem;
            font-weight: 800;
            color: var(--text-main, #0f172a);
            margin-top: 0;
            margin-bottom: 16px;
            line-height: 1.3;
        }

        .seo-card p {
            color: var(--text-muted, #64748b);
            line-height: 1.6;
            font-size: 0.95rem;
            margin: 0;
        }

        @media(max-width: 768px) {
            .seo-cards-container {
                grid-template-columns: 1fr; 
                gap: 20px;
            }
            .seo-card {
                padding: 24px;
            }
        }

        /* --- MODERN INTERNAL LINKS (PILL STYLE) --- */
        .modern-internal-links {
            margin-top: 40px;
            margin-bottom: 32px;
            background: #ffffff;
            padding: 32px;
            border-radius: 12px;
            border: 1px solid var(--border, #e2e8f0);
        }

        .modern-internal-links h2 {
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--text-main, #0f172a);
            margin-top: 0;
            margin-bottom: 20px;
        }

        .modern-internal-links .nav-pills {
            list-style: none;
            padding: 0;
            margin: 0;
            display: flex;
            flex-wrap: wrap; 
            gap: 12px;
        }

        .modern-internal-links .nav-pills li {
            margin: 0;
        }

        .modern-internal-links .nav-pills a {
            display: inline-flex;
            align-items: center;
            background: #f8fafc;
            color: var(--text-main, #334155);
            text-decoration: none;
            padding: 12px 20px;
            border-radius: 999px; 
            font-size: 0.95rem;
            font-weight: 600;
            border: 1px solid #e2e8f0;
            transition: all 0.2s ease;
        }

        .modern-internal-links .nav-pills a svg {
            width: 16px;
            height: 16px;
            margin-left: 10px;
            color: var(--primary, #2563eb);
            transition: transform 0.2s ease;
        }

        .modern-internal-links .nav-pills a:hover {
            background: var(--primary, #2563eb);
            color: #ffffff;
            border-color: var(--primary, #2563eb);
            box-shadow: 0 4px 10px -2px rgba(37, 99, 235, 0.25);
        }

        .modern-internal-links .nav-pills a:hover svg {
            color: #ffffff;
            transform: translateX(4px); 
        }

        @media(max-width: 768px) {
            .modern-internal-links {
                padding: 24px;
            }
            .modern-internal-links .nav-pills a {
                width: 100%; 
                justify-content: space-between;
            }
        }
        
        /* --- ADDED SEARCH FORM CSS --- */
        .history-search-form {
            display: flex;
            align-items: center;
            gap: 8px;
            background: #f8fafc;
            padding: 6px 12px;
            border-radius: 8px;
            border: 1px solid #e2e8f0;
            margin: 0 auto; /* Keeps it centered in the flex container */
        }
        .search-form-label {
            font-size: 0.8rem;
            font-weight: 700;
            color: #475569;
        }
        .search-form-input {
            border: 1px solid #cbd5e1;
            border-radius: 4px;
            padding: 4px 8px;
            font-size: 0.85rem;
            font-family: 'Inter', sans-serif;
            color: #1e293b;
        }
        .search-form-input:disabled {
            background: #e2e8f0;
            cursor: not-allowed;
        }
        .btn-search-go {
            background: #2563eb;
            color: white;
            border: none;
            padding: 5px 12px;
            border-radius: 4px;
            font-size: 0.85rem;
            font-weight: 600;
            cursor: pointer;
        }
        .btn-search-go:hover {
            background: #1d4ed8;
        }
        .btn-search-reset {
            font-size: 0.8rem;
            color: #ef4444;
            text-decoration: none;
            font-weight: 600;
            margin-left: 4px;
        }

    </style>

    <link rel="icon" href="/favicon.ico" type="image/x-icon">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "CollectionPage",
      "name": "<?php echo $pageTitle; ?>",
      "description": "<?php echo $metaDesc; ?>",
      "url": "<?php echo $currentUrl; ?>",
      "inLanguage": "en-ZA",
      "isPartOf": {
        "@type": "WebSite",
        "name": "LottoGenius SA",
        "url": "https://yourdomain.co.za"
      }
    }
    </script>

    <script type="application/ld+json">
        {
          "@context": "https://schema.org",
          "@type": "BreadcrumbList",
          "itemListElement": [
            <?php foreach ($breadcrumbs as $index => $crumb): ?>
            {
              "@type": "ListItem",
              "position": <?php echo $index + 1; ?>,
              "name": "<?php echo $crumb['name']; ?>",
              "item": "<?php echo $crumb['url']; ?>"
            }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
            <?php endforeach; ?>
          ]
        }
    </script>

    <?php if($page === 1 && !empty($pageFaqs)): ?>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
    <?php endif; ?>

    <?php if(!empty($historyResults)): ?>
    <script type="application/ld+json">
    <?php echo $dynamicLotterySchemaJSON; ?>
    </script>
    <?php endif; ?>

</head>
<body>

    <?php include __DIR__ . '/../../../static/nav.php'; ?>

    <main class="container">
        <nav class="breadcrumb">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link">
                                <?php echo $crumb['name']; ?>
                            </a>
                        <?php else: ?>
                            <span class="breadcrumb-current">
                                <?php echo $crumb['name']; ?>
                            </span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>
        
        <div class="layout-with-sidebar">
            
            <div class="content-area">
                
                <?php if($page > 1): ?>
                <section class="seo-rich-content-pagination">
                    <h1>Lotto Plus 1 Results History – Page <?php echo $page; ?></h1>
                    <p>
                        This is page <?php echo $page; ?> of the South African <strong>Lotto Plus 1 results history</strong>.
                        Browse <strong>past Lotto Plus 1 results</strong>, winning numbers, and jackpot amounts from previous draws.
                        Explore over <?php echo $totalRecords; ?> verified results in our complete Lotto Plus 1 archive.
                    </p>
                </section>
                <?php endif; ?>
                
                <section class="table-card">
                    <article class="page-header" style="text-align: left; margin-bottom: 24px;">
                    <?php if($page === 1): ?>
                        <h1 style="margin-top: 0 !important; margin-bottom: 8px;">Past Lotto Plus 1 Results &amp; History Archive</h1>
                    <?php else: ?>
                        <h2>Past Lotto Plus 1 Results &amp; History Archive</h2>
                    <?php endif; ?>
                    
                    <p style="margin: 0; font-size: 1.05rem;">Browse our comprehensive archive of official South African Lotto Plus 1 draws. Analyse past winning numbers and refine your strategy using our verified database.</p>
                    
                    <h2 style="margin-top: 24px;">Latest Lotto Plus 1 Results</h2>
                    
                    <?php if(!empty($latestSlug)): ?>
                        <p style="margin: 0; font-size: 1.05rem;">Looking for the most recent Lotto Plus 1 results? View the latest winning numbers and payout details on our <a href="/results/lotto-plus-1/<?php echo $latestSlug; ?>">latest results page</a>, updated immediately after each official Ithuba draw.</p>
                    <?php else: ?>
                        <p style="margin: 0; font-size: 1.05rem;">Looking for the most recent Lotto Plus 1 results? View the latest winning numbers and payout details on our <a href="/results/lotto-plus-1/">latest results page</a>, updated immediately after each official Ithuba draw.</p>
                    <?php endif; ?>
                    
                    <?php if($page === 1 && !empty($historyResults)): ?>
                    <div class="freshness-badge">
                        <div class="freshness-dot"></div>
                        Live Archive: Updated <?php echo $lastUpdatedText; ?>
                    </div>
                    <?php endif; ?>
                                        
                </article>
                
                    <div class="table-controls" style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                        <h2 style="font-size: 1.15rem; margin: 0;">Verified Draw</h2>
                        
                        <form method="GET" action="" class="history-search-form">
                            <span class="search-form-label">Start Date:</span>
                            <input type="date" name="start_date" id="start_date" class="search-form-input" 
                                   value="<?php echo htmlspecialchars($startDate ?? ''); ?>" 
                                   min="<?php echo $minDbDate; ?>" max="<?php echo $maxDbDate; ?>" required>
                            
                            <span class="search-form-label">End Date:</span>
                            <input type="date" name="end_date" id="end_date" class="search-form-input" 
                                   value="<?php echo htmlspecialchars($endDate ?? ''); ?>" 
                                   min="<?php echo $minDbDate; ?>" max="<?php echo $maxDbDate; ?>"
                                   <?php echo !$startDate ? 'disabled' : ''; ?> required>
                            
                            <button type="submit" class="btn-search-go">Search</button>
                            <?php if($startDate): ?>
                                <a href="/results/lotto-plus-1/history/" class="btn-search-reset">Clear</a>
                            <?php endif; ?>
                        </form>

                        <span class="records-count">Page <?php echo $page; ?> of <?php echo $totalPages > 0 ? $totalPages : 1; ?> (Total Draws: <?php echo $totalRecords; ?>)</span>
                    </div>
                    
                    <?php if(count($historyResults) > 0): ?>
                    <div class="table-responsive">
                        <table class="pro-table">
                            <thead>
                                <tr>
                                    <th>Draw Date</th>
                                    <th>Winning Numbers</th>
                                    <th>Top Prize</th>
                                    <th>Total Winners</th>
                                    <th style="text-align: right;">Draw Data</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($historyResults as $row): 
                                    $dateObj = new DateTime($row['draw_date']);
                                    $dayName = $dateObj->format('l'); // e.g. Saturday
                                    $fullDate = $dateObj->format('d M Y'); // e.g. 18 Apr 2026
                                    $shortDate = $dateObj->format('d M'); // e.g. 18 Apr
                                    
                                    $urlSlug = strtolower($dateObj->format('d-F-Y'));

                                    // DYNAMIC DATA CALCULATION: Total Winners (Summing div1 to div8)
                                    $totalWinners = 0;
                                    for ($i = 1; $i <= 8; $i++) {
                                        $totalWinners += (int)($row["div{$i}_winners"] ?? 0);
                                    }
                                    $totalWinnersFormatted = number_format($totalWinners);

                                    // DYNAMIC DATA CALCULATION: Top Prize
                                    $topPrize = "Rollover";
                                    if (!empty($row['div1_winners']) && $row['div1_winners'] > 0) {
                                        $topPrize = 'R ' . number_format((float)($row['div1_amount'] ?? 0), 2);
                                    } elseif (!empty($row['jackpot_amount'])) {
                                        $topPrize = is_numeric($row['jackpot_amount']) ? 'R ' . number_format((float)$row['jackpot_amount'], 2) : $row['jackpot_amount'];
                                    }
                                ?>
                                <tr>
                                    <td class="td-date">
                                        <span class="day-badge"><?php echo $dayName; ?></span>
                                        <?php echo $fullDate; ?>
                                    </td>
                                    <td>
                                        <div class="table-balls-wrap">
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_1'] ?? '')); ?></div>
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_2'] ?? '')); ?></div>
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_3'] ?? '')); ?></div>
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_4'] ?? '')); ?></div>
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_5'] ?? '')); ?></div>
                                            <div class="table-ball"><?php echo htmlspecialchars((string)($row['ball_6'] ?? '')); ?></div>
                                            <div class="table-ball" style="background-color: #fbbf24; color: #fff; border-color: #d97706; margin-left: 4px;" title="Bonus Ball"><?php echo htmlspecialchars((string)($row['bonus_ball'] ?? '')); ?></div>
                                        </div>
                                    </td>
                                    <td class="td-jackpot"><?php echo htmlspecialchars($topPrize); ?></td>
                                    <td class="td-winners"><?php echo htmlspecialchars($totalWinnersFormatted); ?></td>
                                    <td style="text-align: right;">
                                        <a href="/results/lotto-plus-1/<?php echo $urlSlug; ?>" class="btn-sm-outline" aria-label="View Lotto Plus 1 results for <?php echo $fullDate; ?>">
                                            View <?php echo $shortDate; ?> Results
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                        <div style="text-align:center; padding: 40px; background: #f8fafc; border-radius: 8px;">No draws found for this date range.</div>
                    <?php endif; ?>
                    
                    <?php if ($totalPages > 1): ?>
                    <div class="pagination-container">
                        
                        <?php 
                        // Persist search filters across pagination links
                        $filterStr = ($startDate && $endDate) ? "&start_date=" . urlencode($startDate) . "&end_date=" . urlencode($endDate) : "";
                        
                        if ($page > 1): ?>
                            <a href="?page=<?php echo $page - 1; ?><?php echo $filterStr; ?>" class="page-btn">Prev</a>
                        <?php else: ?>
                            <span class="page-btn disabled">Prev</span>
                        <?php endif; ?>

                        <?php 
                        $startPage = max(1, $page - 2);
                        $endPage = min($totalPages, $page + 2);
                        
                        if ($startPage > 1) {
                            echo '<a href="?page=1' . $filterStr . '" class="page-btn">1</a>';
                            if ($startPage > 2) echo '<span class="page-btn disabled">...</span>';
                        }

                        for ($i = $startPage; $i <= $endPage; $i++) {
                            if ($i == $page) {
                                echo '<span class="page-btn active">' . $i . '</span>';
                            } else {
                                echo '<a href="?page=' . $i . $filterStr . '" class="page-btn">' . $i . '</a>';
                            }
                        }

                        if ($endPage < $totalPages) {
                            if ($endPage < $totalPages - 1) echo '<span class="page-btn disabled">...</span>';
                            echo '<a href="?page=' . $totalPages . $filterStr . '" class="page-btn">' . $totalPages . '</a>';
                        }
                        ?>

                        <?php if ($page < $totalPages): ?>
                            <a href="?page=<?php echo $page + 1; ?><?php echo $filterStr; ?>" class="page-btn">Next</a>
                        <?php else: ?>
                            <span class="page-btn disabled">Next</span>
                        <?php endif; ?>
                        
                    </div>
                    <?php endif; ?>

                </section>
                
                <?php if($page === 1 && !$startDate): ?>
                
                <section class="seo-cards-container">
                    <div class="seo-card">
                        <div class="seo-card-icon">📂</div>
                        <h2>Your Trusted Results Archive</h2>
                        <p>Whether you're searching for <a href="/results/lotto-plus-1">the latest lotto plus 1 results</a> or analyzing <strong>past lotto plus 1 results</strong> from months ago, LottoGenius SA provides the most accurate and up-to-date database in South Africa. Our team ensures that every number in our <strong>lotto plus 1 results archive</strong> is verified against the official Ithuba draw data.</p>
                    </div>
                    
                    <div class="seo-card">
                        <div class="seo-card-icon">📈</div>
                        <h3>Why Check Previous Results?</h3>
                        <p>Smart players don't just guess; they analyze. By studying <strong>lotto plus 1 results history</strong>, players can identify frequency patterns, track hot and cold numbers, and avoid combinations that were recently drawn. 
                            
                            To go deeper, explore our <a href="/results/lotto-plus-1/hot-cold">lotto plus 1 statistics</a> to see which numbers are trending and discover actionable insights before your next ticket purchase.
                            </p>
                    </div>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>
                
                <?php endif; ?>
                
                <section class="modern-internal-links">
                    <h2>Explore Lotto Plus 1 Results</h2>
                    <ul class="nav-pills">
                        <li>
                            <a href="/results/lotto-plus-1">
                                Latest Lotto Plus 1 Results
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                        <li>
                            <a href="/results/lotto-plus-1/hot-cold">
                                Hot and Cold Numbers
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                        <li>
                            <a href="/results/lotto-plus-1/predictions">
                                Lotto Plus 1 Predictions
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                        <li>
                            <a href="/results/lotto-plus-1/payouts">
                                Prize Breakdown
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                    </ul>
                </section>

                <section class="related-cards-section">
                    <h2 class="related-cards-header">More Lotto Plus 1 Tools</h2>
                    <div class="related-cards-grid">
                        <div class="related-card">
                            <div class="related-card-icon">🤖</div>
                            <h3>Smart Predictions</h3>
                            <p>Use our data-driven algorithm to generate your next Lotto Plus 1 ticket based on historical patterns.</p>
                            <a href="/results/lotto-plus-1/predictions">Get Plus 1 Predictions &rarr;</a>
                        </div>
                        <div class="related-card">
                            <div class="related-card-icon">🔥</div>
                            <h3>Hot &amp; Cold Numbers</h3>
                            <p>Discover which numbers are drawn most frequently and which ones are currently overdue.</p>
                            <a href="/results/lotto-plus-1/hot-cold">View Hot/Cold Stats &rarr;</a>
                        </div>
                        <div class="related-card">
                            <div class="related-card-icon">🎫</div>
                            <h3>Check Your Tickets</h3>
                            <p>Instantly check your numbers against the latest official results to see if you're a winner.</p>
                            <a href="/results/lotto-plus-1/check-tickets">Check Plus 1 Tickets &rarr;</a>
                        </div>
                    </div>
                </section>

                <div class="modern-disclaimer">
                    <svg class="disclaimer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="16" x2="12" y2="12"></line>
                        <line x1="12" y1="8" x2="12.01" y2="8"></line>
                    </svg>
                    <div class="disclaimer-content">
                        <strong>Disclaimer</strong>
                        <p>LottoGenius SA is an independent informational platform and is not affiliated with, endorsed, or sponsored by the official South African National Lottery or Ithuba Holdings. We strive to provide accurate and up-to-date information, but we do not guarantee the absolute accuracy of the results provided. Always verify your tickets with an official National Lottery retailer.</p>
                    </div>
                </div>

            </div> 
            
            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lotto Plus 1 navigation">
                    <div class="sidebar-menu-header">Lotto Plus 1 Menu</div>
                    
                    <ul class="sidebar-links">
            
                        <li>
                            <a href="/results/lotto-plus-1">
                                Latest Lotto Plus 1 Results
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/history" class="active">
                                Lotto Plus 1 Draw History & Past Results
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/predictions">
                                Lotto Plus 1 Predictions & Number Picks
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/check-tickets">
                                Check Lotto Plus 1 Tickets Online
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/hot-cold">
                                Lotto Plus 1 Hot and Cold Numbers
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/payouts">
                                Lotto Plus 1 Prize Payouts & Dividends
                            </a>
                        </li>
            
                        <li>
                            <a href="/faqs">
                                Lotto FAQs & Help Guide
                            </a>
                        </li>
            
                        <li>
                            <a href="/how-to-play">
                                How to Play Lotto South Africa
                            </a>
                        </li>
            
                        <li>
                            <a href="/results/lotto-plus-1/generator">
                                Lotto Plus 1 Number Generator Tool
                            </a>
                        </li>
            
                        <li>
                            <a href="https://affiliates.hollywoodbets.net/" 
                               class="highlight" 
                               target="_blank" 
                               rel="noopener nofollow sponsored">
                                Play Lotto Online
                            </a>
                        </li>
            
                    </ul>
                </nav>
            </aside>
            
        </div>
    </main>

    <?php include __DIR__ . '/../../../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            
            // --- ADDED: START AND END DATE SELECTION LOGIC ---
            const startInput = document.getElementById('start_date');
            const endInput = document.getElementById('end_date');

            if (startInput && endInput) {
                startInput.addEventListener('change', function() {
                    if (this.value) {
                        endInput.disabled = false;
                        endInput.min = this.value;
                    } else {
                        endInput.disabled = true;
                        endInput.value = '';
                    }
                });
            }

            const faqQuestions = document.querySelectorAll('.faq-question');
            
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    
                    // Close all other open FAQs (Optional: remove this if you want multiple to stay open)
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) {
                            item.classList.remove('active');
                        }
                    });

                    // Toggle current FAQ
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>