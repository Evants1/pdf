<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// BULLETPROOF PATH: Connect to your database
// Adjust this path if this file is located in a different folder depth!
require_once __DIR__ . '/../../db.php';

// --- DETERMINE NEXT DRAW DATE (Tue & Fri) ---
$currentTime = time();
$todayName = date('l');
$drawTimeToday = strtotime('today 21:00:00'); // PowerBall draws at 21:00

if (($todayName === 'Tuesday' || $todayName === 'Friday') && $currentTime <= $drawTimeToday) {
    // If today is a draw day AND it's before 9:00 PM
    $nextDrawTimestamp = strtotime('today');
} else {
    // Otherwise, find the NEXT Tuesday or Friday
    $nextTue = strtotime('next Tuesday');
    $nextFri = strtotime('next Friday');
    $nextDrawTimestamp = min($nextTue, $nextFri);
}

$nextDrawDate = date('Y-m-d', $nextDrawTimestamp);
$nextDrawFormatted = date('d F Y', $nextDrawTimestamp);
$nextDrawDay = date('l', $nextDrawTimestamp);

// --- FETCH LAST 50 DRAWS FOR ANALYSIS ---
$analyzeLimit = 50;
$stmt = $pdo->prepare("SELECT ball_1, ball_2, ball_3, ball_4, ball_5, powerball, draw_date FROM powerball_results ORDER BY draw_date DESC LIMIT :limit");
$stmt->bindValue(':limit', $analyzeLimit, PDO::PARAM_INT);
$stmt->execute();
$historyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- DATA PROCESSING & ALGORITHM (50 MAIN BALLS, 20 POWERBALLS) ---
$numberFrequency = array_fill(1, 50, 0);
$pbFrequency = array_fill(1, 20, 0);
$lastSeen = array_fill(1, 50, null);

// Pairs and Triplets tracking (Main balls only)
$pairCounts = [];
$tripletCounts = [];

foreach ($historyResults as $draw) {
    $drawDate = $draw['draw_date'];
    $ballsInDraw = [];
    
    // Process main 5 single numbers
    for ($i = 1; $i <= 5; $i++) {
        $ball = (int)$draw['ball_' . $i];
        if ($ball >= 1 && $ball <= 50) {
            $numberFrequency[$ball]++;
            $ballsInDraw[] = $ball;
            if ($lastSeen[$ball] === null || $drawDate > $lastSeen[$ball]) {
                $lastSeen[$ball] = $drawDate;
            }
        }
    }
    
    // Process PowerBall
    $pb = (int)$draw['powerball'];
    if ($pb >= 1 && $pb <= 20) {
        $pbFrequency[$pb]++;
    }
    
    // Process Pairs and Triplets for this draw
    sort($ballsInDraw);
    $len = count($ballsInDraw);
    
    if ($len >= 2) {
        for ($i = 0; $i < $len - 1; $i++) {
            for ($j = $i + 1; $j < $len; $j++) {
                $pair = $ballsInDraw[$i] . ',' . $ballsInDraw[$j];
                $pairCounts[$pair] = ($pairCounts[$pair] ?? 0) + 1;
            }
        }
    }
    
    if ($len >= 3) {
        for ($i = 0; $i < $len - 2; $i++) {
            for ($j = $i + 1; $j < $len - 1; $j++) {
                for ($k = $j + 1; $k < $len; $k++) {
                    $triplet = $ballsInDraw[$i] . ',' . $ballsInDraw[$j] . ',' . $ballsInDraw[$k];
                    $tripletCounts[$triplet] = ($tripletCounts[$triplet] ?? 0) + 1;
                }
            }
        }
    }
}

// Sort to find Hot and Cold Main Balls
arsort($numberFrequency); 
$hotNumbersAll = array_keys($numberFrequency);
$coldNumbersAll = array_reverse($hotNumbersAll); 

// Sort to find Hot and Cold PowerBalls
arsort($pbFrequency);
$hotPbAll = array_keys($pbFrequency);
$coldPbAll = array_reverse($hotPbAll);

// Sort Pairs and Triplets
arsort($pairCounts);
arsort($tripletCounts);
$topPairs = array_slice($pairCounts, 0, 4, true); 
$topTriplets = array_slice($tripletCounts, 0, 3, true); 

// Extract subsets for Main Balls (5 numbers needed)
$topHot = array_slice($hotNumbersAll, 0, 5); 
$topCold = array_slice($coldNumbersAll, 0, 5);
$midNumbers = array_slice($hotNumbersAll, 20, 10);
shuffle($midNumbers);

// Extract PowerBalls
$hotPb = $hotPbAll[0]; // #1 Hottest PB
$coldPb = $coldPbAll[0]; // #1 Coldest PB
$midPbArray = array_slice($hotPbAll, 5, 10);
shuffle($midPbArray);
$midPb = $midPbArray[0];

// --- GENERATE PREDICTION SETS (5 MAIN + 1 PB EACH) ---

// Set 1: Balanced (2 Hot, 2 Cold, 1 Mid) + Mid PB
$set1_main = array_merge(array_slice($topHot, 0, 2), array_slice($topCold, 0, 2), array_slice($midNumbers, 0, 1));
sort($set1_main);
$set1_pb = $midPb;

// Set 2: Hot Numbers Focus (5 Hot) + Hot PB
$set2_main = $topHot;
sort($set2_main);
$set2_pb = $hotPb;

// Set 3: Cold Numbers Strategy (5 Cold) + Cold PB
$set3_main = $topCold;
sort($set3_main);
$set3_pb = $coldPb;

// --- VERIFY PREVIOUS DRAW ACCURACY ---
$latestDraw = $historyResults[0] ?? null;
$latestDrawMatchesHTML = '';
if ($latestDraw) {
    $latestBalls = [];
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($latestDraw['ball_' . $i])) $latestBalls[] = (int)$latestDraw['ball_' . $i];
    }
    $latestBonus = (int)$latestDraw['powerball'];
    $latestDateFormatted = date('d M Y', strtotime($latestDraw['draw_date']));
    
    // Check if the previous draw's numbers were in our tracking zones
    $matchElements = [];
    foreach ($latestBalls as $b) {
        if (in_array($b, array_slice($hotNumbersAll, 0, 10))) {
            $matchElements[] = "<span class='acc-badge acc-hot'>$b (Hot)</span>";
        } elseif (in_array($b, array_slice($coldNumbersAll, 0, 10))) {
            $matchElements[] = "<span class='acc-badge acc-cold'>$b (Cold)</span>";
        } elseif (in_array($b, array_slice($hotNumbersAll, 10, 15))) {
            $matchElements[] = "<span class='acc-badge acc-warm'>$b (Warm)</span>";
        } else {
            $matchElements[] = "<span class='acc-badge acc-neutral'>$b</span>";
        }
    }
    
    // Check PB accuracy
    if ($latestBonus == $hotPb) {
        $pbLabel = " (Hot)";
        $pbClass = "acc-hot-pb";
    } elseif ($latestBonus == $coldPb) {
        $pbLabel = " (Cold)";
        $pbClass = "acc-cold-pb";
    } else {
        $pbLabel = "";
        $pbClass = "acc-neutral-pb";
    }
    
    $matchElements[] = "<span class='acc-badge $pbClass' style='border-width: 2px;'>PB: $latestBonus$pbLabel</span>";
    
    $latestDrawMatchesHTML = implode(' ', $matchElements);
}

// Prepare Chart Data
$chartLabels = array_slice($hotNumbersAll, 0, 10); // Top 10 numbers
$chartData = [];
foreach ($chartLabels as $num) {
    $chartData[] = $numberFrequency[$num];
}

// --- FRESHNESS SIGNAL ---
$lastUpdatedText = date('F j, Y \a\t g:i A');

// --- SEO METADATA ---
$pageTitle = "PowerBall Predictions South Africa Today | Smart Picks & Analysis";
$metaDesc = "Get data-driven SA PowerBall predictions for {$nextDrawFormatted}. View balanced, hot, and cold strategies for the 5 main balls plus the PowerBall, based on 50-draw frequency analysis.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "PowerBall", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/powerball"],
    ["name" => "Predictions", "url" => $currentUrl]
];

// --- PAGE SPECIFIC FAQs ---
$pageFaqs = [
    [
        "question" => "Are these SA PowerBall predictions guaranteed to win?",
        "answer" => "No. Lottery draws are inherently random, and no system can guarantee a win. However, our data-driven predictions use statistical frequency and historical patterns from the last 50 draws to help you make informed choices rather than picking blindly."
    ],
    [
        "question" => "How are these PowerBall numbers generated?",
        "answer" => "We use an algorithmic approach that analyzes the most recent 50 South African PowerBall draws. We independently track the main 50-ball pool and the separate 20-ball PowerBall pool to extract the 'Hot' and 'Cold' numbers for both segments."
    ],
    [
        "question" => "When is the next SA PowerBall draw?",
        "answer" => "The official SA PowerBall draws take place every Tuesday and Friday at 21:00 SAST."
    ],
    [
        "question" => "Why do you predict the PowerBall separately?",
        "answer" => "Because the South African PowerBall is drawn from a completely separate machine with only 20 balls (compared to the 50 main balls). A mathematical prediction model must treat them as two entirely different probability pools to be accurate."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="keywords" content="powerball prediction for <?php echo strtolower($nextDrawFormatted); ?>, powerball predictions today, powerball predictions south africa, powerball hot numbers, smart powerball picks, powerball pairs">
    
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo $currentUrl; ?>">
    <meta property="og:image" content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/assets/og-image.jpg">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Automatically includes your main style if available */
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* --- CENTERING FIX --- */
        .container {
            max-width: 1323px;
            margin: 0 auto;
            padding: 0 20px;
            width: 100%;
            box-sizing: border-box;
        }

        /* --- SIDEBAR PAGE LAYOUT STYLES --- */
        .layout-with-sidebar {
            display: grid;
            grid-template-columns: minmax(0, 1fr) 280px; 
            gap: 40px;
            align-items: start;
            margin-top: 24px;
        }
        
        .content-area {
            min-width: 0; 
            width: 100%;
        }

        .lotto-sidebar {
            position: sticky;
            top: 100px;
            z-index: 10;
        }

        .sidebar-menu {
            background: #ffffff;
            border-radius: var(--radius-md, 8px);
            overflow: hidden;
            box-shadow: var(--shadow-md, 0 4px 6px -1px rgba(0, 0, 0, 0.1));
            border: 1px solid var(--border, #e2e8f0);
        }

        .sidebar-menu-header {
            background: linear-gradient(135deg, #e11d48, #9f1239); /* Red gradient for PowerBall */
            color: #ffffff;
            padding: 20px 24px;
            font-weight: 800;
            font-size: 1.1rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .sidebar-links {
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .sidebar-links li {
            border-bottom: 1px solid #f1f5f9;
        }

        .sidebar-links li:last-child {
            border-bottom: none;
        }

        .sidebar-links a {
            display: flex;
            align-items: center;
            padding: 16px 24px;
            color: var(--text-muted, #64748b);
            font-weight: 600;
            font-size: 0.95rem;
            border-left: 4px solid transparent; 
            transition: all 0.2s ease;
            background: #ffffff;
            text-decoration: none;
        }

        .sidebar-links a:hover {
            background: #fff1f2;
            color: var(--text-main, #0f172a);
            border-left-color: #fecdd3; 
        }

        .sidebar-links a.active {
            background: #fff1f2;
            color: #e11d48;
            border-left-color: #e11d48; 
            font-weight: 800;
        }

        .sidebar-links a.highlight {
            color: #d97706;
            font-weight: 700;
        }
        
        .sidebar-links a.highlight:hover {
            border-left-color: #d97706;
        }
        
        /* --- MODERN DISCLAIMER STYLES --- */
        .modern-disclaimer {
            display: flex;
            align-items: flex-start;
            gap: 16px;
            margin-top: 32px;
            margin-bottom: 40px;
            padding: 24px;
            background: linear-gradient(145deg, #f8fafc, #f1f5f9);
            border-radius: 12px;
            border: 1px solid #e2e8f0;
            border-left: 2px solid #6a3ee7;
            box-shadow: inset 0 2px 4px rgba(255, 255, 255, 0.5), 0 2px 4px rgba(0, 0, 0, 0.02);
        }

        .disclaimer-icon { flex-shrink: 0; width: 22px; height: 22px; color: #94a3b8; margin-top: 2px; }
        .disclaimer-content { flex: 1; }
        .modern-disclaimer strong { display: block; color: #475569; font-weight: 700; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.8px; margin-bottom: 6px; }
        .modern-disclaimer p { margin: 0; font-size: 0.85rem; color: #64748b; line-height: 1.6; text-align: left; }

        /* Freshness & SEO Header */
        .freshness-badge { display: inline-flex; align-items: center; background: #ecfdf5; color: #059669; padding: 8px 14px; border-radius: 999px; font-size: 0.85rem; font-weight: 700; margin-bottom: 20px; border: 1px solid #a7f3d0; }
        .freshness-dot { width: 8px; height: 8px; background-color: #10b981; border-radius: 50%; margin-right: 8px; animation: pulse-green 2s infinite; }
        @keyframes pulse-green { 0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); } 70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); } 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); } }

        /* Accuracy Verification Block */
        .accuracy-block { background: linear-gradient(to right, #f8fafc, #ffffff); border: 1px solid #e2e8f0; border-left: 4px solid #8b5cf6; padding: 20px 24px; border-radius: 8px; margin-bottom: 30px; display: flex; flex-direction: column; gap: 12px; }
        .accuracy-title { font-weight: 800; font-size: 1.1rem; color: #0f172a; display: flex; align-items: center; gap: 8px; margin: 0; }
        .accuracy-desc { font-size: 0.95rem; color: #475569; margin: 0; }
        .acc-badge-container { display: flex; flex-wrap: wrap; gap: 8px; margin-top: 4px; }
        .acc-badge { padding: 6px 12px; border-radius: 6px; font-size: 0.9rem; font-weight: 700; border: 1px solid; }
        .acc-hot { background: #fef2f2; color: #b91c1c; border-color: #fca5a5; }
        .acc-cold { background: #eff6ff; color: #1d4ed8; border-color: #bfdbfe; }
        .acc-warm { background: #fffbeb; color: #b45309; border-color: #fcd34d; }
        .acc-neutral { background: #f1f5f9; color: #475569; border-color: #cbd5e1; }
        .acc-hot-pb { background: #e11d48; color: #ffffff; border-color: #9f1239; }
        .acc-cold-pb { background: #2563eb; color: #ffffff; border-color: #1e40af; }
        .acc-neutral-pb { background: #f43f5e; color: #ffffff; border-color: #e11d48; }

        /* Prediction Blocks */
        .predictions-grid { display: grid; gap: 24px; margin-top: 30px; margin-bottom: 40px; }
        .prediction-card { background: #ffffff; border-radius: 12px; padding: 30px; border: 1px solid #e2e8f0; border-top: 5px solid #2563eb; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .pred-card-hot { border-top-color: #ef4444; }
        .pred-card-cold { border-top-color: #3b82f6; }
        .pred-card-balanced { border-top-color: #10b981; }
        
        .prediction-header { display: flex; align-items: center; gap: 12px; margin-bottom: 20px; }
        .prediction-icon { font-size: 1.8rem; }
        .prediction-header h3 { margin: 0; font-size: 1.3rem; color: #0f172a; font-weight: 800; }
        
        .balls-container { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px; }
        .lotto-ball { display: flex; align-items: center; justify-content: center; width: 48px; height: 48px; border-radius: 50%; background: #f8fafc; border: 2px solid #cbd5e1; font-weight: 800; font-size: 1.1rem; color: #334155; box-shadow: inset 0 -2px 4px rgba(0,0,0,0.05); }
        .lotto-ball.hot { border-color: #fca5a5; background: #fef2f2; color: #b91c1c; }
        .lotto-ball.cold { border-color: #bfdbfe; background: #eff6ff; color: #1d4ed8; }
        .pb-ball { background: #f43f5e; color: #ffffff; border-color: #e11d48; margin-left: 10px; }
        .pb-ball.hot { background: #be123c; border-color: #881337; }
        .pb-ball.cold { background: #3b82f6; border-color: #1d4ed8; }

        .pred-reason { background: #f1f5f9; padding: 16px; border-radius: 8px; font-size: 0.95rem; color: #475569; line-height: 1.5; margin: 0; border-left: 3px solid #94a3b8; }
        
        /* Pairs and Triplets Section */
        .combinations-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; margin-bottom: 40px; }
        .combo-card { background: #ffffff; border-radius: 12px; padding: 24px; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .combo-card h3 { font-size: 1.2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
        .combo-list { list-style: none; padding: 0; margin: 0; }
        .combo-list li { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px dashed #e2e8f0; }
        .combo-list li:last-child { border-bottom: none; padding-bottom: 0; }
        .combo-numbers { display: flex; gap: 6px; }
        .combo-ball { width: 32px; height: 32px; border-radius: 50%; background: #1e293b; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; font-weight: 700; }
        .combo-freq { font-size: 0.85rem; color: #64748b; font-weight: 600; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; }

        /* Data & Depth Section */
        .data-depth-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; }
        .data-depth-section h2 { font-size: 1.4rem; font-weight: 800; margin-top: 0; margin-bottom: 16px; color: #0f172a; }
        .data-depth-section p { color: #475569; line-height: 1.7; margin-bottom: 16px; }
        .data-depth-section ul { padding-left: 20px; color: #475569; line-height: 1.7; margin-bottom: 24px; }
        .data-depth-section li { margin-bottom: 8px; }
        .chart-container { position: relative; height: 300px; width: 100%; margin-top: 24px; }

        /* --- FAQ ACCORDION STYLES --- */
        .faq-section { margin-top: 40px; margin-bottom: 24px; }
        .faq-header { font-size: 1.4rem; font-weight: 800; color: var(--text-main, #0f172a); margin-bottom: 24px; padding-left: 14px; border-left: 5px solid var(--primary, #4f46e5); line-height: 1.2; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-item:hover { box-shadow: 0 2px 8px rgba(0,0,0,0.03); }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 600; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: var(--primary, #4f46e5); font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-answer-inner p { margin: 0; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* --- MODERN INTERNAL LINKS (PILL STYLE) --- */
        .modern-internal-links { margin-top: 40px; margin-bottom: 32px; background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid var(--border, #e2e8f0); }
        .modern-internal-links h2 { font-size: 1.3rem; font-weight: 800; color: var(--text-main, #0f172a); margin-top: 0; margin-bottom: 20px; }
        .modern-internal-links .nav-pills { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 12px; }
        .modern-internal-links .nav-pills li { margin: 0; }
        .modern-internal-links .nav-pills a { display: inline-flex; align-items: center; background: #f8fafc; color: var(--text-main, #334155); text-decoration: none; padding: 12px 20px; border-radius: 999px; font-size: 0.95rem; font-weight: 600; border: 1px solid #e2e8f0; transition: all 0.2s ease; }
        .modern-internal-links .nav-pills a svg { width: 16px; height: 16px; margin-left: 10px; color: #e11d48; transition: transform 0.2s ease; }
        .modern-internal-links .nav-pills a:hover { background: #e11d48; color: #ffffff; border-color: #e11d48; box-shadow: 0 4px 10px -2px rgba(225, 29, 72, 0.25); }
        .modern-internal-links .nav-pills a:hover svg { color: #ffffff; transform: translateX(4px); }

        /* --- RELATED CARDS STYLES --- */
        .related-cards-section { margin-top: 40px; margin-bottom: 24px; }
        .related-cards-header { font-size: 1.5rem; font-weight: 800; color: var(--text-main, #0f172a); margin-bottom: 20px; }
        .related-cards-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; }
        .related-card { background: #ffffff; border-radius: 12px; padding: 24px 20px; border: 1px solid var(--border, #e2e8f0); box-shadow: 0 2px 4px rgba(0, 0, 0, 0.04); transition: transform 0.2s ease, box-shadow 0.2s ease; }
        .related-card:hover { transform: translateY(-4px); box-shadow: 0 12px 20px -8px rgba(0, 0, 0, 0.12); }
        .related-card-icon { font-size: 2.2rem; margin-bottom: 16px; }
        .related-card h3 { margin: 0 0 10px 0; font-size: 1.1rem; font-weight: 700; color: var(--text-main, #0f172a); }
        .related-card p { margin: 0 0 16px 0; font-size: 0.9rem; color: var(--text-muted, #64748b); line-height: 1.5; }
        .related-card a { display: inline-block; font-weight: 600; font-size: 0.95rem; color: #e11d48; text-decoration: none; transition: opacity 0.2s ease; }
        .related-card a:hover { text-decoration: underline; opacity: 0.8; }

        @media(max-width: 1024px) {
            .layout-with-sidebar { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
            .combinations-grid { grid-template-columns: 1fr; }
        }
        @media(max-width: 768px) {
            .related-cards-grid { grid-template-columns: 1fr; }
            .modern-internal-links .nav-pills a { width: 100%; justify-content: space-between; }
        }
    </style>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
</head>
<body>

    <?php 
    $navPath = __DIR__ . '/../../static/nav.php';
    if(file_exists($navPath)) { include $navPath; }
    ?>

    <main class="container">
        <nav class="breadcrumb">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>
        
        <div class="layout-with-sidebar">
            <div class="content-area">
                
                <div class="freshness-badge">
                    <div class="freshness-dot"></div>
                    Algorithm Updated: <?php echo $lastUpdatedText; ?>
                </div>

                <h1 style="font-size: 2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2;">
                    South Africa PowerBall Predictions for Next Draw
                </h1>
                
                <p style="font-size: 1.1rem; color: #475569; line-height: 1.6; margin-bottom: 30px;">
                    Stop guessing your numbers. Our <strong>PowerBall prediction for <?php echo $nextDrawFormatted; ?> (<?php echo $nextDrawDay; ?>)</strong> is powered by a dual-matrix statistical algorithm. By independently analyzing the 50-ball main pool and the 20-ball PowerBall pool from the last 50 draws, LottoGenius SA brings you calculated combinations built on isolated number frequencies and overdue probabilities.
                </p>

                <?php if ($latestDraw): ?>
                <div class="accuracy-block">
                    <h3 class="accuracy-title">✅ Prediction Tracker: Previous Draw</h3>
                    <p class="accuracy-desc">See how the latest official results (<?php echo $latestDateFormatted; ?>) aligned with our historical tracking data.</p>
                    <div class="acc-badge-container">
                        <?php echo $latestDrawMatchesHTML; ?>
                    </div>
                </div>
                <?php endif; ?>

                <div class="predictions-grid">
                    
                    <div class="prediction-card pred-card-balanced">
                        <div class="prediction-header">
                            <span class="prediction-icon">🎯</span>
                            <h3>Strategy 1: Balanced Pick</h3>
                        </div>
                        <div class="balls-container">
                            <?php foreach ($set1_main as $num): ?>
                                <div class="lotto-ball"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="lotto-ball pb-ball" title="PowerBall"><?php echo $set1_pb; ?></div>
                        </div>
                        <p class="pred-reason">
                            <strong>The Logic:</strong> This is our highest-recommended set. It utilizes a calculated mix of heavily trending 'hot' numbers, overdue 'cold' numbers, and a neutral median PowerBall to balance mathematical probability.
                        </p>
                    </div>

                    <div class="prediction-card pred-card-hot">
                        <div class="prediction-header">
                            <span class="prediction-icon">🔥</span>
                            <h3>Strategy 2: Trending / Hot Focus</h3>
                        </div>
                        <div class="balls-container">
                            <?php foreach ($set2_main as $num): ?>
                                <div class="lotto-ball hot"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="lotto-ball pb-ball hot" title="PowerBall"><?php echo $set2_pb; ?></div>
                        </div>
                        <p class="pred-reason">
                            <strong>The Logic:</strong> Based strictly on frequency. These 5 main numbers and 1 PowerBall have been drawn more than any other combinations in the last 50 draws. Ideal for players who believe in riding the momentum.
                        </p>
                    </div>

                    <div class="prediction-card pred-card-cold">
                        <div class="prediction-header">
                            <span class="prediction-icon">❄️</span>
                            <h3>Strategy 3: Overdue / Cold Strategy</h3>
                        </div>
                        <div class="balls-container">
                            <?php foreach ($set3_main as $num): ?>
                                <div class="lotto-ball cold"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="lotto-ball pb-ball cold" title="PowerBall"><?php echo $set3_pb; ?></div>
                        </div>
                        <p class="pred-reason">
                            <strong>The Logic:</strong> The law of averages dictates that numbers unrepresented recently will eventually surface. These are the most overdue numbers in both the 50-ball and 20-ball pools.
                        </p>
                    </div>

                </div>

                <div class="combinations-grid">
                    
                    <div class="combo-card">
                        <h3>🔗 Top Main Number Pairs</h3>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Most common pairs drawn together in the main 50-ball pool.</p>
                        <ul class="combo-list">
                            <?php foreach ($topPairs as $pairStr => $count): 
                                $nums = explode(',', $pairStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?> times</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="combo-card">
                        <h3>⚡ Top Main Number Triplets</h3>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Most common triplets drawn together in the main 50-ball pool.</p>
                        <ul class="combo-list">
                            <?php foreach ($topTriplets as $tripStr => $count): 
                                $nums = explode(',', $tripStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[2]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?> times</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                </div>

                <section class="data-depth-section">
                    <h2>How We Generate Our PowerBall Predictions</h2>
                    <p>At LottoGenius SA, we believe in a data-driven approach. Instead of offering random picks, our algorithm scans the official database to formulate structured <strong>powerball predictions today</strong>. Here is exactly how our system works:</p>
                    
                    <ul>
                        <li><strong>Dual-Matrix Frequency Analysis:</strong> We independently track the appearance rate of the 50 main balls and the 20 PowerBalls over a rolling 50-draw period.</li>
                        <li><strong>Distribution Balancing:</strong> A purely random quick-pick often results in poor odds. We enforce a spread across high/low and odd/even margins for the main set.</li>
                        <li><strong>PowerBall Isolation:</strong> We never mix the statistical probabilities of the main balls with the PowerBall, ensuring accurate 'Hot' and 'Cold' readings for the crucial final ball.</li>
                    </ul>

                    <h3 style="margin-top: 30px; font-size: 1.2rem; font-weight: 700;">Top 10 Hottest Main Numbers (Last 50 Draws)</h3>
                    <div class="chart-container">
                        <canvas id="frequencyChart"></canvas>
                    </div>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">Prediction FAQs & Methodologies</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="modern-internal-links">
                    <h2>Strengthen Your Strategy</h2>
                    <p style="color: #64748b; margin-bottom: 20px;">Cross-reference this prediction with our historical archives and analytical tools to build your ultimate ticket.</p>
                    <ul class="nav-pills">
                        <li>
                            <a href="/results/powerball">
                                Latest PowerBall Results
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                        <li>
                            <a href="/results/powerball/history">
                                PowerBall History Archive
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                        <li>
                            <a href="/results/powerball/hot-cold">
                                Detailed Hot & Cold Stats
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
                            </a>
                        </li>
                    </ul>
                </section>

                <section class="related-cards-section">
                    <h2 class="related-cards-header">More PowerBall Tools</h2>
                    <div class="related-cards-grid">
                        <div class="related-card">
                            <div class="related-card-icon">🎰</div>
                            <h3>Number Generator</h3>
                            <p>Generate completely random numbers if you prefer not to use our statistical prediction models.</p>
                            <a href="/results/powerball/generator">Use Generator &rarr;</a>
                        </div>
                        <div class="related-card">
                            <div class="related-card-icon">🔥</div>
                            <h3>Hot &amp; Cold Numbers</h3>
                            <p>Discover which numbers are drawn most frequently and which ones are currently overdue.</p>
                            <a href="/results/powerball/hot-cold">View Hot/Cold Stats &rarr;</a>
                        </div>
                        <div class="related-card">
                            <div class="related-card-icon">🎫</div>
                            <h3>Check Your Tickets</h3>
                            <p>Instantly check your numbers against the latest official results to see if you're a winner.</p>
                            <a href="/results/powerball/check-tickets">Check Tickets &rarr;</a>
                        </div>
                    </div>
                </section>

                <div class="modern-disclaimer">
                    <svg class="disclaimer-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"></circle>
                        <line x1="12" y1="16" x2="12" y2="12"></line>
                        <line x1="12" y1="8" x2="12.01" y2="8"></line>
                    </svg>
                    <div class="disclaimer-content">
                        <strong>Disclaimer</strong>
                        <p>LottoGenius SA is an independent informational platform and is not affiliated with, endorsed, or sponsored by the official South African National Lottery or Ithuba Holdings. Our predictions are for entertainment and analytical purposes only. Lottery games are games of chance, and past performance does not guarantee future results. Play responsibly.</p>
                    </div>
                </div>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="PowerBall navigation">
                    <div class="sidebar-menu-header">PowerBall Panel</div>
                    <ul class="sidebar-links">
                        <li><a href="/results/powerball">Latest Results</a></li>
                        <li><a href="/results/powerball/history">Draw History</a></li>
                        <li><a href="/results/powerball/predictions" class="active">Smart Predictions</a></li>
                        <li><a href="/results/powerball/check-tickets">Check Tickets</a></li>
                        <li><a href="/results/powerball/hot-cold">Hot & Cold Numbers</a></li>
                        <li><a href="/results/powerball/payouts">Prize Payouts</a></li>
                        <li><a href="/how-to-play">How to Play</a></li>
                        <li><a href="/results/powerball/generator">Generate Numbers</a></li>
                        <li><a href="https://affiliates.hollywoodbets.net/" class="highlight" target="_blank" rel="noopener nofollow">Play Online &rarr;</a></li>
                    </ul>
                </nav>
            </aside>
            
        </div>
    </main>

    <?php 
    $footerPath = __DIR__ . '/../../static/footer.php';
    if(file_exists($footerPath)) { include $footerPath; }
    ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });

            // Chart.js Rendering
            const ctx = document.getElementById('frequencyChart');
            if (ctx) {
                const chartLabels = <?php echo json_encode($chartLabels); ?>;
                const chartData = <?php echo json_encode($chartData); ?>;

                new Chart(ctx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: chartLabels.map(num => 'Ball ' + num),
                        datasets: [{
                            label: 'Draw Frequency (Last 50 Draws)',
                            data: chartData,
                            backgroundColor: '#e11d48',
                            borderRadius: 4,
                            hoverBackgroundColor: '#9f1239'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#1e293b',
                                padding: 12,
                                titleFont: { family: 'Inter', size: 14 },
                                bodyFont: { family: 'Inter', size: 13 }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: '#f1f5f9' },
                                ticks: { precision: 0, font: { family: 'Inter' } }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { font: { family: 'Inter', weight: 'bold' } }
                            }
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>