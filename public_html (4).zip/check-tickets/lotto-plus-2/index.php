<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to database (2 levels back)
require_once __DIR__ . '/../../db.php';

// --- SEO METADATA (MAXIMIZED FOR LOTTO PLUS 2) ---
$pageTitle = "Lotto Plus 2 Ticket Checker SA (2026) – Check If You Won Instantly";
$metaDesc = "Check your Lotto Plus 2 ticket instantly 🇿🇦 Enter your 6 numbers and scan the last 100 official draws. Find out if you’ve won today – fast & free.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Ticket Checker", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/check-tickets/"],
    ["name" => "Lotto Plus 2 Checker", "url" => $currentUrl]
];

// --- PROGRAMMATIC SEO DATA (FRESHNESS SIGNAL) ---
$latestDrawDate = "Recently";
try {
    $stmtLatest = $pdo->query("SELECT draw_date FROM lotto_plus_2_results ORDER BY draw_date DESC LIMIT 1");
    $latestRow = $stmtLatest->fetch(PDO::FETCH_ASSOC);
    if ($latestRow) {
        $latestDrawDate = date('d F Y', strtotime($latestRow['draw_date']));
    }
} catch (Exception $e) {
    // Silently continue if DB fails
}

// --- HANDLE FORM SUBMISSION (100 DRAW SCAN) ---
$checkResults = null;
$userBalls = $_POST['balls'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean and filter user inputs for Lotto Plus 2 (1-52)
    $cleanBalls = [];
    foreach($userBalls as $b) {
        $val = (int)$b;
        if($val > 0 && $val <= 52) {
            $cleanBalls[] = $val;
        }
    }
    $cleanBalls = array_unique($cleanBalls);
    
    // SA Lotto Plus 2 requires exactly 6 balls on the ticket. 
    if (count($cleanBalls) === 6) {
        try {
            // Fetch the last 100 Lotto Plus 2 draws
            $stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5, ball_6, bonus_ball FROM lotto_plus_2_results ORDER BY draw_date DESC LIMIT 100");
            $recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $checkResults = [];
            foreach ($recentDraws as $draw) {
                $drawBalls = [
                    (int)$draw['ball_1'], (int)$draw['ball_2'], (int)$draw['ball_3'], 
                    (int)$draw['ball_4'], (int)$draw['ball_5'], (int)$draw['ball_6']
                ];
                $drawBonus = (int)$draw['bonus_ball'];
                
                // Compare combinations
                $matchedBalls = array_intersect($cleanBalls, $drawBalls);
                $matchCount = count($matchedBalls);
                
                // Check if one of the player's 6 numbers happens to be the Bonus Ball
                $bonusMatched = in_array($drawBonus, $cleanBalls);
                
                // SA Lotto Plus 2 payouts generally start at 2 Main Balls + Bonus Ball, or 3 Main Balls.
                $isWinner = ($matchCount >= 3) || ($matchCount == 2 && $bonusMatched);

                if ($isWinner) {
                    $division = '';
                    if ($matchCount == 6) { $division = 'Jackpot'; }
                    elseif ($matchCount == 5 && $bonusMatched) { $division = 'Division 2'; }
                    elseif ($matchCount == 5) { $division = 'Division 3'; }
                    elseif ($matchCount == 4 && $bonusMatched) { $division = 'Division 4'; }
                    elseif ($matchCount == 4) { $division = 'Division 5'; }
                    elseif ($matchCount == 3 && $bonusMatched) { $division = 'Division 6'; }
                    elseif ($matchCount == 3) { $division = 'Division 7'; }
                    elseif ($matchCount == 2 && $bonusMatched) { $division = 'Division 8'; }

                    $checkResults[] = [
                        'date' => date('l, d M Y', strtotime($draw['draw_date'])),
                        'match_count' => $matchCount,
                        'matched_balls' => $matchedBalls,
                        'bonus_matched' => $bonusMatched,
                        'draw_balls' => $drawBalls,
                        'draw_bonus' => $drawBonus,
                        'division' => $division
                    ];
                }
            }
        } catch (Exception $e) {
            $checkResults = false; // DB Error
        }
    } else {
        $checkResults = 'invalid'; // Not enough valid numbers entered
    }
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "<?php echo addslashes($pageTitle); ?>",
      "description": "<?php echo addslashes($metaDesc); ?>",
      "inLanguage": "en-ZA"
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $index + 1; ?>,
          "name": "<?php echo $crumb['name']; ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Lotto Plus 2 Ticket Checker - NextDrawLogic",
      "applicationCategory": "Utility",
      "operatingSystem": "All",
      "url": "<?php echo $currentUrl; ?>",
      "description": "Cross-reference your South African Lotto Plus 2 ticket numbers against the last 100 official Ithuba draws.",
      "featureList": [
        "Check Lotto Plus 2 tickets",
        "Scan last 100 draws",
        "Automatic bonus ball detection"
      ],
      "creator": {
        "@type": "Organization",
        "name": "NextDrawLogic"
      },
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "ZAR"
      }
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "HowTo",
      "name": "How to Check Lotto Plus 2 Ticket",
      "step": [
        {
          "@type": "HowToStep",
          "text": "Enter your 6 Lotto numbers from your ticket."
        },
        {
          "@type": "HowToStep",
          "text": "Click the 'Scan 100 Draws Now' button."
        },
        {
          "@type": "HowToStep",
          "text": "View matches against past Lotto Plus 2 draws."
        }
      ]
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "What is Lotto Plus 2?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Lotto Plus 2 is the third draw in the South African Lotto series. It gives players who have already entered the main Lotto and Lotto Plus 1 draws a third chance to win using the exact same numbers."
          }
        },
        {
          "@type": "Question",
          "name": "How far back does this Lotto Plus 2 checker search?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "This specialized ticket checker instantly scans the last 100 official Lotto Plus 2 draws. Because the draw happens twice a week, this covers roughly a full year of Wednesday and Saturday gameplay."
          }
        },
        {
          "@type": "Question",
          "name": "Why doesn't the checker ask for a Bonus Ball?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Just like the main game, you only select 6 numbers on your ticket (from 1 to 52). The Bonus Ball is drawn automatically from the remaining 46 balls. If one of your 6 selected numbers matches the Bonus Ball, you win a higher prize tier. You never pick the Bonus Ball manually."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <style>
        /* Layout */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* Typography & Headings */
        .page-title { font-size: 2.6rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; letter-spacing: -0.5px; }
        .page-intro { font-size: 1.15rem; color: #475569; line-height: 1.6; margin: 0 0 24px 0; }
        
        /* Badges for Freshness & Data */
        .meta-badges { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 32px; }
        .badge { display: inline-flex; align-items: center; padding: 6px 14px; border-radius: 99px; font-size: 0.85rem; font-weight: 700; }
        .badge-fresh { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .badge-data { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }

        /* Sidebar */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover, .sidebar-links a.active { background: #f8fafc; color: #2563eb; border-left-color: #2563eb; font-weight: 800; }

        /* Checker Form UI (Lotto Plus 2 Theme - Blue) */
        .checker-card { background: #ffffff; border-radius: 16px; padding: 40px 32px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); margin-bottom: 40px; position: relative; overflow: hidden; }
        .checker-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, #2563eb, #1d4ed8); }
        
        .checker-header { text-align: center; margin-bottom: 32px; }
        .checker-header h2 { font-size: 1.8rem; color: #0f172a; margin: 0 0 8px 0; font-weight: 800; }
        .checker-header p { color: #64748b; margin: 0; font-size: 1rem; }
        
        .input-row { display: flex; justify-content: center; flex-wrap: wrap; gap: 16px; margin-bottom: 36px; }
        .ball-input-wrap { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        
        .ticket-input { width: 72px; height: 72px; border-radius: 50%; border: 2px solid #cbd5e1; font-size: 1.8rem; font-weight: 800; text-align: center; color: #0f172a; background: #ffffff; outline: none; transition: all 0.2s ease; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02); touch-action: manipulation; }
        .ticket-input:focus { border-color: #2563eb; box-shadow: 0 0 0 4px rgba(37, 99, 235, 0.2); transform: scale(1.05); }
        
        .input-label { font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .btn-check { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 0 auto; background: linear-gradient(135deg, #2563eb, #1d4ed8); color: white; border: none; padding: 20px 56px; font-size: 1.2rem; font-weight: 800; border-radius: 99px; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(37, 99, 235, 0.3); text-transform: uppercase; letter-spacing: 0.5px; }
        .btn-check:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(37, 99, 235, 0.4); }

        /* Results Display */
        .results-box { background: #ffffff; border: 2px solid #2563eb; border-radius: 12px; padding: 0; margin-bottom: 40px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(37,99,235,0.1); }
        .results-header { background: #2563eb; color: white; padding: 20px 24px; margin: 0; font-size: 1.3rem; font-weight: 800; display: flex; align-items: center; justify-content: space-between; }
        .results-body { padding: 24px; background: #f8fafc; }
        
        .match-row { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; transition: transform 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .match-row:hover { transform: translateY(-2px); border-color: #cbd5e1; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .match-date-wrap { display: flex; flex-direction: column; gap: 4px; }
        .match-date { font-weight: 800; color: #0f172a; font-size: 1.1rem; }
        .match-tag { font-size: 0.8rem; font-weight: 700; color: #10b981; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .match-balls { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .m-ball { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 800; background: #f1f5f9; color: #94a3b8; border: 1px solid #e2e8f0; }
        .m-ball.hit { background: #2563eb; color: white; border-color: #1d4ed8; box-shadow: 0 2px 4px rgba(37,99,235,0.3); }
        .m-ball.hit-bonus { background: #f59e0b; color: white; border-radius: 8px; border-color: #d97706; box-shadow: 0 2px 4px rgba(245,158,11,0.3); }
        
        .match-summary { font-size: 1rem; font-weight: 800; color: #059669; background: #d1fae5; padding: 8px 16px; border-radius: 8px; border: 1px solid #10b981; }
        .no-match { color: #b91c1c; font-weight: 700; font-size: 1.1rem; text-align: center; padding: 32px; background: #fef2f2; border-radius: 8px; border: 2px dashed #fecaca; }

        /* SEO & Text Blocks */
        .seo-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; }
        .seo-section h3 { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-top: 28px; margin-bottom: 12px; }
        .seo-section p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-section a { color: #2563eb; font-weight: 700; text-decoration: none; }
        .seo-section a:hover { text-decoration: underline; }
        
        .e-e-a-t-box { background: #f8fafc; border-left: 4px solid #3b82f6; padding: 16px 20px; border-radius: 0 8px 8px 0; margin-top: 24px; font-size: 0.95rem; color: #334155; }

        /* FAQ Section */
        .faq-section { margin-bottom: 48px; }
        .faq-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px; overflow: hidden; transition: all 0.2s ease; }
        .faq-item:hover { border-color: #cbd5e1; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #2563eb; font-size: 1.6rem; line-height: 1; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); color: #1d4ed8; }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* Related Links Grid */
        .related-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 20px; }
        .related-card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 10px; text-decoration: none; transition: all 0.2s ease; display: block; }
        .related-card:hover { background: #ffffff; border-color: #2563eb; box-shadow: 0 4px 12px rgba(37,99,235,0.1); transform: translateY(-2px); }
        .related-card h4 { margin: 0 0 8px 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; }
        .related-card p { margin: 0; font-size: 0.9rem; color: #64748b; }

        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }

        @media(max-width: 1024px) { .layout-with-sidebar { grid-template-columns: 1fr; } .lotto-sidebar { position: relative; top: 0; } }
        @media(max-width: 600px) { .ticket-input { width: 52px; height: 52px; font-size: 1.3rem; } .m-ball { width: 32px; height: 32px; font-size: 0.85rem; } .btn-check { padding: 16px 32px; font-size: 1.1rem; } }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <h1 class="page-title">Lotto Plus 2 Ticket Checker SA (2026) – Check If You Won Instantly</h1>
                <p class="page-intro">Instantly verify your South African Lotto Plus 2 tickets. We automatically cross-reference your 6 numbers against the last 100 official Ithuba Plus 2 draws to ensure you haven't missed a third-chance payout.</p>

                <div class="meta-badges">
                    <span class="badge badge-fresh">🗓️ Updated after every official draw (Wed & Sat)</span>
                    <span class="badge badge-data">📊 Latest Draw Scanned: <?php echo $latestDrawDate; ?></span>
                    <span class="badge badge-data">🔍 Total Depth: 100 Draws (~1 Year)</span>
                </div>

                <div class="checker-card">
                    <div class="checker-header">
                        <h2>Enter Your 6 Lotto Numbers</h2>
                        <p>Type your 6 main numbers below. (We will check the Plus 2 Bonus Ball automatically!)</p>
                    </div>

                    <form method="POST" action="/check-tickets/lotto-plus-2/" id="checker-form">
                        <div class="input-row" id="input-container">
                            <?php for($i=1; $i<=6; $i++): ?>
                                <?php $val = isset($userBalls[$i-1]) ? htmlspecialchars((string)$userBalls[$i-1]) : ''; ?>
                                <div class="ball-input-wrap">
                                    <span class="input-label">Ball <?php echo $i; ?></span>
                                    <input type="number" name="balls[]" class="ticket-input" min="1" max="52" value="<?php echo $val; ?>" required placeholder="-">
                                </div>
                            <?php endfor; ?>
                        </div>

                        <p style="text-align:center; font-weight:600; color:#2563eb; margin-bottom: 16px;">
                            💡 Most players forget to check Lotto Plus 2 — don’t miss your winnings.
                        </p>

                        <button type="submit" class="btn-check" id="submit-btn">
                            <span>Scan 100 Draws Now</span>
                        </button>
                        
                        <p style="text-align:center; margin-top:15px;">
                            👉 Want today's results? <a href="/results/lotto-plus-2/" style="font-weight:700;">Check latest Lotto Plus 2 results</a>
                        </p>
                        
                        <div style="text-align: center; margin-top: 10px;">
                            <button type="button" onclick="clearInputs()" style="background:none; border:none; color:#94a3b8; font-weight:600; text-decoration:underline; cursor:pointer; font-size:0.9rem;">Clear Numbers</button>
                        </div>
                    </form>
                </div>

                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="results-box" id="results-anchor" data-nosnippet>
                        <div class="results-header">
                            <span>Scan Results: Lotto Plus 2</span>
                            <span style="font-size:0.9rem; font-weight:600; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:6px;">100-Draw Scan</span>
                        </div>
                        <div class="results-body">
                            <?php if ($checkResults === 'invalid'): ?>
                                <div class="no-match">⚠️ Error: Please enter exactly 6 UNIQUE numbers between 1 and 52.</div>
                            <?php elseif ($checkResults === false): ?>
                                <div class="no-match">⚠️ Database Error: Could not connect to the draw history database.</div>
                            <?php elseif (empty($checkResults)): ?>
                                <div class="no-match">
                                    ❌ No Winning Matches Found.<br>
                                    <span style="font-size:0.95rem; font-weight:500; color:#475569; display:block; margin-top:8px;">Your numbers did not trigger a payout division in the last 100 Lotto Plus 2 draws.</span>
                                </div>
                            <?php else: ?>
                                <h2 style="margin-top:0; margin-bottom:16px; font-size:1.6rem; font-weight:800; color:#0f172a;">Your Lotto Plus 2 Results</h2>
                                <p style="color: #475569; font-size: 1.05rem; margin-top:0; margin-bottom: 20px; font-weight: 600;">
                                    🎉 We found payout matches for your ticket in the following past draws:
                                </p>
                                <?php foreach($checkResults as $res): ?>
                                    <div class="match-row">
                                        <div class="match-date-wrap">
                                            <span class="match-date"><?php echo $res['date']; ?></span>
                                            <span class="match-tag">Verified Draw</span>
                                        </div>
                                        
                                        <div class="match-balls">
                                            <?php foreach($res['draw_balls'] as $db): ?>
                                                <div class="m-ball <?php echo in_array($db, $res['matched_balls']) ? 'hit' : ''; ?>">
                                                    <?php echo $db; ?>
                                                </div>
                                            <?php endforeach; ?>
                                            
                                            <div style="width: 2px; height: 40px; background: #e2e8f0; margin: 0 8px;"></div>
                                            
                                            <div class="m-ball <?php echo $res['bonus_matched'] ? 'hit-bonus' : ''; ?>" style="border-radius: 8px;" title="Bonus Ball">
                                                <?php echo $res['draw_bonus']; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="match-summary">
                                            <?php echo $res['division']; ?> (<?php echo $res['match_count']; ?><?php echo $res['bonus_matched'] ? '+B' : ''; ?>)
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                            <p style="margin-top:20px; font-size:0.95rem; color:#475569;">
                                📊 Lotto Plus 2 odds: Matching 3 numbers or more is rare — always double-check every ticket.
                            </p>
                        </div>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            document.getElementById("results-anchor").scrollIntoView({ behavior: 'smooth', block: 'center' });
                        });
                    </script>
                <?php endif; ?>

                <section class="seo-section">
                    <h2>How to Check Lotto Plus 2 Results in South Africa</h2>
                    <p>Lotto Plus 2 is the ultimate "third chance" draw. After the main Lotto and Lotto Plus 1, a third draw takes place, giving players one final opportunity to hit the jackpot using their original ticket numbers. Because this is the final draw of the evening, many players forget to verify their <a href="/results/lotto-plus-2/">Lotto Plus 2 winning numbers</a>.</p>
                    <p>Our intelligent <strong>SA lotto plus 2 checker</strong> makes sure no winning combination slips through the cracks. By entering the 6 numbers from your playslip, we cross-reference them instantly against the specific Plus 2 draw history. This is the fastest way to <a href="/check-tickets/">check lotto tickets online</a>.</p>

                    <h3>Verify Your Lotto Plus 2 Numbers Against Past Draws</h3>
                    <p>The matrix for Lotto Plus 2 is identical to the main game: 6 numbers out of 52. You do not pick a Bonus Ball manually. During the Plus 2 draw, a separate set of 6 balls and 1 Bonus Ball are drawn. If one of your 6 selected numbers happens to match that specific Bonus Ball, you get bumped up to a higher prize division! Our system automatically does this math for you.</p>

                    <h2>Common Mistakes When Checking Lotto Plus 2 Tickets</h2>
                    <p>Every year, thousands of rands go unclaimed. Make sure you don't make these common errors when you <strong>check lotto plus 2 ticket</strong> results:</p>
                    <ul>
                        <li><strong>Forgetting the Plus 2 draw:</strong> Many players only check the <a href="/results/lotto/">main Lotto results</a> and <a href="/results/lotto-plus-1/">Lotto Plus 1 results</a>.</li>
                        <li><strong>Checking the wrong date:</strong> Manually comparing old tickets to new results is a recipe for disaster.</li>
                        <li><strong>Ignoring the Bonus Ball:</strong> If you match just 2 main numbers and the Bonus Ball, you win a prize! Don't throw a winning ticket away.</li>
                        <li><strong>Losing old tickets:</strong> Tickets are valid for 365 days. Always use our scanner for older slips.</li>
                    </ul>

                    <h3>Check Old Lotto Plus 2 Tickets (Up to 100 Draws)</h3>
                    <p>If you find an old ticket, always check it using our tool before discarding it. National Lottery tickets in SA are valid for an entire year. Our database scans the previous 100 draws, covering almost a full year of Wednesday and Saturday action. If you prefer to manually view <strong>lotto plus 2 results today</strong> or historical payouts, you can browse our <a href="/results/lotto-plus-2/history/">full Lotto Plus 2 history archive</a>.</p>

                    <div class="e-e-a-t-box">
                        <strong>🔒 Official Data Source:</strong> Results are verified using data from the South African National Lottery (Ithuba). This tool is updated after every official draw.
                    </div>
                </section>

                <section class="faq-section">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <div class="faq-item">
                            <button class="faq-question">What is Lotto Plus 2?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>Lotto Plus 2 is the third draw in the South African Lotto series. It gives players who have already entered the main Lotto and Lotto Plus 1 draws a third chance to win using the exact same numbers.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">How far back does this Lotto Plus 2 checker search?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>This specialized ticket checker instantly scans the last 100 official Lotto Plus 2 draws. Because the draw happens twice a week, this covers roughly a full year of Wednesday and Saturday gameplay.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">Why doesn't the checker ask for a Bonus Ball?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>Just like the main game, you only select 6 numbers on your ticket (from 1 to 52). The Bonus Ball is drawn automatically from the remaining 46 balls. If one of your 6 selected numbers matches the Bonus Ball, you win a higher prize tier. You never pick the Bonus Ball manually.</p></div></div>
                        </div>
                    </div>
                </section>

                <section class="related-section">
                    <h2 style="font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 16px;">Related Lotto Plus 2 Searches</h2>
                    <div class="related-grid">
                        <a href="/results/lotto-plus-2/" class="related-card">
                            <h4>Latest Lotto Plus 2 Results</h4>
                            <p>View today's winning numbers and payouts.</p>
                        </a>
                        <a href="/results/lotto-plus-2/predictions/" class="related-card">
                            <h4>Lotto Plus 2 Predictions</h4>
                            <p>Get algorithm-driven predictions for the next draw.</p>
                        </a>
                        <a href="/results/lotto-plus-2/hot-cold/" class="related-card">
                            <h4>Hot & Cold Numbers</h4>
                            <p>See which Plus 2 numbers are trending this month.</p>
                        </a>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/results/lotto-plus-2/hot-cold/">Lotto Plus 2 Hot & Cold</a></li>
                        <li><a href="/results/lotto-plus-2/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/lotto-plus-2/history/">Results Archive</a></li>
                        <li><a href="/check-tickets/" class="active">Ticket Checker Hub</a></li>
                        <li><a href="/check-tickets/lotto-plus-2/" class="active" style="padding-left: 40px; font-size: 0.85rem;">↳ Lotto Plus 2 Checker</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        function clearInputs() {
            const inputs = document.querySelectorAll('.ticket-input');
            inputs.forEach(input => input.value = '');
            localStorage.removeItem('lottoPlus2SavedBalls');
            if(inputs.length > 0) inputs[0].focus();
        }

        document.addEventListener('DOMContentLoaded', () => {
            const container = document.getElementById('input-container');
            const inputs = Array.from(container.querySelectorAll('input[type="number"]'));
            const form = document.getElementById('checker-form');
            const submitBtn = document.getElementById('submit-btn');
            
            // UX Feature: Load last checked numbers from LocalStorage (if not a fresh POST)
            const isPost = <?php echo $_SERVER['REQUEST_METHOD'] === 'POST' ? 'true' : 'false'; ?>;
            if (!isPost) {
                const savedBalls = JSON.parse(localStorage.getItem('lottoPlus2SavedBalls'));
                if (savedBalls && savedBalls.length === 6) {
                    inputs.forEach((input, index) => {
                        input.value = savedBalls[index] || '';
                    });
                }
            }
            
            // UX Feature: Duplicate validation, loading state, and save to LocalStorage
            form.addEventListener('submit', function(e) {
                const currentBalls = inputs.map(input => input.value).filter(val => val !== '');
                const unique = new Set(currentBalls);
                
                if (unique.size !== currentBalls.length || currentBalls.length !== 6) {
                    e.preventDefault();
                    alert("⚠️ Please enter 6 UNIQUE numbers between 1 and 52.");
                    return false;
                }
                
                localStorage.setItem('lottoPlus2SavedBalls', JSON.stringify(currentBalls));
                submitBtn.innerHTML = '<span>Scanning... ⏳</span>';
                submitBtn.style.opacity = '0.8';
                submitBtn.style.cursor = 'wait';
            });
            
            // Advanced App-like Input Logic
            inputs.forEach((input, index) => {
                input.addEventListener('focus', function() { this.select(); });

                input.addEventListener('input', function() {
                    const maxVal = parseInt(this.max);
                    if (this.value.length >= 2) {
                        if (parseInt(this.value) > maxVal) {
                            this.value = maxVal; // Cap value
                        }
                        if (index < inputs.length - 1) {
                            inputs[index + 1].focus(); // Jump to next
                        }
                    }
                });

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && this.value === '') {
                        if (index > 0) {
                            inputs[index - 1].focus();
                            inputs[index - 1].value = ''; 
                        }
                    }
                });
            });

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>