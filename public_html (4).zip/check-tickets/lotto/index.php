<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to database (2 levels back)
require_once __DIR__ . '/../../db.php';

// --- SEO METADATA (MAXIMIZED FOR MAIN LOTTO) ---
$pageTitle = "Check Lotto Tickets Online South Africa – Verify Numbers & Results";
$metaDesc = "Check your SA Lotto ticket instantly 🇿🇦 Enter your 6 numbers to verify against the last 100 official South African draws. Find out if you've won today!";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Ticket Checker", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/check-tickets/"],
    ["name" => "Lotto Checker", "url" => $currentUrl]
];

// --- PROGRAMMATIC SEO DATA (FRESHNESS SIGNAL) ---
$latestDrawDate = "Recently";
try {
    $stmtLatest = $pdo->query("SELECT draw_date FROM lotto_results ORDER BY draw_date DESC LIMIT 1");
    $latestRow = $stmtLatest->fetch(PDO::FETCH_ASSOC);
    if ($latestRow) {
        $latestDrawDate = date('d F Y', strtotime($latestRow['draw_date']));
    }
} catch (Exception $e) {
    // Silently continue if DB fails
}

// --- HANDLE FORM SUBMISSION (100 DRAW SCAN) ---
$checkResults = null;
$userBalls = $_POST['balls'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean and filter user inputs for Lotto (1-52)
    $cleanBalls = [];
    foreach($userBalls as $b) {
        $val = (int)$b;
        if($val > 0 && $val <= 52) {
            $cleanBalls[] = $val;
        }
    }
    $cleanBalls = array_unique($cleanBalls);
    
    // SA Lotto requires exactly 6 balls on the ticket. (The Bonus is drawn from the remaining 46, you don't pick it).
    if (count($cleanBalls) === 6) {
        try {
            // Fetch the last 100 Lotto draws
            $stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5, ball_6, bonus_ball FROM lotto_results ORDER BY draw_date DESC LIMIT 100");
            $recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $checkResults = [];
            foreach ($recentDraws as $draw) {
                $drawBalls = [
                    (int)$draw['ball_1'], (int)$draw['ball_2'], (int)$draw['ball_3'], 
                    (int)$draw['ball_4'], (int)$draw['ball_5'], (int)$draw['ball_6']
                ];
                $drawBonus = (int)$draw['bonus_ball'];
                
                // Compare combinations
                $matchedBalls = array_intersect($cleanBalls, $drawBalls);
                $matchCount = count($matchedBalls);
                
                // Check if one of the player's 6 numbers happens to be the Bonus Ball
                $bonusMatched = in_array($drawBonus, $cleanBalls);
                
                // SA Lotto payouts generally start at 2 Main Balls + Bonus Ball, or 3 Main Balls.
                if ($matchCount >= 3 || ($matchCount == 2 && $bonusMatched)) {
                    $checkResults[] = [
                        'date' => date('l, d M Y', strtotime($draw['draw_date'])),
                        'match_count' => $matchCount,
                        'matched_balls' => $matchedBalls,
                        'bonus_matched' => $bonusMatched,
                        'draw_balls' => $drawBalls,
                        'draw_bonus' => $drawBonus
                    ];
                }
            }
        } catch (Exception $e) {
            $checkResults = false; // DB Error
        }
    } else {
        $checkResults = 'invalid'; // Not enough valid numbers entered
    }
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $index + 1; ?>,
          "name": "<?php echo $crumb['name']; ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "Lotto Ticket Checker - NextDrawLogic",
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "All",
      "description": "Cross-reference your South African Lotto ticket numbers against the last 100 official Ithuba draws.",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "ZAR"
      }
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "Why doesn't the checker ask for a Bonus Ball?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "In the South African Lotto, you only select 6 numbers on your playslip (from 1 to 52). The Bonus Ball is drawn from the remaining 46 balls in the machine. If one of your 6 chosen numbers matches the Bonus Ball, you win a higher prize tier. You do not pick the Bonus Ball yourself."
          }
        },
        {
          "@type": "Question",
          "name": "How far back does this Lotto checker search?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "This specialized Lotto ticket checker instantly scans the last 100 official draws. Because Lotto is played twice a week (Wednesdays and Saturdays), this covers roughly an entire year of gameplay."
          }
        },
        {
          "@type": "Question",
          "name": "What is the minimum I need to match to win a Lotto prize?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "In South Africa, the lowest prize division for the main Lotto game is Division 8, which requires you to match exactly 2 main numbers plus the Bonus Ball."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* Layout */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* Typography & Headings */
        .page-title { font-size: 2.6rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; letter-spacing: -0.5px; }
        .page-intro { font-size: 1.15rem; color: #475569; line-height: 1.6; margin: 0 0 24px 0; }
        
        /* Badges for Freshness & Data */
        .meta-badges { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 32px; }
        .badge { display: inline-flex; align-items: center; padding: 6px 14px; border-radius: 99px; font-size: 0.85rem; font-weight: 700; }
        .badge-fresh { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .badge-data { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }

        /* Sidebar */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover, .sidebar-links a.active { background: #f8fafc; color: #10b981; border-left-color: #10b981; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* Checker Form UI (Lotto Theme - Green) */
        .checker-card { background: #ffffff; border-radius: 16px; padding: 40px 32px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); margin-bottom: 40px; position: relative; overflow: hidden; }
        .checker-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, #10b981, #047857); }
        
        .checker-header { text-align: center; margin-bottom: 32px; }
        .checker-header h2 { font-size: 1.8rem; color: #0f172a; margin: 0 0 8px 0; font-weight: 800; }
        .checker-header p { color: #64748b; margin: 0; font-size: 1rem; }
        
        .input-row { display: flex; justify-content: center; flex-wrap: wrap; gap: 16px; margin-bottom: 36px; }
        .ball-input-wrap { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        
        .ticket-input { width: 72px; height: 72px; border-radius: 50%; border: 2px solid #cbd5e1; font-size: 1.8rem; font-weight: 800; text-align: center; color: #0f172a; background: #ffffff; outline: none; transition: all 0.2s ease; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02); }
        .ticket-input:focus { border-color: #10b981; box-shadow: 0 0 0 4px rgba(16, 185, 129, 0.2); transform: scale(1.05); }
        
        .input-label { font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .btn-check { display: block; margin: 0 auto; background: linear-gradient(135deg, #10b981, #047857); color: white; border: none; padding: 20px 56px; font-size: 1.2rem; font-weight: 800; border-radius: 99px; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3); text-transform: uppercase; letter-spacing: 0.5px; }
        .btn-check:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(16, 185, 129, 0.4); }

        /* Results Display */
        .results-box { background: #ffffff; border: 2px solid #10b981; border-radius: 12px; padding: 0; margin-bottom: 40px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(16,185,129,0.1); }
        .results-header { background: #10b981; color: white; padding: 20px 24px; margin: 0; font-size: 1.3rem; font-weight: 800; display: flex; align-items: center; justify-content: space-between; }
        .results-body { padding: 24px; background: #f8fafc; }
        
        .match-row { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; transition: transform 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .match-row:hover { transform: translateY(-2px); border-color: #cbd5e1; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .match-date-wrap { display: flex; flex-direction: column; gap: 4px; }
        .match-date { font-weight: 800; color: #0f172a; font-size: 1.1rem; }
        .match-tag { font-size: 0.8rem; font-weight: 700; color: #10b981; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .match-balls { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
        .m-ball { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 800; background: #f1f5f9; color: #94a3b8; border: 1px solid #e2e8f0; }
        .m-ball.hit { background: #10b981; color: white; border-color: #047857; box-shadow: 0 2px 4px rgba(16,185,129,0.3); }
        .m-ball.hit-bonus { background: #f59e0b; color: white; border-radius: 8px; border-color: #d97706; box-shadow: 0 2px 4px rgba(245,158,11,0.3); }
        
        .match-summary { font-size: 1rem; font-weight: 800; color: #059669; background: #d1fae5; padding: 8px 16px; border-radius: 8px; border: 1px solid #10b981; }
        .no-match { color: #b91c1c; font-weight: 700; font-size: 1.1rem; text-align: center; padding: 32px; background: #fef2f2; border-radius: 8px; border: 2px dashed #fecaca; }

        /* SEO & Text Blocks */
        .seo-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; }
        .seo-section h3 { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-top: 28px; margin-bottom: 12px; }
        .seo-section p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-section a { color: #10b981; font-weight: 700; text-decoration: none; }
        .seo-section a:hover { text-decoration: underline; }
        
        .e-e-a-t-box { background: #f8fafc; border-left: 4px solid #3b82f6; padding: 16px 20px; border-radius: 0 8px 8px 0; margin-top: 24px; font-size: 0.95rem; color: #334155; }

        /* FAQ Section */
        .faq-section { margin-bottom: 48px; }
        .faq-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px; overflow: hidden; transition: all 0.2s ease; }
        .faq-item:hover { border-color: #cbd5e1; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #10b981; font-size: 1.6rem; line-height: 1; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); color: #047857; }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* Related Links Grid */
        .related-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 20px; }
        .related-card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 10px; text-decoration: none; transition: all 0.2s ease; display: block; }
        .related-card:hover { background: #ffffff; border-color: #10b981; box-shadow: 0 4px 12px rgba(16,185,129,0.1); transform: translateY(-2px); }
        .related-card h4 { margin: 0 0 8px 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; }
        .related-card p { margin: 0; font-size: 0.9rem; color: #64748b; }

        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }

        @media(max-width: 1024px) { .layout-with-sidebar { grid-template-columns: 1fr; } .lotto-sidebar { position: relative; top: 0; } }
        @media(max-width: 600px) { .ticket-input { width: 52px; height: 52px; font-size: 1.3rem; } .m-ball { width: 32px; height: 32px; font-size: 0.85rem; } .btn-check { padding: 16px 32px; font-size: 1.1rem; } }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <h1 class="page-title">Check Lotto Tickets Online South Africa</h1>
                <p class="page-intro">Instantly verify your classic South African Lotto tickets. We automatically cross-reference your custom 6-number combination against the last 100 official Ithuba Wed/Sat draws to see if you have an unclaimed prize.</p>

                <div class="meta-badges">
                    <span class="badge badge-fresh">🗓️ Last updated: <?php echo date("d F Y"); ?></span>
                    <span class="badge badge-data">📊 Latest Draw Scanned: <?php echo $latestDrawDate; ?></span>
                    <span class="badge badge-data">🔍 Total Depth: 100 Draws (~1 Year)</span>
                </div>

                <div class="checker-card">
                    <div class="checker-header">
                        <h2>Enter Your 6 Lotto Numbers</h2>
                        <p>Type your 6 main numbers below. (We will check the Bonus Ball automatically!)</p>
                    </div>

                    <form method="POST" action="/check-tickets/lotto/" id="checker-form">
                        <div class="input-row" id="input-container">
                            <?php for($i=1; $i<=6; $i++): ?>
                                <?php $val = isset($userBalls[$i-1]) ? htmlspecialchars((string)$userBalls[$i-1]) : ''; ?>
                                <div class="ball-input-wrap">
                                    <span class="input-label">Ball <?php echo $i; ?></span>
                                    <input type="number" name="balls[]" class="ticket-input" min="1" max="52" value="<?php echo $val; ?>" required placeholder="-">
                                </div>
                            <?php endfor; ?>
                        </div>

                        <button type="submit" class="btn-check">Scan 100 Draws Now</button>
                        
                        <div style="text-align: center; margin-top: 20px;">
                            <button type="button" onclick="clearInputs()" style="background:none; border:none; color:#94a3b8; font-weight:600; text-decoration:underline; cursor:pointer; font-size:0.9rem;">Clear Numbers</button>
                        </div>
                    </form>
                </div>

                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="results-box" id="results-anchor">
                        <div class="results-header">
                            <span>Scan Results: Main Lotto</span>
                            <span style="font-size:0.9rem; font-weight:600; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:6px;">100-Draw Scan</span>
                        </div>
                        <div class="results-body">
                            <?php if ($checkResults === 'invalid'): ?>
                                <div class="no-match">⚠️ Error: Ensure you have entered exactly 6 unique numbers (1-52).</div>
                            <?php elseif ($checkResults === false): ?>
                                <div class="no-match">⚠️ Database Error: Could not connect to the draw history database.</div>
                            <?php elseif (empty($checkResults)): ?>
                                <div class="no-match">
                                    ❌ No Winning Matches Found.<br>
                                    <span style="font-size:0.95rem; font-weight:500; color:#475569; display:block; margin-top:8px;">Your numbers did not trigger a payout division in the last 100 Lotto draws.</span>
                                </div>
                            <?php else: ?>
                                <p style="color: #475569; font-size: 1.05rem; margin-top:0; margin-bottom: 20px; font-weight: 600;">
                                    🎉 We found payout matches for your ticket in the following past draws:
                                </p>
                                <?php foreach($checkResults as $res): ?>
                                    <div class="match-row">
                                        <div class="match-date-wrap">
                                            <span class="match-date"><?php echo $res['date']; ?></span>
                                            <span class="match-tag">Verified Draw</span>
                                        </div>
                                        
                                        <div class="match-balls">
                                            <?php foreach($res['draw_balls'] as $db): ?>
                                                <div class="m-ball <?php echo in_array($db, $res['matched_balls']) ? 'hit' : ''; ?>">
                                                    <?php echo $db; ?>
                                                </div>
                                            <?php endforeach; ?>
                                            
                                            <div style="width: 2px; height: 40px; background: #e2e8f0; margin: 0 8px;"></div>
                                            
                                            <div class="m-ball <?php echo $res['bonus_matched'] ? 'hit-bonus' : ''; ?>" style="border-radius: 8px;" title="Bonus Ball">
                                                <?php echo $res['draw_bonus']; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="match-summary">
                                            Matched: <?php echo $res['match_count']; ?> 
                                            <?php echo $res['bonus_matched'] ? '+ Bonus' : ''; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            document.getElementById("results-anchor").scrollIntoView({ behavior: 'smooth', block: 'center' });
                        });
                    </script>
                <?php endif; ?>

                <section class="seo-section">
                    <h2>How to Check Lotto Results in South Africa</h2>
                    <p>The original South African Lotto remains a favorite for millions of players. However, checking tickets manually against the <a href="/results/lotto/">latest Lotto results</a> can sometimes lead to missed wins, especially when dealing with the Bonus Ball mechanics.</p>
                    <p>Our automated checking engine simplifies this. Enter the 6 numbers from your playslip just once, and we will instantly tell you if you hold a winning combination from any recent draw.</p>

                    <h3>Verify Your Lotto Numbers Against Past Draws</h3>
                    <p>A common point of confusion is how the Bonus Ball works. <strong>You do not select a Bonus Ball when buying a ticket.</strong> Instead, you pick 6 numbers from 1 to 52. During the draw, a 7th ball is pulled from the machine—this is the Bonus Ball. If you matched 5 of the main numbers, and your 6th chosen number happens to be the Bonus Ball, your payout skyrockets! Our system automatically does this math for you, highlighting the Bonus Ball in gold if you hit it.</p>

                    <h3>Check Old Lotto Tickets (Up to 100 Draws)</h3>
                    <p>Found an old ticket lying around? You have exactly 365 days to claim any lottery winnings before they expire and are forfeited to the National Lottery Distribution Trust Fund. Our system scans the previous 100 draws (which covers nearly an entire year of Wednesday and Saturday draws) to secure your claim window. You can also manually browse our <a href="/results/lotto/history/">full Lotto history archive</a>.</p>

                    <div class="e-e-a-t-box">
                        <strong>🔒 Trust & Verification:</strong> All results and payouts processed by this tool are strictly sourced from official Ithuba National Lottery data feeds and updated automatically after each verified draw.
                    </div>
                </section>

                <section class="faq-section">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <div class="faq-item">
                            <button class="faq-question">Why doesn't the checker ask for a Bonus Ball?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>In the South African Lotto, you only select 6 numbers on your playslip (from 1 to 52). The Bonus Ball is drawn from the remaining 46 balls in the machine. If one of your 6 chosen numbers matches the Bonus Ball, you win a higher prize tier. You do not pick the Bonus Ball yourself.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">How far back does this Lotto checker search?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>This specialized Lotto ticket checker instantly scans the last 100 official draws. Because Lotto is played twice a week (Wednesdays and Saturdays), this covers roughly an entire year of gameplay.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">What is the minimum I need to match to win a Lotto prize?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>In South Africa, the lowest prize division for the main Lotto game is Division 8, which requires you to match exactly 2 main numbers plus the Bonus Ball. If you don't have the Bonus Ball, you need at least 3 main numbers to win Division 7.</p></div></div>
                        </div>
                    </div>
                </section>

                <section class="related-section">
                    <h2 style="font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 16px;">Related Lotto Searches</h2>
                    <div class="related-grid">
                        <a href="/results/lotto/" class="related-card">
                            <h4>Latest Lotto Results</h4>
                            <p>View today's winning numbers and payouts.</p>
                        </a>
                        <a href="/results/lotto/predictions/" class="related-card">
                            <h4>Lotto Predictions</h4>
                            <p>Get algorithm-driven predictions for the next draw.</p>
                        </a>
                        <a href="/results/lotto/hot-cold/" class="related-card">
                            <h4>Hot & Cold Numbers</h4>
                            <p>See which Lotto numbers are trending this month.</p>
                        </a>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/results/lotto/hot-cold/">Lotto Hot & Cold</a></li>
                        <li><a href="/results/lotto/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/lotto/history/">Results Archive</a></li>
                        <li><a href="/check-tickets/" class="active">Ticket Checker Hub</a></li>
                        <li><a href="/check-tickets/lotto/" class="active" style="padding-left: 40px; font-size: 0.85rem;">↳ Lotto Checker</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        function clearInputs() {
            const inputs = document.querySelectorAll('.ticket-input');
            inputs.forEach(input => input.value = '');
            if(inputs.length > 0) inputs[0].focus();
        }

        document.addEventListener('DOMContentLoaded', () => {
            const container = document.getElementById('input-container');
            const inputs = Array.from(container.querySelectorAll('input[type="number"]'));
            
            // Advanced App-like Input Logic
            inputs.forEach((input, index) => {
                input.addEventListener('focus', function() { this.select(); });

                input.addEventListener('input', function() {
                    const maxVal = parseInt(this.max);
                    if (this.value.length >= 2) {
                        if (parseInt(this.value) > maxVal) {
                            this.value = maxVal; // Cap value
                        }
                        if (index < inputs.length - 1) {
                            inputs[index + 1].focus(); // Jump to next
                        }
                    }
                });

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && this.value === '') {
                        if (index > 0) {
                            inputs[index - 1].focus();
                            inputs[index - 1].value = ''; 
                        }
                    }
                });
            });

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>