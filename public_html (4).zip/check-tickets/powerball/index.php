<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to database (2 levels back)
require_once __DIR__ . '/../../db.php';

// --- SEO METADATA (GUIDELINE #1 & #9) ---
$pageTitle = "Check PowerBall Tickets Online South Africa – Verify Numbers & Results";
$metaDesc = "Check your PowerBall ticket instantly 🇿🇦 Enter your numbers and verify against the last 100 official South African draws. Find out if you’ve won now.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Ticket Checker", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/check-tickets/"],
    ["name" => "PowerBall Checker", "url" => $currentUrl]
];

// --- PROGRAMMATIC SEO DATA (GUIDELINE #7) ---
$latestDrawDate = "Recently";
try {
    $stmtLatest = $pdo->query("SELECT draw_date FROM powerball_results ORDER BY draw_date DESC LIMIT 1");
    $latestRow = $stmtLatest->fetch(PDO::FETCH_ASSOC);
    if ($latestRow) {
        $latestDrawDate = date('d F Y', strtotime($latestRow['draw_date']));
    }
} catch (Exception $e) {
    // Silently continue if DB fails
}

// --- HANDLE FORM SUBMISSION (100 DRAW SCAN) ---
$checkResults = null;
$userBalls = $_POST['balls'] ?? [];
$userBonus = $_POST['bonus'] ?? null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean and filter user inputs for PowerBall (1-50)
    $cleanBalls = [];
    foreach($userBalls as $b) {
        $val = (int)$b;
        if($val > 0 && $val <= 50) {
            $cleanBalls[] = $val;
        }
    }
    $cleanBalls = array_unique($cleanBalls);
    
    // Clean PowerBall Bonus (1-20)
    $cleanBonus = ((int)$userBonus > 0 && (int)$userBonus <= 20) ? (int)$userBonus : null;
    
    if (count($cleanBalls) === 5 && $cleanBonus !== null) {
        try {
            // Fetch the last 100 PowerBall draws
            $stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5, powerball FROM powerball_results ORDER BY draw_date DESC LIMIT 100");
            $recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $checkResults = [];
            foreach ($recentDraws as $draw) {
                $drawBalls = [
                    (int)$draw['ball_1'], (int)$draw['ball_2'], (int)$draw['ball_3'], 
                    (int)$draw['ball_4'], (int)$draw['ball_5']
                ];
                $drawBonus = (int)$draw['powerball'];
                
                // Compare combinations
                $matchedBalls = array_intersect($cleanBalls, $drawBalls);
                $matchCount = count($matchedBalls);
                $bonusMatched = ($cleanBonus === $drawBonus);
                
                // In SA PowerBall, matching just the PowerBall wins a prize, or matching 2+ main balls.
                if ($matchCount >= 2 || $bonusMatched) {
                    $checkResults[] = [
                        'date' => date('l, d M Y', strtotime($draw['draw_date'])),
                        'match_count' => $matchCount,
                        'matched_balls' => $matchedBalls,
                        'bonus_matched' => $bonusMatched,
                        'draw_balls' => $drawBalls,
                        'draw_bonus' => $drawBonus
                    ];
                }
            }
        } catch (Exception $e) {
            $checkResults = false; // DB Error
        }
    } else {
        $checkResults = 'invalid'; // Not enough valid numbers entered
    }
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $index + 1; ?>,
          "name": "<?php echo $crumb['name']; ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "SoftwareApplication",
      "name": "PowerBall Ticket Checker - NextDrawLogic",
      "applicationCategory": "UtilitiesApplication",
      "operatingSystem": "All",
      "description": "Cross-reference your South African PowerBall ticket numbers against the last 100 official Ithuba draws.",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "ZAR"
      }
    }
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How many numbers do I need to check a PowerBall ticket?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You must enter exactly 5 main numbers (between 1 and 50) and 1 PowerBall (between 1 and 20) to accurately verify your ticket against historical records."
          }
        },
        {
          "@type": "Question",
          "name": "How far back does this PowerBall checker search?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "This specialized PowerBall ticket checker instantly scans the last 100 official draws, which covers roughly a year of historical Tuesday and Friday gameplay."
          }
        },
        {
          "@type": "Question",
          "name": "Do I win anything if I only match the PowerBall?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes! In the South African PowerBall, matching only the PowerBall (with 0 main balls) guarantees a Division 9 payout."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* Layout */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* Typography & Headings */
        .page-title { font-size: 2.6rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; letter-spacing: -0.5px; }
        .page-intro { font-size: 1.15rem; color: #475569; line-height: 1.6; margin: 0 0 24px 0; }
        
        /* Badges for Freshness & Data */
        .meta-badges { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 32px; }
        .badge { display: inline-flex; align-items: center; padding: 6px 14px; border-radius: 99px; font-size: 0.85rem; font-weight: 700; }
        .badge-fresh { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .badge-data { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }

        /* Sidebar */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover, .sidebar-links a.active { background: #f8fafc; color: #e11d48; border-left-color: #e11d48; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* Checker Form UI */
        .checker-card { background: #ffffff; border-radius: 16px; padding: 40px 32px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); margin-bottom: 40px; position: relative; overflow: hidden; }
        .checker-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, #e11d48, #be123c); }
        
        .checker-header { text-align: center; margin-bottom: 32px; }
        .checker-header h2 { font-size: 1.8rem; color: #0f172a; margin: 0 0 8px 0; font-weight: 800; }
        .checker-header p { color: #64748b; margin: 0; font-size: 1rem; }
        
        .input-row { display: flex; justify-content: center; flex-wrap: wrap; gap: 16px; margin-bottom: 36px; }
        .ball-input-wrap { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        
        .ticket-input { width: 72px; height: 72px; border-radius: 50%; border: 2px solid #cbd5e1; font-size: 1.8rem; font-weight: 800; text-align: center; color: #0f172a; background: #ffffff; outline: none; transition: all 0.2s ease; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02); }
        .ticket-input:focus { border-color: #e11d48; box-shadow: 0 0 0 4px rgba(225, 29, 72, 0.2); transform: scale(1.05); }
        
        .ticket-input.bonus-input { border-color: #f59e0b; color: #d97706; background: #fffbeb; }
        .ticket-input.bonus-input:focus { box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.2); border-color: #d97706; }
        .input-label { font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .btn-check { display: block; margin: 0 auto; background: linear-gradient(135deg, #e11d48, #be123c); color: white; border: none; padding: 20px 56px; font-size: 1.2rem; font-weight: 800; border-radius: 99px; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(225, 29, 72, 0.3); text-transform: uppercase; letter-spacing: 0.5px; }
        .btn-check:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(225, 29, 72, 0.4); }

        /* Results Display */
        .results-box { background: #ffffff; border: 2px solid #e11d48; border-radius: 12px; padding: 0; margin-bottom: 40px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(225,29,72,0.1); }
        .results-header { background: #e11d48; color: white; padding: 20px 24px; margin: 0; font-size: 1.3rem; font-weight: 800; display: flex; align-items: center; justify-content: space-between; }
        .results-body { padding: 24px; background: #f8fafc; }
        
        .match-row { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; transition: transform 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .match-row:hover { transform: translateY(-2px); border-color: #cbd5e1; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .match-date-wrap { display: flex; flex-direction: column; gap: 4px; }
        .match-date { font-weight: 800; color: #0f172a; font-size: 1.1rem; }
        .match-tag { font-size: 0.8rem; font-weight: 700; color: #10b981; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .match-balls { display: flex; gap: 8px; flex-wrap: wrap; }
        .m-ball { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 800; background: #f1f5f9; color: #94a3b8; border: 1px solid #e2e8f0; }
        .m-ball.hit { background: #e11d48; color: white; border-color: #be123c; box-shadow: 0 2px 4px rgba(225,29,72,0.3); }
        .m-ball.hit-bonus { background: #f59e0b; color: white; border-radius: 8px; border-color: #d97706; box-shadow: 0 2px 4px rgba(245,158,11,0.3); }
        
        .match-summary { font-size: 1rem; font-weight: 800; color: #059669; background: #d1fae5; padding: 8px 16px; border-radius: 8px; border: 1px solid #10b981; }
        .no-match { color: #b91c1c; font-weight: 700; font-size: 1.1rem; text-align: center; padding: 32px; background: #fef2f2; border-radius: 8px; border: 2px dashed #fecaca; }

        /* SEO & Text Blocks */
        .seo-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; }
        .seo-section h3 { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-top: 28px; margin-bottom: 12px; }
        .seo-section p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-section a { color: #e11d48; font-weight: 700; text-decoration: none; }
        .seo-section a:hover { text-decoration: underline; }
        
        .e-e-a-t-box { background: #f8fafc; border-left: 4px solid #3b82f6; padding: 16px 20px; border-radius: 0 8px 8px 0; margin-top: 24px; font-size: 0.95rem; color: #334155; }

        /* FAQ Section */
        .faq-section { margin-bottom: 48px; }
        .faq-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px; overflow: hidden; transition: all 0.2s ease; }
        .faq-item:hover { border-color: #cbd5e1; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #e11d48; font-size: 1.6rem; line-height: 1; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); color: #be123c; }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* Related Links Grid (Guideline #8) */
        .related-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-top: 20px; }
        .related-card { background: #f8fafc; border: 1px solid #e2e8f0; padding: 20px; border-radius: 10px; text-decoration: none; transition: all 0.2s ease; display: block; }
        .related-card:hover { background: #ffffff; border-color: #e11d48; box-shadow: 0 4px 12px rgba(225,29,72,0.1); transform: translateY(-2px); }
        .related-card h4 { margin: 0 0 8px 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; }
        .related-card p { margin: 0; font-size: 0.9rem; color: #64748b; }

        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }

        @media(max-width: 1024px) { .layout-with-sidebar { grid-template-columns: 1fr; } .lotto-sidebar { position: relative; top: 0; } }
        @media(max-width: 600px) { .ticket-input { width: 56px; height: 56px; font-size: 1.4rem; } .m-ball { width: 34px; height: 34px; font-size: 0.9rem; } .btn-check { padding: 16px 32px; font-size: 1.1rem; } }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <h1 class="page-title">Check PowerBall Tickets Online South Africa</h1>
                <p class="page-intro">Instantly verify your South African PowerBall tickets. We automatically cross-reference your custom combination against the last 100 official Ithuba draws to see if you have an unclaimed prize.</p>

                <div class="meta-badges">
                    <span class="badge badge-fresh">🗓️ Last updated: <?php echo date("d F Y"); ?></span>
                    <span class="badge badge-data">📊 Latest Draw Scanned: <?php echo $latestDrawDate; ?></span>
                    <span class="badge badge-data">🔍 Total Depth: 100 Draws</span>
                </div>

                <div class="checker-card">
                    <div class="checker-header">
                        <h2>Enter Your PowerBall Numbers</h2>
                        <p>Type your 5 main numbers and 1 Bonus PowerBall below.</p>
                    </div>

                    <form method="POST" action="/check-tickets/powerball/" id="checker-form">
                        <div class="input-row" id="input-container">
                            <?php for($i=1; $i<=5; $i++): ?>
                                <?php $val = isset($userBalls[$i-1]) ? htmlspecialchars((string)$userBalls[$i-1]) : ''; ?>
                                <div class="ball-input-wrap">
                                    <span class="input-label">Ball <?php echo $i; ?></span>
                                    <input type="number" name="balls[]" class="ticket-input" min="1" max="50" value="<?php echo $val; ?>" required placeholder="-">
                                </div>
                            <?php endfor; ?>
                            
                            <div class="ball-input-wrap" style="margin-left: 16px;">
                                <span class="input-label" style="color: #d97706;">PowerBall</span>
                                <input type="number" name="bonus" class="ticket-input bonus-input" min="1" max="20" value="<?php echo htmlspecialchars((string)$userBonus); ?>" required placeholder="-">
                            </div>
                        </div>

                        <button type="submit" class="btn-check">Scan 100 Draws Now</button>
                        
                        <div style="text-align: center; margin-top: 20px;">
                            <button type="button" onclick="clearInputs()" style="background:none; border:none; color:#94a3b8; font-weight:600; text-decoration:underline; cursor:pointer; font-size:0.9rem;">Clear Numbers</button>
                        </div>
                    </form>
                </div>

                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="results-box" id="results-anchor">
                        <div class="results-header">
                            <span>Scan Results: PowerBall</span>
                            <span style="font-size:0.9rem; font-weight:600; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:6px;">100-Draw Scan</span>
                        </div>
                        <div class="results-body">
                            <?php if ($checkResults === 'invalid'): ?>
                                <div class="no-match">⚠️ Error: Ensure you have entered 5 main balls (1-50) and 1 PowerBall (1-20) correctly.</div>
                            <?php elseif ($checkResults === false): ?>
                                <div class="no-match">⚠️ Database Error: Could not connect to the draw history database.</div>
                            <?php elseif (empty($checkResults)): ?>
                                <div class="no-match">
                                    ❌ No Winning Matches Found.<br>
                                    <span style="font-size:0.95rem; font-weight:500; color:#475569; display:block; margin-top:8px;">Your numbers did not trigger a payout division in the last 100 PowerBall draws.</span>
                                </div>
                            <?php else: ?>
                                <p style="color: #475569; font-size: 1.05rem; margin-top:0; margin-bottom: 20px; font-weight: 600;">
                                    🎉 We found payout matches for your ticket in the following past draws:
                                </p>
                                <?php foreach($checkResults as $res): ?>
                                    <div class="match-row">
                                        <div class="match-date-wrap">
                                            <span class="match-date"><?php echo $res['date']; ?></span>
                                            <span class="match-tag">Verified Draw</span>
                                        </div>
                                        
                                        <div class="match-balls">
                                            <?php foreach($res['draw_balls'] as $db): ?>
                                                <div class="m-ball <?php echo in_array($db, $res['matched_balls']) ? 'hit' : ''; ?>">
                                                    <?php echo $db; ?>
                                                </div>
                                            <?php endforeach; ?>
                                            
                                            <div class="m-ball <?php echo $res['bonus_matched'] ? 'hit-bonus' : ''; ?>" style="border-radius: 8px;">
                                                <?php echo $res['draw_bonus']; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="match-summary">
                                            Matched: <?php echo $res['match_count']; ?> 
                                            <?php echo $res['bonus_matched'] ? '+ PB' : ''; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            document.getElementById("results-anchor").scrollIntoView({ behavior: 'smooth', block: 'center' });
                        });
                    </script>
                <?php endif; ?>

                <section class="seo-section">
                    <h2>How to Check PowerBall Results in South Africa</h2>
                    <p>Playing the South African PowerBall gives you two massive chances a week (Tuesdays and Fridays) to win life-changing jackpots. But with complex payout structures, manually checking your ticket against the <a href="/results/powerball/">latest PowerBall results</a> can be confusing, and it is easy to miss a lower-division win.</p>
                    <p>Our automated checking engine simplifies this. Enter your numbers once, and we will instantly tell you if you hold a winning combination.</p>

                    <h3>Verify Your PowerBall Numbers Against Past Draws</h3>
                    <p>One of the biggest mistakes players make is throwing away tickets without checking them thoroughly. Unlike Daily Lotto, the PowerBall utilizes a dual-matrix system. Because of this, the payout structure is highly weighted toward the PowerBall itself. <strong>If you match 0 main balls, but correctly match the PowerBall, you still win a Division 9 prize!</strong></p>

                    <h3>Check Old PowerBall Tickets (Up to 100 Draws)</h3>
                    <p>Found an old ticket in your wallet? Don't throw it away! In South Africa, you have 365 days to claim your winnings from the draw date. Our system scans the previous 100 draws (roughly a year of gameplay) to ensure you don't miss a valid claim. If you prefer to verify manually, you can always browse our <a href="/results/powerball/history/">full PowerBall history archive</a>.</p>

                    <div class="e-e-a-t-box">
                        <strong>🔒 Trust & Verification:</strong> All results and payouts processed by this tool are strictly sourced from official Ithuba National Lottery data feeds and updated automatically after each verified draw.
                    </div>
                </section>

                <section class="faq-section">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <div class="faq-item">
                            <button class="faq-question">How many numbers do I need to check a PowerBall ticket?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>You must enter exactly 5 main numbers (between 1 and 50) and 1 PowerBall (between 1 and 20) to accurately verify your ticket against historical records.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">How far back does this PowerBall checker search?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>This specialized PowerBall ticket checker instantly scans the last 100 official draws, which covers roughly a year of historical Tuesday and Friday gameplay.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">Do I win anything if I only match the PowerBall?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>Yes! In the South African PowerBall, matching only the PowerBall (with 0 main balls) guarantees a Division 9 payout.</p></div></div>
                        </div>
                    </div>
                </section>

                <section class="related-section">
                    <h2 style="font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 16px;">Related PowerBall Searches</h2>
                    <div class="related-grid">
                        <a href="/results/powerball/" class="related-card">
                            <h4>Latest PowerBall Results</h4>
                            <p>View today's winning numbers and payouts.</p>
                        </a>
                        <a href="/results/powerball/predictions/" class="related-card">
                            <h4>PowerBall Predictions</h4>
                            <p>Get algorithm-driven predictions for the next draw.</p>
                        </a>
                        <a href="/results/powerball/hot-cold/" class="related-card">
                            <h4>Hot & Cold Numbers</h4>
                            <p>See which numbers are trending this month.</p>
                        </a>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/results/powerball/hot-cold/">PowerBall Hot & Cold</a></li>
                        <li><a href="/results/powerball/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/powerball/history/">Results Archive</a></li>
                        <li><a href="/check-tickets/" class="active">Ticket Checker Hub</a></li>
                        <li><a href="https://affiliates.hollywoodbets.net/" class="highlight" target="_blank" rel="noopener nofollow">Play Online Now &rarr;</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        function clearInputs() {
            const inputs = document.querySelectorAll('.ticket-input');
            inputs.forEach(input => input.value = '');
            if(inputs.length > 0) inputs[0].focus();
        }

        document.addEventListener('DOMContentLoaded', () => {
            const container = document.getElementById('input-container');
            const inputs = Array.from(container.querySelectorAll('input[type="number"]'));
            
            // Advanced App-like Input Logic
            inputs.forEach((input, index) => {
                input.addEventListener('focus', function() { this.select(); });

                input.addEventListener('input', function() {
                    const maxVal = parseInt(this.max);
                    if (this.value.length >= 2) {
                        if (parseInt(this.value) > maxVal) {
                            this.value = maxVal; // Cap value
                        }
                        if (index < inputs.length - 1) {
                            inputs[index + 1].focus(); // Jump to next
                        }
                    }
                });

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && this.value === '') {
                        if (index > 0) {
                            inputs[index - 1].focus();
                            inputs[index - 1].value = ''; 
                        }
                    }
                });
            });

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>