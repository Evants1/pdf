<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to database (2 levels back)
require_once __DIR__ . '/../../db.php';

// --- SEO METADATA (MAXIMIZED FOR DAILY LOTTO) ---
$pageTitle = "Check Daily Lotto Tickets Online (SA) – Scan Last 100 Results Instantly";
$metaDesc = "Check your Daily Lotto ticket online in South Africa. Enter your numbers and instantly scan the last 100 official results to see if you’ve won. Fast, free & accurate.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Ticket Checker", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/check-tickets/"],
    ["name" => "Daily Lotto Checker", "url" => $currentUrl]
];

// --- PROGRAMMATIC SEO DATA (FRESHNESS SIGNAL) ---
$latestDrawDate = "Recently";
try {
    $stmtLatest = $pdo->query("SELECT draw_date FROM daily_lotto_results ORDER BY draw_date DESC LIMIT 1");
    $latestRow = $stmtLatest->fetch(PDO::FETCH_ASSOC);
    if ($latestRow) {
        $latestDrawDate = date('d F Y', strtotime($latestRow['draw_date']));
    }
} catch (Exception $e) {
    // Silently continue if DB fails
}

// --- HANDLE FORM SUBMISSION (100 DRAW SCAN) ---
$checkResults = null;
$userBalls = $_POST['balls'] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Clean and filter user inputs for Daily Lotto (1-36)
    $cleanBalls = [];
    foreach($userBalls as $b) {
        $val = (int)$b;
        if($val > 0 && $val <= 36) {
            $cleanBalls[] = $val;
        }
    }
    $cleanBalls = array_unique($cleanBalls);
    
    // Daily Lotto only requires 5 balls, no bonus.
    if (count($cleanBalls) === 5) {
        try {
            // Fetch the last 100 Daily Lotto draws
            $stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5 FROM daily_lotto_results ORDER BY draw_date DESC LIMIT 100");
            $recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            $checkResults = [];
            foreach ($recentDraws as $draw) {
                $drawBalls = [
                    (int)$draw['ball_1'], (int)$draw['ball_2'], (int)$draw['ball_3'], 
                    (int)$draw['ball_4'], (int)$draw['ball_5']
                ];
                
                // Compare combinations
                $matchedBalls = array_intersect($cleanBalls, $drawBalls);
                $matchCount = count($matchedBalls);
                
                // SA Daily Lotto pays out for matching 2, 3, 4, or 5 balls.
                if ($matchCount >= 2) {
                    $checkResults[] = [
                        'date' => date('l, d M Y', strtotime($draw['draw_date'])),
                        'match_count' => $matchCount,
                        'matched_balls' => $matchedBalls,
                        'draw_balls' => $drawBalls
                    ];
                }
            }
        } catch (Exception $e) {
            $checkResults = false; // DB Error
        }
    } else {
        $checkResults = 'invalid'; // Not enough valid numbers entered
    }
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "<?php echo addslashes($pageTitle); ?>",
      "description": "<?php echo addslashes($metaDesc); ?>",
      "inLanguage": "en-ZA"
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $index + 1; ?>,
          "name": "<?php echo $crumb['name']; ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebApplication",
      "name": "Daily Lotto Checker South Africa",
      "url": "<?php echo $currentUrl; ?>",
      "applicationCategory": "Utility",
      "operatingSystem": "All",
      "description": "Cross-reference your South African Daily Lotto ticket numbers against the last 100 official Ithuba draws.",
      "offers": {
        "@type": "Offer",
        "price": "0",
        "priceCurrency": "ZAR"
      }
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How many numbers do I need to check a Daily Lotto ticket?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You must enter exactly 5 main numbers, choosing from 1 to 36, to verify your Daily Lotto ticket. Unlike PowerBall, there is no bonus ball in this game."
          }
        },
        {
          "@type": "Question",
          "name": "How far back does this Daily Lotto checker search?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Our ticket checker instantly scans the last 100 official draws. Because Daily Lotto is drawn every day, this covers roughly the last 3 months of historical gameplay."
          }
        },
        {
          "@type": "Question",
          "name": "When do Daily Lotto draws take place?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "The South African Daily Lotto is drawn every single evening at 21:00 SAST, except on Christmas Day."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <style>
        /* Layout */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* Typography & Headings */
        .page-title { font-size: 2.6rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; letter-spacing: -0.5px; }
        .page-intro { font-size: 1.15rem; color: #475569; line-height: 1.6; margin: 0 0 24px 0; }
        
        /* Badges for Freshness & Data */
        .meta-badges { display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 32px; }
        .badge { display: inline-flex; align-items: center; padding: 6px 14px; border-radius: 99px; font-size: 0.85rem; font-weight: 700; }
        .badge-fresh { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .badge-data { background: #f1f5f9; color: #475569; border: 1px solid #e2e8f0; }

        /* Sidebar */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover, .sidebar-links a.active { background: #f8fafc; color: #d97706; border-left-color: #d97706; font-weight: 800; }

        /* Checker Form UI (Daily Lotto Theme - Orange/Gold) */
        .checker-card { background: #ffffff; border-radius: 16px; padding: 40px 32px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); margin-bottom: 40px; position: relative; overflow: hidden; }
        .checker-card::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, #f59e0b, #d97706); }
        
        .checker-header { text-align: center; margin-bottom: 32px; }
        .checker-header h2 { font-size: 1.8rem; color: #0f172a; margin: 0 0 8px 0; font-weight: 800; }
        .checker-header p { color: #64748b; margin: 0; font-size: 1rem; }
        
        .input-row { display: flex; justify-content: center; flex-wrap: wrap; gap: 16px; margin-bottom: 36px; }
        .ball-input-wrap { display: flex; flex-direction: column; align-items: center; gap: 8px; }
        
        .ticket-input { width: 72px; height: 72px; border-radius: 50%; border: 2px solid #cbd5e1; font-size: 1.8rem; font-weight: 800; text-align: center; color: #0f172a; background: #ffffff; outline: none; transition: all 0.2s ease; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02); }
        .ticket-input:focus { border-color: #f59e0b; box-shadow: 0 0 0 4px rgba(245, 158, 11, 0.2); transform: scale(1.05); }
        
        .input-label { font-size: 0.85rem; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .btn-check { display: flex; align-items: center; justify-content: center; gap: 12px; margin: 0 auto; background: linear-gradient(135deg, #f59e0b, #d97706); color: white; border: none; padding: 20px 56px; font-size: 1.2rem; font-weight: 800; border-radius: 99px; cursor: pointer; transition: all 0.3s ease; box-shadow: 0 4px 12px rgba(217, 119, 6, 0.3); text-transform: uppercase; letter-spacing: 0.5px; }
        .btn-check:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(217, 119, 6, 0.4); }

        /* Results Display */
        .results-box { background: #ffffff; border: 2px solid #d97706; border-radius: 12px; padding: 0; margin-bottom: 40px; overflow: hidden; box-shadow: 0 10px 15px -3px rgba(217,119,6,0.1); }
        .results-header { background: #d97706; color: white; padding: 20px 24px; margin: 0; font-size: 1.3rem; font-weight: 800; display: flex; align-items: center; justify-content: space-between; }
        .results-body { padding: 24px; background: #f8fafc; }
        
        .match-row { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; margin-bottom: 12px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px; transition: transform 0.2s ease; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .match-row:hover { transform: translateY(-2px); border-color: #cbd5e1; box-shadow: 0 4px 6px rgba(0,0,0,0.05); }
        
        .match-date-wrap { display: flex; flex-direction: column; gap: 4px; }
        .match-date { font-weight: 800; color: #0f172a; font-size: 1.1rem; }
        .match-tag { font-size: 0.8rem; font-weight: 700; color: #10b981; text-transform: uppercase; letter-spacing: 0.5px; }
        
        .match-balls { display: flex; gap: 8px; flex-wrap: wrap; }
        .m-ball { width: 40px; height: 40px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1rem; font-weight: 800; background: #f1f5f9; color: #94a3b8; border: 1px solid #e2e8f0; }
        .m-ball.hit { background: #d97706; color: white; border-color: #b45309; box-shadow: 0 2px 4px rgba(217,119,6,0.3); }
        
        .match-summary { font-size: 1rem; font-weight: 800; color: #059669; background: #d1fae5; padding: 8px 16px; border-radius: 8px; border: 1px solid #10b981; }
        .no-match { color: #b91c1c; font-weight: 700; font-size: 1.1rem; text-align: center; padding: 32px; background: #fef2f2; border-radius: 8px; border: 2px dashed #fecaca; }

        /* SEO & Text Blocks */
        .seo-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; }
        .seo-section h3 { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-top: 28px; margin-bottom: 12px; }
        .seo-section p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-section a { color: #d97706; font-weight: 700; text-decoration: none; }
        .seo-section a:hover { text-decoration: underline; }
        
        .e-e-a-t-box { background: #f8fafc; border-left: 4px solid #3b82f6; padding: 16px 20px; border-radius: 0 8px 8px 0; margin-top: 24px; font-size: 0.95rem; color: #334155; }

        /* FAQ Section */
        .faq-section { margin-bottom: 48px; }
        .faq-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px; overflow: hidden; transition: all 0.2s ease; }
        .faq-item:hover { border-color: #cbd5e1; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #d97706; font-size: 1.6rem; line-height: 1; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); color: #b45309; }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* Tools Block */
        .tools-list { list-style: none; padding: 0; margin: 0; }
        .tools-list li { margin-bottom: 12px; }
        .tools-list a { display: inline-flex; align-items: center; color: #d97706; font-weight: 700; text-decoration: none; font-size: 1.05rem; }
        .tools-list a::before { content: "→"; margin-right: 8px; font-weight: 800; color: #94a3b8; }
        .tools-list a:hover { text-decoration: underline; color: #b45309; }

        input[type=number]::-webkit-inner-spin-button, input[type=number]::-webkit-outer-spin-button { -webkit-appearance: none; margin: 0; }
        input[type=number] { -moz-appearance: textfield; }

        @media(max-width: 1024px) { .layout-with-sidebar { grid-template-columns: 1fr; } .lotto-sidebar { position: relative; top: 0; } }
        @media(max-width: 600px) { .ticket-input { width: 56px; height: 56px; font-size: 1.4rem; } .m-ball { width: 34px; height: 34px; font-size: 0.9rem; } .btn-check { padding: 16px 32px; font-size: 1.1rem; } }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <h1 class="page-title">Check Daily Lotto Ticket Online South Africa (Instant Results)</h1>
                <p class="page-intro">Instantly verify your South African Daily Lotto tickets. Since the game is drawn every evening, it's easy to lose track. We automatically cross-reference your numbers against the last 100 official Ithuba draws.</p>

                <div class="meta-badges">
                    <span class="badge badge-fresh">🗓️ Updated after every official draw (21:00 SAST)</span>
                    <span class="badge badge-data">📊 Latest Draw Scanned: <?php echo $latestDrawDate; ?></span>
                    <span class="badge badge-data">🔍 Total Depth: 100 Draws (~3 Months)</span>
                </div>

                <h2>Daily Lotto Ticket Checker South Africa (Instant Results)</h2>
                <p style="color: #475569; line-height: 1.6; margin-bottom: 32px;">Use our free Daily Lotto ticket checker to verify your numbers against the latest and past results in South Africa. This tool scans up to 100 previous draws instantly so you don't miss a payout.</p>

                <div class="checker-card">
                    <div class="checker-header">
                        <h2>Enter Your Daily Lotto Numbers</h2>
                        <p>Type your 5 main numbers (1-36) below. No bonus ball required!</p>
                    </div>

                    <form method="POST" action="/check-tickets/daily-lotto/" id="checker-form">
                        <div class="input-row" id="input-container">
                            <?php for($i=1; $i<=5; $i++): ?>
                                <?php $val = isset($userBalls[$i-1]) ? htmlspecialchars((string)$userBalls[$i-1]) : ''; ?>
                                <div class="ball-input-wrap">
                                    <span class="input-label">Ball <?php echo $i; ?></span>
                                    <input type="number" name="balls[]" class="ticket-input" min="1" max="36" value="<?php echo $val; ?>" required placeholder="-">
                                </div>
                            <?php endfor; ?>
                        </div>

                        <button type="submit" class="btn-check" id="submit-btn">
                            <span>Scan 100 Draws Now</span>
                        </button>
                        
                        <div style="text-align: center; margin-top: 20px;">
                            <button type="button" onclick="clearInputs()" style="background:none; border:none; color:#94a3b8; font-weight:600; text-decoration:underline; cursor:pointer; font-size:0.9rem;">Clear Numbers</button>
                        </div>
                    </form>
                </div>

                <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                    <div class="results-box" id="results-anchor" data-nosnippet>
                        <div class="results-header">
                            <span>Scan Results: Daily Lotto</span>
                            <span style="font-size:0.9rem; font-weight:600; background:rgba(255,255,255,0.2); padding:4px 10px; border-radius:6px;">100-Draw Scan</span>
                        </div>
                        <div class="results-body">
                            <?php if ($checkResults === 'invalid'): ?>
                                <div class="no-match">⚠️ Error: Ensure you have entered exactly 5 balls between 1 and 36.</div>
                            <?php elseif ($checkResults === false): ?>
                                <div class="no-match">⚠️ Database Error: Could not connect to the draw history database.</div>
                            <?php elseif (empty($checkResults)): ?>
                                <div class="no-match">
                                    ❌ No Winning Matches Found.<br>
                                    <span style="font-size:0.95rem; font-weight:500; color:#475569; display:block; margin-top:8px;">Your numbers did not match 2 or more balls in the last 100 Daily Lotto draws.</span>
                                </div>
                            <?php else: ?>
                                <p style="color: #475569; font-size: 1.05rem; margin-top:0; margin-bottom: 20px; font-weight: 600;">
                                    🎉 We found payout matches for your ticket in the following past draws:
                                </p>
                                <?php foreach($checkResults as $res): ?>
                                    <div class="match-row">
                                        <div class="match-date-wrap">
                                            <span class="match-date"><?php echo $res['date']; ?></span>
                                            <span class="match-tag">Verified Draw</span>
                                        </div>
                                        
                                        <div class="match-balls">
                                            <?php foreach($res['draw_balls'] as $db): ?>
                                                <div class="m-ball <?php echo in_array($db, $res['matched_balls']) ? 'hit' : ''; ?>">
                                                    <?php echo $db; ?>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        
                                        <div class="match-summary">
                                            Matched: <?php echo $res['match_count']; ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <script>
                        document.addEventListener("DOMContentLoaded", function() {
                            document.getElementById("results-anchor").scrollIntoView({ behavior: 'smooth', block: 'center' });
                        });
                    </script>
                <?php endif; ?>

                <section class="seo-section">
                    <h3>Can I Check My Daily Lotto Ticket Online?</h3>
                    <p>Yes, you can <strong>check your lotto ticket online in SA</strong> using our free South African ticket checker. Simply enter your 5 numbers and compare them against official <a href="/results/daily-lotto/">Daily Lotto results South Africa</a> instantly.</p>

                    <h3>How Do I Know If My Daily Lotto Ticket Won?</h3>
                    <p>You win in Daily Lotto by matching at least 2 numbers. Our <strong>lotto results checker</strong> highlights your matches in gold and automatically calculates if your combination qualifies for a payout based on the <strong>Daily Lotto numbers today</strong>.</p>
                    
                    <h3>Daily Lotto vs PowerBall – What’s the Difference?</h3>
                    <p>Daily Lotto is drawn every day and uses 5 numbers from 1–36, while PowerBall includes a bonus ball and significantly larger jackpots. Daily Lotto offers better overall odds for smaller, daily wins. You can also <a href="/check-tickets/powerball/">verify a PowerBall ticket</a> using our dedicated tools.</p>

                    <h3>Check Old Daily Lotto Tickets (Up to 100 Draws)</h3>
                    <p>Found a crumpled ticket in your pocket? Don't throw it away! In South Africa, National Lottery tickets are valid for 365 days from the draw date. Our system scans the previous 100 draws to ensure you don't miss a valid claim. If you need to <strong>verify a lotto ticket in South Africa</strong> that is older than 3 months, you can manually browse our <a href="/results/daily-lotto/history/">full Daily Lotto history archive</a>.</p>

                    <div class="e-e-a-t-box">
                        <strong>🔒 Trust & Verification:</strong> This tool uses verified results from official South African National Lottery draws operated by Ithuba. All data is automatically updated and cross-checked for accuracy immediately after the 21:00 SAST draw.
                    </div>
                </section>

                <section class="seo-section" style="padding: 24px 32px;">
                    <h2 style="margin-bottom: 16px; font-size: 1.5rem; border-bottom: none;">Daily Lotto Tools & Resources</h2>
                    <ul class="tools-list">
                        <li><a href="/results/daily-lotto/">Today's Daily Lotto Results</a></li>
                        <li><a href="/results/daily-lotto/history/">Full Results History</a></li>
                        <li><a href="/results/daily-lotto/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/daily-lotto/hot-cold/">Hot & Cold Numbers</a></li>
                    </ul>
                </section>

                <section class="faq-section">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <div class="faq-item">
                            <button class="faq-question">How many numbers do I need to check a Daily Lotto ticket?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>You must enter exactly 5 main numbers, choosing from 1 to 36, to verify your Daily Lotto ticket. Unlike PowerBall, there is no bonus ball in this game.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">How far back does this Daily Lotto checker search?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>Our ticket checker instantly scans the last 100 official draws. Because Daily Lotto is drawn every day, this covers roughly the last 3 months of historical gameplay.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">When do Daily Lotto draws take place?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>The South African Daily Lotto is drawn every single evening at 21:00 SAST, 364 days a year (excluding Christmas Day).</p></div></div>
                        </div>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/results/daily-lotto/hot-cold/">Daily Lotto Hot & Cold</a></li>
                        <li><a href="/results/daily-lotto/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/daily-lotto/history/">Results Archive</a></li>
                        <li><a href="/check-tickets/" class="active">Ticket Checker Hub</a></li>
                        <li><a href="/check-tickets/daily-lotto/" class="active" style="padding-left: 40px; font-size: 0.85rem;">↳ Daily Lotto Checker</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        function clearInputs() {
            const inputs = document.querySelectorAll('.ticket-input');
            inputs.forEach(input => input.value = '');
            localStorage.removeItem('dailyLottoSavedBalls');
            if(inputs.length > 0) inputs[0].focus();
        }

        document.addEventListener('DOMContentLoaded', () => {
            const container = document.getElementById('input-container');
            const inputs = Array.from(container.querySelectorAll('input[type="number"]'));
            const form = document.getElementById('checker-form');
            const submitBtn = document.getElementById('submit-btn');
            
            // UX Feature: Load last checked numbers from LocalStorage (if not a fresh POST)
            const isPost = <?php echo $_SERVER['REQUEST_METHOD'] === 'POST' ? 'true' : 'false'; ?>;
            if (!isPost) {
                const savedBalls = JSON.parse(localStorage.getItem('dailyLottoSavedBalls'));
                if (savedBalls && savedBalls.length === 5) {
                    inputs.forEach((input, index) => {
                        input.value = savedBalls[index] || '';
                    });
                }
            }
            
            // UX Feature: Loading Spinner & Save to LocalStorage on submit
            form.addEventListener('submit', () => {
                const currentBalls = inputs.map(input => input.value);
                localStorage.setItem('dailyLottoSavedBalls', JSON.stringify(currentBalls));
                submitBtn.innerHTML = '<span>Scanning... ⏳</span>';
                submitBtn.style.opacity = '0.8';
                submitBtn.style.cursor = 'wait';
            });
            
            // Advanced App-like Input Logic
            inputs.forEach((input, index) => {
                input.addEventListener('focus', function() { this.select(); });

                input.addEventListener('input', function() {
                    const maxVal = parseInt(this.max);
                    if (this.value.length >= 2) {
                        if (parseInt(this.value) > maxVal) {
                            this.value = maxVal; // Cap value
                        }
                        if (index < inputs.length - 1) {
                            inputs[index + 1].focus(); // Jump to next
                        }
                    }
                });

                input.addEventListener('keydown', function(e) {
                    if (e.key === 'Backspace' && this.value === '') {
                        if (index > 0) {
                            inputs[index - 1].focus();
                            inputs[index - 1].value = ''; 
                        }
                    }
                });
            });

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>