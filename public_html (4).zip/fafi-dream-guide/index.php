<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to database (if needed for nav/footer)
require_once __DIR__ . '/../db.php';

// --- SEO METADATA (MAXIMIZED FOR FAFI DREAM GUIDE) ---
$pageTitle = "SA Fafi Dream Guide – Translate Dreams Into Lucky Numbers";
$metaDesc = "Translate your dreams into lucky South African Fafi numbers. Use our interactive dream guide to find meanings for snakes, water, money, and more to play the lotto.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Fafi Dream Guide", "url" => $currentUrl]
];

// --- FAFI DICTIONARY DATA ---
// Traditional 1-36 SA Fafi / Mo-China Guide
$fafiData = [
    ["num" => 1, "terms" => ["King", "Blood", "White Man", "Left Eye"], "cat" => "people"],
    ["num" => 2, "terms" => ["Monkey", "Native", "Spirit", "Chief", "Copper"], "cat" => "animals"],
    ["num" => 3, "terms" => ["Sea Water", "Accident", "Frog", "Sailor", "Sex"], "cat" => "nature"],
    ["num" => 4, "terms" => ["Dead Man", "Turkey", "Small Fortune", "Bed"], "cat" => "death"],
    ["num" => 5, "terms" => ["Tiger", "Fight", "Strong Man", "Thief"], "cat" => "animals"],
    ["num" => 6, "terms" => ["Ox", "Gentleman", "Milk", "Blood"], "cat" => "animals"],
    ["num" => 7, "terms" => ["Lion", "Thief", "Big Stick", "Chickens"], "cat" => "animals"],
    ["num" => 8, "terms" => ["Pig", "Drunk Man", "Loafer", "Fat Man"], "cat" => "animals"],
    ["num" => 9, "terms" => ["Moon", "Baby", "Owl", "Devil", "Pumpkin"], "cat" => "nature"],
    ["num" => 10, "terms" => ["Eggs", "Train", "Grave", "Boat"], "cat" => "objects"],
    ["num" => 11, "terms" => ["Carriage", "Wood", "Tree", "Bicycle"], "cat" => "nature"],
    ["num" => 12, "terms" => ["Dead Woman", "Duck", "Small Fire"], "cat" => "death"],
    ["num" => 13, "terms" => ["Big Fish", "Ghost", "Spirits"], "cat" => "nature"],
    ["num" => 14, "terms" => ["Old Woman", "Fox", "Detective", "Nurse"], "cat" => "people"],
    ["num" => 15, "terms" => ["Bad Woman", "Prostitute", "Canary", "White Horse"], "cat" => "people"],
    ["num" => 16, "terms" => ["Small House", "Pigeon", "Young Woman", "Letter"], "cat" => "objects"],
    ["num" => 17, "terms" => ["Diamond", "Queen", "Pearls", "Stars", "White Woman"], "cat" => "wealth"],
    ["num" => 18, "terms" => ["Silver Money", "Servant", "Right Path", "Rain"], "cat" => "wealth"],
    ["num" => 19, "terms" => ["Little Girl", "Smoke", "Bread", "Bird"], "cat" => "people"],
    ["num" => 20, "terms" => ["Cat", "Sky", "Tears", "Music"], "cat" => "animals"],
    ["num" => 21, "terms" => ["Elephant", "Old Man", "Stranger", "Teeth"], "cat" => "animals"],
    ["num" => 22, "terms" => ["Ships", "Shoes", "Rats", "Motorcar"], "cat" => "objects"],
    ["num" => 23, "terms" => ["Horse", "Doctor", "Head", "Hair"], "cat" => "animals"],
    ["num" => 24, "terms" => ["Mouth", "Wild Cat", "Vixen", "Lioness"], "cat" => "body"],
    ["num" => 25, "terms" => ["Big House", "Church", "Boxer", "Hospital"], "cat" => "objects"],
    ["num" => 26, "terms" => ["Bees", "Crown", "Bad Man", "Bush"], "cat" => "animals"],
    ["num" => 27, "terms" => ["Dog", "Policeman", "Sad News", "Medicine"], "cat" => "animals"],
    ["num" => 28, "terms" => ["Herring", "Thief", "Surprise", "Small Fish"], "cat" => "animals"],
    ["num" => 29, "terms" => ["Small Water", "Tears", "Priest", "Right Eye"], "cat" => "nature"],
    ["num" => 30, "terms" => ["Fowl", "Graveyard", "Sun", "Forest"], "cat" => "nature"],
    ["num" => 31, "terms" => ["Big Fire", "Bishop", "Feathers", "Tick"], "cat" => "nature"],
    ["num" => 32, "terms" => ["Gold Money", "Snake", "Dirty Woman"], "cat" => "wealth"],
    ["num" => 33, "terms" => ["Little Boy", "Spider", "Spider Web"], "cat" => "people"],
    ["num" => 34, "terms" => ["Meat", "Human Dung", "Anything Dirty"], "cat" => "objects"],
    ["num" => 35, "terms" => ["Clothes", "Sheep", "Hole", "Big Grave"], "cat" => "objects"],
    ["num" => 36, "terms" => ["Shrimp", "Stick", "Admiral", "Gum"], "cat" => "objects"]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "<?php echo addslashes($pageTitle); ?>",
      "description": "<?php echo addslashes($metaDesc); ?>",
      "inLanguage": "en-ZA"
    }
    </script>
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $index => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $index + 1; ?>,
          "name": "<?php echo $crumb['name']; ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $index < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "How does the SA Fafi dream guide work?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "The Fafi dream guide translates common dream symbols (like snakes, water, or money) into specific numbers from 1 to 36. Players use these numbers to make predictions for Daily Lotto, Lotto, and PowerBall."
          }
        },
        {
          "@type": "Question",
          "name": "What is the Fafi number for a snake?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "In the traditional South African Fafi guide, dreaming of a snake translates to the number 32."
          }
        },
        {
          "@type": "Question",
          "name": "Can I use Fafi numbers for the National Lottery?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes! Because the Daily Lotto matrix goes up to 36, Fafi numbers fit perfectly. You can also mix them into your Lotto (1-52) and PowerBall (1-50) strategies."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <style>
        /* Layout */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* Typography & Headings */
        .page-title { font-size: 2.6rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; letter-spacing: -0.5px; }
        .page-intro { font-size: 1.15rem; color: #475569; line-height: 1.6; margin: 0 0 24px 0; }
        
        /* App UI: Dream Dictionary */
        .dictionary-app { background: #ffffff; border-radius: 16px; border: 1px solid #e2e8f0; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05); margin-bottom: 40px; overflow: hidden; position: relative; }
        .dictionary-app::before { content: ''; position: absolute; top: 0; left: 0; width: 100%; height: 6px; background: linear-gradient(90deg, #6366f1, #4338ca); }
        
        .app-header { padding: 32px 32px 24px 32px; background: #f8fafc; border-bottom: 1px solid #e2e8f0; }
        .search-box { position: relative; max-width: 600px; margin: 0 auto; }
        .search-input { width: 100%; padding: 18px 24px 18px 56px; border: 2px solid #cbd5e1; border-radius: 99px; font-size: 1.1rem; font-family: inherit; color: #0f172a; transition: all 0.2s ease; box-shadow: inset 0 2px 4px rgba(0,0,0,0.02); }
        .search-input:focus { border-color: #6366f1; outline: none; box-shadow: 0 0 0 4px rgba(99, 102, 241, 0.15); }
        .search-icon { position: absolute; left: 20px; top: 50%; transform: translateY(-50%); font-size: 1.3rem; }

        .category-filters { display: flex; flex-wrap: wrap; justify-content: center; gap: 10px; margin-top: 20px; }
        .filter-btn { background: #ffffff; border: 1px solid #cbd5e1; padding: 8px 16px; border-radius: 99px; font-size: 0.9rem; font-weight: 600; color: #475569; cursor: pointer; transition: all 0.2s ease; }
        .filter-btn:hover { border-color: #6366f1; color: #4338ca; }
        .filter-btn.active { background: #6366f1; color: #ffffff; border-color: #4338ca; }

        /* Grid Results */
        .fafi-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 16px; padding: 32px; background: #ffffff; max-height: 800px; overflow-y: auto; }
        .fafi-card { display: flex; align-items: center; background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px; transition: all 0.2s ease; }
        .fafi-card:hover { transform: translateY(-3px); box-shadow: 0 8px 15px -3px rgba(0,0,0,0.05); border-color: #a5b4fc; }
        
        .fafi-num { width: 56px; height: 56px; border-radius: 50%; background: linear-gradient(135deg, #6366f1, #4338ca); color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 1.6rem; font-weight: 800; flex-shrink: 0; box-shadow: 0 4px 6px rgba(99,102,241,0.3); margin-right: 16px; }
        .fafi-terms { font-size: 1rem; color: #1e293b; font-weight: 600; line-height: 1.4; }
        .fafi-terms span { color: #64748b; font-weight: 400; font-size: 0.9rem; display: block; margin-top: 4px; }
        
        .no-results { grid-column: 1 / -1; text-align: center; padding: 40px; color: #64748b; font-size: 1.1rem; font-weight: 500; display: none; }

        /* Action CTA Box inside Grid */
        .action-cta { grid-column: 1 / -1; background: linear-gradient(135deg, #1e293b, #0f172a); color: white; border-radius: 12px; padding: 24px; text-align: center; margin-top: 16px; display: flex; flex-direction: column; align-items: center; justify-content: center; }
        .action-cta h3 { margin: 0 0 12px 0; font-size: 1.4rem; color: #ffffff; }
        .action-cta p { color: #94a3b8; margin: 0 0 20px 0; font-size: 1rem; }
        .cta-btn-group { display: flex; gap: 12px; flex-wrap: wrap; justify-content: center; }
        .cta-btn { background: #6366f1; color: white; text-decoration: none; padding: 12px 24px; border-radius: 99px; font-weight: 700; font-size: 0.95rem; transition: all 0.2s ease; border: 1px solid transparent; }
        .cta-btn:hover { background: #4f46e5; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(99,102,241,0.4); }
        .cta-btn-outline { background: transparent; border-color: #475569; }
        .cta-btn-outline:hover { background: rgba(255,255,255,0.05); border-color: #94a3b8; box-shadow: none; }

        /* SEO & Text Blocks */
        .seo-section { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; }
        .seo-section h3 { font-size: 1.3rem; font-weight: 800; color: #1e293b; margin-top: 28px; margin-bottom: 12px; }
        .seo-section p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-section a { color: #4338ca; font-weight: 700; text-decoration: none; }
        .seo-section a:hover { text-decoration: underline; }
        .seo-section ul { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; padding-left: 20px; }
        .seo-section li { margin-bottom: 8px; }

        /* FAQ Section */
        .faq-section { margin-bottom: 48px; }
        .faq-section h2 { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-bottom: 12px; border-bottom: 2px solid #e2e8f0; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 12px; overflow: hidden; transition: all 0.2s ease; }
        .faq-item:hover { border-color: #cbd5e1; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #6366f1; font-size: 1.6rem; line-height: 1; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); color: #4338ca; }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* Sidebar */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover, .sidebar-links a.active { background: #f8fafc; color: #4338ca; border-left-color: #4338ca; font-weight: 800; }

        @media(max-width: 1024px) { .layout-with-sidebar { grid-template-columns: 1fr; } .lotto-sidebar { position: relative; top: 0; } }
        @media(max-width: 600px) { .fafi-grid { padding: 16px; } .fafi-card { padding: 12px; } .fafi-num { width: 48px; height: 48px; font-size: 1.3rem; margin-right: 12px; } }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <h1 class="page-title">SA Fafi Dream Guide – Translate Dreams Into Lucky Numbers</h1>
                <p class="page-intro">Turn your visions into winning predictions. Use our interactive South African dream dictionary below to find the traditional Fafi numbers for snakes, money, water, ancestors, and more.</p>

                <!-- Interactive App Container -->
                <div class="dictionary-app">
                    <div class="app-header">
                        <div class="search-box">
                            <span class="search-icon">🔍</span>
                            <input type="text" id="dreamSearch" class="search-input" placeholder="What did you dream about? (e.g., snake, water, baby)">
                        </div>
                        
                        <div class="category-filters">
                            <button class="filter-btn active" data-filter="all">All Meanings</button>
                            <button class="filter-btn" data-filter="animals">Animals</button>
                            <button class="filter-btn" data-filter="nature">Nature</button>
                            <button class="filter-btn" data-filter="people">People</button>
                            <button class="filter-btn" data-filter="wealth">Wealth & Money</button>
                            <button class="filter-btn" data-filter="death">Death & Spirits</button>
                        </div>
                    </div>

                    <div class="fafi-grid" id="fafiGrid">
                        <?php foreach($fafiData as $fafi): ?>
                            <div class="fafi-card" data-cat="<?php echo $fafi['cat']; ?>" data-terms="<?php echo strtolower(implode(' ', $fafi['terms'])); ?>">
                                <div class="fafi-num"><?php echo $fafi['num']; ?></div>
                                <div class="fafi-terms">
                                    <?php echo $fafi['terms'][0]; ?>
                                    <span>Also: <?php echo implode(', ', array_slice($fafi['terms'], 1)); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="no-results" id="noResults">
                            ❌ No Fafi numbers found for that dream. Try searching a different keyword.
                        </div>

                        <!-- Embedded CTA for Monetization/Engagement Loop -->
                        <div class="action-cta">
                            <h3>Got Your Lucky Numbers?</h3>
                            <p>Don't just dream it—play it! Use your Fafi numbers in the next draw.</p>
                            <div class="cta-btn-group">
                                <a href="/results/daily-lotto/" class="cta-btn">Check Daily Lotto</a>
                                <a href="/check-tickets/" class="cta-btn cta-btn-outline">Go to Ticket Checker Hub</a>
                            </div>
                        </div>
                    </div>
                </div>

                <section class="seo-section">
                    <h2>How the South African Dream Guide Works</h2>
                    <p>In South Africa, the Fafi dream guide (also known as Mo-China) has been used for decades to translate nocturnal visions and daily omens into playable lottery numbers. Originally tied to township betting games, these meanings are now widely used by players picking numbers for the National Lottery.</p>
                    <p>To use our tool, simply type the most prominent symbol from your dream into the search bar above. For example, if you search <strong>"dream about snake meaning number"</strong>, the guide will reveal the number 32.</p>

                    <h3>Applying Fafi Numbers to Lotto & PowerBall</h3>
                    <p>The traditional Fafi dictionary consists of numbers from 1 to 36. This makes it absolutely perfect for generating predictions for the <a href="/results/daily-lotto/">Daily Lotto</a>, which uses exactly a 36-ball matrix. If you are playing the <a href="/results/lotto/">Lotto</a> (52 balls) or <a href="/results/powerball/">PowerBall</a> (50 balls), you can combine multiple dream symbols from your week to build a complete ticket.</p>

                    <h3>Common Dream Number Meanings</h3>
                    <ul>
                        <li><strong>Fafi number for Water / Sea Water:</strong> Water generally translates to the number <strong>3</strong>. Small water or tears translate to <strong>29</strong>.</li>
                        <li><strong>Fafi number for Snake:</strong> A snake is strongly associated with the number <strong>32</strong> (which also signifies gold/money).</li>
                        <li><strong>Fafi number for Death / Dead Man:</strong> Dreaming of a deceased person generally points to the number <strong>4</strong>, while ghosts or spirits point to <strong>13</strong>.</li>
                        <li><strong>Fafi number for Pregnancy / Baby:</strong> A baby or childbirth translates to the number <strong>9</strong>.</li>
                    </ul>

                    <p style="margin-top: 24px; font-weight: 600; color: #4338ca;">
                        💡 Tip: After picking your numbers, use our <a href="/check-tickets/">Ticket Checker Tools</a> to instantly scan past draws and see if your dream combination has won recently!
                    </p>
                </section>

                <section class="faq-section">
                    <h2>Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <div class="faq-item">
                            <button class="faq-question">How does the SA Fafi dream guide work?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>The Fafi dream guide translates common dream symbols (like snakes, water, or money) into specific numbers from 1 to 36. Players use these numbers to make predictions for Daily Lotto, Lotto, and PowerBall.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">What is the Fafi number for a snake?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>In the traditional South African Fafi guide, dreaming of a snake translates to the number 32. This number is also associated with gold and wealth.</p></div></div>
                        </div>
                        <div class="faq-item">
                            <button class="faq-question">Can I use Fafi numbers for the National Lottery?<span class="faq-icon">+</span></button>
                            <div class="faq-answer"><div class="faq-answer-inner"><p>Yes! Because the Daily Lotto matrix goes up to 36, Fafi numbers fit perfectly. You can also mix them into your Lotto (1-52) and PowerBall (1-50) strategies by combining multiple dream symbols.</p></div></div>
                        </div>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/check-tickets/">Ticket Checker Hub</a></li>
                        <li><a href="/fafi-dream-guide/" class="active">Fafi Dream Guide</a></li>
                        <li><a href="/results/daily-lotto/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/lotto/hot-cold/">Hot & Cold Numbers</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            const searchInput = document.getElementById('dreamSearch');
            const filterBtns = document.querySelectorAll('.filter-btn');
            const cards = document.querySelectorAll('.fafi-card');
            const noResults = document.getElementById('noResults');

            let currentFilter = 'all';
            let currentSearch = '';

            function filterGrid() {
                let visibleCount = 0;

                cards.forEach(card => {
                    const terms = card.getAttribute('data-terms');
                    const cat = card.getAttribute('data-cat');
                    
                    const matchesSearch = terms.includes(currentSearch);
                    const matchesCat = (currentFilter === 'all') || (cat === currentFilter);

                    if (matchesSearch && matchesCat) {
                        card.style.display = 'flex';
                        visibleCount++;
                    } else {
                        card.style.display = 'none';
                    }
                });

                if (visibleCount === 0) {
                    noResults.style.display = 'block';
                } else {
                    noResults.style.display = 'none';
                }
            }

            // Real-time search
            searchInput.addEventListener('input', (e) => {
                currentSearch = e.target.value.toLowerCase().trim();
                filterGrid();
            });

            // Category buttons
            filterBtns.forEach(btn => {
                btn.addEventListener('click', (e) => {
                    // Update active state
                    filterBtns.forEach(b => b.classList.remove('active'));
                    e.target.classList.add('active');
                    
                    // Update filter and trigger
                    currentFilter = e.target.getAttribute('data-filter');
                    filterGrid();
                });
            });

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>