<?php
// Prevent timeouts for background execution
set_time_limit(120); 

// CRITICAL FIX: Set timezone to South Africa
date_default_timezone_set('Africa/Johannesburg');

// Connect to your database
require_once __DIR__ . '/db.php';

$apiKey = "5db296ba3e566384fcfae279c702e052"; 
$logFile = __DIR__ . '/cron_log.txt';
$logOutput = "\n========================================\n";
$logOutput .= "[" . date('Y-m-d H:i:s') . " SAST] Cron Execution Started\n";

// --- MIDNIGHT ROLLOVER SAFETY FIX ---
// If running early in the morning, look for yesterday's results
$currentHour = (int)date('H');
if ($currentHour >= 0 && $currentHour <= 10) {
    $targetDate = date('Y-m-d', strtotime('-1 day'));
    $logOutput .= "Early morning run. Fetching results for yesterday: {$targetDate}\n";
} else {
    $targetDate = date('Y-m-d');
    $logOutput .= "Fetching results for today: {$targetDate}\n";
}

$apiUrl = "https://resultsZA.co.za/api/get_latest_results?api_key={$apiKey}&date={$targetDate}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
curl_setopt($ch, CURLOPT_TIMEOUT, 30); 
curl_setopt($ch, CURLOPT_USERAGENT, 'LottoGenius-Auto-Cron');
$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200 && $response) {
    $apiData = json_decode($response, true);
    
    if (isset($apiData['status']) && $apiData['status'] === 'success') {
        
        // ==========================================
        // 1. DAILY LOTTO
        // ==========================================
        $game = $apiData['results']['daily_lotto_results'] ?? null;
        if ($game && !empty($game['winning_numbers'])) {
            $stmt = $pdo->prepare("INSERT IGNORE INTO daily_lotto_results (
                draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
                ball_1, ball_2, ball_3, ball_4, ball_5,
                div1_winners, div1_amount, div2_winners, div2_amount, div3_winners, div3_amount, div4_winners, div4_amount
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            $stmt->execute([
                $game['date'], $game['draw_id']??null, $game['draw_machine']??null, $game['total_pool_size']??0, $game['total_sales']??0, 0,
                $game['winning_numbers'][0]??null, $game['winning_numbers'][1]??null, $game['winning_numbers'][2]??null, $game['winning_numbers'][3]??null, $game['winning_numbers'][4]??null,
                $game['divisions'][0]['winners']??0, $game['divisions'][0]['winning_amount']??0,
                $game['divisions'][1]['winners']??0, $game['divisions'][1]['winning_amount']??0,
                $game['divisions'][2]['winners']??0, $game['divisions'][2]['winning_amount']??0,
                $game['divisions'][3]['winners']??0, $game['divisions'][3]['winning_amount']??0
            ]);
            $logOutput .= "Daily Lotto: " . ($stmt->rowCount() > 0 ? "Inserted Successfully\n" : "Skipped (Already Exists)\n");
        } else {
            $logOutput .= "Daily Lotto: No data available yet.\n";
        }

        // ==========================================
        // Helper for Lotto/PowerBall structures
        // ==========================================
        if (!function_exists('processStandardGame')) {
            function processStandardGame($pdo, $gameData, $tableName, $isPowerBall) {
                $balls = $gameData['winning_numbers'];
                $bonus = $gameData['powerball'] ?? $gameData['bonus_ball'] ?? ($balls[5] ?? null);
                $divs = $gameData['divisions'] ?? [];
                
                if ($isPowerBall) {
                    $stmt = $pdo->prepare("INSERT IGNORE INTO $tableName (
                        draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
                        ball_1, ball_2, ball_3, ball_4, ball_5, powerball,
                        div1_winners, div1_amount, div2_winners, div2_amount, div3_winners, div3_amount, div4_winners, div4_amount,
                        div5_winners, div5_amount, div6_winners, div6_amount, div7_winners, div7_amount, div8_winners, div8_amount, div9_winners, div9_amount
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    $stmt->execute([
                        $gameData['date'], $gameData['draw_id']??null, $gameData['draw_machine']??null, $gameData['total_pool_size']??0, $gameData['total_sales']??0, $gameData['rollover_number']??0,
                        $balls[0]??null, $balls[1]??null, $balls[2]??null, $balls[3]??null, $balls[4]??null, $bonus,
                        $divs[0]['winners']??0, $divs[0]['winning_amount']??0, $divs[1]['winners']??0, $divs[1]['winning_amount']??0,
                        $divs[2]['winners']??0, $divs[2]['winning_amount']??0, $divs[3]['winners']??0, $divs[3]['winning_amount']??0,
                        $divs[4]['winners']??0, $divs[4]['winning_amount']??0, $divs[5]['winners']??0, $divs[5]['winning_amount']??0,
                        $divs[6]['winners']??0, $divs[6]['winning_amount']??0, $divs[7]['winners']??0, $divs[7]['winning_amount']??0,
                        $divs[8]['winners']??0, $divs[8]['winning_amount']??0
                    ]);
                } else {
                    $stmt = $pdo->prepare("INSERT IGNORE INTO $tableName (
                        draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
                        ball_1, ball_2, ball_3, ball_4, ball_5, ball_6, bonus_ball,
                        div1_winners, div1_amount, div2_winners, div2_amount, div3_winners, div3_amount, div4_winners, div4_amount,
                        div5_winners, div5_amount, div6_winners, div6_amount, div7_winners, div7_amount, div8_winners, div8_amount
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    $stmt->execute([
                        $gameData['date'], $gameData['draw_id']??null, $gameData['draw_machine']??null, $gameData['total_pool_size']??0, $gameData['total_sales']??0, $gameData['rollover_number']??0,
                        $balls[0]??null, $balls[1]??null, $balls[2]??null, $balls[3]??null, $balls[4]??null, $balls[5]??null, $bonus,
                        $divs[0]['winners']??0, $divs[0]['winning_amount']??0, $divs[1]['winners']??0, $divs[1]['winning_amount']??0,
                        $divs[2]['winners']??0, $divs[2]['winning_amount']??0, $divs[3]['winners']??0, $divs[3]['winning_amount']??0,
                        $divs[4]['winners']??0, $divs[4]['winning_amount']??0, $divs[5]['winners']??0, $divs[5]['winning_amount']??0,
                        $divs[6]['winners']??0, $divs[6]['winning_amount']??0, $divs[7]['winners']??0, $divs[7]['winning_amount']??0
                    ]);
                }
                return $stmt->rowCount();
            }
        }

        // ==========================================
        // 2. RUN LOTTO GAMES
        // ==========================================
        $lottoData = $apiData['results']['lotto_results'] ?? null;
        if ($lottoData && !empty($lottoData['winning_numbers'])) {
            $rows = processStandardGame($pdo, $lottoData, 'lotto_results', false);
            $logOutput .= "Lotto: " . ($rows > 0 ? "Inserted Successfully\n" : "Skipped\n");
        } else { $logOutput .= "Lotto: No data.\n"; }

        $lottoP1Data = $apiData['results']['lotto_plus_1_results'] ?? $apiData['results']['lotto_plus_results'] ?? null;
        if ($lottoP1Data && !empty($lottoP1Data['winning_numbers'])) {
            $rows = processStandardGame($pdo, $lottoP1Data, 'lotto_plus_1_results', false);
            $logOutput .= "Lotto Plus 1: " . ($rows > 0 ? "Inserted Successfully\n" : "Skipped\n");
        } else { $logOutput .= "Lotto Plus 1: No data.\n"; }

        $lottoP2Data = $apiData['results']['lotto_plus_2_results'] ?? null;
        if ($lottoP2Data && !empty($lottoP2Data['winning_numbers'])) {
            $rows = processStandardGame($pdo, $lottoP2Data, 'lotto_plus_2_results', false);
            $logOutput .= "Lotto Plus 2: " . ($rows > 0 ? "Inserted Successfully\n" : "Skipped\n");
        } else { $logOutput .= "Lotto Plus 2: No data.\n"; }

        // ==========================================
        // 3. RUN POWERBALL GAMES
        // ==========================================
        $pbData = $apiData['results']['powerball_results'] ?? null;
        if ($pbData && !empty($pbData['winning_numbers'])) {
            $rows = processStandardGame($pdo, $pbData, 'powerball_results', true);
            $logOutput .= "PowerBall: " . ($rows > 0 ? "Inserted Successfully\n" : "Skipped\n");
        } else { $logOutput .= "PowerBall: No data.\n"; }

        $pbPlusData = $apiData['results']['powerball_plus_results'] ?? null;
        if ($pbPlusData && !empty($pbPlusData['winning_numbers'])) {
            $rows = processStandardGame($pdo, $pbPlusData, 'powerball_plus_results', true);
            $logOutput .= "PowerBall Plus: " . ($rows > 0 ? "Inserted Successfully\n" : "Skipped\n");
        } else { $logOutput .= "PowerBall Plus: No data.\n"; }

    } else {
        $logOutput .= "Error: API returned status 'error'.\n";
        $logOutput .= "API Message: " . ($apiData['message'] ?? 'Unknown Error') . "\n";
    }
} else {
    $logOutput .= "Error: API connection failed. HTTP Code: $httpCode\n";
    $logOutput .= "Full API Response Body: " . ($response ? htmlspecialchars($response) : "NULL") . "\n";
}

$logOutput .= "Auto-Update Finished.\n========================================\n";

// Save to log
file_put_contents($logFile, $logOutput, FILE_APPEND);

// Output to browser for instant check
echo nl2br($logOutput);
?>