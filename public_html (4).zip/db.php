<?php
$host = 'localhost'; 
$db   = 'u990828483_Lotto';

// IMPORTANT: Check Hostinger for the exact username. It MUST have the prefix.
$user = 'u990828483_Lotto'; 
$pass = 'Pass@20223!@#'; 
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // This will now print the EXACT reason it is failing so you can fix it
    die("Database Connection Failed. Reason: " . $e->getMessage());
}
?>