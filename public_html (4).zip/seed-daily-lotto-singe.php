<?php
// Turn on errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

set_time_limit(30); 

// Connect to your database
require_once __DIR__ . '/db.php';

$apiKey = "5db296ba3e566384fcfae279c702e052"; // <-- Add your real key
$tableName = "daily_lotto_results"; 

// Determine the date to process
$targetDate = isset($_REQUEST['date']) ? $_REQUEST['date'] : date('Y-m-d');
$dayOfWeek = date('l', strtotime($targetDate));

// Check if the user clicked the "Insert" button
$isInsertMode = (isset($_POST['action']) && $_POST['action'] === 'insert');

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Daily Lotto Importer</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 20px; background: #f1f5f9; color: #334155; }
        .box { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; color: white; text-decoration: none; display: inline-block; }
        .btn-blue { background: #3b82f6; }
        .btn-blue:hover { background: #2563eb; }
        .btn-green { background: #22c55e; font-size: 1.1rem; padding: 12px 24px; }
        .btn-green:hover { background: #16a34a; }
        .btn-gray { background: #64748b; }
        .ball { display: inline-block; width: 40px; height: 40px; line-height: 40px; text-align: center; background: #e2e8f0; border-radius: 50%; font-weight: bold; margin-right: 8px; font-size: 18px;}
        .success-msg { background: #dcfce7; color: #166534; padding: 16px; border-radius: 6px; border: 1px solid #bbf7d0; font-weight: bold; }
        .warning-msg { background: #fef08a; color: #854d0e; padding: 16px; border-radius: 6px; border: 1px solid #fde047; }
    </style>
</head>
<body>

<div class="box">
    <form method="GET" action="">
        <label for="date" style="font-weight: bold; margin-right: 10px; font-size: 1.1rem;">1. Select Draw Date:</label>
        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($targetDate); ?>" max="<?php echo date('Y-m-d'); ?>" style="padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 1rem;">
        <button type="submit" class="btn btn-blue" style="margin-left: 10px;">Fetch Preview</button>
    </form>
</div>

<?php
// Only fetch from API if a date was explicitly submitted via GET, or if we are inserting
if (isset($_GET['date']) || $isInsertMode) {
    
    echo "<div class='box'>";
    echo "<h2>" . ($isInsertMode ? "Database Insert Status" : "Preview for: $targetDate ($dayOfWeek)") . "</h2>";

    $apiUrl = "https://resultsZA.co.za/api/get_latest_results?api_key={$apiKey}&date={$targetDate}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)');
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $apiData = json_decode($response, true);
        
        if (isset($apiData['status']) && $apiData['status'] === 'success' && isset($apiData['results']['daily_lotto_results'])) {
            
            $gameData = $apiData['results']['daily_lotto_results'];
            $actualDrawDate = date('Y-m-d', strtotime($gameData['date']));
            
            if ($actualDrawDate === $targetDate && !empty($gameData['winning_numbers'])) {
                
                $balls = $gameData['winning_numbers'];
                
                // Show Preview
                echo "<p><strong>Winning Numbers Found:</strong></p>";
                echo "<div>";
                foreach ($balls as $b) {
                    echo "<span class='ball'>$b</span>";
                }
                echo "</div><br>";

                if ($isInsertMode) {
                    // --- STEP 2: ACTUALLY INSERT DATA ---
                    $drawId = $gameData['draw_id'] ?? null;
                    $machine = $gameData['draw_machine'] ?? null;
                    $poolSize = $gameData['total_pool_size'] ?? 0;
                    $sales = $gameData['total_sales'] ?? 0;
                    $rollover = 0; 
                    $divs = $gameData['divisions'] ?? [];
                    
                    $stmt = $pdo->prepare("INSERT IGNORE INTO $tableName (
                        draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
                        ball_1, ball_2, ball_3, ball_4, ball_5,
                        div1_winners, div1_amount, div2_winners, div2_amount, 
                        div3_winners, div3_amount, div4_winners, div4_amount
                    ) VALUES (
                        ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?
                    )");
                    
                    $success = $stmt->execute([
                        $actualDrawDate, $drawId, $machine, $poolSize, $sales, $rollover,
                        $balls[0]??null, $balls[1]??null, $balls[2]??null, $balls[3]??null, $balls[4]??null,
                        $divs[0]['winners']??0, $divs[0]['winning_amount']??0, 
                        $divs[1]['winners']??0, $divs[1]['winning_amount']??0,
                        $divs[2]['winners']??0, $divs[2]['winning_amount']??0, 
                        $divs[3]['winners']??0, $divs[3]['winning_amount']??0
                    ]);
                    
                    if ($success) {
                        echo "<div class='success-msg'>✅ Successfully inserted $actualDrawDate into the database!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Database insert failed. It might already exist.</div>";
                    }

                } else {
                    // --- STEP 1: SHOW CONFIRMATION BUTTON ---
                    echo "<p style='color: #64748b;'>Data retrieved successfully. Click the button below to save it.</p>";
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert'>";
                    echo "<button type='submit' class='btn btn-green'>2. Confirm & Save to Database</button>";
                    echo "</form>";
                }

            } else {
                echo "<div class='warning-msg'>The API returned a different date ($actualDrawDate) or the draw results are not out yet for $targetDate.</div>";
            }
        } else {
            echo "<div class='warning-msg'>Missing 'daily_lotto_results' in the API response.</div>";
        }
    } else {
        echo "<div class='warning-msg'>API Request Failed. HTTP Code: $httpCode</div>";
    }
    
    echo "</div>"; // End box
}
?>

<div style='margin-top: 20px; display: flex; gap: 16px;'>
    <?php 
    $prevDay = date('Y-m-d', strtotime("-1 day", strtotime($targetDate)));
    $nextDay = date('Y-m-d', strtotime("+1 day", strtotime($targetDate)));
    ?>
    <a href='?date=<?php echo $prevDay; ?>' class='btn btn-gray'>&larr; Check <?php echo $prevDay; ?></a>
    <?php if (strtotime($nextDay) <= strtotime(date('Y-m-d'))): ?>
        <a href='?date=<?php echo $nextDay; ?>' class='btn btn-gray'>Check <?php echo $nextDay; ?> &rarr;</a>
    <?php endif; ?>
</div>

</body>
</html>