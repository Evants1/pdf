<?php
$pageTitle = "About Us | Next Draw Logic - SA's Trusted Lotto Hub";
$metaDesc = "Learn more about Next Draw Logic. We provide fast, accurate, and free South African National Lottery results, ticket checkers, and data-driven predictions.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Structured Data for SEO Trust -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "AboutPage",
      "mainEntity": {
        "@type": "Organization",
        "name": "Next Draw Logic",
        "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>",
        "description": "An independent South African portal providing lottery results, historical data analysis, and ticket checking tools."
      }
    }
    </script>

    <style>
        /* Modern Legal Page Container */
        .legal-wrapper {
            padding: 60px 20px;
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .legal-container { 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 50px 60px; 
            background: #ffffff; 
            border-radius: 24px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0; 
            line-height: 1.8; 
            color: #475569; 
            font-size: 1.05rem;
        }

        /* Modern Typography & Header */
        .page-header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
        }

        .legal-container h1 { 
            font-size: 2.8rem; 
            color: #0f172a; 
            margin: 0 0 16px 0; 
            font-weight: 800; 
            letter-spacing: -0.03em;
        }

        .tagline {
            display: inline-block;
            background: #e0e7ff;
            color: var(--primary, #4f46e5);
            padding: 8px 20px;
            border-radius: 99px;
            font-size: 1rem;
            font-weight: 700;
        }

        .legal-container h2 { 
            font-size: 1.5rem; 
            color: #0f172a; 
            margin: 40px 0 20px 0; 
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .legal-container h2::before {
            content: '';
            display: block;
            width: 24px;
            height: 4px;
            background: var(--primary, #4f46e5);
            border-radius: 4px;
        }

        .legal-container p {
            margin-bottom: 20px;
        }

        /* Feature Grid UI */
        .feature-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 32px 0;
        }

        .feature-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 24px;
            border-radius: 16px;
            transition: all 0.2s ease;
        }

        .feature-card:hover {
            border-color: var(--primary, #4f46e5);
            box-shadow: 0 10px 25px -5px rgba(79, 70, 229, 0.1);
            transform: translateY(-4px);
        }

        .feature-icon {
            font-size: 2rem;
            margin-bottom: 12px;
            display: block;
        }

        .feature-card h3 {
            margin: 0 0 8px 0;
            color: #0f172a;
            font-size: 1.15rem;
            font-weight: 800;
        }

        .feature-card p {
            margin: 0;
            font-size: 0.95rem;
            line-height: 1.6;
        }

        /* Trust & Disclaimer Block UI */
        .trust-block { 
            background: linear-gradient(to right, #f0fdf4, #ffffff); 
            padding: 24px 28px; 
            border-left: 4px solid #10b981; 
            border-radius: 0 12px 12px 0; 
            margin: 40px 0; 
            color: #064e3b; 
            font-size: 1.05rem; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
        }
        
        .trust-block strong { color: #047857; display: block; margin-bottom: 8px; font-size: 1.15rem; }

        /* Modern Links */
        .legal-container a { 
            color: var(--primary, #4f46e5); 
            text-decoration: none; 
            font-weight: 600; 
            position: relative;
        }
        
        .legal-container a:hover { text-decoration: underline; }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .legal-wrapper { padding: 20px 10px; }
            .legal-container { padding: 30px 20px; border-radius: 16px; }
            .legal-container h1 { font-size: 2.2rem; }
            .legal-container h2 { font-size: 1.25rem; }
            .feature-grid { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../static/nav.php'; ?>

    <div class="legal-wrapper">
        <main class="legal-container">
            
            <header class="page-header">
                <h1>About Next Draw Logic</h1>
                <span class="tagline">Data-Driven Lottery Insights for South Africa</span>
            </header>
            
            <p>Welcome to <strong>Next Draw Logic</strong>. We are a dedicated team of data enthusiasts and developers committed to building South Africa's most reliable, independent portal for National Lottery results, smart ticket checking, and historical draw analysis.</p>

            <h2>The Problem We Solve</h2>
            <p>We started Next Draw Logic because we noticed a gap in the South African market. Checking old, forgotten lottery tickets against months of draw data was tedious, confusing, and prone to human error. Players needed a faster, smarter way to verify their numbers.</p>
            <p>That frustration led us to build our proprietary <strong>100-Draw Ticket Scanner</strong>—a tool that allows you to instantly cross-reference your numbers against months of historical data with a single click.</p>

            <h2>Our Core Features</h2>
            <div class="feature-grid">
                <div class="feature-card">
                    <span class="feature-icon">⚡</span>
                    <h3>Instant Verification</h3>
                    <p>Stop scrolling through endless lists. Our ticket scanners instantly check your numbers against the latest results for Lotto, PowerBall, and Daily Lotto.</p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">📊</span>
                    <h3>Historical Data</h3>
                    <p>We maintain deep archives of past draws, allowing you to track hot and cold numbers and analyze statistical trends over time.</p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">🧠</span>
                    <h3>Smart Predictions</h3>
                    <p>Using algorithms that track frequency and probability, we generate data-driven number predictions for upcoming draws.</p>
                </div>
                <div class="feature-card">
                    <span class="feature-icon">🐘</span>
                    <h3>Fafi Dream Guide</h3>
                    <p>We honor South African tradition with our interactive Fafi/Mo-China dream dictionary, helping you translate dreams into lucky numbers.</p>
                </div>
            </div>

            <h2>Our Commitment to Free Access</h2>
            <p>We believe that accessing public lottery data and utility tools should never cost you money. Every tool on Next Draw Logic—from our predictions to our historical archives—is <strong>100% free to use</strong>. To keep our servers running and our tools free, our platform is supported by carefully selected advertisements and affiliate partnerships.</p>

            <h2>Accuracy & Data Integrity</h2>
            <p>When it comes to lottery results, accuracy is everything. Our automated systems independently aggregate and verify data following the official South African National Lottery (Ithuba) draws. While we hold our technology to the highest standards, we always advise players to double-check winning tickets with an official retailer.</p>

            <div class="trust-block">
                <strong>🛡️ 100% Independent</strong>
                Next Draw Logic is purely an informational platform. We do not sell lottery tickets, and we are not affiliated with, endorsed by, or sponsored by the official South African National Lottery or Ithuba Holdings. 
            </div>

            <h2>Get in Touch</h2>
            <p>We are constantly improving our tools based on user feedback. If you have a feature request, noticed a bug, or simply want to say hello, please visit our <a href="/contact-us/">Contact Us</a> page.</p>

        </main>
    </div>

    <?php include __DIR__ . '/../static/footer.php'; ?>
</body>
</html>