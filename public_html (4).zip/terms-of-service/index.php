<?php
$pageTitle = "Terms of Service & Conditions | Next Draw Logic South Africa";
$metaDesc = "Read the official Terms of Service for Next Draw Logic. Understand our disclaimers, liability limitations, and rules for using our lotto tools and predictions.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Structured Data for SEO Trust -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "Terms of Service",
      "description": "Terms and conditions for using Next Draw Logic, including disclaimers regarding lottery results and predictions.",
      "publisher": {
        "@type": "Organization",
        "name": "Next Draw Logic"
      }
    }
    </script>

    <style>
        /* Modern Legal Page Container */
        .legal-wrapper {
            padding: 60px 20px;
            background-color: #f8fafc;
            min-height: 100vh;
        }

        .legal-container { 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 50px 60px; 
            background: #ffffff; 
            border-radius: 24px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0; 
            line-height: 1.8; 
            color: #475569; 
            font-size: 1.05rem;
        }

        /* Modern Typography & Header */
        .page-header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
        }

        .legal-container h1 { 
            font-size: 2.8rem; 
            color: #0f172a; 
            margin: 0 0 16px 0; 
            font-weight: 800; 
            letter-spacing: -0.03em;
        }

        .last-updated {
            display: inline-block;
            background: #f1f5f9;
            color: #64748b;
            padding: 6px 16px;
            border-radius: 99px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .legal-container h2 { 
            font-size: 1.4rem; 
            color: #0f172a; 
            margin: 40px 0 16px 0; 
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Accent dash before H2 tags */
        .legal-container h2::before {
            content: '';
            display: block;
            width: 24px;
            height: 4px;
            background: var(--primary, #4f46e5);
            border-radius: 4px;
        }

        .legal-container p {
            margin-bottom: 20px;
        }

        /* Modern Links */
        .legal-container a { 
            color: var(--primary, #4f46e5); 
            text-decoration: none; 
            font-weight: 600; 
            position: relative;
        }
        
        .legal-container a::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -2px;
            left: 0;
            background-color: var(--primary, #4f46e5);
            visibility: hidden;
            transform: scaleX(0);
            transition: all 0.2s ease-in-out;
        }

        .legal-container a:hover::after {
            visibility: visible;
            transform: scaleX(1);
        }

        /* Trust & Disclaimer Block UI */
        .trust-block { 
            background: linear-gradient(to right, #fffbeb, #ffffff); 
            padding: 24px 28px; 
            border-left: 4px solid #f59e0b; 
            border-radius: 0 12px 12px 0; 
            margin: 32px 0; 
            color: #78350f; 
            font-size: 1.05rem; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
        }
        
        .trust-block strong { color: #b45309; display: block; margin-bottom: 8px; font-size: 1.15rem; }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .legal-wrapper { padding: 20px 10px; }
            .legal-container { padding: 30px 20px; border-radius: 16px; }
            .legal-container h1 { font-size: 2.2rem; }
            .legal-container h2 { font-size: 1.25rem; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../static/nav.php'; ?>

    <div class="legal-wrapper">
        <main class="legal-container">
            
            <header class="page-header">
                <h1>Terms & Conditions</h1>
                <span class="last-updated">Updated: <?php echo date("F Y"); ?></span>
            </header>
            
            <p>Welcome to Next Draw Logic (accessible at <a href="/">nextdrawlogic.co.za</a>). By accessing or using this website, you agree to be bound by these Terms of Service. If you disagree with any part of these terms, you must discontinue use of our website and services immediately.</p>

            <div class="trust-block">
                <strong>⚠️ Legal Disclaimer</strong>
                Next Draw Logic is an independent, informational platform. <strong>We are NOT a gambling operator</strong>, and we are not affiliated with, endorsed by, or officially connected to the South African National Lottery or Ithuba Holdings. We do not sell lottery tickets or process prize claims.
            </div>

            <h2>1. Informational Purposes Only</h2>
            <p>All content provided on Next Draw Logic—including lottery results, ticket checkers, Fafi dream guides, hot and cold statistics, and algorithmic predictions—is intended for <strong>entertainment and informational purposes only</strong>.</p>
            <p>While we strive for 100% accuracy by cross-referencing our data with official feeds, technical errors or delays can occur. You should always verify your lottery tickets at an official National Lottery retailer or via the official Ithuba platform before discarding them.</p>

            <h2>2. Limitation of Liability</h2>
            <p>Under no circumstances shall Next Draw Logic, its owners, developers, or affiliates be held liable for any direct, indirect, incidental, consequential, or punitive damages arising out of your access to or use of this website. This includes, but is not limited to, financial loss resulting from relying on inaccurate published results, failed predictions, or errors in our ticket checking software.</p>

            <h2>3. Age Restrictions</h2>
            <p>In accordance with South African law, playing the National Lottery is strictly restricted to individuals who are <strong>18 years of age or older</strong>. By using this website, you warrant that you meet this age requirement. We do not intentionally market our content or services to minors.</p>

            <h2>4. Predictions and Statistical Data</h2>
            <p>Any "Smart Predictions," "Hot and Cold Numbers," or algorithmic forecasts provided on this site are based entirely on historical statistical analysis and mathematical probability. <strong>Lottery draws are entirely random events.</strong> Past performance is not an indicator of future results. We make absolutely no guarantees that using our predictions or Fafi guides will result in a winning ticket. Users play the lottery entirely at their own risk.</p>

            <h2>5. External Links and Third Parties</h2>
            <p>Our website may contain links to external third-party websites, including sports betting platforms, affiliate partners, and the official National Lottery website. We have no control over the content, privacy policies, or practices of any third-party sites. Clicking on these links is done at your own discretion, and we bear no responsibility for any losses or damages incurred on external platforms.</p>

            <h2>6. User Conduct and Acceptable Use</h2>
            <p>By accessing Next Draw Logic, you agree NOT to:</p>
            <ul>
                <li>Use automated scripts, bots, or scrapers to extract data, lottery results, or predictions from our site.</li>
                <li>Attempt to bypass our security measures, execute DDOS attacks, or overwhelm our servers.</li>
                <li>Reproduce, duplicate, copy, or resell any part of our website's content without express written permission.</li>
            </ul>
            <p>We reserve the right to block access to users or IP addresses that violate these rules.</p>

            <h2>7. Intellectual Property</h2>
            <p>The original content, features, proprietary ticket-checking algorithms, and UI design of Next Draw Logic are the exclusive property of Next Draw Logic and are protected by international copyright and intellectual property laws. Official lottery logos and brand names remain the property of their respective owners (Ithuba Holdings) and are used here purely for nominative/identification purposes.</p>

            <h2>8. Governing Law</h2>
            <p>These Terms shall be governed and construed in accordance with the laws of the <strong>Republic of South Africa</strong>, without regard to its conflict of law provisions. Any dispute arising from these terms will be subject to the exclusive jurisdiction of the courts of South Africa.</p>

            <h2>9. Changes to Terms</h2>
            <p>We reserve the right to modify or replace these Terms at any time at our sole discretion. We will indicate the date of the latest revision at the top of this page. Your continued use of the website following any changes constitutes acceptance of those changes.</p>

            <h2>10. Contact Us</h2>
            <p>If you have any questions regarding these Terms of Service or need legal clarification, please contact us via our <a href="/contact-us/">Contact Us page</a> or email us directly at <strong>support@nextdrawlogic.co.za</strong>.</p>

        </main>
    </div>

    <?php include __DIR__ . '/../static/footer.php'; ?>
</body>
</html>