<?php
// Turn on errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

set_time_limit(30); 

// Connect to your database
require_once __DIR__ . '/db.php';

// Force PDO to throw exceptions so we can see EXACTLY why an insert fails
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$apiKey = "5db296ba3e566384fcfae279c702e052"; // <-- Add your real key

// Determine the date to process
$targetDate = isset($_REQUEST['date']) ? $_REQUEST['date'] : date('Y-m-d');
$dayOfWeek = date('l', strtotime($targetDate));

// Check if the user clicked an "Insert" button
$action = isset($_POST['action']) ? $_POST['action'] : '';

// Helper function to insert a single row for PowerBall games
function insertPowerBallRow($pdo, $tableName, $gameData, $targetDate) {
    try {
        $actualDrawDate = date('Y-m-d', strtotime($gameData['date']));
        $drawId = $gameData['draw_id'] ?? null;
        $machine = $gameData['draw_machine'] ?? null; 
        $poolSize = $gameData['total_pool_size'] ?? 0;
        $sales = $gameData['total_sales'] ?? 0;
        $rollover = $gameData['rollover_number'] ?? 0;
        
        $balls = $gameData['winning_numbers'];
        $divs = $gameData['divisions'] ?? [];
        
        // --- BULLETPROOF POWERBALL CATCHER ---
        // APIs format this differently. We check all 3 possible locations to guarantee we get the number.
        $powerball = null;
        if (isset($gameData['powerball']) && $gameData['powerball'] !== '') {
            $powerball = $gameData['powerball'];
        } elseif (isset($gameData['bonus_ball']) && $gameData['bonus_ball'] !== '') {
            $powerball = $gameData['bonus_ball'];
        } elseif (is_array($balls) && count($balls) >= 6) {
            // Sometimes they just append it as the 6th ball in the array
            $powerball = $balls[5]; 
        }
        
        $stmt = $pdo->prepare("INSERT IGNORE INTO $tableName (
            draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
            ball_1, ball_2, ball_3, ball_4, ball_5, powerball,
            div1_winners, div1_amount, div2_winners, div2_amount, 
            div3_winners, div3_amount, div4_winners, div4_amount,
            div5_winners, div5_amount, div6_winners, div6_amount,
            div7_winners, div7_amount, div8_winners, div8_amount,
            div9_winners, div9_amount
        ) VALUES (
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?
        )");
        
        $success = $stmt->execute([
            $actualDrawDate, $drawId, $machine, $poolSize, $sales, $rollover,
            $balls[0]??null, $balls[1]??null, $balls[2]??null, $balls[3]??null, $balls[4]??null, $powerball,
            $divs[0]['winners']??0, $divs[0]['winning_amount']??0, 
            $divs[1]['winners']??0, $divs[1]['winning_amount']??0,
            $divs[2]['winners']??0, $divs[2]['winning_amount']??0, 
            $divs[3]['winners']??0, $divs[3]['winning_amount']??0,
            $divs[4]['winners']??0, $divs[4]['winning_amount']??0, 
            $divs[5]['winners']??0, $divs[5]['winning_amount']??0,
            $divs[6]['winners']??0, $divs[6]['winning_amount']??0, 
            $divs[7]['winners']??0, $divs[7]['winning_amount']??0,
            $divs[8]['winners']??0, $divs[8]['winning_amount']??0
        ]);
        
        return ['success' => $success, 'rows_affected' => $stmt->rowCount(), 'error' => null];
        
    } catch (PDOException $e) {
        return ['success' => false, 'rows_affected' => 0, 'error' => $e->getMessage()];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PowerBall Single Row Importer</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 20px; background: #f8fafc; color: #334155; }
        .box { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; color: white; text-decoration: none; display: inline-block; }
        .btn-blue { background: #3b82f6; }
        .btn-blue:hover { background: #2563eb; }
        .btn-green { background: #22c55e; font-size: 1rem; padding: 10px 20px; margin-top: 15px;}
        .btn-green:hover { background: #16a34a; }
        .btn-gray { background: #64748b; }
        .ball { display: inline-block; width: 40px; height: 40px; line-height: 40px; text-align: center; background: #e2e8f0; border-radius: 50%; font-weight: bold; margin-right: 8px; font-size: 16px;}
        .powerball-ball { background: #ef4444; color: white; border: 2px solid #b91c1c; }
        .success-msg { background: #dcfce7; color: #166534; padding: 12px; border-radius: 6px; border: 1px solid #bbf7d0; font-weight: bold; margin-top: 15px;}
        .warning-msg { background: #fef08a; color: #854d0e; padding: 12px; border-radius: 6px; border: 1px solid #fde047; margin-top: 15px;}
        .error-msg { background: #fee2e2; color: #991b1b; padding: 12px; border-radius: 6px; border: 1px solid #f87171; font-weight: bold; margin-top: 15px;}
        .game-card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 20px; background: #fdfdfd; }
    </style>
</head>
<body>

<div class="box">
    <form method="GET" action="">
        <label for="date" style="font-weight: bold; margin-right: 10px; font-size: 1.1rem;">1. Select Draw Date (Tue/Fri):</label>
        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($targetDate); ?>" max="<?php echo date('Y-m-d'); ?>" style="padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 1rem;">
        <button type="submit" class="btn btn-blue" style="margin-left: 10px;">Fetch Preview</button>
    </form>
</div>

<?php
if (isset($_GET['date']) || !empty($action)) {
    
    echo "<div class='box'>";
    echo "<h2>Preview for: $targetDate ($dayOfWeek)</h2>";

    $apiUrl = "https://resultsZA.co.za/api/get_latest_results?api_key={$apiKey}&date={$targetDate}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $apiData = json_decode($response, true);
        
        if (isset($apiData['status']) && $apiData['status'] === 'success') {
            
            // ==========================================
            // 1. MAIN POWERBALL SECTION
            // ==========================================
            echo "<div class='game-card'>";
            echo "<h3 style='margin-top: 0; color: #1e293b;'>Main PowerBall</h3>";
            
            $pbData = $apiData['results']['powerball_results'] ?? null;
            
            if ($pbData && date('Y-m-d', strtotime($pbData['date'])) === $targetDate && !empty($pbData['winning_numbers'])) {
                
                $balls = $pbData['winning_numbers'];
                
                // Extraction purely for preview display
                $displayPowerball = $pbData['powerball'] ?? $pbData['bonus_ball'] ?? (isset($balls[5]) ? $balls[5] : null);
                
                echo "<div>";
                // Show first 5 balls
                for ($i = 0; $i < min(5, count($balls)); $i++) {
                    echo "<span class='ball'>" . htmlspecialchars($balls[$i]) . "</span>";
                }
                // Show PowerBall
                if ($displayPowerball !== null) { 
                    echo "<span class='ball powerball-ball'>" . htmlspecialchars($displayPowerball) . "</span>"; 
                }
                echo "</div>";

                if ($action === 'insert_pb') {
                    $result = insertPowerBallRow($pdo, 'powerball_results', $pbData, $targetDate);
                    
                    if (!empty($result['error'])) {
                        echo "<div class='error-msg'>❌ DATABASE ERROR: " . htmlspecialchars($result['error']) . "</div>";
                    } elseif ($result['success'] && $result['rows_affected'] > 0) {
                        echo "<div class='success-msg'>✅ Successfully inserted 1 row into powerball_results!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Skipped. Row already exists in the database.</div>";
                    }
                } else {
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert_pb'>";
                    echo "<button type='submit' class='btn btn-green'>Insert Main PowerBall Row</button>";
                    echo "</form>";
                }

            } else {
                echo "<div style='color: #64748b;'>No Main PowerBall draw data found for this date.</div>";
            }
            echo "</div>";


            // ==========================================
            // 2. POWERBALL PLUS SECTION
            // ==========================================
            echo "<div class='game-card'>";
            echo "<h3 style='margin-top: 0; color: #1e293b;'>PowerBall Plus</h3>";
            
            $pbPlusData = $apiData['results']['powerball_plus_results'] ?? null;
            
            if ($pbPlusData && date('Y-m-d', strtotime($pbPlusData['date'])) === $targetDate && !empty($pbPlusData['winning_numbers'])) {
                
                $balls = $pbPlusData['winning_numbers'];
                
                // Extraction purely for preview display
                $displayPowerballPlus = $pbPlusData['powerball'] ?? $pbPlusData['bonus_ball'] ?? (isset($balls[5]) ? $balls[5] : null);
                
                echo "<div>";
                // Show first 5 balls
                for ($i = 0; $i < min(5, count($balls)); $i++) {
                    echo "<span class='ball'>" . htmlspecialchars($balls[$i]) . "</span>";
                }
                // Show PowerBall
                if ($displayPowerballPlus !== null) { 
                    echo "<span class='ball powerball-ball'>" . htmlspecialchars($displayPowerballPlus) . "</span>"; 
                }
                echo "</div>";

                if ($action === 'insert_pb_plus') {
                    $result = insertPowerBallRow($pdo, 'powerball_plus_results', $pbPlusData, $targetDate);
                    
                    if (!empty($result['error'])) {
                        echo "<div class='error-msg'>❌ DATABASE ERROR: " . htmlspecialchars($result['error']) . "</div>";
                    } elseif ($result['success'] && $result['rows_affected'] > 0) {
                        echo "<div class='success-msg'>✅ Successfully inserted 1 row into powerball_plus_results!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Skipped. Row already exists in the database.</div>";
                    }
                } else {
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert_pb_plus'>";
                    echo "<button type='submit' class='btn btn-green'>Insert PowerBall Plus Row</button>";
                    echo "</form>";
                }

            } else {
                echo "<div style='color: #64748b;'>No PowerBall Plus draw data found for this date.</div>";
            }
            echo "</div>";

        } else {
            echo "<div class='warning-msg'>API returned an unsuccessful status.</div>";
        }
    } else {
        echo "<div class='warning-msg'>API Request Failed. HTTP Code: $httpCode</div>";
    }
    
    echo "</div>"; 
}
?>

<div style='margin-top: 20px; display: flex; gap: 16px;'>
    <?php 
    $prevDay = date('Y-m-d', strtotime("-1 day", strtotime($targetDate)));
    $nextDay = date('Y-m-d', strtotime("+1 day", strtotime($targetDate)));
    ?>
    <a href='?date=<?php echo $prevDay; ?>' class='btn btn-gray'>&larr; Check <?php echo $prevDay; ?></a>
    <?php if (strtotime($nextDay) <= strtotime(date('Y-m-d'))): ?>
        <a href='?date=<?php echo $nextDay; ?>' class='btn btn-gray'>Check <?php echo $nextDay; ?> &rarr;</a>
    <?php endif; ?>
</div>

</body>
</html>