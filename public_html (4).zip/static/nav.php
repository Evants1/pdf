<?php
// Get the current URL so we can highlight the correct menu item
$current_path = $_SERVER['REQUEST_URI'];
?>

<style>
/* --- HEADER & BASE STYLES --- */
header {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(12px);
    -webkit-backdrop-filter: blur(12px);
    padding: 12px 0;
    border-bottom: 2px solid var(--primary, #4f46e5);
    position: sticky; top: 0; z-index: 100;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
}

.nav-wrap { 
    display: flex; 
    justify-content: space-between; 
    align-items: center; 
    max-width: 1323px; 
    margin: 0 auto; 
    padding: 0 20px;
}

.logo { 
    font-size: 1.5rem; 
    font-weight: 800; 
    background: linear-gradient(90deg, var(--primary, #4f46e5), #9333ea); 
    -webkit-background-clip: text; 
    -webkit-text-fill-color: transparent; 
    text-decoration: none;
    letter-spacing: -0.5px;
}

/* Header CTA Button */
.btn-nav {
    background: linear-gradient(135deg, #059669, #065f46);
    color: white !important;
    padding: 10px 22px;
    border-radius: 99px; 
    font-size: 0.9rem;
    font-weight: 800;
    transition: all 0.2s ease;
    box-shadow: 0 4px 10px rgba(5, 150, 105, 0.2);
    text-decoration: none;
    white-space: nowrap;
}

.btn-nav:hover {
    transform: translateY(-2px);
    box-shadow: 0 6px 15px rgba(5, 150, 105, 0.4);
}

.right-cluster {
    display: flex;
    align-items: center;
    gap: 20px;
}

/* --- DESKTOP NAVIGATION (Hidden on Mobile) --- */
.desktop-nav { margin: 0 auto; }
.desktop-nav .nav-links { display: flex; gap: 24px; list-style: none; align-items: center; margin: 0; padding: 0; }
.desktop-nav .nav-links > li > a { font-size: 0.95rem; font-weight: 700; color: #64748b; transition: all 0.2s ease; padding: 4px 0; position: relative; text-decoration: none; white-space: nowrap; }
.desktop-nav .nav-links > li > a:hover, .desktop-nav .nav-links > li > a.active { color: #0f172a; }

/* Desktop Animated Underline */
.desktop-nav .nav-links > li > a::after { content: ''; position: absolute; bottom: -2px; left: 0; width: 0%; height: 2px; background: linear-gradient(90deg, #4f46e5, #9333ea); transition: width 0.2s ease; border-radius: 2px; }
.desktop-nav .nav-links > li > a:hover::after, .desktop-nav .nav-links > li > a.active::after, .desktop-nav .dropdown:hover > a::after { width: 100%; }

/* Desktop Dropdown CSS (Hover) */
.desktop-nav .dropdown { position: relative; }
.desktop-nav .drop-arrow { font-size: 0.75em; margin-left: 4px; display: inline-block; transition: transform 0.2s ease; vertical-align: middle; }
.desktop-nav .dropdown:hover .drop-arrow { transform: rotate(180deg); }
.desktop-nav .dropdown-content { visibility: hidden; opacity: 0; position: absolute; top: 100%; left: 50%; transform: translateX(-50%) translateY(10px); background-color: #ffffff; min-width: 160px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.1); border-radius: 8px; padding: 8px 0; z-index: 1000; transition: all 0.2s ease; border: 1px solid #e2e8f0; display: flex; flex-direction: column; }
.desktop-nav .dropdown:hover .dropdown-content { visibility: visible; opacity: 1; transform: translateX(-50%) translateY(4px); }
.desktop-nav .dropdown-content a { padding: 10px 20px; color: #475569; font-size: 0.9rem; font-weight: 600; text-decoration: none; transition: background-color 0.2s ease, color 0.2s ease; white-space: nowrap; }
.desktop-nav .dropdown-content a:hover, .desktop-nav .dropdown-content a.active { background-color: #f8fafc; color: #4f46e5; }

/* --- MOBILE NAVIGATION (Hidden on Desktop) --- */
.hamburger { background: none; border: none; cursor: pointer; display: none; flex-direction: column; gap: 6px; padding: 4px; z-index: 1002; }
.hamburger span { display: block; width: 28px; height: 3px; background-color: #0f172a; border-radius: 3px; transition: all 0.3s ease; }

.side-menu { position: fixed; top: 0; right: -400px; width: 320px; height: 100vh; background: #ffffff; box-shadow: -5px 0 25px rgba(0,0,0,0.1); z-index: 1001; transition: right 0.4s cubic-bezier(0.4, 0, 0.2, 1); display: flex; flex-direction: column; padding: 80px 24px 24px 24px; overflow-y: auto; }
.side-menu.open { right: 0; }

.menu-overlay { position: fixed; top: 0; left: 0; width: 100%; height: 100vh; background: rgba(15, 23, 42, 0.5); backdrop-filter: blur(4px); z-index: 1000; opacity: 0; visibility: hidden; transition: all 0.3s ease; }
.menu-overlay.open { opacity: 1; visibility: visible; }

.side-menu .nav-links { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; gap: 12px; }
.side-menu .nav-links > li > a, .side-menu .dropdown-btn { display: flex; justify-content: space-between; align-items: center; font-size: 1.1rem; font-weight: 700; color: #1e293b; text-decoration: none; padding: 12px 16px; border-radius: 8px; transition: all 0.2s ease; background: transparent; border: none; width: 100%; cursor: pointer; font-family: inherit; }
.side-menu .nav-links > li > a:hover, .side-menu .dropdown-btn:hover, .side-menu .nav-links > li > a.active { background: #f8fafc; color: #4f46e5; }

/* Mobile Accordion Dropdown */
.side-menu .dropdown-content { max-height: 0; overflow: hidden; transition: max-height 0.3s ease-out; background: #f8fafc; border-radius: 8px; margin: 0 8px; }
.side-menu .dropdown-content.open { max-height: 500px; }
.side-menu .dropdown-content a { display: block; padding: 10px 16px 10px 32px; color: #475569; font-size: 0.95rem; font-weight: 600; text-decoration: none; border-left: 2px solid transparent; transition: all 0.2s; }
.side-menu .dropdown-content a:hover, .side-menu .dropdown-content a.active { color: #4f46e5; border-left-color: #4f46e5; background: #f1f5f9; }
.side-menu .drop-arrow { font-size: 0.8em; transition: transform 0.3s ease; color: #94a3b8; }
.side-menu .dropdown-btn.open .drop-arrow { transform: rotate(180deg); }

.mobile-only-cta { display: none; margin-top: 24px; text-align: center; width: 100%; }

/* --- RESPONSIVE BREAKPOINTS --- */
@media (max-width: 1024px) {
    .desktop-nav .nav-links { gap: 16px; }
    .desktop-nav .nav-links > li > a { font-size: 0.85rem; }
}

@media (max-width: 860px) {
    .desktop-nav { display: none; } /* Hide Desktop Nav */
    .hamburger { display: flex; }   /* Show Mobile Menu Toggle */
    .btn-nav.desktop-cta { display: none; } /* Hide Desktop CTA to save space */
    .mobile-only-cta { display: block; }    /* Show CTA inside Mobile Menu */
    .side-menu { width: 85%; max-width: 350px; }
    .logo { font-size: 1.35rem; }
}
</style>

<header>
    <div class="nav-wrap">
        <a href="/" class="logo" title="Latest Lotto Results & Ticket Checker South Africa">Next Draw Logic</a>
        
        <!-- ==========================================
             DESKTOP NAVIGATION (Hidden on Mobile)
        =========================================== -->
        <nav class="desktop-nav" aria-label="Desktop navigation">
            <ul class="nav-links">
                <li><a href="/results/daily-lotto/history/" class="<?php echo (strpos($current_path, '/daily-lotto') !== false) ? 'active' : ''; ?>">Daily Lotto Results</a></li>
                
                <li class="dropdown">
                    <a href="/results/lotto/history/" class="<?php echo (strpos($current_path, '/lotto') !== false && strpos($current_path, '/daily-lotto') === false) ? 'active' : ''; ?>">
                        Lotto Results <span class="drop-arrow">▼</span>
                    </a>
                    <div class="dropdown-content">
                        <a href="/results/lotto/history/" class="<?php echo ($current_path == '/results/lotto/' || $current_path == '/') ? 'active' : ''; ?>">Main Lotto</a>
                        <a href="/results/lotto-plus-1/history/" class="<?php echo (strpos($current_path, '/lotto-plus-1') !== false) ? 'active' : ''; ?>">Lotto Plus 1</a>
                        <a href="/results/lotto-plus-2/history/" class="<?php echo (strpos($current_path, '/lotto-plus-2') !== false) ? 'active' : ''; ?>">Lotto Plus 2</a>
                    </div>
                </li>
                
                <li class="dropdown">
                    <a href="/results/powerball/history/" class="<?php echo (strpos($current_path, '/powerball') !== false) ? 'active' : ''; ?>">
                        PowerBall Results <span class="drop-arrow">▼</span>
                    </a>
                    <div class="dropdown-content">
                        <a href="/results/powerball/history/" class="<?php echo ($current_path == '/results/powerball/') ? 'active' : ''; ?>">Main PowerBall</a>
                        <a href="/results/powerball-plus/history/" class="<?php echo (strpos($current_path, '/powerball-plus') !== false) ? 'active' : ''; ?>">PowerBall Plus</a>
                    </div>
                </li>
                
                <li><a href="/fafi-dream-guide/" class="<?php echo (strpos($current_path, '/fafi-dream-guide') !== false) ? 'active' : ''; ?>">Fafi Dreams</a></li>
                <li><a href="/predictions/" class="<?php echo (strpos($current_path, '/predictions') !== false) ? 'active' : ''; ?>">Predictions</a></li>
            </ul>
        </nav>

        <!-- Right Side CTA and Hamburger Icon -->
        <div class="right-cluster">
            <a href="/check-tickets/" class="btn-nav desktop-cta">Check If You Won</a>
            
            <button class="hamburger" id="menuToggle" aria-label="Toggle Menu">
                <span></span>
                <span></span>
                <span></span>
            </button>
        </div>
    </div>
</header>


<div class="menu-overlay" id="menuOverlay"></div>
<nav class="side-menu" id="sideMenu" aria-label="Mobile navigation">
    <ul class="nav-links">
        <li>
            <a href="/results/daily-lotto/history/" class="<?php echo (strpos($current_path, '/daily-lotto') !== false) ? 'active' : ''; ?>">Daily Lotto Results</a>
        </li>
       
        <li>
                <button type="button" class="dropdown-btn" data-active="<?php echo (strpos($current_path, '/lotto') !== false && strpos($current_path, '/daily-lotto') === false) ? '1' : '0'; ?>">
        Lotto Results <span class="drop-arrow">▼</span>
    </button>
            <div class="dropdown-content">
                <a href="/results/lotto/history/" class="<?php echo ($current_path == '/results/lotto/' || $current_path == '/') ? 'active' : ''; ?>">Main Lotto</a>
                <a href="/results/lotto-plus-1/history/" class="<?php echo (strpos($current_path, '/lotto-plus-1') !== false) ? 'active' : ''; ?>">Lotto Plus 1</a>
                <a href="/results/lotto-plus-2/history/" class="<?php echo (strpos($current_path, '/lotto-plus-2') !== false) ? 'active' : ''; ?>">Lotto Plus 2</a>
            </div>
        </li>
       
        <li>
            <button type="button" class="dropdown-btn" data-active="<?php echo (strpos($current_path, '/powerball') !== false) ? '1' : '0'; ?>">
    PowerBall Results <span class="drop-arrow">▼</span>
</button>
            <div class="dropdown-content">
                <a href="/results/powerball/history/" class="<?php echo ($current_path == '/results/powerball/') ? 'active' : ''; ?>">Main PowerBall</a>
                <a href="/results/powerball-plus/history/" class="<?php echo (strpos($current_path, '/powerball-plus') !== false) ? 'active' : ''; ?>">PowerBall Plus</a>
            </div>
        </li>
       
        <li><a href="/fafi-dream-guide/" class="<?php echo (strpos($current_path, '/fafi-dream-guide') !== false) ? 'active' : ''; ?>">Fafi Dream Guide</a></li>
        <li><a href="/predictions/" class="<?php echo (strpos($current_path, '/predictions') !== false) ? 'active' : ''; ?>">Predictions</a></li>
    </ul>
    <a href="/check-tickets/" class="btn-nav mobile-only-cta">Check If You Won</a>
</nav>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const menuToggle   = document.getElementById('menuToggle');
    const sideMenu     = document.getElementById('sideMenu');
    const menuOverlay  = document.getElementById('menuOverlay');
    const dropdownBtns = document.querySelectorAll('.side-menu .dropdown-btn');

    // Toggle Mobile Sidebar Menu
    function toggleMenu() {
        sideMenu.classList.toggle('open');
        menuOverlay.classList.toggle('open');
    }

    menuToggle.addEventListener('click', toggleMenu);
    menuOverlay.addEventListener('click', toggleMenu);

    // Bulletproof Mobile Dropdown (Accordion) Logic
    dropdownBtns.forEach(btn => {
        btn.addEventListener('click', function(e) {
            e.preventDefault(); // Stop mobile glitching
            
            const content = this.nextElementSibling;

            // Toggle arrow state
            this.classList.toggle('open');

            // Explicitly set max-height for perfect mobile animation
            if (content.style.maxHeight || content.classList.contains('open')) {
                content.style.maxHeight = null;
                content.classList.remove('open');
            } else {
                content.style.maxHeight = content.scrollHeight + "px";
                content.classList.add('open');
            }
        });
    });

    // === Open dropdown automatically if user is on a sub-page ===
    function openActiveDropdowns() {
        dropdownBtns.forEach(btn => {
            if (btn.getAttribute('data-active') === '1') {
                btn.classList.add('open');
                const content = btn.nextElementSibling;
                if (content) {
                    content.classList.add('open');
                    // Ensure height is set so it doesn't instantly snap shut
                    content.style.maxHeight = content.scrollHeight + "px"; 
                }
            }
        });
    }

    // Open active dropdowns when menu opens
    const observer = new MutationObserver((mutations) => {
        mutations.forEach(mutation => {
            if (mutation.target.classList.contains('open')) {
                // Slight delay to allow DOM to render before calculating scrollHeight
                setTimeout(openActiveDropdowns, 50);
            }
        });
    });

    observer.observe(sideMenu, { attributes: true, attributeFilter: ['class'] });

    // Also open immediately in case menu is already open
    if (sideMenu.classList.contains('open')) {
        openActiveDropdowns();
    }
});
</script>