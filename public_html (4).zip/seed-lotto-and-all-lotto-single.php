<?php
// Turn on errors for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

set_time_limit(30); 

// Connect to your database
require_once __DIR__ . '/db.php';

// Force PDO to throw exceptions so we can see EXACTLY why an insert fails
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$apiKey = "5db296ba3e566384fcfae279c702e052"; // <-- Add your real key

// Determine the date to process
$targetDate = isset($_REQUEST['date']) ? $_REQUEST['date'] : date('Y-m-d');
$dayOfWeek = date('l', strtotime($targetDate));

// Check if the user clicked an "Insert" button
$action = isset($_POST['action']) ? $_POST['action'] : '';

// Helper function to insert a single row for Lotto games (6 Balls + 1 Bonus Ball - 8 Divisions)
function insertLottoRow($pdo, $tableName, $gameData, $targetDate) {
    try {
        $actualDrawDate = date('Y-m-d', strtotime($gameData['date']));
        $drawId = $gameData['draw_id'] ?? null;
        $machine = $gameData['draw_machine'] ?? null; 
        $poolSize = $gameData['total_pool_size'] ?? 0;
        $sales = $gameData['total_sales'] ?? 0;
        $rollover = $gameData['rollover_number'] ?? 0;
        
        $balls = $gameData['winning_numbers'];
        $divs = $gameData['divisions'] ?? [];
        
        // --- BULLETPROOF BONUS BALL CATCHER ---
        $bonusBall = null;
        if (isset($gameData['bonus_ball']) && $gameData['bonus_ball'] !== '') {
            $bonusBall = $gameData['bonus_ball'];
        } elseif (is_array($balls) && count($balls) >= 7) {
            // Sometimes they just append it as the 7th ball in the array
            $bonusBall = $balls[6]; 
        }
        
        // Matches exact DB Schema: 8 divisions
        $stmt = $pdo->prepare("INSERT IGNORE INTO $tableName (
            draw_date, draw_number, machine_name, total_pool_size, total_sales, rollover_number,
            ball_1, ball_2, ball_3, ball_4, ball_5, ball_6, bonus_ball,
            div1_winners, div1_amount, div2_winners, div2_amount, 
            div3_winners, div3_amount, div4_winners, div4_amount,
            div5_winners, div5_amount, div6_winners, div6_amount,
            div7_winners, div7_amount, div8_winners, div8_amount
        ) VALUES (
            ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?,
            ?, ?, ?, ?
        )");
        
        $success = $stmt->execute([
            $actualDrawDate, $drawId, $machine, $poolSize, $sales, $rollover,
            $balls[0]??null, $balls[1]??null, $balls[2]??null, $balls[3]??null, $balls[4]??null, $balls[5]??null, $bonusBall,
            $divs[0]['winners']??0, $divs[0]['winning_amount']??0, 
            $divs[1]['winners']??0, $divs[1]['winning_amount']??0,
            $divs[2]['winners']??0, $divs[2]['winning_amount']??0, 
            $divs[3]['winners']??0, $divs[3]['winning_amount']??0,
            $divs[4]['winners']??0, $divs[4]['winning_amount']??0, 
            $divs[5]['winners']??0, $divs[5]['winning_amount']??0,
            $divs[6]['winners']??0, $divs[6]['winning_amount']??0, 
            $divs[7]['winners']??0, $divs[7]['winning_amount']??0
        ]);
        
        return ['success' => $success, 'rows_affected' => $stmt->rowCount(), 'error' => null];
        
    } catch (PDOException $e) {
        return ['success' => false, 'rows_affected' => 0, 'error' => $e->getMessage()];
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Lotto Single Row Importer</title>
    <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; padding: 20px; background: #f8fafc; color: #334155; }
        .box { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .btn { padding: 10px 20px; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; color: white; text-decoration: none; display: inline-block; }
        .btn-blue { background: #3b82f6; }
        .btn-blue:hover { background: #2563eb; }
        .btn-green { background: #22c55e; font-size: 1rem; padding: 10px 20px; margin-top: 15px;}
        .btn-green:hover { background: #16a34a; }
        .btn-gray { background: #64748b; }
        .ball { display: inline-block; width: 40px; height: 40px; line-height: 40px; text-align: center; background: #e2e8f0; border-radius: 50%; font-weight: bold; margin-right: 8px; font-size: 16px;}
        .bonus-ball { background: #3b82f6; color: white; border: 2px solid #1d4ed8; }
        .success-msg { background: #dcfce7; color: #166534; padding: 12px; border-radius: 6px; border: 1px solid #bbf7d0; font-weight: bold; margin-top: 15px;}
        .warning-msg { background: #fef08a; color: #854d0e; padding: 12px; border-radius: 6px; border: 1px solid #fde047; margin-top: 15px;}
        .error-msg { background: #fee2e2; color: #991b1b; padding: 12px; border-radius: 6px; border: 1px solid #f87171; font-weight: bold; margin-top: 15px;}
        .game-card { border: 1px solid #e2e8f0; border-radius: 8px; padding: 20px; margin-bottom: 20px; background: #fdfdfd; }
        .debug-pre { background: #1e293b; color: #10b981; padding: 15px; border-radius: 6px; overflow-x: auto; font-size: 0.85rem;}
    </style>
</head>
<body>

<div class="box">
    <form method="GET" action="">
        <label for="date" style="font-weight: bold; margin-right: 10px; font-size: 1.1rem;">1. Select Draw Date (Wed/Sat):</label>
        <input type="date" id="date" name="date" value="<?php echo htmlspecialchars($targetDate); ?>" max="<?php echo date('Y-m-d'); ?>" style="padding: 10px; border: 1px solid #cbd5e1; border-radius: 6px; font-size: 1rem;">
        <button type="submit" class="btn btn-blue" style="margin-left: 10px;">Fetch Preview</button>
    </form>
</div>

<?php
if (isset($_GET['date']) || !empty($action)) {
    
    echo "<div class='box'>";
    echo "<h2>Preview for: $targetDate ($dayOfWeek)</h2>";

    $apiUrl = "https://resultsZA.co.za/api/get_latest_results?api_key={$apiKey}&date={$targetDate}";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $apiUrl);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); 
    curl_setopt($ch, CURLOPT_TIMEOUT, 10); 
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0');
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200 && $response) {
        $apiData = json_decode($response, true);
        
        if (isset($apiData['status']) && $apiData['status'] === 'success') {
            
            // ==========================================
            // 1. MAIN LOTTO SECTION
            // ==========================================
            echo "<div class='game-card'>";
            echo "<h3 style='margin-top: 0; color: #1e293b;'>Main Lotto</h3>";
            
            $lottoData = $apiData['results']['lotto_results'] ?? null;
            
            if ($lottoData && date('Y-m-d', strtotime($lottoData['date'])) === $targetDate && !empty($lottoData['winning_numbers'])) {
                
                $balls = $lottoData['winning_numbers'];
                
                // Extraction purely for preview display
                $displayBonusBall = $lottoData['bonus_ball'] ?? (isset($balls[6]) ? $balls[6] : null);
                
                echo "<div>";
                // Show first 6 balls
                for ($i = 0; $i < min(6, count($balls)); $i++) {
                    echo "<span class='ball'>" . htmlspecialchars($balls[$i]) . "</span>";
                }
                // Show Bonus Ball
                if ($displayBonusBall !== null) { 
                    echo "<span class='ball bonus-ball'>" . htmlspecialchars($displayBonusBall) . "</span>"; 
                }
                echo "</div>";

                if ($action === 'insert_lotto') {
                    $result = insertLottoRow($pdo, 'lotto_results', $lottoData, $targetDate);
                    
                    if (!empty($result['error'])) {
                        echo "<div class='error-msg'>❌ DATABASE ERROR: " . htmlspecialchars($result['error']) . "</div>";
                    } elseif ($result['success'] && $result['rows_affected'] > 0) {
                        echo "<div class='success-msg'>✅ Successfully inserted 1 row into lotto_results!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Skipped. Row already exists in the database.</div>";
                    }
                } else {
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert_lotto'>";
                    echo "<button type='submit' class='btn btn-green'>Insert Main Lotto Row</button>";
                    echo "</form>";
                }

            } else {
                echo "<div style='color: #64748b;'>No Main Lotto draw data found for this date.</div>";
            }
            echo "</div>";


            // ==========================================
            // 2. LOTTO PLUS 1 SECTION
            // ==========================================
            echo "<div class='game-card'>";
            echo "<h3 style='margin-top: 0; color: #1e293b;'>Lotto Plus 1</h3>";
            
            // --- FALLBACK LOGIC ---
            $lottoP1Data = $apiData['results']['lotto_plus_1_results'] 
                        ?? $apiData['results']['lotto_plus_results'] 
                        ?? $apiData['results']['lotto_plus1_results'] 
                        ?? null;
            
            if ($lottoP1Data && date('Y-m-d', strtotime($lottoP1Data['date'])) === $targetDate && !empty($lottoP1Data['winning_numbers'])) {
                
                $balls = $lottoP1Data['winning_numbers'];
                
                $displayBonusBall = $lottoP1Data['bonus_ball'] ?? (isset($balls[6]) ? $balls[6] : null);
                
                echo "<div>";
                for ($i = 0; $i < min(6, count($balls)); $i++) {
                    echo "<span class='ball'>" . htmlspecialchars($balls[$i]) . "</span>";
                }
                if ($displayBonusBall !== null) { 
                    echo "<span class='ball bonus-ball'>" . htmlspecialchars($displayBonusBall) . "</span>"; 
                }
                echo "</div>";

                if ($action === 'insert_lotto_p1') {
                    $result = insertLottoRow($pdo, 'lotto_plus_1_results', $lottoP1Data, $targetDate);
                    
                    if (!empty($result['error'])) {
                        echo "<div class='error-msg'>❌ DATABASE ERROR: " . htmlspecialchars($result['error']) . "</div>";
                    } elseif ($result['success'] && $result['rows_affected'] > 0) {
                        echo "<div class='success-msg'>✅ Successfully inserted 1 row into lotto_plus_1_results!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Skipped. Row already exists in the database.</div>";
                    }
                } else {
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert_lotto_p1'>";
                    echo "<button type='submit' class='btn btn-green'>Insert Lotto Plus 1 Row</button>";
                    echo "</form>";
                }

            } else {
                echo "<div style='color: #64748b;'>No Lotto Plus 1 draw data found for this date.</div>";
            }
            echo "</div>";

            // ==========================================
            // 3. LOTTO PLUS 2 SECTION
            // ==========================================
            echo "<div class='game-card'>";
            echo "<h3 style='margin-top: 0; color: #1e293b;'>Lotto Plus 2</h3>";
            
            // --- FALLBACK LOGIC ---
            $lottoP2Data = $apiData['results']['lotto_plus_2_results'] 
                        ?? $apiData['results']['lotto_plus2_results'] 
                        ?? null;
            
            if ($lottoP2Data && date('Y-m-d', strtotime($lottoP2Data['date'])) === $targetDate && !empty($lottoP2Data['winning_numbers'])) {
                
                $balls = $lottoP2Data['winning_numbers'];
                
                $displayBonusBall = $lottoP2Data['bonus_ball'] ?? (isset($balls[6]) ? $balls[6] : null);
                
                echo "<div>";
                for ($i = 0; $i < min(6, count($balls)); $i++) {
                    echo "<span class='ball'>" . htmlspecialchars($balls[$i]) . "</span>";
                }
                if ($displayBonusBall !== null) { 
                    echo "<span class='ball bonus-ball'>" . htmlspecialchars($displayBonusBall) . "</span>"; 
                }
                echo "</div>";

                if ($action === 'insert_lotto_p2') {
                    $result = insertLottoRow($pdo, 'lotto_plus_2_results', $lottoP2Data, $targetDate);
                    
                    if (!empty($result['error'])) {
                        echo "<div class='error-msg'>❌ DATABASE ERROR: " . htmlspecialchars($result['error']) . "</div>";
                    } elseif ($result['success'] && $result['rows_affected'] > 0) {
                        echo "<div class='success-msg'>✅ Successfully inserted 1 row into lotto_plus_2_results!</div>";
                    } else {
                        echo "<div class='warning-msg'>⚠️ Skipped. Row already exists in the database.</div>";
                    }
                } else {
                    echo "<form method='POST' action=''>";
                    echo "<input type='hidden' name='date' value='" . htmlspecialchars($targetDate) . "'>";
                    echo "<input type='hidden' name='action' value='insert_lotto_p2'>";
                    echo "<button type='submit' class='btn btn-green'>Insert Lotto Plus 2 Row</button>";
                    echo "</form>";
                }

            } else {
                echo "<div style='color: #64748b;'>No Lotto Plus 2 draw data found for this date.</div>";
            }
            echo "</div>";
            
            // ==========================================
            // DEBUG SECTION (Shows available API keys if missing)
            // ==========================================
            if (!$lottoData || !$lottoP1Data || !$lottoP2Data) {
                echo "<div style='margin-top:30px;'>";
                echo "<h4>API Debugger</h4>";
                echo "<p style='font-size:0.9rem; color:#64748b;'>If a game is missing, check the exact names the API is sending below. If they differ from 'lotto_plus_1_results', update the script's fallback checks.</p>";
                echo "<pre class='debug-pre'>";
                print_r(array_keys($apiData['results'] ?? []));
                echo "</pre>";
                echo "</div>";
            }

        } else {
            echo "<div class='warning-msg'>API returned an unsuccessful status.</div>";
        }
    } else {
        echo "<div class='warning-msg'>API Request Failed. HTTP Code: $httpCode</div>";
    }
    
    echo "</div>"; 
}
?>

<div style='margin-top: 20px; display: flex; gap: 16px;'>
    <?php 
    $prevDay = date('Y-m-d', strtotime("-1 day", strtotime($targetDate)));
    $nextDay = date('Y-m-d', strtotime("+1 day", strtotime($targetDate)));
    ?>
    <a href='?date=<?php echo $prevDay; ?>' class='btn btn-gray'>&larr; Check <?php echo $prevDay; ?></a>
    <?php if (strtotime($nextDay) <= strtotime(date('Y-m-d'))): ?>
        <a href='?date=<?php echo $nextDay; ?>' class='btn btn-gray'>Check <?php echo $nextDay; ?> &rarr;</a>
    <?php endif; ?>
</div>

</body>
</html>