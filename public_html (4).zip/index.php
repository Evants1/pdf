<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// Connect to your database
require_once __DIR__ . '/db.php';

// --- DYNAMIC LAST DRAW CALCULATOR ---
function getLastDraw($gameId) {
    $now = new DateTime();
    $currentDay = (int)$now->format('w');
    $currentTime = $now->format('H:i');
    
    // Daily Lotto is 20:30 (08:30 PM), Others are 21:30 (09:30 PM)
    $drawHour = ($gameId === 'dailylotto') ? 20 : 21;
    $timeString = $drawHour . ':30';
    
    if (in_array($gameId, ['powerball', 'powerballplus'])) {
        $days = [2, 5]; // Tuesday (2) & Friday (5)
    } elseif (in_array($gameId, ['lotto', 'lottoplus1', 'lottoplus2'])) {
        $days = [3, 6]; // Wednesday (3) & Saturday (6)
    } elseif ($gameId === 'dailylotto') {
        $days = [0, 1, 2, 3, 4, 5, 6]; // Daily Lotto (Everyday)
    } else {
        $days = [0]; // Fallback
    }

    $pastDates = [];
    foreach ($days as $day) {
        $d = clone $now;
        // If today is a draw day and it's AFTER the draw time
        if ($currentDay == $day && $currentTime >= $timeString) {
            $d->setTime($drawHour, 30);
        } else {
            // Find the previous occurrence of this specific day
            $dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            $d->modify('last ' . $dayNames[$day]);
            $d->setTime($drawHour, 30);
        }
        $pastDates[] = $d;
    }

    // Sort to find the absolute closest past draw (descending order)
    usort($pastDates, function($a, $b) { return $b <=> $a; });
    return $pastDates[0]->format('F j, Y');
}

// --- DYNAMIC NEXT DRAW CALCULATOR ---
function getNextDraw($gameId) {
    $now = new DateTime();
    $currentDay = (int)$now->format('w');
    $currentTime = $now->format('H:i');
    
    // Daily Lotto is 20:30 (08:30 PM), Others are 21:30 (09:30 PM)
    $drawHour = ($gameId === 'dailylotto') ? 20 : 21;
    $timeString = $drawHour . ':30';
    
    // Explicitly target each game by ID to ensure accurate days
    if (in_array($gameId, ['powerball', 'powerballplus'])) {
        $days = [2, 5]; // Tuesday (2) & Friday (5)
    } elseif (in_array($gameId, ['lotto', 'lottoplus1', 'lottoplus2'])) {
        $days = [3, 6]; // Wednesday (3) & Saturday (6)
    } elseif ($gameId === 'dailylotto') {
        $days = [0, 1, 2, 3, 4, 5, 6]; // Daily Lotto (Everyday)
    } else {
        $days = [0]; // Fallback
    }

    $nextDates = [];
    foreach ($days as $day) {
        $d = clone $now;
        // If today is a draw day and it's before the draw time
        if ($currentDay == $day && $currentTime < $timeString) {
            $d->setTime($drawHour, 30);
        } else {
            // Find the next occurrence of this specific day
            $dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
            $d->modify('next ' . $dayNames[$day]);
            $d->setTime($drawHour, 30);
        }
        $nextDates[] = $d;
    }

    // Sort to find the absolute closest upcoming draw
    usort($nextDates, function($a, $b) { return $a <=> $b; });
    return $nextDates[0]->format('l, F j, Y, g:i A') . ' ZA time';
}


// --- UNIVERSAL DYNAMIC FETCH SYSTEM ---
function fetchLatestGameData($pdo, $tableName, $gameId, $ballCount, $highThreshold, $bonusColName, $fbJackpot, $fbNumbers, $fbBonus) {
    $data = [
        'date' => getLastDraw($gameId),
        'last_updated' => date('F j, Y \a\t g:i A'),
        'draw_number' => 'N/A',
        'jackpot' => $fbJackpot,
        'numbers' => $fbNumbers,
        'bonus' => $fbBonus,
        'stats' => ['odd_even' => '0/0', 'high_low' => '0/0']
    ];
    
    // Auto-calculate fallbacks stats so they are accurate to the hardcoded numbers
    $odds = 0; $evens = 0; $highs = 0; $lows = 0;
    foreach($data['numbers'] as $b) {
        if ($b % 2 == 0) { $evens++; } else { $odds++; }
        if ($b >= $highThreshold) { $highs++; } else { $lows++; }
    }
    $data['stats'] = ['odd_even' => "$odds/$evens", 'high_low' => "$highs/$lows"];

    try {
        $stmt = $pdo->query("SELECT * FROM $tableName ORDER BY draw_date DESC, id DESC LIMIT 1");
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($row) {
            $data['date'] = date('F j, Y', strtotime($row['draw_date']));
            
            // --- TOP WIN AMOUNT CALCULATOR ---
            $topWin = 'Pending';
            $foundWin = false;
            
            for ($d = 1; $d <= 15; $d++) {
                $winCol = "div{$d}_winners";
                $amtCol = "div{$d}_amount";
                
                if (array_key_exists($winCol, $row) && array_key_exists($amtCol, $row)) {
                    $winners = (int)$row[$winCol];
                    $amount = (float)$row[$amtCol];
                    
                    if ($winners > 0 && $amount > 0) {
                        $topWin = 'R ' . number_format($amount, 2);
                        $foundWin = true;
                        break; 
                    }
                }
            }
            
            if (!$foundWin) {
                if (array_key_exists('jackpot_amount', $row) && !empty($row['jackpot_amount'])) {
                    if (is_numeric($row['jackpot_amount'])) {
                        $topWin = 'R ' . number_format((float)$row['jackpot_amount'], 2) . ' (Rolled)';
                    } else {
                        $topWin = $row['jackpot_amount'];
                    }
                }
            }
            $data['jackpot'] = $topWin;
            
            // Pull draw number if available
            if (isset($row['draw_number']) && !empty($row['draw_number'])) {
                $data['draw_number'] = $row['draw_number'];
            }
            
            $nums = [];
            for($i=1; $i<=$ballCount; $i++) {
                $nums[] = (int)($row["ball_$i"] ?? 0);
            }
            $data['numbers'] = array_filter($nums);
            
            if ($bonusColName && isset($row[$bonusColName])) {
                $data['bonus'] = (int)$row[$bonusColName];
            }
            
            // Re-calculate stats with live DB numbers
            $odds = 0; $evens = 0; $highs = 0; $lows = 0;
            foreach($data['numbers'] as $b) {
                if ($b % 2 == 0) { $evens++; } else { $odds++; }
                if ($b >= $highThreshold) { $highs++; } else { $lows++; }
            }
            $data['stats'] = ['odd_even' => "$odds/$evens", 'high_low' => "$highs/$lows"];
            
            if (!empty($row['created_at'])) {
                $data['last_updated'] = (new DateTime($row['created_at']))->format('F j, Y \a\t g:i A'); 
            } else {
                $data['last_updated'] = date('F j, Y', strtotime($row['draw_date'])) . ' at 09:15 PM';
            }
        }
    } catch(Exception $e) {
        // Table missing or DB error? Silently continue using the SEO fallbacks.
    }
    
    return $data;
}

// --- DYNAMIC ANALYTICS CALCULATOR (100 DRAWS) ---
function fetchGameAnalytics($pdo, $tableName, $ballCount, $maxNum, $fbAnalytics) {
    try {
        $cols = "ball_1, ball_2, ball_3, ball_4, ball_5";
        if ($ballCount === 6) { $cols .= ", ball_6"; }
        
        $stmt = $pdo->query("SELECT $cols FROM $tableName ORDER BY draw_date DESC LIMIT 100");
        $draws = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        if (!$draws || count($draws) < 5) { return $fbAnalytics; }

        $frequency = array_fill(1, $maxNum, 0);
        $pairCounts = [];

        foreach ($draws as $draw) {
            $balls = [];
            for ($i = 1; $i <= $ballCount; $i++) {
                $b = (int)($draw["ball_$i"] ?? 0);
                if ($b >= 1 && $b <= $maxNum) {
                    $frequency[$b]++;
                    $balls[] = $b;
                }
            }

            // Calculate pairs for this draw
            sort($balls);
            $len = count($balls);
            if ($len >= 2) {
                for ($i = 0; $i < $len - 1; $i++) {
                    for ($j = $i + 1; $j < $len; $j++) {
                        $pair = $balls[$i] . ' & ' . $balls[$j];
                        $pairCounts[$pair] = ($pairCounts[$pair] ?? 0) + 1;
                    }
                }
            }
        }

        // Sort Hot (High to Low)
        arsort($frequency);
        $hotAll = array_keys($frequency);
        
        // Sort Cold (Low to High)
        asort($frequency);
        $coldAll = array_keys($frequency);

        // Sort Pairs
        arsort($pairCounts);
        $topPairs = array_slice(array_keys($pairCounts), 0, 2);

        $topCount = ($ballCount === 6) ? 6 : 5;

        return [
            'hot' => array_slice($hotAll, 0, $topCount),
            'cold' => array_slice($coldAll, 0, $topCount),
            'pairs' => $topPairs,
            'smart_pool' => array_slice($hotAll, 0, max(15, floor($maxNum * 0.6))) 
        ];

    } catch (Exception $e) {
        return $fbAnalytics; // Silent fallback
    }
}


// --- FETCH ALL LIVE DATA & ANALYTICS ---
$emptyAnalytics = ['hot' => [], 'cold' => [], 'pairs' => [], 'smart_pool' => []];

$dlData  = fetchLatestGameData($pdo, 'daily_lotto_results', 'dailylotto', 5, 19, null, 'Pending', [], null);
$dlStats = fetchGameAnalytics($pdo, 'daily_lotto_results', 5, 36, $emptyAnalytics);

$pbData  = fetchLatestGameData($pdo, 'powerball_results', 'powerball', 5, 26, 'powerball', 'Pending', [], null);
$pbStats = fetchGameAnalytics($pdo, 'powerball_results', 5, 50, $emptyAnalytics);

$pbpData = fetchLatestGameData($pdo, 'powerball_plus_results', 'powerballplus', 5, 26, 'powerball', 'Pending', [], null);
$pbpStats= fetchGameAnalytics($pdo, 'powerball_plus_results', 5, 50, $emptyAnalytics);

$ltData  = fetchLatestGameData($pdo, 'lotto_results', 'lotto', 6, 27, 'bonus_ball', 'Pending', [], null);
$ltStats = fetchGameAnalytics($pdo, 'lotto_results', 6, 52, $emptyAnalytics);

$ltp1Data= fetchLatestGameData($pdo, 'lotto_plus_1_results', 'lottoplus1', 6, 27, 'bonus_ball', 'Pending', [], null);
$ltp1Stats=fetchGameAnalytics($pdo, 'lotto_plus_1_results', 6, 52, $emptyAnalytics);

$ltp2Data= fetchLatestGameData($pdo, 'lotto_plus_2_results', 'lottoplus2', 6, 27, 'bonus_ball', 'Pending', [], null);
$ltp2Stats=fetchGameAnalytics($pdo, 'lotto_plus_2_results', 6, 52, $emptyAnalytics);


// --- BUILD THE FINAL DYNAMIC PIPELINE ---
$pageTitle = "SA Lottery Results Today | PowerBall, Lotto & Daily Lotto Analytics | NextDrawLogic";

$lotteryData = [
    'powerball' => [
        'id' => 'powerball',
        'slug' => 'powerball',
        'name' => 'PowerBall',
        'date' => $pbData['date'],
        'draw_number' => $pbData['draw_number'],
        'next_draw' => getNextDraw('powerball'),
        'last_updated' => $pbData['last_updated'],
        'jackpot' => $pbData['jackpot'],
        'numbers' => $pbData['numbers'],
        'bonus' => $pbData['bonus'],
        'stats' => $pbData['stats'],
        'analytics' => $pbStats,
        'rules' => ['max_num' => 50, 'draw_size' => 5, 'has_bonus' => true, 'bonus_max' => 20]
    ],
    'powerballplus' => [
        'id' => 'powerballplus',
        'slug' => 'powerball-plus',
        'name' => 'PowerBall Plus',
        'date' => $pbpData['date'],
        'draw_number' => $pbpData['draw_number'],
        'next_draw' => getNextDraw('powerballplus'),
        'last_updated' => $pbpData['last_updated'],
        'jackpot' => $pbpData['jackpot'],
        'numbers' => $pbpData['numbers'],
        'bonus' => $pbpData['bonus'],
        'stats' => $pbpData['stats'],
        'analytics' => $pbpStats,
        'rules' => ['max_num' => 50, 'draw_size' => 5, 'has_bonus' => true, 'bonus_max' => 20]
    ],
    'lotto' => [
        'id' => 'lotto',
        'slug' => 'lotto',
        'name' => 'Lotto',
        'date' => $ltData['date'],
        'draw_number' => $ltData['draw_number'],
        'next_draw' => getNextDraw('lotto'),
        'last_updated' => $ltData['last_updated'],
        'jackpot' => $ltData['jackpot'],
        'numbers' => $ltData['numbers'],
        'bonus' => $ltData['bonus'],
        'stats' => $ltData['stats'],
        'analytics' => $ltStats,
        'rules' => ['max_num' => 52, 'draw_size' => 6, 'has_bonus' => true, 'bonus_max' => 52]
    ],
    'lottoplus1' => [
        'id' => 'lottoplus1',
        'slug' => 'lotto-plus-1',
        'name' => 'Lotto Plus 1',
        'date' => $ltp1Data['date'],
        'draw_number' => $ltp1Data['draw_number'],
        'next_draw' => getNextDraw('lottoplus1'),
        'last_updated' => $ltp1Data['last_updated'],
        'jackpot' => $ltp1Data['jackpot'],
        'numbers' => $ltp1Data['numbers'],
        'bonus' => $ltp1Data['bonus'],
        'stats' => $ltp1Data['stats'],
        'analytics' => $ltp1Stats,
        'rules' => ['max_num' => 52, 'draw_size' => 6, 'has_bonus' => true, 'bonus_max' => 52]
    ],
    'lottoplus2' => [
        'id' => 'lottoplus2',
        'slug' => 'lotto-plus-2',
        'name' => 'Lotto Plus 2',
        'date' => $ltp2Data['date'],
        'draw_number' => $ltp2Data['draw_number'],
        'next_draw' => getNextDraw('lottoplus2'),
        'last_updated' => $ltp2Data['last_updated'],
        'jackpot' => $ltp2Data['jackpot'],
        'numbers' => $ltp2Data['numbers'],
        'bonus' => $ltp2Data['bonus'],
        'stats' => $ltp2Data['stats'],
        'analytics' => $ltp2Stats,
        'rules' => ['max_num' => 52, 'draw_size' => 6, 'has_bonus' => true, 'bonus_max' => 52]
    ],
    'dailylotto' => [
        'id' => 'dailylotto',
        'slug' => 'daily-lotto',
        'name' => 'Daily Lotto',
        'date' => $dlData['date'],
        'draw_number' => $dlData['draw_number'],
        'next_draw' => getNextDraw('dailylotto'),
        'last_updated' => $dlData['last_updated'],
        'jackpot' => $dlData['jackpot'],
        'numbers' => $dlData['numbers'],
        'bonus' => $dlData['bonus'],
        'stats' => $dlData['stats'],
        'analytics' => $dlStats,
        'rules' => ['max_num' => 36, 'draw_size' => 5, 'has_bonus' => false, 'bonus_max' => 0]
    ]
];
$jsonData = json_encode($lotteryData);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Latest South African lottery results today for PowerBall, Lotto and Daily Lotto. View winning numbers, jackpots, hot & cold numbers and historical results updated after every draw.">
    <meta name="keywords" content="SA lottery results, PowerBall results, Lotto results, Daily Lotto results, South Africa lottery, hot numbers, cold numbers, lottery analytics, lottery predictions, PowerBall jackpot">
    <meta name="robots" content="index, follow">
    <title><?php echo $pageTitle; ?></title>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebSite",
      "name": "NextDrawLogic",
      "url": "https://nextdrawlogic.com",
      "potentialAction": {
        "@type": "SearchAction",
        "target": "https://nextdrawlogic.com/search?q={search_term_string}",
        "query-input": "required name=search_term_string"
      }
    }
    </script>
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "What time is the Daily Lotto draw in South Africa?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "The Daily Lotto draw takes place every day at 20:30 SA time."
          }
        },
        {
          "@type": "Question",
          "name": "Where can I check PowerBall results?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "You can check the latest PowerBall results on NextDrawLogic immediately after each draw is concluded and verified."
          }
        },
        {
          "@type": "Question",
          "name": "Are these lottery results official?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "All results are verified using official Ithuba data sources."
          }
        },
        {
          "@type": "Question",
          "name": "How do I claim my lottery winnings in South Africa?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Prizes up to R2,000 can be claimed at any participating retailer. Prizes up to R49,999 can be claimed at the post office, and larger jackpot amounts require a visit to an official Ithuba regional office."
          }
        },
        {
          "@type": "Question",
          "name": "What is the difference between Hot and Cold numbers?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Hot numbers are those drawn most frequently in recent draws, while Cold numbers have not appeared for a long time. Players use these statistics to make smarter, data-driven decisions."
          }
        },
        {
          "@type": "Question",
          "name": "Can I buy lottery tickets online?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "Yes, you can play safely online through the National Lottery website, major banking apps like FNB and Capitec, or trusted betting partners like Hollywoodbets."
          }
        }
      ]
    }
    </script>
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        <?php echo file_get_contents($_SERVER['DOCUMENT_ROOT'] . '/style/style.css'); ?>
        
        /* Modern UI Last Updated Badge */
        .last-updated-wrapper { text-align: center; margin-top: 10px; margin-bottom: 24px; }
        .last-updated-badge {
            display: inline-flex; align-items: center; background: #f8fafc; color: #64748b; font-size: 0.8rem; font-weight: 600; padding: 6px 14px; border-radius: 999px; border: 1px solid #e2e8f0; box-shadow: 0 1px 2px rgba(0,0,0,0.03); transition: all 0.2s ease;
        }
        .last-updated-badge:hover { background: #f1f5f9; color: #334155; border-color: #cbd5e1; }
        .last-updated-badge svg { width: 14px; height: 14px; margin-right: 6px; fill: currentColor; }

        /* SEO BLOCK STYLES */
        .seo-content-block { background: #ffffff; border-radius: 12px; padding: 24px 32px; margin-bottom: 32px; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-content-block h2 { font-size: 1.6rem; font-weight: 800; margin-top: 0; color: #0f172a; margin-bottom: 12px; }
        .seo-content-block h3 { font-size: 1.2rem; font-weight: 700; color: #1e293b; margin-top: 20px; margin-bottom: 10px; }
        .seo-content-block p { color: #475569; line-height: 1.6; font-size: 1.05rem; margin-bottom: 12px; }
        .seo-dynamic-text { margin-bottom: 24px; padding: 14px 20px; background: #f8fafc; border-left: 4px solid #3b82f6; border-radius: 6px; color: #334155; font-size: 1rem; }
        .trust-signal { color: #64748b; font-style: italic; font-size: 0.9rem; margin-top: 16px; border-top: 1px solid #f1f5f9; padding-top: 12px;}

        /* READ MORE TOGGLE STYLING */
        #seo-toggle-btn {
            color: #3b82f6;
            font-weight: 700;
            text-decoration: none;
            cursor: pointer;
            margin-left: 6px;
            transition: color 0.2s ease;
        }
        #seo-toggle-btn:hover { color: #2563eb; text-decoration: underline; }

        .faq-section { margin-top: 40px; margin-bottom: 40px; max-width: 100%; margin-left: auto; margin-right: auto;}
        .faq-header { font-size: 1.8rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; text-align: center; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #3b82f6; font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }section.faq-section {
    border-top: 1px solid #e0e6ed;
}
    </style>

</head>
<body>
    
<?php include __DIR__ . '/static/nav.php'; ?>
    <main class="container">
        <section class="hero">
            <h1>Latest South African Lottery Results Today (PowerBall, Lotto & Daily Lotto)</h1>
            <p>
                Real-time winning numbers, jackpot updates, hot &amp; cold trends and data-driven predictions for PowerBall, Lotto and Daily Lotto. Written and analysed by lottery experts who turn numbers into stories — and stories into smarter plays. 
                <a href="javascript:void(0)" id="seo-toggle-btn">Read More &darr;</a>
            </p>
        </section>

        <div id="seo-hidden-block" style="display: none;">
            <section class="seo-content-block">
                <h2>South African Lottery Results Today</h2>
                <p>Get the latest South African lottery results today for PowerBall, PowerBall Plus, Lotto, Lotto Plus 1, Lotto Plus 2 and Daily Lotto. Our platform provides real-time winning numbers, verified draw results, jackpot payouts and historical data.</p>
                <h3>Daily Updated Lottery Results</h3>
                <p>All results are updated immediately after each official Ithuba draw. Track Daily Lotto results, PowerBall jackpots, and Lotto payouts with advanced analytics including hot numbers, cold numbers and number frequency trends.</p>
                <div class="trust-signal">🔒 Data verified and securely sourced directly from official Ithuba National Lottery feeds.</div>
            </section>
        </div>

        <div class="grid">
            <section class="card" id="results-section">
                <h2 style="margin-bottom: 16px; font-size: 1.5rem;">Choose Your Game – Instant Results &amp; Analysis</h2>
                
                <div class="tabs-wrapper">
                    <div class="tabs" role="tablist" aria-label="Lottery Games">
                        <button class="tab-btn active" role="tab" aria-selected="true" aria-controls="dailylotto-content" onclick="switchTab('dailylotto', this)">Daily Lotto</button>
                        
                        <div class="dropdown-wrapper">
                            <button class="tab-btn" role="tab" aria-selected="false" aria-controls="powerball-content" onclick="switchTab('powerball', this)">PowerBall</button>
                            <div class="dropdown-content">
                                <button class="dropdown-btn" onclick="switchTab('powerballplus', this)">PowerBall Plus</button>
                            </div>
                        </div>
                        <div class="dropdown-wrapper">
                            <button class="tab-btn" role="tab" aria-selected="false" aria-controls="lotto-content" onclick="switchTab('lotto', this)">Lotto</button>
                            <div class="dropdown-content">
                                <button class="dropdown-btn" onclick="switchTab('lottoplus1', this)">Lotto Plus 1</button>
                                <button class="dropdown-btn" onclick="switchTab('lottoplus2', this)">Lotto Plus 2</button>
                            </div>
                        </div>
                    </div>
                </div>
            
                <?php foreach($lotteryData as $key => $data): ?>
                    <div id="<?php echo $key; ?>-content" role="tabpanel" tabindex="0" class="tab-content <?php echo $key === 'dailylotto' ? 'active' : ''; ?>">
                        
                        <div class="draw-header">
                            <span class="draw-date">
                                Last Draw: <?php echo $data['date']; ?> 
                                <?php if($data['draw_number'] !== 'N/A') echo '(#'.$data['draw_number'].')'; ?> 
                                | Next: <?php echo $data['next_draw']; ?>
                            </span>
                            <div class="status-dot" aria-label="Results verified by Ithuba"></div>
                        </div>

                        <div class="seo-dynamic-text">
                            Latest <strong><?php echo $data['name']; ?> results for <?php echo $data['date']; ?></strong>. Check winning numbers, jackpot payouts and historical trends for South Africa.
                        </div>
                        
                        <div class="last-updated-wrapper">
                            <div class="last-updated-badge">
                                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8zm.5-13H11v6l5.2 3.2.8-1.3-4.5-2.7V7z"/>
                                </svg>
                                Last updated: <?php echo $data['last_updated']; ?>
                            </div>
                        </div>
                        
                        <div class="jackpot-container">
                            <span class="jackpot-label">Latest Top Win Amount</span>
                            <div class="jackpot-display"><?php echo $data['jackpot']; ?></div>
                        </div>
            
                        <ul class="balls-row" aria-label="Winning Numbers">
                            <?php foreach($data['numbers'] as $num): ?>
                                <li class="ball"><?php echo htmlspecialchars((string)$num); ?></li>
                            <?php endforeach; ?>
                            
                            <?php if($data['bonus']): ?>
                                <li class="ball bonus" aria-label="Bonus Ball"><?php echo htmlspecialchars((string)$data['bonus']); ?></li>
                            <?php endif; ?>
                        </ul>
            
                        <div class="advanced-stats">
                            <div class="stat-box">
                                <div class="stat-lbl">Odd / Even Split</div>
                                <div class="stat-val"><?php echo $data['stats']['odd_even']; ?></div>
                            </div>
                            <div class="stat-box">
                                <div class="stat-lbl">High / Low Split</div>
                                <div class="stat-val"><?php echo $data['stats']['high_low']; ?></div>
                            </div>
                        </div>
                        
                    </div>
                <?php endforeach; ?>
                
                <a href="/results/daily-lotto/history/" id="dynamic-history-link" class="btn btn-outline" style="text-align:center;">
                    View Full <?php echo $lotteryData['dailylotto']['name']; ?> Results History &amp; Archive
                </a>
                
                <p style="margin-top: 24px; font-size: 0.95rem; color: var(--text-muted); line-height: 1.6;">
                            🔒 Verified results from official <a href="https://www.nationallottery.co.za/home" target="_blank" rel="noopener noreferrer" style="text-decoration:underline; color:inherit;">South African National Lottery</a> data. Updated after every draw.
                        </p>
            </section>
            
            <aside>
                <div class="card" style="margin-bottom: 24px;">
                    <div class="sidebar-header">
                        <h2>Hot &amp; Cold Trends</h2>
                        <span id="dynamic-sidebar-label" class="dynamic-game-label">Daily Lotto</span>
                    </div>
                    
                    <div class="utility-row">
                        <span class="utility-label">Hot Numbers</span>
                        <ul class="mini-balls" id="dyn-hot-numbers" aria-label="Hot Numbers"></ul>
                    </div>
                    <div class="utility-row">
                        <span class="utility-label">Cold Numbers</span>
                        <ul class="mini-balls" id="dyn-cold-numbers" aria-label="Cold Numbers"></ul>
                    </div>
                    <div class="utility-row">
                        <span class="utility-label">Most Frequent Pairs</span>
                        <div style="display: flex; gap: 8px;" id="dyn-frequent-pairs" aria-label="Frequent Pairs"></div>
                    </div>
                </div>
                
                <div class="generator-box" id="generator">
                    <h3>Smart Algorithm Number Generator</h3>
                    <p class="gen-desc">Our data team’s proprietary algorithm — built from over 100 past SA lottery draws — tailors every pick specifically to <span id="dyn-gen-label">Daily Lotto</span>. No guesswork. Just smarter plays.</p>
                    
                    <div class="gen-result" id="generated-numbers" aria-live="polite">
                        <div class="gen-ball">-</div>
                        <div class="gen-ball">-</div>
                        <div class="gen-ball">-</div>
                        <div class="gen-ball">-</div>
                        <div class="gen-ball">-</div>
                    </div>
                    
                    <button class="btn btn-gold" id="generate-btn" onclick="generateTicket()">Generate My Algorithm Pick</button>
                </div>
            </aside>
        </div>

        <h2 class="pw-hp" style="margin-bottom: 24px; font-size: 1.6rem; font-weight: 800; text-align: center;">More Tools to Play Smarter</h2>

        <section class="features-grid">
            <div class="card feature-card">
                <div class="feature-icon">🔥</div>
                <h3>Hot &amp; Cold Tracker</h3>
                <p>Track the most and least frequently drawn numbers across all major SA games.</p>
                <a href="/hot-numbers/" class="btn btn-outline" style="padding: 10px 20px; font-size: 0.95rem;">View Stats</a>
            </div>
            
            <div class="card feature-card">
                <div class="feature-icon">🤖</div>
                <h3>Smart Predictions</h3>
                <p>Get weekly data-driven predictions generated by our proprietary algorithm.</p>
                <a href="/predictions/" class="btn btn-outline" style="padding: 10px 20px; font-size: 0.95rem;">Get Picks</a>
            </div>
            
            <div class="card feature-card">
                <div class="feature-icon">✅</div>
                <h3>Smart Ticket Checker</h3>
                <p>Did you win? Instantly verify your lucky numbers against our historical database.</p>
                <a href="/check-tickets/" class="btn btn-outline" style="padding: 10px 20px; font-size: 0.95rem;">Check Numbers</a>
            </div>
            
            <!--<div class="card feature-card">-->
            <!--    <div class="feature-icon">🎟️</div>-->
            <!--    <h3>Play Lucky Numbers</h3>-->
            <!--    <p>Bet on the outcome of your favorite lotteries securely via our trusted partners.</p>-->
            <!--    <a href="https://affiliates.hollywoodbets.net/" target="_blank" rel="noopener nofollow" class="btn btn-gold" style="padding: 10px 20px; font-size: 0.95rem;">Bet Now</a>-->
            <!--</div>-->
            
            <div class="card feature-card">
                <div class="feature-icon">☁️</div>
                <h3>SA Dream Guide</h3>
                <p>Translate your dreams into lucky numbers using our traditional SA Fafi guide.</p>
                <a href="/fafi-dream-guide/" class="btn btn-outline" style="padding: 10px 20px; font-size: 0.95rem;">Find Your Numbers</a>
            </div>
        </section>

        <section class="faq-section">
            <h2 class="faq-header">Frequently Asked Questions</h2>
            <div class="faq-list">
                <div class="faq-item">
                    <button class="faq-question">What time is the Daily Lotto draw in South Africa?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>The Daily Lotto draw takes place every day at 20:30 SA time.</p></div></div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">Where can I check PowerBall results?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>You can check the latest PowerBall results on NextDrawLogic immediately after each draw is concluded and verified.</p></div></div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">Are these lottery results official?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>All results are verified using official Ithuba data sources to ensure complete accuracy for our players.</p></div></div>
                </div>
                
                <div class="faq-item">
                    <button class="faq-question">How do I claim my lottery winnings in South Africa?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>Prizes up to R2,000 can be claimed at any participating retailer. Prizes up to R49,999 can be claimed at the post office, and larger jackpot amounts require a visit to an official Ithuba regional office.</p></div></div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">What is the difference between Hot and Cold numbers?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>Hot numbers are those drawn most frequently in recent draws, while Cold numbers have not appeared for a long time. Players use these statistics to make smarter, data-driven decisions.</p></div></div>
                </div>
                <div class="faq-item">
                    <button class="faq-question">Can I buy lottery tickets online?<span class="faq-icon">+</span></button>
                    <div class="faq-answer"><div class="faq-answer-inner"><p>Yes, you can play safely online through the National Lottery website, major banking apps like FNB and Capitec, or trusted betting partners like Hollywoodbets.</p></div></div>
                </div>
            </div>
        </section>

    </main>

    <?php include __DIR__ . '/static/footer.php'; ?>

    <script>
        // High-Performance Data Injection
        const appData = <?php echo $jsonData; ?>;
        let currentGame = 'dailylotto';
        let isGenerating = false;

        const renderMiniBalls = (numbers, type) => numbers.map(num => `<li class="mini-ball ${type}">${num}</li>`).join('');
        const renderPairs = (pairs) => pairs.map(pair => `<span class="pair-badge">${pair}</span>`).join('');

        function switchTab(gameId, btnElement) {
            if(isGenerating) return;
            currentGame = gameId;
            const data = appData[gameId];

            // Update tab states
            document.querySelectorAll('.tab-btn, .dropdown-btn').forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            });
            btnElement.classList.add('active');
            btnElement.setAttribute('aria-selected', 'true');
            
            const parentWrapper = btnElement.closest('.dropdown-wrapper');
            if (parentWrapper) {
                const parentTabBtn = parentWrapper.querySelector('.tab-btn');
                if (parentTabBtn) parentTabBtn.classList.add('active');
            }

            // Toggle content
            document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
            document.getElementById(`${gameId}-content`).classList.add('active');

            // Dynamic SEO-friendly updates
            const historyUrl = `/results/${data.slug}/history/`;
            
            document.getElementById('dynamic-history-link').href = historyUrl;
            document.getElementById('dynamic-history-link').innerText = `View Full ${data.name} Results History & Archive`;
            document.getElementById('dynamic-sidebar-label').innerText = data.name;
            document.getElementById('dyn-gen-label').innerText = data.name;

            // Populate analytics
            document.getElementById('dyn-hot-numbers').innerHTML = renderMiniBalls(data.analytics.hot, 'hot');
            document.getElementById('dyn-cold-numbers').innerHTML = renderMiniBalls(data.analytics.cold, 'cold');
            document.getElementById('dyn-frequent-pairs').innerHTML = renderPairs(data.analytics.pairs);

            resetGeneratorUI(data.rules.draw_size, data.rules.has_bonus);
        }

        function resetGeneratorUI(drawSize, hasBonus) {
            let html = '';
            for(let i = 0; i < drawSize; i++) html += `<div class="gen-ball">-</div>`;
            if(hasBonus) html += `<div class="gen-ball bonus-pick">-</div>`;
            document.getElementById('generated-numbers').innerHTML = html;
        }

        function generateTicket() {
            if(isGenerating) return;
            isGenerating = true;
            
            const btn = document.getElementById('generate-btn');
            const resultDiv = document.getElementById('generated-numbers');
            const rules = appData[currentGame].rules;
            const analyticsData = appData[currentGame].analytics;
            
            btn.innerText = "Analysing historical data…";
            btn.style.opacity = "0.7";
            
            let ticks = 0;
            const maxTicks = 22;
            
            const rollInterval = setInterval(() => {
                let tempHtml = '';
                for(let i = 0; i < rules.draw_size; i++) {
                    const rand = Math.floor(Math.random() * rules.max_num) + 1;
                    tempHtml += `<div class="gen-ball">${rand}</div>`;
                }
                if(rules.has_bonus) {
                    const randB = Math.floor(Math.random() * rules.bonus_max) + 1;
                    tempHtml += `<div class="gen-ball bonus-pick">${randB}</div>`;
                }
                resultDiv.innerHTML = tempHtml;
                ticks++;
                if(ticks >= maxTicks) {
                    clearInterval(rollInterval);
                    finalizeSmartTicket(rules, resultDiv, btn, analyticsData.smart_pool);
                }
            }, 55);
        }

        function finalizeSmartTicket(rules, resultDiv, btn, smartPool) {
            let numbers = [];
            let pool = (smartPool && smartPool.length >= rules.draw_size) ? [...smartPool] : [];

            while(numbers.length < rules.draw_size) {
                let r;
                if (pool.length > 0) {
                    let randIdx = Math.floor(Math.random() * pool.length);
                    r = pool[randIdx];
                    pool.splice(randIdx, 1); 
                } else {
                    r = Math.floor(Math.random() * rules.max_num) + 1;
                }
                
                if(numbers.indexOf(r) === -1) numbers.push(r);
            }
            numbers.sort((a,b) => a - b);
            
            let finalHtml = numbers.map(n => `<div class="gen-ball">${n}</div>`).join('');
            
            if(rules.has_bonus) {
                let bonusNum = Math.floor(Math.random() * rules.bonus_max) + 1;
                finalHtml += `<div class="gen-ball bonus-pick">${bonusNum}</div>`;
            }
            
            resultDiv.innerHTML = finalHtml;
            btn.innerText = "Generate My Algorithm Pick";
            btn.style.opacity = "1";
            isGenerating = false;
        }

        window.onload = () => {
            const defaultData = appData['dailylotto'];
            document.getElementById('dyn-hot-numbers').innerHTML = renderMiniBalls(defaultData.analytics.hot, 'hot');
            document.getElementById('dyn-cold-numbers').innerHTML = renderMiniBalls(defaultData.analytics.cold, 'cold');
            document.getElementById('dyn-frequent-pairs').innerHTML = renderPairs(defaultData.analytics.pairs);

            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });

            // "Read More" SEO Block Toggle Logic
            const seoToggleBtn = document.getElementById('seo-toggle-btn');
            const seoHiddenBlock = document.getElementById('seo-hidden-block');

            if(seoToggleBtn && seoHiddenBlock) {
                seoToggleBtn.addEventListener('click', function() {
                    if(seoHiddenBlock.style.display === 'none') {
                        seoHiddenBlock.style.display = 'block';
                        this.innerHTML = 'Read Less &uarr;';
                    } else {
                        seoHiddenBlock.style.display = 'none';
                        this.innerHTML = 'Read More &darr;';
                    }
                });
            }
        };
    </script>
</body>
</html>