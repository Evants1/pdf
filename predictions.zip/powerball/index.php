<?php
// ============================================================
// NEXTDRAWLOGIC — SA PowerBall Predictions Page
// Optimized for SEO, CTR, and rich snippet eligibility
// ============================================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

require_once __DIR__ . '/../../db.php';

// --- DETERMINE NEXT DRAW DATE (Tue & Fri) ---
$currentTime   = time();
$todayName     = date('l');
$drawTimeToday = strtotime('today 21:00:00');

if (($todayName === 'Tuesday' || $todayName === 'Friday') && $currentTime <= $drawTimeToday) {
    $nextDrawTimestamp = strtotime('today');
} else {
    $nextTue = strtotime('next Tuesday');
    $nextFri = strtotime('next Friday');
    $nextDrawTimestamp = min($nextTue, $nextFri);
}

$nextDrawDate      = date('Y-m-d', $nextDrawTimestamp);
$nextDrawFormatted = date('d F Y', $nextDrawTimestamp);
$nextDrawDay       = date('l', $nextDrawTimestamp);

// --- FETCH LAST 50 DRAWS FOR ANALYSIS ---
$analyzeLimit = 50;
$stmt = $pdo->prepare("SELECT ball_1, ball_2, ball_3, ball_4, ball_5, powerball, draw_date
                        FROM powerball_results
                        ORDER BY draw_date DESC
                        LIMIT :limit");
$stmt->bindValue(':limit', $analyzeLimit, PDO::PARAM_INT);
$stmt->execute();
$historyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Latest date (for slug / freshness)
if (!empty($historyResults) && isset($historyResults[0]['draw_date'])) {
    $latestDate = $historyResults[0]['draw_date'];
} else {
    $latestDate = date('Y-m-d');
}

$slug                = strtolower(str_replace(' ', '-', date('d-F-Y', strtotime($latestDate))));
$latestDateFormatted = date('d M Y', strtotime($latestDate));

// --- FREQUENCY & TRACKING ---
$numberFrequency = array_fill(1, 50, 0);
$pbFrequency     = array_fill(1, 20, 0);
$lastSeen        = array_fill(1, 50, null);
$pairCounts      = [];
$tripletCounts   = [];

foreach ($historyResults as $draw) {
    $drawDate    = $draw['draw_date'];
    $ballsInDraw = [];

    for ($i = 1; $i <= 5; $i++) {
        $ball = (int)$draw['ball_' . $i];
        if ($ball >= 1 && $ball <= 50) {
            $numberFrequency[$ball]++;
            $ballsInDraw[] = $ball;
            if ($lastSeen[$ball] === null || $drawDate > $lastSeen[$ball]) {
                $lastSeen[$ball] = $drawDate;
            }
        }
    }

    $pb = (int)$draw['powerball'];
    if ($pb >= 1 && $pb <= 20) {
        $pbFrequency[$pb]++;
    }

    sort($ballsInDraw);
    $len = count($ballsInDraw);

    if ($len >= 2) {
        for ($i = 0; $i < $len - 1; $i++)
            for ($j = $i + 1; $j < $len; $j++) {
                $key = $ballsInDraw[$i] . ',' . $ballsInDraw[$j];
                $pairCounts[$key] = ($pairCounts[$key] ?? 0) + 1;
            }
    }

    if ($len >= 3) {
        for ($i = 0; $i < $len - 2; $i++)
            for ($j = $i + 1; $j < $len - 1; $j++)
                for ($k = $j + 1; $k < $len; $k++) {
                    $key = $ballsInDraw[$i] . ',' . $ballsInDraw[$j] . ',' . $ballsInDraw[$k];
                    $tripletCounts[$key] = ($tripletCounts[$key] ?? 0) + 1;
                }
    }
}

// --- SORT & SLICE ---
arsort($numberFrequency);
$hotNumbersAll = array_keys($numberFrequency);
$coldNumbersAll = array_reverse($hotNumbersAll);

arsort($pbFrequency);
$hotPbAll  = array_keys($pbFrequency);
$coldPbAll = array_reverse($hotPbAll);

arsort($pairCounts);
arsort($tripletCounts);
$topPairs    = array_slice($pairCounts, 0, 4, true);
$topTriplets = array_slice($tripletCounts, 0, 3, true);

$topHot    = array_slice($hotNumbersAll, 0, 5);
$topCold   = array_slice($coldNumbersAll, 0, 5);
$midNumbers = array_slice($hotNumbersAll, 20, 10);
shuffle($midNumbers);

$hotPb  = $hotPbAll[0];
$coldPb = $coldPbAll[0];
$midPbArray = array_slice($hotPbAll, 5, 10);
shuffle($midPbArray);
$midPb = $midPbArray[0];

// --- BUILD PREDICTION SETS ---
$set1_main = array_merge(array_slice($topHot, 0, 2), array_slice($topCold, 0, 2), array_slice($midNumbers, 0, 1));
sort($set1_main);
$set1_pb = $midPb;

$set2_main = $topHot;
sort($set2_main);
$set2_pb = $hotPb;

$set3_main = $topCold;
sort($set3_main);
$set3_pb = $coldPb;

// --- HISTORICAL MATCH ACCURACY ---
$match1 = $match2 = $match3 = 0;
$latestDraw  = $historyResults[0] ?? null;
$latestBalls = [];

if (count($historyResults) > 1 && $latestDraw) {
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($latestDraw['ball_' . $i])) $latestBalls[] = (int)$latestDraw['ball_' . $i];
    }

    $yDraws = array_slice($historyResults, 1, 50);
    $yFreq  = array_fill(1, 50, 0);
    foreach ($yDraws as $d)
        for ($i = 1; $i <= 5; $i++) $yFreq[(int)$d['ball_'.$i]]++;

    arsort($yFreq);
    $yHot  = array_keys($yFreq);
    $yCold = array_reverse($yHot);

    $ySet1 = array_merge(array_slice($yHot, 0, 2), array_slice($yCold, 0, 2), array_slice($yHot, 20, 1));
    $ySet2 = array_slice($yHot, 0, 5);
    $ySet3 = array_slice($yCold, 0, 5);

    $match1 = count(array_intersect($ySet1, $latestBalls));
    $match2 = count(array_intersect($ySet2, $latestBalls));
    $match3 = count(array_intersect($ySet3, $latestBalls));
}

// --- PREVIOUS DRAW BADGE HTML ---
$latestDrawMatchesHTML = '';
if ($latestDraw && !empty($latestBalls)) {
    $latestBonus = (int)$latestDraw['powerball'];
    $matchElements = [];

    foreach ($latestBalls as $b) {
        if (in_array($b, array_slice($hotNumbersAll, 0, 10)))
            $matchElements[] = "<span class='acc-badge acc-hot'>$b <em>Hot</em></span>";
        elseif (in_array($b, array_slice($coldNumbersAll, 0, 10)))
            $matchElements[] = "<span class='acc-badge acc-cold'>$b <em>Cold</em></span>";
        elseif (in_array($b, array_slice($hotNumbersAll, 10, 15)))
            $matchElements[] = "<span class='acc-badge acc-warm'>$b <em>Warm</em></span>";
        else
            $matchElements[] = "<span class='acc-badge acc-neutral'>$b</span>";
    }

    $pbClass = ($latestBonus == $hotPb) ? 'acc-hot-pb' : (($latestBonus == $coldPb) ? 'acc-cold-pb' : 'acc-neutral-pb');
    $pbLabel = ($latestBonus == $hotPb) ? ' Hot' : (($latestBonus == $coldPb) ? ' Cold' : '');
    $matchElements[] = "<span class='acc-badge $pbClass'>PB: $latestBonus$pbLabel</span>";

    $latestDrawMatchesHTML = implode('', $matchElements);
}

// --- CHART DATA (Top 10 Hot) ---
$chartLabels = array_slice($hotNumbersAll, 0, 10);
$chartData   = [];
foreach ($chartLabels as $num) $chartData[] = $numberFrequency[$num];

// --- METADATA ---
$lastUpdatedText   = date('F j, Y \a\t g:i A');
$pageTitle         = "SA PowerBall Predictions " . date('Y') . " | Hot Numbers & Smart Picks";
$metaDesc          = "South Africa PowerBall Predictions Today based on the last 50 draws. Hot &amp; cold numbers, smart picks, and overdue stats for Tuesday &amp; Friday draws at 21:00 SAST.";
$currentUrl        = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home",        "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Predictions", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/predictions/"],
    ["name" => "PowerBall",   "url" => $currentUrl],
];

// --- FAQs (strict PowerBall main draw only) ---
$pageFaqs = [
    [
        "question" => "How are the SA PowerBall predictions generated?",
        "answer"   => "Our algorithm analyses the last 50 official South African PowerBall draws using a dual-matrix approach: one frequency model for the main 5/50 ball pool and a separate model for the 1/20 PowerBall pool. Hot numbers (high frequency) and cold numbers (overdue) are identified independently for each pool, then blended into three distinct prediction strategies."
    ],
    [
        "question" => "What is the difference between hot and cold numbers in SA PowerBall?",
        "answer"   => "Hot numbers are those drawn most often in recent draws — they show a statistical tendency to appear. Cold (overdue) numbers have not been drawn for an above-average number of draws and are considered statistically due. Our Balanced Strategy mixes both to cover a wider probability range."
    ],
    [
        "question" => "When does the South African PowerBall draw take place?",
        "answer"   => "The official SA PowerBall draw takes place every Tuesday and Friday at 21:00 SAST (South African Standard Time), operated by Ithuba Holdings under licence from the National Lottery Commission."
    ],
    [
        "question" => "Can PowerBall predictions guarantee a win?",
        "answer"   => "No. PowerBall is a game of chance and every draw is statistically independent. Our predictions are data-driven tools designed to inform your number selection — not to guarantee any outcome. Always play responsibly and within your means."
    ],
    [
        "question" => "Why is the PowerBall analysed separately from the main numbers?",
        "answer"   => "The PowerBall is drawn from a completely separate drum containing only 20 balls, compared to 50 in the main draw. Mixing the two probability pools into a single frequency model would produce inaccurate results. Our system maintains two independent statistical models to give you the most precise hot and cold readings for each pool."
    ],
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">

    <meta property="og:title"        content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:url"         content="<?php echo $currentUrl; ?>">
    <meta property="og:type"        content="website">
    <meta property="og:image"       content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/og-powerball-predictions.jpg">
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo $metaDesc; ?>">
    <meta name="twitter:image"       content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/og-powerball-predictions.jpg">

    <link rel="preload" href="/style/style.css" as="style" onload="this.rel='stylesheet'">
    <noscript><link rel="stylesheet" href="/style/style.css"></noscript>
    <meta name="theme-color" content="#c0182e">
    <link rel="icon" type="image/webp" href="/images/next_draw_logic_favicon.webp">
    <link rel="alternate" hreflang="en-za" href="<?php echo $currentUrl; ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700;800;900&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">

    <script src="https://cdn.jsdelivr.net/npm/chart.js" defer></script>

    <!-- =====================================================================
         PAGE STYLES
         ===================================================================== -->
    <style>
        /* ── TOKENS ── */
        :root {
            --red:        #c0182e;
            --red-dark:   #8b0d1e;
            --red-light:  #fdf1f3;
            --red-border: #f3bcc5;
            --navy:       #0d1b2a;
            --navy-mid:   #1c2f44;
            --slate:      #455a72;
            --muted:      #6b8099;
            --border:     #dde5ef;
            --bg:         #f4f7fb;
            --white:      #ffffff;
            --gold:       #e8a020;
            --gold-bg:    #fdf8ee;
            --green:      #0d9963;
            --green-bg:   #e9faf3;
            --blue:       #1a6dc4;
            --blue-bg:    #eaf3fd;

            --radius-sm:  6px;
            --radius-md:  10px;
            --radius-lg:  16px;
            --radius-xl:  24px;

            --font-display: 'Barlow Condensed', sans-serif;
            --font-body:    'DM Sans', sans-serif;

            --shadow-xs: 0 1px 3px rgba(13,27,42,.06);
            --shadow-sm: 0 2px 8px rgba(13,27,42,.08);
            --shadow-md: 0 4px 16px rgba(13,27,42,.10);
            --shadow-lg: 0 8px 32px rgba(13,27,42,.12);
        }

        /* ── RESET ── */
        *, *::before, *::after { box-sizing: border-box; }
        /*body { margin: 0; font-family: var(--font-body); background: var(--bg); color: var(--navy); }*/

        /* ── LAYOUT ── */
        .page-container   { max-width: 1340px; margin: 0 auto; padding: 0 20px; }
        .layout-two-col  {
            display: grid;
            grid-template-columns: minmax(0,1fr) 272px;
            gap: 36px;
            align-items: start;
            margin-top: 28px;
        }
        .content-col { min-width: 0; }

        .lotto-sidebar { position: sticky; top: 96px; }
        .sidebar-card  {
            background: var(--white);
            border-radius: var(--radius-lg);
            overflow: hidden;
            box-shadow: var(--shadow-md);
            border: 1px solid var(--border);
        }
        .sidebar-head {
            background: linear-gradient(135deg, var(--red), var(--red-dark));
            color: #fff;
            padding: 18px 22px;
            /*font-family: var(--font-display);*/
            font-size: 1.05rem;
            font-weight: 800;
            letter-spacing: .6px;
            text-transform: uppercase;
        }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f0f4f8; }
        .sidebar-links li:last-child { border-bottom: none; }
        .sidebar-links a {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px 22px;
            color: var(--slate);
            font-size: .92rem;
            font-weight: 600;
            text-decoration: none;
            border-left: 3px solid transparent;
            transition: all .18s ease;
        }
        .sidebar-links a:hover { background: var(--red-light); color: var(--red); border-left-color: var(--red-border); }
        .sidebar-links a.active { background: var(--red-light); color: var(--red); border-left-color: var(--red); font-weight: 800; }
        .sidebar-links a svg { width: 14px; height: 14px; opacity: .4; }

        /* Countdown widget in sidebar */
        .sidebar-countdown {
            margin: 16px 16px 4px;
            background: var(--navy);
            border-radius: var(--radius-md);
            padding: 16px 18px;
            color: #fff;
            text-align: center;
        }
        .sidebar-countdown .cd-label { font-size: .75rem; font-weight: 700; letter-spacing: .8px; text-transform: uppercase; opacity: .6; margin-bottom: 8px; }
        .sidebar-countdown #cd-inline { font-size: 1.5rem; font-weight: 800; letter-spacing: 1px; color: #fff; }
        .sidebar-countdown .cd-draw { font-size: .8rem; opacity: .55; margin-top: 6px; }

        .breadcrumb { padding: 14px 0 0; }
        .breadcrumb-list { display: flex; align-items: center; gap: 6px; list-style: none; margin: 0; padding: 0; flex-wrap: wrap; }
        .breadcrumb-item { display: flex; align-items: center; gap: 6px; font-size: .83rem; }
        .breadcrumb-item:not(:last-child)::after { content: '/'; color: var(--muted); opacity: .5; }
        .breadcrumb-link { color: var(--muted); text-decoration: none; }
        .breadcrumb-link:hover { color: var(--red); }
        .breadcrumb-current { color: var(--slate); font-weight: 600; }

        .hero-section {
            background: linear-gradient(160deg, var(--navy) 0%, var(--navy-mid) 100%);
            border-radius: var(--radius-xl);
            padding: 44px 48px;
            margin: 20px 0 32px;
            position: relative;
            overflow: hidden;
        }
        .hero-section::before {
            content: '';
            position: absolute; inset: 0;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Ccircle cx='30' cy='30' r='20'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
            pointer-events: none;
        }
        .hero-eyebrow {
            display: inline-flex; align-items: center; gap: 8px;
            background: rgba(192,24,46,.25);
            border: 1px solid rgba(192,24,46,.4);
            color: #ff8fa0;
            padding: 5px 14px;
            border-radius: 999px;
            font-size: .78rem;
            font-weight: 700;
            letter-spacing: .8px;
            text-transform: uppercase;
            margin-bottom: 16px;
        }
        .hero-eyebrow .pulse {
            width: 7px; height: 7px;
            background: #ff4466;
            border-radius: 50%;
            animation: pulse 2s infinite;
        }
        @keyframes pulse {
            0%   { box-shadow: 0 0 0 0 rgba(255,68,102,.5); }
            70%  { box-shadow: 0 0 0 8px rgba(255,68,102,0); }
            100% { box-shadow: 0 0 0 0 rgba(255,68,102,0); }
        }
        .hero-section h1 {
            /*font-family: var(--font-display);*/
            font-size: clamp(2rem, 4.5vw, 3rem);
            font-weight: 900;
            color: #fff;
            margin: 0 0 16px;
            line-height: 1.1;
            letter-spacing: -.5px;
        }
        .hero-section h1 span { color: #ff8fa0; }
        .hero-lead {
            font-size: 1rem;
            color: rgba(255,255,255,.7);
            line-height: 1.65;
            max-width: 640px;
            margin: 0;
        }
        .hero-lead strong { color: #fff; }
        .hero-meta {
            display: flex; flex-wrap: wrap; gap: 12px;
            margin-top: 28px;
        }
        .hero-badge {
            display: inline-flex; align-items: center; gap: 7px;
            background: rgba(255,255,255,.08);
            border: 1px solid rgba(255,255,255,.12);
            color: rgba(255,255,255,.8);
            padding: 8px 14px;
            border-radius: var(--radius-sm);
            font-size: .83rem;
            font-weight: 600;
        }
        .hero-badge svg { width: 14px; height: 14px; opacity: .7; }

        .section-label {
            display: flex; align-items: center; gap: 10px;
            /*font-family: var(--font-display);*/
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: 1.2px;
            text-transform: uppercase;
            color: var(--red);
            margin-bottom: 14px;
        }
        .section-label::after { content: ''; flex: 1; height: 1px; background: var(--border); }

        .panel {
            background: var(--white);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-xs);
            overflow: hidden;
        }
        .panel + .panel { margin-top: 24px; }
        .panel-pad { padding: 28px 30px; }

        .recent-draws-panel .panel-head {
            padding: 18px 24px;
            border-bottom: 1px solid var(--border);
            display: flex; align-items: center; justify-content: space-between;
        }
        .recent-draws-panel .panel-head h2 {
            margin: 0;
            font-size: 1.05rem;
            font-weight: 800;
            color: var(--navy);
        }
        .recent-draws-panel .panel-head .draws-count {
            font-size: .78rem;
            font-weight: 700;
            color: var(--muted);
            background: var(--bg);
            padding: 4px 10px;
            border-radius: 999px;
            border: 1px solid var(--border);
        }
        .draw-row {
            display: flex; align-items: center; justify-content: space-between;
            padding: 14px 24px;
            border-bottom: 1px solid #f2f5f9;
            transition: background .15s;
        }
        .draw-row:last-child { border-bottom: none; }
        .draw-row:hover { background: #fafcff; }
        .draw-row-date { font-size: .88rem; font-weight: 700; color: var(--slate); min-width: 90px; }
        .draw-balls { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
        .d-ball {
            width: 32px; height: 32px;
            border-radius: 50%;
            background: var(--bg);
            border: 1.5px solid var(--border);
            display: flex; align-items: center; justify-content: center;
            font-size: .82rem;
            font-weight: 800;
            color: var(--navy-mid);
        }
        .d-ball.pb {
            background: var(--red);
            border-color: var(--red-dark);
            color: #fff;
        }
        .d-ball-sep {
            width: 1px; height: 28px;
            background: var(--border);
            margin: 0 4px;
        }

        .predictions-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 20px;
            margin: 0 0 32px;
        }
        .pred-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-sm);
            overflow: hidden;
            display: flex; flex-direction: column;
            transition: transform .2s, box-shadow .2s;
        }
        .pred-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); }
        .pred-card-stripe { height: 5px; }
        .stripe-green { background: linear-gradient(90deg, #0d9963, #06c17a); }
        .stripe-red   { background: linear-gradient(90deg, #c0182e, #e85a6a); }
        .stripe-blue  { background: linear-gradient(90deg, #1a6dc4, #3d9ae8); }
        .pred-card-body { padding: 24px 26px; flex: 1; display: flex; flex-direction: column; }
        .pred-card-label {
            display: inline-flex; align-items: center; gap: 8px;
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .9px;
            text-transform: uppercase;
            margin-bottom: 10px;
        }
        .label-green { color: var(--green); }
        .label-red   { color: var(--red); }
        .label-blue  { color: var(--blue); }
        .pred-card-title {
            /*font-family: var(--font-display);*/
            font-size: 1.3rem;
            font-weight: 800;
            color: var(--navy);
            margin: 0 0 16px;
            line-height: 1.2;
        }
        .match-pill {
            display: inline-flex; align-items: center; gap: 6px;
            font-size: .78rem;
            font-weight: 700;
            padding: 4px 10px;
            border-radius: 999px;
            margin-bottom: 18px;
            border: 1px solid;
        }
        .match-neutral { background: #f1f5f9; color: var(--slate); border-color: var(--border); }
        .match-success { background: var(--green-bg); color: var(--green); border-color: #a3dfc7; }
        .balls-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 18px; align-items: center; }
        .lotto-ball {
            width: 44px; height: 44px;
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            /*font-family: var(--font-display);*/
            font-size: 1.05rem;
            font-weight: 800;
            border: 2px solid var(--border);
            background: var(--bg);
            color: var(--navy-mid);
            box-shadow: inset 0 -2px 4px rgba(0,0,0,.04);
            transition: transform .15s;
        }
        .lotto-ball:hover { transform: scale(1.1); }
        .lotto-ball.hot  { background: #fff0f2; border-color: #ffb3be; color: var(--red); }
        .lotto-ball.cold { background: var(--blue-bg); border-color: #9ecdf5; color: var(--blue); }
        .lotto-ball.pb   { background: var(--red); border-color: var(--red-dark); color: #fff; }
        .lotto-ball.pb.hot  { background: var(--red-dark); }
        .lotto-ball.pb.cold { background: var(--blue); border-color: #1558a3; }
        .pb-divider { width: 1.5px; height: 36px; background: var(--border); margin: 0 4px; }
        .pred-logic {
            margin: 0;
            font-size: .88rem;
            color: var(--slate);
            line-height: 1.55;
            padding: 12px 14px;
            background: var(--bg);
            border-radius: var(--radius-sm);
            border-left: 3px solid var(--border);
            margin-top: auto;
        }

        .accuracy-panel {
            background: linear-gradient(135deg, #fdfbff, #f6f3ff);
            border: 1px solid #e8e0ff;
            border-left: 4px solid #7c4dff;
            border-radius: var(--radius-md);
            padding: 22px 26px;
            margin-bottom: 28px;
        }
        .accuracy-panel h3 {
            margin: 0 0 6px;
            font-size: 1rem;
            font-weight: 800;
            color: var(--navy);
            display: flex; align-items: center; gap: 8px;
        }
        .accuracy-panel p { margin: 0 0 14px; font-size: .88rem; color: var(--slate); }
        .acc-badges { display: flex; flex-wrap: wrap; gap: 8px; }
        .acc-badge {
            padding: 5px 12px;
            border-radius: var(--radius-sm);
            font-size: .88rem;
            font-weight: 700;
            border: 1.5px solid;
            display: inline-flex; align-items: center; gap: 5px;
        }
        .acc-badge em { font-style: normal; font-size: .72rem; opacity: .75; }
        .acc-hot  { background: #fff0f2; color: #b91c1c; border-color: #ffb3be; }
        .acc-cold { background: var(--blue-bg); color: var(--blue); border-color: #9ecdf5; }
        .acc-warm { background: var(--gold-bg); color: #92400e; border-color: #fcd34d; }
        .acc-neutral { background: var(--bg); color: var(--slate); border-color: var(--border); }
        .acc-hot-pb  { background: var(--red); color: #fff; border-color: var(--red-dark); }
        .acc-cold-pb { background: var(--blue); color: #fff; border-color: #1558a3; }
        .acc-neutral-pb { background: #1e293b; color: #fff; border-color: #0f172a; }

        .combos-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 32px;
        }
        .combo-panel { background: var(--white); border-radius: var(--radius-lg); border: 1px solid var(--border); box-shadow: var(--shadow-xs); overflow: hidden; }
        .combo-head {
            padding: 16px 22px;
            border-bottom: 1px solid var(--border);
            background: var(--bg);
        }
        .combo-head h3 { margin: 0; font-size: .95rem; font-weight: 800; color: var(--navy); display: flex; align-items: center; gap: 8px; }
        .combo-head p  { margin: 6px 0 0; font-size: .8rem; color: var(--muted); }
        .combo-list { list-style: none; padding: 0; margin: 0; }
        .combo-list li {
            display: flex; align-items: center; justify-content: space-between;
            padding: 12px 22px;
            border-bottom: 1px solid #f2f5f9;
        }
        .combo-list li:last-child { border-bottom: none; }
        .combo-balls { display: flex; gap: 6px; }
        .combo-ball {
            width: 30px; height: 30px;
            border-radius: 50%;
            background: var(--navy-mid);
            color: #fff;
            display: flex; align-items: center; justify-content: center;
            font-size: .8rem;
            font-weight: 800;
        }
        .combo-freq {
            font-size: .78rem;
            font-weight: 700;
            color: var(--muted);
            background: var(--bg);
            padding: 3px 9px;
            border-radius: 999px;
            border: 1px solid var(--border);
        }

        /* ── HOW IT WORKS ── */
        .how-it-works {
            background: var(--white);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            box-shadow: var(--shadow-xs);
            padding: 32px 34px;
            margin-bottom: 32px;
        }
        .how-it-works h2 {
            /*font-family: var(--font-display);*/
            font-size: 1.6rem;
            font-weight: 900;
            color: var(--navy);
            margin: 0 0 8px;
        }
        .how-it-works .subtitle { color: var(--slate); font-size: .95rem; line-height: 1.6; margin-bottom: 28px; }
        .steps-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 28px; }
        .step-card {
            background: var(--bg);
            border-radius: var(--radius-md);
            border: 1px solid var(--border);
            padding: 20px 18px;
        }
        .step-num {
            /*font-family: var(--font-display);*/
            font-size: 2rem;
            font-weight: 900;
            color: var(--red);
            opacity: .3;
            line-height: 1;
            margin-bottom: 8px;
        }
        .step-title { font-weight: 800; font-size: .92rem; color: var(--navy); margin-bottom: 6px; }
        .step-text  { font-size: .84rem; color: var(--slate); line-height: 1.5; margin: 0; }

        .matrix-callout {
            display: flex; align-items: stretch; gap: 0;
            border-radius: var(--radius-md);
            overflow: hidden;
            border: 1px solid var(--border);
            margin-bottom: 28px;
        }
        .matrix-col {
            flex: 1;
            padding: 20px 22px;
            background: var(--white);
        }
        .matrix-col + .matrix-col { border-left: 1px solid var(--border); background: var(--red-light); }
        .matrix-col-title {
            font-size: .72rem;
            font-weight: 800;
            letter-spacing: .9px;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 8px;
        }
        .matrix-col-val {
            /*font-family: var(--font-display);*/
            font-size: 2rem;
            font-weight: 900;
            color: var(--navy);
            line-height: 1;
            margin-bottom: 4px;
        }
        .matrix-col + .matrix-col .matrix-col-val { color: var(--red); }
        .matrix-col-desc { font-size: .83rem; color: var(--slate); }

        .tips-list { list-style: none; padding: 0; margin: 0; }
        .tips-list li {
            display: flex; align-items: flex-start; gap: 12px;
            padding: 12px 0;
            border-bottom: 1px dashed var(--border);
            font-size: .92rem;
            color: var(--slate);
            line-height: 1.5;
        }
        .tips-list li:last-child { border-bottom: none; }
        .tips-list .tip-icon {
            flex-shrink: 0;
            width: 22px; height: 22px;
            border-radius: 50%;
            background: var(--green-bg);
            border: 1.5px solid #a3dfc7;
            display: flex; align-items: center; justify-content: center;
            font-size: .72rem;
            margin-top: 1px;
        }

        .chart-panel { background: var(--white); border-radius: var(--radius-lg); border: 1px solid var(--border); padding: 28px 30px; margin-bottom: 32px; }
        .chart-panel h3 { font-size: 1.2rem; font-weight: 800; color: var(--navy); margin: 0 0 20px; }
        .chart-wrap { position: relative; height: 280px; }

        .faq-section { margin-bottom: 36px; }
        .faq-section h2 {
            /*font-family: var(--font-display);*/
            font-size: 1.6rem;
            font-weight: 900;
            color: var(--navy);
            margin: 0 0 6px;
            padding-left: 16px;
            border-left: 4px solid var(--red);
        }
        .faq-sub { font-size: .92rem; color: var(--slate); margin: 0 0 22px; }
        .faq-item {
            background: var(--white);
            border: 1px solid var(--border);
            border-radius: var(--radius-md);
            margin-bottom: 10px;
            overflow: hidden;
            transition: box-shadow .2s;
        }
        .faq-item.active { box-shadow: var(--shadow-sm); }
        .faq-question {
            width: 100%;
            text-align: left;
            background: transparent;
            border: none;
            padding: 18px 22px;
            font-size: .97rem;
            font-weight: 700;
            color: var(--navy);
            cursor: pointer;
            display: flex; justify-content: space-between; align-items: center;
            /*font-family: var(--font-body);*/
            gap: 12px;
        }
        .faq-question:hover { background: var(--bg); }
        .faq-icon {
            flex-shrink: 0;
            width: 24px; height: 24px;
            border-radius: 50%;
            background: var(--bg);
            border: 1.5px solid var(--border);
            display: flex; align-items: center; justify-content: center;
            font-size: 1rem;
            color: var(--red);
            font-weight: 400;
            transition: transform .25s, background .25s;
        }
        .faq-item.active .faq-icon { transform: rotate(45deg); background: var(--red); color: #fff; border-color: var(--red); }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height .3s ease; }
        .faq-item.active .faq-answer { max-height: 400px; }
        .faq-answer-inner {
            padding: 0 22px 18px 22px;
            font-size: .9rem;
            color: var(--slate);
            line-height: 1.65;
            border-top: 1px solid var(--border);
        }
        .faq-answer-inner p { margin: 14px 0 0; }

        .links-panel { background: var(--white); border-radius: var(--radius-lg); border: 1px solid var(--border); padding: 28px 30px; margin-bottom: 32px; }
        .links-panel h2 { font-size: 1.3rem; font-weight: 900; color: var(--navy); margin: 0 0 6px; }
        .links-panel p  { font-size: .88rem; color: var(--muted); margin: 0 0 20px; }
        .pill-links { display: flex; flex-wrap: wrap; gap: 10px; }
        .pill-link {
            display: inline-flex; align-items: center; gap: 8px;
            background: var(--bg);
            color: var(--slate);
            text-decoration: none;
            padding: 11px 18px;
            border-radius: 999px;
            font-size: .9rem;
            font-weight: 600;
            border: 1px solid var(--border);
            transition: all .2s;
        }
        .pill-link svg { width: 14px; height: 14px; color: var(--red); transition: transform .2s, color .2s; }
        .pill-link:hover { background: var(--red); color: #fff; border-color: var(--red); box-shadow: 0 4px 14px rgba(192,24,46,.2); }
        .pill-link:hover svg { color: #fff; transform: translateX(4px); }

        .tools-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; margin-bottom: 32px; }
        .tool-card {
            background: var(--white);
            border-radius: var(--radius-lg);
            border: 1px solid var(--border);
            padding: 24px 20px;
            box-shadow: var(--shadow-xs);
            transition: transform .2s, box-shadow .2s;
        }
        .tool-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
        .tool-icon { font-size: 2rem; margin-bottom: 14px; }
        .tool-card h3 { margin: 0 0 8px; font-size: 1rem; font-weight: 800; color: var(--navy); }
        .tool-card p  { margin: 0 0 16px; font-size: .84rem; color: var(--muted); line-height: 1.5; }
        .tool-link { font-size: .9rem; font-weight: 700; color: var(--red); text-decoration: none; }
        .tool-link:hover { text-decoration: underline; }

        .disclaimer {
            display: flex; align-items: flex-start; gap: 16px;
            background: #fafbfc;
            border: 1px solid var(--border);
            border-left: 3px solid #94a3b8;
            border-radius: var(--radius-md);
            padding: 22px 24px;
            margin-bottom: 12px;
        }
        .disclaimer svg { flex-shrink: 0; width: 20px; height: 20px; color: #94a3b8; margin-top: 2px; }
        .disclaimer-body strong { display: block; font-size: .7rem; font-weight: 800; text-transform: uppercase; letter-spacing: .9px; color: #94a3b8; margin-bottom: 6px; }
        .disclaimer-body p { margin: 0; font-size: .82rem; color: var(--muted); line-height: 1.6; }
        .disclaimer-body a { color: var(--blue); }

        .page-footer-note { text-align: center; font-size: .78rem; color: var(--muted); padding-bottom: 28px; }

        @media (max-width: 1080px) {
            .layout-two-col { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
        }
        @media (max-width: 768px) {
            .hero-section { padding: 30px 24px; }
            .combos-grid { grid-template-columns: 1fr; }
            .tools-grid  { grid-template-columns: 1fr; }
            .predictions-grid { grid-template-columns: 1fr; }
            .steps-grid  { grid-template-columns: 1fr 1fr; }
            .matrix-callout { flex-direction: column; }
            .matrix-col + .matrix-col { border-left: none; border-top: 1px solid var(--border); }
            .how-it-works { padding: 24px 20px; }
            .panel-pad { padding: 20px; }
        }
        @media (max-width: 480px) {
            .page-container { padding: 0 14px; }
            .steps-grid { grid-template-columns: 1fr; }
            .lotto-ball { width: 38px; height: 38px; font-size: .95rem; }
        }
    </style>


    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>


    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": "<?php echo addslashes($pageTitle); ?>",
      "description": "<?php echo addslashes($metaDesc); ?>",
      "author": { "@type": "Organization", "name": "NextDrawLogic" },
      "publisher": {
        "@type": "Organization",
        "name": "NextDrawLogic",
        "logo": { "@type": "ImageObject", "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/assets/logo.png" }
      },
      "datePublished": "<?php echo date('Y-m-d', strtotime($latestDate)); ?>",
      "dateModified": "<?php echo date('Y-m-d'); ?>",
      "mainEntityOfPage": { "@type": "WebPage", "@id": "<?php echo $currentUrl; ?>" }
    }
    </script>


    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $i => $crumb): ?>
        {
          "@type": "ListItem",
          "position": <?php echo $i + 1; ?>,
          "name": "<?php echo addslashes($crumb['name']); ?>",
          "item": "<?php echo $crumb['url']; ?>"
        }<?php echo $i < count($breadcrumbs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
</head>
<body>

<?php
$navPath = __DIR__ . '/../../static/nav.php';
if (file_exists($navPath)) { include $navPath; }
?>

<main class="page-container">

    <nav class="breadcrumb" aria-label="Breadcrumb">
        <ul class="breadcrumb-list">
            <?php foreach ($breadcrumbs as $index => $crumb): ?>
            <li class="breadcrumb-item">
                <?php if ($index !== array_key_last($breadcrumbs)): ?>
                    <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                <?php else: ?>
                    <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                <?php endif; ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </nav>

    <div class="layout-two-col">

        <div class="content-col">

            <!-- ── HERO ── -->
            <section class="hero-section" aria-label="Page introduction">
                <div class="hero-eyebrow">
                    <div class="pulse"></div>
                    Updated <?php echo $lastUpdatedText; ?>
                </div>

                <h1>SA PowerBall Predictions<br><span>for <?php echo $nextDrawFormatted; ?></span></h1>

                <p class="hero-lead">
                    Data-driven <strong>SA PowerBall predictions</strong> based on frequency analysis of the last <?php echo $analyzeLimit; ?> official draws.
                    Our algorithm independently models the <strong>5/50 main ball pool</strong> and the <strong>1/20 PowerBall pool</strong>
                    to surface today's hottest and most overdue numbers — giving you an informed edge every
                    <strong>Tuesday and Friday at&nbsp;21:00&nbsp;SAST</strong>.
                </p>

                <div class="hero-meta">
                    <div class="hero-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>
                        Next draw: <?php echo $nextDrawDay; ?>, <?php echo $nextDrawFormatted; ?>
                    </div>
                    <div class="hero-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>
                        Based on last <?php echo $analyzeLimit; ?> draws
                    </div>
                    <div class="hero-badge">
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
                        Draw at 21:00 SAST
                    </div>
                </div>
            </section>

            <?php if (count($historyResults) >= 5): ?>
            <section class="panel recent-draws-panel" aria-labelledby="recent-head" style="margin-bottom:24px;">
                <div class="panel-head">
                    <h2 id="recent-head">Recent SA PowerBall Results</h2>
                    <span class="draws-count">Last 5 draws</span>
                </div>
                <?php foreach (array_slice($historyResults, 0, 5) as $r): ?>
                <div class="draw-row">
                    <div class="draw-row-date"><?php echo date('d M Y', strtotime($r['draw_date'])); ?></div>
                    <div class="draw-balls">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <div class="d-ball"><?php echo (int)$r['ball_'.$i]; ?></div>
                        <?php endfor; ?>
                        <div class="d-ball-sep"></div>
                        <div class="d-ball pb" title="PowerBall"><?php echo (int)$r['powerball']; ?></div>
                    </div>
                </div>
                <?php endforeach; ?>
            </section>
            <?php endif; ?>

            <?php if ($latestDraw && !empty($latestBalls)): ?>
            <div class="accuracy-panel" role="region" aria-label="Prediction accuracy tracker">
                <h3>✅ Prediction Tracker — Previous Draw Analysis</h3>
                <p>How the most recent official draw mapped to our statistical tracking zones.</p>
                <div class="acc-badges">
                    <?php echo $latestDrawMatchesHTML; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="section-label">PowerBall Smart Picks — <?php echo $nextDrawFormatted; ?></div>

            <div class="predictions-grid" role="list">

                <article class="pred-card" role="listitem">
                    <div class="pred-card-stripe stripe-green"></div>
                    <div class="pred-card-body">
                        <div class="pred-card-label label-green">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
                            Recommended
                        </div>
                        <h3 class="pred-card-title">🎯 Balanced Strategy</h3>
                        <span class="match-pill <?php echo $match1 >= 2 ? 'match-success' : 'match-neutral'; ?>">
                            Last draw: <?php echo $match1; ?>/5 matched
                        </span>
                        <div class="balls-row" aria-label="Predicted main numbers and PowerBall">
                            <?php foreach ($set1_main as $num): ?>
                                <div class="lotto-ball" title="Main ball <?php echo $num; ?>"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="pb-divider" aria-hidden="true"></div>
                            <div class="lotto-ball pb" title="PowerBall <?php echo $set1_pb; ?>"><?php echo $set1_pb; ?></div>
                        </div>
                        <p class="pred-logic">
                            <strong>Logic:</strong> Mixes 2 hot numbers, 2 cold/overdue numbers, and 1 mid-range number with a median PowerBall. The most statistically balanced SA PowerBall smart pick.
                        </p>
                    </div>
                </article>

                <article class="pred-card" role="listitem">
                    <div class="pred-card-stripe stripe-red"></div>
                    <div class="pred-card-body">
                        <div class="pred-card-label label-red">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M12 2c0 6-6 8-6 14a6 6 0 0012 0c0-6-6-8-6-14z"/></svg>
                            Hot Numbers
                        </div>
                        <h3 class="pred-card-title">🔥 Hot Number Focus</h3>
                        <span class="match-pill <?php echo $match2 >= 2 ? 'match-success' : 'match-neutral'; ?>">
                            Last draw: <?php echo $match2; ?>/5 matched
                        </span>
                        <div class="balls-row" aria-label="Hot main numbers and hot PowerBall">
                            <?php foreach ($set2_main as $num): ?>
                                <div class="lotto-ball hot" title="Hot ball <?php echo $num; ?>"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="pb-divider" aria-hidden="true"></div>
                            <div class="lotto-ball pb hot" title="Hot PowerBall <?php echo $set2_pb; ?>"><?php echo $set2_pb; ?></div>
                        </div>
                        <p class="pred-logic">
                            <strong>Logic:</strong> The 5 most frequent PowerBall main numbers from the last <?php echo $analyzeLimit; ?> draws, paired with the hottest PowerBall. Ideal for momentum-based number selection.
                        </p>
                    </div>
                </article>

                <article class="pred-card" role="listitem">
                    <div class="pred-card-stripe stripe-blue"></div>
                    <div class="pred-card-body">
                        <div class="pred-card-label label-blue">
                            <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><path d="M2 12C2 6.48 6.48 2 12 2s10 4.48 10 10-4.48 10-10 10S2 17.52 2 12z"/><path d="M8 12l2 2 4-4"/></svg>
                            Overdue Numbers
                        </div>
                        <h3 class="pred-card-title">❄️ Cold / Overdue Strategy</h3>
                        <span class="match-pill <?php echo $match3 >= 2 ? 'match-success' : 'match-neutral'; ?>">
                            Last draw: <?php echo $match3; ?>/5 matched
                        </span>
                        <div class="balls-row" aria-label="Cold overdue main numbers and cold PowerBall">
                            <?php foreach ($set3_main as $num): ?>
                                <div class="lotto-ball cold" title="Cold ball <?php echo $num; ?>"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                            <div class="pb-divider" aria-hidden="true"></div>
                            <div class="lotto-ball pb cold" title="Cold PowerBall <?php echo $set3_pb; ?>"><?php echo $set3_pb; ?></div>
                        </div>
                        <p class="pred-logic">
                            <strong>Logic:</strong> Targets the 5 most statistically overdue main numbers, paired with the coldest PowerBall — the numbers that are due for a return based on long-run frequency analysis.
                        </p>
                    </div>
                </article>

            </div><!-- /predictions-grid -->

            <div class="section-label">Recurring Number Combinations</div>
            <div class="combos-grid">

                <div class="combo-panel">
                    <div class="combo-head">
                        <h3>🔗 Top Main Number Pairs</h3>
                        <p>Most common pairs in the main 5/50 pool</p>
                    </div>
                    <ul class="combo-list" aria-label="Top number pairs">
                        <?php foreach ($topPairs as $pairStr => $count): $nums = explode(',', $pairStr); ?>
                        <li>
                            <div class="combo-balls">
                                <div class="combo-ball"><?php echo $nums[0]; ?></div>
                                <div class="combo-ball"><?php echo $nums[1]; ?></div>
                            </div>
                            <span class="combo-freq">Drawn <?php echo $count; ?>× in <?php echo $analyzeLimit; ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <div class="combo-panel">
                    <div class="combo-head">
                        <h3>⚡ Top Main Number Triplets</h3>
                        <p>Most common triplets in the main 5/50 pool</p>
                    </div>
                    <ul class="combo-list" aria-label="Top number triplets">
                        <?php foreach ($topTriplets as $tripStr => $count): $nums = explode(',', $tripStr); ?>
                        <li>
                            <div class="combo-balls">
                                <div class="combo-ball"><?php echo $nums[0]; ?></div>
                                <div class="combo-ball"><?php echo $nums[1]; ?></div>
                                <div class="combo-ball"><?php echo $nums[2]; ?></div>
                            </div>
                            <span class="combo-freq">Drawn <?php echo $count; ?>× in <?php echo $analyzeLimit; ?></span>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

            </div><!-- /combos-grid -->

            <section class="how-it-works" aria-labelledby="how-head">
                <div class="section-label">Methodology</div>
                <h2 id="how-head">How Our SA PowerBall Prediction Algorithm Works</h2>
                <p class="subtitle">
                    Unlike random number generators, NextDrawLogic uses a structured, dual-pool statistical model.
                    Here is exactly what happens under the hood every time the page loads.
                </p>

                <div class="matrix-callout" role="region" aria-label="PowerBall matrix overview">
                    <div class="matrix-col">
                        <div class="matrix-col-title">Main Ball Pool</div>
                        <div class="matrix-col-val">5 / 50</div>
                        <div class="matrix-col-desc">5 balls drawn from a pool of 50. We track frequency, recency, and pairs independently.</div>
                    </div>
                    <div class="matrix-col">
                        <div class="matrix-col-title">PowerBall Pool</div>
                        <div class="matrix-col-val">1 / 20</div>
                        <div class="matrix-col-desc">1 PowerBall drawn from a separate 20-ball drum. Analysed in its own independent model.</div>
                    </div>
                </div>

                <div class="steps-grid">
                    <div class="step-card">
                        <div class="step-num">01</div>
                        <div class="step-title">Data Collection</div>
                        <p class="step-text">We pull the last <?php echo $analyzeLimit; ?> verified SA PowerBall draw results directly from our database of official National Lottery outcomes.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-num">02</div>
                        <div class="step-title">Dual-Matrix Frequency Analysis</div>
                        <p class="step-text">Ball appearance counts are calculated separately for the 50-ball main pool and the 20-ball PowerBall pool, producing independent hot/cold rankings for each.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-num">03</div>
                        <div class="step-title">Pair & Triplet Tracking</div>
                        <p class="step-text">Every possible 2-ball and 3-ball combination across all draws is counted to surface the most frequently co-drawn groups.</p>
                    </div>
                    <div class="step-card">
                        <div class="step-num">04</div>
                        <div class="step-title">Strategy Blending</div>
                        <p class="step-text">Three distinct pick strategies are generated: a Balanced mix, a pure Hot focus, and a Cold/Overdue focus — each with its own statistically sourced PowerBall.</p>
                    </div>
                </div>

                <h3 style="font-size:1.1rem;font-weight:800;color:var(--navy);margin:28px 0 14px;">
                    PowerBall Tips for Smarter Number Selection
                </h3>
                <ul class="tips-list">
                    <li><span class="tip-icon">✓</span> Avoid picking only numbers 1–31. Many players use birth dates, causing heavy overlap and potential jackpot splitting if you win.</li>
                    <li><span class="tip-icon">✓</span> Aim for a balanced odd/even spread (e.g., 3 odd + 2 even) across your main five numbers.</li>
                    <li><span class="tip-icon">✓</span> Cross-reference our hot and cold numbers to build a Balanced Strategy ticket that covers both ends of the frequency spectrum.</li>
                    <li><span class="tip-icon">✓</span> Never play the exact same numbers from the previous draw — the statistical probability of an identical repeat is effectively zero.</li>
                    <li><span class="tip-icon">✓</span> Treat the PowerBall as a completely separate decision. Use our dedicated 1/20 hot/cold stats rather than extending your main ball logic.</li>
                </ul>

            </section>

            <section class="chart-panel" aria-labelledby="chart-head">
                <h3 id="chart-head">Most Frequent SA PowerBall Numbers — Last <?php echo $analyzeLimit; ?> Draws</h3>
                <div class="chart-wrap">
                    <canvas id="frequencyChart" role="img" aria-label="Bar chart of top 10 most frequent PowerBall main numbers"></canvas>
                </div>
            </section>

            <section class="faq-section" aria-labelledby="faq-head">
                <h2 id="faq-head">SA PowerBall Predictions — FAQs</h2>
                <p class="faq-sub">Answers to the most common questions about our prediction methodology and the South African PowerBall draw.</p>

                <?php foreach ($pageFaqs as $faq): ?>
                <div class="faq-item" itemscope itemprop="mainEntity" itemtype="https://schema.org/Question">
                    <button class="faq-question" itemprop="name" aria-expanded="false">
                        <?php echo htmlspecialchars($faq['question']); ?>
                        <span class="faq-icon" aria-hidden="true">+</span>
                    </button>
                    <div class="faq-answer" itemscope itemprop="acceptedAnswer" itemtype="https://schema.org/Answer">
                        <div class="faq-answer-inner" itemprop="text">
                            <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </section>

            <div class="links-panel">
                <h2>Strengthen Your Strategy</h2>
                <p>Cross-reference today's PowerBall predictions with our historical archive and analytical tools.</p>
                <div class="pill-links">
                    <a class="pill-link" href="/results/powerball/<?php echo $slug; ?>/">
                        Latest PowerBall Results
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                    <a class="pill-link" href="/results/powerball/history/">
                        Full Draw History
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                    <a class="pill-link" href="/hot-and-cold-numbers/powerball/">
                        Detailed Hot &amp; Cold Stats
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                    <a class="pill-link" href="/number-generator/powerball/">
                        PowerBall Number Generator
                        <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
                    </a>
                </div>
            </div>

            <section aria-labelledby="tools-head">
                <div class="section-label">More PowerBall Tools</div>
                <div class="tools-grid">
                    <div class="tool-card">
                        <div class="tool-icon">🎰</div>
                        <h3>Number Generator</h3>
                        <p>Generate fully randomised PowerBall tickets instantly with our SA PowerBall number generator.</p>
                        <a class="tool-link" href="/number-generator/powerball/">Use Generator &rarr;</a>
                    </div>
                    <div class="tool-card">
                        <div class="tool-icon">🔥</div>
                        <h3>Hot &amp; Cold Numbers</h3>
                        <p>Full frequency tables for every main ball and PowerBall, updated after each official draw.</p>
                        <a class="tool-link" href="/hot-and-cold-numbers/powerball/">View Stats &rarr;</a>
                    </div>
                    <div class="tool-card">
                        <div class="tool-icon">🎫</div>
                        <h3>Check Your Tickets</h3>
                        <p>Instantly check your numbers against the latest official SA PowerBall results.</p>
                        <a class="tool-link" href="/check-tickets/powerball/">Check Tickets &rarr;</a>
                    </div>
                </div>
            </section>

            <div class="disclaimer" role="note" aria-label="Legal disclaimer">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="16" x2="12" y2="12"/>
        <line x1="12" y1="8" x2="12.01" y2="8"/>
    </svg>
    <div class="disclaimer-body">
        <strong>Independent Platform — Not Affiliated with the National Lottery</strong>
        
        <p>
            NextDrawLogic is an independent informational and analytical platform. 
            We are not affiliated with, endorsed by, or sponsored by 
            Ithuba Holdings
            or the Official South African National Lottery.
        </p>
        
        <p>
            All predictions, statistics, and number tools are generated using mathematical algorithms 
            and historical data for entertainment and informational purposes only.
        </p>
        
        <p>
            <strong>Lottery draws are games of pure chance.</strong> 
            Past results and frequency patterns do not influence or guarantee future outcomes.
        </p>
        
        <p>
            Please play responsibly and only with money you can afford to lose. 
            If you or someone you know needs support, contact the 
            <a href="https://www.responsiblegambling.co.za/" target="_blank" rel="noopener nofollow">National Responsible Gambling Programme</a> 
            or call the helpline on 0800 006 008.
        </p>
        
        <p style="font-size: 0.85rem; margin-top: 12px; color: #64748b;">
                <strong>Data Source:</strong> 
                <a href="https://www.nationallottery.co.za/" target="_blank" rel="noopener nofollow">Official South African National Lottery</a>. 
                Independently collected and verified. 
                Last updated: <?php echo date('F j, Y \a\t g:i A T'); ?>.
            </p>
    </div>
</div>

            

        </div><!-- /content-col -->

     
        <aside class="lotto-sidebar" aria-label="PowerBall navigation and countdown">

            <div class="sidebar-countdown">
                <div class="cd-label">Next Draw Countdown</div>
                <div id="cd-inline">–– : –– : ––</div>
                <div class="cd-draw"><?php echo $nextDrawDay; ?>, <?php echo $nextDrawFormatted; ?> at 21:00</div>
            </div>

            <div class="sidebar-card" style="margin-top:16px;">
                <div class="sidebar-head">PowerBall Panel</div>
                <ul class="sidebar-links">
                    <li>
                        <a href="/results/powerball/<?php echo $slug; ?>/">
                            Latest Results
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                    <li>
                        <a href="/results/powerball/history/">
                            Draw History
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                    <li>
                        <a href="/predictions/powerball/" class="active" aria-current="page">
                            Smart Predictions
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                    <li>
                        <a href="/check-tickets/powerball/">
                            Check Tickets
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                    <li>
                        <a href="/hot-and-cold-numbers/powerball/">
                            Hot &amp; Cold Numbers
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                    <li>
                        <a href="/number-generator/powerball/">
                            Generate Numbers
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
                        </a>
                    </li>
                </ul>
            </div>

        </aside>

    </div><!-- /layout-two-col -->
</main>

<?php
$footerPath = __DIR__ . '/../../static/footer.php';
if (file_exists($footerPath)) { include $footerPath; }
?>


<script>
document.addEventListener('DOMContentLoaded', function () {

    // ── COUNTDOWN (both inline hero badge and sidebar widget) ──
    const drawTime = new Date("<?php echo $nextDrawDate; ?>T21:00:00+02:00").getTime();
    const cdEl     = document.getElementById('cd-inline');

    function pad(n) { return String(n).padStart(2, '0'); }

    const tick = setInterval(function () {
        const diff = drawTime - Date.now();
        if (diff <= 0) {
            if (cdEl) cdEl.textContent = 'Drawing now!';
            clearInterval(tick);
            return;
        }
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        if (cdEl) cdEl.textContent = pad(h) + 'h ' + pad(m) + 'm ' + pad(s) + 's';
    }, 1000);

    // ── FAQ ACCORDION ──
    document.querySelectorAll('.faq-question').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const item    = btn.closest('.faq-item');
            const isOpen  = item.classList.contains('active');

            document.querySelectorAll('.faq-item.active').forEach(function (el) {
                el.classList.remove('active');
                el.querySelector('.faq-question').setAttribute('aria-expanded', 'false');
            });

            if (!isOpen) {
                item.classList.add('active');
                btn.setAttribute('aria-expanded', 'true');
            }
        });
    });

    const canvas = document.getElementById('frequencyChart');
    if (canvas && typeof Chart !== 'undefined') {
        const labels   = <?php echo json_encode($chartLabels); ?>;
        const data     = <?php echo json_encode($chartData); ?>;
        const maxFreq  = Math.max(...data);

        new Chart(canvas.getContext('2d'), {
            type: 'bar',
            data: {
                labels: labels.map(function (n) { return 'Ball ' + n; }),
                datasets: [{
                    label: 'Frequency (Last <?php echo $analyzeLimit; ?> Draws)',
                    data: data,
                    backgroundColor: data.map(function (v) {
                        return v === maxFreq ? '#c0182e' : '#e8b4bc';
                    }),
                    borderRadius: 5,
                    hoverBackgroundColor: '#8b0d1e'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { display: false },
                    tooltip: {
                        backgroundColor: '#0d1b2a',
                        padding: 12,
                        titleFont: { family: "'DM Sans', sans-serif", size: 13, weight: '700' },
                        bodyFont:  { family: "'DM Sans', sans-serif", size: 12 },
                        callbacks: {
                            label: function (ctx) { return ' Drawn ' + ctx.parsed.y + ' times'; }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: { color: '#f0f4f8' },
                        ticks: { precision: 0, font: { family: "'DM Sans', sans-serif" } }
                    },
                    x: {
                        grid: { display: false },
                        ticks: { font: { family: "'DM Sans', sans-serif", weight: '700' } }
                    }
                }
            }
        });
    }
});
</script>

</body>
</html>