<?php
// ============================================================
// DAILY LOTTO PREDICTIONS — NextDrawLogic
// ============================================================

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');
require_once __DIR__ . '/../../db.php';

$currentTime     = time();
$drawTimeToday   = strtotime('today 21:00:00');
$nextDrawTimestamp  = ($currentTime > $drawTimeToday) ? strtotime('tomorrow') : strtotime('today');
$nextDrawDate       = date('Y-m-d', $nextDrawTimestamp);
$nextDrawFormatted  = date('d F Y', $nextDrawTimestamp);
$nextDrawDay        = date('l', $nextDrawTimestamp);
$publishedISO       = date('c');

$analyzeLimit = 51;
$stmt = $pdo->prepare("SELECT ball_1, ball_2, ball_3, ball_4, ball_5, draw_date
                        FROM daily_lotto_results
                        ORDER BY draw_date DESC LIMIT :limit");
$stmt->bindValue(':limit', $analyzeLimit, PDO::PARAM_INT);
$stmt->execute();
$historyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

$latestDate          = !empty($historyResults[0]['draw_date']) ? $historyResults[0]['draw_date'] : date('Y-m-d');
$latestDateFormatted = date('d M Y', strtotime($latestDate));
$slug                = strtolower(str_replace(' ', '-', date('d-F-Y', strtotime($latestDate))));

$latestDraw  = $historyResults[0] ?? null;
$latestBalls = [];
if ($latestDraw) {
    for ($i = 1; $i <= 5; $i++) {
        if (!empty($latestDraw['ball_'.$i])) $latestBalls[] = (int)$latestDraw['ball_'.$i];
    }
}

$numberFrequency = array_fill(1, 36, 0);
$lastSeen        = array_fill(1, 36, null);
$pairCounts      = [];
$tripletCounts   = [];

$currentDrawsToAnalyze = array_slice($historyResults, 0, 50);
foreach ($currentDrawsToAnalyze as $draw) {
    $drawDate    = $draw['draw_date'];
    $ballsInDraw = [];
    for ($i = 1; $i <= 5; $i++) {
        $ball = (int)$draw['ball_'.$i];
        if ($ball >= 1 && $ball <= 36) {
            $numberFrequency[$ball]++;
            $ballsInDraw[] = $ball;
            if ($lastSeen[$ball] === null || $drawDate > $lastSeen[$ball]) $lastSeen[$ball] = $drawDate;
        }
    }
    sort($ballsInDraw);
    $len = count($ballsInDraw);
    if ($len >= 2) {
        for ($i = 0; $i < $len-1; $i++)
            for ($j = $i+1; $j < $len; $j++)
                $pairCounts[$ballsInDraw[$i].','.$ballsInDraw[$j]] = ($pairCounts[$ballsInDraw[$i].','.$ballsInDraw[$j]] ?? 0) + 1;
    }
    if ($len >= 3) {
        for ($i = 0; $i < $len-2; $i++)
            for ($j = $i+1; $j < $len-1; $j++)
                for ($k = $j+1; $k < $len; $k++)
                    $tripletCounts[$ballsInDraw[$i].','.$ballsInDraw[$j].','.$ballsInDraw[$k]] =
                        ($tripletCounts[$ballsInDraw[$i].','.$ballsInDraw[$j].','.$ballsInDraw[$k]] ?? 0) + 1;
    }
}

arsort($numberFrequency);
$hotNumbersAll  = array_keys($numberFrequency);
$coldNumbersAll = array_reverse($hotNumbersAll);
arsort($pairCounts);
arsort($tripletCounts);
$topPairs    = array_slice($pairCounts, 0, 4, true);
$topTriplets = array_slice($tripletCounts, 0, 3, true);

$topHot    = array_slice($hotNumbersAll, 0, 5);
$topCold   = array_slice($coldNumbersAll, 0, 5);
$midNumbers = array_slice($hotNumbersAll, 15, 6);
shuffle($midNumbers);

$set1 = array_merge(array_slice($topHot, 0, 2), array_slice($topCold, 0, 2), array_slice($midNumbers, 0, 1)); sort($set1);
$set2 = $topHot; sort($set2);
$set3 = $topCold; sort($set3);

$prevFreq = array_fill(1, 36, 0);
for ($k = 1; $k <= 50; $k++) {
    if (!isset($historyResults[$k])) continue;
    for ($i = 1; $i <= 5; $i++) {
        $ball = (int)$historyResults[$k]['ball_'.$i];
        if ($ball >= 1 && $ball <= 36) $prevFreq[$ball]++;
    }
}
arsort($prevFreq);
$prevHotAll  = array_keys($prevFreq);
$prevColdAll = array_reverse($prevHotAll);
$prevSet1    = array_merge(array_slice($prevHotAll, 0, 2), array_slice($prevColdAll, 0, 2), array_slice($prevHotAll, 15, 1));
$prevSet2    = array_slice($prevHotAll, 0, 5);
$prevSet3    = array_slice($prevColdAll, 0, 5);
$match1 = $match2 = $match3 = 0;
if (!empty($latestBalls)) {
    $match1 = count(array_intersect($prevSet1, $latestBalls));
    $match2 = count(array_intersect($prevSet2, $latestBalls));
    $match3 = count(array_intersect($prevSet3, $latestBalls));
}

$latestDrawMatchesHTML = '';
if ($latestDraw) {
    $matchElements = [];
    foreach ($latestBalls as $b) {
        if      (in_array($b, $topHot))                              $matchElements[] = "<span class='acc-badge acc-hot'>$b <span class='acc-label'>Hot</span></span>";
        elseif  (in_array($b, $topCold))                             $matchElements[] = "<span class='acc-badge acc-cold'>$b <span class='acc-label'>Cold</span></span>";
        elseif  (in_array($b, array_slice($hotNumbersAll, 0, 15)))   $matchElements[] = "<span class='acc-badge acc-warm'>$b <span class='acc-label'>Warm</span></span>";
        else                                                          $matchElements[] = "<span class='acc-badge acc-neutral'>$b</span>";
    }
    $latestDrawMatchesHTML = implode('', $matchElements);
}

$chartLabels = array_slice($hotNumbersAll, 0, 10);
$chartData   = array_map(fn($n) => $numberFrequency[$n], $chartLabels);

$pageTitle  = "Daily Lotto Predictions for Today ({$nextDrawFormatted}) | SA";
$metaDesc   = "Get SA Daily Lotto predictions for tonight's 21:00 draw. Hot & cold numbers, overdue picks, pairs & triplets — updated daily from the last 50 official draws.";
$currentUrl = "https://".$_SERVER['HTTP_HOST'].explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home",        "url" => "https://".$_SERVER['HTTP_HOST']."/"],
    ["name" => "Predictions", "url" => "https://".$_SERVER['HTTP_HOST']."/predictions/"],
    ["name" => "Daily Lotto", "url" => $currentUrl],
];

$pageFaqs = [
    [
        "question" => "How are today's Daily Lotto predictions calculated?",
        "answer"   => "Our Daily Lotto prediction algorithm analyses the last 50 official Ithuba draws to identify hot numbers (drawn most often), cold/overdue numbers (drawn least often), and high-frequency pairs and triplets. These statistics are used to generate three structured combination sets — Balanced, Hot Focus, and Cold Strategy — updated automatically before each 21:00 SAST draw."
    ],
    [
        "question" => "What are the hottest Daily Lotto numbers right now?",
        "answer"   => "Based on our latest 50-draw frequency analysis, the top hot numbers are ".implode(', ', $topHot).". These have appeared more often than any others in recent official SA Daily Lotto draws."
    ],
    [
        "question" => "Which Daily Lotto numbers are overdue tonight?",
        "answer"   => "The most overdue Daily Lotto numbers — those drawn least frequently over the last 50 results — are currently ".implode(', ', $topCold).". Some players target these cold numbers on the theory that they are statistically due for a return, though all draws remain independently random."
    ],
    [
        "question" => "Can a Daily Lotto prediction algorithm guarantee a win?",
        "answer"   => "No prediction tool or algorithm can guarantee a lottery win. Daily Lotto draws are entirely random. Our smart pick system uses verified historical frequency data to help players make systematic, data-informed choices rather than selecting numbers at random. Play responsibly and within your means."
    ],
    [
        "question" => "When does the Daily Lotto draw take place in South Africa?",
        "answer"   => "The Ithuba Daily Lotto draw takes place every day at 21:00 SAST (South African Standard Time), except on Christmas Day (25 December). Results are published on the official National Lottery website shortly after each draw."
    ],
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo htmlspecialchars($pageTitle); ?></title>
    <meta name="description" content="<?php echo htmlspecialchars($metaDesc); ?>">
    <meta name="robots" content="index, follow, max-image-preview:large">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <meta name="keywords" content="daily lotto predictions, daily lotto predictions for today, SA daily lotto predictions, daily lotto predictions tonight, today's daily lotto predictions, daily lotto numbers for today, daily lotto hot and cold numbers, daily lotto overdue numbers, daily lotto prediction algorithm, daily lotto number generator, daily lotto smart pick">
    <meta name="geo.region" content="ZA">
    <meta name="geo.placename" content="South Africa">
    <meta name="language" content="English">
    <link rel="alternate" hreflang="en-za" href="<?php echo $currentUrl; ?>">

    <!-- Open Graph -->
    <meta property="og:title"       content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta property="og:description" content="<?php echo htmlspecialchars($metaDesc); ?>">
    <meta property="og:url"         content="<?php echo $currentUrl; ?>">
    <meta property="og:type"        content="article">
    <meta property="og:image"       content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/og-daily-lotto.jpg">
    <meta property="og:image:alt"   content="Daily Lotto Predictions South Africa">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="630">

    <!-- Twitter -->
    <meta name="twitter:card"        content="summary_large_image">
    <meta name="twitter:title"       content="<?php echo htmlspecialchars($pageTitle); ?>">
    <meta name="twitter:description" content="<?php echo htmlspecialchars($metaDesc); ?>">

    <link rel="stylesheet" href="/style/style.css?v=4">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800;900&family=DM+Serif+Display:ital@0;1&display=swap" rel="stylesheet">
    <meta name="theme-color" content="#1a3a6e">
    <link rel="icon" type="image/webp" href="/images/next_draw_logic_favicon.webp">
    <script src="https://cdn.jsdelivr.net/npm/chart.js" defer></script>

    <style>
    :root {
        --navy:       #0e2044;
        --navy-mid:   #1a3a6e;
        --blue:       #1d5fe5;
        --blue-light: #3b7ff5;
        --gold:       #f5a623;
        --gold-light: #ffd270;
        --emerald:    #0fa86a;
        --ice:        #3b9eff;
        --red:        #e53e3e;
        --ink:        #0d1b2a;
        --slate:      #475569;
        --border:     #dde4ef;
        --surface:    #f6f8fd;
        --white:      #ffffff;
        --radius-sm:  6px;
        --radius-md:  12px;
        --radius-lg:  20px;
        --shadow-sm:  0 2px 8px rgba(14,32,68,.06);
        --shadow-md:  0 6px 24px rgba(14,32,68,.10);
        --shadow-lg:  0 16px 48px rgba(14,32,68,.15);
    }

    *, *::before, *::after { box-sizing: border-box; }
    html { scroll-behavior: smooth; }

    /*body {*/
    /*    font-family: 'Outfit', sans-serif;*/
    /*    color: var(--ink);*/
    /*    background: #f9fafb;*/
    /*}*/

    .ndl-container  { max-width: 1300px; margin: 0 auto; padding: 0 20px; }
    .ndl-layout     { display: grid; grid-template-columns: minmax(0,1fr) 300px; gap: 40px; align-items: start; margin-top: 28px; }
    .ndl-content    { min-width: 0; }

    .ndl-breadcrumb { display: flex; align-items: center; gap: 6px; font-size: .82rem; color: var(--slate); padding: 14px 0 10px; flex-wrap: wrap; }
    .ndl-breadcrumb a { color: var(--blue); text-decoration: none; font-weight: 600; }
    .ndl-breadcrumb a:hover { text-decoration: underline; }
    .ndl-breadcrumb .sep { opacity: .4; }

    .ndl-hero {
        background: linear-gradient(135deg, var(--navy) 0%, var(--navy-mid) 55%, #1a4fa0 100%);
        border-radius: var(--radius-lg);
        padding: 36px 40px 32px;
        color: var(--white);
        position: relative;
        overflow: hidden;
        margin-bottom: 28px;
    }
    .ndl-hero::before {
        content: '';
        position: absolute; inset: 0;
        background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.04'%3E%3Ccircle cx='30' cy='30' r='28'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        pointer-events: none;
    }
    .ndl-hero-live {
        display: inline-flex; align-items: center; gap: 7px;
        background: rgba(255,255,255,.12);
        border: 1px solid rgba(255,255,255,.2);
        padding: 5px 14px; border-radius: 999px;
        font-size: .8rem; font-weight: 700; letter-spacing: .5px;
        text-transform: uppercase; margin-bottom: 14px;
    }
    .ndl-live-dot { width: 7px; height: 7px; background: #4ade80; border-radius: 50%; animation: ndl-pulse 2s infinite; }
    @keyframes ndl-pulse { 0%,100% { box-shadow: 0 0 0 0 rgba(74,222,128,.5); } 60% { box-shadow: 0 0 0 7px rgba(74,222,128,0); } }

    .ndl-hero h1 {
        /*font-family: 'DM Serif Display', Georgia, serif;*/
        font-size: clamp(1.7rem, 3.5vw, 2.6rem);
        font-weight: 400; line-height: 1.15;
        margin: 0 0 14px; color: var(--white);
    }
    .ndl-hero h1 em { font-style: italic; color: var(--gold-light); }
    .ndl-hero-intro { font-size: 1.02rem; color: rgba(255,255,255,.8); line-height: 1.6; max-width: 620px; margin: 0 0 20px; }

    .ndl-latest-strip {
        display: inline-flex; align-items: center; gap: 8px; flex-wrap: wrap;
        background: rgba(255,255,255,.1); border: 1px solid rgba(255,255,255,.15);
        padding: 8px 16px; border-radius: var(--radius-md);
        font-size: .88rem; font-weight: 600;
    }
    .ndl-latest-strip .ndl-ball-sm {
        width: 32px; height: 32px; border-radius: 50%;
        background: rgba(255,255,255,.2); border: 1.5px solid rgba(255,255,255,.4);
        display: flex; align-items: center; justify-content: center;
        font-size: .85rem; font-weight: 800; color: var(--white);
    }

    .ndl-toc { display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 30px; }
    .ndl-toc a {
        background: var(--white); color: var(--navy-mid);
        padding: 7px 16px; border-radius: 999px; font-size: .88rem; font-weight: 700;
        border: 1.5px solid var(--border); text-decoration: none;
        transition: all .2s; white-space: nowrap;
    }
    .ndl-toc a:hover { background: var(--navy-mid); color: var(--white); border-color: var(--navy-mid); }

    .ndl-section-title {
        /*font-family: 'DM Serif Display', Georgia, serif;*/
        font-size: clamp(1.3rem, 2.5vw, 1.8rem);
        color: var(--navy); margin: 0 0 6px; font-weight: 400;
    }
    .ndl-section-sub { color: var(--slate); font-size: .98rem; margin: 0 0 22px; }

    .ndl-accuracy {
        background: var(--white); border: 1px solid var(--border);
        border-left: 4px solid #8b5cf6;
        border-radius: var(--radius-md); padding: 20px 24px;
        margin-bottom: 30px; display: flex; flex-direction: column; gap: 12px;
    }
    .ndl-accuracy-title { font-weight: 800; font-size: 1rem; color: var(--navy); margin: 0; }
    .ndl-accuracy-sub   { font-size: .9rem; color: var(--slate); margin: 0; }
    .ndl-acc-row        { display: flex; flex-wrap: wrap; gap: 8px; }
    .acc-badge {
        display: inline-flex; align-items: center; gap: 5px;
        padding: 5px 11px; border-radius: 6px; font-size: .88rem; font-weight: 800; border: 1px solid;
    }
    .acc-label { font-weight: 500; font-size: .75rem; opacity: .85; }
    .acc-hot     { background: #fef2f2; color: #b91c1c; border-color: #fca5a5; }
    .acc-cold    { background: #eff6ff; color: #1d4ed8; border-color: #bfdbfe; }
    .acc-warm    { background: #fffbeb; color: #b45309; border-color: #fcd34d; }
    .acc-neutral { background: #f1f5f9; color: var(--slate); border-color: var(--border); }

    .ndl-pred-grid  { display: grid; gap: 22px; margin-bottom: 40px; }

    .ndl-pred-card {
        background: var(--white); border-radius: var(--radius-md);
        border: 1px solid var(--border); box-shadow: var(--shadow-sm);
        overflow: hidden; transition: transform .2s, box-shadow .2s;
    }
    .ndl-pred-card:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); }

    .ndl-pred-header {
        padding: 20px 26px 16px;
        border-bottom: 1px solid var(--border);
        display: flex; align-items: center; gap: 14px;
    }
    .ndl-pred-icon {
        width: 44px; height: 44px; border-radius: var(--radius-sm);
        display: flex; align-items: center; justify-content: center;
        font-size: 1.4rem; flex-shrink: 0;
    }
    .icon-balanced { background: #ecfdf5; }
    .icon-hot      { background: #fef2f2; }
    .icon-cold     { background: #eff6ff; }

    .ndl-pred-header-text h3 { margin: 0 0 2px; font-size: 1.1rem; font-weight: 800; color: var(--navy); }
    .ndl-pred-header-text p  { margin: 0; font-size: .82rem; color: var(--slate); font-weight: 500; }

    .ndl-pred-body { padding: 20px 26px 24px; }

    .ndl-match-pill {
        display: inline-flex; align-items: center; gap: 6px;
        padding: 5px 12px; border-radius: 999px; font-size: .82rem; font-weight: 700;
        background: #f1f5f9; color: var(--slate); border: 1px solid var(--border); margin-bottom: 18px;
    }
    .ndl-match-pill.good { background: #dcfce7; color: #166534; border-color: #bbf7d0; }
    .ndl-match-pill .match-dot { width: 6px; height: 6px; border-radius: 50%; background: currentColor; }

    .ndl-balls { display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 18px; }
    .ndl-ball {
        width: 52px; height: 52px; border-radius: 50%;
        display: flex; align-items: center; justify-content: center;
        font-size: 1.1rem; font-weight: 900; border: 2px solid;
        position: relative; transition: transform .15s;
    }
    .ndl-ball:hover { transform: scale(1.1); }
    .ndl-ball-default { background: #f8fafc; border-color: #cbd5e1; color: #334155; }
    .ndl-ball-hot     { background: #fef2f2; border-color: #fca5a5; color: var(--red); }
    .ndl-ball-cold    { background: #eff6ff; border-color: #bfdbfe; color: #1d4ed8; }

    .ndl-pred-reason {
        background: var(--surface); padding: 14px 18px; border-radius: var(--radius-sm);
        font-size: .9rem; color: var(--slate); line-height: 1.55; border-left: 3px solid var(--border);
    }
    .ndl-pred-reason strong { color: var(--navy); }

    /* Card accent tops */
    .ndl-pred-card.card-balanced { border-top: 4px solid var(--emerald); }
    .ndl-pred-card.card-hot      { border-top: 4px solid var(--red); }
    .ndl-pred-card.card-cold     { border-top: 4px solid var(--ice); }

    .ndl-combo-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; margin-bottom: 40px; }
    .ndl-combo-card {
        background: var(--white); border-radius: var(--radius-md);
        border: 1px solid var(--border); padding: 26px; box-shadow: var(--shadow-sm);
    }
    .ndl-combo-card h3 { font-size: 1.05rem; font-weight: 800; color: var(--navy); margin: 0 0 4px; }
    .ndl-combo-card p  { font-size: .84rem; color: var(--slate); margin: 0 0 18px; }
    .ndl-combo-list { list-style: none; padding: 0; margin: 0; }
    .ndl-combo-list li { display: flex; justify-content: space-between; align-items: center; padding: 11px 0; border-bottom: 1px dashed var(--border); }
    .ndl-combo-list li:last-child { border-bottom: none; padding-bottom: 0; }
    .ndl-combo-nums { display: flex; gap: 7px; }
    .ndl-combo-ball {
        width: 34px; height: 34px; border-radius: 50%;
        background: var(--navy); color: var(--white);
        display: flex; align-items: center; justify-content: center;
        font-size: .85rem; font-weight: 800;
    }
    .ndl-combo-freq { font-size: .8rem; color: var(--slate); font-weight: 700; background: var(--surface); padding: 4px 10px; border-radius: var(--radius-sm); }

    .ndl-how {
        background: var(--white); border: 1px solid var(--border);
        border-radius: var(--radius-md); padding: 36px; margin-bottom: 40px;
    }
    .ndl-how h2 { margin-top: 0; }
    .ndl-how p, .ndl-how li { color: var(--slate); line-height: 1.7; font-size: .98rem; }

    .ndl-check-list { list-style: none; padding: 0; margin: 20px 0 28px; }
    .ndl-check-list li { position: relative; padding-left: 28px; margin-bottom: 12px; font-size: 1rem; color: var(--slate); }
    .ndl-check-list li::before { content: "✓"; position: absolute; left: 0; top: -1px; color: var(--emerald); font-weight: 900; font-size: 1.1rem; }

    .ndl-strategy-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin: 24px 0 32px; }
    .ndl-strategy-card {
        border: 1px solid var(--border); border-radius: var(--radius-md);
        padding: 22px 20px; background: var(--white);
        transition: transform .2s, box-shadow .2s;
    }
    .ndl-strategy-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
    .ndl-strategy-card h3 { font-size: 1.05rem; font-weight: 800; color: var(--navy); margin: 0 0 10px; }
    .ndl-strategy-card p  { margin: 0; font-size: .9rem; color: var(--slate); line-height: 1.55; }
    .card-s-hot      { border-top: 4px solid var(--red); }
    .card-s-cold     { border-top: 4px solid var(--ice); }
    .card-s-balanced { border-top: 4px solid var(--emerald); }

    .ndl-chart-wrap { position: relative; height: 280px; margin-top: 22px; }

    .ndl-stat-strip {
        display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin-bottom: 40px;
    }
    .ndl-stat-tile {
        background: var(--white); border: 1px solid var(--border);
        border-radius: var(--radius-md); padding: 20px 22px; text-align: center;
        box-shadow: var(--shadow-sm);
    }
    .ndl-stat-tile .ndl-stat-num { font-size: 2rem; font-weight: 900; color: var(--navy); line-height: 1; margin-bottom: 4px; }
    .ndl-stat-tile .ndl-stat-label { font-size: .82rem; color: var(--slate); font-weight: 600; }

    .ndl-author {
        border-left: 4px solid var(--blue); background: var(--surface);
        padding: 18px 22px; border-radius: var(--radius-sm); margin-bottom: 40px;
        border: 1px solid var(--border);
    }
    .ndl-author strong { display: block; color: var(--navy); margin-bottom: 6px; font-size: 1rem; }
    .ndl-author p { margin: 0; font-size: .9rem; color: var(--slate); line-height: 1.55; }

    .ndl-faq { margin-bottom: 40px; }
    .ndl-faq-header {
        font-size: 1.45rem; font-weight: 800; color: var(--navy);
        margin-bottom: 22px; padding-left: 16px;
        border-left: 5px solid var(--blue); line-height: 1.2;
        /*font-family: 'DM Serif Display', Georgia, serif; */
        font-weight: 400;
    }
    .ndl-faq-item {
        background: var(--white); border: 1px solid var(--border);
        border-radius: var(--radius-md); margin-bottom: 12px; overflow: hidden;
    }
    .ndl-faq-question {
        width: 100%; background: none; border: none; text-align: left;
        padding: 18px 22px; font-size: 1rem; font-weight: 700; color: var(--navy);
        cursor: pointer; display: flex; justify-content: space-between; align-items: center;
        /*font-family: 'Outfit', sans-serif; */
        gap: 12px;
    }
    .ndl-faq-question:hover { background: var(--surface); }
    .ndl-faq-icon { color: var(--blue); font-size: 1.5rem; line-height: 1; transition: transform .3s; flex-shrink: 0; }
    .ndl-faq-answer { max-height: 0; overflow: hidden; transition: max-height .35s ease, padding .3s ease; }
    .ndl-faq-answer-inner { padding: 0 22px 18px; color: var(--slate); font-size: .95rem; line-height: 1.65; }
    .ndl-faq-item.active .ndl-faq-icon { transform: rotate(45deg); }
    .ndl-faq-item.active .ndl-faq-answer { max-height: 600px; }

    .ndl-int-links {
        background: var(--white); padding: 30px; border-radius: var(--radius-md);
        border: 1px solid var(--border); margin-bottom: 40px;
    }
    .ndl-int-links h2 { font-size: 1.25rem; font-weight: 800; color: var(--navy); margin: 0 0 6px; }
    .ndl-int-links p  { color: var(--slate); font-size: .92rem; margin: 0 0 18px; }
    .ndl-pill-nav { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 10px; }
    .ndl-pill-nav a {
        display: inline-flex; align-items: center; gap: 8px;
        background: var(--surface); color: var(--navy-mid); text-decoration: none;
        padding: 10px 18px; border-radius: 999px; font-size: .9rem; font-weight: 700;
        border: 1.5px solid var(--border); transition: all .2s;
    }
    .ndl-pill-nav a svg { width: 14px; height: 14px; color: var(--blue); transition: color .2s; }
    .ndl-pill-nav a:hover { background: var(--blue); color: var(--white); border-color: var(--blue); }
    .ndl-pill-nav a:hover svg { color: var(--white); }

    .ndl-related { margin-bottom: 40px; }
    .ndl-related h2 { font-size: 1.35rem; font-weight: 800; color: var(--navy); margin-bottom: 18px; }
    .ndl-related-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
    .ndl-related-card {
        background: var(--white); border: 1px solid var(--border);
        border-radius: var(--radius-md); padding: 22px 20px;
        transition: transform .2s, box-shadow .2s;
    }
    .ndl-related-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
    .ndl-related-card .rc-icon { font-size: 2rem; margin-bottom: 14px; }
    .ndl-related-card h3 { margin: 0 0 8px; font-size: 1rem; font-weight: 800; color: var(--navy); }
    .ndl-related-card p  { margin: 0 0 14px; font-size: .88rem; color: var(--slate); line-height: 1.5; }
    .ndl-related-card a  { font-weight: 700; font-size: .9rem; color: var(--blue); text-decoration: none; }
    .ndl-related-card a:hover { text-decoration: underline; }

    .ndl-disclaimer {
        display: flex; gap: 18px; align-items: flex-start;
        background: linear-gradient(145deg, var(--surface), #f1f5f9);
        border: 1px solid var(--border); border-left: 3px solid #6a3ee7;
        padding: 24px; border-radius: var(--radius-md);
        margin-bottom: 48px; box-shadow: var(--shadow-sm);
    }
    .ndl-disclaimer svg { flex-shrink: 0; width: 22px; height: 22px; color: #94a3b8; margin-top: 2px; }
    .ndl-disclaimer strong { display: block; color: var(--slate); font-weight: 700; text-transform: uppercase; font-size: .72rem; letter-spacing: .8px; margin-bottom: 6px; }
    .ndl-disclaimer p { margin: 0 0 8px; font-size: .84rem; color: var(--slate); line-height: 1.6; }
    .ndl-disclaimer p:last-child { margin-bottom: 0; }
    .ndl-disclaimer a { color: var(--slate); }

    .ndl-sidebar { position: sticky; top: 96px; }
    .ndl-sidebar-card {
        background: var(--white); border-radius: var(--radius-md);
        border: 1px solid var(--border); box-shadow: var(--shadow-sm); overflow: hidden;
    }
    .ndl-sidebar-head {
        background: linear-gradient(135deg, var(--navy), var(--navy-mid));
        color: var(--white); padding: 18px 22px;
        font-weight: 800; font-size: 1rem; letter-spacing: .3px;
    }
    .ndl-sidebar-links { list-style: none; padding: 0; margin: 0; }
    .ndl-sidebar-links li { border-bottom: 1px solid var(--surface); }
    .ndl-sidebar-links li:last-child { border-bottom: none; }
    .ndl-sidebar-links a {
        display: flex; align-items: center; padding: 14px 22px;
        color: var(--slate); font-weight: 600; font-size: .92rem;
        border-left: 3px solid transparent; transition: all .2s; text-decoration: none;
    }
    .ndl-sidebar-links a:hover { background: var(--surface); color: var(--navy); border-left-color: var(--border); }
    .ndl-sidebar-links a.active { background: var(--surface); color: var(--blue); border-left-color: var(--blue); font-weight: 800; }

    .ndl-draw-chip {
        margin: 14px 16px 16px;
        background: linear-gradient(135deg, var(--gold), var(--gold-light));
        border-radius: var(--radius-md); padding: 14px 16px;
        text-align: center;
    }
    .ndl-draw-chip .dc-label { font-size: .78rem; font-weight: 700; color: var(--navy); text-transform: uppercase; letter-spacing: .6px; margin-bottom: 4px; }
    .ndl-draw-chip .dc-date  { font-size: 1.05rem; font-weight: 900; color: var(--navy); }
    .ndl-draw-chip .dc-time  { font-size: .82rem; font-weight: 600; color: rgba(14,32,68,.7); margin-top: 2px; }

    @media (max-width: 1060px) {
        .ndl-layout { grid-template-columns: 1fr; }
        .ndl-sidebar { position: relative; top: 0; }
        .ndl-combo-grid { grid-template-columns: 1fr; }
        .ndl-strategy-grid { grid-template-columns: 1fr; }
    }
    @media (max-width: 680px) {
        .ndl-hero { padding: 24px 22px 22px; }
        .ndl-related-grid { grid-template-columns: 1fr; }
        .ndl-stat-strip { grid-template-columns: 1fr 1fr; }
        .ndl-how { padding: 24px 20px; }
        .ndl-int-links { padding: 22px 18px; }
        .ndl-pill-nav a { width: 100%; justify-content: space-between; }
    }
    @media (max-width: 420px) {
        .ndl-stat-strip { grid-template-columns: 1fr; }
    }
    </style>


    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Article",
      "headline": <?php echo json_encode($pageTitle); ?>,
      "description": <?php echo json_encode($metaDesc); ?>,
      "author": { "@type": "Organization", "name": "NextDrawLogic", "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>" },
      "publisher": { "@type": "Organization", "name": "NextDrawLogic", "logo": { "@type": "ImageObject", "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/logo.png" } },
      "datePublished": <?php echo json_encode($publishedISO); ?>,
      "dateModified": <?php echo json_encode($publishedISO); ?>,
      "mainEntityOfPage": { "@type": "WebPage", "@id": <?php echo json_encode($currentUrl); ?> }
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      "itemListElement": [
        <?php foreach ($breadcrumbs as $idx => $crumb): ?>
        { "@type": "ListItem", "position": <?php echo $idx+1; ?>, "name": <?php echo json_encode($crumb['name']); ?>, "item": <?php echo json_encode($crumb['url']); ?> }<?php echo $idx < count($breadcrumbs)-1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $idx => $faq): ?>
        {
          "@type": "Question",
          "name": <?php echo json_encode($faq['question']); ?>,
          "acceptedAnswer": { "@type": "Answer", "text": <?php echo json_encode($faq['answer']); ?> }
        }<?php echo $idx < count($pageFaqs)-1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>

    <script type="application/ld+json">
    { "@context":"https://schema.org", "@type":"WebPage", "name":<?php echo json_encode($pageTitle); ?>, "url":<?php echo json_encode($currentUrl); ?>, "description":<?php echo json_encode($metaDesc); ?>, "inLanguage":"en-ZA" }
    </script>

    <script type="application/ld+json">
    { "@context":"https://schema.org", "@type":"Organization", "name":"NextDrawLogic", "url":"https://<?php echo $_SERVER['HTTP_HOST']; ?>", "logo":"https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/logo.png" }
    </script>

    <script type="application/ld+json">
    { "@context":"https://schema.org", "@type":"WebPage", "speakable": { "@type":"SpeakableSpecification", "cssSelector":[".ndl-pred-card",".ndl-how",".ndl-faq-item"] } }
    </script>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="ndl-container" id="main-content">

        <!-- Breadcrumb -->
        <nav class="ndl-breadcrumb" aria-label="Breadcrumb">
            <?php foreach ($breadcrumbs as $idx => $crumb): ?>
                <?php if ($idx < count($breadcrumbs)-1): ?>
                    <a href="<?php echo $crumb['url']; ?>"><?php echo htmlspecialchars($crumb['name']); ?></a>
                    <span class="sep" aria-hidden="true">›</span>
                <?php else: ?>
                    <span aria-current="page"><?php echo htmlspecialchars($crumb['name']); ?></span>
                <?php endif; ?>
            <?php endforeach; ?>
        </nav>

        <div class="ndl-layout">

            <div class="ndl-content">

                <header class="ndl-hero" aria-label="Page header">

                    <div class="ndl-hero-live" aria-label="Updated today">
                        <span class="ndl-live-dot" aria-hidden="true"></span>
                        Updated for <?php echo $nextDrawDay; ?> · <?php echo date('d M Y'); ?>
                    </div>

                    <h1>
                        Daily Lotto Predictions for <em>Today</em><br>
                        <?php echo $nextDrawFormatted; ?> — SA
                    </h1>

                    <p class="ndl-hero-intro">
                        Data-driven <strong>SA Daily Lotto predictions</strong> for tonight's 21:00 SAST draw. Our algorithm analyses the last 50 official Ithuba results to surface the hottest numbers, most overdue picks, and highest-frequency combinations — updated before every draw.
                    </p>

                    <?php if (!empty($latestBalls)): ?>
                    <div class="ndl-latest-strip" aria-label="Latest draw result">
                        <span>Latest result (<?php echo $latestDateFormatted; ?>):</span>
                        <?php foreach ($latestBalls as $b): ?>
                            <span class="ndl-ball-sm"><?php echo $b; ?></span>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>

                </header>

                <nav class="ndl-toc" aria-label="On-page sections">
                    <a href="#predictions">🎯 Today's Picks</a>
                    <a href="#pairs">🔗 Pairs & Triplets</a>
                    <a href="#how-it-works">⚙️ How It Works</a>
                    <a href="#hot-cold">🔥 Hot & Cold</a>
                    <a href="#faqs">❓ FAQs</a>
                </nav>

                <div class="ndl-stat-strip" aria-label="Key statistics">
                    <div class="ndl-stat-tile">
                        <div class="ndl-stat-num"><?php echo count($currentDrawsToAnalyze); ?></div>
                        <div class="ndl-stat-label">Draws Analysed</div>
                    </div>
                    <div class="ndl-stat-tile">
                        <div class="ndl-stat-num">36</div>
                        <div class="ndl-stat-label">Number Pool</div>
                    </div>
                    <div class="ndl-stat-tile">
                        <div class="ndl-stat-num">3</div>
                        <div class="ndl-stat-label">Smart Pick Sets</div>
                    </div>
                </div>

                <?php if ($latestDraw): ?>
                <div class="ndl-accuracy" aria-label="Recent trend alignment">
                    <p class="ndl-accuracy-title">✅ Latest Result — Trend Alignment Check</p>
                    <p class="ndl-accuracy-sub">
                        How the <?php echo $latestDateFormatted; ?> official numbers aligned with our frequency categories.
                    </p>
                    <div class="ndl-acc-row">
                        <?php echo $latestDrawMatchesHTML; ?>
                    </div>
                </div>
                <?php endif; ?>

                <section id="predictions" aria-labelledby="pred-heading">
                    <h2 class="ndl-section-title" id="pred-heading">Today's Daily Lotto Number Combinations</h2>
                    <p class="ndl-section-sub">Three algorithmic strategies. Choose the one that matches your playing style — or play all three.</p>

                    <div class="ndl-pred-grid">

                        <article class="ndl-pred-card card-balanced" aria-label="Balanced prediction set">
                            <div class="ndl-pred-header">
                                <div class="ndl-pred-icon icon-balanced" aria-hidden="true">🎯</div>
                                <div class="ndl-pred-header-text">
                                    <h3>Strategy 1: Balanced Smart Pick</h3>
                                    <p>Hot numbers + overdue picks + a neutral mid-range ball</p>
                                </div>
                            </div>
                            <div class="ndl-pred-body">
                                <span class="ndl-match-pill <?php echo ($match1 >= 2) ? 'good' : ''; ?>" aria-label="Yesterday's match score">
                                    <span class="match-dot" aria-hidden="true"></span>
                                    Yesterday's algorithm matched <strong><?php echo $match1; ?>/5</strong>
                                </span>
                                <div class="ndl-balls" aria-label="Predicted numbers">
                                    <?php foreach ($set1 as $num): ?>
                                        <div class="ndl-ball ndl-ball-default" title="Ball <?php echo $num; ?>"><?php echo $num; ?></div>
                                    <?php endforeach; ?>
                                </div>
                                <p class="ndl-pred-reason">
                                    <strong>The Logic:</strong> A mathematically balanced mix of 2 trending hot numbers, 2 statistically overdue cold numbers, and 1 neutral mid-frequency pick. This daily lotto smart pick strategy spreads probability across frequency bands.
                                </p>
                            </div>
                        </article>

                        <article class="ndl-pred-card card-hot" aria-label="Hot numbers prediction set">
                            <div class="ndl-pred-header">
                                <div class="ndl-pred-icon icon-hot" aria-hidden="true">🔥</div>
                                <div class="ndl-pred-header-text">
                                    <h3>Strategy 2: Hot Numbers — Trending Focus</h3>
                                    <p>The 5 most frequently drawn numbers over the last 50 draws</p>
                                </div>
                            </div>
                            <div class="ndl-pred-body">
                                <span class="ndl-match-pill <?php echo ($match2 >= 2) ? 'good' : ''; ?>" aria-label="Yesterday's match score">
                                    <span class="match-dot" aria-hidden="true"></span>
                                    Yesterday's algorithm matched <strong><?php echo $match2; ?>/5</strong>
                                </span>
                                <div class="ndl-balls" aria-label="Hot predicted numbers">
                                    <?php foreach ($set2 as $num): ?>
                                        <div class="ndl-ball ndl-ball-hot" title="Hot ball <?php echo $num; ?>"><?php echo $num; ?></div>
                                    <?php endforeach; ?>
                                </div>
                                <p class="ndl-pred-reason">
                                    <strong>The Logic:</strong> These are the current <strong>Daily Lotto hot numbers</strong> — the five balls drawn most frequently in recent official Ithuba results. This strategy bets on numerical momentum continuing.
                                </p>
                            </div>
                        </article>

                        <article class="ndl-pred-card card-cold" aria-label="Cold/overdue prediction set">
                            <div class="ndl-pred-header">
                                <div class="ndl-pred-icon icon-cold" aria-hidden="true">❄️</div>
                                <div class="ndl-pred-header-text">
                                    <h3>Strategy 3: Overdue / Cold Strategy</h3>
                                    <p>The 5 most statistically overdue numbers in the current pool</p>
                                </div>
                            </div>
                            <div class="ndl-pred-body">
                                <span class="ndl-match-pill <?php echo ($match3 >= 2) ? 'good' : ''; ?>" aria-label="Yesterday's match score">
                                    <span class="match-dot" aria-hidden="true"></span>
                                    Yesterday's algorithm matched <strong><?php echo $match3; ?>/5</strong>
                                </span>
                                <div class="ndl-balls" aria-label="Cold predicted numbers">
                                    <?php foreach ($set3 as $num): ?>
                                        <div class="ndl-ball ndl-ball-cold" title="Cold ball <?php echo $num; ?>"><?php echo $num; ?></div>
                                    <?php endforeach; ?>
                                </div>
                                <p class="ndl-pred-reason">
                                    <strong>The Logic:</strong> These are the current <strong>Daily Lotto overdue numbers</strong> — the balls least frequently drawn over 50 results. Some players use a Daily Lotto cold number strategy based on the theory of statistical reversion.
                                </p>
                            </div>
                        </article>

                    </div>
                </section>

                <section id="pairs" aria-labelledby="pairs-heading">
                    <h2 class="ndl-section-title" id="pairs-heading">High-Frequency Pairs &amp; Triplets</h2>
                    <p class="ndl-section-sub">Number combinations that have appeared together most often in recent draws — useful for system bets and cover plays.</p>

                    <div class="ndl-combo-grid">

                        <div class="ndl-combo-card">
                            <h3>🔗 Top 2-Number Pairs</h3>
                            <p>Most common pairs drawn together in the last 50 SA Daily Lotto results.</p>
                            <ul class="ndl-combo-list" aria-label="Top pairs">
                                <?php foreach ($topPairs as $pairStr => $count): $nums = explode(',', $pairStr); ?>
                                <li>
                                    <div class="ndl-combo-nums">
                                        <span class="ndl-combo-ball"><?php echo $nums[0]; ?></span>
                                        <span class="ndl-combo-ball"><?php echo $nums[1]; ?></span>
                                    </div>
                                    <span class="ndl-combo-freq">Drawn <?php echo $count; ?>×</span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>

                        <div class="ndl-combo-card">
                            <h3>⚡ Top 3-Number Triplets</h3>
                            <p>Triplets that have appeared most frequently in recent draws — ideal for system 5/3 bets.</p>
                            <ul class="ndl-combo-list" aria-label="Top triplets">
                                <?php foreach ($topTriplets as $tripStr => $count): $nums = explode(',', $tripStr); ?>
                                <li>
                                    <div class="ndl-combo-nums">
                                        <span class="ndl-combo-ball"><?php echo $nums[0]; ?></span>
                                        <span class="ndl-combo-ball"><?php echo $nums[1]; ?></span>
                                        <span class="ndl-combo-ball"><?php echo $nums[2]; ?></span>
                                    </div>
                                    <span class="ndl-combo-freq">Drawn <?php echo $count; ?>×</span>
                                </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>

                    </div>
                </section>

                <section id="how-it-works" class="ndl-how" aria-labelledby="how-heading">
                    <h2 class="ndl-section-title" id="how-heading">How Our Daily Lotto Prediction Algorithm Works</h2>
                    <p>
                        Our <strong>Daily Lotto prediction algorithm</strong> runs a multi-layer frequency analysis against the last 50 verified South African Daily Lotto draws sourced directly from official Ithuba results. Here is what the model evaluates with each update:
                    </p>
                    <ul class="ndl-check-list">
                        <li><strong>Frequency scoring</strong> — every ball from 1–36 is ranked by how many times it appeared in the analysis window.</li>
                        <li><strong>Hot number identification</strong> — the top-five most frequently drawn balls are flagged as current Daily Lotto hot numbers.</li>
                        <li><strong>Overdue / cold number identification</strong> — the five least-drawn balls are highlighted as statistically overdue.</li>
                        <li><strong>Pair &amp; triplet co-occurrence analysis</strong> — all two- and three-ball combinations are tracked across draws to surface statistically significant affinities.</li>
                        <li><strong>Balanced combination assembly</strong> — the Balanced Smart Pick blends hot, cold, and median-frequency numbers for broader probability distribution.</li>
                        <li><strong>Retrospective accuracy tracking</strong> — the system back-calculates yesterday's prediction sets against yesterday's actual result so you can see recent performance transparency.</li>
                    </ul>

                    <div class="ndl-strategy-grid" id="hot-cold" aria-label="Strategy descriptions">
                        <div class="ndl-strategy-card card-s-hot">
                            <h3>🔥 Hot Numbers Strategy</h3>
                            <p>Numbers that have been drawn most often recently. These carry current statistical momentum in the dataset.</p>
                        </div>
                        <div class="ndl-strategy-card card-s-cold">
                            <h3>❄️ Overdue / Cold Numbers</h3>
                            <p>Numbers absent from recent draws. Statistical reversion theory suggests these may be due for a return, though each draw is independent.</p>
                        </div>
                        <div class="ndl-strategy-card card-s-balanced">
                            <h3>🎯 Balanced Smart Pick</h3>
                            <p>A structured blend of hot, cold, and mid-range numbers — our recommended Daily Lotto smart pick for players who want broad frequency coverage.</p>
                        </div>
                    </div>

                    <h3 style="font-size:1.15rem;font-weight:800;color:var(--navy);margin:28px 0 4px;">Top 10 Hottest Daily Lotto Numbers — Last 50 Draws</h3>
                    <p style="font-size:.88rem;color:var(--slate);margin:0 0 16px;">Official frequency chart based on verified Ithuba draw data.</p>
                    <div class="ndl-chart-wrap">
                        <canvas id="frequencyChart" aria-label="Bar chart: top 10 hot numbers by draw frequency"></canvas>
                    </div>
                    <p style="font-size: 0.87rem; color: var(--slate); margin-top: 12px;">
                        All results are verified from the 
                        <a href="https://www.nationallottery.co.za/info/results_daily_lotto" target="_blank" rel="noopener noreferrer nofollow">official South African National Lottery Daily Lotto results</a> 
                        and updated shortly after each 21:00 SAST draw.
                    </p>
                </section>

                <div class="ndl-author">
                    <strong>Statistical Analysis &amp; Draw Research — NextDrawLogic</strong>
                    <p>All prediction data is generated using verified SA Daily Lotto draw records and statistical frequency modelling. This page is updated automatically each day before the 21:00 draw to ensure you always have today's most current Daily Lotto predictions.</p>
                </div>

                <section id="faqs" class="ndl-faq" aria-labelledby="faq-heading">
                    <h2 class="ndl-faq-header" id="faq-heading">Frequently Asked Questions About Daily Lotto Predictions</h2>
                    <div class="ndl-faq-list">
                        <?php foreach ($pageFaqs as $faq): ?>
                        <div class="ndl-faq-item">
                            <button class="ndl-faq-question" aria-expanded="false">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="ndl-faq-icon" aria-hidden="true">+</span>
                            </button>
                            <div class="ndl-faq-answer" role="region">
                                <div class="ndl-faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="ndl-int-links" aria-label="Related tools and pages">
                    <h2>Strengthen Your Strategy</h2>
                    <p>Cross-reference today's Daily Lotto predictions with our full suite of analytical tools.</p>
                    <ul class="ndl-pill-nav">
                        <li><a href="/hot-and-cold-numbers/daily-lotto/">Daily Lotto Hot &amp; Cold Stats <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a></li>
                        <li><a href="/results/daily-lotto/history/">Daily Lotto Historical Results <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a></li>
                        <li><a href="/predictions/powerball/">PowerBall Predictions SA <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a></li>
                        <li><a href="/lotto/results/">SA Lotto Results Hub <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg></a></li>
                    </ul>
                </section>

                <section class="ndl-related" aria-labelledby="related-heading">
                    <h2 id="related-heading">More Daily Lotto Tools</h2>
                    <div class="ndl-related-grid">
                        <div class="ndl-related-card">
                            <div class="rc-icon">🎰</div>
                            <h3>Daily Lotto Number Generator</h3>
                            <p>Prefer a fully random approach? Our Daily Lotto number generator delivers randomised quick picks instantly.</p>
                            <a href="/number-generator/daily-lotto/">Use Generator &rarr;</a>
                        </div>
                        <div class="ndl-related-card">
                            <div class="rc-icon">🔥</div>
                            <h3>Hot &amp; Cold Number Stats</h3>
                            <p>Deep-dive into Daily Lotto hot and cold numbers with full historical frequency tables across all draws.</p>
                            <a href="/hot-and-cold-numbers/daily-lotto/">View Full Stats &rarr;</a>
                        </div>
                        <div class="ndl-related-card">
                            <div class="rc-icon">🎫</div>
                            <h3>Ticket Checker</h3>
                            <p>Check your numbers against the latest official Daily Lotto results instantly — for free.</p>
                            <a href="/check-tickets/daily-lotto/">Check Tickets &rarr;</a>
                        </div>
                    </div>
                </section>

                <aside class="ndl-disclaimer" role="note" aria-label="Disclaimer">
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <circle cx="12" cy="12" r="10"/>
        <line x1="12" y1="16" x2="12" y2="12"/>
        <line x1="12" y1="8" x2="12.01" y2="8"/>
    </svg>
    <div>
        <strong>Disclaimer &amp; Responsible Play</strong>
        
        <p>
            NextDrawLogic is an independent  informational platform. We are not affiliated with, endorsed by, or sponsored by Ithuba Holdings or the Official South African National Lottery.
        </p>
        
        <p>
            All lottery predictions, statistics, and number analyses are generated using 
            mathematical algorithms and historical data for <strong>entertainment and informational purposes only</strong>.
        </p>
        
        <p><strong>Lottery games are games of pure chance.</strong> 
            Past results and number frequency do not influence or predict future draws. 
            No prediction method can guarantee winning numbers.
        </p>
        
        <p>
            Please play responsibly and only with money you can afford to lose. 
            If you or someone you know needs support, contact the 
            <a href="https://www.responsiblegambling.co.za/" target="_blank" rel="noopener nofollow">Responsible Gambling Council of South Africa</a> 
            or call the National Gambling Helpline on <strong>0800 006 008</strong>.
        </p>
        
        <p>
            <strong>Data Source:</strong> 
            Official results from the 
            <a href="https://www.nationallottery.co.za/home" target="_blank" rel="noopener nofollow">South African National Lottery</a>. 
            Independently collected, verified, and updated after every official draw.
            Last updated: <?php echo date('F j, Y \a\t g:i A T'); ?>.
        </p>
    </div>
</aside>

            </div><!-- /ndl-content -->

            <aside class="ndl-sidebar" aria-label="Daily Lotto quick links">
                <nav class="ndl-sidebar-card">
                    <div class="ndl-sidebar-head">Daily Lotto Panel</div>

                    <div class="ndl-draw-chip" aria-label="Next draw information">
                        <div class="dc-label">Next Draw</div>
                        <div class="dc-date"><?php echo $nextDrawFormatted; ?></div>
                        <div class="dc-time">21:00 SAST · <?php echo $nextDrawDay; ?></div>
                    </div>

                    <ul class="ndl-sidebar-links">
                        <li><a href="/results/daily-lotto/<?php echo $slug; ?>/">📊 Latest Results</a></li>
                        <li><a href="/results/daily-lotto/history/">🗓 Draw History</a></li>
                        <li><a href="/predictions/daily-lotto/" class="active">🎯 Smart Predictions</a></li>
                        <li><a href="/check-tickets/daily-lotto/">🎫 Check Tickets</a></li>
                        <li><a href="/hot-and-cold-numbers/daily-lotto/">🔥 Hot &amp; Cold Numbers</a></li>
                        <li><a href="/number-generator/daily-lotto/">🎰 Generate Numbers</a></li>
                    </ul>
                </nav>
            </aside>

        </div><!-- /ndl-layout -->
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function () {

        document.querySelectorAll('.ndl-faq-question').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var item = btn.closest('.ndl-faq-item');
                var isOpen = item.classList.contains('active');
                // Close all
                document.querySelectorAll('.ndl-faq-item').forEach(function (el) {
                    el.classList.remove('active');
                    el.querySelector('.ndl-faq-question').setAttribute('aria-expanded', 'false');
                });
                // Open clicked
                if (!isOpen) {
                    item.classList.add('active');
                    btn.setAttribute('aria-expanded', 'true');
                }
            });
        });

        var ctx = document.getElementById('frequencyChart');
        if (ctx) {
            var chartLabels = <?php echo json_encode(array_map(fn($n) => 'Ball '.$n, $chartLabels)); ?>;
            var chartData   = <?php echo json_encode($chartData); ?>;

            new Chart(ctx.getContext('2d'), {
                type: 'bar',
                data: {
                    labels: chartLabels,
                    datasets: [{
                        label: 'Draw Frequency (Last 50 Draws)',
                        data: chartData,
                        backgroundColor: function (ctx) {
                            var colors = ['#1d5fe5','#1d5fe5','#1d5fe5','#1d5fe5','#1d5fe5',
                                          '#3b9eff','#3b9eff','#3b9eff','#94a3b8','#94a3b8'];
                            return colors[ctx.dataIndex] || '#94a3b8';
                        },
                        borderRadius: 5,
                        hoverBackgroundColor: '#f5a623'
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: '#0e2044',
                            padding: 12,
                            titleFont: { family: 'Outfit', size: 14, weight: '700' },
                            bodyFont:  { family: 'Outfit', size: 13 },
                            callbacks: {
                                label: function (ctx) { return ' Drawn ' + ctx.parsed.y + ' times'; }
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            grid: { color: '#f1f5f9' },
                            ticks: { precision: 0, font: { family: 'Outfit' }, color: '#475569' }
                        },
                        x: {
                            grid: { display: false },
                            ticks: { font: { family: 'Outfit', weight: '700' }, color: '#334155' }
                        }
                    }
                }
            });
        }
    });
    </script>

</body>
</html>