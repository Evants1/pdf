<?php
/**
 * Plugin Name:       Claude Auto Poster
 * Description:       Generates posts on a schedule with Claude (Anthropic API) through a research → brief → draft → edit → QA pipeline, with designed featured and in-article images, working through a topic and keyword queue you control.
 * Version:           2.1.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Akani
 * License:           GPL-2.0-or-later
 * Text Domain:       claude-auto-poster
 */

if (!defined('ABSPATH')) exit;

require_once __DIR__ . '/includes/class-cap-image.php';

final class Claude_Auto_Poster {

    const OPT_SETTINGS = 'cap_settings';
    const OPT_TOPICS   = 'cap_topics';
    const OPT_LOG      = 'cap_log';
    const CRON_HOOK    = 'cap_generate_post';
    const SCHEDULE     = 'cap_custom_interval';
    const LOCK         = 'cap_running_lock';
    const OPT_KEYWORDS = 'cap_keywords';
    const OPT_TYPES    = 'cap_types';
    const OPT_WORDS    = 'cap_words';
    const OPT_FAILS    = 'cap_topic_fails';
    const MANUAL_HOOK  = 'cap_generate_manual';
    const OPT_LASTFAIL = 'cap_last_failed_run';

    /** Content languages: code => [label shown in admin, name given to Claude, text direction]. */
    const LANGUAGES = [
        'en' => ['English',              'English',                         'ltr'],
        'es' => ['Spanish',              'Spanish',                         'ltr'],
        'fr' => ['French',               'French',                          'ltr'],
        'zh' => ['Chinese (Simplified)', 'Simplified Chinese (Mandarin)',   'ltr'],
        'hi' => ['Hindi',                'Hindi (Devanagari script)',       'ltr'],
        'ar' => ['Arabic',               'Modern Standard Arabic',          'rtl'],
    ];

    /**
     * Target markets: tag => [label, ISO country for web search, region, timezone, currency, English variant].
     * Tags are used at the start of a topic line, e.g. [au] or [ca-on].
     */
    const GEOS = [
        'au'    => ['Australia',             'AU', '',        'Australia/Sydney',    'AUD ($)',   'Australian English'],
        'nz'    => ['New Zealand',           'NZ', '',        'Pacific/Auckland',    'NZD ($)',   'New Zealand English'],
        'za'    => ['South Africa',          'ZA', '',        'Africa/Johannesburg', 'ZAR (R)',   'South African English'],
        'uk'    => ['United Kingdom',        'GB', '',        'Europe/London',       'GBP (£)',   'British English'],
        'us'    => ['United States',         'US', '',        'America/New_York',    'USD ($)',   'American English'],
        'ca'    => ['Canada',                'CA', '',        'America/Toronto',     'CAD ($)',   'Canadian English'],
        'ca-on' => ['Canada – Ontario',      'CA', 'Ontario', 'America/Toronto',     'CAD ($)',   'Canadian English'],
    ];

    public static function init() {
        add_filter('cron_schedules', [__CLASS__, 'cron_schedules']);
        add_action(self::CRON_HOOK, [__CLASS__, 'run']);
        add_action(self::MANUAL_HOOK, [__CLASS__, 'run'], 10, 3);
        add_filter('display_post_states', [__CLASS__, 'post_states'], 10, 2);
        add_action('add_meta_boxes', [__CLASS__, 'add_meta_boxes'], 10, 2);
        add_action('add_meta_boxes', [__CLASS__, 'add_optimise_box'], 10, 2);
        add_action('wp_ajax_cap_opt_start', [__CLASS__, 'ajax_opt_start']);
        add_action('wp_ajax_cap_opt_status', [__CLASS__, 'ajax_opt_status']);
        add_action('admin_menu', [__CLASS__, 'register_compare_page']);
        add_action('admin_post_cap_opt_apply', [__CLASS__, 'handle_opt_apply']);
        add_action('admin_notices', [__CLASS__, 'opt_admin_notice']);
        add_filter('plugin_action_links_' . plugin_basename(__FILE__), function ($links) {
            array_unshift($links, '<a href="' . esc_url(self::page_url()) . '">Settings</a>');
            return $links;
        });
        add_action('admin_menu', [__CLASS__, 'admin_menu']);
        add_action('admin_init', [__CLASS__, 'register_settings']);
        add_action('admin_post_cap_generate_now', [__CLASS__, 'handle_generate_now']);
        add_action('admin_post_cap_run_direct', [__CLASS__, 'handle_run_direct']);
        add_action('admin_post_cap_system_check', [__CLASS__, 'handle_system_check']);
        add_action('admin_post_cap_image_preview', [__CLASS__, 'handle_image_preview']);
        add_action('init', [__CLASS__, 'register_doc_type']);
        foreach (['upload', 'bulk', 'edit', 'delete', 'export', 'download'] as $a) {
            add_action('admin_post_cap_doc_' . $a, [__CLASS__, 'handle_doc_' . $a]);
        }
        add_action('admin_post_cap_save_topics', [__CLASS__, 'handle_save_topics']);
        add_action('admin_post_cap_test_email', [__CLASS__, 'handle_test_email']);
        add_action('update_option_' . self::OPT_SETTINGS, [__CLASS__, 'reschedule'], 10, 0);
        add_action('add_option_' . self::OPT_SETTINGS, [__CLASS__, 'reschedule'], 10, 0);
    }

    /* ---------------------------------------------------------------
     * Settings helpers
     * ------------------------------------------------------------- */

    public static function defaults() {
        return [
            'api_key'        => '',
            'model'          => 'claude-sonnet-5-5',
            'posts_per_day'  => 3,
            'enabled'        => 0,
            'post_status'    => 'draft',
            'author_id'      => get_current_user_id() ?: 1,
            'category_id'    => 0,
            'max_tokens'     => 12000,
            'word_count'     => 1500,
            'system_prompt'  => "You are an experienced editor writing accurate, genuinely useful articles for this website.\n"
                              . "Write clearly and naturally for the site's audience. Do not invent statistics, quotes, prices or facts you are not confident about.\n"
                              . "Avoid filler, clichés and generic introductions. Use descriptive subheadings.",
            'extra_instructions' => '',
            'notify_enabled' => 1,
            'notify_to'      => 'david.b@goldmedialab.com',
            'notify_cc'      => 'Takudzwa@goldmedialab.com, seodev@goldmedialab.com',
            'img_featured'   => 1,
            'img_body'       => 1,
            'img_text'       => 1,
            'img_brand'      => '',
            'img_bg'         => '#0F1B3D',
            'img_accent'     => '#F5B700',
            'language'       => 'en',
            'content_type'   => 'post',
            'geo'            => '',
            'parent_page'    => 0,
            'web_research'   => 0,
            'edit_pass'      => 1,
            'qa_enabled'     => 1,
            'qa_threshold'   => 80,
            'max_rewrites'   => 1,
            'voice_guide'    => '',
            'content_checklist' => "- Answers the reader's main question (search intent) within the first two or three paragraphs.\n"
                                 . "- Primary keyword appears naturally in the title, the first 100 words and at least one H2. Secondary keywords are used where they fit, with no keyword stuffing.\n"
                                 . "- Clear structure: descriptive H2/H3 headings, short paragraphs, and lists or a table where they genuinely help the reader.\n"
                                 . "- Specific, practical information the reader can act on. No vague generalities or padding.\n"
                                 . "- No invented facts: no made-up statistics, bonus amounts, wagering figures, RTP values, licence details, payout times or quotes. If a figure is not certain, tell the reader how to check it instead.\n"
                                 . "- Gambling topics: include a short responsible gambling note (age limit, play responsibly, set limits) and never promise or imply guaranteed winnings.\n"
                                 . "- A short FAQ section near the end with 3 to 5 questions real searchers ask, each as an H3.\n"
                                 . "- Ends with a clear takeaway or next step, not a generic summary.",
            'editing_guide'  => "- Cut filler, repetition and throat-clearing introductions.\n"
                              . "- Remove AI-sounding phrases such as \"in today's fast-paced world\", \"dive into\", \"navigate the landscape\", \"it's important to note\", \"unlock\", \"game-changer\", \"in conclusion\".\n"
                              . "- Vary sentence length and rhythm. Use plain, direct, confident language.\n"
                              . "- Prefer concrete examples over abstract claims.\n"
                              . "- Keep the voice consistent with the voice & style guide.\n"
                              . "- Soften or remove any claim that cannot be supported.\n"
                              . "- Keep headings, keyword placement and every checklist item intact while editing.",
        ];
    }

    public static function settings() {
        return wp_parse_args(get_option(self::OPT_SETTINGS, []), self::defaults());
    }

    /** API key: wp-config constant wins over the stored setting. */
    public static function api_key() {
        // Trim stray spaces, line breaks and quotes that often sneak in when a key is copied.
        $clean = function ($k) { return trim((string) $k, " \t\n\r\0\x0B\"'“”‘’"); };
        $const = self::key_constant();
        if ($const) return $clean(constant($const));
        return $clean(self::settings()['api_key']);
    }

    /** wp-config.php constant holding the key. Older/common names are accepted too. */
    private static function key_constant() {
        foreach (['CAP_ANTHROPIC_KEY', 'CAD_ANTHROPIC_API_KEY', 'CAD_ANTHROPIC_KEY', 'CAP_ANTHROPIC_API_KEY', 'ANTHROPIC_API_KEY'] as $c) {
            if (defined($c) && constant($c)) return $c;
        }
        return '';
    }

    private static function key_source() {
        $c = self::key_constant();
        return $c ? 'wp-config.php (' . $c . ')' : 'General settings';
    }

    /** e.g. sk-ant-api03-…x7Qa (the Console lists keys by their last characters). */
    private static function key_masked() {
        $k = self::api_key();
        return $k === '' ? '' : substr($k, 0, 12) . '…' . substr($k, -4);
    }

    /** Ask Anthropic whether the key works (no tokens used). */
    private static function test_key() {
        $k = self::api_key();
        if ($k === '') return [false, 'Missing. Add it in General or in wp-config.php.'];
        if (strpos($k, 'sk-ant-') !== 0) {
            return [false, 'This does not look like a Claude API key (keys start with “sk-ant-”). Key in use starts with “' . substr($k, 0, 8) . '…” (from ' . self::key_source() . ').'];
        }
        $r = wp_remote_get('https://api.anthropic.com/v1/models?limit=1', [
            'timeout' => 15,
            'headers' => ['x-api-key' => $k, 'anthropic-version' => '2023-06-01'],
        ]);
        $where = ' Key in use: ' . self::key_masked() . ' (from ' . self::key_source() . ').';
        if (is_wp_error($r)) return ['warn', 'Could not reach Anthropic: ' . $r->get_error_message() . '.' . $where];
        $code = (int) wp_remote_retrieve_response_code($r);
        if ($code === 200) return [true, 'Valid.' . $where];
        if ($code === 401) return [false, 'Rejected as invalid (401).' . $where . ' Compare the last 4 characters with the keys listed in the Claude Console (Keys & access → API keys). If no key there ends the same way, or that key has expired, this site has an old or wrong key.'];
        if ($code === 403) return [false, 'Not permitted (403): the key exists but its workspace or organization is blocked.' . $where];
        return ['warn', 'Unexpected response (HTTP ' . $code . ').' . $where];
    }

    public static function topics() {
        $t = get_option(self::OPT_TOPICS, []);
        return is_array($t) ? $t : [];
    }

    /* ---------------------------------------------------------------
     * Scheduling
     * ------------------------------------------------------------- */

    public static function cron_schedules($schedules) {
        $n = max(1, min(24, (int) self::settings()['posts_per_day']));
        $schedules[self::SCHEDULE] = [
            'interval' => (int) floor(DAY_IN_SECONDS / $n),
            'display'  => sprintf('Claude Auto Poster (%d per day)', $n),
        ];
        return $schedules;
    }

    public static function reschedule() {
        wp_clear_scheduled_hook(self::CRON_HOOK);
        if (self::settings()['enabled']) {
            wp_schedule_event(time() + 120, self::SCHEDULE, self::CRON_HOOK);
        }
    }

    public static function activate() {
        self::reschedule();
    }

    public static function deactivate() {
        wp_clear_scheduled_hook(self::CRON_HOOK);
    }

    /* ---------------------------------------------------------------
     * Logging
     * ------------------------------------------------------------- */

    public static function log($message, $type = 'info') {
        $log = get_option(self::OPT_LOG, []);
        array_unshift($log, [
            'time'    => current_time('mysql'),
            'type'    => $type,
            'message' => $message,
        ]);
        update_option(self::OPT_LOG, array_slice($log, 0, 30), false);
        if ($type === 'error') error_log('[Claude Auto Poster] ' . $message);
    }

    /* ---------------------------------------------------------------
     * The job
     * ------------------------------------------------------------- */

    /**
     * Generate one post from the next topic in the queue.
     * @return int|WP_Error Post ID on success.
     */
    public static function run($lang_override = '', $type_override = '', $geo_override = '') {
        if (get_transient(self::LOCK)) {
            self::log('Skipped: another post is still being generated.', 'warn');
            return new WP_Error('locked', 'A generation is already running.');
        }
        set_transient(self::LOCK, 1, 30 * MINUTE_IN_SECONDS);
        update_option('cap_last_run', time(), false);
        if (function_exists('ignore_user_abort')) ignore_user_abort(true);
        if (function_exists('set_time_limit')) @set_time_limit(0);

        try {
            return self::generate(is_string($lang_override) ? $lang_override : '', is_string($type_override) ? $type_override : '', is_string($geo_override) ? $geo_override : '');
        } finally {
            delete_transient(self::LOCK);
        }
    }

    /**
     * Pull optional tags off the front of a topic line, in any order:
     * a language ([es], [fr], ...) and/or a content type ([page] or [post]).
     * @return array [language code or '', 'post'|'page'|'', topic text, market tag or '']
     */
    private static function split_topic_tags($topic) {
        $lang = '';
        $type = '';
        $geo  = '';
        $extra = [];
        $text = trim($topic);
        while (preg_match('/^\[([a-z][a-z0-9-]{1,19})\]\s*/i', $text, $m)) {
            $tag = strtolower($m[1]);
            if (isset(self::LANGUAGES[$tag]) && !$lang) {
                $lang = $tag;
            } elseif (isset(self::GEOS[$tag]) && !$geo) {
                $geo = $tag;
            } elseif (($tag === 'page' || $tag === 'post') && !$type) {
                $type = $tag;
            } else {
                $extra[] = $tag; // custom tags such as [review] or [hub] select SOP documents
            }
            $text = trim(substr($text, strlen($m[0])));
        }
        return [$lang, $type, $text !== '' ? $text : $topic, $geo, $extra];
    }

    private static function geo_label($geo) {
        return isset(self::GEOS[$geo]) ? self::GEOS[$geo][0] : 'Global (no specific country)';
    }

    private static function type_label($type) {
        return $type === 'page' ? 'Page' : 'Post';
    }

    private static function lang_label($code) {
        return self::LANGUAGES[$code][0] ?? 'English';
    }

    /* ---------------------------------------------------------------
     * Claude API helpers
     * ------------------------------------------------------------- */

    /** Token / search usage for the post currently being generated. */
    private static $usage = ['in' => 0, 'out' => 0, 'searches' => 0, 'calls' => 0];

    /** Step-by-step record of the current run, saved on the post as its process report. */
    private static $trace = [];
    private static $run   = [];

    /** Search queries and result pages seen during competitor research. */
    private static $research = ['queries' => [], 'results' => [], 'errors' => []];

    private static function capture_research($content) {
        $last_query = '';
        foreach ((array) $content as $blk) {
            if (!is_array($blk)) continue;
            $bt = $blk['type'] ?? '';
            if ($bt === 'server_tool_use' && ($blk['name'] ?? '') === 'web_search' && !empty($blk['input']['query'])) {
                $last_query = (string) $blk['input']['query'];
                self::$research['queries'][] = $last_query;
            } elseif ($bt === 'web_search_tool_result') {
                $c = $blk['content'] ?? [];
                if (is_array($c) && ($c['type'] ?? '') === 'web_search_tool_result_error') {
                    self::$research['errors'][] = (string) ($c['error_code'] ?? 'unknown');
                    continue;
                }
                $pos = 0;
                foreach ((array) $c as $res) {
                    if (!is_array($res) || ($res['type'] ?? '') !== 'web_search_result' || empty($res['url'])) continue;
                    $pos++;
                    $url = esc_url_raw($res['url']);
                    foreach (self::$research['results'] as $seen) { if ($seen['url'] === $url) continue 2; }
                    self::$research['results'][] = [
                        'url'      => $url,
                        'title'    => sanitize_text_field($res['title'] ?? ''),
                        'age'      => sanitize_text_field($res['page_age'] ?? ''),
                        'query'    => $last_query,
                        'position' => $pos,
                    ];
                }
            }
        }
    }

    private static function stage_start() {
        return ['t' => microtime(true), 'u' => self::$usage];
    }

    private static function stage_end($mark, $key, $label, $status, $summary, $data = null) {
        self::$trace[] = [
            'key'      => $key,
            'label'    => $label,
            'status'   => $status, // ok | warn | fail
            'seconds'  => round(microtime(true) - $mark['t'], 1),
            'calls'    => self::$usage['calls'] - $mark['u']['calls'],
            'in'       => self::$usage['in'] - $mark['u']['in'],
            'out'      => self::$usage['out'] - $mark['u']['out'],
            'searches' => self::$usage['searches'] - $mark['u']['searches'],
            'summary'  => $summary,
            'data'     => $data,
        ];
    }

    private static function count_words($html, $lang = 'en') {
        $plain = trim(wp_strip_all_tags((string) $html));
        if ($lang === 'zh') return mb_strlen(preg_replace('/\s+/u', '', $plain));
        return count(preg_split('/\s+/u', $plain, -1, PREG_SPLIT_NO_EMPTY));
    }

    private static function length_label($n, $lang) {
        return '~' . number_format((int) $n) . ($lang === 'zh' ? ' characters' : ' words');
    }

    /** Snapshot of one version of the article for the report. */
    private static function snapshot($p, $lang) {
        return [
            'title'   => (string) ($p['title'] ?? ''),
            'excerpt' => (string) ($p['excerpt'] ?? ''),
            'words'   => self::count_words($p['content_html'] ?? '', $lang),
            'content' => (string) ($p['content_html'] ?? ''),
        ];
    }

    /** Full report for the post (stored as JSON; slashed so WordPress doesn't strip the escapes). */
    private static function build_report($final_status, $post_id = 0) {
        return array_merge(self::$run, [
            'finished' => current_time('mysql'),
            'seconds'  => round(microtime(true) - (self::$run['t0'] ?? microtime(true)), 1),
            'result'   => $final_status,
            'post_id'  => (int) $post_id,
            'totals'   => self::$usage,
            'stages'   => self::$trace,
        ]);
    }

    /**
     * One Messages API call. Handles pause_turn (long web research) by continuing.
     * @return string|WP_Error The final text of Claude's answer.
     */
    private static function api($system, $user, $max_tokens, $tools = []) {
        $s        = self::settings();
        $messages = [['role' => 'user', 'content' => $user]];

        for ($i = 0; $i < 4; $i++) {
            $payload = [
                'model'      => $s['model'],
                'max_tokens' => (int) $max_tokens,
                'system'     => $system,
                'messages'   => $messages,
            ];
            if ($tools) $payload['tools'] = $tools;

            $response = wp_remote_post('https://api.anthropic.com/v1/messages', [
                'timeout' => 300,
                'headers' => [
                    'x-api-key'         => self::api_key(),
                    'anthropic-version' => '2023-06-01',
                    'content-type'      => 'application/json',
                ],
                'body' => wp_json_encode($payload),
            ]);

            if (is_wp_error($response)) {
                return new WP_Error('http', 'Request failed: ' . $response->get_error_message());
            }
            $code = (int) wp_remote_retrieve_response_code($response);
            $body = json_decode(wp_remote_retrieve_body($response), true);
            if ($code !== 200) {
                $msg = $body['error']['message'] ?? wp_remote_retrieve_body($response);
                return new WP_Error('api', "API error ({$code}): " . substr((string) $msg, 0, 300));
            }

            self::$usage['calls']++;
            self::$usage['in']       += (int) ($body['usage']['input_tokens'] ?? 0);
            self::$usage['out']      += (int) ($body['usage']['output_tokens'] ?? 0);
            self::$usage['cached']    = (self::$usage['cached'] ?? 0) + (int) ($body['usage']['cache_read_input_tokens'] ?? 0) + (int) ($body['usage']['cache_creation_input_tokens'] ?? 0);
            self::$usage['searches'] += (int) ($body['usage']['server_tool_use']['web_search_requests'] ?? 0);
            if ($tools) self::capture_research($body['content'] ?? []);

            $stop = $body['stop_reason'] ?? '';
            if ($stop === 'pause_turn') {
                // Long-running server tool turn: send it back so Claude can continue.
                $messages[] = ['role' => 'assistant', 'content' => $body['content']];
                continue;
            }
            if ($stop === 'max_tokens') {
                return new WP_Error('cut_off', sprintf('Output was cut off at %d tokens. Raise "Max tokens" in General settings.', (int) ($body['usage']['output_tokens'] ?? $max_tokens)));
            }

            // Keep only the text written after the last search result (the actual answer).
            $text = '';
            foreach (($body['content'] ?? []) as $block) {
                $type = $block['type'] ?? '';
                if ($type === 'server_tool_use' || $type === 'web_search_tool_result') {
                    $text = '';
                } elseif ($type === 'text') {
                    $text .= $block['text'];
                }
            }
            return $text;
        }
        return new WP_Error('pause', 'Web research did not finish in time.');
    }

    private static function parse_json($text) {
        $text = trim(preg_replace('/^```(?:json)?\s*|\s*```$/', '', trim((string) $text)));
        $json = json_decode($text, true);
        if (is_array($json)) return $json;
        $a = strpos($text, '{');
        $b = strrpos($text, '}');
        if ($a !== false && $b !== false && $b > $a) {
            $json = json_decode(substr($text, $a, $b - $a + 1), true);
            if (is_array($json)) return $json;
        }
        return null;
    }

    /** API call that must return a JSON object. Retries once if the JSON is unreadable. */
    private static function api_json($system, $user, $max_tokens, $tools = []) {
        for ($try = 0; $try < 2; $try++) {
            $text = self::api($system, $user, $max_tokens, $tools);
            // Cut off? Retry once with double the room (up to 32,000) instead of failing the whole run.
            if (is_wp_error($text) && $text->get_error_code() === 'cut_off' && $max_tokens < 32000) {
                $bigger = min(32000, $max_tokens * 2);
                self::log(sprintf('Output hit the %s-token limit; retrying this step with %s.', number_format($max_tokens), number_format($bigger)), 'warn');
                $max_tokens = $bigger;
                $text = self::api($system, $user, $max_tokens, $tools);
            }
            if (is_wp_error($text)) return $text;
            $json = self::parse_json($text);
            if (is_array($json)) return $json;
        }
        return new WP_Error('parse', 'Could not read Claude\'s response as JSON.');
    }

    /* ---------------------------------------------------------------
     * Queue helpers
     * ------------------------------------------------------------- */

    public static function keywords() {
        $k = get_option(self::OPT_KEYWORDS, []);
        return is_array($k) ? $k : [];
    }

    /** The queue as rows: topic, keywords, type (post|page) and word count. Older queues are filled in with defaults. */
    public static function queue() {
        $s     = self::settings();
        $types = (array) get_option(self::OPT_TYPES, []);
        $words = (array) get_option(self::OPT_WORDS, []);
        $kw    = self::keywords();
        $rows  = [];
        foreach (self::topics() as $i => $t) {
            list(, $tag_type) = self::split_topic_tags($t);
            $type = in_array($types[$i] ?? '', ['post', 'page'], true) ? $types[$i] : ($tag_type ?: ($s['content_type'] === 'page' ? 'page' : 'post'));
            $rows[] = [
                'topic'    => $t,
                'keywords' => (string) ($kw[$i] ?? ''),
                'type'     => $type,
                'words'    => max(300, min(5000, (int) ($words[$i] ?? 0) ?: (int) $s['word_count'])),
            ];
        }
        return $rows;
    }

    private static function save_queue(array $rows) {
        update_option(self::OPT_TOPICS,   array_column($rows, 'topic'), false);
        update_option(self::OPT_KEYWORDS, array_column($rows, 'keywords'), false);
        update_option(self::OPT_TYPES,    array_column($rows, 'type'), false);
        update_option(self::OPT_WORDS,    array_column($rows, 'words'), false);
    }

    private static function queue_row_html($r) {
        ?>
        <tr>
            <td class="cap-q-n"><span></span><em>Next</em></td>
            <td><input type="text" data-f="topic" value="<?php echo esc_attr($r['topic']); ?>" required placeholder="e.g. Baccarat Rules and How to Play"></td>
            <td class="cap-q-type">
                <select data-f="type" required>
                    <option value="" <?php selected($r['type'], ''); ?> disabled>Choose…</option>
                    <option value="post" <?php selected($r['type'], 'post'); ?>>Post</option>
                    <option value="page" <?php selected($r['type'], 'page'); ?>>Page</option>
                </select>
            </td>
            <td class="cap-q-words"><input type="number" data-f="words" value="<?php echo (int) $r['words']; ?>" min="300" max="5000" step="50" required></td>
            <td><input type="text" data-f="keywords" value="<?php echo esc_attr($r['keywords']); ?>" placeholder="primary keyword, secondary keyword"></td>
            <td class="cap-q-act">
                <button type="button" class="button-link" data-act="up" title="Move up" aria-label="Move up">▲</button>
                <button type="button" class="button-link" data-act="down" title="Move down" aria-label="Move down">▼</button>
                <button type="button" class="button-link cap-q-del" data-act="del" title="Remove" aria-label="Remove">✕</button>
            </td>
        </tr>
        <?php
    }

    /** Remove the first topic with its keywords, type and word count. */
    private static function shift_queue() {
        $rows  = self::queue();
        $fails = get_option(self::OPT_FAILS, []);
        if ($rows) unset($fails[md5($rows[0]['topic'])]);
        array_shift($rows);
        self::save_queue($rows);
        update_option(self::OPT_FAILS, $fails, false);
        return count($rows);
    }

    /** Log a failure. After 3 failures in a row the topic is removed so it can't burn credits forever. */
    private static function fail($topic, $stage, WP_Error $err) {
        $msg   = $stage . ' failed: ' . $err->get_error_message();
        if (self::$run) {
            $report = self::build_report('failed');
            $report['error'] = $msg;
            update_option(self::OPT_LASTFAIL, $report, false);
        }
        $fails = get_option(self::OPT_FAILS, []);
        $key   = md5($topic);
        $fails[$key] = ($fails[$key] ?? 0) + 1;
        update_option(self::OPT_FAILS, $fails, false);

        if ($fails[$key] >= 3) {
            self::shift_queue();
            self::log($msg . ' Topic removed from the queue after 3 failed attempts: "' . $topic . '"', 'error');
        } else {
            self::log($msg . ' Topic kept in queue (attempt ' . $fails[$key] . ' of 3).', 'error');
        }
        return $err;
    }

    /* ---------------------------------------------------------------
     * The content pipeline
     * ------------------------------------------------------------- */

    /** Output format shared by the draft and revision passes. */
    private static function format_spec($lang, $lang_name) {
        return "Return ONLY a JSON object with these keys:\n"
             . "- \"title\": string, under 65 characters\n"
             . "- \"excerpt\": string, under 160 characters, usable as a meta description\n"
             . "- \"tags\": array of 3 to 6 short tag strings\n"
             . "- \"slug\": string, a short lowercase URL slug using only a-z, 0-9 and hyphens" . ($lang !== 'en' ? " (romanize/transliterate it; do not use {$lang_name} script)" : '') . "\n"
             . "- \"content_html\": string, the article body using only <h2>, <h3>, <p>, <ul>, <ol>, <li>, <strong>, <em>, <a>, <table>, <tr>, <th>, <td>. Do not include the title as an <h1>.\n"
             . "No markdown, no code fences, no text outside the JSON object. Keep the JSON keys in English.";
    }

    private static function valid_post($p) {
        return is_array($p) && !empty($p['title']) && !empty($p['content_html']);
    }

    private static function post_json($p) {
        return wp_json_encode([
            'title'        => $p['title'] ?? '',
            'excerpt'      => $p['excerpt'] ?? '',
            'tags'         => $p['tags'] ?? [],
            'slug'         => $p['slug'] ?? '',
            'content_html' => $p['content_html'] ?? '',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    }

    private static function generate($lang_override = '', $type_override = '', $geo_override = '') {
        $s = self::settings();
        self::$usage = ['in' => 0, 'out' => 0, 'searches' => 0, 'calls' => 0];
        self::$trace = [];
        self::$research = ['queries' => [], 'results' => [], 'errors' => []];
        self::$run   = [];

        if (!self::api_key()) {
            self::log('No API key set. Add it in Auto Poster → General or define CAP_ANTHROPIC_KEY in wp-config.php.', 'error');
            return new WP_Error('no_key', 'No API key set.');
        }
        if (strpos(self::api_key(), 'sk-ant-') !== 0) {
            // Stop before any request so the topic isn't charged a failed attempt.
            self::log('Not started: the key in ' . self::key_source() . ' does not look like a Claude API key (keys start with “sk-ant-”). Create one in the Claude Console under Keys & access → API keys.', 'error');
            return new WP_Error('bad_key', 'Not a Claude API key.');
        }

        $topics = self::topics();
        if (empty($topics)) {
            self::log('Topic queue is empty. Nothing generated.', 'error');
            return new WP_Error('no_topics', 'Topic queue is empty.');
        }
        $topic    = $topics[0];
        $keywords = self::keywords();
        $kws      = array_values(array_filter(array_map('trim', explode(',', (string) ($keywords[0] ?? '')))));
        $primary  = $kws[0] ?? '';

        // Priority for language and type: manual one-off choice > tag on the topic > default in settings.
        list($topic_lang, $topic_type, $topic_text, $topic_geo, $topic_tags) = self::split_topic_tags($topic);
        if ($geo_override === 'global') {
            $geo = '';
        } elseif (isset(self::GEOS[$geo_override])) {
            $geo = $geo_override;
        } elseif ($topic_geo) {
            $geo = $topic_geo;
        } else {
            $geo = isset(self::GEOS[$s['geo']]) ? $s['geo'] : '';
        }
        // Type and length come from the topic's row in the queue.
        $qrow = self::queue()[0] ?? ['type' => 'post', 'words' => (int) $s['word_count']];
        $type = in_array($type_override, ['post', 'page'], true) ? $type_override : $qrow['type'];
        $kind = $type === 'page'
            ? 'website page (evergreen reference content: no publish dates, no "this week" or news framing, written to stay accurate for a long time)'
            : 'blog post';
        if (isset(self::LANGUAGES[$lang_override])) {
            $lang = $lang_override;
        } elseif ($topic_lang) {
            $lang = $topic_lang;
        } else {
            $lang = isset(self::LANGUAGES[$s['language']]) ? $s['language'] : 'en';
        }
        list(, $lang_name, $dir) = self::LANGUAGES[$lang];

        $lang_rule = $lang === 'en'
            ? 'The article is written in English.'
            : "The article must be written entirely in {$lang_name}, natively for {$lang_name}-speaking readers and not as a translation from English. Instructions here may be in English; the article must not be.";
        if ($geo) {
            list($g_name, $g_cc, $g_region, , $g_cur, $g_eng) = self::GEOS[$geo];
            $lang_rule .= "\nTARGET MARKET: readers in {$g_name}. Write for them specifically: use {$g_cur} for any money amounts"
                        . ($lang === 'en' ? ", {$g_eng} spelling" : '')
                        . ", payment methods, terms and examples that are familiar locally, and the local context searchers there expect. "
                        . "Online gambling rules differ by country" . ($g_region ? ' and province' : '') . ": describe the legal position in {$g_name} only where you are confident, never imply that playing is legal where it is restricted, and point readers to the local regulator for the final word.";
        } else {
            $lang_rule .= "\nTARGET MARKET: international readers. Avoid country-specific legal claims and use neutral currency wording.";
        }
        $kw_text = $kws
            ? "Primary keyword: {$primary}\nSecondary keywords: " . (count($kws) > 1 ? implode(', ', array_slice($kws, 1)) : '(none)')
            : 'No keywords were supplied: choose the most sensible primary keyword for this topic and use it consistently.';

        $dctx = ['type' => $type, 'tags' => $topic_tags, 'kind' => $type === 'page' ? 'page' : 'post'];
        $core = "- Never invent facts: no made-up statistics, bonus amounts, wagering figures, RTP values, licence details, payout times or quotes. If a figure is not certain, tell the reader how to check it.\n"
              . "- Gambling topics: include a short responsible gambling note and never promise or imply guaranteed winnings.\n"
              . "- The primary keyword appears naturally in the title, the first 100 words and at least one H2.";
        $has_sop   = self::docs_for('draft', $dctx) || self::docs_for('qa', $dctx);
        $checklist = $has_sop
            ? "Follow the team's SOPs, writing rules and checklists provided in your instructions (the system documents). These rules always apply as well:\n{$core}"
            : (trim($s['content_checklist']) ?: self::defaults()['content_checklist']);
        $voice     = trim($s['voice_guide']);
        $voice_txt = $voice ? "\n\nVOICE & STYLE GUIDE:\n{$voice}" : '';
        $extra     = trim($s['extra_instructions']) ? "\n\nADDITIONAL INSTRUCTIONS:\n" . trim($s['extra_instructions']) : '';
        $writer    = $s['system_prompt'] . $voice_txt;
        $words     = max(300, (int) $qrow['words']);
        // Token budget per stage: the setting, but never less than the article needs.
        // Non-Latin scripts use far more tokens per word, so they get a bigger allowance.
        $per_word  = in_array($lang, ['zh', 'hi', 'ar'], true) ? 7 : 4;
        $max       = min(32000, max(12000, (int) $s['max_tokens'], $words * $per_word));
        self::$run = [
            't0'        => microtime(true),
            'started'   => current_time('mysql'),
            'topic'     => $topic_text,
            'keywords'  => $kws,
            'language'  => $lang,
            'type'      => $type,
            'geo'       => $geo,
            'model'     => $s['model'],
            'tags'      => $topic_tags,
            'docs'      => self::docs_plan(['type' => $type, 'tags' => $topic_tags]),
            'words'     => $words,
            'research'  => !empty($s['web_research']) ? 1 : 0,
            'edit_pass' => !empty($s['edit_pass']) ? 1 : 0,
            'qa'        => !empty($s['qa_enabled']) ? (int) $s['qa_threshold'] : 0,
            'rewrites_max' => (int) $s['max_rewrites'],
        ];
        $len_note  = ' This limit also applies to glossaries, A-Z lists and hub guides: choose the most useful items rather than trying to be exhaustive.';
        $len_rule  = "TARGET LENGTH: about {$words} words for the article body (stay within 10% either way; never exceed " . (int) round($words * 1.2) . ' words).' . $len_note;

        /* Stage 1: research + brief ------------------------------------ */
        $tools = [];
        $research_txt = '';
        if (!empty($s['web_research'])) {
            $tool = ['type' => 'web_search_20250305', 'name' => 'web_search', 'max_uses' => 5];
            if ($geo) {
                // Localize search results to the target country.
                $loc = ['type' => 'approximate', 'country' => self::GEOS[$geo][1], 'timezone' => self::GEOS[$geo][3]];
                if (self::GEOS[$geo][2]) $loc['region'] = self::GEOS[$geo][2];
                $tool['user_location'] = $loc;
            }
            $tools = [$tool];
            $research_txt = "\n\nCOMPETITOR RESEARCH: Before writing the brief, use web search to look at the pages currently ranking for the primary keyword"
                          . ($geo ? ' for searchers in ' . self::GEOS[$geo][0] . ' (search the way a local searcher would, and prefer sites aimed at that market)' : '')
                          . ($lang !== 'en' ? " in {$lang_name}-language results" : '')
                          . ". Note what they cover, how they are structured, and what they miss. Use this to find a better angle. Never copy their wording.";
        }
        $brief_prompt = "Create a content brief and outline for a {$kind}.\n\n"
                      . "TOPIC: {$topic_text}\n{$lang_rule}\n{$kw_text}\n{$len_rule} Size the outline to fit this length (roughly one H2 per 200-250 words, FAQ included).{$research_txt}\n\n"
                      . "The post must satisfy this checklist, so plan for every item:\n{$checklist}{$extra}\n\n"
                      . "Write the brief itself in English. Return ONLY a JSON object with these keys:\n"
                      . "\"search_intent\", \"audience\", \"angle\" (what makes this post better than what ranks now), "
                      . "\"primary_keyword\", \"secondary_keywords\" (array), "
                      . "\"outline\" (array of {\"h2\": string, \"h3\": array of strings, \"notes\": string}), "
                      . "\"must_cover\" (array), \"faq\" (array of questions), "
                      . "\"facts_to_handle_carefully\" (array of claims that must not be invented or must be phrased cautiously), "
                      . "\"competitor_notes\" (string, empty if no research was done), "
                      . "\"competitors_reviewed\" (array of {\"url\": string, \"site\": string, \"strengths\": string, \"gaps\": string} for each ranking page you actually looked at, in the order they ranked; empty array if no research was done).\n"
                      . "Keep the brief compact: no more H2 sections than the length allows (8 at most), one short sentence of notes per section, at most 6 FAQ questions, and short list items. It is a plan, not the article.";

        $mark  = self::stage_start();
        $brief = self::api_json(self::sys('brief', $s['system_prompt'], $dctx), $brief_prompt, $max, $tools);
        if (is_wp_error($brief)) {
            self::stage_end($mark, 'brief', $tools ? 'Research & brief' : 'Brief & outline', 'fail', $brief->get_error_message());
            return self::fail($topic, 'Brief', $brief);
        }
        $n_h2 = is_array($brief['outline'] ?? null) ? count($brief['outline']) : 0;
        $n_fq = is_array($brief['faq'] ?? null) ? count($brief['faq']) : 0;
        self::stage_end($mark, 'brief', $tools ? 'Research & brief' : 'Brief & outline', 'ok',
            sprintf('Planned %d sections and %d FAQ questions%s%s.', $n_h2, $n_fq,
                self::$usage['searches'] ? ' after ' . self::$usage['searches'] . ' web search(es)' : '',
                $tools ? ' (' . ($geo ? self::GEOS[$geo][0] . ' results' : 'global results') . ', ' . count(self::$research['results']) . ' pages found)' : ''),
            array_merge($brief, ['_research' => self::$research, '_geo' => $geo]));
        $brief_json = wp_json_encode($brief, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        /* Stage 2: draft ------------------------------------------------ */
        $draft_prompt = "Write a complete {$kind} that follows this brief.\n\n"
                      . "TOPIC: {$topic_text}\n{$lang_rule}\n{$kw_text}\n{$len_rule}\n\n"
                      . "BRIEF (follow its outline, angle and must-cover points):\n{$brief_json}\n\n"
                      . "CONTENT CHECKLIST (every item must be satisfied):\n{$checklist}{$extra}\n\n"
                      . self::format_spec($lang, $lang_name);

        $mark = self::stage_start();
        $post = self::api_json(self::sys('draft', $writer, $dctx), $draft_prompt, $max);
        if (!is_wp_error($post) && !self::valid_post($post)) {
            $post = new WP_Error('invalid', 'Draft was missing a title or content.');
        }
        if (is_wp_error($post)) {
            self::stage_end($mark, 'draft', 'First draft', 'fail', $post->get_error_message());
            return self::fail($topic, 'Draft', $post);
        }
        $snap = self::snapshot($post, $lang);
        self::stage_end($mark, 'draft', 'First draft', 'ok', 'Wrote "' . $snap['title'] . '" (' . self::length_label($snap['words'], $lang) . ').', $snap);

        $revise = function ($post, $instructions) use ($writer, $lang_rule, $kw_text, $checklist, $max, $lang, $lang_name, $len_rule, $kind, $dctx) {
            $prompt = "Revise this {$kind}.\n{$lang_rule}\n{$kw_text}\n\n"
                    . "INSTRUCTIONS:\n{$instructions}\n\n"
                    . "CONTENT CHECKLIST (must still be fully satisfied after your changes):\n{$checklist}\n\n"
                    . "{$len_rule}\n"
                    . "Keep everything that already works. Do not drop sections and do not add facts that are not supported.\n\n"
                    . "POST (JSON):\n" . self::post_json($post) . "\n\n"
                    . self::format_spec($lang, $lang_name);
            $out = self::api_json(self::sys('edit', $writer, $dctx), $prompt, $max);
            return (!is_wp_error($out) && self::valid_post($out)) ? $out : null;
        };

        /* Stage 3: editing + humanizing --------------------------------- */
        if (!empty($s['edit_pass'])) {
            $guide  = trim($s['editing_guide']) ?: self::defaults()['editing_guide'];
            $mark   = self::stage_start();
            $edited = $revise($post, self::docs_for('edit', $dctx)
                ? "Edit and humanize this post by working through the editing and humanizing SOPs in your instructions, pass by pass."
                : "Edit and humanize this post using this editing guide:\n{$guide}");
            if ($edited) {
                $post = $edited;
                $snap = self::snapshot($post, $lang);
                self::stage_end($mark, 'edit', 'Edit & humanize', 'ok', 'Edited against the editing guide (' . self::length_label($snap['words'], $lang) . ').', $snap);
            } else {
                self::stage_end($mark, 'edit', 'Edit & humanize', 'warn', 'Editing pass failed; continued with the unedited draft.');
                self::log('Editing pass failed; continuing with the unedited draft.', 'warn');
            }
        }

        /* Stage 4: QA scoring, with automatic rewrites ------------------- */
        $qa = null;
        $rewrites = 0;
        if (!empty($s['qa_enabled'])) {
            $threshold = (int) $s['qa_threshold'];
            while (true) {
                $qa_prompt = "Audit this {$kind} strictly.\n{$lang_rule}\n{$kw_text}\n\n"
                           . "CHECKLIST:\n{$checklist}{$voice_txt}\n\n"
                           . "POST (JSON):\n" . self::post_json($post) . "\n\n"
                           . "{$len_rule}\n"
                           . "Score it 0-100. 100 means publish-ready with every checklist item fully met. Deduct for each missed or weak checklist item, a length far off the target, any invented or risky factual claim, AI-sounding or generic language, and any mismatch with the voice guide. Be specific.\n"
                           . "Return ONLY a JSON object: {\"score\": integer 0-100, \"summary\": \"one or two sentences\", \"issues\": [{\"problem\": \"...\", \"fix\": \"a specific instruction\"}]}";
                $mark   = self::stage_start();
                $result = self::api_json(self::sys('qa', 'You are a strict senior SEO content editor and QA auditor.', $dctx), $qa_prompt, $max);
                if (is_wp_error($result) || !isset($result['score'])) {
                    self::stage_end($mark, 'qa', 'QA score', 'warn', 'QA scoring failed; post saved without a score.');
                    self::log('QA scoring failed; saving the post without a score.', 'warn');
                    $qa = null;
                    break;
                }
                $qa = [
                    'score'   => max(0, min(100, (int) $result['score'])),
                    'summary' => sanitize_text_field($result['summary'] ?? ''),
                    'issues'  => is_array($result['issues'] ?? null) ? $result['issues'] : [],
                ];
                $passed = $qa['score'] >= $threshold;
                self::stage_end($mark, 'qa', 'QA score', $passed ? 'ok' : 'warn',
                    sprintf('Scored %d/100 (target %d), %d issue(s) found. %s', $qa['score'], $threshold, count($qa['issues']),
                        $passed ? 'Passed.' : ($rewrites >= (int) $s['max_rewrites'] ? 'Below target; no rewrites left, saved and flagged.' : 'Below target, sending for a rewrite.')),
                    $qa);
                if ($qa['score'] >= $threshold || $rewrites >= (int) $s['max_rewrites']) break;

                $fixes = '';
                foreach ($qa['issues'] as $iss) {
                    $fixes .= '- ' . ($iss['problem'] ?? '') . ' → ' . ($iss['fix'] ?? '') . "\n";
                }
                $mark      = self::stage_start();
                $rewritten = $revise($post, "A QA audit scored this post {$qa['score']}/100 (target {$threshold}). Fix every issue below:\n{$fixes}");
                $rewrites++;
                if (!$rewritten) {
                    self::stage_end($mark, 'rewrite', 'Rewrite #' . $rewrites, 'warn', 'Rewrite failed; kept the previous version.');
                    self::log('Rewrite after QA failed; keeping the previous version.', 'warn');
                    break;
                }
                $post = $rewritten;
                $snap = self::snapshot($post, $lang);
                $snap['instructions'] = $qa['issues'];
                self::stage_end($mark, 'rewrite', 'Rewrite #' . $rewrites, 'ok',
                    sprintf('Rewrote to fix %d issue(s) (%s).', count($qa['issues']), self::length_label($snap['words'], $lang)), $snap);
            }
        }

        /* Save the draft ------------------------------------------------- */
        $content = wp_kses_post($post['content_html']);
        if ($lang !== 'en') {
            // Mark the language (and right-to-left direction for Arabic) so browsers and Google read it correctly.
            $content = '<div lang="' . esc_attr($lang) . '" dir="' . esc_attr($dir) . '">' . "\n" . $content . "\n</div>";
        }

        $postarr = [
            'post_title'   => sanitize_text_field($post['title']),
            'post_excerpt' => sanitize_text_field($post['excerpt'] ?? ''),
            'post_content' => $content,
            'post_status'  => in_array($s['post_status'], ['draft', 'pending', 'publish'], true) ? $s['post_status'] : 'draft',
            'post_author'  => (int) $s['author_id'] ?: 1,
            'post_type'    => $type,
        ];
        if ($type === 'page' && !empty($s['parent_page'])) {
            $postarr['post_parent'] = (int) $s['parent_page'];
        }
        if (!empty($post['slug'])) {
            $postarr['post_name'] = sanitize_title($post['slug']);
        }
        if ($type === 'post' && !empty($s['category_id'])) {
            $postarr['post_category'] = [(int) $s['category_id']];
        }

        $post_id = wp_insert_post($postarr, true);
        if (is_wp_error($post_id)) return self::fail($topic, 'Saving the post', $post_id);

        if ($type === 'post' && !empty($post['tags']) && is_array($post['tags'])) {
            wp_set_post_tags($post_id, array_map('sanitize_text_field', $post['tags']));
        }

        // SEO plugins: meta description + focus keyword, if installed
        $desc = sanitize_text_field($post['excerpt'] ?? '');
        if (defined('WPSEO_VERSION')) {
            if ($desc)    update_post_meta($post_id, '_yoast_wpseo_metadesc', $desc);
            if ($primary) update_post_meta($post_id, '_yoast_wpseo_focuskw', $primary);
        }
        if (class_exists('RankMath')) {
            if ($desc) update_post_meta($post_id, 'rank_math_description', $desc);
            if ($kws)  update_post_meta($post_id, 'rank_math_focus_keyword', implode(',', $kws));
        }

        update_post_meta($post_id, '_cap_source_topic', $topic);
        update_post_meta($post_id, '_cap_model', $s['model']);
        update_post_meta($post_id, '_cap_language', $lang);
        update_post_meta($post_id, '_cap_type', $type);
        update_post_meta($post_id, '_cap_geo', $geo);
        update_post_meta($post_id, '_cap_keywords', implode(', ', $kws));
        update_post_meta($post_id, '_cap_brief', wp_slash($brief_json));
        update_post_meta($post_id, '_cap_rewrites', $rewrites);
        if ($qa) {
            update_post_meta($post_id, '_cap_qa_score', $qa['score']);
            update_post_meta($post_id, '_cap_qa_passed', $qa['score'] >= (int) $s['qa_threshold'] ? 1 : 0);
            update_post_meta($post_id, '_cap_qa_report', wp_slash(wp_json_encode($qa, JSON_UNESCAPED_UNICODE)));
        }

        self::add_images($post_id, $post, $s, $lang, $lang_name, $kind, $kws, $primary, $geo);

        $left = self::shift_queue();

        self::stage_end(self::stage_start(), 'save', 'Saved to WordPress', 'ok',
            sprintf('Saved as %s %s (ID %d)%s.', $postarr['post_status'], strtolower(self::type_label($type)), $post_id, $kws ? ', focus keyword "' . $primary . '"' : ''));
        $report = self::build_report('created', $post_id);
        update_post_meta($post_id, '_cap_process', wp_slash(wp_json_encode($report, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)));

        $qa_txt = $qa ? sprintf('QA %d/100%s', $qa['score'], $rewrites ? " after {$rewrites} rewrite(s)" : '') : 'no QA score';
        $below  = $qa && $qa['score'] < (int) $s['qa_threshold'];
        self::log(sprintf(
            'Created %s "%s" (ID %d, %s, %s, %s%s). %d API calls, %s in / %s out tokens%s. %d topics left.',
            strtolower(self::type_label($type)), $postarr['post_title'], $post_id, $postarr['post_status'], self::lang_label($lang) . ($geo ? ', ' . self::GEOS[$geo][0] : ''), $qa_txt,
            $below ? ', BELOW TARGET' : '',
            self::$usage['calls'], number_format(self::$usage['in']), number_format(self::$usage['out']),
            (self::$usage['searches'] ? ', ' . self::$usage['searches'] . ' web searches' : '') . (!empty(self::$usage['cached']) ? ', ' . number_format(self::$usage['cached']) . ' SOP tokens via cache' : ''),
            $left
        ), $below ? 'warn' : 'info');

        self::notify_editor($post_id, $topic_text);

        return $post_id;
    }

    /* ---------------------------------------------------------------
     * Editor notification
     * ------------------------------------------------------------- */

    /** Split a comma/semicolon/space separated list into valid, unique emails. */
    private static function parse_emails($raw) {
        $out = [];
        foreach (preg_split('/[\s,;]+/', (string) $raw) as $e) {
            $e = sanitize_email($e);
            if ($e && is_email($e)) $out[] = $e;
        }
        return array_values(array_unique($out));
    }

    /**
     * Email the editor (To) and CC list with a link to the new post.
     * @return bool Whether wp_mail accepted the message.
     */
    private static function notify_editor($post_id, $topic, $is_test = false) {
        $s = self::settings();
        if (!$is_test && empty($s['notify_enabled'])) return false;

        $to = self::parse_emails($s['notify_to']);
        if (!$to) {
            self::log('Editor email skipped: no valid "To" address in settings.', 'error');
            return false;
        }
        $cc = self::parse_emails($s['notify_cc']);

        $site = wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES);

        if ($is_test) {
            $subject = sprintf('[%s] Test: Claude Auto Poster editor notification', $site);
            $body    = "This is a test from Claude Auto Poster on {$site}.\n\n"
                     . "If you received this, draft notifications will reach you.\n\n"
                     . 'Settings: ' . self::page_url() . "\n";
        } else {
            $title   = get_the_title($post_id);
            $status  = get_post_status($post_id);
            $label   = $status === 'publish' ? 'Published' : ($status === 'pending' ? 'Pending review' : 'Draft');
            $lang    = get_post_meta($post_id, '_cap_language', true) ?: 'en';
            $plain   = wp_strip_all_tags(get_post_field('post_content', $post_id));
            $length  = $lang === 'zh'
                ? '~' . mb_strlen(preg_replace('/\s+/u', '', $plain)) . ' characters'
                : '~' . count(preg_split('/\s+/u', trim($plain), -1, PREG_SPLIT_NO_EMPTY)) . ' words';
            $excerpt = get_post_field('post_excerpt', $post_id);
            $edit    = admin_url('post.php?post=' . (int) $post_id . '&action=edit');
            $kw      = get_post_meta($post_id, '_cap_keywords', true);
            $score   = get_post_meta($post_id, '_cap_qa_score', true);
            $passed  = (int) get_post_meta($post_id, '_cap_qa_passed', true);
            $report  = json_decode((string) get_post_meta($post_id, '_cap_qa_report', true), true);
            $qa_line = $score !== '' ? $score . '/100 ' . ($passed ? '(passed)' : '(below target, please check carefully)') : '';
            $open_issues = '';
            if ($score !== '' && !$passed && !empty($report['issues'])) {
                foreach (array_slice($report['issues'], 0, 8) as $iss) {
                    $open_issues .= '- ' . sanitize_text_field($iss['problem'] ?? '') . "\n";
                }
            }
            $preview = get_preview_post_link($post_id);

            $ptype   = get_post_type($post_id) === 'page' ? 'page' : 'post';
            $subject = ($score !== '' && !$passed ? '[Needs attention] ' : '') . sprintf('[%s] New %s%s%s ready for review: %s', $site, $lang !== 'en' ? self::lang_label($lang) . ' ' : '', $status === 'publish' ? '' : 'draft ', $ptype, $title);
            $body    = "Hi,\n\nA new article was generated on {$site} and is waiting for your review.\n\n"
                     . "Title:      {$title}\n"
                     . "Status:     {$label}\n"
                     . "Type:       " . self::type_label($ptype) . "\n"
                     . "Language:   " . self::lang_label($lang) . "\n"
                     . "Market:     " . self::geo_label(get_post_meta($post_id, '_cap_geo', true)) . "\n"
                     . "Images:     " . (has_post_thumbnail($post_id) ? 'featured image added' : 'no featured image') . (strpos(get_post_field('post_content', $post_id), 'wp-image-') !== false ? ', 1 image in the body' : '') . "\n"
                     . "Length:     {$length}\n"
                     . ($kw ? "Keywords:   {$kw}\n" : '')
                     . ($qa_line ? "QA score:   {$qa_line}\n" : '')
                     . "Topic:      {$topic}\n\n"
                     . ($excerpt ? "Summary:\n{$excerpt}\n\n" : '')
                     . ($open_issues ? "Issues QA still found:\n{$open_issues}\n" : '')
                     . "Review and edit:\n{$edit}\n\n"
                     . ($preview ? "Preview:\n{$preview}\n\n" : '')
                     . ($status === 'publish'
                         ? "Note: this post is already live.\n"
                         : "It will not go live until someone clicks Publish.\n")
                     . "\n(You need to be logged in to WordPress to open these links.)\n";
        }

        $headers = [];
        if ($cc) $headers[] = 'Cc: ' . implode(', ', $cc);

        $sent = wp_mail($to, $subject, $body, $headers);

        $who = implode(', ', $to) . ($cc ? '; cc ' . implode(', ', $cc) : '');
        if ($sent) {
            self::log(($is_test ? 'Test email sent to ' : 'Editor notified: ') . $who);
        } else {
            self::log('Editor email FAILED (' . $who . '). Check the site\'s mail/SMTP setup.', 'error');
        }
        return $sent;
    }

    /* ---------------------------------------------------------------
     * Admin UI
     * ------------------------------------------------------------- */

    public static function admin_menu() {
        add_menu_page('Claude Auto Poster', 'Auto Poster', 'manage_options', 'claude-auto-poster', [__CLASS__, 'render_page'], 'dashicons-edit-page', 26);
    }

    public static function register_settings() {
        register_setting('cap_settings_group', self::OPT_SETTINGS, [
            'sanitize_callback' => [__CLASS__, 'sanitize_settings'],
        ]);
    }

    public static function sanitize_settings($in) {
        $d   = self::defaults();
        $old = self::settings();
        $out = [];

        // Keep the existing key if the field was left blank
        $key = isset($in['api_key']) ? trim($in['api_key']) : '';
        $out['api_key']            = $key !== '' ? sanitize_text_field($key) : $old['api_key'];
        $out['model']              = sanitize_text_field($in['model'] ?? $d['model']) ?: $d['model'];
        $out['posts_per_day']      = max(1, min(24, (int) ($in['posts_per_day'] ?? 3)));
        $out['enabled']            = !empty($in['enabled']) ? 1 : 0;
        $out['post_status']        = in_array($in['post_status'] ?? '', ['draft', 'pending', 'publish'], true) ? $in['post_status'] : 'draft';
        $out['author_id']          = (int) ($in['author_id'] ?? 1);
        $out['category_id']        = (int) ($in['category_id'] ?? 0);
        $out['max_tokens']         = max(8000, min(32000, (int) ($in['max_tokens'] ?? 12000)));
        $out['word_count']         = array_key_exists('word_count', $in) ? max(300, min(5000, (int) $in['word_count'])) : (int) $old['word_count'];
        $out['system_prompt']      = sanitize_textarea_field($in['system_prompt'] ?? $d['system_prompt']);
        $out['extra_instructions'] = sanitize_textarea_field($in['extra_instructions'] ?? '');
        $out['notify_enabled']     = !empty($in['notify_enabled']) ? 1 : 0;
        $out['notify_to']          = implode(', ', self::parse_emails($in['notify_to'] ?? ''));
        $out['notify_cc']          = implode(', ', self::parse_emails($in['notify_cc'] ?? ''));
        $out['img_featured']       = !empty($in['img_featured']) ? 1 : 0;
        $out['img_body']           = !empty($in['img_body']) ? 1 : 0;
        $out['img_text']           = !empty($in['img_text']) ? 1 : 0;
        $out['img_brand']          = sanitize_text_field($in['img_brand'] ?? '');
        $out['img_bg']             = preg_match('/^#[0-9a-f]{6}$/i', $in['img_bg'] ?? '') ? strtoupper($in['img_bg']) : $d['img_bg'];
        $out['img_accent']         = preg_match('/^#[0-9a-f]{6}$/i', $in['img_accent'] ?? '') ? strtoupper($in['img_accent']) : $d['img_accent'];
        $out['language']           = isset(self::LANGUAGES[$in['language'] ?? '']) ? $in['language'] : 'en';
        $out['content_type']       = array_key_exists('content_type', $in) ? (($in['content_type'] === 'page') ? 'page' : 'post') : $old['content_type'];
        $out['geo']                = isset(self::GEOS[$in['geo'] ?? '']) ? $in['geo'] : '';
        $out['parent_page']        = max(0, (int) ($in['parent_page'] ?? 0));
        $out['web_research']       = !empty($in['web_research']) ? 1 : 0;
        $out['edit_pass']          = !empty($in['edit_pass']) ? 1 : 0;
        $out['qa_enabled']         = !empty($in['qa_enabled']) ? 1 : 0;
        $out['qa_threshold']       = max(1, min(100, (int) ($in['qa_threshold'] ?? 80)));
        $out['max_rewrites']       = max(0, min(3, (int) ($in['max_rewrites'] ?? 1)));
        // No longer shown (the SOP library replaces them); keep stored values as the fallback for sites without SOPs.
        $out['voice_guide']        = array_key_exists('voice_guide', $in) ? sanitize_textarea_field($in['voice_guide']) : $old['voice_guide'];
        $out['content_checklist']  = array_key_exists('content_checklist', $in) ? (sanitize_textarea_field($in['content_checklist']) ?: $d['content_checklist']) : $old['content_checklist'];
        $out['editing_guide']      = array_key_exists('editing_guide', $in) ? (sanitize_textarea_field($in['editing_guide']) ?: $d['editing_guide']) : $old['editing_guide'];
        return $out;
    }

    public static function handle_save_topics() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_save_topics');

        $in   = isset($_POST['rows']) && is_array($_POST['rows']) ? wp_unslash($_POST['rows']) : [];
        $rows = [];
        $missing_type = 0;
        ksort($in, SORT_NUMERIC);
        foreach ($in as $r) {
            $topic = sanitize_text_field($r['topic'] ?? '');
            if ($topic === '') continue;
            $type = in_array($r['type'] ?? '', ['post', 'page'], true) ? $r['type'] : '';
            if ($type === '') { $missing_type++; $type = 'post'; }
            $rows[] = [
                'topic'    => $topic,
                'keywords' => sanitize_text_field($r['keywords'] ?? ''),
                'type'     => $type,
                'words'    => max(300, min(5000, (int) ($r['words'] ?? 0) ?: 1500)),
            ];
        }
        self::save_queue($rows);
        wp_safe_redirect(self::page_url(['tab' => 'queue', 'cap_msg' => $missing_type ? 'topics_typefix' : 'topics_saved']));
        exit;
    }

    public static function handle_test_email() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_test_email');

        $ok = self::notify_editor(0, '', true);
        wp_safe_redirect(self::page_url(['tab' => 'notifications', 'cap_msg' => $ok ? 'mail_ok' : 'mail_failed']));
        exit;
    }

    /* ---------------------------------------------------------------
     * SOP & prompt library: uploaded .md documents used by pipeline stages
     * ------------------------------------------------------------- */

    const DOC_TYPE   = 'cap_doc';
    const DOC_STAGES = [
        'reference' => 'Brand reference',
        'brief'     => 'Brief',
        'draft'     => 'Draft',
        'edit'      => 'Edit & rewrite',
        'qa'        => 'QA',
    ];
    const DOC_MAX_AUTO = 150000; // characters; larger documents are uploaded switched off

    public static function register_doc_type() {
        register_post_type(self::DOC_TYPE, [
            'public'       => false,
            'show_ui'      => false,
            'rewrite'      => false,
            'query_var'    => false,
            'supports'     => ['title', 'editor'],
            'can_export'   => true,
        ]);
    }

    private static function tokens_est($chars) {
        return (int) ceil($chars / 4);
    }

    private static function fmt_tokens($n) {
        return $n >= 1000 ? round($n / 1000, $n >= 10000 ? 0 : 1) . 'k' : (string) $n;
    }

    /** All library documents with their settings. */
    private static function docs() {
        static $cache = null;
        if ($cache !== null) return $cache;
        $cache = [];
        $posts = get_posts(['post_type' => self::DOC_TYPE, 'post_status' => 'any', 'numberposts' => -1, 'orderby' => ['menu_order' => 'ASC', 'title' => 'ASC']]);
        foreach ($posts as $p) {
            $stages = get_post_meta($p->ID, '_cap_stages', true);
            $cache[$p->ID] = [
                'id'       => $p->ID,
                'title'    => $p->post_title,
                'content'  => $p->post_content,
                'filename' => (string) get_post_meta($p->ID, '_cap_filename', true),
                'stages'   => is_array($stages) ? $stages : [],
                'enabled'  => (int) get_post_meta($p->ID, '_cap_enabled', true),
                'applies'  => get_post_meta($p->ID, '_cap_applies', true) ?: 'all',
                'tag'      => (string) get_post_meta($p->ID, '_cap_tag', true),
                'note'     => (string) get_post_meta($p->ID, '_cap_note', true),
                'edited'   => get_post_meta($p->ID, '_cap_original', true) !== $p->post_content,
                'order'    => (int) $p->menu_order,
            ];
        }
        return $cache;
    }

    /** Custom topic tags that documents are limited to, e.g. review, hub. */
    private static function doc_tags() {
        $t = [];
        foreach (self::docs() as $d) if ($d['tag'] !== '') $t[$d['tag']] = true;
        return array_keys($t);
    }

    /** Documents that apply to a stage for this run. $ctx = ['type' => post|page, 'tags' => [..]] */
    private static function docs_for($stage, $ctx) {
        $out = [];
        foreach (self::docs() as $d) {
            if (!$d['enabled'] || !in_array($stage, $d['stages'], true)) continue;
            if ($d['applies'] !== 'all' && $d['applies'] !== ($ctx['type'] ?? 'post')) continue;
            if ($d['tag'] !== '' && !in_array($d['tag'], (array) ($ctx['tags'] ?? []), true)) continue;
            $out[] = $d;
        }
        return $out;
    }

    private static function docs_block($docs) {
        $txt = '';
        foreach ($docs as $d) {
            $txt .= "\n\n=============================\nDOCUMENT: {$d['title']}\n=============================\n\n" . trim($d['content']);
        }
        return $txt;
    }

    /**
     * System prompt for a stage: brand reference and this stage's SOPs (cached), then the stage instruction.
     * Returns a plain string when the library has nothing for this stage.
     */
    private static function sys($stage, $instruction, $ctx) {
        $blocks = [];
        $kind = $ctx['kind'] ?? 'article';
        $ref = self::docs_for('reference', $ctx);
        if ($ref) {
            $blocks[] = ['type' => 'text', 'cache_control' => ['type' => 'ephemeral'], 'text' =>
                "BRAND & REFERENCE DOCUMENTS\nThese are the source of truth for facts about the brand, its terms, products and site. Never contradict them. If they do not cover a fact, do not invent it."
                . self::docs_block($ref)];
        }
        $sop = self::docs_for($stage, $ctx);
        if ($sop) {
            $blocks[] = ['type' => 'text', 'cache_control' => ['type' => 'ephemeral'], 'text' =>
                "TEAM STANDARD OPERATING PROCEDURES FOR THIS STEP\nFollow every rule in these documents that applies to producing this {$kind}. "
                . "Some steps describe work done by people or with tools you do not have here (spreadsheets, Excel workbooks, SEO tools such as Semrush, Trello, sign-offs, sending files): skip those steps and apply their standards to the text instead. "
                . "Where a document conflicts with the target length, language, market or output format given in the request, the request wins."
                . self::docs_block($sop)];
        }
        if (!$blocks) return $instruction;
        $blocks[] = ['type' => 'text', 'text' => $instruction];
        return $blocks;
    }

    /** Title list of documents a run will use, per stage, for the process report. */
    private static function docs_plan($ctx) {
        $plan = [];
        foreach (array_keys(self::DOC_STAGES) as $st) {
            $plan[$st] = array_map(function ($d) { return $d['title']; }, self::docs_for($st, $ctx));
        }
        return $plan;
    }

    /* ---- upload, classify, save ---- */

    private static function doc_title_from($filename) {
        $t = preg_replace('/\.(md|markdown|txt)$/i', '', basename($filename));
        $t = preg_replace('/_{2,}\d+_?$/', '', $t);
        $t = str_replace(['___', '_-_', '_'], [' & ', ' – ', ' '], $t);
        return trim(preg_replace('/\s+/', ' ', $t));
    }

    private static function doc_key($filename) {
        $k = strtolower(preg_replace('/\.(md|markdown|txt)$/i', '', basename($filename)));
        $k = preg_replace('/^\d+[a-z]?_/', '', $k);
        $k = preg_replace('/_{2,}\d+_?$/', '', $k);
        $k = preg_replace('/_v\d+$/', '', $k);
        return preg_replace('/[^a-z0-9]/', '', $k);
    }

    /** Sensible defaults from the filename; everything stays editable afterwards. */
    private static function classify_doc($filename, $chars) {
        $n   = strtolower($filename);
        $has = function () use ($n) { foreach (func_get_args() as $w) { if (strpos($n, $w) !== false) return true; } return false; };
        $r   = ['stages' => ['draft'], 'enabled' => 1, 'applies' => 'all', 'tag' => '', 'note' => ''];

        if ($has('meeting', 'transcrip')) {
            $r = array_merge($r, ['stages' => ['brief'], 'enabled' => 0, 'note' => 'Meeting notes. Off by default.']);
        } elseif ($has('master_order')) {
            $r = array_merge($r, ['stages' => ['brief'], 'enabled' => 0, 'note' => 'Index of the other documents. Not needed by Claude.']);
        } elseif ($has('internal_linking')) {
            $r = array_merge($r, ['stages' => ['edit'], 'enabled' => 0, 'note' => 'Internal linking is not part of the pipeline yet.']);
        } elseif ($has('competitor_analysis_prompt')) {
            $r = array_merge($r, ['stages' => ['brief'], 'enabled' => 0, 'note' => 'Written for filling an Excel workbook. Off by default.']);
        } elseif ($has('peer_review', 'technical_seo', 'seo_audit')) {
            $r['stages'] = ['qa'];
        } elseif ($has('humaniz', 'humanis', 'editing_guide')) {
            $r['stages'] = ['edit'];
        } elseif ($has('competitor', 'content_gap', 'casino_research', 'content_brief', 'brief_template', 'page_outline')) {
            $r['stages'] = ['brief'];
        } elseif ($has('hub_page', 'operator_hub', 'sop_for_hub')) {
            $r = array_merge($r, ['stages' => ['draft'], 'tag' => 'hub']);
        } elseif ($has('supporting')) {
            $r = array_merge($r, ['stages' => ['draft'], 'tag' => 'supporting']);
        } elseif ($has('review')) {
            $r = array_merge($r, ['stages' => ['draft'], 'tag' => 'review']);
        } elseif ($has('blog')) {
            $r = array_merge($r, ['stages' => ['draft'], 'applies' => 'post']);
        } elseif ($has('writing')) {
            $r['stages'] = ['draft'];
        } elseif ($has('terms', 'promotional', 'department', 'sitemap', 'provider', 'banking', 'rules')) {
            $r['stages'] = ['reference'];
        }
        if ($chars > self::DOC_MAX_AUTO && $r['enabled']) {
            $r['enabled'] = 0;
            $r['note'] = 'Very large (~' . self::fmt_tokens(self::tokens_est($chars)) . ' tokens). Off by default to control cost.';
        }
        return $r;
    }

    private static function save_doc($id, $title, $content, $meta) {
        kses_remove_filters(); // keep the markdown exactly as uploaded
        $arr = ['post_type' => self::DOC_TYPE, 'post_status' => 'publish', 'post_title' => wp_slash($title), 'post_content' => wp_slash($content)];
        if (isset($meta['order'])) $arr['menu_order'] = (int) $meta['order'];
        if ($id) { $arr['ID'] = $id; $res = wp_update_post($arr, true); } else { $res = wp_insert_post($arr, true); }
        kses_init_filters();
        if (is_wp_error($res)) return $res;
        foreach (['stages', 'enabled', 'applies', 'tag', 'note', 'filename', 'original'] as $k) {
            if (array_key_exists($k, $meta)) update_post_meta($res, '_cap_' . $k, $k === 'original' ? wp_slash($meta[$k]) : $meta[$k]);
        }
        return $res;
    }

    public static function handle_doc_upload() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_doc_upload');

        $files = [];   // filename => content
        $skipped = [];
        $manifest = null;
        $up = $_FILES['cap_docs'] ?? null;
        if ($up && is_array($up['name'])) {
            foreach ($up['name'] as $i => $name) {
                if (!empty($up['error'][$i]) || !is_uploaded_file($up['tmp_name'][$i])) continue;
                $name = sanitize_file_name($name);
                if (preg_match('/\.zip$/i', $name)) {
                    if (!class_exists('ZipArchive')) { $skipped[] = $name . ' (this server cannot open zip files; upload the .md files instead)'; continue; }
                    $zip = new ZipArchive();
                    if ($zip->open($up['tmp_name'][$i]) !== true) { $skipped[] = $name . ' (could not open)'; continue; }
                    for ($z = 0; $z < $zip->numFiles; $z++) {
                        $entry = $zip->getNameIndex($z);
                        if (substr($entry, -1) === '/' || strpos($entry, '__MACOSX') !== false || strpos(basename($entry), '.') === 0) continue;
                        $base = sanitize_file_name(basename($entry));
                        if ($base === 'library.json') { $manifest = json_decode((string) $zip->getFromIndex($z), true); continue; }
                        if (!preg_match('/\.(md|markdown|txt)$/i', $base)) { $skipped[] = $base . ' (only .md and .txt files are used)'; continue; }
                        $files[$base] = (string) $zip->getFromIndex($z);
                    }
                    $zip->close();
                } elseif (preg_match('/\.(md|markdown|txt)$/i', $name)) {
                    $files[$name] = (string) file_get_contents($up['tmp_name'][$i]);
                } else {
                    $skipped[] = $name . ' (only .zip, .md and .txt files are accepted)';
                }
            }
        }

        $existing = [];
        $keys = [];
        foreach (self::docs() as $d) {
            if ($d['filename'] !== '') $existing[strtolower($d['filename'])] = $d['id'];
            $keys[self::doc_key($d['filename'] ?: $d['title'])] = $d['title'];
        }
        ksort($files, SORT_NATURAL | SORT_FLAG_CASE);
        $added = $updated = 0;
        $order = count(self::docs());
        foreach ($files as $fname => $content) {
            $content = preg_replace('/^\xEF\xBB\xBF/', '', str_replace("\r\n", "\n", $content));
            if (function_exists('mb_check_encoding') && !mb_check_encoding($content, 'UTF-8') && function_exists('mb_convert_encoding')) $content = mb_convert_encoding($content, 'UTF-8', 'Windows-1252');
            $lc = strtolower($fname);
            if (isset($existing[$lc])) {
                // Same file uploaded again: replace the text, keep its settings.
                self::save_doc($existing[$lc], get_the_title($existing[$lc]), $content, ['original' => $content]);
                $updated++;
                continue;
            }
            $m = is_array($manifest['docs'][$fname] ?? null) ? $manifest['docs'][$fname] : null;
            $c = $m ? array_merge(['stages' => [], 'enabled' => 1, 'applies' => 'all', 'tag' => '', 'note' => ''], array_intersect_key($m, array_flip(['stages', 'enabled', 'applies', 'tag', 'note'])))
                    : self::classify_doc($fname, strlen($content));
            $title = $m['title'] ?? self::doc_title_from($fname);
            $key = self::doc_key($fname);
            if (!$m && isset($keys[$key])) {
                $c['enabled'] = 0;
                $c['note'] = 'Looks like a duplicate of “' . $keys[$key] . '”. Off by default.';
            }
            $keys[$key] = $title;
            $res = self::save_doc(0, $title, $content, $c + ['filename' => $fname, 'original' => $content, 'order' => $m['order'] ?? ++$order]);
            if (is_wp_error($res)) { $skipped[] = $fname . ' (' . $res->get_error_message() . ')'; continue; }
            $added++;
        }

        set_transient('cap_doc_msg', ['added' => $added, 'updated' => $updated, 'skipped' => $skipped], 120);
        self::log(sprintf('SOP library upload: %d added, %d updated, %d skipped.', $added, $updated, count($skipped)));
        wp_safe_redirect(self::page_url(['tab' => 'quality', 'cap_msg' => 'docs_uploaded']) . '#cap-library');
        exit;
    }

    /** Saves the library table: on/off, stages, applies-to and tag for every document. */
    public static function handle_doc_bulk() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_doc_bulk');
        $in = isset($_POST['docs']) && is_array($_POST['docs']) ? wp_unslash($_POST['docs']) : [];
        foreach (self::docs() as $id => $d) {
            $row = $in[$id] ?? [];
            $stages = array_values(array_intersect(array_keys(self::DOC_STAGES), (array) ($row['stages'] ?? [])));
            update_post_meta($id, '_cap_enabled', !empty($row['enabled']) ? 1 : 0);
            update_post_meta($id, '_cap_stages', $stages);
            update_post_meta($id, '_cap_applies', in_array($row['applies'] ?? '', ['all', 'post', 'page'], true) ? $row['applies'] : 'all');
            update_post_meta($id, '_cap_tag', strtolower(preg_replace('/[^a-z0-9-]/i', '', (string) ($row['tag'] ?? ''))));
        }
        wp_safe_redirect(self::page_url(['tab' => 'quality', 'cap_msg' => 'docs_saved']) . '#cap-library');
        exit;
    }

    public static function handle_doc_edit() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_doc_edit');
        $id = (int) ($_POST['doc_id'] ?? 0);
        $title = sanitize_text_field(wp_unslash($_POST['doc_title'] ?? '')) ?: 'Untitled document';
        $content = str_replace("\r\n", "\n", (string) wp_unslash($_POST['doc_content'] ?? ''));

        if (!empty($_POST['revert']) && $id) {
            $content = (string) get_post_meta($id, '_cap_original', true);
        }
        if ($id && get_post_type($id) !== self::DOC_TYPE) wp_die('Unknown document');
        $meta = $id ? [] : ['stages' => ['draft'], 'enabled' => 1, 'applies' => 'all', 'tag' => '', 'filename' => sanitize_file_name($title) . '.md', 'original' => $content, 'order' => 999];
        $res = self::save_doc($id, $title, $content, $meta);
        if (is_wp_error($res)) wp_die(esc_html($res->get_error_message()));
        wp_safe_redirect(self::page_url(['tab' => 'quality', 'doc' => (int) $res, 'cap_msg' => !empty($_POST['revert']) ? 'doc_reverted' : 'doc_saved']));
        exit;
    }

    public static function handle_doc_delete() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        $id = (int) ($_GET['doc'] ?? 0);
        check_admin_referer('cap_doc_delete_' . $id);
        if (get_post_type($id) === self::DOC_TYPE) wp_delete_post($id, true);
        wp_safe_redirect(self::page_url(['tab' => 'quality', 'cap_msg' => 'doc_deleted']) . '#cap-library');
        exit;
    }

    /** Download the whole library (documents + their settings) to install on another site. */
    public static function handle_doc_export() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_doc_export');
        if (!class_exists('ZipArchive')) wp_die('This server cannot create zip files.');
        $tmp = wp_tempnam('cap-library');
        $zip = new ZipArchive();
        $zip->open($tmp, ZipArchive::OVERWRITE);
        $manifest = ['plugin' => 'claude-auto-poster', 'exported' => current_time('mysql'), 'docs' => []];
        $used = [];
        foreach (self::docs() as $d) {
            $fname = $d['filename'] ?: sanitize_file_name($d['title']) . '.md';
            while (isset($used[strtolower($fname)])) $fname = preg_replace('/(\.\w+)$/', '-2$1', $fname);
            $used[strtolower($fname)] = true;
            $zip->addFromString($fname, $d['content']);
            $manifest['docs'][$fname] = ['title' => $d['title'], 'stages' => $d['stages'], 'enabled' => $d['enabled'], 'applies' => $d['applies'], 'tag' => $d['tag'], 'note' => $d['note'], 'order' => $d['order']];
        }
        $zip->addFromString('library.json', wp_json_encode($manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
        $zip->close();
        nocache_headers();
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="sop-library-' . sanitize_file_name(wp_parse_url(home_url(), PHP_URL_HOST)) . '.zip"');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    public static function handle_doc_download() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        $id = (int) ($_GET['doc'] ?? 0);
        check_admin_referer('cap_doc_download_' . $id);
        $d = self::docs()[$id] ?? null;
        if (!$d) wp_die('Unknown document');
        nocache_headers();
        header('Content-Type: text/markdown; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . ($d['filename'] ?: sanitize_file_name($d['title']) . '.md') . '"');
        echo $d['content'];
        exit;
    }

    /* ---- library UI (Quality Pipeline tab) ---- */

    private static function render_library() {
        $docs = self::docs();
        $edit = isset($_GET['doc']) ? sanitize_key($_GET['doc']) : '';

        if ($edit !== '') {
            $d = $edit === 'new' ? ['id' => 0, 'title' => '', 'content' => '', 'filename' => '', 'edited' => false, 'note' => ''] : ($docs[(int) $edit] ?? null);
            if ($d) { self::render_doc_editor($d); return; }
        }

        $msg = get_transient('cap_doc_msg');
        if ($msg && ($_GET['cap_msg'] ?? '') === 'docs_uploaded') {
            delete_transient('cap_doc_msg');
            echo '<div class="notice notice-success inline"><p><strong>Upload finished:</strong> ' . (int) $msg['added'] . ' added, ' . (int) $msg['updated'] . ' updated.';
            if ($msg['skipped']) echo '<br>Skipped: ' . esc_html(implode('; ', $msg['skipped']));
            echo '</p></div>';
        }

        // token budget per stage for a typical untagged post
        $ctx = ['type' => 'post', 'tags' => []];
        $ref = array_sum(array_map(function ($d) { return strlen($d['content']); }, self::docs_for('reference', $ctx)));
        $tot = [];
        foreach (['brief', 'draft', 'edit', 'qa'] as $st) {
            $tot[$st] = self::tokens_est(array_sum(array_map(function ($d) { return strlen($d['content']); }, self::docs_for($st, $ctx))));
        }
        $ref_t = self::tokens_est($ref);
        $enabled = count(array_filter($docs, function ($d) { return $d['enabled']; }));
        ?>
        <div class="cap-card" id="cap-library">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:12px;flex-wrap:wrap;">
                <div>
                    <h2>SOP &amp; prompt library</h2>
                    <p class="cap-sub" style="max-width:760px;">Upload your team’s SOPs, guides and prompts (.md files or a .zip of them). Each document is given to Claude at the pipeline step you choose, so every post follows your own standards. Brand reference documents (terms, sitemap, products) are given to every step as the source of truth.</p>
                </div>
                <div class="cap-inline-form">
                    <a class="button" href="<?php echo esc_url(self::page_url(['tab' => 'quality', 'doc' => 'new'])); ?>">+ New document</a>
                    <?php if ($docs) : ?><a class="button" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=cap_doc_export'), 'cap_doc_export')); ?>">Export library (.zip)</a><?php endif; ?>
                </div>
            </div>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data" class="cap-dropzone">
                <input type="hidden" name="action" value="cap_doc_upload">
                <?php wp_nonce_field('cap_doc_upload'); ?>
                <span class="dashicons dashicons-upload"></span>
                <div><strong>Upload documents</strong><br><span class="description">A .zip from your Claude project, or one or more .md / .txt files. Re-uploading a file with the same name replaces its text and keeps its settings. A library exported from another site keeps all its settings.</span></div>
                <input type="file" name="cap_docs[]" multiple accept=".zip,.md,.markdown,.txt" required>
                <?php submit_button('Upload', 'primary', 'submit', false); ?>
            </form>

            <?php if (!$docs) : ?>
                <p class="cap-empty">No documents yet. Upload your SOP files to get started.</p>
            </div>
            <?php return; endif; ?>

            <div class="cap-grid" style="grid-template-columns:repeat(5,1fr);margin-top:14px;">
                <?php
                $cards = ['reference' => [$ref_t, 'Brand reference', 'given to every step'], 'brief' => [$tot['brief'], 'Brief', 'research & outline'], 'draft' => [$tot['draft'], 'Draft', 'writing'], 'edit' => [$tot['edit'], 'Edit & rewrite', 'editing passes'], 'qa' => [$tot['qa'], 'QA', 'scoring']];
                foreach ($cards as $c) : $big = $c[0] > 40000; ?>
                    <div class="cap-stat">
                        <div class="lbl"><?php echo esc_html($c[1]); ?></div>
                        <div class="val" style="<?php echo $big ? 'color:#b26200;' : ''; ?>">~<?php echo esc_html(self::fmt_tokens($c[0])); ?></div>
                        <div class="sub">tokens · <?php echo esc_html($c[2]); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php
            $per_post = $ref_t * 5 + $tot['brief'] + $tot['draft'] + $tot['edit'] * 2 + $tot['qa'] * 2;
            ?>
            <p class="description" style="margin-top:8px;">For a typical untagged post, the library adds roughly <strong><?php echo esc_html(self::fmt_tokens($per_post)); ?> input tokens</strong> across all steps (more when topics use tags such as <code>[review]</code>). Repeated documents within a post are cached by Anthropic and billed at a fraction of the normal rate. Turn off documents you don’t need to keep cost and time down.</p>

            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="cap_doc_bulk">
                <?php wp_nonce_field('cap_doc_bulk'); ?>
                <div style="overflow-x:auto;">
                <table class="widefat striped cap-table cap-doc-table">
                    <thead><tr>
                        <th style="width:42px;">On</th>
                        <th>Document</th>
                        <th style="width:330px;">Used in step</th>
                        <th style="width:110px;">Applies to</th>
                        <th style="width:120px;">Only for tag</th>
                        <th style="width:150px;"></th>
                    </tr></thead>
                    <tbody>
                    <?php foreach ($docs as $id => $d) : $tok = self::tokens_est(strlen($d['content'])); ?>
                        <tr class="<?php echo $d['enabled'] ? '' : 'cap-doc-off'; ?>">
                            <td><input type="checkbox" name="docs[<?php echo (int) $id; ?>][enabled]" value="1" <?php checked($d['enabled'], 1); ?>></td>
                            <td>
                                <strong><a href="<?php echo esc_url(self::page_url(['tab' => 'quality', 'doc' => $id])); ?>"><?php echo esc_html($d['title']); ?></a></strong>
                                <?php if ($d['edited']) echo ' ' . self::badge('Edited', 'info'); ?>
                                <div class="cap-note"><?php echo esc_html(($d['filename'] ?: 'created here') . ' · ~' . self::fmt_tokens($tok) . ' tokens'); ?><?php if ($tok > 40000) echo ' · ' . self::badge('Large', 'warn'); ?></div>
                                <?php if ($d['note']) : ?><div class="cap-note" style="color:#8a5a00;"><?php echo esc_html($d['note']); ?></div><?php endif; ?>
                            </td>
                            <td class="cap-stage-checks">
                                <?php foreach (self::DOC_STAGES as $sk => $sl) : ?>
                                    <label><input type="checkbox" name="docs[<?php echo (int) $id; ?>][stages][]" value="<?php echo esc_attr($sk); ?>" <?php checked(in_array($sk, $d['stages'], true)); ?>> <?php echo esc_html($sl); ?></label>
                                <?php endforeach; ?>
                            </td>
                            <td>
                                <select name="docs[<?php echo (int) $id; ?>][applies]">
                                    <option value="all" <?php selected($d['applies'], 'all'); ?>>All</option>
                                    <option value="post" <?php selected($d['applies'], 'post'); ?>>Posts</option>
                                    <option value="page" <?php selected($d['applies'], 'page'); ?>>Pages</option>
                                </select>
                            </td>
                            <td><input type="text" class="small-text" style="width:100px;" name="docs[<?php echo (int) $id; ?>][tag]" value="<?php echo esc_attr($d['tag']); ?>" placeholder="any"></td>
                            <td class="cap-row-actions">
                                <a href="<?php echo esc_url(self::page_url(['tab' => 'quality', 'doc' => $id])); ?>">View / edit</a> ·
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=cap_doc_download&doc=' . $id), 'cap_doc_download_' . $id)); ?>">Download</a> ·
                                <a href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=cap_doc_delete&doc=' . $id), 'cap_doc_delete_' . $id)); ?>" style="color:#b32d2e;" onclick="return confirm('Delete this document from the library?');">Delete</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <p class="description" style="margin:10px 0;">
                    <strong>Only for tag:</strong> the document is used only for topics that start with that tag, e.g. a reviews SOP with tag <code>review</code> is used for <code>[review] Betway Casino Review</code>.
                    Leave empty to use it for every topic. <?php echo $enabled; ?> of <?php echo count($docs); ?> documents are on.
                </p>
                <?php submit_button('Save library settings', 'primary', 'submit', false); ?>
            </form>
        </div>
        <?php
    }

    private static function render_doc_editor($d) {
        $id = (int) $d['id'];
        $tok = self::tokens_est(strlen($d['content']));
        ?>
        <p><a href="<?php echo esc_url(self::page_url(['tab' => 'quality']) . '#cap-library'); ?>">&larr; Back to the SOP library</a></p>
        <div class="cap-card" id="cap-library">
            <h2><?php echo $id ? 'Edit document' : 'New document'; ?></h2>
            <p class="cap-sub"><?php echo $id ? esc_html(($d['filename'] ?: 'created here') . ' · ~' . self::fmt_tokens($tok) . ' tokens') : 'Write a prompt or rules for Claude. Markdown is fine. After saving, choose which pipeline step uses it in the library table.'; ?>
                <?php if (!empty($d['edited'])) echo ' · ' . self::badge('Edited since upload', 'info'); ?></p>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <input type="hidden" name="action" value="cap_doc_edit">
                <input type="hidden" name="doc_id" value="<?php echo $id; ?>">
                <?php wp_nonce_field('cap_doc_edit'); ?>
                <p><label><strong>Title</strong><br><input type="text" name="doc_title" value="<?php echo esc_attr($d['title']); ?>" class="large-text" required></label></p>
                <p><label><strong>Content</strong> <span class="description">(Markdown)</span><br>
                    <textarea name="doc_content" rows="28" class="large-text code" style="font-family:Consolas,Monaco,monospace;font-size:13px;line-height:1.55;" spellcheck="false"><?php echo esc_textarea($d['content']); ?></textarea></label></p>
                <div class="cap-inline-form">
                    <?php submit_button('Save document', 'primary', 'submit', false); ?>
                    <?php if ($id && !empty($d['edited'])) : ?>
                        <button type="submit" name="revert" value="1" class="button" onclick="return confirm('Discard your edits and restore the uploaded version?');">Revert to uploaded version</button>
                    <?php endif; ?>
                    <a class="button-link" href="<?php echo esc_url(self::page_url(['tab' => 'quality']) . '#cap-library'); ?>">Cancel</a>
                </div>
            </form>
        </div>
        <?php
    }

    /* ---------------------------------------------------------------
     * Images: designed from scratch (PHP GD), featured + one in the body
     * ------------------------------------------------------------- */

    private static function currency_symbol($geo) {
        if (isset(self::GEOS[$geo]) && preg_match('/\(([^)]+)\)/u', self::GEOS[$geo][4], $m)) return $m[1];
        return '$';
    }

    private static function image_spec($plan, $s, $geo, $lang, $layout) {
        return [
            'headline' => (string) ($plan['headline'] ?? ''),
            'keywords' => array_slice((array) ($plan['keywords'] ?? []), 0, 3),
            'motif'    => (string) ($plan['motif'] ?? 'chips'),
            'brand'    => trim($s['img_brand']) !== '' ? $s['img_brand'] : wp_specialchars_decode(get_bloginfo('name'), ENT_QUOTES),
            'bg'       => $s['img_bg'],
            'accent'   => $s['img_accent'],
            'currency' => self::currency_symbol($geo),
            'layout'   => $layout,
            // The bundled font covers Latin script only, so Chinese, Hindi and Arabic images carry no text.
            'text'     => !empty($s['img_text']) && in_array($lang, ['en', 'es', 'fr'], true),
        ];
    }

    /** Render a graphic into the uploads folder and register it in the Media Library. */
    private static function save_image($spec, $filename, $parent, $alt, $title, $caption = '') {
        $up = wp_upload_dir();
        if (!empty($up['error'])) return new WP_Error('upload', $up['error']);
        $name = wp_unique_filename($up['path'], (sanitize_file_name($filename) ?: 'casino-guide') . '.jpg');
        $path = trailingslashit($up['path']) . $name;

        $r = (new CAP_Image())->render($spec, $path);
        if ($r !== true) return new WP_Error('render', $r);

        $id = wp_insert_attachment([
            'post_mime_type' => 'image/jpeg',
            'post_title'     => $title,
            'post_excerpt'   => $caption,
            'post_content'   => '',
            'post_status'    => 'inherit',
        ], $path, $parent, true);
        if (is_wp_error($id)) return $id;

        require_once ABSPATH . 'wp-admin/includes/image.php';
        wp_update_attachment_metadata($id, wp_generate_attachment_metadata($id, $path));
        update_post_meta($id, '_wp_attachment_image_alt', $alt);
        update_post_meta($id, '_cap_generated', 1);
        return $id;
    }

    /** Insert a figure after the first paragraph that follows the Nth H2 (falls back to the first paragraph). */
    private static function insert_figure($html, $figure, $after_h2) {
        $pos = 0;
        $n = max(1, (int) $after_h2);
        for ($i = 0; $i < $n; $i++) {
            $p = stripos($html, '<h2', $pos);
            if ($p === false) { $pos = $i ? $pos : 0; break; }
            $pos = $p + 3;
        }
        $end = stripos($html, '</p>', $pos);
        if ($end === false) $end = stripos($html, '</p>');
        if ($end === false) return $html . "\n" . $figure;
        $end += 4;
        return substr($html, 0, $end) . "\n" . $figure . "\n" . substr($html, $end);
    }

    /** Plans and creates the images for a saved post. Never fails the post: problems are logged as warnings. */
    private static function add_images($post_id, $post, $s, $lang, $lang_name, $kind, $kws, $primary, $geo) {
        $want_f = !empty($s['img_featured']);
        $want_b = !empty($s['img_body']);
        if (!$want_f && !$want_b) return;

        $mark = self::stage_start();
        if (!CAP_Image::supported()) {
            self::stage_end($mark, 'images', 'Images', 'warn', 'Skipped: this server’s PHP has no GD/FreeType support, so images cannot be drawn.');
            self::log('Images skipped: PHP GD with FreeType is not available on this server.', 'warn');
            return;
        }

        preg_match_all('/<h2[^>]*>(.*?)<\/h2>/is', (string) $post['content_html'], $m);
        $h2s = array_map(function ($h) { return trim(wp_strip_all_tags($h)); }, $m[1] ?? []);
        $motifs = '';
        foreach (CAP_Image::MOTIFS as $k => $hint) $motifs .= "- {$k}: {$hint}\n";

        $prompt = "Plan two illustrations for this {$kind}. The graphics are drawn automatically from your plan.\n\n"
                . "TITLE: {$post['title']}\nLANGUAGE: {$lang_name}\n"
                . ($kws ? 'KEYWORDS: ' . implode(', ', $kws) . "\n" : '')
                . "SECTIONS (H2, numbered):\n" . implode("\n", array_map(function ($h, $i) { return ($i + 1) . '. ' . $h; }, $h2s, array_keys($h2s))) . "\n\n"
                . "AVAILABLE ILLUSTRATIONS:\n{$motifs}\n"
                . "Return ONLY a JSON object:\n"
                . "{\"featured\": {\"headline\": \"the post's main message in at most 7 words, in {$lang_name}\", \"keywords\": [3 short keyword phrases of 1-3 words taken from the keywords, in {$lang_name}], \"motif\": \"one illustration name from the list\", \"alt\": \"descriptive alt text in {$lang_name}, under 125 characters, naturally including the primary keyword\", \"filename\": \"short-lowercase-ascii-slug-with-primary-keyword\"},\n"
                . " \"body\": {\"headline\": \"the key point of one section in at most 8 words, in {$lang_name}\", \"keywords\": [3 short phrases relevant to that section, in {$lang_name}], \"motif\": \"a DIFFERENT illustration name from the list\", \"after_h2\": the section number it belongs to (choose an early-to-middle section), \"alt\": \"descriptive alt text in {$lang_name}, under 125 characters\", \"caption\": \"one short caption sentence in {$lang_name}\", \"filename\": \"short-lowercase-ascii-slug\"}}";

        $plan = self::api_json('You are a graphic designer who plans clear, on-brand blog illustrations.', $prompt, 2000);
        if (is_wp_error($plan)) {
            self::stage_end($mark, 'images', 'Images', 'warn', 'Image planning failed: ' . $plan->get_error_message());
            self::log('Images skipped: ' . $plan->get_error_message(), 'warn');
            return;
        }

        $done = []; $data = ['plan' => $plan];
        $title = get_the_title($post_id);

        if ($want_f && !empty($plan['featured'])) {
            $f  = $plan['featured'];
            $id = self::save_image(self::image_spec($f, $s, $geo, $lang, 'featured'), $f['filename'] ?? $primary, $post_id,
                sanitize_text_field($f['alt'] ?? $title), $title);
            if (is_wp_error($id)) {
                self::log('Featured image failed: ' . $id->get_error_message(), 'warn');
            } else {
                set_post_thumbnail($post_id, $id);
                $done[] = 'featured image';
                $data['featured'] = ['id' => $id, 'url' => wp_get_attachment_image_url($id, 'medium_large'), 'motif' => $f['motif'] ?? ''];
            }
        }

        if ($want_b && !empty($plan['body'])) {
            $b  = $plan['body'];
            $alt = sanitize_text_field($b['alt'] ?? $title);
            $cap = sanitize_text_field($b['caption'] ?? '');
            $id  = self::save_image(self::image_spec($b, $s, $geo, $lang, 'body'), $b['filename'] ?? ($primary . '-guide'), $post_id, $alt, $title, $cap);
            if (is_wp_error($id)) {
                self::log('Body image failed: ' . $id->get_error_message(), 'warn');
            } else {
                $url = wp_get_attachment_image_url($id, 'large');
                $fig = '<figure class="wp-block-image size-large"><img src="' . esc_url($url) . '" alt="' . esc_attr($alt) . '" class="wp-image-' . (int) $id . '" width="1200" height="630" loading="lazy" />'
                     . ($cap ? '<figcaption class="wp-element-caption">' . esc_html($cap) . '</figcaption>' : '') . '</figure>';
                $content = get_post_field('post_content', $post_id);
                wp_update_post(['ID' => $post_id, 'post_content' => self::insert_figure($content, $fig, $b['after_h2'] ?? 1)]);
                $done[] = 'body image';
                $data['body'] = ['id' => $id, 'url' => wp_get_attachment_image_url($id, 'medium_large'), 'motif' => $b['motif'] ?? '', 'after_h2' => (int) ($b['after_h2'] ?? 1)];
            }
        }

        $wanted = ($want_f ? 1 : 0) + ($want_b ? 1 : 0);
        self::stage_end($mark, 'images', 'Images', count($done) === $wanted ? 'ok' : 'warn',
            $done ? 'Designed and added the ' . implode(' and the ', $done) . ' (keywords written on the graphics' . (in_array($lang, ['en', 'es', 'fr'], true) && !empty($s['img_text']) ? '' : ': off for this language') . ').' : 'No images could be created.', $data);
    }

    /** Settings → Images: show a sample built from the current (unsaved) colours. */
    public static function handle_image_preview() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_image_preview');
        if (!CAP_Image::supported()) wp_die('This server’s PHP has no GD/FreeType support, so the plugin cannot draw images here.');

        $s = self::settings();
        foreach (['img_bg', 'img_accent'] as $k) {
            if (!empty($_GET[$k]) && preg_match('/^#[0-9a-f]{6}$/i', $_GET[$k])) $s[$k] = $_GET[$k];
        }
        if (isset($_GET['img_brand'])) $s['img_brand'] = sanitize_text_field(wp_unslash($_GET['img_brand']));
        $layout = (($_GET['layout'] ?? '') === 'body') ? 'body' : 'featured';
        $spec = self::image_spec([
            'headline' => $layout === 'body' ? 'What wagering requirements really mean' : 'Casino Bonuses Explained: Welcome Offers and Free Spins',
            'keywords' => ['casino bonuses', 'free spins', 'wagering'],
            'motif'    => $layout === 'body' ? 'checklist' : 'chips',
        ], $s, $s['geo'], 'en', $layout);
        $tmp = wp_tempnam('cap-preview') ;
        $r = (new CAP_Image())->render($spec, $tmp);
        if ($r !== true) wp_die(esc_html($r));
        nocache_headers();
        header('Content-Type: image/jpeg');
        header('Content-Length: ' . filesize($tmp));
        readfile($tmp);
        @unlink($tmp);
        exit;
    }

    /* ===============================================================
     * OPTIMISE EXISTING POSTS & PAGES
     * Audit → optimised draft copy → compare → apply (old version kept as a revision).
     * =============================================================== */

    /** Page builders store layouts outside the normal content, so a rewrite would break them. */
    private static function page_builder($id) {
        if (get_post_meta($id, '_elementor_edit_mode', true) === 'builder') return 'Elementor';
        if (get_post_meta($id, '_et_pb_use_builder', true) === 'on') return 'Divi';
        if (get_post_meta($id, '_fl_builder_enabled', true)) return 'Beaver Builder';
        if (get_post_meta($id, 'ct_builder_shortcodes', true)) return 'Oxygen';
        if (get_post_meta($id, '_bricks_page_content_2', true)) return 'Bricks';
        $c = (string) get_post_field('post_content', $id);
        if (strpos($c, '[vc_row') !== false) return 'WPBakery';
        if (strpos($c, '[et_pb_') !== false) return 'Divi';
        return '';
    }

    private static function focus_keyword($id) {
        foreach (['_cap_opt_keyword', '_yoast_wpseo_focuskw', 'rank_math_focus_keyword', '_cap_keywords'] as $k) {
            $v = trim((string) get_post_meta($id, $k, true));
            if ($v !== '') return $v;
        }
        return '';
    }

    /**
     * Replace everything the rewrite must not touch (non-text blocks, images, tables, embeds, shortcodes)
     * with [[KEEP-n]] placeholders. Returns [html for Claude, map placeholder => original markup].
     */
    private static function protect_content($html) {
        $map = [];
        $n   = 0;
        $keep = function ($chunk) use (&$map, &$n) {
            $n++;
            $key = '[[KEEP-' . $n . ']]';
            $map[$key] = $chunk;
            return "\n" . $key . "\n";
        };

        if (function_exists('has_blocks') && has_blocks($html)) {
            $text_blocks = ['core/paragraph', 'core/heading', 'core/list', 'core/quote'];
            $out = '';
            foreach (parse_blocks($html) as $b) {
                if ($b['blockName'] === null) { $out .= $b['innerHTML']; continue; }
                if (in_array($b['blockName'], $text_blocks, true)) { $out .= render_block($b); continue; }
                $out .= $keep(serialize_block($b));
            }
            $html = $out;
        }
        $html = preg_replace_callback('/<(script|style|iframe|object|video|audio|form|figure|table|svg)\b.*?<\/\1>/is', function ($m) use ($keep) { return $keep($m[0]); }, $html);
        $html = preg_replace_callback('/<(img|embed|input)\b[^>]*>/i', function ($m) use ($keep) { return $keep($m[0]); }, $html);
        if (function_exists('get_shortcode_regex')) {
            $html = preg_replace_callback('/' . get_shortcode_regex() . '/s', function ($m) use ($keep) { return $m[1] === '[' && $m[6] === ']' ? $m[0] : $keep($m[0]); }, $html);
        }
        $html = preg_replace("/\n{3,}/", "\n\n", trim($html));
        return [$html, $map];
    }

    /** Put protected markup back. Returns [html, missing placeholders]. */
    private static function restore_content($html, $map) {
        $missing = [];
        foreach ($map as $key => $chunk) {
            $re = '/<p>\s*' . preg_quote($key, '/') . '\s*<\/p>|' . preg_quote($key, '/') . '/';
            if (!preg_match($re, $html)) { $missing[$key] = $chunk; continue; }
            $html = preg_replace($re, str_replace(['\\', '$'], ['\\\\', '\\$'], "\n" . $chunk . "\n"), $html, 1);
        }
        return [trim($html), $missing];
    }

    private static function hrefs($html) {
        preg_match_all('/<a\b[^>]*\bhref=(["\'])(.*?)\1/i', (string) $html, $m);
        return array_values(array_unique(array_filter(array_map('trim', $m[2]))));
    }

    private static function text_lines($html) {
        $html = preg_replace('/<!--.*?-->/s', '', (string) $html);
        $html = preg_replace('/<h([1-6])[^>]*>/i', "\n## ", $html);
        $html = preg_replace('/<li[^>]*>/i', "\n• ", $html);
        $html = preg_replace('/<\/t[dh]>/i', ' · ', $html);
        $html = preg_replace('/<(\/p|\/h[1-6]|br\s*\/?|\/li|\/tr|\/blockquote|\/figure|\/table)>/i', "\n", $html);
        $txt  = html_entity_decode(wp_strip_all_tags($html, false), ENT_QUOTES, 'UTF-8');
        $lines = array_filter(array_map(function ($l) { return trim(preg_replace('/\s+/u', ' ', $l)); }, explode("\n", $txt)), 'strlen');
        return implode("\n", $lines);
    }

    /* ---- job state (shown live in the editor box) ---- */

    private static function job_set($id, $state, $step = '', $extra = []) {
        update_post_meta($id, '_cap_opt_job', array_merge(['state' => $state, 'step' => $step, 'time' => time()], $extra));
    }

    private static function job_get($id) {
        $j = get_post_meta($id, '_cap_opt_job', true);
        if (is_array($j) && $j['state'] === 'running' && time() - (int) $j['time'] > 20 * MINUTE_IN_SECONDS) {
            $j = ['state' => 'failed', 'step' => '', 'message' => 'The job stopped without finishing (server time limit). Please try again.', 'time' => time()];
            update_post_meta($id, '_cap_opt_job', $j);
        }
        return is_array($j) ? $j : ['state' => 'idle'];
    }

    /** Send the JSON reply to the browser now, then keep working on the server. */
    private static function json_and_continue($data) {
        ignore_user_abort(true);
        if (function_exists('set_time_limit')) @set_time_limit(0);
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
        while (ob_get_level() > 0) @ob_end_clean();
        $body = wp_json_encode(['success' => true, 'data' => $data]);
        header('Content-Type: application/json; charset=utf-8');
        header('Content-Length: ' . strlen($body));
        header('Connection: close');
        echo $body;
        if (function_exists('fastcgi_finish_request')) { fastcgi_finish_request(); }
        elseif (function_exists('litespeed_finish_request')) { litespeed_finish_request(); }
        else { flush(); }
    }

    /* ---- AJAX endpoints ---- */

    public static function ajax_opt_start() {
        $id = (int) ($_POST['post_id'] ?? 0);
        check_ajax_referer('cap_opt_' . $id);
        if (!$id || !current_user_can('edit_post', $id)) wp_send_json_error('Not allowed');
        $job = in_array($_POST['job'] ?? '', ['audit', 'optimise'], true) ? $_POST['job'] : 'audit';
        if (!self::api_key()) wp_send_json_error('No Claude API key is set. Ask an admin to add it in Auto Poster → General.');
        if (self::job_get($id)['state'] === 'running') wp_send_json_error('A job is already running for this page.');
        if ($job === 'optimise' && ($b = self::page_builder($id))) wp_send_json_error('This page is built with ' . $b . '. Only audits are available.');

        $opts = [
            'keyword' => sanitize_text_field(wp_unslash($_POST['keyword'] ?? '')),
            'geo'     => isset(self::GEOS[$_POST['geo'] ?? '']) ? $_POST['geo'] : '',
            'tag'     => strtolower(preg_replace('/[^a-z0-9-]/i', '', (string) ($_POST['tag'] ?? ''))),
            'words'   => max(300, min(5000, (int) ($_POST['words'] ?? 0))),
        ];
        update_post_meta($id, '_cap_opt_keyword', $opts['keyword']);
        update_post_meta($id, '_cap_opt_opts', $opts);
        self::job_set($id, 'running', $job === 'audit' ? 'Auditing the page…' : 'Starting…', ['job' => $job]);

        self::json_and_continue(['state' => 'running']);
        try {
            $job === 'audit' ? self::audit_post($id, $opts) : self::optimise_post($id, $opts);
        } catch (Throwable $e) {
            self::job_set($id, 'failed', '', ['message' => 'Error: ' . $e->getMessage()]);
        }
        exit;
    }

    public static function ajax_opt_status() {
        $id = (int) ($_POST['post_id'] ?? 0);
        check_ajax_referer('cap_opt_' . $id);
        if (!$id || !current_user_can('edit_post', $id)) wp_send_json_error('Not allowed');
        $j = self::job_get($id);
        wp_send_json_success(['state' => $j['state'], 'step' => $j['step'] ?? '', 'html' => $j['state'] === 'running' ? '' : self::opt_box_html(get_post($id))]);
    }

    /* ---- the work ---- */

    private static function opt_context($id, $opts) {
        $s    = self::settings();
        $p    = get_post($id);
        $type = $p->post_type === 'page' ? 'page' : 'post';
        $lang = get_post_meta($id, '_cap_language', true) ?: ($s['language'] ?: 'en');
        if (!isset(self::LANGUAGES[$lang])) $lang = 'en';
        $geo  = $opts['geo'] !== '' ? $opts['geo'] : (get_post_meta($id, '_cap_geo', true) ?: $s['geo']);
        $kind = $type === 'page' ? 'website page' : 'blog post';
        list(, $lang_name) = self::LANGUAGES[$lang];
        $kws  = array_values(array_filter(array_map('trim', explode(',', $opts['keyword']))));

        $rule = $lang === 'en' ? 'The page is in English.' : "The page is in {$lang_name} and must stay in {$lang_name}.";
        if ($geo && isset(self::GEOS[$geo])) {
            list($g_name, , $g_region, , $g_cur, $g_eng) = self::GEOS[$geo];
            $rule .= "\nTARGET MARKET: readers in {$g_name}. Use {$g_cur} for money" . ($lang === 'en' ? ", {$g_eng} spelling" : '')
                   . ", and local payment methods and context. Describe the legal position in {$g_name} only where you are confident; never imply play is legal where it is restricted.";
        }
        $kw_text = $kws ? "Primary keyword: {$kws[0]}\nSecondary keywords: " . (count($kws) > 1 ? implode(', ', array_slice($kws, 1)) : '(none)')
                        : 'No focus keyword was given: identify the keyword this page should target and use it.';

        return [
            's' => $s, 'post' => $p, 'type' => $type, 'lang' => $lang, 'lang_name' => $lang_name, 'geo' => $geo, 'kind' => $kind,
            'kws' => $kws, 'rule' => $rule, 'kw_text' => $kw_text,
            'dctx' => ['type' => $type, 'tags' => $opts['tag'] ? [$opts['tag']] : [], 'kind' => $type],
        ];
    }

    private static function audit_post($id, $opts) {
        self::$usage = ['in' => 0, 'out' => 0, 'searches' => 0, 'calls' => 0];
        $c = self::opt_context($id, $opts);
        list($html) = self::protect_content((string) $c['post']->post_content);
        $words = self::count_words($html, $c['lang']);
        $desc  = get_post_meta($id, '_yoast_wpseo_metadesc', true) ?: get_post_meta($id, 'rank_math_description', true) ?: $c['post']->post_excerpt;

        $prompt = "Audit this existing, published {$c['kind']} for SEO and quality. It may already rank, so judge what to keep as well as what to fix.\n"
                . "{$c['rule']}\n{$c['kw_text']}\n\n"
                . "Score it against the team's QA SOPs and checklists in your instructions (or general best practice if none are given), and these core rules: no invented facts or figures; gambling topics need a responsible gambling note and must never promise winnings; the primary keyword belongs in the title, the first 100 words and an H2.\n"
                . "Placeholders like [[KEEP-3]] stand for images, tables, embeds and widgets that are not shown here; do not score them.\n\n"
                . "TITLE: {$c['post']->post_title}\nMETA DESCRIPTION: {$desc}\nCURRENT LENGTH: about {$words} words\n\nCONTENT:\n{$html}\n\n"
                . "Return ONLY a JSON object: {\"score\": integer 0-100, \"summary\": \"two sentences\", \"keyword\": \"the primary keyword this page should target\", "
                . "\"strengths\": [up to 5 short strings], \"issues\": [{\"problem\": \"...\", \"fix\": \"a specific instruction\", \"priority\": \"high|medium|low\"}], "
                . "\"recommended_words\": integer}";
        $r = self::api_json(self::sys('qa', 'You are a strict senior SEO content editor auditing existing pages.', $c['dctx']), $prompt, 6000);
        if (is_wp_error($r) || !isset($r['score'])) {
            self::job_set($id, 'failed', '', ['message' => 'Audit failed: ' . (is_wp_error($r) ? $r->get_error_message() : 'unreadable response')]);
            return;
        }
        $audit = [
            'score'     => max(0, min(100, (int) $r['score'])),
            'summary'   => sanitize_text_field($r['summary'] ?? ''),
            'keyword'   => sanitize_text_field($r['keyword'] ?? ''),
            'strengths' => array_map('sanitize_text_field', array_slice((array) ($r['strengths'] ?? []), 0, 5)),
            'issues'    => array_slice(array_values(array_filter((array) ($r['issues'] ?? []), 'is_array')), 0, 15),
            'rec_words' => (int) ($r['recommended_words'] ?? 0),
            'words'     => $words,
            'date'      => current_time('mysql'),
            'tokens'    => self::$usage,
        ];
        update_post_meta($id, '_cap_audit', wp_slash(wp_json_encode($audit, JSON_UNESCAPED_UNICODE)));
        if (!$opts['keyword'] && $audit['keyword']) update_post_meta($id, '_cap_opt_keyword', $audit['keyword']);
        self::log(sprintf('Audited "%s" (ID %d): %d/100.', $c['post']->post_title, $id, $audit['score']));
        self::job_set($id, 'done', '', ['job' => 'audit']);
    }

    private static function optimise_post($id, $opts) {
        self::$usage = ['in' => 0, 'out' => 0, 'searches' => 0, 'calls' => 0];
        self::$trace = [];
        self::$research = ['queries' => [], 'results' => [], 'errors' => []];
        $c = self::opt_context($id, $opts);
        $s = $c['s'];
        list($html, $map) = self::protect_content((string) $c['post']->post_content);
        $orig_links = self::hrefs($c['post']->post_content);
        $cur_words  = self::count_words($html, $c['lang']);
        $words = $opts['words'] ?: max(600, $cur_words);
        $max   = min(32000, max(12000, (int) $s['max_tokens'], $words * (in_array($c['lang'], ['zh', 'hi', 'ar'], true) ? 7 : 4)));
        $len   = "TARGET LENGTH: about {$words} words for the article body (within 10%).";
        $audit = json_decode((string) get_post_meta($id, '_cap_audit', true), true);
        $issues = '';
        foreach ((array) ($audit['issues'] ?? []) as $iss) $issues .= '- ' . ($iss['problem'] ?? '') . ' → ' . ($iss['fix'] ?? '') . "\n";

        self::$run = ['t0' => microtime(true), 'started' => current_time('mysql'), 'topic' => 'Optimise: ' . $c['post']->post_title, 'keywords' => $c['kws'],
                      'language' => $c['lang'], 'type' => $c['type'], 'geo' => $c['geo'], 'model' => $s['model'], 'words' => $words,
                      'docs' => self::docs_plan($c['dctx']), 'qa' => !empty($s['qa_enabled']) ? (int) $s['qa_threshold'] : 0];
        $protect = "PROTECTED ITEMS: the content contains placeholders like [[KEEP-3]]. Each stands for an image, table, embed, widget or shortcode. "
                 . "Keep EVERY placeholder exactly as written, each on its own line, in a sensible position. Never remove or invent placeholders.\n"
                 . "LINKS: keep every existing link (<a href=\"...\">) with exactly the same href, including affiliate links. You may adjust the anchor text slightly if a sentence is rewritten.";

        // 1. brief
        self::job_set($id, 'running', !empty($s['web_research']) ? 'Researching competitors and planning…' : 'Planning the improvements…', ['job' => 'optimise']);
        $tools = [];
        if (!empty($s['web_research'])) {
            $tool = ['type' => 'web_search_20250305', 'name' => 'web_search', 'max_uses' => 5];
            if ($c['geo'] && isset(self::GEOS[$c['geo']])) {
                $tool['user_location'] = array_filter(['type' => 'approximate', 'country' => self::GEOS[$c['geo']][1], 'region' => self::GEOS[$c['geo']][2], 'timezone' => self::GEOS[$c['geo']][3]]);
            }
            $tools = [$tool];
        }
        $mark = self::stage_start();
        $brief = self::api_json(self::sys('brief', $s['system_prompt'], $c['dctx']),
            "Plan how to improve this existing {$c['kind']} so it ranks and converts better.\n{$c['rule']}\n{$c['kw_text']}\n{$len}\n"
            . ($tools ? "First use web search to look at the pages currently ranking for the primary keyword" . ($c['geo'] ? ' for searchers in ' . self::GEOS[$c['geo']][0] : '') . ", and find what they cover that this page does not.\n" : '')
            . ($issues ? "A recent audit found:\n{$issues}\n" : '')
            . "\nCURRENT TITLE: {$c['post']->post_title}\nCURRENT CONTENT:\n{$html}\n\n"
            . "Write the plan in English. Return ONLY a JSON object with: \"search_intent\", \"angle\", \"keep\" (array: strong parts to keep), \"improve\" (array of specific changes), "
            . "\"add\" (array of missing sections or points), \"outline\" (array of {\"h2\": string, \"h3\": array, \"notes\": string}), \"faq\" (array), "
            . "\"competitor_notes\" (string), \"competitors_reviewed\" (array of {\"url\",\"site\",\"strengths\",\"gaps\"}).",
            $max, $tools);
        if (is_wp_error($brief)) return self::opt_fail($id, 'brief', 'Planning', $mark, $brief);
        self::stage_end($mark, 'brief', $tools ? 'Research & plan' : 'Improvement plan', 'ok',
            sprintf('%d changes and %d additions planned%s.', count((array) ($brief['improve'] ?? [])), count((array) ($brief['add'] ?? [])), self::$usage['searches'] ? ' after ' . self::$usage['searches'] . ' web search(es)' : ''),
            array_merge($brief, ['_research' => self::$research, '_geo' => $c['geo']]));
        $brief_json = wp_json_encode($brief, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        // 2. optimised rewrite
        self::job_set($id, 'running', 'Writing the optimised version…', ['job' => 'optimise']);
        $writer = $s['system_prompt'];
        $fmt = self::format_spec($c['lang'], $c['lang_name']) . "\nAlso include \"change_summary\": an array of the 3 to 8 most important changes you made, in plain English.";
        $mark = self::stage_start();
        $post = self::api_json(self::sys('draft', $writer, $c['dctx']),
            "Optimise this existing {$c['kind']} using the plan below. Keep what already works (this page may already rank): keep its topic, search intent and strong sections. "
            . "Apply the improvements, add what is missing, fix weak or outdated passages and make it read naturally.\n{$c['rule']}\n{$c['kw_text']}\n{$len}\n{$protect}\n\n"
            . "PLAN:\n{$brief_json}\n\nCURRENT TITLE: {$c['post']->post_title}\nCURRENT CONTENT:\n{$html}\n\n{$fmt}",
            $max);
        if (!is_wp_error($post) && !self::valid_post($post)) $post = new WP_Error('invalid', 'The optimised version was empty.');
        if (is_wp_error($post)) return self::opt_fail($id, 'draft', 'Optimised rewrite', $mark, $post);
        $changes = array_map('sanitize_text_field', (array) ($post['change_summary'] ?? []));
        $snap = self::snapshot($post, $c['lang']);
        self::stage_end($mark, 'draft', 'Optimised rewrite', 'ok', 'Rewrote the page (' . self::length_label($snap['words'], $c['lang']) . ', was ' . self::length_label($cur_words, $c['lang']) . ').', $snap);

        $revise = function ($p, $instr) use ($c, $max, $len, $protect, $writer) {
            $out = self::api_json(self::sys('edit', $writer, $c['dctx']),
                "Revise this {$c['kind']}.\n{$c['rule']}\n{$c['kw_text']}\n{$len}\n{$protect}\n\nINSTRUCTIONS:\n{$instr}\n\nKeep everything that already works.\n\nPOST (JSON):\n"
                . self::post_json($p) . "\n\n" . self::format_spec($c['lang'], $c['lang_name']), $max);
            return (!is_wp_error($out) && self::valid_post($out)) ? $out : null;
        };

        // 3. edit
        if (!empty($s['edit_pass'])) {
            self::job_set($id, 'running', 'Editing and humanizing…', ['job' => 'optimise']);
            $mark = self::stage_start();
            $e = $revise($post, self::docs_for('edit', $c['dctx']) ? 'Edit and humanize it by working through the editing and humanizing SOPs in your instructions, pass by pass.' : (trim($s['editing_guide']) ?: self::defaults()['editing_guide']));
            if ($e) { $post = array_merge($post, $e); self::stage_end($mark, 'edit', 'Edit & humanize', 'ok', 'Edited (' . self::length_label(self::count_words($post['content_html'], $c['lang']), $c['lang']) . ').', self::snapshot($post, $c['lang'])); }
            else { self::stage_end($mark, 'edit', 'Edit & humanize', 'warn', 'Editing pass failed; kept the rewrite.'); }
        }

        // 4. QA (+ rewrite)
        $qa = null; $rewrites = 0;
        if (!empty($s['qa_enabled'])) {
            $threshold = (int) $s['qa_threshold'];
            while (true) {
                self::job_set($id, 'running', $rewrites ? 'Re-checking quality…' : 'Checking quality…', ['job' => 'optimise']);
                $mark = self::stage_start();
                $r = self::api_json(self::sys('qa', 'You are a strict senior SEO content editor and QA auditor.', $c['dctx']),
                    "Audit this {$c['kind']} strictly against the team's QA SOPs (or best practice).\n{$c['rule']}\n{$c['kw_text']}\n{$len}\nIgnore [[KEEP-n]] placeholders.\n\nPOST (JSON):\n"
                    . self::post_json($post) . "\n\nReturn ONLY JSON: {\"score\": integer 0-100, \"summary\": \"...\", \"issues\": [{\"problem\": \"...\", \"fix\": \"...\"}]}", $max);
                if (is_wp_error($r) || !isset($r['score'])) { self::stage_end($mark, 'qa', 'QA score', 'warn', 'QA scoring failed.'); break; }
                $qa = ['score' => max(0, min(100, (int) $r['score'])), 'summary' => sanitize_text_field($r['summary'] ?? ''), 'issues' => array_values(array_filter((array) ($r['issues'] ?? []), 'is_array'))];
                $ok = $qa['score'] >= $threshold;
                self::stage_end($mark, 'qa', 'QA score', $ok ? 'ok' : 'warn', sprintf('Scored %d/100 (target %d).%s', $qa['score'], $threshold, $ok ? ' Passed.' : ''), $qa);
                if ($ok || $rewrites >= (int) $s['max_rewrites']) break;
                self::job_set($id, 'running', 'Fixing the issues QA found…', ['job' => 'optimise']);
                $fixes = '';
                foreach ($qa['issues'] as $iss) $fixes .= '- ' . ($iss['problem'] ?? '') . ' → ' . ($iss['fix'] ?? '') . "\n";
                $mark = self::stage_start();
                $rw = $revise($post, "QA scored this {$qa['score']}/100 (target {$threshold}). Fix every issue:\n{$fixes}");
                $rewrites++;
                if (!$rw) { self::stage_end($mark, 'rewrite', 'Rewrite #' . $rewrites, 'warn', 'Rewrite failed; kept the previous version.'); break; }
                $post = array_merge($post, $rw);
                $sn = self::snapshot($post, $c['lang']); $sn['instructions'] = $qa['issues'];
                self::stage_end($mark, 'rewrite', 'Rewrite #' . $rewrites, 'ok', sprintf('Fixed %d issue(s).', count($qa['issues'])), $sn);
            }
        }

        // 5. restore protected items and check links
        self::job_set($id, 'running', 'Checking images, tables and links are intact…', ['job' => 'optimise']);
        list($content, $missing) = self::restore_content(wp_kses_post($post['content_html']), $map);
        if ($missing) {
            $fixed = $revise($post, "You removed these protected placeholders. Put each one back exactly where it belongs, without changing anything else: " . implode(', ', array_keys($missing)));
            if ($fixed) { $post = array_merge($post, $fixed); list($content, $missing) = self::restore_content(wp_kses_post($post['content_html']), $map); }
        }
        $warnings = [];
        if ($missing) {
            foreach ($missing as $chunk) $content .= "\n" . $chunk;
            $warnings[] = count($missing) . ' image(s), table(s) or embed(s) could not be placed by Claude and were added at the end of the page. Move them into position before applying.';
        }
        $lost = array_values(array_diff($orig_links, self::hrefs($content)));
        if ($lost) $warnings[] = count($lost) . ' link(s) from the current page are missing: ' . implode(', ', array_slice($lost, 0, 8)) . (count($lost) > 8 ? '…' : '') . '. Add them back in the draft before applying.';

        // 6. save as a separate draft copy
        $old_copy = (int) get_post_meta($id, '_cap_opt_copy', true);
        if ($old_copy && get_post($old_copy)) wp_trash_post($old_copy);
        kses_remove_filters(); // protected embeds/scripts must survive exactly
        $copy = wp_insert_post([
            'post_type'    => $c['post']->post_type,
            'post_status'  => 'draft',
            'post_title'   => sanitize_text_field($post['title']),
            'post_excerpt' => sanitize_text_field($post['excerpt'] ?? ''),
            'post_content' => $content,
            'post_author'  => $c['post']->post_author,
            'post_parent'  => $c['post']->post_parent,
            'menu_order'   => $c['post']->menu_order,
        ], true);
        kses_init_filters();
        if (is_wp_error($copy)) return self::opt_fail($id, 'save', 'Saving the draft', self::stage_start(), $copy);
        self::stage_end(self::stage_start(), 'save', 'Saved optimised draft', 'ok', sprintf('Saved as a separate draft (ID %d). The live page is unchanged until you apply it.', $copy));

        update_post_meta($copy, '_cap_optimises', $id);
        update_post_meta($copy, '_cap_model', $s['model']);
        update_post_meta($copy, '_cap_language', $c['lang']);
        update_post_meta($copy, '_cap_geo', $c['geo']);
        update_post_meta($copy, '_cap_keywords', implode(', ', $c['kws']));
        update_post_meta($copy, '_cap_changes', $changes);
        update_post_meta($copy, '_cap_warnings', $warnings);
        update_post_meta($copy, '_cap_rewrites', $rewrites);
        if ($qa) {
            update_post_meta($copy, '_cap_qa_score', $qa['score']);
            update_post_meta($copy, '_cap_qa_passed', $qa['score'] >= (int) $s['qa_threshold'] ? 1 : 0);
            update_post_meta($copy, '_cap_qa_report', wp_slash(wp_json_encode($qa, JSON_UNESCAPED_UNICODE)));
        }
        update_post_meta($copy, '_cap_process', wp_slash(wp_json_encode(self::build_report('created', $copy), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)));
        update_post_meta($id, '_cap_opt_copy', $copy);
        self::log(sprintf('Optimised draft created for "%s" (ID %d → draft %d)%s. %d API calls, %s in / %s out tokens.',
            $c['post']->post_title, $id, $copy, $qa ? ', QA ' . $qa['score'] . '/100' : '', self::$usage['calls'], number_format(self::$usage['in']), number_format(self::$usage['out'])), $warnings ? 'warn' : 'info');
        self::job_set($id, 'done', '', ['job' => 'optimise']);
    }

    private static function opt_fail($id, $key, $label, $mark, WP_Error $e) {
        self::stage_end($mark, $key, $label, 'fail', $e->get_error_message());
        self::log($label . ' failed while optimising post ' . $id . ': ' . $e->get_error_message(), 'error');
        self::job_set($id, 'failed', '', ['message' => $label . ' failed: ' . $e->get_error_message()]);
        return $e;
    }

    /* ---- editor sidebar box ---- */

    public static function add_optimise_box($post_type, $post) {
        if (!in_array($post_type, ['post', 'page'], true) || !$post) return;
        if (get_post_meta($post->ID, '_cap_optimises', true)) {
            add_meta_box('cap_optimise', 'Optimised draft', [__CLASS__, 'render_copy_box'], $post_type, 'side', 'high');
            return;
        }
        add_meta_box('cap_optimise', 'Optimise with Auto Poster', [__CLASS__, 'render_optimise_box'], $post_type, 'side', 'high');
    }

    public static function render_copy_box($post) {
        $orig = (int) get_post_meta($post->ID, '_cap_optimises', true);
        echo '<p><strong>This is an optimised draft of “' . esc_html(get_the_title($orig)) . '”.</strong></p>';
        echo '<p>Don’t publish it directly, as that would create a duplicate page. Review it, then use <em>Compare &amp; apply</em> to update the original.</p>';
        echo '<p><a class="button button-primary" href="' . esc_url(admin_url('admin.php?page=cap-compare&post=' . $orig)) . '">Compare &amp; apply</a></p>';
    }

    public static function render_optimise_box($post) {
        echo '<div id="cap-opt-box" data-post="' . (int) $post->ID . '" data-nonce="' . esc_attr(wp_create_nonce('cap_opt_' . $post->ID)) . '">' . self::opt_box_html($post) . '</div>';
        ?>
        <style>
            #cap-opt-box .cap-o-score { font-size:22px; font-weight:700; }
            #cap-opt-box .cap-o-muted { color:#646970; font-size:12px; }
            #cap-opt-box label { display:block; font-weight:600; margin:8px 0 2px; }
            #cap-opt-box input[type=text], #cap-opt-box select, #cap-opt-box input[type=number] { width:100%; max-width:100%; min-width:0; box-sizing:border-box; }
            #cap-opt-box .cap-o-row { display:flex; gap:8px; } #cap-opt-box .cap-o-row > div { flex:1 1 0; min-width:0; }
            #cap-opt-box .cap-o-row > div:last-child { flex:0 0 86px; }
            #cap-opt-box .cap-o-btns { display:flex; flex-direction:column; gap:6px; margin-top:12px; }
            #cap-opt-box .cap-o-btns .button { text-align:center; justify-content:center; }
            #cap-opt-box ul { margin:6px 0 0 16px; list-style:disc; } #cap-opt-box li { margin-bottom:4px; }
            #cap-opt-box .cap-o-box { background:#f6f7f7; border:1px solid #dcdcde; border-radius:4px; padding:8px 10px; margin:8px 0; }
            #cap-opt-box .cap-o-ready { background:#e6f4ea; border-color:#a7d7b5; }
            #cap-opt-box .cap-o-spin { display:inline-block; width:12px; height:12px; border:2px solid #c3c4c7; border-top-color:#2271b1; border-radius:50%; animation:capspin 0.8s linear infinite; vertical-align:-2px; margin-right:6px; }
            @keyframes capspin { to { transform:rotate(360deg); } }
        </style>
        <script>
        (function () {
            var box = document.getElementById('cap-opt-box');
            if (!box) return;
            var timer = null;
            function post(action, extra) {
                var fd = new FormData();
                fd.append('action', action); fd.append('post_id', box.dataset.post); fd.append('_ajax_nonce', box.dataset.nonce);
                Object.keys(extra || {}).forEach(function (k) { fd.append(k, extra[k]); });
                return fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json(); });
            }
            function poll() {
                post('cap_opt_status').then(function (r) {
                    if (!r.success) return;
                    if (r.data.state === 'running') {
                        var st = box.querySelector('.cap-o-step'); if (st) st.textContent = r.data.step || 'Working…';
                        timer = setTimeout(poll, 4000);
                    } else { box.innerHTML = r.data.html; }
                }).catch(function () { timer = setTimeout(poll, 6000); });
            }
            box.addEventListener('click', function (e) {
                var b = e.target.closest('[data-job]');
                if (!b) return;
                e.preventDefault();
                if (b.dataset.job === 'optimise' && !confirm('Create an optimised version of this page? It is saved as a separate draft; the live page is not changed until you apply it.')) return;
                var v = function (n) { var el = box.querySelector('[name="' + n + '"]'); return el ? el.value : ''; };
                var data = { job: b.dataset.job, keyword: v('cap_o_keyword'), geo: v('cap_o_geo'), tag: v('cap_o_tag'), words: v('cap_o_words') };
                box.innerHTML = '<p><span class="cap-o-spin"></span><span class="cap-o-step">Starting…</span></p><p class="cap-o-muted">This takes ' + (b.dataset.job === 'audit' ? 'about a minute' : 'a few minutes') + '. You can keep editing or leave the page.</p>';
                post('cap_opt_start', data).then(function (r) {
                    if (!r.success) { box.innerHTML = '<p style="color:#b32d2e;">' + (r.data || 'Could not start.') + '</p>'; setTimeout(function () { post('cap_opt_status').then(function (s) { if (s.success) box.innerHTML = s.data.html; }); }, 3000); return; }
                    timer = setTimeout(poll, 3000);
                });
            });
            if (box.querySelector('.cap-o-step')) timer = setTimeout(poll, 3000);
        })();
        </script>
        <?php
    }

    private static function opt_box_html($post) {
        ob_start();
        $id  = $post->ID;
        $job = self::job_get($id);
        if (in_array($post->post_status, ['auto-draft'], true) || trim((string) $post->post_content) === '') {
            echo '<p class="cap-o-muted">Save this ' . esc_html($post->post_type) . ' with some content first, then you can audit and optimise it.</p>';
            return ob_get_clean();
        }
        if ($job['state'] === 'running') {
            echo '<p><span class="cap-o-spin"></span><span class="cap-o-step">' . esc_html($job['step'] ?: 'Working…') . '</span></p><p class="cap-o-muted">You can keep editing or leave the page.</p>';
            return ob_get_clean();
        }
        if ($job['state'] === 'failed' && !empty($job['message'])) {
            echo '<div class="cap-o-box" style="border-color:#e6a2a2;background:#fbe7e7;">' . esc_html($job['message']) . '</div>';
        }

        $builder = self::page_builder($id);
        $copy    = (int) get_post_meta($id, '_cap_opt_copy', true);
        if ($copy && get_post_status($copy) && get_post_status($copy) !== 'trash') {
            $sc = get_post_meta($copy, '_cap_qa_score', true);
            echo '<div class="cap-o-box cap-o-ready"><strong>Optimised draft ready</strong>' . ($sc !== '' ? ' · QA ' . (int) $sc . '/100' : '')
               . '<br><a class="button button-primary" style="margin-top:6px;" href="' . esc_url(admin_url('admin.php?page=cap-compare&post=' . $id)) . '">Compare &amp; apply</a></div>';
        }

        $audit = json_decode((string) get_post_meta($id, '_cap_audit', true), true);
        if ($audit) {
            $col = $audit['score'] >= 80 ? '#1e7b34' : ($audit['score'] >= 60 ? '#b26200' : '#b32d2e');
            echo '<div class="cap-o-box"><span class="cap-o-score" style="color:' . $col . ';">' . (int) $audit['score'] . '/100</span> <span class="cap-o-muted">audit · ' . esc_html(mysql2date('j M Y', $audit['date'])) . '</span>';
            if ($audit['summary']) echo '<p style="margin:6px 0;">' . esc_html($audit['summary']) . '</p>';
            if ($audit['issues']) {
                echo '<details><summary style="cursor:pointer;">' . count($audit['issues']) . ' issue(s) to fix</summary><ul>';
                foreach ($audit['issues'] as $iss) {
                    $pr = $iss['priority'] ?? '';
                    echo '<li>' . ($pr === 'high' ? '<strong>' : '') . esc_html($iss['problem'] ?? '') . ($pr === 'high' ? '</strong>' : '') . '</li>';
                }
                echo '</ul></details>';
            }
            echo '</div>';
        }

        $s     = self::settings();
        $opts  = (array) get_post_meta($id, '_cap_opt_opts', true);
        $kw    = self::focus_keyword($id) ?: ($audit['keyword'] ?? '');
        list($plain) = self::protect_content((string) $post->post_content);
        $words = !empty($opts['words']) ? (int) $opts['words'] : max(600, (int) (round(self::count_words($plain) / 50) * 50));
        if (!empty($audit['rec_words']) && empty($opts['words'])) $words = max($words, (int) $audit['rec_words']);
        $geo   = $opts['geo'] ?? (get_post_meta($id, '_cap_geo', true) ?: $s['geo']);
        $tags  = self::doc_tags();
        ?>
        <label for="cap_o_keyword">Focus keyword</label>
        <input type="text" id="cap_o_keyword" name="cap_o_keyword" value="<?php echo esc_attr($kw); ?>" placeholder="Leave empty to let Claude suggest one">
        <div class="cap-o-row">
            <div><label for="cap_o_geo">Market</label>
                <select id="cap_o_geo" name="cap_o_geo"><option value="">Global</option>
                    <?php foreach (self::GEOS as $code => $g) echo '<option value="' . esc_attr($code) . '"' . selected($geo, $code, false) . '>' . esc_html($g[0]) . '</option>'; ?>
                </select></div>
            <div><label for="cap_o_words">Words</label>
                <input type="number" id="cap_o_words" name="cap_o_words" value="<?php echo (int) $words; ?>" min="300" max="5000" step="50"></div>
        </div>
        <?php if ($tags) : ?>
            <label for="cap_o_tag">Page type (SOPs)</label>
            <select id="cap_o_tag" name="cap_o_tag"><option value="">General</option>
                <?php foreach ($tags as $t) echo '<option value="' . esc_attr($t) . '"' . selected($opts['tag'] ?? '', $t, false) . '>' . esc_html(ucfirst($t)) . '</option>'; ?>
            </select>
        <?php endif; ?>
        <div class="cap-o-btns">
            <button type="button" class="button" data-job="audit"><?php echo $audit ? 'Audit again' : 'Audit this ' . esc_html($post->post_type); ?></button>
            <?php if ($builder) : ?>
                <p class="cap-o-muted" style="margin:4px 0 0;">Built with <?php echo esc_html($builder); ?>: audits only. Rewriting would break the page layout.</p>
            <?php else : ?>
                <button type="button" class="button button-primary" data-job="optimise">Create optimised version</button>
                <p class="cap-o-muted" style="margin:2px 0 0;">Saved as a separate draft. The live <?php echo esc_html($post->post_type); ?> only changes when you apply it.</p>
            <?php endif; ?>
        </div>
        <?php
        return ob_get_clean();
    }

    /* ---- compare & apply ---- */

    public static function register_compare_page() {
        add_submenu_page('options.php', 'Compare optimised version', 'Compare optimised version', 'edit_posts', 'cap-compare', [__CLASS__, 'render_compare']);
    }

    public static function render_compare() {
        $id   = (int) ($_GET['post'] ?? 0);
        $orig = get_post($id);
        $copy_id = (int) get_post_meta($id, '_cap_opt_copy', true);
        $copy = $copy_id ? get_post($copy_id) : null;
        if (!$orig || !current_user_can('edit_post', $id)) wp_die('Not allowed.');
        echo '<div class="wrap"><h1>Compare optimised version</h1>';
        if (!$copy || $copy->post_status === 'trash') {
            echo '<p>No optimised draft exists for this page. Create one from the “Optimise with Auto Poster” box on the edit screen.</p></div>';
            return;
        }
        $audit    = json_decode((string) get_post_meta($id, '_cap_audit', true), true);
        $score    = get_post_meta($copy_id, '_cap_qa_score', true);
        $changes  = (array) get_post_meta($copy_id, '_cap_changes', true);
        $warnings = (array) get_post_meta($copy_id, '_cap_warnings', true);
        $w_old = self::count_words(self::text_lines($orig->post_content));
        $w_new = self::count_words(self::text_lines($copy->post_content));
        $l_old = count(self::hrefs($orig->post_content));
        $l_new = count(self::hrefs($copy->post_content));
        ?>
        <style>
            .cap-cmp-grid { display:grid; grid-template-columns:repeat(4, minmax(160px, 1fr)); gap:12px; margin:16px 0; }
            .cap-cmp-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:14px 16px; }
            .cap-cmp-card .l { font-size:11px; text-transform:uppercase; color:#646970; letter-spacing:.04em; }
            .cap-cmp-card .v { font-size:20px; font-weight:600; margin-top:4px; }
            .cap-cmp-box { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px 20px; margin-top:16px; }
            .cap-cmp-box h2 { margin-top:0; font-size:15px; }
            .cap-cmp-box table.diff { width:100%; }
            .cap-cmp-box table.diff td { padding:4px 8px 4px 26px; font-size:13px; line-height:1.55; vertical-align:top; position:relative; font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; }
            .cap-cmp-box table.diff td::before { left:8px !important; }
            .cap-cmp-actions { position:sticky; bottom:0; background:rgba(240,240,241,.96); border-top:1px solid #dcdcde; padding:12px 0; margin-top:16px; display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
        </style>
        <p>
            <strong>Current:</strong> <a href="<?php echo esc_url(get_edit_post_link($id)); ?>"><?php echo esc_html($orig->post_title); ?></a> ·
            <strong>Optimised draft:</strong> <a href="<?php echo esc_url(get_edit_post_link($copy_id)); ?>">edit</a> · <a href="<?php echo esc_url(get_preview_post_link($copy)); ?>" target="_blank">preview</a> ·
            <a href="<?php echo esc_url(self::page_url(['tab' => 'reports', 'report' => $copy_id])); ?>">process report</a>
        </p>
        <div class="cap-cmp-grid">
            <div class="cap-cmp-card"><div class="l">Score</div><div class="v"><?php echo $audit ? (int) $audit['score'] : '—'; ?> → <?php echo $score !== '' ? (int) $score : '—'; ?></div></div>
            <div class="cap-cmp-card"><div class="l">Words</div><div class="v"><?php echo number_format($w_old); ?> → <?php echo number_format($w_new); ?></div></div>
            <div class="cap-cmp-card"><div class="l">Links</div><div class="v"><?php echo $l_old; ?> → <?php echo $l_new; ?></div></div>
            <div class="cap-cmp-card"><div class="l">Title</div><div class="v" style="font-size:14px;"><?php echo $orig->post_title === $copy->post_title ? 'Unchanged' : esc_html($copy->post_title); ?></div></div>
        </div>
        <?php foreach ($warnings as $w) : ?>
            <div class="notice notice-warning inline"><p><?php echo esc_html($w); ?></p></div>
        <?php endforeach; ?>
        <?php if ($changes) : ?>
            <div class="cap-cmp-box"><h2>What changed</h2><ul style="list-style:disc;margin-left:18px;"><?php foreach ($changes as $ch) echo '<li>' . esc_html($ch) . '</li>'; ?></ul></div>
        <?php endif; ?>
        <div class="cap-cmp-box">
            <h2>Text changes</h2>
            <p class="description">Removed text is highlighted on the left, new text on the right. Images, tables and embeds are kept as they are and not shown here; use Preview to see the full page.</p>
            <?php echo wp_text_diff(self::text_lines($orig->post_content), self::text_lines($copy->post_content), ['title_left' => 'Current', 'title_right' => 'Optimised', 'show_split_view' => true]) ?: '<p>No text differences.</p>'; ?>
        </div>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cap-cmp-actions">
            <input type="hidden" name="action" value="cap_opt_apply">
            <input type="hidden" name="post" value="<?php echo (int) $id; ?>">
            <?php wp_nonce_field('cap_opt_apply_' . $id); ?>
            <label><input type="checkbox" name="apply_title" value="1" <?php checked($orig->post_title !== $copy->post_title); ?>> Use the new title</label>
            <label><input type="checkbox" name="apply_meta" value="1" checked> Use the new meta description</label>
            <button type="submit" name="do" value="apply" class="button button-primary" onclick="return confirm('Replace the current content with the optimised version? The current version is saved as a revision so you can restore it.');">Apply to the live <?php echo esc_html($orig->post_type); ?></button>
            <button type="submit" name="do" value="discard" class="button" onclick="return confirm('Discard the optimised draft?');">Discard</button>
            <span class="description">The URL never changes. The current version is kept in Revisions.</span>
        </form>
        </div>
        <?php
    }

    public static function handle_opt_apply() {
        $id = (int) ($_POST['post'] ?? 0);
        check_admin_referer('cap_opt_apply_' . $id);
        if (!$id || !current_user_can('edit_post', $id)) wp_die('Not allowed');
        $copy_id = (int) get_post_meta($id, '_cap_opt_copy', true);
        $copy = $copy_id ? get_post($copy_id) : null;
        if (!$copy) wp_die('No optimised draft found.');

        if (($_POST['do'] ?? '') === 'discard') {
            wp_trash_post($copy_id);
            delete_post_meta($id, '_cap_opt_copy');
            self::log('Optimised draft discarded for post ' . $id . '.');
            wp_safe_redirect(add_query_arg('cap_opt', 'discarded', get_edit_post_link($id, 'raw')));
            exit;
        }

        wp_save_post_revision($id); // make sure the current version is in Revisions
        $arr = ['ID' => $id, 'post_content' => wp_slash($copy->post_content)];
        if (!empty($_POST['apply_title'])) $arr['post_title'] = wp_slash($copy->post_title);
        if (!empty($_POST['apply_meta']) && $copy->post_excerpt !== '') {
            $arr['post_excerpt'] = wp_slash($copy->post_excerpt);
            if (defined('WPSEO_VERSION')) update_post_meta($id, '_yoast_wpseo_metadesc', $copy->post_excerpt);
            if (class_exists('RankMath')) update_post_meta($id, 'rank_math_description', $copy->post_excerpt);
        }
        kses_remove_filters();
        $r = wp_update_post($arr, true);
        kses_init_filters();
        if (is_wp_error($r)) wp_die(esc_html($r->get_error_message()));

        $kw = (string) get_post_meta($copy_id, '_cap_keywords', true);
        if ($kw !== '') {
            $primary = trim(explode(',', $kw)[0]);
            if (defined('WPSEO_VERSION') && !get_post_meta($id, '_yoast_wpseo_focuskw', true)) update_post_meta($id, '_yoast_wpseo_focuskw', $primary);
            if (class_exists('RankMath') && !get_post_meta($id, 'rank_math_focus_keyword', true)) update_post_meta($id, 'rank_math_focus_keyword', $kw);
        }
        update_post_meta($id, '_cap_last_optimised', ['date' => current_time('mysql'), 'score' => get_post_meta($copy_id, '_cap_qa_score', true), 'report' => $copy_id]);
        update_post_meta($id, '_cap_process', wp_slash((string) get_post_meta($copy_id, '_cap_process', true)));
        delete_post_meta($id, '_cap_audit');
        delete_post_meta($id, '_cap_opt_copy');
        wp_trash_post($copy_id);
        self::log('Optimised version applied to "' . get_the_title($id) . '" (ID ' . $id . '). Previous version saved in Revisions.');
        wp_safe_redirect(add_query_arg('cap_opt', 'applied', get_edit_post_link($id, 'raw')));
        exit;
    }

    public static function opt_admin_notice() {
        if (empty($_GET['cap_opt'])) return;
        $m = sanitize_key($_GET['cap_opt']);
        if ($m === 'applied') echo '<div class="notice notice-success is-dismissible"><p><strong>Optimised version applied.</strong> The previous version is saved in Revisions if you need to restore it.</p></div>';
        if ($m === 'discarded') echo '<div class="notice notice-info is-dismissible"><p>Optimised draft discarded. The page is unchanged.</p></div>';
    }

    /* ---------------------------------------------------------------
     * Background jobs: health check and direct-run fallback
     * ------------------------------------------------------------- */

    /** Oldest manual job still waiting for WP-Cron: [timestamp, args] or null. */
    private static function pending_manual() {
        $crons = function_exists('_get_cron_array') ? _get_cron_array() : [];
        $found = null;
        foreach ((array) $crons as $ts => $hooks) {
            if (empty($hooks[self::MANUAL_HOOK])) continue;
            foreach ($hooks[self::MANUAL_HOOK] as $event) {
                if (!$found || $ts < $found[0]) $found = [(int) $ts, (array) ($event['args'] ?? [])];
            }
        }
        return $found;
    }

    /** End the browser request now, then keep working in PHP (no WP-Cron or loopback needed). */
    private static function finish_request_and_continue($redirect) {
        ignore_user_abort(true);
        if (function_exists('set_time_limit')) @set_time_limit(0);
        if (session_status() === PHP_SESSION_ACTIVE) session_write_close();
        while (ob_get_level() > 0) @ob_end_clean();
        wp_safe_redirect($redirect);
        header('Content-Length: 0');
        header('Connection: close');
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        } elseif (function_exists('litespeed_finish_request')) {
            litespeed_finish_request();
        } else {
            flush();
        }
    }

    /** "Run it directly": takes a stuck queued job (or the next topic) and runs it without WP-Cron. */
    public static function handle_run_direct() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_run_direct');

        if (get_transient(self::LOCK)) {
            wp_safe_redirect(self::page_url(['tab' => 'dashboard', 'cap_msg' => 'gen_busy']));
            exit;
        }
        $pending = self::pending_manual();
        $args    = $pending ? $pending[1] : [];
        wp_unschedule_hook(self::MANUAL_HOOK);

        self::log('Running directly in the background (without WP-Cron). This takes a few minutes.');
        self::finish_request_and_continue(self::page_url(['tab' => 'dashboard', 'cap_msg' => 'gen_direct']));
        self::run($args[0] ?? '', $args[1] ?? '', $args[2] ?? '');
        exit;
    }

    /** Checks everything background generation depends on. */
    public static function handle_system_check() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_system_check');
        set_transient('cap_syscheck', self::system_check(), DAY_IN_SECONDS);
        wp_safe_redirect(self::page_url(['tab' => 'dashboard', 'cap_msg' => 'checked']) . '#cap-syscheck');
        exit;
    }

    private static function system_check() {
        $s   = self::settings();
        $out = ['time' => current_time('mysql'), 'rows' => []];
        $add = function ($label, $ok, $msg) use (&$out) { $out['rows'][] = [$label, $ok, $msg]; };

        list($kok, $kmsg) = self::test_key();
        $add('API key', $kok, $kmsg);
        $add('Topic queue', (bool) self::topics(), self::topics() ? count(self::topics()) . ' topics waiting.' : 'Empty. Add topics in Topics & Keywords.');

        $disabled = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
        $add('WP-Cron', $disabled ? 'warn' : true, $disabled
            ? 'Disabled in wp-config.php (DISABLE_WP_CRON). Jobs only run if a server cron calls wp-cron.php regularly.'
            : 'Enabled.');

        $resp = wp_remote_post(site_url('wp-cron.php'), [
            'timeout'   => 15,
            'blocking'  => true,
            'sslverify' => apply_filters('https_local_ssl_verify', false),
        ]);
        if (is_wp_error($resp)) {
            $add('Loopback request', false, 'The site cannot call itself: ' . $resp->get_error_message() . '. Background jobs cannot start. Ask your host to allow loopback requests, or use “Run it directly”.');
        } else {
            $code = (int) wp_remote_retrieve_response_code($resp);
            if ($code >= 200 && $code < 300) {
                $add('Loopback request', true, 'Works (HTTP ' . $code . ').');
            } elseif (in_array($code, [401, 403], true)) {
                $add('Loopback request', false, 'Blocked (HTTP ' . $code . '). Usually password protection, a firewall/security plugin, or Cloudflare blocking the site from calling itself. Whitelist wp-cron.php, or use “Run it directly”.');
            } else {
                $add('Loopback request', false, 'Returned HTTP ' . $code . '. Background jobs may not start. Use “Run it directly” and ask your host about loopback requests.');
            }
        }

        $last = (int) get_option('cap_last_run', 0);
        $add('Last background run', $last ? true : 'warn', $last ? 'Started ' . human_time_diff($last) . ' ago.' : 'No run has started on this site yet.');

        $pending = self::pending_manual();
        if ($pending && $pending[0] < time() - 120) {
            $add('Queued manual job', false, 'Waiting for ' . human_time_diff($pending[0]) . '. WP-Cron is not picking it up.');
        }

        $next = wp_next_scheduled(self::CRON_HOOK);
        $add('Schedule', $s['enabled'] ? ($next ? true : 'warn') : 'warn', $s['enabled']
            ? ($next ? 'Next scheduled run in ' . human_time_diff($next) . ($next < time() ? ' (overdue)' : '') . '.' : 'Enabled but nothing is scheduled. Save settings in General to reschedule.')
            : 'Automatic posting is off (manual runs only).');

        $add('Image drawing (GD)', CAP_Image::supported() ? true : 'warn', CAP_Image::supported()
            ? 'Available. Featured and body images can be created.'
            : 'PHP GD with FreeType is missing. Posts are still created, but without images. Ask your host to enable the GD extension.');
        $add('PHP time limit', true, ini_get('max_execution_time') ? ini_get('max_execution_time') . 's (the plugin asks for unlimited time while generating).' : 'Unlimited.');
        return $out;
    }

    public static function handle_generate_now() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('cap_generate_now');

        // The full pipeline takes several minutes, so it runs in the background instead of in this browser request.
        $lang = isset($_POST['cap_lang']) ? sanitize_key(wp_unslash($_POST['cap_lang'])) : '';
        $lang = isset(self::LANGUAGES[$lang]) ? $lang : '';
        $type = isset($_POST['cap_type']) ? sanitize_key(wp_unslash($_POST['cap_type'])) : '';
        $type = in_array($type, ['post', 'page'], true) ? $type : '';
        $geo  = isset($_POST['cap_geo']) ? sanitize_text_field(wp_unslash($_POST['cap_geo'])) : '';
        $geo  = (isset(self::GEOS[$geo]) || $geo === 'global') ? $geo : '';
        $args = ['tab' => 'dashboard'];
        if (get_transient(self::LOCK)) {
            $args['cap_msg'] = 'gen_busy';
        } elseif (self::pending_manual() || wp_schedule_single_event(time(), self::MANUAL_HOOK, [$lang, $type, $geo]) === false) {
            $args['cap_msg'] = 'gen_queued';
        } else {
            spawn_cron();
            $bits = array_filter([$type ? self::type_label($type) : '', $lang ? self::lang_label($lang) : '', $geo ? self::geo_label($geo === 'global' ? '' : $geo) : '']);
            self::log('Manual generation queued' . ($bits ? ' (' . implode(', ', $bits) . ')' : '') . '. It should start within a minute and takes a few minutes.');
            $args['cap_msg'] = 'gen_started';
        }
        wp_safe_redirect(self::page_url($args));
        exit;
    }

    /** Show "AI draft · QA 86" next to generated drafts in the Posts list. */
    public static function post_states($states, $post) {
        if ($o = (int) get_post_meta($post->ID, '_cap_optimises', true)) {
            $states['cap_opt'] = 'Optimised draft of “' . get_the_title($o) . '”';
            return $states;
        }
        if (!in_array($post->post_status, ['draft', 'pending'], true)) return $states;
        if (!get_post_meta($post->ID, '_cap_model', true)) return $states;
        $score = get_post_meta($post->ID, '_cap_qa_score', true);
        $states['cap_ai'] = 'AI draft' . ($score !== '' ? ' · QA ' . (int) $score : '');
        return $states;
    }

    /* ---------------------------------------------------------------
     * Process reports
     * ------------------------------------------------------------- */

    private static function get_report($post_id) {
        $r = json_decode((string) get_post_meta($post_id, '_cap_process', true), true);
        return is_array($r) ? $r : null;
    }

    private static function fmt_secs($s) {
        $s = (float) $s;
        return $s >= 60 ? floor($s / 60) . 'm ' . round(fmod($s, 60)) . 's' : round($s, 1) . 's';
    }

    private static function list_html($items) {
        if (!is_array($items) || !$items) return '<p class="cap-empty">None.</p>';
        $out = '<ul class="cap-list">';
        foreach ($items as $it) {
            $out .= '<li>' . esc_html(is_scalar($it) ? (string) $it : wp_json_encode($it, JSON_UNESCAPED_UNICODE)) . '</li>';
        }
        return $out . '</ul>';
    }

    private static function score_bar($score, $target) {
        $score = max(0, min(100, (int) $score));
        $kind  = $score >= $target ? '#1e7b34' : ($score >= $target - 10 ? '#b26200' : '#b32d2e');
        return '<div class="cap-score"><div class="cap-score-num" style="color:' . $kind . ';">' . $score . '<span>/100</span></div>'
             . '<div class="cap-score-track"><div class="cap-score-fill" style="width:' . $score . '%;background:' . $kind . ';"></div>'
             . '<div class="cap-score-target" style="left:' . (int) $target . '%;" title="Target ' . (int) $target . '"></div></div></div>';
    }

    private static function issues_table($issues) {
        if (!is_array($issues) || !$issues) return '<p class="cap-empty">No issues listed.</p>';
        $out = '<table class="widefat striped cap-issues"><thead><tr><th style="width:50%;">Problem</th><th>Fix requested</th></tr></thead><tbody>';
        foreach ($issues as $iss) {
            $out .= '<tr><td>' . esc_html($iss['problem'] ?? '') . '</td><td>' . esc_html($iss['fix'] ?? '') . '</td></tr>';
        }
        return $out . '</tbody></table>';
    }

    private static function version_box($snap, $lang) {
        if (empty($snap['content'])) return '';
        $dir = self::LANGUAGES[$lang][2] ?? 'ltr';
        return '<details class="cap-details"><summary>Read this version: “' . esc_html($snap['title']) . '” (' . esc_html(self::length_label($snap['words'] ?? 0, $lang)) . ')</summary>'
             . '<div class="cap-version" lang="' . esc_attr($lang) . '" dir="' . esc_attr($dir) . '">'
             . (!empty($snap['excerpt']) ? '<p class="cap-excerpt"><strong>Excerpt:</strong> ' . esc_html($snap['excerpt']) . '</p>' : '')
             . '<h1>' . esc_html($snap['title']) . '</h1>' . wp_kses_post($snap['content']) . '</div></details>';
    }

    /** The searches Claude ran and the ranking pages it looked at, shown on the brief stage. */
    private static function research_html($b) {
        $r = $b['_research'] ?? null;
        if (!is_array($r)) return '';
        $geo   = $b['_geo'] ?? '';
        $notes = [];
        foreach ((array) ($b['competitors_reviewed'] ?? []) as $c) {
            if (!is_array($c)) continue;
            $host = strtolower(preg_replace('/^www\./', '', (string) wp_parse_url($c['url'] ?? '', PHP_URL_HOST)));
            if (!empty($c['url'])) $notes['u:' . untrailingslashit($c['url'])] = $c;
            if ($host) $notes['h:' . $host] = $notes['h:' . $host] ?? $c;
        }

        $out  = '<div class="cap-research">';
        $out .= '<h4 style="margin-top:4px;">Competitor research · ' . esc_html($geo ? self::GEOS[$geo][0] . ' search results' : 'Global search results') . '</h4>';
        if (!empty($r['queries'])) {
            $out .= '<p style="margin:4px 0 10px;"><strong>Searches Claude ran:</strong> ';
            $out .= implode(' ', array_map(function ($q) { return '<span class="cap-badge cap-badge--muted">' . esc_html($q) . '</span>'; }, array_values(array_unique($r['queries']))));
            $out .= '</p>';
        }
        if (!empty($r['errors'])) {
            $out .= '<div class="notice notice-warning inline"><p>Some searches failed: ' . esc_html(implode(', ', array_unique($r['errors']))) . '</p></div>';
        }
        if (empty($r['results'])) {
            return $out . '<p class="cap-empty">No search results were recorded for this run.</p></div>';
        }
        $out .= '<table class="widefat striped cap-issues"><thead><tr><th style="width:36px;">#</th><th style="width:38%;">Page</th><th>Claude’s notes</th></tr></thead><tbody>';
        foreach ($r['results'] as $i => $res) {
            $host = strtolower(preg_replace('/^www\./', '', (string) wp_parse_url($res['url'], PHP_URL_HOST)));
            $n = $notes['u:' . untrailingslashit($res['url'])] ?? ($notes['h:' . $host] ?? null);
            $note = '';
            if ($n) {
                if (!empty($n['strengths'])) $note .= '<div><strong>Does well:</strong> ' . esc_html($n['strengths']) . '</div>';
                if (!empty($n['gaps']))      $note .= '<div><strong>Misses:</strong> ' . esc_html($n['gaps']) . '</div>';
            }
            $out .= '<tr><td>' . ($i + 1) . '</td><td><a href="' . esc_url($res['url']) . '" target="_blank" rel="noopener noreferrer"><strong>' . esc_html($res['title'] ?: $host) . '</strong></a>'
                  . '<div class="cap-note">' . esc_html($host) . ($res['query'] ? ' · result ' . (int) $res['position'] . ' for “' . esc_html($res['query']) . '”' : '') . ($res['age'] ? ' · ' . esc_html($res['age']) : '') . '</div></td>'
                  . '<td>' . ($note ?: '<span class="cap-note">Found in search; not singled out by Claude.</span>') . '</td></tr>';
        }
        $out .= '</tbody></table>';
        $out .= '<p class="cap-note" style="margin-top:6px;">Results come from the Claude API’s web search, localized to the selected market. Order is the order the search returned, which is close to but not identical to Google’s live ranking.</p>';
        return $out . '</div>';
    }

    private static function brief_html($b) {
        if (!is_array($b)) return '';
        $rows = [
            'Search intent' => $b['search_intent'] ?? '',
            'Audience'      => $b['audience'] ?? '',
            'Angle'         => $b['angle'] ?? '',
            'Primary keyword'    => $b['primary_keyword'] ?? '',
            'Secondary keywords' => is_array($b['secondary_keywords'] ?? null) ? implode(', ', $b['secondary_keywords']) : '',
        ];
        $out = '<table class="cap-kv">';
        foreach ($rows as $k => $v) {
            if ($v === '') continue;
            $out .= '<tr><th>' . esc_html($k) . '</th><td>' . esc_html(is_scalar($v) ? $v : wp_json_encode($v)) . '</td></tr>';
        }
        $out .= '</table>';

        if (!empty($b['outline']) && is_array($b['outline'])) {
            $out .= '<h4>Outline</h4><ol class="cap-outline">';
            foreach ($b['outline'] as $sec) {
                if (!is_array($sec)) { $out .= '<li>' . esc_html((string) $sec) . '</li>'; continue; }
                $out .= '<li><strong>' . esc_html($sec['h2'] ?? '') . '</strong>';
                if (!empty($sec['notes'])) $out .= '<div class="cap-note">' . esc_html($sec['notes']) . '</div>';
                if (!empty($sec['h3']) && is_array($sec['h3'])) $out .= self::list_html($sec['h3']);
                $out .= '</li>';
            }
            $out .= '</ol>';
        }
        $out .= '<div class="cap-cols">';
        $out .= '<div><h4>Must cover</h4>' . self::list_html($b['must_cover'] ?? []) . '</div>';
        $out .= '<div><h4>FAQ questions</h4>' . self::list_html($b['faq'] ?? []) . '</div>';
        $out .= '<div><h4>Facts to handle carefully</h4>' . self::list_html($b['facts_to_handle_carefully'] ?? []) . '</div>';
        $out .= '</div>';
        if (!empty($b['competitor_notes'])) {
            $out .= '<h4>Competitor research notes</h4><p>' . esc_html(is_scalar($b['competitor_notes']) ? $b['competitor_notes'] : wp_json_encode($b['competitor_notes'])) . '</p>';
        }
        return $out;
    }

    /** One run's full report: header facts, pipeline strip and a stage-by-stage timeline. */
    private static function render_report($r, $post = null) {
        $lang   = $r['language'] ?? 'en';
        $target = (int) ($r['qa'] ?? 0);
        $stages = is_array($r['stages'] ?? null) ? $r['stages'] : [];
        $t      = $r['totals'] ?? [];
        $final_qa = null;
        foreach ($stages as $st) { if (($st['key'] ?? '') === 'qa' && is_array($st['data'])) $final_qa = $st['data']; }

        echo '<p><a href="' . esc_url(self::page_url(['tab' => 'reports'])) . '">&larr; All process reports</a></p>';

        echo '<div class="cap-card">';
        if ($post) {
            $st = get_post_status_object($post->post_status);
            echo '<div class="cap-report-head"><div><h2 style="font-size:18px;margin:0 0 6px;">' . esc_html(get_the_title($post)) . '</h2>'
               . self::badge($st ? $st->label : $post->post_status, $post->post_status === 'publish' ? 'ok' : 'info') . ' '
               . ($final_qa ? self::badge('QA ' . (int) $final_qa['score'] . '/100', $final_qa['score'] >= $target ? 'ok' : 'warn') : '')
               . '</div><div class="cap-inline-form">'
               . '<a class="button button-primary" href="' . esc_url(admin_url('post.php?post=' . $post->ID . '&action=edit')) . '">Edit post</a>'
               . '<a class="button" target="_blank" href="' . esc_url(get_preview_post_link($post)) . '">Preview</a></div></div>';
        } else {
            echo '<h2 style="font-size:18px;margin:0 0 6px;">Failed run</h2>' . self::badge('No post created', 'err');
            if (!empty($r['error'])) echo '<div class="notice notice-error inline" style="margin-top:12px;"><p>' . esc_html($r['error']) . '</p></div>';
        }

        $facts = [
            'Topic'        => $r['topic'] ?? '',
            'Keywords'     => !empty($r['keywords']) ? implode(', ', (array) $r['keywords']) : '(chosen by Claude)',
            'Type'         => self::type_label($r['type'] ?? ($post ? $post->post_type : 'post')),
            'Language'     => self::lang_label($lang),
            'Market'       => self::geo_label($r['geo'] ?? ''),
            'Model'        => $r['model'] ?? '',
            'Target length'=> isset($r['words']) ? number_format((int) $r['words']) . ' words' : '',
            'Started'      => $r['started'] ?? '',
            'Total time'   => isset($r['seconds']) ? self::fmt_secs($r['seconds']) : '',
            'API calls'    => (int) ($t['calls'] ?? 0),
            'Tokens'       => number_format((int) ($t['in'] ?? 0)) . ' in / ' . number_format((int) ($t['out'] ?? 0)) . ' out',
            'Web searches' => (int) ($t['searches'] ?? 0),
        ];
        echo '<div class="cap-facts">';
        foreach ($facts as $k => $v) {
            echo '<div><div class="lbl">' . esc_html($k) . '</div><div class="v">' . esc_html((string) $v) . '</div></div>';
        }
        echo '</div>';

        // Pipeline strip
        echo '<div class="cap-steps" style="margin-top:16px;">';
        foreach ($stages as $i => $st) {
            if ($i) echo '<span class="cap-arrow">→</span>';
            $cls = ($st['status'] ?? 'ok') === 'fail' ? 'is-fail' : (($st['status'] ?? 'ok') === 'warn' ? 'is-warn' : 'is-on');
            echo '<a class="cap-step ' . $cls . '" href="#cap-stage-' . (int) $i . '">' . esc_html($st['label'] ?? '') . '</a>';
        }
        echo '</div></div>';

        // Timeline
        echo '<div class="cap-timeline">';
        foreach ($stages as $i => $st) {
            $status = $st['status'] ?? 'ok';
            $b = $status === 'fail' ? self::badge('Failed', 'err') : ($status === 'warn' ? self::badge('Needs attention', 'warn') : self::badge('Done', 'ok'));
            $meta = [self::fmt_secs($st['seconds'] ?? 0)];
            if (!empty($st['calls'])) $meta[] = (int) $st['calls'] . ' API call' . ($st['calls'] > 1 ? 's' : '');
            if (!empty($st['in']) || !empty($st['out'])) $meta[] = number_format((int) $st['in']) . ' in / ' . number_format((int) $st['out']) . ' out tokens';
            if (!empty($st['searches'])) $meta[] = (int) $st['searches'] . ' web search' . ($st['searches'] > 1 ? 'es' : '');

            echo '<div class="cap-card cap-stage cap-stage--' . esc_attr($status) . '" id="cap-stage-' . (int) $i . '">';
            echo '<div class="cap-stage-head"><span class="cap-stage-num">' . ($i + 1) . '</span><div style="flex:1;"><h3>' . esc_html($st['label'] ?? '') . ' ' . $b . '</h3>'
               . '<div class="cap-stage-meta">' . esc_html(implode(' · ', $meta)) . '</div></div></div>';
            echo '<p class="cap-stage-summary">' . esc_html($st['summary'] ?? '') . '</p>';

            $map = ['brief' => 'brief', 'draft' => 'draft', 'edit' => 'edit', 'rewrite' => 'edit', 'qa' => 'qa'];
            $plan = $r['docs'] ?? [];
            if (isset($map[$st['key'] ?? '']) && (!empty($plan[$map[$st['key']]]) || !empty($plan['reference']))) {
                $used = array_merge((array) ($plan[$map[$st['key']]] ?? []), array_map(function ($t) { return $t . ' (reference)'; }, (array) ($plan['reference'] ?? [])));
                echo '<p class="cap-note" style="margin:-2px 0 6px;"><strong>SOPs applied:</strong> ' . esc_html(implode(' · ', $used)) . '</p>';
            }
            $d = $st['data'] ?? null;
            switch ($st['key'] ?? '') {
                case 'brief':
                    if ($d) {
                        echo self::research_html($d);
                        echo '<details class="cap-details"><summary>View the brief and outline</summary><div class="cap-details-body">' . self::brief_html($d) . '</div></details>';
                    }
                    break;
                case 'qa':
                    if (is_array($d)) {
                        echo self::score_bar($d['score'] ?? 0, $target);
                        if (!empty($d['summary'])) echo '<p><em>' . esc_html($d['summary']) . '</em></p>';
                        echo '<details class="cap-details"' . (count($stages) < 8 ? ' open' : '') . '><summary>Issues found (' . count((array) ($d['issues'] ?? [])) . ')</summary><div class="cap-details-body">' . self::issues_table($d['issues'] ?? []) . '</div></details>';
                    }
                    break;
                case 'images':
                    if (is_array($d)) {
                        echo '<div class="cap-cols" style="margin-top:8px;">';
                        foreach (['featured' => 'Featured image', 'body' => 'Image in the article'] as $k => $lbl) {
                            if (empty($d[$k]['id'])) continue;
                            $edit = admin_url('post.php?post=' . (int) $d[$k]['id'] . '&action=edit');
                            echo '<div><h4 style="margin:0 0 6px;">' . esc_html($lbl) . '</h4>'
                               . '<a href="' . esc_url($edit) . '"><img src="' . esc_url(wp_get_attachment_image_url((int) $d[$k]['id'], 'medium_large') ?: $d[$k]['url']) . '" style="width:100%;max-width:520px;border-radius:6px;border:1px solid #dcdcde;" alt=""></a>'
                               . '<div class="cap-note">Illustration: ' . esc_html($d[$k]['motif'] ?? '') . ($k === 'body' ? ' · placed after section ' . (int) ($d[$k]['after_h2'] ?? 1) : '') . '</div></div>';
                        }
                        echo '</div>';
                    }
                    break;
                case 'draft':
                case 'edit':
                case 'rewrite':
                    if (is_array($d)) {
                        if (!empty($d['instructions'])) {
                            echo '<details class="cap-details"><summary>What this rewrite was asked to fix</summary><div class="cap-details-body">' . self::issues_table($d['instructions']) . '</div></details>';
                        }
                        echo self::version_box($d, $lang);
                    }
                    break;
            }
            echo '</div>';
        }
        echo '</div>';
    }

    /** Reports tab: list of runs, or one run's detail. */
    private static function render_reports_tab($s) {
        $id = isset($_GET['report']) ? sanitize_key($_GET['report']) : '';

        if ($id === 'failed') {
            $r = get_option(self::OPT_LASTFAIL);
            if (is_array($r)) { self::render_report($r); return; }
        } elseif ($id !== '' && ctype_digit($id)) {
            $post = get_post((int) $id);
            if ($post) {
                $r = self::get_report($post->ID);
                if ($r) { self::render_report($r, $post); return; }
                // Posts made before reports existed: show what was saved.
                echo '<p><a href="' . esc_url(self::page_url(['tab' => 'reports'])) . '">&larr; All process reports</a></p>';
                echo '<div class="cap-card"><h2>' . esc_html(get_the_title($post)) . '</h2><p class="cap-sub">This post was generated before process reports were added, so only the brief and final QA result were saved.</p>';
                $brief = json_decode((string) get_post_meta($post->ID, '_cap_brief', true), true);
                $qa    = json_decode((string) get_post_meta($post->ID, '_cap_qa_report', true), true);
                if ($brief) echo '<h3>Brief</h3>' . self::brief_html($brief);
                if ($qa)    echo '<h3>Final QA</h3>' . self::score_bar($qa['score'] ?? 0, (int) $s['qa_threshold']) . self::issues_table($qa['issues'] ?? []);
                if (!$brief && !$qa) echo '<p class="cap-empty">No details available.</p>';
                echo '</div>';
                return;
            }
        }

        $posts = get_posts([
            'post_type'   => ['post', 'page'],
            'post_status' => ['draft', 'pending', 'publish', 'future', 'private'],
            'numberposts' => 30,
            'meta_key'    => '_cap_model',
            'orderby'     => 'date',
            'order'       => 'DESC',
        ]);
        $fail = get_option(self::OPT_LASTFAIL);

        echo '<div class="cap-card"><h2>Process reports</h2><p class="cap-sub">How Claude produced each post: the brief, every version of the article, each QA score and what was fixed. Open a report to review it step by step.</p>';

        if (is_array($fail)) {
            echo '<div class="notice notice-warning inline" style="margin:0 0 12px;"><p><strong>Last failed run:</strong> ' . esc_html($fail['topic'] ?? '') . ' (' . esc_html($fail['finished'] ?? '') . '). '
               . '<a href="' . esc_url(self::page_url(['tab' => 'reports', 'report' => 'failed'])) . '">See where it stopped</a></p></div>';
        }

        if (!$posts) {
            echo '<p class="cap-empty">No generated posts yet.</p></div>';
            return;
        }
        echo '<table class="widefat striped cap-table"><thead><tr><th>Post / page</th><th style="width:120px;">Created</th><th style="width:90px;">Language</th><th style="width:100px;">QA</th><th style="width:80px;">Rewrites</th><th style="width:80px;">Time</th><th style="width:150px;">Tokens (in / out)</th><th style="width:110px;"></th></tr></thead><tbody>';
        foreach ($posts as $p) {
            $r    = self::get_report($p->ID);
            $sc   = get_post_meta($p->ID, '_cap_qa_score', true);
            $pass = (int) get_post_meta($p->ID, '_cap_qa_passed', true);
            $lang = get_post_meta($p->ID, '_cap_language', true) ?: 'en';
            echo '<tr>'
               . '<td><strong><a href="' . esc_url(self::page_url(['tab' => 'reports', 'report' => $p->ID])) . '">' . esc_html(get_the_title($p) ?: '(no title)') . '</a></strong>' . ($p->post_type === 'page' ? ' ' . self::badge('Page', 'muted') : '') . '</td>'
               . '<td>' . esc_html(get_the_date('M j, H:i', $p)) . '</td>'
               . '<td>' . esc_html(self::lang_label($lang)) . '</td>'
               . '<td>' . ($sc === '' ? self::badge('n/a') : self::badge($sc . '/100', $pass ? 'ok' : 'warn')) . '</td>'
               . '<td>' . (int) get_post_meta($p->ID, '_cap_rewrites', true) . '</td>'
               . '<td>' . ($r ? esc_html(self::fmt_secs($r['seconds'] ?? 0)) : '—') . '</td>'
               . '<td>' . ($r ? esc_html(number_format((int) ($r['totals']['in'] ?? 0)) . ' / ' . number_format((int) ($r['totals']['out'] ?? 0))) : '—') . '</td>'
               . '<td><a class="button button-small" href="' . esc_url(self::page_url(['tab' => 'reports', 'report' => $p->ID])) . '">View process</a></td>'
               . '</tr>';
        }
        echo '</tbody></table></div>';
    }

    /** Sidebar box on the post editor so the reviewing editor sees how the post was made. */
    public static function add_meta_boxes($post_type, $post) {
        if (!in_array($post_type, ['post', 'page'], true) || !$post || !get_post_meta($post->ID, '_cap_model', true)) return;
        add_meta_box('cap_process', 'AI generation process', [__CLASS__, 'render_meta_box'], $post_type, 'side', 'high');
    }

    public static function render_meta_box($post) {
        $r  = self::get_report($post->ID);
        $sc = get_post_meta($post->ID, '_cap_qa_score', true);
        $pass = (int) get_post_meta($post->ID, '_cap_qa_passed', true);
        $kw = get_post_meta($post->ID, '_cap_keywords', true);

        echo '<style>.cap-mb ul{margin:8px 0 0;} .cap-mb li{margin:0 0 6px;padding-left:18px;position:relative;} .cap-mb li:before{position:absolute;left:0;font-weight:700;}
              .cap-mb li.ok:before{content:"✓";color:#1e7b34;} .cap-mb li.warn:before{content:"!";color:#b26200;} .cap-mb li.fail:before{content:"✕";color:#b32d2e;}
              .cap-mb .score{font-size:20px;font-weight:600;} .cap-mb .muted{color:#646970;}</style><div class="cap-mb">';
        if ($sc !== '') {
            echo '<div><span class="score" style="color:' . ($pass ? '#1e7b34' : '#b26200') . ';">' . (int) $sc . '/100</span> <span class="muted">QA score' . ($pass ? ', passed' : ', below target') . '</span></div>';
        }
        if ($kw) echo '<p class="muted" style="margin:6px 0 0;">Keywords: ' . esc_html($kw) . '</p>';

        if ($r && !empty($r['stages'])) {
            echo '<ul>';
            foreach ($r['stages'] as $st) {
                echo '<li class="' . esc_attr($st['status'] ?? 'ok') . '"><strong>' . esc_html($st['label'] ?? '') . '</strong><br><span class="muted">' . esc_html($st['summary'] ?? '') . '</span></li>';
            }
            echo '</ul>';
        }

        if ($sc !== '' && !$pass) {
            $qa = json_decode((string) get_post_meta($post->ID, '_cap_qa_report', true), true);
            if (!empty($qa['issues'])) {
                echo '<p style="margin:10px 0 4px;"><strong>Still flagged by QA:</strong></p><ul>';
                foreach (array_slice($qa['issues'], 0, 6) as $iss) echo '<li class="warn">' . esc_html($iss['problem'] ?? '') . '</li>';
                echo '</ul>';
            }
        }
        if (current_user_can('manage_options')) {
            echo '<p style="margin:10px 0 0;"><a href="' . esc_url(self::page_url(['tab' => 'reports', 'report' => $post->ID])) . '">View the full process report &rarr;</a></p>';
        }
        echo '</div>';
    }

    private static function page_url($args = []) {
        return add_query_arg(array_merge(['page' => 'claude-auto-poster'], $args), admin_url('admin.php'));
    }

    private static function badge($text, $kind = 'muted') {
        return '<span class="cap-badge cap-badge--' . esc_attr($kind) . '">' . esc_html($text) . '</span>';
    }

    public static function render_page() {
        if (!current_user_can('manage_options')) return;

        $s        = self::settings();
        $topics   = self::topics();
        $kw_lines = self::keywords();
        $log      = get_option(self::OPT_LOG, []);
        $next     = wp_next_scheduled(self::CRON_HOOK);
        $running  = (bool) get_transient(self::LOCK);
        $keyFromConfig = (bool) self::key_constant();
        $opt      = self::OPT_SETTINGS;
        $ver      = get_file_data(__FILE__, ['v' => 'Version'])['v'];

        $tabs = [
            'dashboard'     => 'Dashboard',
            'queue'         => 'Topics & Keywords',
            'reports'       => 'Process Reports',
            'general'       => 'General',
            'quality'       => 'Quality Pipeline',
            'images'        => 'Images',
            'notifications' => 'Notifications',
        ];
        $tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'dashboard';
        if (!isset($tabs[$tab])) $tab = 'dashboard';
        $settings_tabs = 'general quality images notifications';

        $recent = get_posts([
            'post_type'   => ['post', 'page'],
            'post_status' => ['draft', 'pending', 'publish', 'future'],
            'numberposts' => 8,
            'meta_key'    => '_cap_model',
            'orderby'     => 'date',
            'order'       => 'DESC',
        ]);
        $scores = [];
        foreach ($recent as $p) {
            $sc = get_post_meta($p->ID, '_cap_qa_score', true);
            if ($sc !== '') $scores[] = (int) $sc;
        }
        $avg = $scores ? round(array_sum($scores) / count($scores)) : null;

        $missing = 0;
        foreach ($topics as $i => $t) { if (trim($kw_lines[$i] ?? '') === '') $missing++; }
        ?>
        <style>
            .cap-wrap { max-width: 1180px; }
            .cap-header { display:flex; align-items:center; justify-content:space-between; flex-wrap:wrap; gap:12px; margin:18px 0 8px; }
            .cap-header h1 { display:flex; align-items:center; gap:10px; margin:0; padding:0; font-size:23px; font-weight:600; }
            .cap-header h1 .dashicons { font-size:28px; width:28px; height:28px; color:#2271b1; }
            .cap-version { font-size:12px; font-weight:500; color:#646970; background:#f0f0f1; border-radius:10px; padding:2px 8px; }
            .cap-tabs.nav-tab-wrapper { margin-top:12px; }
            .cap-panel { display:none; }
            .cap-panel.is-active { display:block; }
            .cap-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:20px 24px; margin-top:16px; box-shadow:0 1px 2px rgba(0,0,0,.04); }
            .cap-card > h2 { margin:0 0 4px; font-size:15px; font-weight:600; }
            .cap-card > .cap-sub { margin:0 0 12px; color:#646970; }
            .cap-card .form-table { margin-top:0; }
            .cap-card .form-table th { width:210px; padding-left:0; }
            .cap-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(200px, 1fr)); gap:12px; margin-top:16px; }
            .cap-stat { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px 18px; }
            .cap-stat .lbl { font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:#646970; }
            .cap-stat .val { font-size:22px; font-weight:600; margin-top:6px; line-height:1.2; }
            .cap-stat .sub { color:#646970; margin-top:4px; font-size:12px; }
            .cap-badge { display:inline-block; font-size:11px; font-weight:600; line-height:1; padding:5px 8px; border-radius:10px; white-space:nowrap; }
            .cap-badge--ok { background:#e6f4ea; color:#1e7b34; }
            .cap-badge--warn { background:#fcf0d9; color:#8a5a00; }
            .cap-badge--err { background:#fbe7e7; color:#b32d2e; }
            .cap-badge--info { background:#e5f0fa; color:#135e96; }
            .cap-badge--muted { background:#f0f0f1; color:#50575e; }
            .cap-pulse { display:inline-block; width:8px; height:8px; border-radius:50%; background:#2271b1; margin-right:6px; animation:capPulse 1.2s infinite ease-in-out; vertical-align:middle; }
            @keyframes capPulse { 0%,100% { opacity:.3; } 50% { opacity:1; } }
            .cap-steps { display:flex; flex-wrap:wrap; align-items:center; gap:6px; margin:6px 0 4px; }
            .cap-step { border:1px solid #dcdcde; border-radius:6px; padding:6px 10px; font-weight:500; background:#f6f7f7; }
            .cap-step.is-on { background:#e5f0fa; border-color:#9ec2e6; color:#135e96; }
            .cap-step.is-off { color:#a7aaad; text-decoration:line-through; }
            .cap-arrow { color:#a7aaad; }
            .cap-queue { display:flex; gap:16px; flex-wrap:wrap; }
            .cap-queue > div { flex:1 1 400px; }
            .cap-queue label { display:block; font-weight:600; margin-bottom:6px; }
            .cap-queue textarea { width:100%; font-family:Consolas, Monaco, monospace; font-size:13px; line-height:1.6; }
            .cap-inline-form { display:flex; align-items:center; flex-wrap:wrap; gap:10px; }
            .cap-table { border-radius:6px; overflow:hidden; }
            .cap-table td, .cap-table th { vertical-align:middle; }
            .cap-log { max-height:420px; overflow:auto; border:1px solid #dcdcde; border-radius:6px; }
            .cap-log table { border:0; }
            .cap-savebar { position:sticky; bottom:0; z-index:5; background:rgba(240,240,241,.95); border-top:1px solid #dcdcde; padding:12px 0; margin-top:16px; }
            .cap-savebar .button { margin:0; }
            .cap-empty { color:#646970; font-style:italic; margin:4px 0; }
            .cap-q-head { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; margin-bottom:14px; }
            .cap-q-head h2 { display:flex; align-items:center; gap:8px; }
            .cap-q-bulk { background:#f6f7f7; border:1px solid #dcdcde; border-radius:8px; padding:14px 16px; margin-bottom:14px; }
            .cap-q-wrap { border:1px solid #dcdcde; border-radius:8px; overflow-x:auto; }
            .cap-q-table { width:100%; border-collapse:collapse; min-width:860px; }
            .cap-q-table th { text-align:left; font-weight:600; padding:10px 8px; background:#f6f7f7; border-bottom:1px solid #dcdcde; white-space:nowrap; }
            .cap-q-table td { padding:6px 8px; border-bottom:1px solid #f0f0f1; vertical-align:middle; }
            .cap-q-table tr:last-child td { border-bottom:0; }
            .cap-q-table input[type=text], .cap-q-table select, .cap-q-table input[type=number] { width:100%; max-width:none; min-height:34px; }
            .cap-q-table td:nth-child(2) { width:34%; }
            .cap-q-n { width:54px; color:#646970; text-align:center; }
            .cap-q-n em { display:none; font-style:normal; font-size:10px; font-weight:600; text-transform:uppercase; color:#1e7b34; background:#e6f4ea; border-radius:8px; padding:1px 5px; margin-top:2px; }
            .cap-q-table tr.is-next td { background:#fbfdfb; }
            .cap-q-table tr.is-next .cap-q-n em { display:inline-block; }
            .cap-q-type { width:120px; }
            .cap-q-words { width:96px; }
            .cap-q-act { width:86px; white-space:nowrap; text-align:right; }
            .cap-q-act .button-link { text-decoration:none; color:#50575e; padding:2px 4px; font-size:13px; }
            .cap-q-act .button-link:hover { color:#2271b1; }
            .cap-q-act .cap-q-del:hover { color:#b32d2e; }
            .cap-q-table select:invalid { color:#b32d2e; border-color:#d63638; }
            .cap-req { color:#d63638; }
            .cap-q-foot { display:flex; align-items:center; gap:12px; margin-top:14px; }
            #cap-q-dirty { color:#b26200; font-weight:500; }
            .cap-dropzone { display:flex; align-items:center; gap:14px; flex-wrap:wrap; border:2px dashed #c3c4c7; border-radius:8px; padding:14px 16px; background:#f9f9f9; margin-top:12px; }
            .cap-dropzone > div { flex:1 1 320px; }
            .cap-dropzone .dashicons { font-size:28px; width:28px; height:28px; color:#2271b1; }
            .cap-doc-table td { vertical-align:top; }
            .cap-doc-off td { opacity:.55; }
            .cap-doc-off td:first-child { opacity:1; }
            .cap-stage-checks label { display:inline-block; margin:0 10px 4px 0; white-space:nowrap; }
            .cap-row-actions { white-space:nowrap; }
            .cap-report-head { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; }
            .cap-facts { display:grid; grid-template-columns:repeat(auto-fit, minmax(170px, 1fr)); gap:10px 18px; margin-top:16px; padding-top:14px; border-top:1px solid #f0f0f1; }
            .cap-facts .lbl { font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:#646970; }
            .cap-facts .v { margin-top:3px; font-weight:500; word-break:break-word; }
            a.cap-step { text-decoration:none; }
            .cap-step.is-warn { background:#fcf0d9; border-color:#f0c36d; color:#8a5a00; }
            .cap-step.is-fail { background:#fbe7e7; border-color:#e6a2a2; color:#b32d2e; }
            .cap-timeline { position:relative; margin-left:14px; padding-left:22px; border-left:2px solid #dcdcde; }
            .cap-stage { position:relative; }
            .cap-stage-head { display:flex; gap:12px; align-items:flex-start; }
            .cap-stage-head h3 { margin:2px 0 2px; font-size:14px; display:flex; align-items:center; gap:8px; flex-wrap:wrap; }
            .cap-stage-num { position:absolute; left:-38px; top:18px; width:28px; height:28px; border-radius:50%; background:#2271b1; color:#fff; font-weight:600; display:flex; align-items:center; justify-content:center; box-shadow:0 0 0 4px #f0f0f1; }
            .cap-stage--warn .cap-stage-num { background:#b26200; }
            .cap-stage--fail .cap-stage-num { background:#b32d2e; }
            .cap-stage-meta { color:#646970; font-size:12px; }
            .cap-stage-summary { margin:10px 0 6px; font-size:13px; }
            .cap-details { margin-top:10px; border:1px solid #dcdcde; border-radius:6px; background:#f9f9f9; }
            .cap-details > summary { cursor:pointer; padding:9px 12px; font-weight:500; }
            .cap-details[open] > summary { border-bottom:1px solid #dcdcde; }
            .cap-details-body { padding:12px 14px; background:#fff; border-radius:0 0 6px 6px; }
            .cap-version { max-height:520px; overflow:auto; padding:16px 22px; background:#fff; font-size:14px; line-height:1.65; border-radius:0 0 6px 6px; }
            .cap-version h1 { font-size:22px; margin:0 0 12px; }
            .cap-version table { border-collapse:collapse; } .cap-version td, .cap-version th { border:1px solid #dcdcde; padding:6px 8px; }
            .cap-excerpt { background:#f6f7f7; padding:8px 10px; border-radius:4px; }
            .cap-score { display:flex; align-items:center; gap:14px; margin:8px 0; }
            .cap-score-num { font-size:26px; font-weight:700; min-width:90px; } .cap-score-num span { font-size:13px; color:#646970; font-weight:500; }
            .cap-score-track { position:relative; flex:1; max-width:420px; height:10px; background:#f0f0f1; border-radius:6px; }
            .cap-score-fill { height:100%; border-radius:6px; }
            .cap-score-target { position:absolute; top:-4px; width:2px; height:18px; background:#1d2327; }
            .cap-kv { border-collapse:collapse; margin-bottom:8px; } .cap-kv th { text-align:left; color:#646970; font-weight:500; padding:4px 16px 4px 0; vertical-align:top; white-space:nowrap; } .cap-kv td { padding:4px 0; }
            .cap-outline > li { margin-bottom:8px; } .cap-note { color:#646970; font-size:12px; }
            .cap-list { list-style:disc; margin:4px 0 0 18px; }
            .cap-cols { display:grid; grid-template-columns:repeat(auto-fit, minmax(220px, 1fr)); gap:16px; }
            .cap-details-body h4 { margin:14px 0 6px; }
            .cap-issues td { vertical-align:top; }
            .cap-research { margin-top:8px; }
            .cap-research .cap-badge { margin:0 4px 4px 0; }
        </style>

        <div class="wrap cap-wrap">
            <div class="cap-header">
                <h1><span class="dashicons dashicons-edit-page"></span>Claude Auto Poster <span class="cap-version">v<?php echo esc_html($ver); ?></span></h1>
                <div>
                    <?php
                    if ($running) {
                        echo '<span class="cap-badge cap-badge--info"><span class="cap-pulse"></span>Generating a post</span> ';
                    }
                    echo $s['enabled'] ? self::badge('Schedule on', 'ok') : self::badge('Schedule off', 'muted');
                    ?>
                </div>
            </div>

            <?php
            settings_errors();
            if (isset($_GET['cap_msg'])) {
                $m = sanitize_key($_GET['cap_msg']);
                $notices = [
                    'topics_saved' => ['success', 'Queue saved.'],
                    'topics_typefix' => ['warning', 'Queue saved. Some topics had no type, so they were set to Post. Please check them.'],
                    'mail_ok'      => ['success', 'Test email handed to the mail server. Check the inboxes (and spam).'],
                    'mail_failed'  => ['error',   'Test email failed to send. See the activity log on the Dashboard.'],
                    'gen_started'  => ['success', 'Generation started in the background. It takes a few minutes; refresh this page to follow progress. The editor email goes out when the draft is ready.'],
                    'gen_busy'     => ['warning', 'A post is already being generated. Wait for it to finish, then try again.'],
                    'gen_queued'   => ['warning', 'A generation is already queued and waiting to start. If it does not start within a couple of minutes, use “Run it directly” on the Dashboard.'],
                    'gen_direct'   => ['success', 'Running directly in the background. Refresh in a minute: the header will show “Generating a post”, and the editor email goes out when the draft is ready.'],
                    'checked'      => ['success', 'System check finished. See the results on the Dashboard.'],
                    'docs_saved'   => ['success', 'SOP library settings saved.'],
                    'doc_saved'    => ['success', 'Document saved.'],
                    'doc_reverted' => ['success', 'Document restored to the uploaded version.'],
                    'doc_deleted'  => ['success', 'Document deleted from the library.'],
                ];
                if (isset($notices[$m])) {
                    printf('<div class="notice notice-%s is-dismissible"><p>%s</p></div>', esc_attr($notices[$m][0]), esc_html($notices[$m][1]));
                }
            }
            ?>

            <nav class="nav-tab-wrapper cap-tabs" data-initial="<?php echo esc_attr($tab); ?>">
                <?php foreach ($tabs as $key => $label) : ?>
                    <a href="<?php echo esc_url(self::page_url(['tab' => $key])); ?>" data-tab="<?php echo esc_attr($key); ?>"
                       class="nav-tab<?php echo $key === $tab ? ' nav-tab-active' : ''; ?>"><?php echo esc_html($label); ?></a>
                <?php endforeach; ?>
            </nav>

            <!-- ============ DASHBOARD ============ -->
            <div class="cap-panel<?php echo $tab === 'dashboard' ? ' is-active' : ''; ?>" data-tab-panel="dashboard">
                <div class="cap-grid">
                    <div class="cap-stat">
                        <div class="lbl">Schedule</div>
                        <div class="val"><?php echo $s['enabled'] ? 'On' : 'Off'; ?></div>
                        <div class="sub"><?php echo (int) $s['posts_per_day']; ?> posts per day · <?php echo esc_html(self::lang_label($s['language'])); ?></div>
                    </div>
                    <div class="cap-stat">
                        <div class="lbl">Topics queued</div>
                        <div class="val"><?php echo count($topics); ?></div>
                        <div class="sub">~<?php echo $s['posts_per_day'] ? round(count($topics) / $s['posts_per_day'], 1) : 0; ?> days of content<?php echo $missing ? ' · ' . (int) $missing . ' without keywords' : ''; ?></div>
                    </div>
                    <div class="cap-stat">
                        <div class="lbl">Next run</div>
                        <div class="val"><?php echo $next ? esc_html(get_date_from_gmt(gmdate('Y-m-d H:i:s', $next), 'H:i')) : '—'; ?></div>
                        <div class="sub"><?php echo $next ? esc_html(get_date_from_gmt(gmdate('Y-m-d H:i:s', $next), 'D, M j')) : ($s['enabled'] ? 'Waiting for WP-Cron' : 'Scheduling is off'); ?></div>
                    </div>
                    <div class="cap-stat">
                        <div class="lbl">Avg. QA score</div>
                        <div class="val"><?php echo $avg !== null ? (int) $avg . '<span style="font-size:14px;color:#646970;">/100</span>' : '—'; ?></div>
                        <div class="sub">Last <?php echo count($scores); ?> scored posts · target <?php echo (int) $s['qa_threshold']; ?></div>
                    </div>
                </div>

                <?php $pending = self::pending_manual(); if ($pending && !$running && $pending[0] < time() - 90) : ?>
                    <div class="notice notice-error inline" style="margin:16px 0 0;"><p>
                        <strong>A queued post has been waiting <?php echo esc_html(human_time_diff($pending[0])); ?> and has not started.</strong>
                        This site’s WP-Cron is not running background jobs (common on new sites, password-protected sites, or behind a firewall).</p>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cap-inline-form" style="margin:0 0 10px;">
                            <input type="hidden" name="action" value="cap_run_direct">
                            <?php wp_nonce_field('cap_run_direct'); ?>
                            <?php submit_button('Run it directly', 'primary', 'submit', false); ?>
                            <span class="description">Runs the queued post now without WP-Cron. Then use “Run system check” below to find the cause.</span>
                        </form>
                    </div>
                <?php endif; ?>

                <div class="cap-card">
                    <h2>Generate a post now</h2>
                    <p class="cap-sub">Uses the next topic in the queue and runs the full pipeline in the background (a few minutes).</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cap-inline-form">
                        <input type="hidden" name="action" value="cap_generate_now">
                        <?php wp_nonce_field('cap_generate_now'); ?>
                        <label for="cap_geo_once">Market</label>
                        <select id="cap_geo_once" name="cap_geo">
                            <option value="">Default (topic tag or <?php echo esc_html($s['geo'] ? self::GEOS[$s['geo']][0] : 'Global'); ?>)</option>
                            <option value="global">Global</option>
                            <?php foreach (self::GEOS as $code => $g) : ?>
                                <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($g[0]); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <label for="cap_lang_once">Language</label>
                        <select id="cap_lang_once" name="cap_lang">
                            <option value="">Default (topic tag or <?php echo esc_html(self::lang_label($s['language'])); ?>)</option>
                            <?php foreach (self::LANGUAGES as $code => $l) : ?>
                                <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($l[0]); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php submit_button('Generate', 'primary', 'submit', false, (empty($topics) || $running) ? ['disabled' => 'disabled'] : []); ?>
                        <?php if ($topics) : ?>
                            <span class="description">Next topic: <strong><?php echo esc_html(mb_strimwidth($topics[0], 0, 80, '…')); ?></strong></span>
                        <?php else : ?>
                            <span class="description">The queue is empty. Add topics in the Topics &amp; Keywords tab.</span>
                        <?php endif; ?>
                    </form>
                </div>

                <div class="cap-card">
                    <h2>Recent AI posts &amp; pages</h2>
                    <?php if (!$recent) : ?>
                        <p class="cap-empty">No generated posts yet.</p>
                    <?php else : ?>
                        <table class="widefat striped cap-table">
                            <thead><tr><th>Title</th><th style="width:80px;">Type</th><th style="width:110px;">Language</th><th style="width:110px;">QA score</th><th style="width:110px;">Status</th><th style="width:130px;">Created</th><th style="width:110px;"></th></tr></thead>
                            <tbody>
                            <?php foreach ($recent as $p) :
                                $sc   = get_post_meta($p->ID, '_cap_qa_score', true);
                                $pass = (int) get_post_meta($p->ID, '_cap_qa_passed', true);
                                $lang = get_post_meta($p->ID, '_cap_language', true) ?: 'en';
                                $st   = get_post_status_object($p->post_status);
                                ?>
                                <tr>
                                    <td><strong><a href="<?php echo esc_url(admin_url('post.php?post=' . $p->ID . '&action=edit')); ?>"><?php echo esc_html(get_the_title($p) ?: '(no title)'); ?></a></strong></td>
                                    <td><?php echo esc_html(self::type_label($p->post_type)); ?></td>
                                    <td><?php echo esc_html(self::lang_label($lang)); ?></td>
                                    <td><?php echo $sc === '' ? self::badge('n/a') : self::badge($sc . '/100', $pass ? 'ok' : 'warn'); ?></td>
                                    <td><?php echo self::badge($st ? $st->label : $p->post_status, $p->post_status === 'publish' ? 'ok' : 'info'); ?></td>
                                    <td><?php echo esc_html(get_the_date('M j, H:i', $p)); ?></td>
                                    <td><a class="button button-small" href="<?php echo esc_url(self::page_url(['tab' => 'reports', 'report' => $p->ID])); ?>">View process</a></td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>

                <div class="cap-card" id="cap-syscheck">
                    <h2>System check</h2>
                    <p class="cap-sub">Checks everything background generation needs. Run it on a new site, or when posts stop appearing.</p>
                    <?php $chk = get_transient('cap_syscheck'); if ($chk) : ?>
                        <table class="widefat striped cap-table" style="margin-bottom:12px;">
                            <tbody>
                            <?php foreach ($chk['rows'] as $row) :
                                $state = $row[1] === true ? self::badge('OK', 'ok') : ($row[1] === 'warn' ? self::badge('Check', 'warn') : self::badge('Problem', 'err')); ?>
                                <tr><td style="width:180px;"><strong><?php echo esc_html($row[0]); ?></strong></td><td style="width:90px;"><?php echo $state; ?></td><td><?php echo esc_html($row[2]); ?></td></tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                        <p class="description" style="margin-top:0;">Last checked <?php echo esc_html($chk['time']); ?>.</p>
                    <?php endif; ?>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cap-inline-form">
                        <input type="hidden" name="action" value="cap_system_check">
                        <?php wp_nonce_field('cap_system_check'); ?>
                        <?php submit_button('Run system check', 'secondary', 'submit', false); ?>
                    </form>
                </div>

                <div class="cap-card">
                    <h2>Activity log</h2>
                    <p class="cap-sub">The last 30 events, newest first.</p>
                    <?php if (empty($log)) : ?>
                        <p class="cap-empty">No activity yet.</p>
                    <?php else : ?>
                        <div class="cap-log">
                            <table class="widefat striped">
                                <thead><tr><th style="width:160px;">Time</th><th style="width:90px;">Type</th><th>Message</th></tr></thead>
                                <tbody>
                                <?php foreach ($log as $row) :
                                    $type = $row['type'] ?? 'info';
                                    $b = $type === 'error' ? self::badge('Error', 'err') : ($type === 'warn' ? self::badge('Warning', 'warn') : self::badge('OK', 'ok'));
                                    ?>
                                    <tr>
                                        <td><?php echo esc_html($row['time']); ?></td>
                                        <td><?php echo $b; ?></td>
                                        <td><?php echo esc_html($row['message']); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- ============ TOPICS & KEYWORDS ============ -->
            <div class="cap-panel<?php echo $tab === 'queue' ? ' is-active' : ''; ?>" data-tab-panel="queue">
                <?php $rows = self::queue(); ?>
                <div class="cap-card">
                    <div class="cap-q-head">
                        <div>
                            <h2>Topic queue <span class="cap-badge cap-badge--muted"><?php echo count($rows); ?></span></h2>
                            <p class="cap-sub" style="margin:0;">Each run takes the top topic. A topic is removed from the queue once its draft is created. Type and word count are required for every topic.</p>
                        </div>
                        <div class="cap-inline-form">
                            <button type="button" class="button" id="cap-q-bulk-toggle">Bulk add</button>
                            <button type="button" class="button button-primary" id="cap-q-add">+ Add topic</button>
                        </div>
                    </div>

                    <div id="cap-q-bulk" class="cap-q-bulk" hidden>
                        <p style="margin-top:0;"><strong>Paste many topics at once.</strong> One per line. Add keywords after a <code>|</code> (or paste two columns from a spreadsheet):<br>
                            <code>Baccarat Rules and How to Play | baccarat rules, how to play baccarat</code></p>
                        <textarea id="cap-q-bulk-text" rows="6" class="large-text code" placeholder="Topic | primary keyword, secondary keyword"></textarea>
                        <div class="cap-inline-form" style="margin-top:8px;">
                            <label>Type <select id="cap-q-bulk-type"><option value="">Choose…</option><option value="post">Post</option><option value="page">Page</option></select></label>
                            <label>Words <input type="number" id="cap-q-bulk-words" min="300" max="5000" step="50" value="<?php echo (int) self::settings()['word_count']; ?>" class="small-text" style="width:80px;"></label>
                            <button type="button" class="button button-primary" id="cap-q-bulk-add">Add to queue</button>
                            <span class="description" id="cap-q-bulk-msg"></span>
                        </div>
                    </div>

                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="cap-q-form">
                        <input type="hidden" name="action" value="cap_save_topics">
                        <?php wp_nonce_field('cap_save_topics'); ?>
                        <div class="cap-q-wrap">
                            <table class="cap-q-table">
                                <thead><tr>
                                    <th class="cap-q-n">#</th>
                                    <th>Topic <span class="cap-req">*</span></th>
                                    <th class="cap-q-type">Type <span class="cap-req">*</span></th>
                                    <th class="cap-q-words">Words <span class="cap-req">*</span></th>
                                    <th>Keywords <span class="description">(primary first)</span></th>
                                    <th class="cap-q-act"></th>
                                </tr></thead>
                                <tbody id="cap-q-body">
                                <?php foreach ($rows as $row) self::queue_row_html($row); ?>
                                </tbody>
                            </table>
                            <p class="cap-empty" id="cap-q-empty"<?php echo $rows ? ' hidden' : ''; ?>>The queue is empty. Click “+ Add topic” or “Bulk add”.</p>
                        </div>
                        <template id="cap-q-tpl"><?php self::queue_row_html(['topic' => '', 'keywords' => '', 'type' => '', 'words' => (int) self::settings()['word_count']]); ?></template>

                        <div class="cap-q-foot">
                            <?php submit_button('Save queue', 'primary', 'submit', false); ?>
                            <span class="description" id="cap-q-dirty" hidden>Unsaved changes</span>
                        </div>
                    </form>

                    <details class="cap-details" style="margin-top:16px;">
                        <summary>Optional tags you can put at the start of a topic</summary>
                        <div class="cap-details-body">
                            <p style="margin-top:0;"><strong>Market:</strong> <?php echo implode(' ', array_map(function ($c, $g) { return '<code>[' . esc_html($c) . ']</code> ' . esc_html($g[0]); }, array_keys(self::GEOS), self::GEOS)); ?>. Without a tag, the default market from General is used.</p>
                            <p><strong>Language:</strong> <code>[es]</code> Spanish, <code>[fr]</code> French, <code>[zh]</code> Chinese, <code>[hi]</code> Hindi, <code>[ar]</code> Arabic. Without a tag, the article is in <?php echo esc_html(self::lang_label(self::settings()['language'])); ?>.</p>
                            <?php $dt = self::doc_tags(); if ($dt) : ?>
                                <p><strong>SOP tags</strong> (from the SOP library): <?php echo implode(' ', array_map(function ($t) { return '<code>[' . esc_html($t) . ']</code>'; }, $dt)); ?>, which select the SOP documents for that page type.</p>
                            <?php endif; ?>
                            <p style="margin-bottom:0;">Tags combine in any order, e.g. <code>[au] [review] Betway Casino Review</code>.</p>
                        </div>
                    </details>
                </div>
            </div>

            <script>
            (function () {
                var body = document.getElementById('cap-q-body');
                if (!body) return;
                var tpl = document.getElementById('cap-q-tpl'), form = document.getElementById('cap-q-form');
                var dirty = document.getElementById('cap-q-dirty'), empty = document.getElementById('cap-q-empty');

                function renumber() {
                    var rows = body.querySelectorAll('tr');
                    rows.forEach(function (tr, i) {
                        tr.querySelector('.cap-q-n span').textContent = i + 1;
                        tr.classList.toggle('is-next', i === 0);
                        tr.querySelectorAll('[data-f]').forEach(function (el) { el.name = 'rows[' + i + '][' + el.dataset.f + ']'; });
                    });
                    empty.hidden = rows.length > 0;
                }
                function changed() { dirty.hidden = false; }
                function addRow(v) {
                    var tr = tpl.content.firstElementChild.cloneNode(true);
                    if (v) {
                        tr.querySelector('[data-f="topic"]').value = v.topic || '';
                        tr.querySelector('[data-f="keywords"]').value = v.keywords || '';
                        if (v.type) tr.querySelector('[data-f="type"]').value = v.type;
                        if (v.words) tr.querySelector('[data-f="words"]').value = v.words;
                    }
                    body.appendChild(tr);
                    renumber(); changed();
                    return tr;
                }

                document.getElementById('cap-q-add').addEventListener('click', function () {
                    addRow().querySelector('[data-f="topic"]').focus();
                });
                body.addEventListener('click', function (e) {
                    var b = e.target.closest('button[data-act]');
                    if (!b) return;
                    var tr = b.closest('tr');
                    if (b.dataset.act === 'del') tr.remove();
                    if (b.dataset.act === 'up' && tr.previousElementSibling) body.insertBefore(tr, tr.previousElementSibling);
                    if (b.dataset.act === 'down' && tr.nextElementSibling) body.insertBefore(tr.nextElementSibling, tr);
                    renumber(); changed();
                });
                body.addEventListener('input', changed);
                body.addEventListener('change', changed);
                form.addEventListener('submit', function () { renumber(); dirty.hidden = true; });

                // Bulk add
                var panel = document.getElementById('cap-q-bulk');
                document.getElementById('cap-q-bulk-toggle').addEventListener('click', function () { panel.hidden = !panel.hidden; });
                document.getElementById('cap-q-bulk-add').addEventListener('click', function () {
                    var type = document.getElementById('cap-q-bulk-type'), words = document.getElementById('cap-q-bulk-words');
                    var msg = document.getElementById('cap-q-bulk-msg'), text = document.getElementById('cap-q-bulk-text');
                    if (!type.value) { msg.textContent = 'Choose a type first.'; type.focus(); return; }
                    var n = 0;
                    text.value.split(/\r?\n/).forEach(function (line) {
                        line = line.trim();
                        if (!line) return;
                        var parts = line.indexOf('\t') > -1 ? line.split('\t') : line.split('|');
                        addRow({ topic: parts[0].trim(), keywords: (parts.slice(1).join(', ') || '').trim(), type: type.value, words: words.value });
                        n++;
                    });
                    msg.textContent = n ? n + ' topic(s) added below. Click “Save queue” to keep them.' : 'Nothing to add.';
                    if (n) text.value = '';
                });
                renumber(); dirty.hidden = true;
            })();
            </script>

            <!-- ============ PROCESS REPORTS ============ -->
            <div class="cap-panel<?php echo $tab === 'reports' ? ' is-active' : ''; ?>" data-tab-panel="reports">
                <?php self::render_reports_tab($s); ?>
            </div>

            <!-- ============ SETTINGS (one form across four tabs) ============ -->
            <div data-tabs="quality"<?php echo $tab !== 'quality' ? ' style="display:none;"' : ''; ?>>
                <?php self::render_library(); ?>
            </div>

            <form method="post" action="options.php" id="cap-settings-form">
                <?php settings_fields('cap_settings_group'); ?>

                <div class="cap-panel<?php echo $tab === 'general' ? ' is-active' : ''; ?>" data-tab-panel="general">
                    <div class="cap-card">
                        <h2>Schedule</h2>
                        <p class="cap-sub">How often posts are generated and where they land.</p>
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row">Automatic posting</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[enabled]" value="1" <?php checked($s['enabled'], 1); ?>> Generate posts automatically on a schedule</label></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_ppd">Posts per day</label></th>
                                <td><input type="number" id="cap_ppd" min="1" max="24" name="<?php echo $opt; ?>[posts_per_day]" value="<?php echo (int) $s['posts_per_day']; ?>" class="small-text">
                                    <p class="description">Spread evenly across 24 hours.</p></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_status">Post status</label></th>
                                <td>
                                    <select id="cap_status" name="<?php echo $opt; ?>[post_status]">
                                        <option value="draft"   <?php selected($s['post_status'], 'draft'); ?>>Draft (review before publishing)</option>
                                        <option value="pending" <?php selected($s['post_status'], 'pending'); ?>>Pending review</option>
                                        <option value="publish" <?php selected($s['post_status'], 'publish'); ?>>Publish immediately</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_geo_default">Target market</label></th>
                                <td>
                                    <select id="cap_geo_default" name="<?php echo $opt; ?>[geo]">
                                        <option value="" <?php selected($s['geo'], ''); ?>>Global (no specific country)</option>
                                        <?php foreach (self::GEOS as $code => $g) : ?>
                                            <option value="<?php echo esc_attr($code); ?>" <?php selected($s['geo'], $code); ?>><?php echo esc_html($g[0]); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description">The country Claude researches and writes for: search results come from that country, and money, spelling, payment methods and legal context are localized.
                                        For one topic, start its line with a market tag such as <code>[au]</code>, <code>[za]</code> or <code>[ca-on]</code>.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Parent page</th>
                                <td><?php wp_dropdown_pages(['name' => $opt . '[parent_page]', 'selected' => (int) $s['parent_page'], 'show_option_none' => '— None (top level) —', 'option_none_value' => 0, 'post_status' => ['publish', 'draft']]); ?>
                                    <p class="description">Only for pages. New pages are placed under this page, e.g. a “Casino Guides” hub.</p></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_lang_default">Content language</label></th>
                                <td>
                                    <select id="cap_lang_default" name="<?php echo $opt; ?>[language]">
                                        <?php foreach (self::LANGUAGES as $code => $l) : ?>
                                            <option value="<?php echo esc_attr($code); ?>" <?php selected($s['language'], $code); ?>><?php echo esc_html($l[0]); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <p class="description">Language for scheduled posts. Keep English unless every scheduled post should be in another language; use topic tags for one-offs.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Author</th>
                                <td><?php wp_dropdown_users(['name' => $opt . '[author_id]', 'selected' => $s['author_id'], 'capability' => ['edit_posts']]); ?></td>
                            </tr>
                            <tr>
                                <th scope="row">Category <span class="cap-badge cap-badge--muted">posts only</span></th>
                                <td><?php wp_dropdown_categories(['name' => $opt . '[category_id]', 'selected' => $s['category_id'], 'hide_empty' => 0, 'show_option_none' => '— Default —', 'option_none_value' => 0]); ?></td>
                            </tr>
                        </table>
                    </div>

                    <div class="cap-card">
                        <h2>Claude API</h2>
                        <p class="cap-sub">Connection and model settings.</p>
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row"><label for="cap_api_key">API key</label></th>
                                <td>
                                    <?php if ($keyFromConfig) : ?>
                                        <?php echo self::badge('Set in wp-config.php', 'ok'); ?> <code><?php echo esc_html(self::key_masked()); ?></code> <span class="description">(<?php echo esc_html(self::key_constant()); ?>)</span>
                                        <p class="description">This overrides any key pasted here. To change it, edit <code><?php echo esc_html(self::key_constant()); ?></code> in wp-config.php.</p>
                                    <?php else : ?>
                                        <input type="password" id="cap_api_key" name="<?php echo $opt; ?>[api_key]" value="" class="regular-text" autocomplete="off"
                                               placeholder="<?php echo $s['api_key'] ? 'Saved (leave blank to keep)' : 'sk-ant-...'; ?>">
                                        <?php echo $s['api_key'] ? ' ' . self::badge('Saved', 'ok') . ' <code>' . esc_html(self::key_masked()) . '</code>' : ' ' . self::badge('Missing', 'err'); ?>
                                        <p class="description">More secure: define <code>CAP_ANTHROPIC_KEY</code> in wp-config.php instead.</p>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_model">Model</label></th>
                                <td><input type="text" id="cap_model" name="<?php echo $opt; ?>[model]" value="<?php echo esc_attr($s['model']); ?>" class="regular-text">
                                    <p class="description"><code>claude-sonnet-5-5</code> for quality, <code>claude-haiku-5-5</code> for lower cost.</p></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_max">Max tokens</label></th>
                                <td><input type="number" id="cap_max" min="8000" max="32000" step="1000" name="<?php echo $opt; ?>[max_tokens]" value="<?php echo (int) $s['max_tokens']; ?>" class="small-text">
                                    <p class="description">Output limit for each pipeline stage (minimum 8000). 12000 is recommended; raise it if the log reports output being cut off. You only pay for tokens actually used.</p></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="cap-panel<?php echo $tab === 'quality' ? ' is-active' : ''; ?>" data-tab-panel="quality">
                    <div class="cap-card">
                        <h2>Pipeline</h2>
                        <p class="cap-sub">Every post moves through these stages before it is saved.</p>
                        <div class="cap-steps">
                            <?php
                            $steps = [
                                ['Competitor research', !empty($s['web_research'])],
                                ['Brief & outline', true],
                                ['Draft', true],
                                ['Edit & humanize', !empty($s['edit_pass'])],
                                ['QA score' . (!empty($s['qa_enabled']) ? ' ≥ ' . (int) $s['qa_threshold'] : ''), !empty($s['qa_enabled'])],
                                ['Images', !empty($s['img_featured']) || !empty($s['img_body'])],
                                ['SOP library: ' . count(array_filter(self::docs(), function ($d) { return $d['enabled']; })) . ' docs on', (bool) array_filter(self::docs(), function ($d) { return $d['enabled']; })],
                                ['Saved as ' . ($s['post_status'] === 'publish' ? 'published' : $s['post_status']), true],
                            ];
                            foreach ($steps as $i => $st) {
                                if ($i) echo '<span class="cap-arrow">→</span>';
                                echo '<span class="cap-step ' . ($st[1] ? 'is-on' : 'is-off') . '">' . esc_html($st[0]) . '</span>';
                            }
                            ?>
                        </div>
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row">Competitor research</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[web_research]" value="1" <?php checked($s['web_research'], 1); ?>> Look at the pages currently ranking (web search) before writing the brief</label>
                                    <p class="description">Extra cost per post. Web search must be enabled for your organization in the Claude Console.</p></td>
                            </tr>
                            <tr>
                                <th scope="row">Editing pass</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[edit_pass]" value="1" <?php checked($s['edit_pass'], 1); ?>> Edit and humanize every draft using the editing SOPs in the library</label></td>
                            </tr>
                            <tr>
                                <th scope="row">QA scoring</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[qa_enabled]" value="1" <?php checked($s['qa_enabled'], 1); ?>> Score every post against the QA SOPs in the library</label>
                                    <p style="margin-top:10px;">
                                        <label>Target score <input type="number" min="1" max="100" name="<?php echo $opt; ?>[qa_threshold]" value="<?php echo (int) $s['qa_threshold']; ?>" class="small-text"></label>
                                        &nbsp;&nbsp;
                                        <label>Max automatic rewrites <input type="number" min="0" max="3" name="<?php echo $opt; ?>[max_rewrites]" value="<?php echo (int) $s['max_rewrites']; ?>" class="small-text"></label>
                                    </p>
                                    <p class="description">Posts below the target are rewritten from the QA feedback. If still below after the last rewrite, they are saved and flagged in the email.</p></td>
                            </tr>
                        </table>
                    </div>

                    <div class="cap-card">
                        <details>
                            <summary style="cursor:pointer;"><strong>Advanced: base instructions</strong> <span class="description">— rarely needs changing; your SOP library holds the detailed rules</span></summary>
                            <table class="form-table" role="presentation" style="margin-top:8px;">
                                <tr>
                                    <th scope="row"><label for="cap_sys">Base system prompt</label></th>
                                    <td><textarea id="cap_sys" name="<?php echo $opt; ?>[system_prompt]" rows="4" class="large-text"><?php echo esc_textarea($s['system_prompt']); ?></textarea>
                                        <p class="description">A short description of the writer and site, placed before the SOPs at every step.</p></td>
                                </tr>
                                <tr>
                                    <th scope="row"><label for="cap_extra">Extra instructions</label></th>
                                    <td><textarea id="cap_extra" name="<?php echo $opt; ?>[extra_instructions]" rows="3" class="large-text"><?php echo esc_textarea($s['extra_instructions']); ?></textarea>
                                        <p class="description">Optional. Added to every post, e.g. a section every article must include.</p></td>
                                </tr>
                            </table>
                        </details>
                    </div>
                </div>

                <div class="cap-panel<?php echo $tab === 'images' ? ' is-active' : ''; ?>" data-tab-panel="images">
                    <div class="cap-card">
                        <h2>Images</h2>
                        <p class="cap-sub">Claude plans two graphics for every post or page and the plugin draws them from scratch: a branded background, a headline, the keywords written on it, and an illustration matched to the topic (roulette wheel, cards, slot machine, shield and more). They are saved to the Media Library with SEO alt text.</p>
                        <?php if (!CAP_Image::supported()) : ?>
                            <div class="notice notice-warning inline"><p>This server’s PHP has no GD/FreeType support, so images can’t be drawn here. Posts are still created without images. Ask your host to enable the GD extension.</p></div>
                        <?php endif; ?>
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row">Featured image</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[img_featured]" value="1" <?php checked($s['img_featured'], 1); ?>> Create and set a featured image (1200 × 630, also used for social sharing)</label></td>
                            </tr>
                            <tr>
                                <th scope="row">Image in the article</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[img_body]" value="1" <?php checked($s['img_body'], 1); ?>> Add one image inside the article, after a relevant section, with a caption</label></td>
                            </tr>
                            <tr>
                                <th scope="row">Text on images</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[img_text]" value="1" <?php checked($s['img_text'], 1); ?>> Write the headline and keywords on the graphics</label>
                                    <p class="description">English, Spanish and French only. Chinese, Hindi and Arabic posts get illustration-only images (their alt text and captions are still in that language).</p></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_img_brand">Brand label</label></th>
                                <td><input type="text" id="cap_img_brand" name="<?php echo $opt; ?>[img_brand]" value="<?php echo esc_attr($s['img_brand']); ?>" class="regular-text" placeholder="<?php echo esc_attr(get_bloginfo('name')); ?>">
                                    <p class="description">Shown in the small pill at the top. Leave empty to use the site name.</p></td>
                            </tr>
                            <tr>
                                <th scope="row">Colours</th>
                                <td>
                                    <label>Background <input type="color" id="cap_img_bg" name="<?php echo $opt; ?>[img_bg]" value="<?php echo esc_attr($s['img_bg']); ?>"></label>
                                    &nbsp;&nbsp;
                                    <label>Accent <input type="color" id="cap_img_accent" name="<?php echo $opt; ?>[img_accent]" value="<?php echo esc_attr($s['img_accent']); ?>"></label>
                                    <p class="description">Use your brand colours. A dark background with a bright accent works best.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Preview</th>
                                <td>
                                    <a class="button" id="cap_img_prev_f" target="_blank" href="#">Preview featured image</a>
                                    <a class="button" id="cap_img_prev_b" target="_blank" href="#">Preview article image</a>
                                    <p class="description">Opens a sample with the colours and label above (before saving). Sample text only; real images use each post’s own headline, keywords and illustration.</p>
                                    <script>
                                    (function () {
                                        var base = <?php echo wp_json_encode(wp_nonce_url(admin_url('admin-post.php?action=cap_image_preview'), 'cap_image_preview')); ?>;
                                        function go(layout, e) {
                                            e.preventDefault();
                                            var u = base + '&layout=' + layout
                                                + '&img_bg=' + encodeURIComponent(document.getElementById('cap_img_bg').value)
                                                + '&img_accent=' + encodeURIComponent(document.getElementById('cap_img_accent').value)
                                                + '&img_brand=' + encodeURIComponent(document.getElementById('cap_img_brand').value);
                                            window.open(u, '_blank');
                                        }
                                        document.getElementById('cap_img_prev_f').addEventListener('click', function (e) { go('featured', e); });
                                        document.getElementById('cap_img_prev_b').addEventListener('click', function (e) { go('body', e); });
                                    })();
                                    </script>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="cap-panel<?php echo $tab === 'notifications' ? ' is-active' : ''; ?>" data-tab-panel="notifications">
                    <div class="cap-card">
                        <h2>Editor email</h2>
                        <p class="cap-sub">Sent whenever a new post is ready, with the edit link, keywords and QA score.</p>
                        <table class="form-table" role="presentation">
                            <tr>
                                <th scope="row">Notifications</th>
                                <td><label><input type="checkbox" name="<?php echo $opt; ?>[notify_enabled]" value="1" <?php checked($s['notify_enabled'], 1); ?>> Email the editor a link to each new post</label></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_notify_to">Send to</label></th>
                                <td><input type="text" id="cap_notify_to" name="<?php echo $opt; ?>[notify_to]" value="<?php echo esc_attr($s['notify_to']); ?>" class="large-text"></td>
                            </tr>
                            <tr>
                                <th scope="row"><label for="cap_notify_cc">CC</label></th>
                                <td><input type="text" id="cap_notify_cc" name="<?php echo $opt; ?>[notify_cc]" value="<?php echo esc_attr($s['notify_cc']); ?>" class="large-text">
                                    <p class="description">Separate multiple addresses with commas.</p></td>
                            </tr>
                        </table>
                    </div>
                </div>

                <div class="cap-savebar" data-tabs="<?php echo esc_attr($settings_tabs); ?>"<?php echo strpos($settings_tabs, $tab) === false ? ' style="display:none;"' : ''; ?>>
                    <?php submit_button('Save settings', 'primary', 'submit', false); ?>
                </div>
            </form>

            <div class="cap-card" data-tabs="notifications"<?php echo $tab !== 'notifications' ? ' style="display:none;"' : ''; ?>>
                <h2>Test delivery</h2>
                <p class="cap-sub">Save first, then send a test to the addresses above.</p>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" class="cap-inline-form">
                    <input type="hidden" name="action" value="cap_test_email">
                    <?php wp_nonce_field('cap_test_email'); ?>
                    <?php submit_button('Send test email', 'secondary', 'submit', false); ?>
                </form>
            </div>
        </div>

        <script>
        (function () {
            var nav = document.querySelector('.cap-tabs');
            if (!nav) return;
            var links = nav.querySelectorAll('.nav-tab');

            function show(tab) {
                links.forEach(function (a) { a.classList.toggle('nav-tab-active', a.dataset.tab === tab); });
                document.querySelectorAll('[data-tab-panel]').forEach(function (p) { p.classList.toggle('is-active', p.dataset.tabPanel === tab); });
                document.querySelectorAll('[data-tabs]').forEach(function (el) { el.style.display = el.dataset.tabs.split(' ').indexOf(tab) > -1 ? '' : 'none'; });

                // Keep the tab in the URL, and make "Save settings" return to the same tab.
                try {
                    var u = new URL(window.location.href);
                    u.searchParams.set('tab', tab);
                    ['cap_msg', 'settings-updated'].forEach(function (k) { u.searchParams.delete(k); });
                    if (tab !== 'reports') u.searchParams.delete('report');
                    window.history.replaceState(null, '', u.toString());
                    var ref = document.querySelector('#cap-settings-form input[name="_wp_http_referer"]');
                    if (ref) {
                        var r = new URL(ref.value, window.location.origin);
                        r.searchParams.set('tab', tab);
                        r.searchParams.delete('settings-updated');
                        ref.value = r.pathname + r.search;
                    }
                } catch (e) {}
            }

            links.forEach(function (a) {
                a.addEventListener('click', function (e) { e.preventDefault(); show(a.dataset.tab); });
            });
            show(nav.dataset.initial);

            // Keep the topic and keyword boxes scrolled together so lines stay aligned.
            var t = document.getElementById('cap_topics_box'), k = document.getElementById('cap_keywords_box');
            if (t && k) {
                t.addEventListener('scroll', function () { k.scrollTop = t.scrollTop; });
                k.addEventListener('scroll', function () { t.scrollTop = k.scrollTop; });
            }
        })();
        </script>
        <?php
    }
}

Claude_Auto_Poster::init();
register_activation_hook(__FILE__, ['Claude_Auto_Poster', 'activate']);
register_deactivation_hook(__FILE__, ['Claude_Auto_Poster', 'deactivate']);
