<?php
/**
 * Draws branded article graphics from scratch with PHP GD:
 * a gradient background, the headline, keyword chips and a drawn illustration (motif).
 * No external image service is used.
 */
if (!defined('ABSPATH') && PHP_SAPI !== 'cli') exit;

class CAP_Image {

    const W = 1200;
    const H = 630;
    const S = 2; // draw at 2x, then downsample for smooth edges

    /** Motifs Claude can choose from, with a hint of what each suits. */
    const MOTIFS = [
        'roulette'  => 'roulette, table games, odds, fairness, RNG',
        'cards'     => 'blackjack, poker, baccarat, card games',
        'dice'      => 'craps, chance, luck, house edge, odds',
        'chips'     => 'casino in general, bankroll, bonuses, betting',
        'slot'      => 'slots, jackpots, slot features, RTP',
        'coins'     => 'money, deposits, withdrawals, payouts, cashback',
        'phone'     => 'mobile casinos, apps, PayID, e-wallets',
        'shield'    => 'safety, licensing, trust, legitimate casinos, scams',
        'lock'      => 'security, verification, KYC, privacy',
        'chart'     => 'statistics, comparisons, payout rates, rankings',
        'checklist' => 'guides, rules, terms and conditions, how-to, tips',
        'globe'     => 'online vs land-based, international, crypto, live dealer streaming',
    ];

    private $im;
    private $font_bold;
    private $font_semi;
    private $c = [];

    public function __construct() {
        $dir = dirname(__DIR__) . '/fonts/';
        $this->font_bold = $dir . 'Poppins-Bold.ttf';
        $this->font_semi = $dir . 'Poppins-SemiBold.ttf';
    }

    public static function supported() {
        return function_exists('imagecreatetruecolor') && function_exists('imagettftext') && function_exists('imagejpeg');
    }

    /**
     * @param array  $spec headline, keywords[], motif, brand, bg, accent, currency, layout ('featured'|'body'), text (bool)
     * @param string $path where to save the JPEG
     * @return true|string true on success, error message otherwise
     */
    public function render(array $spec, $path) {
        if (!self::supported()) return 'PHP GD with FreeType is not available on this server.';
        if (!is_readable($this->font_bold)) return 'Font file missing: ' . $this->font_bold;

        $W = self::W * self::S; $H = self::H * self::S;
        $this->im = imagecreatetruecolor($W, $H);
        imagealphablending($this->im, true);
        if (function_exists('imageantialias')) @imageantialias($this->im, false);

        $bg     = $this->hex($spec['bg'] ?? '#0F1B3D', '#0F1B3D');
        $accent = $this->hex($spec['accent'] ?? '#F5B700', '#F5B700');
        $this->c = [
            'bg'      => $bg,
            'bg2'     => $this->mix($bg, [255, 255, 255], 0.16),
            'bgdark'  => $this->mix($bg, [0, 0, 0], 0.35),
            'accent'  => $accent,
            'accentD' => $this->mix($accent, [0, 0, 0], 0.35),
            'accentL' => $this->mix($accent, [255, 255, 255], 0.35),
            'white'   => [255, 255, 255],
            'ink'     => [27, 27, 34],
            'red'     => [214, 48, 58],
            'green'   => [24, 150, 84],
            'grey'    => [200, 204, 214],
        ];

        $layout = ($spec['layout'] ?? 'featured') === 'body' ? 'body' : 'featured';
        $text   = !empty($spec['text']);
        $this->background($layout);

        $motif = isset(self::MOTIFS[$spec['motif'] ?? '']) ? $spec['motif'] : 'chips';
        $cur   = (string) ($spec['currency'] ?? '$');

        if (!$text) {
            $this->motif($motif, 600, 315, 200, $cur);
        } elseif ($layout === 'featured') {
            $this->motif($motif, 935, 320, 175, $cur);
            $this->text_block(70, 70, 640, $spec, true);
        } else {
            $this->motif($motif, 285, 315, 175, $cur);
            $this->text_block(540, 95, 600, $spec, false);
        }

        $out = imagecreatetruecolor(self::W, self::H);
        imagecopyresampled($out, $this->im, 0, 0, 0, 0, self::W, self::H, $W, $H);
        imagedestroy($this->im);
        $ok = imagejpeg($out, $path, 88);
        imagedestroy($out);
        return $ok ? true : 'Could not write the image file.';
    }

    /* ---------------- helpers ---------------- */

    private function p($v) { return (int) round($v * self::S); }

    private function hex($hex, $fallback) {
        $hex = ltrim((string) $hex, '#');
        if (!preg_match('/^[0-9a-f]{6}$/i', $hex)) $hex = ltrim($fallback, '#');
        return [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];
    }

    private function mix($a, $b, $t) {
        return [(int) round($a[0] + ($b[0] - $a[0]) * $t), (int) round($a[1] + ($b[1] - $a[1]) * $t), (int) round($a[2] + ($b[2] - $a[2]) * $t)];
    }

    /** Colour index; $alpha 0 (solid) to 127 (transparent). */
    private function col($rgb, $alpha = 0) {
        if (is_string($rgb)) $rgb = $this->c[$rgb];
        return imagecolorallocatealpha($this->im, $rgb[0], $rgb[1], $rgb[2], $alpha);
    }

    private function circle($cx, $cy, $r, $color, $alpha = 0) {
        imagefilledellipse($this->im, $this->p($cx), $this->p($cy), $this->p($r * 2), $this->p($r * 2), $this->col($color, $alpha));
    }

    private function ellipse($cx, $cy, $w, $h, $color, $alpha = 0) {
        imagefilledellipse($this->im, $this->p($cx), $this->p($cy), $this->p($w), $this->p($h), $this->col($color, $alpha));
    }

    private function poly(array $pts, $color, $alpha = 0) {
        $flat = [];
        foreach ($pts as $pt) { $flat[] = $this->p($pt[0]); $flat[] = $this->p($pt[1]); }
        if (PHP_VERSION_ID >= 80100) {
            imagefilledpolygon($this->im, $flat, $this->col($color, $alpha));
        } else {
            imagefilledpolygon($this->im, $flat, count($pts), $this->col($color, $alpha));
        }
    }

    /** Rounded rectangle as polygon points, optionally rotated (degrees) around its centre. */
    private function rrect_pts($cx, $cy, $w, $h, $rad, $angle = 0) {
        $pts = [];
        $corners = [[$w / 2 - $rad, -$h / 2 + $rad, -90], [$w / 2 - $rad, $h / 2 - $rad, 0], [-$w / 2 + $rad, $h / 2 - $rad, 90], [-$w / 2 + $rad, -$h / 2 + $rad, 180]];
        foreach ($corners as $c) {
            for ($i = 0; $i <= 6; $i++) {
                $a = deg2rad($c[2] + $i * 15);
                $pts[] = [$c[0] + cos($a) * $rad, $c[1] + sin($a) * $rad];
            }
        }
        return $this->rot($pts, $cx, $cy, $angle);
    }

    private function rot(array $pts, $cx, $cy, $angle) {
        $a = deg2rad($angle); $cs = cos($a); $sn = sin($a);
        return array_map(function ($pt) use ($cx, $cy, $cs, $sn) { return [$cx + $pt[0] * $cs - $pt[1] * $sn, $cy + $pt[0] * $sn + $pt[1] * $cs]; }, $pts);
    }

    private function rrect($cx, $cy, $w, $h, $rad, $color, $alpha = 0, $angle = 0) {
        $this->poly($this->rrect_pts($cx, $cy, $w, $h, $rad, $angle), $color, $alpha);
    }

    /** Thick line drawn as a polygon (smooth after downsampling). */
    private function line($x1, $y1, $x2, $y2, $t, $color, $alpha = 0) {
        $dx = $x2 - $x1; $dy = $y2 - $y1; $len = max(0.001, sqrt($dx * $dx + $dy * $dy));
        $nx = -$dy / $len * $t / 2; $ny = $dx / $len * $t / 2;
        $this->poly([[$x1 + $nx, $y1 + $ny], [$x2 + $nx, $y2 + $ny], [$x2 - $nx, $y2 - $ny], [$x1 - $nx, $y1 - $ny]], $color, $alpha);
        $this->circle($x1, $y1, $t / 2, $color, $alpha);
        $this->circle($x2, $y2, $t / 2, $color, $alpha);
    }

    private function arc_line($cx, $cy, $rx, $ry, $from, $to, $t, $color, $alpha = 0) {
        $steps = 40; $prev = null;
        for ($i = 0; $i <= $steps; $i++) {
            $a = deg2rad($from + ($to - $from) * $i / $steps);
            $pt = [$cx + cos($a) * $rx, $cy + sin($a) * $ry];
            if ($prev) $this->line($prev[0], $prev[1], $pt[0], $pt[1], $t, $color, $alpha);
            $prev = $pt;
        }
    }

    private function text($x, $y, $size, $txt, $color, $font = null, $angle = 0, $alpha = 0) {
        imagettftext($this->im, $size * self::S, $angle, $this->p($x), $this->p($y), $this->col($color, $alpha), $font ?: $this->font_bold, $txt);
    }

    private function text_w($size, $txt, $font = null) {
        $b = imagettfbbox($size * self::S, 0, $font ?: $this->font_bold, $txt);
        return (abs($b[2] - $b[0])) / self::S;
    }

    private function text_center($cx, $cy, $size, $txt, $color, $font = null) {
        $b = imagettfbbox($size * self::S, 0, $font ?: $this->font_bold, $txt);
        $w = abs($b[2] - $b[0]) / self::S; $h = abs($b[7] - $b[1]) / self::S;
        $this->text($cx - $w / 2, $cy + $h / 2, $size, $txt, $color, $font);
    }

    private function wrap($txt, $size, $max_w, $font = null) {
        $words = preg_split('/\s+/u', trim($txt)); $lines = []; $cur = '';
        foreach ($words as $w) {
            $try = $cur === '' ? $w : $cur . ' ' . $w;
            if ($cur !== '' && $this->text_w($size, $try, $font) > $max_w) { $lines[] = $cur; $cur = $w; } else { $cur = $try; }
        }
        if ($cur !== '') $lines[] = $cur;
        return $lines;
    }

    /* ---------------- layout ---------------- */

    private function background($layout) {
        $W = self::W * self::S; $H = self::H * self::S;
        $top = $this->c['bg2']; $bot = $this->c['bgdark'];
        for ($y = 0; $y < $H; $y++) {
            $t = $y / $H;
            imageline($this->im, 0, $y, $W, $y, imagecolorallocate($this->im, (int) ($top[0] + ($bot[0] - $top[0]) * $t), (int) ($top[1] + ($bot[1] - $top[1]) * $t), (int) ($top[2] + ($bot[2] - $top[2]) * $t)));
        }
        if ($layout === 'featured') {
            $this->circle(1060, 70, 330, 'accent', 112);
            $this->circle(930, 330, 250, 'white', 120);
            $this->circle(-40, 680, 240, 'white', 122);
        } else {
            $this->circle(140, 560, 330, 'accent', 114);
            $this->circle(285, 315, 245, 'white', 120);
            $this->circle(1180, -30, 220, 'white', 122);
        }
        // faint dot grid
        for ($x = 0; $x < 7; $x++) for ($y = 0; $y < 4; $y++) {
            $this->circle(($layout === 'featured' ? 470 : 1010) + $x * 22, 560 + $y * 18 - 40, 2.2, 'white', 100);
        }
        // accent bar along the bottom
        imagefilledrectangle($this->im, 0, $H - $this->p(8), $W, $H, $this->col('accent'));
    }

    /** Lays out brand pill, headline (max 3 lines), accent bar and keyword chips, centred vertically. */
    private function text_block($x, $y_unused, $max_w, $spec, $featured) {
        $brand    = strtoupper(trim((string) ($spec['brand'] ?? '')));
        $headline = trim((string) ($spec['headline'] ?? ''));
        $size  = $featured ? 46 : 38;
        $lines = $this->wrap($headline, $size, $max_w);
        while (count($lines) > 3 && $size > 26) { $size -= 2; $lines = $this->wrap($headline, $size, $max_w); }
        $lines = array_slice($lines, 0, 3);
        $lh = $size * 1.32;

        // chip rows
        $kws = [];
        foreach (array_slice(array_filter(array_map('trim', (array) ($spec['keywords'] ?? []))), 0, 4) as $kw) {
            $kws[] = mb_strlen($kw) > 34 ? mb_substr($kw, 0, 33) . '…' : $kw;
        }
        $fs = 16; $ch = 42; $rows = []; $row = []; $rw = 0;
        foreach ($kws as $kw) {
            $w = $this->text_w($fs, $kw, $this->font_semi) + 36;
            if ($row && $rw + $w > $max_w) { $rows[] = $row; $row = []; $rw = 0; }
            $row[] = [$kw, $w]; $rw += $w + 10;
        }
        if ($row) $rows[] = $row;
        $rows = array_slice($rows, 0, 2);

        $total = ($brand !== '' ? 62 : 0) + $size * 1.05 + (count($lines) - 1) * $lh + 26 + 34 + ($rows ? count($rows) * ($ch + 12) - 12 : 0);
        $y = max(46, (self::H - 8 - $total) / 2);

        if ($brand !== '') {
            $bs = 14; $bw = $this->text_w($bs, $brand, $this->font_semi) + 32;
            $this->rrect($x + $bw / 2, $y + 17, $bw, 34, 17, 'accent');
            $this->text($x + 16, $y + 24, $bs, $brand, 'bgdark', $this->font_semi);
            $y += 62;
        }
        foreach ($lines as $i => $ln) {
            $this->text($x, $y + $size * 1.05 + $i * $lh, $size, $ln, 'white');
        }
        $y += $size * 1.05 + (count($lines) - 1) * $lh + 26;
        $this->rrect($x + 45, $y, 90, 7, 3.5, 'accent');
        $y += 34;

        foreach ($rows as $row) {
            $cx = $x;
            foreach ($row as $chip) {
                list($kw, $w) = $chip;
                $this->rrect($cx + $w / 2, $y + $ch / 2, $w, $ch, $ch / 2, 'white', 104);
                $this->rrect($cx + 15, $y + $ch / 2, 8, 8, 4, 'accent');
                $this->text($cx + 26, $y + $ch / 2 + 6, $fs, $kw, 'white', $this->font_semi);
                $cx += $w + 10;
            }
            $y += $ch + 12;
        }
    }

    /* ---------------- motifs ---------------- */

    private function motif($m, $cx, $cy, $r, $cur) {
        // soft drop shadow
        $this->ellipse($cx + 6, $cy + $r * 1.02, $r * 1.7, $r * 0.28, 'bgdark', 70);
        $fn = 'm_' . $m;
        $this->$fn($cx, $cy, $r, $cur);
    }

    private function m_roulette($cx, $cy, $r, $cur) {
        $this->circle($cx, $cy, $r, 'accentD');
        $this->circle($cx, $cy, $r * 0.95, 'accent');
        $n = 18;
        for ($i = 0; $i < $n; $i++) {
            $a1 = $i * 360 / $n; $a2 = ($i + 1) * 360 / $n;
            $col = $i === 0 ? 'green' : ($i % 2 ? 'red' : 'ink');
            $pts = [[$cx, $cy]];
            for ($k = 0; $k <= 6; $k++) { $a = deg2rad($a1 + ($a2 - $a1) * $k / 6); $pts[] = [$cx + cos($a) * $r * 0.86, $cy + sin($a) * $r * 0.86]; }
            $this->poly($pts, $col);
        }
        $this->circle($cx, $cy, $r * 0.64, 'accentD');
        $this->circle($cx, $cy, $r * 0.56, 'accent');
        for ($i = 0; $i < 4; $i++) {
            $a = deg2rad(45 + $i * 90);
            $this->line($cx, $cy, $cx + cos($a) * $r * 0.42, $cy + sin($a) * $r * 0.42, $r * 0.07, 'accentL');
        }
        $this->circle($cx, $cy, $r * 0.14, 'white');
        $a = deg2rad(-58);
        $this->circle($cx + cos($a) * $r * 0.75, $cy + sin($a) * $r * 0.75, $r * 0.065, 'white');
    }

    private function heart($x, $y, $s, $color) {
        $this->circle($x - $s * 0.25, $y - $s * 0.12, $s * 0.28, $color);
        $this->circle($x + $s * 0.25, $y - $s * 0.12, $s * 0.28, $color);
        $this->poly([[$x - $s * 0.52, $y - $s * 0.02], [$x + $s * 0.52, $y - $s * 0.02], [$x, $y + $s * 0.55]], $color);
    }

    private function spade($x, $y, $s, $color) {
        $this->circle($x - $s * 0.25, $y + $s * 0.12, $s * 0.28, $color);
        $this->circle($x + $s * 0.25, $y + $s * 0.12, $s * 0.28, $color);
        $this->poly([[$x - $s * 0.52, $y + $s * 0.02], [$x + $s * 0.52, $y + $s * 0.02], [$x, $y - $s * 0.55]], $color);
        $this->poly([[$x, $y + $s * 0.15], [$x - $s * 0.22, $y + $s * 0.62], [$x + $s * 0.22, $y + $s * 0.62]], $color);
    }

    private function m_cards($cx, $cy, $r, $cur) {
        $w = $r * 1.05; $h = $r * 1.48;
        // back card
        $this->rrect($cx - $r * 0.32, $cy - $r * 0.05, $w, $h, $r * 0.1, 'accentD', 0, -14);
        $this->rrect($cx - $r * 0.32, $cy - $r * 0.05, $w * 0.86, $h * 0.9, $r * 0.07, 'accent', 0, -14);
        $this->rrect($cx - $r * 0.32, $cy - $r * 0.05, $w * 0.62, $h * 0.68, $r * 0.05, 'accentD', 60, -14);
        // front card
        $fx = $cx + $r * 0.28; $fy = $cy + $r * 0.05; $ang = 10;
        $this->rrect($fx, $fy, $w, $h, $r * 0.1, 'white', 0, $ang);
        $p = $this->rot([[0, 0]], $fx, $fy, $ang)[0];
        $this->spade($p[0], $p[1], $r * 0.42, 'ink');
        $tl = $this->rot([[-$w * 0.36, -$h * 0.3]], $fx, $fy, $ang)[0];
        $this->text($tl[0], $tl[1], $r * 0.17, 'A', 'ink', null, -$ang);
        $br = $this->rot([[$w * 0.36, $h * 0.3]], $fx, $fy, $ang)[0];
        $this->text($br[0], $br[1], $r * 0.17, 'A', 'ink', null, 180 - $ang);
        $hp = $this->rot([[-$w * 0.33, -$h * 0.17]], $fx, $fy, $ang)[0];
        $this->heart($hp[0], $hp[1], $r * 0.09, 'red');
    }

    private function m_dice($cx, $cy, $r, $cur) {
        $dice = [[$cx - $r * 0.42, $cy + $r * 0.12, -12, 5], [$cx + $r * 0.45, $cy - $r * 0.18, 14, 3]];
        foreach ($dice as $d) {
            list($x, $y, $ang, $pips) = $d; $s = $r * 0.95;
            $this->rrect($x + 6, $y + 10, $s, $s, $s * 0.18, 'bgdark', 60, $ang);
            $this->rrect($x, $y, $s, $s, $s * 0.18, 'white', 0, $ang);
            $q = $s * 0.27;
            $map = [3 => [[-$q, -$q], [0, 0], [$q, $q]], 5 => [[-$q, -$q], [$q, -$q], [0, 0], [-$q, $q], [$q, $q]]];
            foreach ($this->rot($map[$pips], $x, $y, $ang) as $pt) $this->circle($pt[0], $pt[1], $s * 0.08, $pips === 5 ? 'red' : 'ink');
        }
    }

    private function chip($x, $y, $rw, $color, $edge) {
        $rh = $rw * 0.42;
        $this->ellipse($x, $y + $rh * 0.22, $rw * 2, $rh * 2, $this->mix($this->c[$color], [0, 0, 0], 0.35));
        $this->ellipse($x, $y, $rw * 2, $rh * 2, $color);
        for ($i = 0; $i < 8; $i++) {
            $a = deg2rad($i * 45 + 22);
            $this->ellipse($x + cos($a) * $rw * 0.86, $y + sin($a) * $rh * 0.86, $rw * 0.2, $rh * 0.2, $edge);
        }
        $this->ellipse($x, $y, $rw * 1.3, $rh * 1.3, $this->mix($this->c[$color], [255, 255, 255], 0.25));
    }

    private function m_chips($cx, $cy, $r, $cur) {
        $rw = $r * 0.62;
        $stacks = [[$cx - $r * 0.48, $cy + $r * 0.5, 'red', 5], [$cx + $r * 0.5, $cy + $r * 0.62, 'accent', 3]];
        foreach ($stacks as $st) {
            for ($i = 0; $i < $st[3]; $i++) $this->chip($st[0], $st[1] - $i * $r * 0.13, $rw * 0.8, $st[2], 'white');
        }
        // big front chip, standing
        $x = $cx + $r * 0.02; $y = $cy - $r * 0.12; $R = $r * 0.62;
        $this->circle($x + 5, $y + 8, $R, 'bgdark', 60);
        $this->circle($x, $y, $R, 'ink');
        for ($i = 0; $i < 8; $i++) {
            $a1 = $i * 45 - 8; $a2 = $i * 45 + 8; $pts = [[$x, $y]];
            for ($k = 0; $k <= 4; $k++) { $a = deg2rad($a1 + ($a2 - $a1) * $k / 4); $pts[] = [$x + cos($a) * $R, $y + sin($a) * $R]; }
            $this->poly($pts, 'white');
        }
        $this->circle($x, $y, $R * 0.72, 'ink');
        $this->circle($x, $y, $R * 0.62, 'accent');
        $this->text_center($x, $y - $R * 0.02, $R * 0.42, $cur, 'ink');
    }

    private function m_slot($cx, $cy, $r, $cur) {
        $w = $r * 1.75; $h = $r * 1.45;
        $this->rrect($cx, $cy + $r * 0.05, $w, $h, $r * 0.16, 'accentD');
        $this->rrect($cx, $cy, $w, $h, $r * 0.16, 'accent');
        $this->rrect($cx, $cy - $h * 0.36, $w * 0.62, $r * 0.24, $r * 0.12, 'red');
        $this->text_center($cx, $cy - $h * 0.36, $r * 0.12, 'JACKPOT', 'white');
        $this->rrect($cx, $cy + $r * 0.08, $w * 0.86, $h * 0.5, $r * 0.08, 'ink');
        for ($i = -1; $i <= 1; $i++) {
            $x = $cx + $i * $w * 0.28;
            $this->rrect($x, $cy + $r * 0.08, $w * 0.25, $h * 0.42, $r * 0.05, 'white');
            $this->text_center($x, $cy + $r * 0.08, $r * 0.36, '7', 'red');
        }
        $this->rrect($cx, $cy + $h * 0.42, $w * 0.5, $r * 0.12, $r * 0.06, 'accentD');
        // lever
        $lx = $cx + $w / 2 + $r * 0.12;
        $this->line($lx, $cy + $r * 0.25, $lx + $r * 0.1, $cy - $r * 0.55, $r * 0.07, 'grey');
        $this->circle($lx + $r * 0.1, $cy - $r * 0.58, $r * 0.14, 'red');
    }

    private function m_coins($cx, $cy, $r, $cur) {
        $rw = $r * 0.5;
        foreach ([[$cx - $r * 0.55, $cy + $r * 0.62, 6], [$cx + $r * 0.6, $cy + $r * 0.7, 4]] as $st) {
            for ($i = 0; $i < $st[2]; $i++) {
                $y = $st[1] - $i * $r * 0.12;
                $this->ellipse($st[0], $y + $r * 0.05, $rw * 2, $rw * 0.8, 'accentD');
                $this->ellipse($st[0], $y, $rw * 2, $rw * 0.8, 'accent');
            }
            $this->ellipse($st[0], $st[1] - ($st[2] - 1) * $r * 0.12, $rw * 1.4, $rw * 0.5, 'accentL');
        }
        $R = $r * 0.6; $x = $cx; $y = $cy - $r * 0.18;
        $this->circle($x + 6, $y + 8, $R, 'bgdark', 60);
        $this->circle($x, $y, $R, 'accentD');
        $this->circle($x, $y, $R * 0.92, 'accent');
        $this->circle($x, $y, $R * 0.74, 'accentL', 40);
        $this->text_center($x, $y, $R * 0.62, $cur, 'accentD');
    }

    private function m_phone($cx, $cy, $r, $cur) {
        $w = $r * 0.95; $h = $r * 1.8;
        $this->rrect($cx + 8, $cy + 10, $w, $h, $r * 0.14, 'bgdark', 60, 8);
        $this->rrect($cx, $cy, $w, $h, $r * 0.14, 'ink', 0, 8);
        $this->rrect($cx, $cy, $w * 0.88, $h * 0.88, $r * 0.08, 'bg2', 0, 8);
        $pts = $this->rot([[0, -$h * 0.405]], $cx, $cy, 8);
        $this->rrect($pts[0][0], $pts[0][1], $w * 0.3, $r * 0.06, $r * 0.03, 'ink', 0, 8);
        foreach ([-1, 0, 1] as $i) {
            $p = $this->rot([[$i * $w * 0.26, -$h * 0.08]], $cx, $cy, 8)[0];
            $this->rrect($p[0], $p[1], $w * 0.22, $h * 0.2, $r * 0.04, 'white', 0, 8);
            $this->text($p[0] - $r * 0.07, $p[1] + $r * 0.1, $r * 0.2, '7', 'red', null, -8);
        }
        $b = $this->rot([[0, $h * 0.22]], $cx, $cy, 8)[0];
        $this->rrect($b[0], $b[1], $w * 0.66, $h * 0.1, $r * 0.06, 'accent', 0, 8);
        $this->circle($cx + $r * 0.62, $cy - $r * 0.62, $r * 0.24, 'accent');
        $this->text_center($cx + $r * 0.62, $cy - $r * 0.62, $r * 0.2, $cur, 'ink');
    }

    private function m_shield($cx, $cy, $r, $cur) {
        $s = function ($k) use ($cx, $cy, $r) {
            return [[$cx - $r * 0.8 * $k, $cy - $r * 0.72 * $k], [$cx, $cy - $r * 0.95 * $k], [$cx + $r * 0.8 * $k, $cy - $r * 0.72 * $k],
                    [$cx + $r * 0.74 * $k, $cy + $r * 0.05 * $k], [$cx + $r * 0.45 * $k, $cy + $r * 0.58 * $k], [$cx, $cy + $r * 0.95 * $k],
                    [$cx - $r * 0.45 * $k, $cy + $r * 0.58 * $k], [$cx - $r * 0.74 * $k, $cy + $r * 0.05 * $k]];
        };
        $this->poly(array_map(function ($p) { return [$p[0] + 7, $p[1] + 10]; }, $s(1)), 'bgdark', 60);
        $this->poly($s(1), 'accentD');
        $this->poly($s(0.9), 'accent');
        $this->poly($s(0.72), 'white', 95);
        $this->line($cx - $r * 0.34, $cy + $r * 0.02, $cx - $r * 0.08, $cy + $r * 0.3, $r * 0.15, 'white');
        $this->line($cx - $r * 0.08, $cy + $r * 0.3, $cx + $r * 0.4, $cy - $r * 0.28, $r * 0.15, 'white');
    }

    private function m_lock($cx, $cy, $r, $cur) {
        $this->arc_line($cx, $cy - $r * 0.2, $r * 0.42, $r * 0.5, 180, 360, $r * 0.16, 'grey');
        $this->line($cx - $r * 0.42, $cy - $r * 0.2, $cx - $r * 0.42, $cy + $r * 0.05, $r * 0.16, 'grey');
        $this->line($cx + $r * 0.42, $cy - $r * 0.2, $cx + $r * 0.42, $cy + $r * 0.05, $r * 0.16, 'grey');
        $this->rrect($cx + 7, $cy + $r * 0.45 + 10, $r * 1.35, $r * 1.0, $r * 0.16, 'bgdark', 60);
        $this->rrect($cx, $cy + $r * 0.45, $r * 1.35, $r * 1.0, $r * 0.16, 'accentD');
        $this->rrect($cx, $cy + $r * 0.42, $r * 1.3, $r * 0.94, $r * 0.14, 'accent');
        $this->circle($cx, $cy + $r * 0.33, $r * 0.14, 'ink');
        $this->poly([[$cx - $r * 0.08, $cy + $r * 0.38], [$cx + $r * 0.08, $cy + $r * 0.38], [$cx + $r * 0.05, $cy + $r * 0.68], [$cx - $r * 0.05, $cy + $r * 0.68]], 'ink');
    }

    private function m_chart($cx, $cy, $r, $cur) {
        $this->rrect($cx + 7, $cy + 10, $r * 1.9, $r * 1.6, $r * 0.12, 'bgdark', 60);
        $this->rrect($cx, $cy, $r * 1.9, $r * 1.6, $r * 0.12, 'white');
        $base = $cy + $r * 0.58; $left = $cx - $r * 0.72;
        $hs = [0.35, 0.55, 0.78, 1.05];
        foreach ($hs as $i => $hh) {
            $x = $left + $i * $r * 0.44;
            $this->rrect($x + $r * 0.15, $base - $hh * $r / 2, $r * 0.3, $hh * $r, $r * 0.05, $i === 3 ? 'accent' : 'bg2');
        }
        $this->line($cx - $r * 0.8, $base + $r * 0.04, $cx + $r * 0.8, $base + $r * 0.04, $r * 0.03, 'grey');
        $pts = [[$cx - $r * 0.62, $cy + $r * 0.05], [$cx - $r * 0.2, $cy - $r * 0.12], [$cx + $r * 0.12, $cy - $r * 0.02], [$cx + $r * 0.62, $cy - $r * 0.5]];
        for ($i = 0; $i < 3; $i++) $this->line($pts[$i][0], $pts[$i][1], $pts[$i + 1][0], $pts[$i + 1][1], $r * 0.06, 'red');
        $this->poly([[$cx + $r * 0.74, $cy - $r * 0.62], [$cx + $r * 0.44, $cy - $r * 0.56], [$cx + $r * 0.68, $cy - $r * 0.32]], 'red');
    }

    private function m_checklist($cx, $cy, $r, $cur) {
        $w = $r * 1.3; $h = $r * 1.75;
        $this->rrect($cx + 7, $cy + 10, $w, $h, $r * 0.12, 'bgdark', 60);
        $this->rrect($cx, $cy, $w, $h, $r * 0.12, 'accentD');
        $this->rrect($cx, $cy + $r * 0.04, $w * 0.86, $h * 0.86, $r * 0.06, 'white');
        $this->rrect($cx, $cy - $h * 0.47, $w * 0.42, $r * 0.2, $r * 0.08, 'grey');
        for ($i = 0; $i < 3; $i++) {
            $y = $cy - $r * 0.38 + $i * $r * 0.42;
            $this->rrect($cx - $w * 0.27, $y, $r * 0.22, $r * 0.22, $r * 0.05, $i < 2 ? 'green' : 'grey');
            if ($i < 2) {
                $this->line($cx - $w * 0.27 - $r * 0.06, $y, $cx - $w * 0.27 - $r * 0.01, $y + $r * 0.05, $r * 0.035, 'white');
                $this->line($cx - $w * 0.27 - $r * 0.01, $y + $r * 0.05, $cx - $w * 0.27 + $r * 0.07, $y - $r * 0.05, $r * 0.035, 'white');
            }
            $this->rrect($cx + $w * 0.1, $y - $r * 0.04, $w * 0.42, $r * 0.06, $r * 0.03, 'grey');
            $this->rrect($cx + $w * 0.02, $y + $r * 0.07, $w * 0.26, $r * 0.05, $r * 0.025, 'grey', 50);
        }
    }

    private function m_globe($cx, $cy, $r, $cur) {
        $R = $r * 0.85;
        $this->circle($cx + 7, $cy + 10, $R, 'bgdark', 60);
        $this->circle($cx, $cy, $R, 'accent');
        $this->circle($cx - $R * 0.25, $cy - $R * 0.25, $R * 0.55, 'accentL', 70);
        foreach ([0.35, 0.72] as $k) $this->arc_line($cx, $cy, $R * $k, $R, 0, 360, $r * 0.035, 'accentD');
        $this->line($cx, $cy - $R, $cx, $cy + $R, $r * 0.035, 'accentD');
        foreach ([-0.5, 0, 0.5] as $k) {
            $hw = sqrt(1 - $k * $k) * $R;
            $this->line($cx - $hw, $cy + $k * $R, $cx + $hw, $cy + $k * $R, $r * 0.035, 'accentD');
        }
        $this->arc_line($cx, $cy, $R, $R, 0, 360, $r * 0.05, 'accentD');
        // orbiting chip
        $this->circle($cx + $R * 0.85, $cy - $R * 0.8, $r * 0.22, 'red');
        $this->circle($cx + $R * 0.85, $cy - $R * 0.8, $r * 0.13, 'white');
        $this->text_center($cx + $R * 0.85, $cy - $R * 0.8, $r * 0.12, $cur, 'red');
    }
}
