<?php
/**
 * XML sitemap, served at /sitemap.xml (see the rewrite in .htaccess).
 * It is built from includes/content.php, so new articles appear automatically.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/comparison.php';

header('Content-Type: application/xml; charset=UTF-8');

$newest = function (array $articles): string {
    return $articles ? max(array_column($articles, 'updated')) : date('Y-m-d');
};

$urls = [];
$urls[] = ['/', $newest(gw_articles_all()), 'daily', '1.0'];
foreach (gw_pages() as $p) {
    if (in_array($p['path'], ['/best-online-casinos/', '/online-casino-payment-methods/'], true) && GW_COMPARISON_IS_SAMPLE && GW_SHOW_COMPARISON) { continue; }   // noindex while sample data is on
    $urls[] = [$p['path'], $p['lastmod'], 'monthly', '0.9'];
}
foreach (gw_categories() as $slug => $c) {
    $urls[] = [$c['path'], $newest(gw_articles($slug)), 'weekly', '0.7'];
}
foreach (gw_articles() as $a) {
    $urls[] = ['/' . $a['slug'] . '/', $a['updated'], 'monthly', '0.8'];
}
foreach (gw_site_pages() as $p) {
    $urls[] = [$p['path'], $p['lastmod'], 'yearly', '0.4'];
}

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
foreach ($urls as [$path, $lastmod, $freq, $prio]) {
    echo "  <url>\n";
    echo '    <loc>' . htmlspecialchars(gw_abs($path), ENT_XML1) . "</loc>\n";
    echo '    <lastmod>' . $lastmod . "</lastmod>\n";
    echo '    <changefreq>' . $freq . "</changefreq>\n";
    echo '    <priority>' . $prio . "</priority>\n";
    echo "  </url>\n";
}
echo "</urlset>\n";