<?php
/** Custom 404 page. Apache/LiteSpeed serves it through ErrorDocument in .htaccess. */
http_response_code(404);
require __DIR__ . '/includes/functions.php';

$seo = [
    'title'        => 'Page not found',
    'description'  => 'The page you were looking for could not be found. Browse our casino guides or search the magazine.',
    'path'         => '/',
    'robots'       => 'noindex,follow',
    'no_canonical' => true,
    'body_class'   => 'is-error',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap err-page">
    <h1>That page is not here</h1>
    <p>The link may be old or mistyped. Try the search above, or head to one of these:</p>
    <ul class="chips">
      <li><a href="/">Homepage</a></li>
      <li><a href="/best-online-casinos/">Best online casinos</a></li>
      <li><a href="/category/casino-guides/">Casino guides</a></li>
      <li><a href="/category/casino-news/">Casino news</a></li>
    </ul>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
