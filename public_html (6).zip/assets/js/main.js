/* GrandWhisper - main.js
   1. The mobile menu.
   2. Keeps --head-h (the sticky header's height) up to date, and highlights the current table-of-contents link
      while you scroll. Everything still works without JavaScript. */

/* 1. Mobile menu */
(function () {
  var toggle = document.querySelector('.nav-toggle');
  var nav = document.getElementById('site-nav');
  if (!toggle || !nav) return;

  function setOpen(open) {
    nav.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  }

  toggle.addEventListener('click', function () {
    setOpen(!nav.classList.contains('is-open'));
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && nav.classList.contains('is-open')) {
      setOpen(false);
      toggle.focus();
    }
  });
})();

/* 2. Sticky header height + table-of-contents highlight */
(function () {
  var head = document.querySelector('.site-head');

  function setHeadHeight() {
    if (head) document.documentElement.style.setProperty('--head-h', head.offsetHeight + 'px');
  }
  setHeadHeight();
  window.addEventListener('resize', setHeadHeight);
  if (window.ResizeObserver && head) new ResizeObserver(setHeadHeight).observe(head);

  var toc = document.querySelector('.lp-toc, .toc');
  if (!toc) return;

  var items = [].slice.call(toc.querySelectorAll('a[href^="#"]')).map(function (a) {
    var el = document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1)));
    return el ? { a: a, el: el } : null;
  }).filter(Boolean);
  if (!items.length) return;

  // Always go through the sections in the order they appear on the page.
  items.sort(function (x, y) {
    return x.el.compareDocumentPosition(y.el) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
  });

  var current = null, queued = false;

  function update() {
    queued = false;
    var line = (head ? head.offsetHeight : 0) + 40;   // a section counts as "current" once its top passes this line
    var active = items[0];
    for (var i = 0; i < items.length; i++) {
      if (items[i].el.getBoundingClientRect().top <= line) active = items[i]; else break;
    }
    if (window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 4) {
      active = items[items.length - 1];                // at the very bottom, highlight the last link
    }
    if (active === current) return;
    current = active;

    items.forEach(function (it) {
      var on = it === active;
      it.a.classList.toggle('is-active', on);
      if (on) it.a.setAttribute('aria-current', 'location'); else it.a.removeAttribute('aria-current');
    });

    // If the sidebar is scrollable, keep the highlighted link in view inside it.
    var box = active.a.closest('.lp-side');
    if (box && box.scrollHeight > box.clientHeight) {
      var ar = active.a.getBoundingClientRect(), br = box.getBoundingClientRect();
      if (ar.top < br.top + 8 || ar.bottom > br.bottom - 8) {
        box.scrollTop += ar.top - br.top - box.clientHeight / 3;
      }
    }
  }

  function queue() {
    if (!queued) { queued = true; requestAnimationFrame(update); }
  }
  window.addEventListener('scroll', queue, { passive: true });
  window.addEventListener('resize', queue);
  update();
})();