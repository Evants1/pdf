/* GrandWhisper page extras: back-to-top button and share bar behaviour. No third-party code, no tracking. */
(function () {
  'use strict';

  /* Back to top: appears after the visitor has scrolled down. */
  var top = document.querySelector('.to-top');
  if (top) {
    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var ticking = false;
    var update = function () {
      var y = window.pageYOffset || document.documentElement.scrollTop || 0;
      if (y > 500) { top.removeAttribute('hidden'); } else { top.setAttribute('hidden', ''); }
      ticking = false;
    };
    window.addEventListener('scroll', function () {
      if (!ticking) { ticking = true; window.requestAnimationFrame(update); }
    }, { passive: true });
    top.addEventListener('click', function () {
      window.scrollTo({ top: 0, behavior: reduce ? 'auto' : 'smooth' });
      var main = document.getElementById('main');
      if (main) { main.setAttribute('tabindex', '-1'); main.focus({ preventScroll: true }); }
    });
    update();
  }

  /* Share bar. */
  var share = document.querySelector('.share');
  if (!share) { return; }
  var toggle = share.querySelector('.share-toggle');
  var url = share.getAttribute('data-url') || window.location.href;
  var title = share.getAttribute('data-title') || document.title;
  var note = share.querySelector('.share-note');

  var close = function () {
    if (share.classList.contains('is-open')) {
      share.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }
  };

  /* Narrow screens: use the phone's own share sheet when there is one, otherwise open the short list. */
  toggle.addEventListener('click', function () {
    if (navigator.share) {
      navigator.share({ title: title, url: url }).catch(function () {});
      return;
    }
    var open = share.classList.toggle('is-open');
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  document.addEventListener('click', function (e) { if (!share.contains(e.target)) { close(); } });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') { close(); } });

  /* Copy link. */
  var copy = share.querySelector('.sh--copy');
  if (copy) {
    var done = function (ok) {
      copy.classList.add('is-copied');
      if (note) { note.textContent = ok ? 'Link copied' : 'Copy this address: ' + url; }
      window.setTimeout(function () { copy.classList.remove('is-copied'); }, 1800);
    };
    var fallback = function () {
      var t = document.createElement('textarea');
      t.value = url; t.setAttribute('readonly', '');
      t.style.position = 'fixed'; t.style.opacity = '0';
      document.body.appendChild(t); t.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (err) { ok = false; }
      document.body.removeChild(t);
      done(ok);
    };
    copy.addEventListener('click', function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(url).then(function () { done(true); }, fallback);
      } else { fallback(); }
    });
  }
})();
