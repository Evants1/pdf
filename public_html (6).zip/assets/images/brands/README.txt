Brand logos for the comparison table (optional).
Upload square images here, about 96 x 96 px (PNG, WebP or SVG), for example aurora.webp.
Then add 'logo' => 'aurora.webp' to that brand in includes/comparison.php.
Without a logo, a coloured initial tile is shown instead.
Only use logos you have permission to use.
