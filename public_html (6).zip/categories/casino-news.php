<?php
/**
 * Category page: Casino News (served at /category/casino-news/).
 *
 * The articles are grouped by topic below. To move an article to another group, move its slug in $groups.
 * Any article that is not listed in a group still appears at the bottom under "More articles", so a new article is never lost.
 * The introduction text and the one-line group descriptions are a DRAFT written for you: edit them freely.
 */
require __DIR__ . '/../includes/functions.php';

$cat  = gw_category('casino-news');
$list = gw_articles('casino-news');

$groups = [
    'law' => [
        'title' => 'Law and regulation',
        'text'  => 'What Australian law says about online casinos, who enforces it, and how to read reports of reform.',
        'slugs' => ['online-gambling-laws-in-australia-2026', 'understanding-australian-online-gambling-regulations', 'online-gambling-laws-in-australia', 'online-casinos-australia-pros-cons-legality'],
    ],
    'crypto' => [
        'title' => 'Crypto and payments',
        'text'  => 'How Bitcoin and other crypto payments work at casinos, what they cost, and where the risks sit.',
        'slugs' => ['crypto-casinos-australia-bitcoin-gambling-guide', 'crypto-casinos-explained-benefits-and-risks', 'bitcoin-casinos-australia-why-crypto'],
    ],
    'play' => [
        'title' => 'Live dealer and mobile play',
        'text'  => 'How live tables and phone play work behind the scenes, and what to watch for on each.',
        'slugs' => ['live-dealer-casino-games-how-they-work', 'live-casino-australia-how-real-dealers-work', 'mobile-casino-gaming-apps-vs-browser-2026', 'mobile-casino-gaming-apps-vs-browser'],
    ],
    'trends' => [
        'title' => 'Trends and new sites',
        'text'  => 'Where the industry is heading in 2026, and how to judge a newly launched casino.',
        'slugs' => ['online-casino-trends-australia-2026', 'new-online-casinos-australia-2026'],
    ],
];

// index the articles by slug, build each group in the order above, and collect anything not placed
$bySlug = [];
foreach ($list as $a) { $bySlug[$a['slug']] = $a; }
$placed = [];
foreach ($groups as $k => $g) {
    $groups[$k]['items'] = [];
    foreach ($g['slugs'] as $s) {
        if (isset($bySlug[$s])) { $groups[$k]['items'][] = $bySlug[$s]; $placed[$s] = true; }
    }
}
$more = array_values(array_filter($list, fn($a) => !isset($placed[$a['slug']])));
if ($more) { $groups['more'] = ['title' => 'More articles', 'text' => '', 'items' => $more]; }

// structured data: this page is a collection that lists the guides, in the order shown on the page
$itemList = [];
$pos = 1;
foreach ($groups as $g) {
    foreach ($g['items'] as $a) {
        $itemList[] = ['@type' => 'ListItem', 'position' => $pos++, 'url' => gw_abs('/' . $a['slug'] . '/'), 'name' => $a['title']];
    }
}

$seo = [
    'title'       => 'Casino News and Explainers',
    'description' => 'Explainers and analysis on how online casino technology, payments and regulation work, from crypto and live dealer games to mobile play and licensing.',
    'path'        => $cat['path'],
    'image'       => 'pages/casino-news.jpg',
    'image_alt'   => $cat['alt'],
    'body_class'  => 'is-category',
    'breadcrumbs' => [['Home', '/'], ['Casino News', $cat['path']]],
    'schema'      => [[
        '@type'      => 'CollectionPage',
        '@id'        => gw_abs($cat['path']) . '#collection',
        'name'       => 'Casino News',
        'url'        => gw_abs($cat['path']),
        'inLanguage' => 'en-AU',
        'isPartOf'   => ['@id' => gw_abs('/') . '#website'],
        'mainEntity' => ['@type' => 'ItemList', 'numberOfItems' => count($itemList), 'itemListElement' => $itemList],
    ]],
    'head_extra'  => '<style>
.cat-intro{max-width:46rem;padding-top:clamp(1.8rem,4vw,2.6rem)}
.cat-intro p{margin:0 0 1rem;font-size:1.05rem;line-height:1.7}
.cat-jump{display:flex;flex-wrap:wrap;gap:.5rem;margin:1.3rem 0 .2rem;padding:0;list-style:none}
.cat-jump a{display:inline-block;padding:.38rem .85rem;border:1px solid var(--line,#d8d3e6);border-radius:999px;font-size:.9rem;text-decoration:none;background:var(--white,#fff)}
.cat-jump a:hover,.cat-jump a:focus-visible{border-color:currentColor}
.cat-group{padding-top:clamp(1.6rem,3.5vw,2.4rem)}
.cat-group h2{margin:0 0 .35rem}
.cat-group>p{margin:0;color:var(--ink-2,#555);max-width:44rem}
.cat-group .cat-grid{padding-block:1.2rem 0}
.cat-end{padding-bottom:clamp(2.5rem,5vw,4rem)}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
  <header class="cat-head">
    <div class="wrap cat-head-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <h1>Casino News</h1>
        <p class="lead">How the technology, payments and rules behind online casinos are changing, explained without hype. We focus on what a development means for players, not on press releases or offers.</p>
      </div>
      <?= gw_img('pages/casino-news', $cat['alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 460px, 100vw']) ?>
    </div>
  </header>

  <div class="wrap cat-intro">
    <p>These explainers look at how online casino technology, payments and regulation work, and how they are changing. Each one is written to tell you what a development means for you as a player, not to repeat an announcement or promote an offer.</p>
    <p>They don't recommend casinos. Online casino games can't lawfully be offered to people in Australia under the Interactive Gambling Act 2001, so each article starts with the legal position, and where a rule or reform is described as proposed or unconfirmed it says so. Rules change, so the regulator's own pages always have the final word. Looking for step-by-step advice? See our <a href="/category/casino-guides/">casino guides</a>.</p>
    <nav aria-label="Article topics">
      <ul class="cat-jump">
<?php foreach ($groups as $k => $g): if (!$g['items']) continue; ?>
        <li><a href="#<?= e($k) ?>"><?= e($g['title']) ?></a></li>
<?php endforeach; ?>
      </ul>
    </nav>
  </div>

<?php foreach ($groups as $k => $g): if (!$g['items']) continue; ?>
  <section class="wrap cat-group" id="<?= e($k) ?>" aria-labelledby="<?= e($k) ?>-title">
    <h2 id="<?= e($k) ?>-title"><?= e($g['title']) ?></h2>
<?php if ($g['text']): ?>
    <p><?= e($g['text']) ?></p>
<?php endif; ?>
    <div class="cat-grid">
<?php foreach ($g['items'] as $a) { echo gw_card($a, 'std', 3); } ?>
    </div>
  </section>

<?php endforeach; ?>
  <div class="wrap cat-other cat-end">
    <p>Looking for how-to advice instead? Browse our <a href="/category/casino-guides/">casino guides</a>, or start with <a href="/safe-and-trusted-online-casinos/">how to identify a safe and trusted casino</a>. If gambling is causing you stress, free and confidential help is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a>.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
