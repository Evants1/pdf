<?php
/**
 * Category page: Casino Guides (served at /category/casino-guides/).
 *
 * The guides are grouped by topic below. To move a guide to another group, move its slug in $groups.
 * Any guide that is not listed in a group still appears at the bottom under "More guides", so a new article is never lost.
 * The introduction text and the one-line group descriptions are a DRAFT written for you: edit them freely.
 */
require __DIR__ . '/../includes/functions.php';

$cat  = gw_category('casino-guides');
$list = gw_articles('casino-guides');

$groups = [
    'choosing' => [
        'title' => 'Choosing and judging a casino',
        'text'  => 'How to size up a site before you sign up, and how to read "best casino" lists critically.',
        'slugs' => ['how-to-find-the-best-online-casino-australia', 'how-to-choose-a-real-money-online-casino', 'how-to-choose-a-real-money-online-casino-australia', 'best-online-casinos-australia-2026'],
    ],
    'bonuses' => [
        'title' => 'Welcome bonuses and no-deposit offers',
        'text'  => 'What bonus terms mean, how wagering is calculated, and how to compare two offers fairly.',
        'slugs' => ['how-casino-welcome-bonuses-work', 'how-casino-welcome-bonuses-work-in-australia', 'how-casino-welcome-bonuses-are-calculated', 'australian-casino-welcome-bonuses-comparison', 'best-casino-bonuses-for-australian-players', 'no-deposit-bonuses-australia', 'best-no-deposit-casino-offers-australia'],
    ],
    'withdrawals' => [
        'title' => 'Withdrawals and payout speed',
        'text'  => 'Why some withdrawals land quickly and others stall, and what to read in the terms before you deposit.',
        'slugs' => ['how-fast-do-online-casinos-pay-out-australia', 'what-affects-casino-withdrawal-speed', 'how-to-withdraw-from-online-casinos-australia', 'how-casino-withdrawals-work-speed-and-limits', 'casino-withdrawal-speed-test-what-matters', 'instant-withdrawal-casinos-australia', 'instant-payout-casinos-australia', 'top-australian-casino-sites-with-fastest-withdrawals'],
    ],
    'kyc' => [
        'title' => 'ID checks and verification',
        'text'  => 'What documents are asked for, why the first withdrawal is slower, and how to avoid delays.',
        'slugs' => ['kyc-verification-at-online-casinos', 'kyc-verification-at-online-casinos-australia'],
    ],
    'games' => [
        'title' => 'Pokies, RTP and casino games',
        'text'  => 'How return to player and volatility work, with the arithmetic in Australian dollars.',
        'slugs' => ['understanding-rtp-and-volatility-in-online-slots', 'understanding-rtp-and-volatility-in-online-slots-australia', 'pokies-and-slots-australia-rtp-themes-paylines', 'high-rtp-slots-australia', 'jackpot-pokies-australia', 'australian-players-top-10-casino-games-2026'],
    ],
    'formats' => [
        'title' => 'Live dealer, mobile and crypto',
        'text'  => 'How live tables, phone apps and crypto payments work, and where each can go wrong.',
        'slugs' => ['live-dealer-casino-games-explained', 'live-dealer-casino-australia', 'live-casinos-australia-what-to-check', 'mobile-casino-apps-australia', 'crypto-casinos-australia-2026-how-to-evaluate'],
    ],
    'control' => [
        'title' => 'Staying in control: limits and self-exclusion',
        'text'  => 'Deposit and loss limits, BetStop, bank blocks and free support, and what each tool does and does not cover.',
        'slugs' => ['how-to-set-deposit-and-loss-limits-australia', 'responsible-gaming-tools-every-australian-should-use', 'responsible-gambling-tools-limits-and-self-exclusion', 'responsible-gambling-tools-limits-and-self-exclusion-australia', 'self-exclusion-australia-guide'],
    ],
];

// index the guides by slug, build each group in the order above, and collect anything not placed
$bySlug = [];
foreach ($list as $a) { $bySlug[$a['slug']] = $a; }
$placed = [];
foreach ($groups as $k => $g) {
    $groups[$k]['items'] = [];
    foreach ($g['slugs'] as $s) {
        if (isset($bySlug[$s])) { $groups[$k]['items'][] = $bySlug[$s]; $placed[$s] = true; }
    }
}
$more = array_values(array_filter($list, fn($a) => !isset($placed[$a['slug']])));
if ($more) { $groups['more'] = ['title' => 'More guides', 'text' => '', 'items' => $more]; }

// structured data: this page is a collection that lists the guides, in the order shown on the page
$itemList = [];
$pos = 1;
foreach ($groups as $g) {
    foreach ($g['items'] as $a) {
        $itemList[] = ['@type' => 'ListItem', 'position' => $pos++, 'url' => gw_abs('/' . $a['slug'] . '/'), 'name' => $a['title']];
    }
}

$seo = [
    'title'       => 'Casino Guides: Bonuses, Withdrawals and Safety',
    'description' => 'Practical online casino guides covering how to choose a casino, welcome bonuses, withdrawal speed, ID checks, slot RTP and responsible gambling tools.',
    'path'        => $cat['path'],
    'image'       => 'pages/casino-guides.jpg',
    'image_alt'   => $cat['alt'],
    'body_class'  => 'is-category',
    'breadcrumbs' => [['Home', '/'], ['Casino Guides', $cat['path']]],
    'schema'      => [[
        '@type'      => 'CollectionPage',
        '@id'        => gw_abs($cat['path']) . '#collection',
        'name'       => 'Casino Guides',
        'url'        => gw_abs($cat['path']),
        'inLanguage' => 'en-AU',
        'isPartOf'   => ['@id' => gw_abs('/') . '#website'],
        'mainEntity' => ['@type' => 'ItemList', 'numberOfItems' => count($itemList), 'itemListElement' => $itemList],
    ]],
    'head_extra'  => '<style>
.cat-intro{max-width:46rem;padding-top:clamp(1.8rem,4vw,2.6rem)}
.cat-intro p{margin:0 0 1rem;font-size:1.05rem;line-height:1.7}
.cat-jump{display:flex;flex-wrap:wrap;gap:.5rem;margin:1.3rem 0 .2rem;padding:0;list-style:none}
.cat-jump a{display:inline-block;padding:.38rem .85rem;border:1px solid var(--line,#d8d3e6);border-radius:999px;font-size:.9rem;text-decoration:none;background:var(--white,#fff)}
.cat-jump a:hover,.cat-jump a:focus-visible{border-color:currentColor}
.cat-group{padding-top:clamp(1.6rem,3.5vw,2.4rem)}
.cat-group h2{margin:0 0 .35rem}
.cat-group>p{margin:0;color:var(--ink-2,#555);max-width:44rem}
.cat-group .cat-grid{padding-block:1.2rem 0}
.cat-end{padding-bottom:clamp(2.5rem,5vw,4rem)}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
  <header class="cat-head">
    <div class="wrap cat-head-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <h1>Casino Guides</h1>
        <p class="lead">Step-by-step help for the questions that come up before, during and after you sign up: what bonus terms really mean, why a withdrawal stalls, how game maths works, and how to stay in control.</p>
      </div>
      <?= gw_img('pages/casino-guides', $cat['alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 460px, 100vw']) ?>
    </div>
  </header>

  <div class="wrap cat-intro">
    <p>These guides explain how online casinos work, so you can judge any site's claims for yourself. They cover welcome bonuses and their small print, withdrawals and ID checks, how pokies and their return to player work, and the tools that help you stay in control of your spending.</p>
    <p>They don't recommend casinos. Online casino games can't lawfully be offered to people in Australia under the Interactive Gambling Act 2001, so each guide starts with the legal position and shows you how to check a site against the regulator's register and blocked list. New here? Start with <a href="/how-to-find-the-best-online-casino-australia/">how to find the best online casino in Australia</a>, then pick a topic below.</p>
    <nav aria-label="Guide topics">
      <ul class="cat-jump">
<?php foreach ($groups as $k => $g): if (!$g['items']) continue; ?>
        <li><a href="#<?= e($k) ?>"><?= e($g['title']) ?></a></li>
<?php endforeach; ?>
      </ul>
    </nav>
  </div>

<?php foreach ($groups as $k => $g): if (!$g['items']) continue; ?>
  <section class="wrap cat-group" id="<?= e($k) ?>" aria-labelledby="<?= e($k) ?>-title">
    <h2 id="<?= e($k) ?>-title"><?= e($g['title']) ?></h2>
<?php if ($g['text']): ?>
    <p><?= e($g['text']) ?></p>
<?php endif; ?>
    <div class="cat-grid">
<?php foreach ($g['items'] as $a) { echo gw_card($a, 'std', 3); } ?>
    </div>
  </section>

<?php endforeach; ?>
  <div class="wrap cat-other cat-end">
    <p>Want the bigger picture? Read our permanent guides to <a href="/best-online-casinos/">the best online casinos</a> and <a href="/online-casino-bonuses/">online casino bonuses</a>, or browse <a href="/category/casino-news/">casino news and explainers</a>. If gambling is causing you stress, free and confidential help is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a>.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
