<?php
/**
 * Copyright and DMCA requests (served at /copyright-and-dmca/).
 *
 * OWNER NOTES (read before publishing). This is general information, not legal advice. Have a qualified Australian lawyer
 * read it, especially sections 3 to 6.
 * 1. Section 1 says the text and illustrations on the site are written and made for it. Only keep that if it is true of every
 *    page. If any text came from another source, replace it or get written permission before relying on this page.
 * 2. Section 9 (credits) says the text font is DM Sans under the SIL Open Font License. Confirm that on the font's own page.
 * 3. No response time is promised on purpose. If you decide to promise one (for example "within 5 business days"), add it
 *    in section 5, and only if you will really meet it.
 * 4. A "DMCA designated agent" registration with the US Copyright Office is for platforms that host OTHER people's content.
 *    A publisher site like this one does not need it. Do not claim US "safe harbour" on this page.
 * 5. Notices arrive at CONTACT_EMAIL (includes/config.php) and through the contact form topic "Copyright or takedown notice".
 *    Make sure both reach a mailbox you read.
 * 6. ADDED in the latest update: the "In short" box, the jump list, section 3 (what counts as a copyright concern), the
 *    step-by-step list under section 5, section 7 (using our content and asking permission), the sources table in section 9,
 *    and section 10 (quick answers). Section 7 repeats what your Terms (section 8) already say. If you change one, change the other.
 * 7. A postal address is not shown because none has been supplied. Formal notices often ask for one. When you have a business
 *    address you are happy to publish, add it in section 11 (and in includes/operator.php).
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/operator.php';
require_once __DIR__ . '/includes/comparison.php';

$updated = '2026-11-25';

$seo = [
    'title'       => 'Copyright and DMCA Takedown Requests',
    'description' => 'How to report a copyright concern about GrandWhisper content: what to send, what we do with a notice and how we treat third-party names and images.',
    'path'        => '/copyright-and-dmca/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Copyright and DMCA', '/copyright-and-dmca/']],
    'schema'      => [[
        '@type'        => 'WebPage',
        '@id'          => gw_abs('/copyright-and-dmca/') . '#webpage',
        'url'          => gw_abs('/copyright-and-dmca/'),
        'name'         => 'Copyright and DMCA Takedown Requests',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Copyright and DMCA requests</h1>
      <p class="lead">We respect other people's rights and ask that they respect ours. This page explains how to report a copyright concern about something on GrandWhisper, and what happens next.</p>
    </div>
  </header>

  <div class="wrap">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></p>

      <nav aria-label="On this page">
        <ul class="chips">
          <li><a href="#notice">How to send a notice</a></li>
          <li><a href="#what">What counts as copyright</a></li>
          <li><a href="#process">What we do</a></li>
          <li><a href="#permission">Using our content</a></li>
          <li><a href="#law">The law</a></li>
          <li><a href="#credits">Credits</a></li>
          <li><a href="#faq">Quick answers</a></li>
          <li><a href="#contact">Contact</a></li>
        </ul>
      </nav>

      <div class="rg-help">
        <h2 style="margin-top:0">In short</h2>
        <p style="margin-bottom:.6rem"><strong>To report a copyright concern,</strong> email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> with the subject &ldquo;Copyright notice&rdquo;, or use the &ldquo;Copyright or takedown notice&rdquo; topic on our <a href="/contact/">contact page</a>.</p>
        <p style="margin-bottom:.6rem"><strong>Include</strong> your contact details, the work you say was copied, the web address of the page, two short statements and your signature. The full list is in <a href="#notice">section 4</a>.</p>
        <p style="margin-bottom:0"><strong>We review every notice</strong> carefully and fairly. Factual errors, privacy concerns and complaints about casinos go to different places: see <a href="#what">section 3</a>.</p>
      </div>

      <h2 id="approach">1. Our approach to content</h2>
      <p>The articles, tables, worked examples and illustrations on GrandWhisper are written and made for this site. Our guides explain how online casinos and gambling rules work. They do not reproduce other publishers' articles, and we do not use operator logos, screenshots or promotional banners.</p>
<?php if (gw_sample_visible()): ?>
      <p>The comparison card shown in some articles is an illustration of a fictional brand with invented figures. It is not copied from a real operator.</p>
<?php endif; ?>
      <p>If you believe something on this site copies your work, please tell us using the steps below.</p>

      <h2 id="names">2. Third-party names and logos</h2>
      <p>We mention companies, products, games and payment methods by name so readers can understand what an article is about. Those names belong to their owners. Mentioning a name does not mean that the owner endorses us or that we endorse it, and we do not use their logos.</p>
      <p>If you are a rights holder and think a name or reference on this site is misleading, please contact us and explain why.</p>

      <h2 id="what">3. What counts as a copyright concern</h2>
      <p>Copyright protects original work such as text, images, graphics, tables and layouts. Other complaints need different handling, so this table shows where each kind belongs.</p>
      <div class="table-wrap">
      <table class="data">
        <caption>Where to send each kind of concern</caption>
        <thead><tr><th scope="col">Your concern</th><th scope="col">Is it a copyright matter?</th><th scope="col">What to do</th></tr></thead>
        <tbody>
          <tr><th scope="row">Text, an image, a table or a graphic on our site was copied from your work</th><td>Yes</td><td>Send a copyright notice, as described in section 4</td></tr>
          <tr><th scope="row">Our page closely copies your article or layout</th><td>Yes</td><td>Send a copyright notice, and say which parts are copied</td></tr>
          <tr><th scope="row">A company, product or brand name is used in a way you think is misleading</th><td>Not usually. It is more often a branding or trademark question</td><td>Contact us and explain what is misleading (section 2)</td></tr>
          <tr><th scope="row">A fact on one of our pages is wrong</th><td>No</td><td>Use the &ldquo;Report an error or correction&rdquo; topic on the <a href="/contact/">contact page</a></td></tr>
          <tr><th scope="row">Your personal information appears on our site, or you have a privacy question</th><td>No</td><td>Contact us, and see our <a href="/privacy-policy/">Privacy Policy</a></td></tr>
          <tr><th scope="row">A complaint about a casino, a bonus or a payout</th><td>No</td><td>We cannot help recover money or judge individual disputes. Our <a href="/safe-and-trusted-online-casinos/">trusted casinos guide</a> explains where to take a complaint</td></tr>
        </tbody>
      </table>
      </div>

      <h2 id="notice">4. How to send a copyright notice</h2>
      <p>Email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> with the subject &ldquo;Copyright notice&rdquo;, or use our <a href="/contact/">contact page</a> and choose &ldquo;Copyright or takedown notice&rdquo;. Please include:</p>
      <ol>
        <li>Your full name and contact details, including an email address and a postal address or telephone number.</li>
        <li>A description of the copyrighted work you say has been copied, with a link to the original if it is online.</li>
        <li>The web address (URL) of the page on GrandWhisper where the material appears, and a description of the material.</li>
        <li>A statement that you believe in good faith that the use is not authorised by the copyright owner, its agent or the law.</li>
        <li>A statement that the information in your notice is accurate, and that you are the copyright owner or are authorised to act for the owner.</li>
        <li>Your physical or electronic signature.</li>
      </ol>
      <p>A notice that leaves out these details may take longer to deal with, because we may need to ask you for them. Please send only copyright concerns here. To report a factual error, use the &ldquo;Report an error or correction&rdquo; topic on the contact page instead.</p>

      <h2 id="process">5. What we do</h2>
      <p>We review each notice carefully and fairly. Where a notice is complete and the claim looks valid, we remove or change the material promptly. Where we need more information, we will email you. Where we disagree with a claim, we will explain why.</p>
      <p>We may keep a record of notices and of our responses, and we may share them where the law requires. If you send your notice to our web host or to a search engine instead, we will deal with it when it is passed on to us. Writing to us directly is usually quicker.</p>
      <h3>What to expect, step by step</h3>
      <ol>
        <li><strong>Check.</strong> We check that the notice has the details listed in section 4, and ask for anything that is missing.</li>
        <li><strong>Compare.</strong> We compare the page on our site with the work you describe.</li>
        <li><strong>Decide.</strong> We decide whether the claim is valid, and whether the material should be removed, changed or kept.</li>
        <li><strong>Act and reply.</strong> We make any change that is needed and email you the outcome.</li>
      </ol>

      <h2 id="false">6. False or abusive notices</h2>
      <p>Please send a notice only if you are the rights holder or are authorised to act for them. Knowingly making a false claim can have legal consequences. We assess each claim on its merits, and we do not remove material only because a complaint was made.</p>

      <h2 id="permission">7. Using our content and asking permission</h2>
      <p>You may share links to our pages and quote short extracts where the law permits, as long as you give appropriate attribution and a link to the original page. Our <a href="/terms-and-conditions/">Terms and Conditions</a> (section 8) say the same.</p>
      <p>To use more than a short extract, or to republish an article, table or graphic, please ask first. Email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> with the subject &ldquo;Permission request&rdquo; and say what you want to use, where it will appear and for how long. We will consider each request. Permission is not given unless we confirm it in writing.</p>

      <h2 id="law">8. The law</h2>
      <p>Copyright in Australia is governed by the <em>Copyright Act 1968</em>. The United States Digital Millennium Copyright Act (DMCA) is a US law, but we handle notices that follow its usual format whichever country they come from. This page is general information and is not legal advice.</p>

      <h2 id="credits">9. Credits</h2>
      <p>Illustrations and article images are original GrandWhisper graphics. The site's text font is DM Sans, released under the SIL Open Font License. Our <a href="/terms-and-conditions/">Terms and Conditions</a> explain how you may use our content.</p>
      <div class="table-wrap">
      <table class="data">
        <caption>Where the content of this site comes from</caption>
        <thead><tr><th scope="col">Part of the site</th><th scope="col">Where it comes from</th></tr></thead>
        <tbody>
          <tr><th scope="row">Articles, tables and worked examples</th><td>Written for GrandWhisper</td></tr>
          <tr><th scope="row">Illustrations and article images</th><td>Original GrandWhisper graphics</td></tr>
          <tr><th scope="row">Text font</th><td>DM Sans, released under the SIL Open Font License</td></tr>
          <tr><th scope="row">Company, product, game and payment names</th><td>Named in text only. They belong to their owners, and we do not use their logos</td></tr>
<?php if (gw_sample_visible()): ?>
          <tr><th scope="row">Sample comparison card</th><td>A fictional brand with invented figures</td></tr>
<?php endif; ?>
        </tbody>
      </table>
      </div>

      <h2 id="faq">10. Quick answers</h2>
      <div class="faq">
        <details>
          <summary>Do I need a special form to send a notice?</summary>
          <p>No. Email <?= e(CONTACT_EMAIL) ?> or use the &ldquo;Copyright or takedown notice&rdquo; topic on the contact page. What matters is that the notice includes the details listed in section 4.</p>
        </details>
        <details>
          <summary>Do I have to be in Australia to send a notice?</summary>
          <p>No. We handle notices that follow the usual format whichever country they come from.</p>
        </details>
        <details>
          <summary>Will you remove the material straight away?</summary>
          <p>We review each notice. Where it is complete and the claim looks valid, we remove or change the material promptly. We do not remove material only because a complaint was made.</p>
        </details>
        <details>
          <summary>Can I send my notice to your web host or to Google instead?</summary>
          <p>You can, and we will deal with it when it is passed on to us. Writing to us directly is usually quicker.</p>
        </details>
        <details>
          <summary>My concern is that a fact on a page is wrong. Is this the right place?</summary>
          <p>No. Please use the &ldquo;Report an error or correction&rdquo; topic on the <a href="/contact/">contact page</a>, tell us which page and what is wrong, and include a source if you can.</p>
        </details>
        <details>
          <summary>Can I quote your articles on my own site?</summary>
          <p>You may quote short extracts where the law permits, with attribution and a link to the original page. For anything more, ask for permission first (section 7).</p>
        </details>
      </div>

      <h2 id="contact">11. Contact</h2>
<?php if (gw_operator_line() !== ''): ?>
      <p><?= e(gw_operator_line()) ?></p>
<?php endif; ?>
      <p>Email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> or use our <a href="/contact/">contact page</a>.</p>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
