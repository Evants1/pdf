<?php
/**
 * Copyright and DMCA requests (served at /copyright-and-dmca/).
 *
 * OWNER NOTES (read before publishing). This is general information, not legal advice. Have a qualified Australian lawyer
 * read it, especially sections 3 to 5.
 * 1. Section 1 says the text and illustrations on the site are written and made for it. Only keep that if it is true of every
 *    page. If any text came from another source, replace it or get written permission before relying on this page.
 * 2. Section 7 (credits) says the text font is DM Sans under the SIL Open Font License. Confirm that on the font's own page.
 * 3. No response time is promised on purpose. If you decide to promise one (for example "within 5 business days"), add it
 *    in section 4, and only if you will really meet it.
 * 4. A "DMCA designated agent" registration with the US Copyright Office is for platforms that host OTHER people's content.
 *    A publisher site like this one does not need it. Do not claim US "safe harbour" on this page.
 * 5. Notices arrive at CONTACT_EMAIL (includes/config.php) and through the contact form topic "Copyright or takedown notice".
 *    Make sure both reach a mailbox you read.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/operator.php';

$updated = '2026-11-20';

$seo = [
    'title'       => 'Copyright and DMCA Takedown Requests',
    'description' => 'How to report a copyright concern about GrandWhisper content: what to send, what we do with a notice and how we treat third-party names and images.',
    'path'        => '/copyright-and-dmca/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Copyright and DMCA', '/copyright-and-dmca/']],
    'schema'      => [[
        '@type'        => 'WebPage',
        '@id'          => gw_abs('/copyright-and-dmca/') . '#webpage',
        'url'          => gw_abs('/copyright-and-dmca/'),
        'name'         => 'Copyright and DMCA Takedown Requests',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Copyright and DMCA requests</h1>
      <p class="lead">We respect other people's rights and ask that they respect ours. This page explains how to report a copyright concern about something on GrandWhisper, and what happens next.</p>
    </div>
  </header>

  <div class="wrap">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></p>

      <h2>1. Our approach to content</h2>
      <p>The articles, tables, worked examples and illustrations on GrandWhisper are written and made for this site. Our guides explain how online casinos and gambling rules work. They do not reproduce other publishers' articles, and we do not use operator logos, screenshots or promotional banners.</p>
      <p>The comparison card shown in some articles is an illustration of a fictional brand with invented figures. It is not copied from a real operator.</p>
      <p>If you believe something on this site copies your work, please tell us using the steps below.</p>

      <h2>2. Third-party names and logos</h2>
      <p>We mention companies, products, games and payment methods by name so readers can understand what an article is about. Those names belong to their owners. Mentioning a name does not mean that the owner endorses us or that we endorse it, and we do not use their logos.</p>
      <p>If you are a rights holder and think a name or reference on this site is misleading, please contact us and explain why.</p>

      <h2>3. How to send a copyright notice</h2>
      <p>Email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> with the subject &ldquo;Copyright notice&rdquo;, or use our <a href="/contact/">contact page</a> and choose &ldquo;Copyright or takedown notice&rdquo;. Please include:</p>
      <ol>
        <li>Your full name and contact details, including an email address and a postal address or telephone number.</li>
        <li>A description of the copyrighted work you say has been copied, with a link to the original if it is online.</li>
        <li>The web address (URL) of the page on GrandWhisper where the material appears, and a description of the material.</li>
        <li>A statement that you believe in good faith that the use is not authorised by the copyright owner, its agent or the law.</li>
        <li>A statement that the information in your notice is accurate, and that you are the copyright owner or are authorised to act for the owner.</li>
        <li>Your physical or electronic signature.</li>
      </ol>
      <p>A notice that leaves out these details may take longer to deal with, because we may need to ask you for them. Please send only copyright concerns here. To report a factual error, use the &ldquo;Report an error or correction&rdquo; topic on the contact page instead.</p>

      <h2>4. What we do</h2>
      <p>We review each notice carefully and fairly. Where a notice is complete and the claim looks valid, we remove or change the material promptly. Where we need more information, we will email you. Where we disagree with a claim, we will explain why.</p>
      <p>We may keep a record of notices and of our responses, and we may share them where the law requires. If you send your notice to our web host or to a search engine instead, we will deal with it when it is passed on to us. Writing to us directly is usually quicker.</p>

      <h2>5. False or abusive notices</h2>
      <p>Please send a notice only if you are the rights holder or are authorised to act for them. Knowingly making a false claim can have legal consequences. We assess each claim on its merits, and we do not remove material only because a complaint was made.</p>

      <h2>6. The law</h2>
      <p>Copyright in Australia is governed by the <em>Copyright Act 1968</em>. The United States Digital Millennium Copyright Act (DMCA) is a US law, but we handle notices that follow its usual format whichever country they come from. This page is general information and is not legal advice.</p>

      <h2>7. Credits</h2>
      <p>Illustrations and article images are original GrandWhisper graphics. The site's text font is DM Sans, released under the SIL Open Font License. Our <a href="/terms-and-conditions/">Terms and Conditions</a> explain how you may use our content.</p>

      <h2>8. Contact</h2>
<?php if (gw_operator_line() !== ''): ?>
      <p><?= e(gw_operator_line()) ?></p>
<?php endif; ?>
      <p>Email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> or use our <a href="/contact/">contact page</a>.</p>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
