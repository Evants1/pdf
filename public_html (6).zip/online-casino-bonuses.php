<?php
/**
 * Permanent page: Online Casino Bonuses (served at /online-casino-bonuses/).
 * Educational guide to what bonuses are really worth. Names no operators and includes no bonus codes.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/comparison.php';

// Visible FAQ. The same array feeds the FAQPage structured data, so the two always match.
$faq = [
    ['q' => 'Are online casino bonuses worth it in Australia?', 'a' => 'Often not. Once rollover, game weighting, expiry and cash-out caps are counted, many offers have an effective value near zero or below. A few low-rollover offers may carry a small positive value on paper. Add the legal position and the weak recourse against offshore sites, and the risk side is considerable. Run the formula before claiming.'],
    ['q' => 'Is it legal to claim an online casino bonus in Australia?', 'a' => 'Under the Interactive Gambling Act 2001, operators are prohibited from providing online casino games to people in Australia, and the Act targets providers rather than customers. That does not make playing legal or safe, and customers have little recourse. This is not legal advice: check ACMA\'s website for the current position.'],
    ['q' => 'What is a good rollover requirement?', 'a' => 'There is no standard, and requirements vary widely between offers. Lower is better, and a rollover applied to the bonus only is far better than one applied to deposit plus bonus. Calculate the dollar turnover, estimate the cost using the game\'s real RTP, and compare it with the bonus. If the cost exceeds the bonus, it is a poor deal.'],
    ['q' => 'Can I withdraw a bonus straight away?', 'a' => 'Usually not. Bonuses typically must be cleared first, and a sticky bonus cannot be withdrawn at all, only the winnings it helps produce. Withdrawing early can forfeit the bonus and any winnings from it. Verification checks, pending periods and payout caps can also delay payment, so read the withdrawal terms before you deposit.'],
    ['q' => 'Do casino welcome bonuses in Australia come with free spins?', 'a' => 'Some do, as part of a package alongside a deposit match, but there is no rule. Free spins usually carry their own conditions: a fixed game, a set bet size, a rollover on winnings and a cash-out cap. Treat them as worth less than their face value and check their terms separately from the match bonus.'],
];

// INDEXING SWITCH FOR THIS PAGE. true = Google may index it (and it is listed in the sitemap).
// Set to false to hide the page from search engines. The fictional comparison table on this page is clearly
// labelled as an illustrative example. If you replace it with real operators, take Australian legal advice first.
$allowIndex = true;

// DATES. $updated is the date of the last real edit to this page (shown to readers and used in the schema).
// $legalChecked: set it to the date you personally verified the legal section against ACMA and the Federal Register
// of Legislation, for example '2026-12-01'. While it is null, nothing about a legal check is shown. Do not set it
// unless you have actually done the check.
$updated      = '2026-11-10';
$legalChecked = null;

$seo = [
    'title'       => 'Online Casino Bonuses Australia Explained',
    'description' => 'Understand online casino bonuses in Australia, including wagering requirements, rollover, free spins, withdrawal limits and how to calculate their real value.',
    'path'        => '/online-casino-bonuses/',
    'image'       => 'pages/online-casino-bonuses.jpg',
    'image_alt'   => 'Guide graphic with casino chips and the title Online Casino Bonuses Australia',
    // Indexing is controlled by $allowIndex above, NOT by the sample-table flag: this is an educational guide.
    'robots'      => $allowIndex ? 'index,follow,max-image-preview:large' : 'noindex,follow',
    'head_extra'  => '<link rel="preload" as="image" href="/assets/images/pages/online-casino-bonuses.webp" imagesrcset="/assets/images/pages/online-casino-bonuses-600.webp 600w, /assets/images/pages/online-casino-bonuses.webp 1200w" imagesizes="(min-width: 960px) 520px, 100vw" fetchpriority="high">',
    'body_class'  => 'is-landing',
    'breadcrumbs' => [['Home', '/'], ['Online Casino Bonuses', '/online-casino-bonuses/']],
    'schema'      => [
        [
            '@type'        => 'WebPage',
            '@id'          => gw_abs('/online-casino-bonuses/') . '#webpage',
            'url'          => gw_abs('/online-casino-bonuses/'),
            'name'         => 'Online Casino Bonuses Australia Explained',
            'dateModified' => $updated,
            'inLanguage'   => 'en-AU',
            'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
            'mainEntity'   => ['@id' => gw_abs('/online-casino-bonuses/') . '#article'],
        ],
        [
            '@type'            => 'Article',
            '@id'              => gw_abs('/online-casino-bonuses/') . '#article',
            'headline'         => 'Australian Online Casino Bonuses: What They Are Really Worth',
            'description'      => 'Understand online casino bonuses in Australia, including wagering requirements, rollover, free spins, withdrawal limits and how to calculate their real value.',
            'image'            => [gw_abs('/assets/images/pages/online-casino-bonuses.jpg')],
            'datePublished'    => '2026-11-08T08:00:00+00:00',
            'dateModified'     => $updated . 'T08:00:00+00:00',
            'author'           => ['@type' => 'Organization', 'name' => SITE_NAME . ' Editorial Team', 'url' => gw_abs('/about/')],
            'publisher'        => ['@id' => gw_abs('/') . '#organization'],
            'mainEntityOfPage' => ['@id' => gw_abs('/online-casino-bonuses/') . '#webpage'],
            'inLanguage'       => 'en-AU',
        ],
        [
            '@type'      => 'FAQPage',
            '@id'        => gw_abs('/online-casino-bonuses/') . '#faq',
            'isPartOf'   => ['@id' => gw_abs('/online-casino-bonuses/') . '#webpage'],
            'mainEntity' => array_map(fn($f) => [
                '@type' => 'Question',
                'name'  => $f['q'],
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => trim(html_entity_decode(strip_tags($f['a']), ENT_QUOTES, 'UTF-8'))],
            ], $faq),
        ],
    ],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">

  <header class="lp-hero on-dark">
    <div class="wrap lp-hero-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <p class="tag">Educational guide</p>
        <h1>Australian Online Casino Bonuses: What They Are Really Worth</h1>
        <p class="lead">A "$2,000 welcome package" is not $2,000 you can keep. It is a conditional credit with a turnover requirement, game restrictions, an expiry date and often a cap on what you can withdraw. This guide shows how to work out the real value. It names no casinos and lists no bonus codes.</p>
        <p class="lp-hero-meta cred">
          <span>Written by: <?= e(SITE_NAME) ?> Editorial Team</span>
          <span>Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></span>
          <span><a href="/about/">About us</a></span>
          <span><a href="/about/#disclosure">Affiliate disclosure</a></span>
          <span><a href="/contact/">Report an error</a></span>
        </p>
      </div>
      <figure class="lp-hero-art"><?= gw_img('pages/online-casino-bonuses', $seo['image_alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 520px, 100vw']) ?></figure>
    </div>
  </header>

  <section class="wrap cmp-sec" id="compare" aria-labelledby="compare-title">
<?php gw_comparison('bonus', 'Sample bonus comparison: the offer and the fine print', 'The biggest headline offer is rarely the best value. Brands here are ranked by bonus terms, with wagering, expiry and cash-out caps shown beside the offer. The brands are fictional and the figures invented.'); ?>
  </section>

  <div class="wrap lp-layout">
    <div class="lp-side">
      <?php gw_promo(); ?>
      <aside class="lp-toc" aria-label="On this page">
        <h2>On this page</h2>
        <ul>
          <li><a href="#compare">Comparison table</a></li>
          <li><a href="#short-answer">The short answer</a></li>
          <li><a href="#biggest">Why the biggest offer loses</a></li>
          <li><a href="#law">The legal position</a></li>
          <li><a href="#types">Bonus types explained</a></li>
          <li><a href="#rollover">Rollover and real cost</a></li>
          <li><a href="#free-spins">Free spins value</a></li>
          <li><a href="#calculator">Wagering calculator</a></li>
          <li><a href="#terms">Terms that shrink value</a></li>
          <li><a href="#worked">Worked comparison</a></li>
          <li><a href="#checklist">Before you claim</a></li>
          <li><a href="#responsible">Responsible gambling</a></li>
          <li><a href="#resources">Official resources</a></li>
          <li><a href="#editorial">Editorial information</a></li>
          <li><a href="#faq">FAQ</a></li>
        </ul>
      </aside>
      <aside class="help-card" aria-label="Need help">
        <p class="help-title">Need to talk to someone?</p>
        <p>Gambling Help Online is free and confidential, 24 hours a day.</p>
        <a class="help-num" href="tel:1800858858">1800 858 858</a>
      </aside>
    </div>

    <div class="lp-main lp-main--wide">

      <section class="lp-sec" id="short-answer">
        <h2>The short answer: headline value vs effective value</h2>
        <p>Australian online casino bonuses are almost always worth far less than the number in the advert. Once you do the arithmetic, many offers are worth close to nothing, and some cost you more in expected losses than they ever give back.</p>
        <div class="formula tldr" role="note" aria-label="Short summary">
          <p class="formula-label">In short</p>
          <ul class="checks">
            <li><strong>Headline is not value.</strong> What a bonus is worth is the bonus minus the expected cost of clearing it (turnover x house edge), minus anything lost to caps and exclusions.</li>
            <li><strong>The rollover base matters most.</strong> A multiple on deposit plus bonus can double the betting compared with the same multiple on the bonus alone.</li>
            <li><strong>Free spins and caps shrink value.</strong> Spins are worth their expected winnings, not their stake, and a cash-out cap limits the best case.</li>
            <li><strong>The law comes first.</strong> Operators are prohibited from offering online casino games to people in Australia, there is no Australian licence for them, and recourse is weak. Check <a href="https://www.acma.gov.au" rel="noopener">ACMA</a>.</li>
            <li><strong>If the numbers do not add up, walk away.</strong> Declining a bonus is always an option.</li>
          </ul>
        </div>
        <div class="keyfacts">
          <div class="kf"><span class="kf-top">Headline value</span><p>The figure in the advert: the match percentage, the maximum bonus, the number of free spins.</p></div>
          <div class="kf"><span class="kf-top">Effective value</span><p>What the offer is worth to you after the cost of meeting its terms.</p></div>
          <div class="kf"><span class="kf-top">Break-even rule</span><p>On a bonus-only rollover, break-even is roughly 1 divided by the house edge. At a 4% edge, that is 25x. This assumes 100% game contribution, a fully withdrawable bonus and no caps.</p></div>
        </div>
        <div class="formula" role="group" aria-label="The effective value formula">
          <p class="formula-label">The simplest version of the formula</p>
          <p class="formula-eq">Effective value = bonus amount &minus; (turnover required &times; house edge) &minus; anything lost to caps and exclusions</p>
          <p class="formula-note">Turnover is the total you must wager before the bonus, or winnings from it, can be withdrawn. The house edge is the average share of each bet the casino keeps over time. Multiply them and you get the average cost of clearing the bonus. If that cost is larger than the bonus, the offer is worth less than nothing in expectation. Any rollover at or above the break-even multiple wipes out the average value of the bonus.</p>
        </div>
        <aside class="lead-note">
          <strong>Two points first.</strong> Gambling is for adults only (18+), and no bonus makes it safer or guarantees a win. Online casino games, including online pokies, are not something operators are permitted to offer to people in Australia, and there is no Australian licence for them. The offers you see come from offshore sites, and your protections are weak. <a href="#law">The legal section below</a> explains this, and the regulator, ACMA, enforces the law.
        </aside>
        <p class="see-also"><strong>How to use this guide:</strong> it is a value guide, not a ranking of offers. It explains each kind of bonus, how to calculate rollover and expected cost in Australian dollars, which terms quietly shrink the value, and what to check before you claim. All dollar examples are hypothetical. Always read the actual terms of any offer.</p>
      </section>

      <section class="lp-sec" id="biggest">
        <h2>Why the biggest number is rarely the best offer</h2>
        <p>Bonus size and bonus quality are different things, and they often move in opposite directions. A larger bonus usually brings a larger required turnover, because the rollover is a multiple of the bonus, or of the deposit plus the bonus. Doubling the bonus can more than double the amount you must wager.</p>
        <div class="mini3">
          <div><h3>Staged deposits</h3><p>Big packages are often spread across several deposits, so you must keep depositing to reach the full figure. Most players never do.</p></div>
          <div><h3>Tighter terms</h3><p>Larger offers can carry shorter expiry windows, lower game contributions and a maximum cash-out that makes the headline unreachable in practice.</p></div>
          <div><h3>Sorted by clicks</h3><p>Many pages that rank for these searches are affiliate lists that sort offers by headline size, because that is what gets clicks, not because of what the offer is worth to you. See <a href="/online-casino-reviews/">how we review casinos</a> for how to judge them.</p></div>
        </div>
        <p>A modest match with a low rollover and no cap can be worth more than a package ten times the size. <a href="#worked">The worked comparison</a> shows how, using invented numbers.</p>
      </section>

      <section class="lp-sec" id="law">
        <h2>The legal position in Australia and what it means for bonus offers</h2>
        <figure class="shot"><?= gw_img('pages/bn-law', 'Shield with a tick beside the title Bonuses and Australian Law', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
<?php if ($legalChecked): ?>
        <p class="see-also"><strong>Legal information last checked:</strong> <time datetime="<?= e($legalChecked) ?>"><?= e(gw_date($legalChecked)) ?></time>, against ACMA and the Federal Register of Legislation.</p>
<?php endif; ?>
        <p class="lead-note">This is not legal advice. Confirm the current position with the Australian Communications and Media Authority (<a href="https://www.acma.gov.au" rel="noopener">ACMA</a>), which enforces the relevant law. What follows is a general summary of the position as ACMA describes it.</p>

        <h3>What the Interactive Gambling Act 2001 says about operators and players</h3>
        <p>The Interactive Gambling Act 2001 is the federal law covering online gambling services. In broad terms, it makes it an offence for operators to provide prohibited interactive gambling services, which include online casino-style games such as online pokies, to customers in Australia. The Act is aimed at the businesses providing the services rather than at the individual customers using them.</p>
        <p>That is not the same as saying playing is legal, safe or consequence-free. In practice it means no operator can offer online casino games to people in Australia under an Australian licence, because no such licence exists for those games. Licensed Australian wagering on sport and racing is a separate regime, run through state and territory licensing. A bookmaker's licence does not extend to online casino games, and the rules for wagering bonuses and inducements differ from those for the casino offers discussed here.</p>

        <h3>Why a foreign licence does not make a casino lawful for Australians</h3>
        <p>Many offshore casino sites display a licence badge from an overseas regulator. At best, that tells you where the operator is registered. It does not authorise the operator to offer casino games to people in Australia, and it does not change the Australian prohibition. Badges can also be copied, out of date or issued by regulators with very light oversight. If you want to check one, look it up on the issuing authority's own register rather than trusting the footer of the casino's site. Even a verified licence is no promise that the casino will pay you.</p>

        <h3>Weak recourse if a bonus or withdrawal dispute arises</h3>
        <p>Bonuses are where disputes most often begin. A casino can say you breached a term, such as betting above the maximum while the bonus was active or playing an excluded game, and void your winnings.</p>
        <div class="vs">
          <div class="vs-col vs-col--bad">
            <h3>What that can mean in practice</h3>
            <ul>
              <li>The terms are written by the operator and are often governed by the law of another country.</li>
              <li>You may have no neutral body to complain to who can order a payout.</li>
              <li>Accounts can be closed, balances frozen or bonus winnings removed, and challenging that is hard.</li>
              <li>Money sent to an offshore operator may be difficult or impossible to recover.</li>
            </ul>
          </div>
          <div class="vs-col">
            <h3>So the risk is not only the maths</h3>
            <ul>
              <li>It is also whether you will be paid at all.</li>
              <li>An operator that openly markets generous bonuses to Australians is likely operating in a way the Act prohibits. Treat that as a warning about how it may behave when you try to withdraw, not as a mark of confidence.</li>
              <li>Our <a href="/online-gambling-laws-in-australia/">guide to Australian gambling law</a> covers the wagering side.</li>
            </ul>
          </div>
        </div>

        <h3>Recent reforms and why advertised offers are a warning sign</h3>
        <?php
        /*
         * OWNER TODO (legal accuracy): replace the paragraph below with a short, verified summary of any amendments to the
         * Interactive Gambling Act that have been ENACTED, which provisions are already IN FORCE, and which have FUTURE
         * commencement dates, taken only from ACMA and the Federal Register of Legislation. Do not publish anything you
         * have not confirmed there. Add the date you checked it, for example "Legal information last checked: 1 December 2026".
         */
        ?>
        <p>The Interactive Gambling Act has been amended over time, and further changes have been enacted or proposed in recent years. Governments in Australia have been looking closely at online gambling, and enforcement against illegal online operators has been getting more attention. ACMA can have illegal gambling websites blocked and publishes information about the action it takes. Which provisions are enacted, which are already in force and which start on a later date changes over time, and a general summary can be wrong or out of date. Check <a href="https://www.acma.gov.au" rel="noopener">ACMA</a> and the <a href="https://www.legislation.gov.au" rel="noopener">Federal Register of Legislation</a> for the current position, and treat any operator that markets generous bonuses to Australians as a warning sign, not a mark of confidence.</p>
      </section>

      <section class="lp-sec" id="types">
        <h2>Types of online casino bonuses explained</h2>
        <figure class="shot"><?= gw_img('pages/bn-types', 'Gift box beside the title Casino Bonus Types', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Most offers are variations on a handful of structures. Knowing which one you are looking at tells you which terms matter most. None of the examples refer to any real operator's offer.</p>
        <div class="bcards">
          <article class="bc">
            <p class="opt-tag">First deposit</p>
            <h3>Welcome bonuses</h3>
            <p>A match on your first deposit: a "100% match" means a $100 deposit attracts a $100 bonus. They are often advertised as packages spread across the first several deposits, sometimes with free spins on top. The headline total is the maximum you could receive if you deposited the required amount at every stage.</p>
            <p class="bc-check"><strong>Check:</strong> whether the rollover applies to the bonus or to deposit plus bonus, each stage's own terms, the minimum deposit, the maximum per stage, the expiry, and whether it is sticky.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Later deposits</p>
            <h3>Deposit and reload bonuses</h3>
            <p>Matches on later deposits, often offered to existing players on a particular day or after a promotional email. The matches tend to be smaller than welcome offers, and the terms can be lighter or heavier. If you were not planning to deposit, a bonus is not a reason to. That is the clearest sign of a bonus working on you rather than for you.</p>
            <p class="bc-check"><strong>Check:</strong> the rollover (it can differ from the welcome offer), the game contribution table, the maximum bonus per deposit, and whether withdrawing before you clear it forfeits the bonus.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Spins and credit</p>
            <h3>Free spins and no-deposit offers</h3>
            <p>Free spins are a set number of pokies spins, usually on one game at a fixed bet size. No-deposit offers give a small credit or spins without a deposit. They sound like the best deal because claiming is free, but they are often the most tightly restricted. Fifty spins at $0.20 is $10 of staked value, not $10 of cash.</p>
            <p class="bc-check"><strong>Check:</strong> the bet size per spin, which game the spins are for, whether the rollover applies to winnings, the maximum cash-out, and the time limit for using the spins and clearing the winnings.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Losses returned</p>
            <h3>Cashback</h3>
            <p>Cashback returns a percentage of your net losses over a set period, such as a week. It does not ask you to win anything, but the details matter. It is a rebate on losing, not protection against it. You still lose the money first, and it becomes a reason to gamble more only if you let it.</p>
            <p class="bc-check"><strong>Check:</strong> whether it is cash or bonus credit, how losses are measured, the payout cap, the period it covers, and any rollover on the returned amount.</p>
          </article>
        </div>
        <div class="table-wrap">
          <table class="data">
            <caption>Common bonus types at a glance</caption>
            <thead><tr><th scope="col">Type</th><th scope="col">How it works</th><th scope="col">Typical catch</th></tr></thead>
            <tbody>
              <tr><th scope="row">Welcome match bonus</th><td>Bonus funds equal to a percentage of your first deposit, up to a limit</td><td>Wagering requirement and a time limit</td></tr>
              <tr><th scope="row">Reload bonus</th><td>A match on later deposits</td><td>Often smaller, with the same kinds of conditions</td></tr>
              <tr><th scope="row">Free spins</th><td>A set number of spins on named slots at a fixed stake</td><td>Winnings may carry wagering and a withdrawal cap</td></tr>
              <tr><th scope="row">No-deposit bonus</th><td>Funds or spins given without a deposit</td><td>Strict wagering and low maximum cash-out</td></tr>
              <tr><th scope="row">Cashback</th><td>A share of net losses returned</td><td>May be paid as bonus funds with their own wagering</td></tr>
              <tr><th scope="row">Loyalty rewards</th><td>Points or perks earned through regular play</td><td>Value depends on how points convert and when they expire</td></tr>
            </tbody>
          </table>
        </div>
        <p>For the basics in plain English, see <a href="/how-casino-welcome-bonuses-work/">how casino welcome bonuses work</a>.</p>
      </section>

      <section class="lp-sec" id="rollover">
        <h2>Online casino wagering requirements explained: how to calculate the real cost</h2>
        <figure class="shot"><?= gw_img('pages/bn-rollover', 'Transaction list beside a clock and the title Casino Rollover Rules', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Rollover (also called wagering, turnover or playthrough) is the single most important number in any offer. It sets how much you must bet before you can cash out. The numbers below are purely illustrative and are not typical.</p>

        <h3>Wagering on bonus only vs deposit plus bonus</h3>
        <p>Take a hypothetical $100 deposit with a 100% match, so a $100 bonus, and a 35x rollover. The multiple looks identical in the advert, but the base changes the workload. The wording is sometimes buried in the terms rather than the promotional text.</p>
        <div class="example" role="group" aria-label="Rollover base comparison">
          <div class="ex-col">
            <p class="ex-title">Bonus only</p>
            <p class="ex-sum">35 x A$100</p>
            <p class="ex-big">A$3,500</p><p class="ex-lbl">of turnover</p>
            <p class="ex-big ex-big--cost">A$140</p><p class="ex-lbl">expected cost at a 4% edge</p>
          </div>
          <div class="ex-col ex-col--hot">
            <p class="ex-title">Deposit plus bonus</p>
            <p class="ex-sum">35 x A$200</p>
            <p class="ex-big">A$7,000</p><p class="ex-lbl">of turnover</p>
            <p class="ex-big ex-big--cost">A$280</p><p class="ex-lbl">expected cost at a 4% edge</p>
          </div>
        </div>

        <h3>Step-by-step turnover calculation in AUD</h3>
        <p>The working for the hypothetical A$100 deposit, 100% match, 35x rollover on bonus only:</p>
        <ol class="steps">
          <li><strong>Find the bonus amount.</strong> 100% of A$100 = A$100.</li>
          <li><strong>Find the rollover base.</strong> Bonus only, so the base is A$100.</li>
          <li><strong>Multiply by the rollover.</strong> 35 x A$100 = A$3,500 of turnover.</li>
          <li><strong>Adjust for game contribution.</strong> If your pokies count 100%, the requirement stays A$3,500. If a game counts less, divide by its contribution.</li>
          <li><strong>Estimate the expected cost.</strong> Assuming, for illustration only, a 4% edge: A$3,500 x 0.04 = A$140.</li>
          <li><strong>Compare with the bonus.</strong> A$100 bonus &minus; A$140 expected cost = &minus;A$40 effective value.</li>
        </ol>
        <p>The 4% figure is an assumption to show the method, not a claim about any game. Take the real figure from the game's information screen, where the return to player (RTP) is normally displayed. House edge is 100% minus the RTP. A bonus does not change the odds on any game. It only changes how much you must bet. For more on RTP, see <a href="/understanding-rtp-and-volatility-in-online-slots/">our RTP and volatility guide</a>.</p>

        <h3>Game weighting, maximum bet and expiry</h3>
        <div class="mini3">
          <div><h3>Game weighting</h3><p>Hypothetically, pokies might count 100% and blackjack or roulette 10% or less, and some games nothing. At 10%, each $1 bet clears only $0.10, so a A$3,500 requirement needs A$35,000 of bets. That is why the advice to clear a bonus on a low-edge table game often fails: the casino has already adjusted for it.</p></div>
          <div><h3>Maximum bet</h3><p>Many casinos cap your bet while a bonus is active, say $5 hypothetically. Betting above it, even by accident, can void the bonus and winnings. It also affects speed: A$3,500 of turnover at $2 a spin is 1,750 spins.</p></div>
          <div><h3>Expiry</h3><p>If a hypothetical 7-day window applies to the A$3,500 requirement, that is A$500 of betting a day for a week. If you cannot realistically do that, the bonus expires and is removed. Expiry can apply separately to claiming, using and clearing.</p></div>
        </div>

        <h3>What the rollover means for your expected loss</h3>
        <p>Expected cost is an average, not what will happen in any one session. Pokies are high-variance: you can lose the whole balance in minutes or have a hot streak. The figure is the long-run drag from the casino's edge on every dollar you are required to wager.</p>
        <div class="mini3 mini3--4">
          <div><h4>Break-even rollover</h4><p>For a bonus-only rollover, break-even is roughly 1 divided by the house edge. At a hypothetical 4% edge, that is 25x. Above that, the average value is negative. This assumes the rollover applies to the bonus only, every game counts 100%, the bonus is fully withdrawable and there are no cash-out caps. Any extra restriction moves the break-even point lower.</p></div>
          <div><h4>Bigger turnover, bigger drag</h4><p>If the expected cost exceeds your deposit plus bonus, you have a real chance of running out of funds before you clear the requirement.</p></div>
          <div><h4>Cost relative to normal play</h4><p>If you would have wagered that turnover anyway, the cost is not extra. Most casual players would not have, so a rollover often means playing more than planned.</p></div>
          <div><h4>No better odds</h4><p>Bonuses add money to the balance and add conditions. They do not make the games fairer. Treat any winnings as a possibility, never a plan.</p></div>
        </div>
      </section>

      <section class="lp-sec" id="free-spins">
        <h2>How to calculate the value of free spins</h2>
        <p>Free spins are easy to overvalue because the headline is a number of spins, not a dollar amount. To value them, convert them to dollars and then apply the terms. This is a hypothetical example with invented figures, not any real offer.</p>
        <ol class="steps">
          <li><strong>Number of spins.</strong> 50 free spins.</li>
          <li><strong>Value per spin.</strong> A$0.20 per spin, a fixed bet set by the offer.</li>
          <li><strong>Total stake value.</strong> 50 x A$0.20 = A$10. This is what the spins are worth in bets, not cash you hold.</li>
          <li><strong>Expected winnings.</strong> At an assumed 96% RTP, the average return is A$10 x 0.96 = A$9.60. Real results vary widely, and you could win far more or nothing.</li>
          <li><strong>Wagering on winnings.</strong> If the winnings carry a 25x rollover, the turnover is 25 x A$9.60 = A$240.</li>
          <li><strong>Cost of clearing it.</strong> At a 4% house edge, A$240 x 0.04 = A$9.60 of expected loss.</li>
          <li><strong>Maximum withdrawal.</strong> A cap, say A$50, limits the best case however well the spins go.</li>
        </ol>
        <div class="example" role="group" aria-label="Free spins value on average">
          <div class="ex-col">
            <p class="ex-title">Expected winnings</p>
            <p class="ex-sum">A$10 staked x 96%</p>
            <p class="ex-big">A$9.60</p><p class="ex-lbl">average, not a promise</p>
          </div>
          <div class="ex-col ex-col--hot">
            <p class="ex-title">Value after a 25x rollover</p>
            <p class="ex-sum">A$9.60 &minus; A$9.60 cost</p>
            <p class="ex-big">about A$0</p><p class="ex-lbl">before the A$50 cap</p>
          </div>
        </div>
        <p>How the same spins change with the terms, using the same assumptions:</p>
        <div class="mini3">
          <div><h3>No wagering on winnings</h3><p>If winnings are paid as withdrawable cash, the average value is the expected winnings, about A$9.60, subject to any cap.</p></div>
          <div><h3>A low rollover</h3><p>At 10x, turnover is A$96 and the expected cost A$3.84, leaving about A$5.76 of average value.</p></div>
          <div><h3>A high rollover</h3><p>At 40x, turnover is A$384 and the expected cost A$15.36, which is more than the winnings. The average value is negative, about &minus;A$5.76.</p></div>
        </div>
        <p class="see-also">These are simplified averages. A positive average value does not mean you will clear the wagering or be paid, and spins that win a lot can still hit the cap. Check the real RTP, bet size, game and terms for any offer. For the wider method, see <a href="#rollover">the wagering requirements section</a> and <a href="/how-casino-welcome-bonuses-work/">how casino welcome bonuses work</a>.</p>
      </section>

      <section class="lp-sec" id="calculator">
        <h2>Wagering calculator</h2>
        <p>Enter the deposit, bonus percentage, wagering multiple and game RTP to estimate the required turnover and expected cost. This simplified calculator does not account for game weighting, withdrawal caps, free spins or other bonus restrictions. Use the same currency for every amount.</p>
        <form class="calc" id="bonus-calc" onsubmit="return false">
          <div class="criteria calc-fields">
            <div class="field"><label for="c-deposit">Deposit</label><input id="c-deposit" type="number" min="0" step="any" value="100" inputmode="decimal"></div>
            <div class="field"><label for="c-match">Match percentage</label><input id="c-match" type="number" min="0" step="any" value="100" inputmode="decimal"></div>
            <div class="field"><label for="c-mult">Wagering multiple</label><input id="c-mult" type="number" min="0" step="any" value="35" inputmode="decimal"></div>
            <div class="field"><label for="c-rtp">Average game RTP (%)</label><input id="c-rtp" type="number" min="1" max="100" step="any" value="96" inputmode="decimal"></div>
          </div>
          <div class="field">
            <label for="c-base">Wagering applies to</label>
            <select id="c-base"><option value="bonus">Bonus amount only</option><option value="both">Deposit plus bonus</option></select>
          </div>
          <dl class="calc-out" aria-live="polite">
            <div><dt>Bonus amount</dt><dd id="r-bonus">0</dd></div>
            <div><dt>Total you must bet</dt><dd id="r-wager">0</dd></div>
            <div><dt>Average expected cost of wagering</dt><dd id="r-cost">0</dd></div>
            <div><dt>Bonus minus expected cost</dt><dd id="r-net">0</dd></div>
          </dl>
          <p class="calc-fine">A negative result means the average cost of meeting the requirement is larger than the bonus. It is a guide to value, not a prediction of your session.</p>
        </form>
      </section>

      <section class="lp-sec" id="terms">
        <h2>Casino bonus terms, withdrawal limits and restrictions</h2>
        <figure class="shot"><?= gw_img('pages/bn-terms', 'Document with a magnifying glass beside the title Bonus Terms That Shrink Value', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Rollover is the headline term, but several other clauses reduce what you can realistically take out. They usually sit in the full terms and conditions rather than the advert. Look for a section titled "bonus terms", "general terms" or "withdrawals".</p>

        <h3>Maximum cash-out caps</h3>
        <p>A cash-out cap is the most you can withdraw from bonus-related winnings, however much you win. These are especially common on no-deposit and free-spin offers. In a hypothetical example, a free-spin offer has a A$50 cap: you turn the spins into A$400, meet the rollover, and can withdraw A$50. The remainder is removed. If you must wager thousands of dollars to unlock a withdrawal limit of A$50, the offer needs a closer look. In the terms, look for "maximum win", "maximum cashout" or "maximum withdrawal from bonus".</p>

        <h3>Sticky vs non-sticky bonuses</h3>
        <div class="vs">
          <div class="vs-col vs-col--bad">
            <h3>Sticky bonus</h3>
            <ul>
              <li>The bonus amount itself can never be withdrawn.</li>
              <li>It stays as playing credit and is removed when you cash out.</li>
              <li>Hypothetically: deposit A$100, receive a A$100 sticky bonus, finish with A$250. The bonus is deducted, leaving A$150 withdrawable. The bonus gave extra play and nothing more.</li>
            </ul>
          </div>
          <div class="vs-col">
            <h3>Non-sticky bonus</h3>
            <ul>
              <li>Sometimes called a "phantom" bonus: your deposit is used first.</li>
              <li>If you win and meet the conditions, or cash out before touching the bonus, the bonus is removed but your own funds and winnings are yours.</li>
              <li>Terms vary on what happens if you withdraw early, so read them, and check whether you can decline the bonus when depositing.</li>
            </ul>
          </div>
        </div>

        <h3>Exclusions that can void a bonus</h3>
        <div class="mini3">
          <div><h4>Excluded games</h4><p>Some pokies or game categories are barred from bonus play, and betting on them can void the bonus. Terms often name specific titles or providers.</p></div>
          <div><h4>Country restrictions</h4><p>If Australia is excluded in the terms, the offer does not apply to you, whatever the advertising suggests, and winnings can be voided.</p></div>
          <div><h4>Payment methods</h4><p>Some methods may not qualify, such as certain e-wallets or prepaid options. Confirm it in the terms for any method you plan to use, whether bank transfer, PayID, a prepaid voucher such as Neosurf, or crypto, before you pay.</p></div>
        </div>

        <h3>Verification, pending periods and payout caps</h3>
        <p>Even if you clear the rollover, withdrawing is a separate step with its own terms. None of these appear in the headline offer, yet all reduce its practical value. If a casino's terms are vague or unavailable on these points, treat that as a reason to walk away. See also <a href="/what-affects-casino-withdrawal-speed/">what affects withdrawal speed</a> and <a href="/kyc-verification-at-online-casinos/">our KYC guide</a>.</p>
        <div class="mini3">
          <div><h4>Verification (KYC)</h4><p>Casinos typically ask for identity documents before the first withdrawal. If your documents do not match, or the casino asks for more, payment can be delayed or refused. You are also handing sensitive documents to a business that is not accountable under Australian licensing.</p></div>
          <div><h4>Pending periods</h4><p>Many casinos hold withdrawal requests for a set time. The terms should say how long, and whether you can reverse the request. Reversing it and playing on is a common way for balances to vanish.</p></div>
          <div><h4>Payout caps</h4><p>Terms may limit what you can withdraw per day, week or month. A hypothetical weekly cap of A$2,000 means a A$10,000 win takes five weeks to receive, with the operator holding your money meanwhile.</p></div>
        </div>
      </section>

      <section class="lp-sec" id="worked">
        <h2>Worked comparison: three hypothetical offers and their estimated value</h2>
        <p>The table shows three invented offers, all for a A$100 deposit. They are not real, not typical and do not reflect any casino. The point is to show how the formula can reverse the ranking suggested by headline size. Assumptions, for illustration only: a 4% house edge on all play, and all games counting 100% towards rollover.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Three hypothetical offers for a A$100 deposit</caption>
            <thead><tr><th scope="col">Hypothetical offer</th><th scope="col">Bonus</th><th scope="col">Rollover</th><th scope="col">Turnover needed</th><th scope="col">Cash-out cap</th><th scope="col">Expected cost at 4%</th><th scope="col">Effective value</th></tr></thead>
            <tbody>
              <tr><th scope="row">A: big match, high rollover</th><td>200% match = A$200</td><td>45x deposit plus bonus</td><td>45 x A$300 = A$13,500</td><td>None stated</td><td>A$540</td><td><strong>&minus;A$340</strong></td></tr>
              <tr><th scope="row">B: smaller match, lower rollover</th><td>100% match = A$100</td><td>20x bonus only</td><td>20 x A$100 = A$2,000</td><td>None stated</td><td>A$80</td><td><strong>+A$20</strong></td></tr>
              <tr><th scope="row">C: free spins with a cap</th><td>50 spins at $0.20 (A$10 staked), expected winnings about A$9.60</td><td>25x winnings</td><td>25 x A$9.60 = A$240</td><td>A$50</td><td>A$9.60</td><td><strong>A$0</strong></td></tr>
            </tbody>
          </table>
        </div>
        <p>On these simplified estimates, B comes out ahead of C, and C ahead of A. A has the biggest headline and is by far the worst. These are mathematical estimates under stated assumptions, not a definitive ranking of real-world bonus value, and a positive expected value does not guarantee that a player will clear the wagering or receive a payout.</p>
        <div class="mini3">
          <div><h3>A: big match, high rollover</h3><p>The rollover applies to deposit plus bonus, so the base is A$300 and 45 times that is A$13,500. The average cost of clearing it, A$540, is more than the whole A$300 you would have in play. You are not certain to lose, but the average outcome is running out of money before you finish.</p></div>
          <div><h3>B: smaller match, lower rollover</h3><p>Only A$100, but the rollover applies to the bonus alone at 20x, so turnover is A$2,000 and expected cost A$80. That leaves about A$20 of expected value, with no cap on winnings. It is a small edge, but far better than A, and it means much less exposure to losses.</p></div>
          <div><h3>C: free spins with a cap</h3><p>Fifty spins at $0.20 stake A$10. At a 4% edge, expected winnings are about A$9.60. With a 25x rollover, the cost of clearing is another A$9.60, so it nets out at about zero: 25x is the break-even multiple at a 4% edge. The A$50 cap limits the best case.</p></div>
        </div>
        <p class="see-also"><strong>Sensitivity:</strong> the outcome depends on the assumed edge. At a 2% edge, B's value rises to A$60 and A is still negative at &minus;A$70. At 6%, B drops to &minus;A$20. The ranking between A and B holds across those assumptions, but a thin margin like B's can vanish, which is why you should use the real RTP from the game's information screen.</p>

        <h3>A simple formula you can reuse</h3>
        <ol class="steps">
          <li><strong>Bonus value (B).</strong> The bonus you would actually receive for the deposit you would actually make. For free spins, use expected winnings, not face value.</li>
          <li><strong>Turnover (T).</strong> Rollover multiple x the base (bonus only, or deposit plus bonus).</li>
          <li><strong>Adjust for weighting.</strong> Divide by the game's contribution if it is below 100%.</li>
          <li><strong>Expected cost.</strong> T x house edge (100% minus the game's RTP, from its information screen).</li>
          <li><strong>Effective value.</strong> B minus expected cost.</li>
          <li><strong>Apply the ceiling.</strong> A cash-out cap limits what you can take out, whatever the formula says.</li>
          <li><strong>Sanity check.</strong> If expected cost exceeds your deposit plus bonus, you may run out before you clear it. Check the max bet, expiry and payout limits too.</li>
        </ol>
        <p>If the answer is negative or close to zero, the bonus is not worth claiming for its own sake. A positive answer is still not a profit, just a smaller expected loss than the headline suggests.</p>
      </section>

      <section class="lp-sec" id="checklist">
        <h2>Before you claim: a checklist, red flags and safe payments</h2>
        <h3>A 10-point terms checklist</h3>
        <p>If you cannot find an answer in the terms, treat that as an answer in itself.</p>
        <div class="rg-card checklist-card">
          <ol class="checks checks--num">
            <li><strong>Rollover multiple and base:</strong> bonus only, or deposit plus bonus?</li>
            <li><strong>Total turnover in dollars:</strong> multiply it out for your actual deposit.</li>
            <li><strong>Game contribution:</strong> what do your games count for, and which are excluded?</li>
            <li><strong>Maximum bet:</strong> the limit while the bonus is active, and the penalty for exceeding it.</li>
            <li><strong>Expiry:</strong> how long to claim, use and clear it.</li>
            <li><strong>Cash-out cap:</strong> the most you can withdraw from bonus winnings.</li>
            <li><strong>Sticky or non-sticky:</strong> is it removed on withdrawal, and can you decline it?</li>
            <li><strong>Payment and country exclusions:</strong> does your method qualify, and is Australia permitted?</li>
            <li><strong>Verification and payouts:</strong> documents, pending period and payout limits.</li>
            <li><strong>Effective value:</strong> after the formula, is it positive and worth the extra betting?</li>
          </ol>
        </div>

        <h3>Red flags</h3>
        <div class="flags">
          <div class="flag"><h3>Vague or missing terms</h3><p class="bad">No clear rollover, cap or expiry, or terms saying the casino may change or cancel a bonus at its discretion.</p></div>
          <div class="flag"><h3>No verifiable company</h3><p class="bad">No named operating company, registered address or licence you can check on the issuer's own register. See <a href="/safe-and-trusted-online-casinos/">our safety checks</a>.</p></div>
          <div class="flag"><h3>Pressure to deposit</h3><p class="bad">Countdown timers, "last chance" messages, or staged offers that only pay out if you keep depositing.</p></div>
          <div class="flag"><h3>Shifting terms</h3><p class="bad">Terms that change after you have claimed, or withdrawals delayed with repeated new document requests.</p></div>
          <div class="flag"><h3>Guarantees</h3><p class="bad">Any language promising wins, "risk-free" play or "free money". No bonus is either of those.</p></div>
          <div class="flag"><h3>Offers aimed at losing players</h3><p class="bad">Large bonuses after losses or after you tried to withdraw are designed to keep you playing.</p></div>
        </div>

        <h3>Payments to be cautious about</h3>
        <p>Because these operators are offshore and unlicensed in Australia, payments to them are riskier than ordinary purchases. Banks and payment providers may block or decline transactions to illegal gambling operators, and if a payment does go through, do not assume you can get it back. Be careful with methods that are hard to trace or reverse, and with any site that steers you toward a particular method or offers a better bonus for using it. Keep records of every transaction and never share banking passwords or card details by email or chat. If something goes wrong, talk to your bank early, but do not assume it can reverse the payment. Our <a href="/online-casino-payment-methods/">payment methods guide</a> compares the options.</p>
      </section>

      <section class="lp-sec" id="responsible">
        <h2>Responsible gambling: 18+, limits, and where to get help</h2>
        <div class="rg-card">
          <p>Gambling is for adults aged 18 and over. Bonuses are a marketing tool, and the way they are structured can push you to bet more than you planned in order to unlock them. They cannot make gambling safer, and they cannot guarantee a win.</p>
          <ul class="checks">
            <li><strong>Decide your limit first.</strong> Set an amount you can afford to lose and a time limit before you play, and do not let a bonus change either. See <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools</a>.</li>
            <li><strong>Never chase losses.</strong> Do not deposit more to clear a bonus or win back what you have lost.</li>
            <li><strong>Treat it as entertainment with a cost.</strong> Money you cannot afford to lose, such as rent or bill money, is never part of the plan.</li>
            <li><strong>Know the warning signs.</strong> Hiding your play, borrowing to gamble, or feeling anxious or irritable when you stop all suggest it is time to seek help.</li>
          </ul>
          <p>If gambling is causing you or someone close to you harm, Gambling Help Online offers free, confidential support on <a href="tel:1800858858">1800 858 858</a> (<a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a>). BetStop, the national self-exclusion register, covers licensed Australian wagering only. It does not cover offshore casino sites, so you cannot rely on it to block your access to them. More support is on our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
        </div>
      </section>

      <section class="lp-sec" id="resources">
        <h2>Official Australian gambling resources</h2>
        <p>Check important points yourself with the official sources below. Laws change, so confirm current rules and commencement dates with them directly.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Official resources and what they are for</caption>
            <thead><tr><th scope="col">Resource</th><th scope="col">What it is for</th></tr></thead>
            <tbody>
              <tr><th scope="row"><a href="https://www.acma.gov.au" rel="noopener">ACMA</a></th><td>Interactive gambling legislation, enforcement and current guidance on illegal gambling services</td></tr>
              <tr><th scope="row"><a href="https://www.legislation.gov.au" rel="noopener">Federal Register of Legislation</a></th><td>The text of the Interactive Gambling Act 2001 and any amendments</td></tr>
              <tr><th scope="row"><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a></th><td>National self-exclusion register for licensed online and phone wagering</td></tr>
              <tr><th scope="row"><a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a></th><td>Free, confidential support, 24 hours a day on 1800 858 858</td></tr>
              <tr><th scope="row"><a href="https://www.scamwatch.gov.au" rel="noopener">Scamwatch</a></th><td>Reporting and avoiding scams</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <section class="lp-sec" id="editorial">
        <h2>Editorial information</h2>
        <?php
        /*
         * OWNER NOTE: only publish claims about reviews, fact-checking or named reviewers that you actually carry out.
         * If a real person reviews this page, add their name and genuine relevant experience here and in the Article schema.
         */
        ?>
        <div class="rg-card">
          <ul class="checks">
            <li><strong>Written by:</strong> <?= e(SITE_NAME) ?> Editorial Team. <a href="/about/">About us</a>.</li>
            <li><strong>Last updated:</strong> <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time>.</li>
            <li><strong>About the numbers:</strong> every dollar example, the sample comparison table and the calculator are illustrative and use the assumptions stated beside them. They are not real offers and not predictions.</li>
            <li><strong>Sources for legal points:</strong> <a href="https://www.acma.gov.au" rel="noopener">ACMA</a> and the <a href="https://www.legislation.gov.au" rel="noopener">Federal Register of Legislation</a>. Laws change, so check them directly.</li>
            <li><strong>How we are funded:</strong> see our <a href="/about/#disclosure">affiliate disclosure</a>. To report a mistake, use our <a href="/contact/">contact page</a>.</li>
          </ul>
        </div>
      </section>

      <section class="lp-sec faq" id="faq">
        <h2>FAQ: Australian casino bonus questions</h2>
<?php foreach ($faq as $item): ?>
        <details>
          <summary><?= e($item['q']) ?></summary>
          <p><?= $item['a'] ?></p>
        </details>
<?php endforeach; ?>
      </section>

      <div class="callout-link">
        <p><strong>The takeaway: your next step</strong>Before you claim any offer, run the effective-value formula with the real rollover base, game contribution and RTP, read the terms for caps, expiry, sticky rules, verification and payout limits, check ACMA for the current legal position, and set a limit you can afford. If the numbers do not add up, walk away. Closing the page costs you nothing.</p>
        <a class="btn btn--ruby" href="#calculator">Use the calculator</a>
      </div>

      <aside class="note">
        <p><strong>Play responsibly.</strong> 18+ only. Bonuses do not change the fact that casino games have a built-in house edge, and no bonus guarantees a win. If gambling is causing you stress, call Gambling Help Online on <a href="tel:1800858858">1800 858 858</a> at any time. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Related guides</h2>
      <div class="related-grid">
<?php foreach (['how-casino-welcome-bonuses-work', 'what-affects-casino-withdrawal-speed', 'understanding-rtp-and-volatility-in-online-slots', 'no-deposit-bonuses-australia', 'how-casino-welcome-bonuses-are-calculated', 'australian-casino-welcome-bonuses-comparison'] as $slug) { if ($r = gw_article($slug)) { echo gw_card($r, 'std'); } } ?>
      </div>
    </div>
  </section>
<?php gw_topic_block(['bonuses', 'withdrawals', 'games']); ?>
</main>
<script>
(function () {
  var $ = function (id) { return document.getElementById(id); };
  var f = $('bonus-calc');
  if (!f) return;
  function n(id) { var v = parseFloat($(id).value); return isFinite(v) && v > 0 ? v : 0; }
  function fmt(x) { return x.toLocaleString(undefined, { maximumFractionDigits: 2 }); }
  function run() {
    var deposit = n('c-deposit'), match = n('c-match'), mult = n('c-mult'), rtp = Math.min(n('c-rtp'), 100);
    var bonus = deposit * match / 100;
    var base = $('c-base').value === 'both' ? deposit + bonus : bonus;
    var wager = base * mult;
    var cost = wager * (1 - rtp / 100);
    $('r-bonus').textContent = fmt(bonus);
    $('r-wager').textContent = fmt(wager);
    $('r-cost').textContent = fmt(cost);
    $('r-net').textContent = fmt(bonus - cost);
  }
  f.addEventListener('input', run);
  f.addEventListener('change', run);
  run();
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>