<?php
/**
 * Article: Understanding Australian Online Gambling Regulations
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the regulators section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('understanding-australian-online-gambling-regulations');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#glance">What's legal online and what isn't</a></li>
            <li><a href="#act">The Interactive Gambling Act</a></li>
            <li><a href="#regulators">Who the regulator is</a></li>
            <li><a href="#enforcement">How ACMA polices online gambling</a></li>
            <li><a href="#protections">Licensed operator protections</a></li>
            <li><a href="#reforms">What changes from 1 January 2027</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Check the licence first</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Australian gambling regulations allow some online gambling and ban the rest. You can bet online on racing, sport and lotteries with an operator that holds an Australian licence. Online casinos, online pokies and in-play sports betting over the internet can't lawfully be offered to people in Australia, however local the site looks.</p>
      <p>The Commonwealth sets the rules for online services through the Interactive Gambling Act 2001, enforced by the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a>. States and territories license operators and regulate venues. This guide covers who regulates what, how to check a licence, and what changes from 1 January 2027. It is general information for adults aged 18 and over, not legal advice. ACMA and your state or territory regulator have the final word.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Racing, sport and lottery betting are legal online</strong> only with an Australian-licensed operator.</li>
          <li><strong>Online casinos, online pokies and in-play online sports betting</strong> can't lawfully be offered to people in Australia.</li>
          <li><strong>There is no single regulator:</strong> ACMA covers online services and advertising, while states and territories license operators and venues.</li>
          <li><strong>Check the licence on ACMA's register before you deposit.</strong> AUD balances and PayID prove nothing.</li>
        </ul>
      </div>

      <h2 id="glance">Australian gambling regulations at a glance: what's legal online and what isn't</h2>
      <figure class="shot"><?= gw_img('articles/regs-glance', 'Payment list with a clock beside the title Whats Legal Online and What Isnt', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The table follows the way ACMA describes the banned categories. The detail is updated from time to time, so check ACMA's site for the current list.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>What is permitted and what can't be offered online</caption>
      <thead><tr><th scope="col">Permitted (with an Australian-licensed operator)</th><th scope="col">Can't be offered to people in Australia</th></tr></thead>
      <tbody>
      <tr><td>Online betting on racing and sport, placed before the event starts</td><td>Online casinos, including online pokies, table games and poker for money</td></tr>
      <tr><td>In-play sports bets made by phone call or in person at a venue</td><td>In-play sports betting online</td></tr>
      <tr><td>Buying tickets online in licensed lotteries</td><td>Sports betting services that don't hold an Australian licence</td></tr>
      <tr><td>Land-based gambling licensed by your state or territory (pokies, casinos, TAB outlets)</td><td>Betting on the outcome of a lottery, and online instant "scratchie"-style lotteries</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Permitted when the operator holds an Australian licence</h3>
      <p>Online wagering is legal when the provider is licensed by an Australian state or territory. That covers the corporate bookmakers, totalisators and betting exchanges punters use for racing and sport, plus licensed lottery sellers. One licence lets a provider take bets from customers across the country, which is why your bookmaker may be licensed somewhere you've never lived.</p>
      <h3>Services that can't be offered to people in Australia</h3>
      <p>No Australian regulator issues a licence for an online casino or online pokies site aimed at Australians. A site offering those products to you is operating outside the law, whatever overseas licence it displays in its footer. The same goes for click-to-bet in-play sports markets and any bookmaker without an Australian licence.</p>
      <h3>Where that leaves you as a player</h3>
      <p>Bet with a licensed operator and you get the consumer protections described later in this guide, plus a regulator to complain to. Play on an unlicensed site and you get neither. That gap is the practical reason to check the licence first.</p>

      <h2 id="act">The Interactive Gambling Act 2001: the law behind online gambling rules in Australia</h2>
      <figure class="shot"><?= gw_img('articles/regs-act', 'Shield with a tick beside the title The Gambling Act in Plain English', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The Interactive Gambling Act 2001 (the IGA) is the Commonwealth law that sets online gambling rules in Australia. ACMA's About the Interactive Gambling Act page is the authoritative summary. This section puts the essentials in plain English.</p>
      <p>The Interactive Gambling Act 2001 defines which online gambling services can legally be offered to Australians.</p>
      <h3>Who the Act targets: providers and advertisers</h3>
      <p>The Act's offences are aimed at the supply side. Companies can't provide banned interactive gambling services to customers in Australia, provide wagering services without an Australian licence, or advertise those services here. Wagering operators are also barred from offering credit to customers.</p>
      <p>The Act is not built around prosecuting individual punters. That doesn't make offshore play "legal" or safe, a point the FAQ below returns to.</p>
      <h3>In-play betting and the telephone exception</h3>
      <p>In-play (or "live") betting means betting on a sporting event after it has started. Under the IGA, in-play sports bets can't be placed online, so you can't click or tap them through a website or app. You can still place them by a voice call to a licensed operator, or in person at a venue.</p>
      <p>Parliament tightened this area in 2017 to close workarounds that imitated a phone call inside an app. If a site lets you click to bet on the next goal mid-match, treat that as a red flag about its licence.</p>
      <h3>Lotteries, keno-style products and other edge cases</h3>
      <p>This is where the rules get fiddly:</p>
      <div class="mini3">
        <div><h3>Lottery tickets</h3><p>Buying a ticket online in a licensed lottery is permitted. Online instant or scratchie-style lotteries are not.</p></div>
        <div><h3>Lottery betting</h3><p>Services that let you bet on the outcome of a lottery draw, rather than enter it, have been prohibited since 2019. Keno-style "betting on the draw" products are treated similarly.</p></div>
        <div><h3>Keno</h3><p>Availability online depends on the product and the state or territory licence behind it.</p></div>
      </div>
      <p>These categories are being adjusted again under the 2026 reforms. If you're unsure about a specific lottery or keno product, ask ACMA rather than relying on the seller's description.</p>
      <p class="see-also">For the longer explainer, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="regulators">Who is the gambling regulator in Australia? ACMA, the states and territories</h2>
      <figure class="shot"><?= gw_img('articles/regs-regulators', 'Dotted circles beside the title Who Is the Gambling Regulator', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>There is no single gambling regulator in Australia. The Commonwealth covers online services and advertising. Each state and territory licenses operators and regulates the pubs, clubs, casinos and TAB outlets within its borders.</p>
      <h3>ACMA: the federal regulator for online services</h3>
      <p>ACMA enforces the Interactive Gambling Act. For players, the ACMA online gambling role comes down to four things:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>it investigates illegal online gambling services and takes enforcement action against them</li>
          <li>it keeps the public register of licensed interactive wagering providers</li>
          <li>it oversees BetStop, the national self-exclusion register</li>
          <li>it enforces gambling advertising rules for broadcast and online streaming</li>
        </ul>
      </div>
      <p>ACMA does not issue betting licences and generally doesn't resolve disputes about individual bets. Those jobs sit with the states and territories.</p>
      <h3>State and territory regulators (table)</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Jurisdiction</th><th scope="col">Regulator</th><th scope="col">What it covers</th></tr></thead>
      <tbody>
      <tr><th scope="row">NSW</th><td>Liquor & Gaming NSW, with the Independent Liquor & Gaming Authority; the NSW Independent Casino Commission for casinos</td><td>Gaming machines in pubs and clubs, wagering, casinos</td></tr>
      <tr><th scope="row">VIC</th><td>Victorian Gambling and Casino Control Commission (VGCCC)</td><td>Casino, gaming machines, wagering, keno and lotteries</td></tr>
      <tr><th scope="row">QLD</th><td>Office of Liquor and Gaming Regulation (OLGR)</td><td>Casinos, gaming machines, wagering, keno and lotteries</td></tr>
      <tr><th scope="row">SA</th><td>Consumer and Business Services (Liquor and Gambling Commissioner)</td><td>Casino, gaming machines, wagering and lotteries</td></tr>
      <tr><th scope="row">WA</th><td>Gaming and Wagering Commission of Western Australia, supported by the responsible state department</td><td>Casino, wagering and community gaming</td></tr>
      <tr><th scope="row">TAS</th><td>Tasmanian Liquor and Gaming Commission</td><td>Casinos, gaming machines, keno and wagering</td></tr>
      <tr><th scope="row">ACT</th><td>ACT Gambling and Racing Commission</td><td>Club gaming machines, casino, racing and wagering</td></tr>
      <tr><th scope="row">NT</th><td>Northern Territory Racing and Wagering Commission</td><td>Racing and wagering, including many of the online bookmakers that operate nationally</td></tr>
      </tbody>
      </table>
      </div>
      <p>Regulator names and structures change. Victoria's VGCCC replaced the old VCGLR in 2022, and the NT's commission replaced the Northern Territory Racing Commission in 2024, yet plenty of online guides still use the old names. Confirm the current body on the relevant government website before lodging anything formal.</p>
      <h3>Other bodies: AUSTRAC and the federal department</h3>
      <p>Two other federal bodies affect what you see as a customer. AUSTRAC, the financial intelligence agency, sets the anti-money-laundering rules behind the identity checks you complete when opening a betting account. The Department of Social Services looks after gambling harm policy, including the National Consumer Protection Framework for Online Wagering. Its gambling reforms page lists each protection and who enforces it.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="enforcement">How ACMA polices online gambling: blocks, warnings and what they mean for you</h2>
      <figure class="shot"><?= gw_img('articles/regs-enforcement', 'Chart with a warning mark beside the title How ACMA Enforces the Rules', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Most illegal services targeting Australians are run from overseas, so ACMA relies on tools that work across borders.</p>
      <h3>Website blocking and other enforcement tools</h3>
      <p>Since November 2019, ACMA has been able to ask Australian internet service providers to block illegal gambling websites, along with affiliate sites that promote them. By ACMA's count, well over a thousand sites have been blocked since then. The tally moves with almost every announcement, so check ACMA's latest media release rather than trusting a figure in an old article.</p>
      <p>ACMA can also issue formal warnings and infringement notices, seek civil penalties in court, and refer operators to licensing authorities overseas. It reports that many offshore operators have withdrawn from the Australian market as a result.</p>
      <h3>Why a blocked or unlicensed site puts your money at risk</h3>
      <p>For a player, the consequences are practical:</p>
      <div class="flags">
        <div class="flag"><h3>No dispute help</h3><p class="bad">If an unlicensed site refuses a withdrawal, voids a win or closes your account, no Australian regulator can order it to pay.</p></div>
        <div class="flag"><h3>Funds can be stranded</h3><p class="bad">If a site is blocked or pulls out of Australia, getting your balance back depends entirely on the operator's goodwill.</p></div>
        <div class="flag"><h3>No mandated safeguards</h3><p class="bad">BetStop, deposit limit rules and activity statements don't apply.</p></div>
        <div class="flag"><h3>Your data is exposed</h3><p class="bad">You've handed ID documents and payment details to a business outside Australian oversight.</p></div>
      </div>
      <p>Don't be reassured by surface details. Prices in AUD, PayID deposits, an Australian-sounding name or a ".au"-looking brand are not proof of an Australian licence. Illegal sites use all of these to look local.</p>
      <h3>How to report an illegal service</h3>
      <p>Anyone can report a suspected illegal gambling service through the online complaint form at acma.gov.au. Include the web address, the type of gambling offered and any ads or messages that led you there. ACMA uses complaints to prioritise investigations. It can't recover money for you, which is another reason to check the licence before depositing rather than after.</p>

      <h2 id="protections">Protections you get with an Australian-licensed operator</h2>
      <figure class="shot"><?= gw_img('articles/regs-protections', 'Checklist card beside the title Licensed Operator Protections', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Licensed online wagering providers must follow the National Consumer Protection Framework, a set of minimum standards agreed by the Commonwealth, states and territories. These protections are legal requirements. They don't depend on how generous an operator chooses to be.</p>
      <h3>BetStop, the national self-exclusion register</h3>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> lets you exclude yourself from every licensed online and phone wagering provider in Australia with one free registration. You choose a period from three months up to a lifetime. Once you're registered, licensed providers must not open an account for you, take your bets or send you marketing. It does not cover unlicensed offshore sites, pokies venues or lottery purchases. Sign-up details are on the official BetStop site.</p>
      <h3>Deposit limits, activity statements and account closure</h3>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Deposit limits</h3>
          <p>You must be offered the chance to set a deposit limit when you open an account, and reminded to review it. Lowering a limit takes effect straight away. Raising one involves a cooling-off period.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Activity statements</h3>
          <p>Operators must send regular statements showing your deposits, withdrawals, wins and losses, so you can see your net position without piecing it together yourself.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Account closure</h3>
          <p>Closing an account must be simple and clearly signposted, and operators can't keep marketing to you afterwards.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>No sign-up inducements</h3>
          <p>Operators can't offer bonuses or free bets to get you to open an account or refer a friend. Winnings from a bonus bet must be withdrawable without turnover conditions.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Direct marketing by consent</h3>
          <p>You must opt in to promotional messages and be able to unsubscribe easily.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Consistent messaging</h3>
          <p>Ads and apps carry nationally agreed harm-minimisation taglines, and staff must be trained in responsible service.</p>
        </article>
      </div>
      <p>So a site pushing a large welcome bonus at new Australian customers is telling you something about its licence status.</p>
      <h3>Payment and ID rules: credit card ban and verification</h3>
      <p>Since 11 June 2024, online wagering providers have been banned from accepting credit cards, credit-linked digital wallets and digital currencies such as cryptocurrency. Debit cards, bank transfers and similar methods that use your own money remain available. Online lottery purchases were left outside the ban, and ACMA's site has the current scope.</p>
      <p>Operators also can't offer you a line of credit or promote payday loans. They must verify your identity before you can place a bet, which helps keep under-18s and self-excluded people out. A site that lets you deposit and play first and asks for ID only at withdrawal is not operating to Australian standards.</p>
      <p class="see-also">More on checks and documents: <a href="/kyc-verification-at-online-casinos-australia/">KYC verification at online casinos in Australia</a>.</p>

      <h2 id="reforms">What changes from 1 January 2027 under the 2026 gambling reforms</h2>
      <figure class="shot"><?= gw_img('articles/regs-reforms', 'Document with a magnifying glass beside the title 2027 Reforms to Check Yourself', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <?php /* OWNER TODO: this section states, as supplied, that Parliament passed a gambling reform package on 19 August 2026, that most measures start on 1 January 2027, and lists bank-level payment blocking, an advertising opt-out register and BetStop changes. These could not be independently verified when the page was built. Confirm them on acma.gov.au and legislation.gov.au. Other pages on this site word the same topic differently (see the owner notes on /best-online-casinos-australia-2026/ and the wording on /online-gambling-laws-in-australia-2026/): make all pages say the same verified thing. Also re-check the Northern Territory commission rename (2024) in the regulators table. */ ?>
      <p>According to the official ACMA and departmental pages, federal Parliament passed a gambling reform package on 19 August 2026. Most measures are scheduled to start on 1 January 2027, and some are phased in. Detailed guidance is still being released, so what follows is headline-level only. Confirm dates and details with ACMA before relying on them.</p>
      <h3>Wagering advertising restrictions</h3>
      <p>The package places new limits on wagering advertising. Which platforms and times are covered, and when each phase begins, is set out in ACMA guidance. We won't paraphrase details that may still be refined. If you want to know exactly when and where betting ads can appear, read ACMA's page directly.</p>
      <h3>Inducements and the advertising opt-out register</h3>
      <p>Two changes affect what lands in your inbox and feed. The reforms curb inducement marketing further, building on the existing ban on sign-up offers. They also establish an advertising opt-out register, so people can choose not to receive wagering advertising. The package includes changes to BetStop as well. ACMA will publish registration steps and start dates for each.</p>
      <h3>New tools against illegal offshore services</h3>
      <p>The reforms add bank-level blocking of payments to illegal gambling services, alongside the existing website blocking. In practice, a deposit to an unlicensed site may simply fail. Anyone holding a balance with an offshore operator also faces more risk once payment channels start closing.</p>
      <p>For the current status of any of these measures, use ACMA's Interactive Gambling Act page linked above.</p>

      <h2 id="faq">Australian online gambling rules: frequently asked questions</h2>
      <div class="faq">
        <details>
          <summary>Is online gambling legal in Australia?</summary>
          <p>Partly. Online betting on racing and sport and online lottery ticket sales are legal when the operator holds an Australian licence. Online casinos, online pokies and online in-play sports betting can't lawfully be offered here. ACMA's Interactive Gambling Act page lists the banned services.</p>
        </details>
        <details>
          <summary>Are online casinos and online pokies legal in Australia?</summary>
          <p>No. It is illegal to provide them to people in Australia, and no Australian regulator licenses them. An overseas licence doesn't change that. Pokies and casino games are only lawfully available in licensed land-based venues, under your state or territory's rules.</p>
        </details>
        <details>
          <summary>Can I get in trouble for playing on an offshore casino site?</summary>
          <p>The federal offences in the Interactive Gambling Act are aimed at providers and advertisers rather than individual players. That is not the same as offshore play being legal or safe. State and territory laws may also apply, you lose every protection described above, and no Australian regulator can recover your money. For advice on your own situation, speak to a lawyer or your state or territory regulator.</p>
        </details>
        <details>
          <summary>Who regulates online gambling in Australia?</summary>
          <p>ACMA enforces the federal law on online services and advertising. Operators are licensed and supervised by state and territory regulators, with the Northern Territory Racing and Wagering Commission licensing many of the online bookmakers. The table above lists each jurisdiction's regulator.</p>
        </details>
        <details>
          <summary>Can I use a credit card to bet online in Australia?</summary>
          <p>Not with online wagering providers. Credit cards, credit-linked digital wallets and digital currencies have been banned for online betting since 11 June 2024. Online lotteries were treated differently, so check ACMA for the current scope. A betting site that accepts credit cards or crypto from Australians is very unlikely to be licensed here.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: check the licence before you deposit</h2>
      <figure class="shot"><?= gw_img('articles/regs-next', 'Limit sliders beside the title Check the Licence First', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>A four-step licence check</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Find the legal name.</strong> Scroll to the footer of the site or app and note the company name and the state or territory licence it claims.</li>
          <li><strong>Search the ACMA register.</strong> Look the name up on ACMA's register of licensed interactive wagering providers. If it's not there, don't deposit.</li>
          <li><strong>Check the products.</strong> Online pokies, casino games or click-to-bet in-play sports markets mean the service isn't licensed for Australians, whatever it claims.</li>
          <li><strong>Ignore the window dressing.</strong> AUD balances, PayID, local-sounding branding and glowing reviews prove nothing. If you're still unsure, ask ACMA or the named regulator first.</li>
        </ol>
      </div>
      <h3>Where to complain if something goes wrong</h3>
      <p>With a licensed operator, complain to the operator in writing first and keep records. If that fails, go to the regulator in the state or territory that issued its licence. For an illegal site, a BetStop breach or an advertising problem, report it to ACMA.</p>
      <h3>Gamble responsibly: 18+, set limits, get support</h3>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over, and no bet comes with guaranteed winnings. Set a deposit limit before you start and only stake what you can afford to lose. If gambling stops being fun, register with <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> or contact <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> for free, confidential support at any hour.</p>
      </div>
      <p>Before your next deposit, take two minutes to look up your operator on the ACMA register.</p>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/online-casinos-australia-pros-cons-legality/">Online Casinos Australia – Pros, Cons &amp; Legality</a>, <a href="/kyc-verification-at-online-casinos/">KYC Verification at Online Casinos: What to Expect</a>, <a href="/kyc-verification-at-online-casinos-australia/">KYC Verification at Online Casinos Australia</a>, <a href="/online-gambling-laws-in-australia/">Online Gambling Laws in Australia: What Players Should Know</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
