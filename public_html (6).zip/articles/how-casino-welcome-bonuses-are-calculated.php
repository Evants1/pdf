<?php
/**
 * Article: How Casino Welcome Bonuses Are Calculated
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the legal position section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('how-casino-welcome-bonuses-are-calculated');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#law">The legal position</a></li>
            <li><a href="#match">Working out the bonus amount</a></li>
            <li><a href="#wagering">Wagering requirement, step by step</a></li>
            <li><a href="#fine-print">The fine print</a></li>
            <li><a href="#value">What an offer is worth</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Run the numbers first</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">How Casino Bonuses Are Calculated: The Short Answer</h2>
      <figure class="shot"><?= gw_img('articles/cb-short', 'Payment list with a clock beside the title Bonus Maths The Short Answer', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>An offer such as ‘100% up to $500’ tells you less than it appears to. To understand how casino bonuses are calculated you need two sums: one for the size of the bonus, and one for how much you must bet before any of it can be withdrawn. The second sum decides whether the offer is worth anything.</p>
      <h3>The two formulas behind every welcome offer</h3>
      <div class="formula">
        <p class="formula-label">The two formulas</p>
        <p class="formula-eq">Bonus amount = deposit × match percentage, up to the cap</p>
        <p class="formula-eq">Wagering requirement = wagering base × multiplier</p>
      </div>
      <p>The wagering base is either the bonus alone or the deposit plus the bonus. The offer's terms state which, and the difference can double the total.</p>
      <p>This guide carries one hypothetical offer through every step: a 100% match up to $500, 35x wagering, a $5 maximum bet and a 7-day expiry, with a $200 deposit. The match gives a $200 bonus. If wagering applies to the bonus only, you must place $7,000 in bets (35 × $200). If it applies to deposit plus bonus, the figure is $14,000 (35 × $400).</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Bonus-only wagering</p>
          <p class="ex-sum">35 × $200</p>
          <p class="ex-big">$7,000</p><p class="ex-lbl">in bets to place</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Deposit-plus-bonus wagering</p>
          <p class="ex-sum">35 × $400</p>
          <p class="ex-big">$14,000</p><p class="ex-lbl">in bets to place</p>
        </div>
      </div>
      <p>Every number in this article is illustrative. None comes from a real casino, and none should be read as typical. Match rates, caps and multipliers vary widely, and the only figures that matter are the ones in the terms of the offer in front of you. No operators are named or recommended here.</p>
      <p>Before the arithmetic, there is a legal point Australian readers need to know.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Two sums decide an offer's value:</strong> the size of the bonus, and how much you must bet before withdrawing.</li>
          <li><strong>The wagering base matters most.</strong> Bonus-only or deposit-plus-bonus can double the total.</li>
          <li><strong>Betting through a requirement has an average cost:</strong> real stakes multiplied by the house edge.</li>
          <li><strong>Welcome bonuses aimed at Australians come from offshore sites,</strong> because online casino games can't lawfully be offered here.</li>
        </ul>
      </div>


      <h2 id="law">Where Online Casino Bonuses Stand in Australia</h2>
      <figure class="shot"><?= gw_img('articles/cb-law', 'Shield with a tick beside the title Bonuses and the Law in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act means for players</h3>
      <p>The Interactive Gambling Act 2001 prohibits providers from offering online casino-style games to people in Australia. That includes online pokies, blackjack and roulette. No Australian licence for an online casino exists, so a site describing its casino games as ‘licensed in Australia’ is making a claim that cannot be true.</p>
      <p>Welcome bonuses aimed at Australians therefore come from offshore sites, and that has practical consequences:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>No Australian regulator oversees the bonus terms or how they are applied.</li>
          <li>If a withdrawal is refused, you have no local dispute process to fall back on.</li>
          <li>The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> can ask internet providers to block illegal sites, which can cut off access to an account and its balance.</li>
        </ul>
      </div>
      <p>The Act's prohibitions are aimed at providers rather than individual players. That is not approval, and it gives you no protection. The Act has also been amended over the years, so rely on the ACMA's current guidance rather than any article, including this one.</p>
      <h3>How to check a provider with the ACMA</h3>
      <p>The ACMA keeps a register of licensed interactive wagering providers, which covers online betting on sport and racing. It also publishes the illegal gambling sites it has had blocked. You can check whether a gambling operator is legal on its website. An online casino will not appear on the register, because that kind of licence does not exist. The ACMA has the final word on what is and is not permitted.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="match">Bonus Percentage Match: Working Out the Bonus Amount</h2>
      <figure class="shot"><?= gw_img('articles/cb-match', 'Gift box beside the title Working Out the Bonus Amount', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Match rate, cap and minimum deposit</h3>
      <p>The bonus percentage match is the share of your deposit the casino adds as bonus funds. The cap is the most it will add. The minimum deposit is the least you must put in to trigger the offer. Using the hypothetical 100% up to $500 offer, and assuming a $20 minimum deposit:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Deposit $10: no bonus, because it is below the minimum.</li>
          <li>Deposit $200: bonus of $200.</li>
          <li>Deposit $500: bonus of $500, which reaches the cap.</li>
          <li>Deposit $800: bonus of $500. The extra $300 earns nothing.</li>
        </ul>
      </div>
      <p>To find the deposit at which the bonus stops growing, divide the cap by the match rate. At 100% up to $500, that is $500. At 200% up to $500, it is $250 ($500 ÷ 2.00). Depositing above that point adds risk without adding bonus.</p>
      <h3>Multi-deposit welcome packages</h3>
      <p>A package advertised as ‘up to $1,000’ is usually several separate offers, each with its own match rate and cap. Calculate each tier on its own. A hypothetical three-part package might look like this:</p>
      <div class="mini3">
        <div><h3>First deposit</h3><p>100% up to $500</p></div>
        <div><h3>Second deposit</h3><p>50% up to $300</p></div>
        <div><h3>Third deposit</h3><p>25% up to $200</p></div>
      </div>
      <p>Three deposits of $200 would return $200, $100 and $50, or $350 in bonus funds. To collect the full $1,000 you would need to deposit $500, $600 and $800, a total of $1,900. Each tier normally carries its own wagering and expiry as well, so treat it as three calculations.</p>
      <h3>Putting a dollar value on free spins</h3>
      <p>Free spins have a face value you can work out: number of spins × the stated value per spin. Fifty spins at $0.20 each is $10 of play. That is the stake value, not what you will win.</p>
      <p>Winnings from free spins are commonly credited as bonus funds with their own wagering requirement. If those 50 spins returned $12 and the terms applied 35x to free spin winnings, you would need to bet $420 before withdrawing. Check the terms for four things: the spin value, which game the spins are locked to, the wagering on winnings, and any cap on what the spins can pay.</p>
      <p class="see-also">Compare common offer types in <a href="/australian-casino-welcome-bonuses-comparison/">Australian casino welcome bonuses: how the main types compare</a>.</p>

      <h2 id="wagering">Wagering Requirement Calculation, Step by Step</h2>
      <figure class="shot"><?= gw_img('articles/cb-wagering', 'Casino coin beside the title Wagering Requirement Step by Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Bonus-only versus deposit-plus-bonus</h3>
      <p>The wagering requirement calculation starts with one question: what is the multiplier applied to? Terms will say something like ‘35x the bonus amount’ or ‘35x the sum of deposit and bonus’. With a 100% match, the second version is exactly double the first. With a smaller match the gap is wider still, because the deposit makes up more of the base.</p>
      <p>Multiply the bonus amount by the wagering multiplier to find the total you must bet.</p>
      <p>If the terms give a multiplier without stating the base, stop there. You cannot calculate the offer.</p>
      <h3>How game contribution changes the total</h3>
      <p>Not every bet counts in full. Each offer has a contribution table showing what percentage of a stake on each game type goes towards wagering. A purely illustrative table might credit pokies at 100%, table games at 10% and list certain games as excluded (0%). The real table is in each offer's terms and can look very different.</p>
      <p>To see what you would actually have to stake, divide the requirement by the contribution rate:</p>
      <div class="formula">
        <p class="formula-label">Formula</p>
        <p class="formula-eq">Real stakes needed = wagering requirement ÷ contribution rate</p>
      </div>
      <p>At 10% contribution, a $7,000 requirement becomes $70,000 in bets. At 0%, the bets do not count at all, and on some sites playing an excluded game with an active bonus can void it.</p>
      <h3>Worked example in AUD</h3>
      <p>Here is the hypothetical offer with a $200 deposit, run under both wagering bases:</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Step</th><th scope="col">Bonus-only wagering</th><th scope="col">Deposit-plus-bonus wagering</th></tr></thead>
      <tbody>
      <tr><th scope="row">Deposit</th><td>$200</td><td>$200</td></tr>
      <tr><th scope="row">Bonus (100% match)</th><td>$200</td><td>$200</td></tr>
      <tr><th scope="row">Wagering base</th><td>$200</td><td>$400</td></tr>
      <tr><th scope="row">Multiplier</th><td>35x</td><td>35x</td></tr>
      <tr><th scope="row">Wagering requirement</th><td>$7,000</td><td>$14,000</td></tr>
      <tr><th scope="row">Stakes needed on pokies (illustrative 100%)</th><td>$7,000</td><td>$14,000</td></tr>
      <tr><th scope="row">Stakes needed on table games (illustrative 10%)</th><td>$70,000</td><td>$140,000</td></tr>
      </tbody>
      </table>
      </div>
      <p>These are totals of bets placed, not losses. A $1 spin counts as $1 towards wagering whether it wins or loses, and winnings can be bet again. Even so, the table shows why the headline matters so little. The same $200 bonus can require anything from $7,000 to $140,000 in stakes, depending on two lines of the terms.</p>

      <h2 id="fine-print">The Fine Print That Changes the Maths</h2>
      <figure class="shot"><?= gw_img('articles/cb-fine', 'Document with a magnifying glass beside the title Fine Print That Changes the Maths', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Maximum bet and expiry</h3>
      <p>Most bonuses limit the size of each bet while the bonus is active and set a deadline for finishing the wagering. Together they tell you how much play the offer actually demands:</p>
      <div class="formula">
        <p class="formula-label">Formulas</p>
        <p class="formula-eq">Minimum rounds = real stakes needed ÷ maximum bet</p>
        <p class="formula-eq">Rounds per day = minimum rounds ÷ days until expiry</p>
      </div>
      <p>For the example, $7,000 ÷ $5 is 1,400 spins, or 200 a day for 7 days. That assumes every spin is at the maximum. At $1 a spin it is 7,000 spins, or 1,000 a day. Under deposit-plus-bonus wagering, double both figures. If the pace looks unrealistic, the bonus will most likely expire with the wagering unfinished.</p>
      <p>Look for these under headings such as ‘maximum bet’ and ‘validity’ or ‘expiry’ in the bonus terms. Exceeding the maximum bet, even once, can be grounds for the site to cancel winnings.</p>
      <h3>Cashout caps and sticky bonuses</h3>
      <p>A cashout cap limits how much you can withdraw from bonus play, often expressed as a multiple of the bonus or a flat amount. If a hypothetical cap were 5x the bonus, the most the $200 bonus could ever return is $1,000. Anything above that is removed at withdrawal.</p>
      <p>A sticky (non-cashable) bonus is deducted when you cash out, so the calculation is: withdrawable amount = final balance − bonus. Finishing the wagering with $450 and a sticky $200 bonus leaves $250.</p>
      <p>A non-sticky bonus keeps your deposit and the bonus separate. Your own money is played first, and you can usually forfeit the bonus and withdraw your cash balance before the bonus funds come into play. Search the terms for ‘maximum withdrawal’, ‘non-cashable’ and ‘forfeit’.</p>
      <h3>Deposit method and currency conditions</h3>
      <p>Some offers exclude deposits made by particular payment methods, so check the ‘eligible deposits’ wording before paying, not after. If the account is not held in AUD, the cap, minimum deposit and maximum bet may be set in another currency. Convert them before running the numbers.</p>
      <p>Your bank or card provider may also charge international transaction or conversion fees, and the site may charge for withdrawals. Any such fees appear on the banking page or in the general terms. They come straight off whatever the bonus is worth to you.</p>
      <p class="see-also">Plain-language terms: <a href="/how-casino-welcome-bonuses-work-in-australia/">how casino welcome bonuses work</a>.</p>

      <h2 id="value">Bonus Value Explained: Estimating What an Offer Is Worth</h2>
      <figure class="shot"><?= gw_img('articles/cb-value', 'Chart with a warning mark beside the title What Is an Offer Worth', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Expected cost of wagering</h3>
      <p>Every casino game has a built-in house edge, so betting through a requirement has an average cost. You can estimate it:</p>
      <div class="formula">
        <p class="formula-label">Formulas</p>
        <p class="formula-eq">House edge = 1 − the game's RTP (return to player)</p>
        <p class="formula-eq">Estimated cost = real stakes needed × house edge</p>
      </div>
      <p>The RTP is published in each game's info or help screen. Use that figure, not a number from a review site, because the same game can be offered in versions with different RTPs.</p>
      <p>For illustration only, assume a pokie showing an RTP of 96%, which is a house edge of 4%. Bonus-only wagering of $7,000 has an estimated cost of $280 ($7,000 × 0.04). That is more than the $200 bonus. Under deposit-plus-bonus wagering the estimate is $560.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Bonus-only: $7,000</p>
          <p class="ex-sum">$7,000 × 4%</p>
          <p class="ex-big">$280</p><p class="ex-lbl">estimated cost, more than the $200 bonus</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Deposit-plus-bonus: $14,000</p>
          <p class="ex-sum">$14,000 × 4%</p>
          <p class="ex-big">$560</p><p class="ex-lbl">estimated cost</p>
        </div>
      </div>
      <p>Switching to table games does not help in the example. Even with an assumed RTP of 99%, the $70,000 of stakes needed at 10% contribution costs an estimated $700.</p>
      <p>This is a long-run average across a very large number of bets. It does not predict what will happen in one session. Your actual result could be far better or far worse, and you may run out of balance before completing the wagering. The estimate is a way to compare offers. It is not a way to profit from them.</p>
      <h3>Why a bigger match is not always better</h3>
      <p>Take a second hypothetical offer: 200% up to $500, with 40x wagering on deposit plus bonus. A $200 deposit earns a $400 bonus, twice the first offer. The wagering base is $600, so the requirement is $24,000, and at the same assumed 4% house edge the estimated cost is $960.</p>
      <p>Compared with the first offer on bonus-only wagering, the bonus doubled but the estimated cost more than tripled, from $280 to $960. A quick comparison figure is required stakes ÷ bonus. The first offer, on bonus-only wagering, needs $35 in bets per bonus dollar. The second needs $60. The headline percentage tells you none of that.</p>
      <h3>A fill-in worksheet for any offer</h3>
      <p>Copy this and complete it from the offer's actual terms:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Deposit:</strong> $____ (minimum to qualify: $____)</li>
          <li><strong>Bonus:</strong> deposit × match % = $____ (cap: $____; use the lower figure)</li>
          <li><strong>Wagering base:</strong> bonus only, or deposit + bonus = $____</li>
          <li><strong>Requirement:</strong> base × multiplier = $____</li>
          <li><strong>Real stakes:</strong> requirement ÷ contribution rate for the game you would play = $____</li>
          <li><strong>Pace:</strong> real stakes ÷ maximum bet = ____ rounds; ÷ days to expiry = ____ per day</li>
          <li><strong>Estimated cost:</strong> real stakes × (1 − RTP from the game's info screen) = $____</li>
          <li><strong>Limits:</strong> cashout cap $____; sticky or non-sticky; excluded games; excluded payment methods; fees $____</li>
        </ol>
      </div>
      <p>If line 7 is larger than line 2, the offer costs more on average than it gives. If you cannot fill in a line because the terms do not say, treat the offer as incomplete and leave it.</p>
      <p class="see-also">For the RTP behind these sums, see <a href="/understanding-rtp-and-volatility-in-online-slots-australia/">understanding RTP and volatility</a>.</p>

      <h2 id="faq">Casino Bonus Calculation FAQ</h2>
      <div class="faq">
        <details>
          <summary>What does a 30x wagering requirement mean?</summary>
          <p>You must place bets totalling 30 times the wagering base before bonus funds, and winnings from them, can be withdrawn. On a hypothetical $200 bonus with bonus-only wagering, that is $6,000 in stakes. If the base is deposit plus bonus, it is $12,000. The figure measures total bets placed, not losses.</p>
        </details>
        <details>
          <summary>Is a 200% match bonus better than a 100% match?</summary>
          <p>Not necessarily. A 200% match gives a larger bonus for the same deposit, but the cap, multiplier and wagering base decide what it costs to clear. In this article's hypothetical comparison, the 200% offer doubled the bonus and more than tripled the required stakes compared with the 100% offer on bonus-only wagering. Compare stakes and estimated cost, not the percentage.</p>
        </details>
        <details>
          <summary>Do all games count towards wagering?</summary>
          <p>Usually not equally. Each offer's terms include a contribution table showing what share of every bet counts. Some games count in full, others for a fraction or nothing, and certain titles can be excluded outright. Divide the requirement by the contribution rate for your chosen game to see the real stakes needed.</p>
        </details>
        <details>
          <summary>Can I withdraw a welcome bonus straight away?</summary>
          <p>Almost never. Bonus funds are locked until the wagering is completed within the time limit, and requesting a withdrawal early usually forfeits the bonus and any winnings from it. With a non-sticky bonus you may be able to withdraw your own cash balance by giving the bonus up. Cashout caps can still apply afterwards.</p>
        </details>
        <details>
          <summary>Are online casino bonuses legal in Australia?</summary>
          <p>The Interactive Gambling Act 2001 prohibits providers from offering online casino games to people in Australia, and no Australian online casino licence exists. Offers therefore come from offshore sites outside Australian consumer protections. The Act is directed at providers, but for the current rules and any recent changes, check with the ACMA.</p>
        </details>
      </div>

      <h2 id="next-step">Run the Numbers Before You Deposit</h2>
      <figure class="shot"><?= gw_img('articles/cb-next', 'Checklist card beside the title Run the Numbers First', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The next step is the worksheet. Open the full terms of the offer, fill in all eight lines with its actual figures, and compare the estimated cost with the bonus. If the terms are vague about the wagering base, contribution rates, maximum bet or cashout cap, that is your answer: walk away.</p>
      <p>A calculation cannot make an offshore site accountable. A bonus that looks reasonable on paper still depends on a provider that is not permitted to offer casino games to people in Australia.</p>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over. No bonus guarantees winnings, and the maths above shows the average result is a cost. Set a money and time limit before you start, and never chase losses. Free, confidential support is available 24/7 from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a>. <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the national self-exclusion register, covers Australian-licensed wagering services and does not extend to offshore casino sites.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/australian-casino-welcome-bonuses-comparison/">Australian Casino Welcome Bonuses 2026 Comparison: How the Main Types Compare</a>, <a href="/best-casino-bonuses-for-australian-players/">Best Bonuses for Australian Players 2026: Choosing One That Suits You</a>, <a href="/no-deposit-bonuses-australia/">No-Deposit Bonuses Australia: What “Free Money to Play” Really Costs</a>, <a href="/best-no-deposit-casino-offers-australia/">Best No-Deposit Casino Offers Australia Right Now: How to Spot a Good One</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
