<?php
/**
 * Article: Best No-Deposit Casino Offers Australia Right Now: How to Spot a Good One
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. KEYWORD-OVERLAP RISK: this page overlaps /no-deposit-bonuses-australia/ and the welcome-bonus pages
 *    (/how-casino-welcome-bonuses-are-calculated/, /how-casino-welcome-bonuses-work/ and its Australia version).
 *    Consider giving each a distinct angle or merging some with 301 redirects.
 * 2. Re-check before publishing: Neosurf being "typically deposit-only", the statement that Australia "issues no licence"
 *    for online casino games, and that ACMA's "Interactive Gambling Act page" exists under that name.
 * 3. The text promises to name an operator only when "its own terms have been read on publication day and date-stamped".
 *    The page names none, which keeps that promise.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the offer types section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('best-no-deposit-casino-offers-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#law">Where Australian law stands</a></li>
            <li><a href="#types">Offer types you'll see</a></li>
            <li><a href="#numbers">Five numbers that decide the value</a></li>
            <li><a href="#verify">Is the offer real and cashable?</a></li>
            <li><a href="#fun">Keep it fun</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Run the five-number check</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>If you're searching for the best no deposit offers Australia can access right now, start with a fact most ranking lists leave out. Every online casino pitching these bonuses to Australians is an offshore site operating outside federal law. None is licensed here, because Australia issues no licence for online casino games. The offers exist. The legal position just changes how much any of them is worth.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Every site offering these bonuses to Australians is offshore.</strong> None is licensed here, so there is little recourse if something goes wrong.</li>
          <li><strong>The best offer is rarely the biggest headline.</strong> Look for low wagering, a clear maximum cashout in AUD and terms you can verify yourself.</li>
          <li><strong>Five numbers decide what an offer is worth:</strong> wagering, maximum cashout, spin value, expiry and maximum bet.</li>
          <li><strong>Treat every no deposit bonus as a trial with a small, capped upside,</strong> never as free money.</li>
        </ul>
      </div>

      <h2 id="short-answer">Best no deposit offers Australia: the short answer</h2>
      <figure class="shot"><?= gw_img('articles/nd-short', 'Gift box beside the title No Deposit Offers Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Two kinds of no deposit casino offers make up most of what you'll see. The first is a bundle of free spins locked to one pokie the casino chooses. The second is a small free chip, meaning bonus cash credited when you register or enter a code. A smaller third group asks you to install an app, verify a mobile number or already hold a funded account.</p>
      <p>All of it comes from offshore sites, so the best offer is rarely the one with the biggest headline. It's the one with:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Low wagering on the bonus or the winnings from it.</li>
          <li>A clear maximum cashout stated in AUD, not euros or “credits”.</li>
          <li>Terms you can verify on the operator's own site, today, without contacting support.</li>
        </ul>
      </div>
      <p>This guide doesn't name a casino. Figures on ranking pages often contradict each other, and the same brand can show different spin counts from one list to the next. We only name an operator when its own terms have been read on publication day and date-stamped. What you'll get here is a five-number method for valuing any offer and a checklist for confirming it's real. Treat every no deposit bonus as a trial with a small, capped upside, never as free money.</p>

      <h2 id="law">Where Australian law stands before you claim anything</h2>
      <figure class="shot"><?= gw_img('articles/nd-law', 'Shield with a tick beside the title The Law Before You Claim', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act bans</h3>
      <p>The Interactive Gambling Act 2001 prohibits offering online casino-style games for real money to people in Australia. That covers online pokies, roulette, blackjack and similar games. It also prohibits advertising those services here. No Australian regulator issues a licence for online casino games, so any site describing itself as “Australian-licensed” for pokies is wrong or misleading.</p>
      <p>The Act's offence provisions are aimed at the companies that provide and promote these services, not at individual players. That is not the same as saying playing is legal or safe, and this article isn't legal advice. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces the Act, and its Interactive Gambling Act page is the final word. The rules are amended from time to time, so read the current version instead of relying on a summary.</p>
      <h3>What that means for your money</h3>
      <p>These operators sit outside Australian law. If one withholds your winnings or your deposit, you have very little recourse. There's no local ombudsman for offshore casinos and no Australian licence for a regulator to suspend. An offshore licence, where one exists, belongs to another jurisdiction and shouldn't be read as protection for Australians.</p>
      <p>Access can also disappear. ACMA can ask internet service providers to block illegal gambling sites, and it publishes a list of blocked gambling websites. If a site you've been using goes behind a block, any balance you hold may become hard to reach. Whether you see it again depends on the operator's goodwill.</p>
      <p>A no deposit bonus limits how much of your own money is exposed. It doesn't limit what you hand over in personal details and ID documents. Weigh that before you register anywhere.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="types">No deposit casino offers you'll see right now, by type</h2>
      <figure class="shot"><?= gw_img('articles/nd-types', 'Casino table beside the title Offer Types You Will See Right Now', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Strip away the branding and nearly every promotion fits one of the rows below. The table has no amounts on purpose. Figures change week to week and need to come from the operator's terms.</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Offer type</th><th scope="col">How it's claimed</th><th scope="col">Usual catch</th><th scope="col">Who it suits</th></tr></thead>
      <tbody>
      <tr><th scope="row">No deposit free spins</th><td>Credited on sign-up, after email verification or with a code</td><td>Fixed low spin value on one pokie; winnings become bonus funds with wagering and a cashout cap</td><td>Pokies players who want to test a site's lobby and mobile experience</td></tr>
      <tr><th scope="row">Free chip (bonus cash)</th><td>Code at registration or in the cashier, sometimes via live chat</td><td>Wagering on the chip amount, restricted games, maximum bet per spin</td><td>Players who want a choice of several pokies</td></tr>
      <tr><th scope="row">App or phone-verification reward</th><td>Install the app or confirm a mobile number by SMS</td><td>May only be available to accounts that have already deposited; you share more personal data</td><td>Existing customers who would use the app anyway</td></tr>
      <tr><th scope="row">Existing-player freebie</th><td>Loyalty tier, email promotion or account activity</td><td>Not open to new sign-ups, despite being listed as “no deposit”</td><td>Players who already have an account and history there</td></tr>
      <tr><th scope="row">“No deposit” with a deposit condition</th><td>Claimed free, but a deposit is required before withdrawal</td><td>You must pay in to cash out, and the deposit may carry its own turnover rule</td><td>Few people; read the terms twice</td></tr>
      </tbody>
      </table>
      </div>
      <h3>No deposit free spins</h3>
      <p>This is the most common format. The casino picks the pokie and the bet size, and you get a set number of spins. Whatever you win usually lands as bonus funds, not cash, and the wagering requirement applies to that amount. The spin value is often set at or near the game's minimum bet, so a large spin count can represent very little total stake.</p>
      <h3>Free chips and bonus cash</h3>
      <p>A free chip is a small bonus balance you can spread across eligible games. You get more choice than with spins, but the terms tend to be stricter about which pokies count, how much you can bet per spin and how wagering is calculated. Table games and live dealer games are commonly excluded or count for only a fraction.</p>
      <h3>App, phone-verification and existing-player offers</h3>
      <p>These are the ones most often mislabelled. An app reward that's only released once you've deposited isn't a no deposit offer for a new player. Neither is a loyalty freebie. If a listing doesn't say who qualifies, assume the terms will.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="numbers">Five numbers that decide what an offer is really worth</h2>
      <figure class="shot"><?= gw_img('articles/nd-five', 'Casino coin beside the title Five Numbers That Decide the Value', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Headline size tells you little. These five figures tell you nearly everything, and all of them should appear in the operator's bonus terms.</p>
      <p>Check these five numbers before you claim any no deposit bonus.</p>
      <h3>Wagering requirement</h3>
      <p>Wagering (also called playthrough or turnover) is how many times you must bet the bonus, or the winnings from free spins, before anything can be withdrawn. Check what the multiple applies to, because that changes the maths.</p>
      <p>Hypothetical example: a $10 free chip with 40x wagering means placing $400 of bets before a withdrawal is possible. Every dollar of that turnover is exposed to the house edge. If the pokie returned 96% over the long run (an assumed figure, for illustration only), $400 of bets would cost about $16 on average. That's more than the chip itself, so on average the balance runs out before the wagering is done. Some players get through on a lucky run, which is where the next number comes in.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Turnover required</p>
          <p class="ex-sum">40 × $10 chip</p>
          <p class="ex-big">$400</p><p class="ex-lbl">of bets before any withdrawal</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Average cost at 96% RTP</p>
          <p class="ex-sum">$400 × 4% (assumed)</p>
          <p class="ex-big">$16</p><p class="ex-lbl">more than the $10 chip itself</p>
        </div>
      </div>
      <h3>Maximum cashout</h3>
      <p>Most no deposit bonuses cap what you can withdraw from them. Win more than the cap and the excess is removed when you cash out. The cap is your real ceiling, so compare it with the effort involved.</p>
      <p>Check its currency too. Some listings quote caps in euros, and a cap in EUR or USD is worth a different amount in AUD depending on the day's exchange rate. If the offer page doesn't state a cap, don't assume there isn't one. Look in the general bonus terms as well.</p>
      <h3>Spin value and eligible pokie</h3>
      <p>Spin count alone misleads. In another hypothetical, 100 spins at $0.10 and 20 spins at $0.50 both add up to $10 of total stake, yet the first will be advertised five times as loudly. Multiply the spin count by the spin value to get a figure you can compare.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">100 spins at $0.10</p>
          <p class="ex-sum">100 × $0.10</p>
          <p class="ex-big">$10</p><p class="ex-lbl">total stake</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">20 spins at $0.50</p>
          <p class="ex-sum">20 × $0.50</p>
          <p class="ex-big">$10</p><p class="ex-lbl">total stake, advertised five times less loudly</p>
        </div>
      </div>
      <p>Then look at which pokie the spins are tied to. Open the game's info screen to see its return-to-player percentage and volatility. Don't trust a figure quoted elsewhere.</p>
      <h3>Expiry and maximum bet</h3>
      <p>These two smaller numbers are easy to overlook, and either can cost you the whole bonus. Expiry is how long you have to use the spins and, separately, to finish wagering. If the window is short and you play in snatches on your phone, the balance can simply lapse. Maximum bet is the largest stake allowed per spin while bonus funds are active. Go over it once, even by accident, and many terms pages let the casino confiscate the winnings.</p>
      <p>Put together, a quick score looks like this:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Total stake value (spins × spin value, or the chip amount).</li>
          <li>Turnover required (wagering multiple × the amount it applies to).</li>
          <li>Maximum cashout in AUD.</li>
          <li>Time allowed.</li>
          <li>Maximum bet per spin.</li>
        </ol>
      </div>
      <p>If the turnover is huge relative to the cap, or any of the five is missing, the offer is worth less than it looks.</p>
      <p class="see-also">The full arithmetic is in <a href="/how-casino-welcome-bonuses-are-calculated/">how casino welcome bonuses are calculated</a>.</p>

      <h2 id="verify">How to check the latest no deposit bonus is real, and cashable</h2>
      <figure class="shot"><?= gw_img('articles/nd-check', 'Checklist card beside the title Is the Offer Real and Cashable', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A listing is only a claim about an offer. The offer itself is whatever the operator's terms say. Checking one against the other takes a few minutes.</p>
      <h3>Read the operator's own bonus terms, not the listing</h3>
      <p>Go to the casino's promotions page and its general bonus terms. Confirm the offer exists there, that Australia isn't on the restricted-countries list for it, and that the figures match what the listing told you. If the code came from a third-party page and the operator's site doesn't mention the promotion, ask live chat to confirm it in writing and keep a screenshot.</p>
      <h3>Look for deposit-before-withdrawal and ID rules</h3>
      <p>Many “no deposit” bonuses require a deposit before any winnings can be withdrawn, sometimes with its own turnover condition. Others are only open to accounts that have deposited before.</p>
      <p>Expect identity checks too: photo ID, proof of address and sometimes proof of the payment method. Be wary of “no-KYC” promises on review pages. The terms page decides when verification happens, and it's commonly at your first withdrawal.</p>
      <h3>Check the site against ACMA's blocked list</h3>
      <p>Search the exact site name on ACMA's blocked gambling websites list. If the name appears there, or the site keeps changing its web address, your access to any balance may not last.</p>
      <p>The full checklist:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Date-stamp.</strong> Does the listing say when the offer was last checked? No date, no trust.</li>
          <li><strong>Source of the code.</strong> Is the code shown on the operator's site or confirmed by its support?</li>
          <li><strong>Eligibility.</strong> Is it for new players only, or existing depositors? Are Australian residents excluded?</li>
          <li><strong>Currency of caps.</strong> Are the maximum cashout and maximum bet in AUD?</li>
          <li><strong>Deposit rule.</strong> Is a deposit needed before withdrawal?</li>
          <li><strong>KYC timing.</strong> Which documents are required, and at what stage?</li>
          <li><strong>Withdrawal methods.</strong> Open the cashier page and see what's available for withdrawals, not just deposits. PayID and bank transfer may be offered for both. Crypto often is, though its AUD value moves with the market and transfers can't be reversed. Neosurf is a prepaid voucher and typically deposit-only, so you'd need a second method to cash out. Compare the minimum withdrawal with the cashout cap, and ignore payout-speed claims you can't confirm in the terms.</li>
          <li><strong>ACMA check.</strong> Is the site on the blocked list?</li>
        </ol>
      </div>

      <h2 id="fun">Keep it fun: limits, age rules and where to get help</h2>
      <figure class="shot"><?= gw_img('articles/nd-fun', 'Limit sliders beside the title Keep It Fun with Limits and Help', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Online gambling is for adults aged 18 and over. A no deposit bonus doesn't change the odds, and no offer, system or bonus code guarantees a win. Expect most free-spin sessions to end with nothing to withdraw. That's how the maths works, not bad luck.</p>
      <p>Decide your limits before you register. If you do go on to deposit, set a fixed amount you can afford to lose and a time limit for the session. Don't deposit just to release a bonus win you hadn't planned to chase.</p>
      <div class="rg-card">
      <p>If gambling stops being fun, or you're worried about someone else, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support around the clock at <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a> or on <a href="tel:1800858858">1800 858 858</a>. <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, covers licensed Australian online and phone wagering providers only. It doesn't extend to offshore casinos, so self-exclusion there relies on whatever tools the site itself offers.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">No deposit bonus FAQs</h2>
      <div class="faq">
        <details>
          <summary>Are no deposit casino offers legal in Australia?</summary>
          <p>Offering them isn't. The Interactive Gambling Act 2001 prohibits providing or advertising online casino games, including pokies, to people in Australia, and no Australian licence exists for them. The Act's offences target operators, not individual players, but that doesn't make playing legal, protected or risk-free, and you'd have little recourse in a dispute. ACMA's Interactive Gambling Act page sets out the current position and should be treated as the final word.</p>
        </details>
        <details>
          <summary>Can I withdraw winnings from no deposit free spins?</summary>
          <p>Sometimes, and only within tight limits. Winnings usually convert to bonus funds that must be wagered a set number of times, within a deadline, at or under a maximum bet. What's left is then subject to a maximum cashout, identity checks and, at some sites, a deposit before withdrawal. Because the operator is offshore, there's no guarantee of payment even when you meet every condition. For questions about tax on winnings, check with the ATO.</p>
        </details>
        <details>
          <summary>Do I need a bonus code to claim a no deposit bonus?</summary>
          <p>It depends on the offer. Some are credited automatically after registration or email verification, some need a code entered at sign-up or in the cashier, and some are added manually by live chat. Codes on third-party pages expire or get recycled, so confirm the code on the operator's own promotions page or with its support before registering. Entering the wrong code, or none, can mean missing the offer with no way to add it later.</p>
        </details>
        <details>
          <summary>Why do different sites list different no deposit offers for the same casino?</summary>
          <p>There are several possible reasons. Casinos may give different affiliates different exclusive codes, offers can vary by country, and promotions change faster than list pages are updated. Some listings also show expired deals, or figures in euros meant for another market. So the same brand can appear with conflicting spin counts across pages. The only version that binds the casino is the one in its own terms on the day you sign up. Check there.</p>
        </details>
        <details>
          <summary>Do I have to verify my ID to claim a no deposit bonus?</summary>
          <p>Usually not to receive the bonus, but almost always before withdrawing. Some sites ask for email or mobile verification to release the spins, then request photo ID and proof of address at cashout. A few verify at registration. Read the terms to see which applies. Then think about whether you're comfortable sending identity documents to an offshore company that isn't overseen by any Australian gambling regulator.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: run the five-number check on one offer</h2>
      <figure class="shot"><?= gw_img('articles/nd-next', 'Document with a magnifying glass beside the title Run the Five-Number Check', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Pick one offer you've seen today, and only one. Then:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Find its page on the operator's own site, plus the general bonus terms.</li>
          <li>Write down the five numbers: total stake value, turnover required, maximum cashout in AUD, expiry and maximum bet.</li>
          <li>Check for a deposit-before-withdrawal rule and when ID is required.</li>
          <li>Search the site on ACMA's blocked list.</li>
        </ol>
      </div>
      <p>If any of the five numbers is missing, the cap is in a currency you didn't expect, or the terms contradict the listing, walk away. Another latest no deposit bonus will appear on someone's list tomorrow, and it deserves the same check.</p>
      <p>An offer that passes is still a small, capped trial on an offshore site with no local safety net. One that fails isn't worth your details. Either way, you'll have judged it on its terms, not its headline.</p>
      <p><strong>Related reading:</strong> <a href="/how-casino-welcome-bonuses-work/">How Casino Welcome Bonuses Work, and What to Check First</a>, <a href="/how-casino-welcome-bonuses-work-in-australia/">How Casino Welcome Bonuses Work in Australia</a>, <a href="/how-casino-welcome-bonuses-are-calculated/">How Casino Welcome Bonuses Are Calculated</a>, <a href="/australian-casino-welcome-bonuses-comparison/">Australian Casino Welcome Bonuses 2026 Comparison: How the Main Types Compare</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
