<?php
/**
 * Article: Crypto Casinos Explained: Benefits and Risks
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. KEYWORD-OVERLAP RISK: this page and /crypto-casinos-australia-bitcoin-gambling-guide/ are not copies (the wording
 *    differs, only one sentence is identical) but they cover the same topics in the same order and both target
 *    "crypto casino Australia" and "bitcoin gambling guide". Two pages aimed at the same searches can compete with
 *    each other. Consider giving this page a different angle (for example the benefits-and-risks view in its
 *    title) or merging the two with a 301 redirect.
 * 2. The step-by-step funding, vetting and test-withdrawal detail for offshore casinos is supplied text. Get an
 *    Australian lawyer's view on it, and re-check the ATO and AUSTRAC statements on the official sites.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the "exchange to cash-out" section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('crypto-casinos-explained-benefits-and-risks');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#law">What the law says</a></li>
            <li><a href="#payments">Exchange to cash-out</a></li>
            <li><a href="#risks">Risks toplists skip</a></li>
            <li><a href="#vetting">How to vet a Bitcoin casino</a></li>
            <li><a href="#tax">Tax on crypto winnings</a></li>
            <li><a href="#control">Limits, alternatives and support</a></li>
            <li><a href="#faq">FAQs</a></li>
            <li><a href="#next-step">Your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Search “crypto casino Australia” and you'll get page after page of rankings and bonus banners. Most leave the legal position for a footnote, so here it is up front: under the Interactive Gambling Act 2001, online casino services cannot lawfully be offered to people in Australia. There is no Australian licence for an online casino, and paying in Bitcoin or any other coin changes nothing.</p>
      <p>Every site advertising online pokies or live tables to Australians is therefore operating from offshore, outside Australian consumer protection. This bitcoin gambling guide covers the law, how the payments work, the risks, the tax angle and how to check a site's claims. It's written for adults aged 18 and over, and it contains no rankings.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>There is no Australian licence for an online casino,</strong> and paying in Bitcoin changes nothing.</li>
          <li><strong>Blockchain transfers can't be charged back,</strong> and a coin balance's AUD value moves while you play.</li>
          <li><strong>Check the licence at the issuing regulator,</strong> read the terms and run a small test withdrawal before depositing more.</li>
          <li><strong>The tax position needs its own check:</strong> a gambling win is generally outside CGT, but selling or spending the coins later may not be.</li>
        </ul>
      </div>

      <h2 id="law">Crypto casino Australia: what the law actually says</h2>
      <figure class="shot"><?= gw_img('articles/cexp-law', 'Shield with a tick beside the title The Law and Crypto Casinos', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act 2001 prohibits</h3>
      <p>The Act makes it an offence to provide certain interactive gambling services to customers in Australia, and to advertise them here. The prohibited category includes online casino-style games such as pokies, roulette and blackjack, along with online poker.</p>
      <p>What Australian law does allow online is narrower: wagering on sport and racing, and lotteries, through operators licensed by a state or territory. No state or territory issues a licence for an online casino, so a “licensed Australian crypto casino” does not exist. The ban turns on the service being offered, not on how you pay, so accepting cryptocurrency does not exempt an operator.</p>
      <h3>Where that leaves players</h3>
      <p>The Act's offences are aimed at the businesses that provide and promote these services, not at the individual placing a bet. That is not the same as saying playing is legal, approved or protected. The operator is breaking Australian law by serving you, and you have none of the safeguards that come with a locally licensed product.</p>
      <p>A licence from an overseas jurisdiction doesn't alter this. It may say something about how the operator is supervised at home, but it does not make the site licensed in Australia. Gambling law is also amended from time to time, so treat ACMA, the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority</a>, as the final word on the current position, not this or any other article.</p>
      <h3>How ACMA enforces it</h3>
      <p>ACMA investigates complaints, issues formal warnings, can pursue civil penalties and asks internet service providers to block illegal gambling websites. It publishes two tools worth using:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">ACMA tool</p>
          <h3>The register of licensed interactive wagering services</h3>
          <p>Search an operator's name. If it isn't there, it isn't licensed to offer online gambling in Australia. Because the register covers wagering providers, no online casino will appear on it.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">ACMA tool</p>
          <h3>The blocked gambling websites list</h3>
          <p>Check whether a site has already been blocked. The list grows with each round of blocks. A site's absence means only that it hasn't been dealt with yet, not that it is lawful.</p>
        </article>
      </div>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="payments">How Bitcoin gambling works, from exchange to cash-out</h2>
      <figure class="shot"><?= gw_img('articles/cexp-payments', 'Wallet with payment cards beside the title Exchange to Cash-Out Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Pages ranking for “bitcoin casino Australia” make the process look like one click. In practice your dollars go to an exchange, become a coin, travel to an address the casino gives you, and eventually make the same trip in reverse. Each leg has its own way of losing money before a bet is placed.</p>
      <h3>Buying crypto with AUD (PayID, bank transfer)</h3>
      <p>Most Australians buy crypto through an exchange that accepts AUD by PayID or standard bank transfer. Digital currency exchanges operating in Australia are required to register with AUSTRAC and verify their customers' identity, so the chain starts with your name attached to it.</p>
      <p>Two snags come up often. Some banks limit, delay or decline payments to crypto exchanges, and some block gambling-related transactions. Policies differ and change, so ask your bank instead of relying on a forum post. Some exchanges also restrict transfers to gambling services in their terms. Read those before you buy.</p>
      <h3>Wallets, networks and address checks</h3>
      <p>The casino's cashier generates a deposit address for a specific coin on a specific network. Send the wrong asset, or the right asset on the wrong chain, and the funds may be gone for good. USDT is the classic trap: it exists on several blockchains, and a deposit sent on a network the casino doesn't support for that address is often unrecoverable.</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Match the coin and the network on both the sending and receiving screens.</li>
          <li>Paste the address, then compare the first and last several characters, because clipboard-swapping malware exists.</li>
          <li>Check whether a memo or tag is required.</li>
          <li>Send a small test amount and wait for it to be credited before sending more.</li>
          <li>Treat a casino balance as money at risk, not as a wallet. Keep there only what you intend to play.</li>
        </ul>
      </div>
      <h3>Coins compared: BTC, ETH, LTC and USDT</h3>
      <figure class="shot"><?= gw_img('articles/cexp-coins', 'Crypto coin beside the title BTC ETH LTC and USDT', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Coin</th><th scope="col">Price movement against AUD</th><th scope="col">Network fee tendency</th><th scope="col">Speed tendency</th><th scope="col">Watch for</th></tr></thead>
      <tbody>
      <tr><th scope="row">Bitcoin (BTC)</th><td>High</td><td>Variable; rises when the network is busy</td><td>Slower confirmations than most alternatives</td><td>Value can shift noticeably during a pending withdrawal</td></tr>
      <tr><th scope="row">Ethereum (ETH)</th><td>High</td><td>Variable; can spike sharply at busy times</td><td>Generally quicker than Bitcoin</td><td>Fees that are large relative to a small deposit</td></tr>
      <tr><th scope="row">Litecoin (LTC)</th><td>High</td><td>Usually low</td><td>Generally quick</td><td>Not every exchange or casino supports it</td></tr>
      <tr><th scope="row">Tether (USDT)</th><td>Designed to track the US dollar, so it still moves against AUD</td><td>Depends entirely on the chain used</td><td>Depends entirely on the chain used</td><td>Wrong-network deposits; reliance on the issuer maintaining the peg</td></tr>
      </tbody>
      </table>
      </div>
      <p>These are tendencies, not promises. Check the live network fee in your wallet or exchange at the moment you send, and the casino's cashier page for its minimum deposit and required confirmations. All of these change.</p>
      <p class="see-also">A beginner glossary is in <a href="/crypto-casinos-australia-bitcoin-gambling-guide/">crypto casinos in Australia: a Bitcoin gambling guide</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="risks">Risks of crypto gambling in Australia that toplists skip</h2>
      <figure class="shot"><?= gw_img('articles/cexp-risks', 'Chart with a warning mark beside the title Risks the Toplists Skip', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>No Australian regulator or dispute path</h3>
      <p>With a licensed Australian bookmaker, an unresolved complaint can go to the state or territory regulator that issued the licence. With an offshore casino there is no equivalent. ACMA takes complaints about illegal services and can have a site blocked, but it does not recover individual players' money.</p>
      <p>Your only formal avenues are the operator's own support desk and, if a genuine licence exists, an overseas regulator whose willingness to help Australian players may be limited.</p>
      <h3>Irreversible payments and price swings</h3>
      <p>A card payment can sometimes be disputed through your bank. A blockchain transfer can't: once it's confirmed, only the recipient can send it back. That removes the one piece of leverage a player normally has when a deposit goes missing or a site stops responding.</p>
      <p>Price movement adds a second layer. If your balance is held in BTC or ETH, its dollar value shifts while you play and while a withdrawal sits pending. A session that looks even in coin terms can be a loss in AUD, and a rising price can make losses look smaller than they are. Some sites convert deposits to a USD-denominated balance instead. If yours does, check the conversion rate applied in each direction.</p>
      <h3>KYC at withdrawal and blocked domains</h3>
      <p>Many sites advertise sign-up with just an email address, then reserve the right in their terms to demand identity documents before paying out, particularly on larger wins. Players commonly report accounts frozen at this stage, sometimes on the ground that their country is on the restricted list. Accessing a site through a VPN is frequently listed as a breach that lets the operator void winnings, which is one more reason not to do it.</p>
      <p>When ACMA has a domain blocked, operators often reappear on a “mirror” address. Phishing copies imitate those mirrors to harvest logins and deposits, and it's hard to tell which is which. A block is a clear signal to stop depositing, not a prompt to chase the new URL.</p>

      <h2 id="vetting">How to vet a Bitcoin casino before sending any crypto</h2>
      <figure class="shot"><?= gw_img('articles/cexp-vetting', 'Checklist card beside the title Nine Checks Before You Send Crypto', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>No checklist makes an offshore casino lawful to offer in Australia, or safe. These steps filter out the worst operators and show you exactly what you'd be agreeing to. Work through them in order.</p>
      <h3>Verify the licence at the issuing regulator</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Record the claim.</strong> In the site footer, note the company name, licence number and the regulator named. A missing company name or number is a red flag in itself.</li>
          <li><strong>Check it at the source.</strong> Type the regulator's web address yourself instead of clicking the casino's seal, which can link to a fake validation page. Search the regulator's public register for the company and the exact domain you're using.</li>
          <li><strong>Look for a complaints process.</strong> See whether the regulator accepts player complaints and from which countries. If you can't confirm the licence independently, treat the site as unlicensed.</li>
        </ol>
      </div>
      <h3>Read withdrawal, KYC and bonus terms</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Withdrawals.</strong> Find the minimum and maximum amounts per transaction and per period, any fees, the stated processing time and which coins and networks are supported for cashing out.</li>
          <li><strong>KYC and restricted countries.</strong> Read when documents can be requested and whether Australia appears on the restricted list. If it does, the operator has a ready-made reason to close your account.</li>
          <li><strong>Bonus rules.</strong> Before accepting any offer, locate the wagering requirement, maximum bet while the bonus is active, game weightings, any cap on winnings and the expiry. If you can't find all five, decline the bonus. Screenshot the terms on the day you deposit.</li>
        </ol>
      </div>
      <h3>Test provably fair claims and start small</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Verify a few rounds.</strong> A provably fair game publishes a hashed server seed before you bet and lets you combine it with your own seed afterwards to recompute the result. Do this for several rounds with a verifier you didn't get from the casino.</li>
          <li><strong>Know its limits.</strong> A successful check shows that individual outcomes weren't altered after the bet. It says nothing about the house edge, usually doesn't cover third-party pokies or live dealer games, and is no guarantee you'll be paid.</li>
          <li><strong>Run a full loop first.</strong> Deposit a small amount, play briefly, then withdraw to your own wallet. Don't add more until that withdrawal has arrived.</li>
        </ol>
      </div>
      <p class="see-also">For a fuller evaluation method, see <a href="/crypto-casinos-australia-2026-how-to-evaluate/">how to evaluate a crypto casino</a>.</p>

      <h2 id="tax">Tax on crypto gambling winnings: what the ATO says</h2>
      <figure class="shot"><?= gw_img('articles/cexp-tax', 'Payment list with a clock beside the title Tax on Crypto Winnings', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Toplists almost never mention tax. The ATO sets out its position in its crypto asset investments guidance, and that is the source to rely on, not a casino blog.</p>
      <h3>The win versus the later sale</h3>
      <p>In broad terms, the ATO's guidance leaves a gambling win itself out of the capital gains tax calculation, and winnings from recreational gambling have not generally been treated as income. The position may differ for someone found to be carrying on a business of gambling.</p>
      <p>The coins you win are a different matter once you hold them. If you later sell, swap or spend them, CGT may apply to any change in value since the win, measured from their market value in AUD on the day you received them. Win crypto, hold it while the price rises, then cash out to your bank, and that increase may be a taxable gain.</p>
      <p>Whether buying coins to deposit, or converting between coins along the way, has tax consequences of its own depends on your circumstances. Don't assume either way. Check with the ATO or a registered tax agent.</p>
      <h3>Records worth keeping</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>The date and AUD value of every purchase, deposit, withdrawal and sale</li>
          <li>Transaction IDs and the wallet addresses involved</li>
          <li>Exchange statements showing AUD in and out</li>
          <li>The casino's deposit and withdrawal history, exported or screenshotted as you go</li>
        </ul>
      </div>
      <p>Save casino records regularly, because access can vanish overnight if an account is closed or a domain is blocked. This section is general information, not tax advice.</p>

      <h2 id="control">Responsible gambling: limits, legal alternatives and support</h2>
      <p>Online gambling is for adults aged 18 and over. Every casino game carries a house edge, no strategy or choice of coin guarantees winnings, and anything you deposit should be money you can afford to lose entirely.</p>
      <h3>Set deposit and time limits in AUD terms</h3>
      <p>Decide on a dollar figure per week or month before you buy any crypto, and track it in AUD. Coin-denominated balances make losses hard to feel: a fraction of a Bitcoin doesn't register the way $200 does, and price swings blur the picture further. Set a time limit too, and don't top up mid-session. Where offshore sites offer their own limit tools, no Australian rule stands behind them.</p>
      <h3>Licensed options and where BetStop applies</h3>
      <p>The licensed online options in Australia are sports and race wagering and lotteries through operators on ACMA's register, with land-based casinos and pokies venues regulated by the states and territories. None of these is a crypto alternative: a ban on credit cards and digital currencies applies to online wagering, and ACMA's website has the current wording.</p>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, covers licensed Australian online and phone wagering providers. It does not reach offshore casinos, so registering won't stop one from taking your deposit. The details are at betstop.gov.au.</p>
      <h3>Where to get help</h3>
      <div class="rg-card">
      <p><a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support around the clock on <a href="tel:1800858858">1800 858 858</a> and by online chat at gamblinghelponline.org.au. Chasing losses, hiding your play or gambling with money set aside for bills are all reasons to make contact.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Crypto casino FAQs for Australians</h2>
      <div class="faq">
        <details>
          <summary>Is it illegal to play at a crypto casino in Australia?</summary>
          <p>The Interactive Gambling Act 2001 makes it illegal to provide or advertise online casino services to people in Australia, and its offences target operators, not individual players. That doesn't make playing legal or protected, and you'd have no Australian recourse if something went wrong. ACMA is the authority on the current rules.</p>
        </details>
        <details>
          <summary>Are there any Australian-licensed Bitcoin casinos?</summary>
          <p>No. No state or territory licenses online casinos, so any site offering casino games online to Australians is offshore, whatever licence it displays. Licensed Australian wagering operators, for their part, can't accept digital currencies. You can confirm who is licensed on ACMA's register.</p>
        </details>
        <details>
          <summary>Do I pay tax on Bitcoin gambling winnings in Australia?</summary>
          <p>ATO guidance generally leaves a recreational gambling win itself out of the CGT calculation. CGT may apply later when you sell, swap or spend the coins you won, calculated from their AUD market value on the day of the win. Check the ATO's crypto guidance or ask a registered tax agent about your situation.</p>
        </details>
        <details>
          <summary>Is a no-KYC crypto casino actually anonymous?</summary>
          <p>Rarely. Bitcoin and most other blockchains are public ledgers, and if you bought your coins on an Australian exchange your identity is linked to the purchase. Many “no-KYC” sites also keep the right to request documents before a withdrawal, so the anonymity can end exactly when you want to be paid.</p>
        </details>
        <details>
          <summary>Can I get my money back if an offshore casino won't pay?</summary>
          <p>Often not. Crypto transfers can't be charged back, ACMA doesn't recover individual losses, and an overseas regulator may or may not assist. Keep your records, complain in writing to the operator and the licensing body it names, report the site to ACMA, and be wary of “recovery” services asking for upfront fees.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step before you deposit</h2>
      <figure class="shot"><?= gw_img('articles/cexp-next', 'Limit sliders beside the title Before You Deposit Anything', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Before any crypto leaves your wallet, do four things in this order.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Search the operator on ACMA's register and its blocked gambling websites list. Expect it to be missing from the first, and walk away if it's on the second.</li>
          <li>Run the nine-point vetting checklist above, starting with the licence check at the issuing regulator's own website.</li>
          <li>Write down a hard limit in AUD for the month and the time you'll allow per session, and decide now what you'll do when you hit either.</li>
          <li>Ask whether you still want to go ahead. Choosing not to play is a perfectly good outcome of doing the research, and it's the only one with no risk attached.</li>
        </ol>
      </div>
      <p>If you do proceed, start with the smallest amount the site accepts and complete a withdrawal before depositing again. If gambling is already causing you stress, call <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> first.</p>
      <p><strong>Related reading:</strong> <a href="/crypto-casinos-australia-bitcoin-gambling-guide/">Crypto Casinos Australia: Bitcoin Gambling Guide</a>, <a href="/bitcoin-casinos-australia-why-crypto/">Bitcoin Casinos Australia – Why Aussies Love Crypto: The Appeal and the Catch</a>, <a href="/crypto-casinos-australia-2026-how-to-evaluate/">Best Crypto Casinos Australia 2026: Bitcoin &amp; More, and How to Evaluate One</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
