<?php
/**
 * Article: Understanding RTP and Volatility in Online Slots
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. Your original text (opening, what RTP means, the three misunderstandings, volatility and its table, hit frequency,
 *    where to find the RTP, fairness, table games, using this information sensibly and the closing paragraph) is kept word for
 *    word. ADDED: the "In short" box, "RTP in dollars" and "your balance and your stake" (hypothetical figures),
 *    hit-frequency example, "reading the information screen", "myths and facts", a glossary, five FAQs and the next-step list.
 *    Edit or delete any added section freely.
 * 2. This page's angle is "the plain-language primer". The Australian rules and venue minimums are on
 *    /understanding-rtp-and-volatility-in-online-slots-australia/ and the "best" slots on /high-rtp-slots-australia/. These pages answer
 *    the same searches, so keep them distinct or merge some with 301 redirects.
 * 3. The roulette house edges in your original (about 2.7% and 5.26%) are standard figures. All other figures are labelled
 *    hypothetical.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. On phones the rail
 *   banner is hidden and the same banner is shown inside the article instead (after the "your balance and your stake" section).
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('understanding-rtp-and-volatility-in-online-slots');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#rtp">What RTP means</a></li>
            <li><a href="#volatility">What volatility means</a></li>
            <li><a href="#hit-frequency">Hit frequency</a></li>
            <li><a href="#finding">Where to find a slot's RTP</a></li>
            <li><a href="#fairness">Where fairness comes from</a></li>
            <li><a href="#table-games">A note on table games</a></li>
            <li><a href="#using">Using this information sensibly</a></li>
            <li><a href="#myths">Myths and facts</a></li>
            <li><a href="#glossary">A short glossary</a></li>
            <li><a href="#faq">Quick answers</a></li>
            <li><a href="#next-step">Before your next spin</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Slots, called pokies in Australia, come with descriptions full of numbers and labels. Two of them, return to player (RTP) and volatility, are genuinely useful, provided you know what they do and do not tell you. This guide explains both in plain language.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>RTP is the theoretical share of all money wagered that is paid back over a very large number of spins.</strong> What it doesn't return is the house edge.</li>
          <li><strong>Volatility describes how wins are spread,</strong> so it changes how bumpy the ride is, not the average cost of playing.</li>
          <li><strong>Neither tells you anything about the next spin.</strong> A slot is never "due" a win.</li>
          <li><strong>Check the RTP in the game's own information panel,</strong> because the same game can run at more than one setting.</li>
        </ul>
      </div>

      <h2 id="rtp">What RTP means</h2>
      <figure class="shot"><?= gw_img('articles/rp-rtp', 'Casino coin beside the title What RTP Means', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Return to player is the theoretical percentage of all money wagered on a game that is paid back to players over a very large number of spins. A slot with an RTP of 96% is designed to return 96 units for every 100 wagered in the long run, and to keep 4. That 4% is the house edge.</p>
      <p>The key phrase is long run. The figure is calculated across enormous numbers of spins, far more than any individual will play. In a single session you can win much more or lose much more than the RTP suggests, and RTP says nothing about whether the next spin will win.</p>
      <h3>RTP in dollars</h3>
      <figure class="shot"><?= gw_img('articles/rp-dollars', 'Payment list with a clock beside the title RTP in Dollars', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Putting dollars on it makes the 4% concrete. If A$100 is bet at an RTP of 96%, the game is designed to return about A$96 on average and keep A$4. Now suppose a player makes 300 spins at A$1 each, which is a hypothetical pace chosen to make the sums easy. That is A$300 bet, so the average cost at 96% is A$12 (A$300 × 4%). At an RTP of 92% the same play costs about A$24 (A$300 × 8%), twice as much.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">At a 96% RTP</p>
          <p class="ex-sum">A$300 bet × 4%</p>
          <p class="ex-big">A$12</p><p class="ex-lbl">average cost of 300 spins at A$1</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">At a 92% RTP</p>
          <p class="ex-sum">A$300 bet × 8%</p>
          <p class="ex-big">A$24</p><p class="ex-lbl">average cost of the same play</p>
        </div>
      </div>
      <p>These are averages over a very large number of spins, not a forecast for any one session. They show why a few percentage points of RTP matter more than they look.</p>
      <h3>Common misunderstandings</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>A slot is not "due" a win.</strong> Each spin is independent. A game that has not paid out recently is no more likely to pay out next.</li>
          <li><strong>A higher RTP does not guarantee a profit.</strong> It lowers the average cost of playing, nothing more.</li>
          <li><strong>RTP is not a promise about your session.</strong> It describes the game's design across all players.</li>
        </ul>
      </div>

      <h2 id="volatility">What volatility means</h2>
      <figure class="shot"><?= gw_img('articles/rp-vol', 'Chart with a warning mark beside the title Volatility Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Volatility, sometimes called variance, describes how a slot's wins are distributed. It tells you what the ride is likely to feel like.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>How volatility shapes the experience</caption>
      <thead><tr><th scope="col">Volatility</th><th scope="col">Typical pattern</th><th scope="col">What it means for your balance</th></tr></thead>
      <tbody>
      <tr><th scope="row">Low</th><td>Frequent, smaller wins</td><td>Balance moves gradually, sessions can last longer</td></tr>
      <tr><th scope="row">Medium</th><td>A mix of small and mid-sized wins</td><td>Balance swings are moderate</td></tr>
      <tr><th scope="row">High</th><td>Long stretches without wins, occasional large ones</td><td>Balance can fall quickly, with a small chance of a large win</td></tr>
      </tbody>
      </table>
      </div>
      <p>Two slots can share the same RTP and still feel very different, because the RTP is built from a different mix of small and large wins. Volatility does not change the average cost of playing. It changes how bumpy the journey is.</p>
      <h3>Your balance and your stake</h3>
      <p>Volatility matters most when you set it against your stake. A A$100 balance at A$1 a spin is 100 spins if nothing ever paid, and at A$0.50 a spin it is 200. A high-volatility game can go a long time without a win, so a smaller stake gives a bumpy game more room to run. That is the arithmetic behind the point that a small balance on a high-volatility game can disappear in minutes.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">A$100 balance at A$1 a spin</p>
          <p class="ex-sum">A$100 ÷ A$1</p>
          <p class="ex-big">100 spins</p><p class="ex-lbl">if no spin paid anything</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">A$100 balance at A$0.50 a spin</p>
          <p class="ex-sum">A$100 ÷ A$0.50</p>
          <p class="ex-big">200 spins</p><p class="ex-lbl">if no spin paid anything</p>
        </div>
      </div>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="hit-frequency">Hit frequency</h2>
      <figure class="shot"><?= gw_img('articles/rp-hit', 'Dice and chips beside the title Hit Frequency', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Hit frequency is how often a spin returns any win at all. A game with a high hit frequency can still lose money, because many of those wins are smaller than your stake. This is sometimes used in marketing to make a slot seem generous.</p>
      <p>For example, a A$0.20 win on a A$1 spin counts as a hit, but you are still A$0.80 down on that spin. Hit frequency tells you how often the screen lights up, not how much comes back.</p>

      <h2 id="finding">Where to find a slot's RTP</h2>
      <figure class="shot"><?= gw_img('articles/rp-find', 'Document with a magnifying glass beside the title Finding a Slot RTP', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Look for the information or help panel inside the game, which often states the RTP. Some game providers publish figures on their own websites. Be aware that some providers offer the same game with more than one RTP setting, and the operator can choose which version to run. This means the RTP of a game at one casino may differ from the same-named game at another. If you cannot find the RTP, ask support, and treat an unwillingness to answer as information.</p>
      <h3>Reading the information screen</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Open the game's information or help panel before you bet.</li>
          <li>Find the RTP figure, and note whether the panel mentions more than one setting.</li>
          <li>Look for a volatility or variance label, if the game shows one.</li>
          <li>Check the minimum and maximum bet, so the stake fits your balance.</li>
          <li>Note the figure you found, because it can differ from a review or from the same game elsewhere.</li>
        </ol>
      </div>

      <h2 id="fairness">Where fairness comes from</h2>
      <p>Online slots use random number generators to determine outcomes. In regulated markets, game providers have their RNGs and RTP calculations tested by independent laboratories, and operators are expected to run certified versions. Independent testing is one of the things we look for in a casino, and it is part of what our <a href="/safe-and-trusted-online-casinos/">guide to safe and trusted casinos</a> describes.</p>

      <h2 id="table-games">A note on table games</h2>
      <figure class="shot"><?= gw_img('articles/rp-table', 'Casino table beside the title Table Games Too', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Table games have a house edge too, and it depends on the rules. For example, European roulette has a single zero, giving a house edge of about 2.7%, while American roulette adds a double zero, raising it to about 5.26%. In blackjack the edge depends on the rules and on how well you play. Checking the rules before you sit down is as important as checking a slot's RTP.</p>

      <h2 id="using">Using this information sensibly</h2>
      <div class="rg-card">
        <ul class="checks">
          <li>Choose a volatility that fits your budget. A small balance on a high-volatility game can disappear in minutes.</li>
          <li>Prefer games that show their RTP, and prefer higher figures when all else is equal.</li>
          <li>Remember that wagering requirements multiply the cost of a house edge. Our guide to <a href="/how-casino-welcome-bonuses-work/">welcome bonuses</a> shows the arithmetic.</li>
          <li>Decide a budget and time limit beforehand. See <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools</a> for how to enforce them.</li>
        </ul>
      </div>
      <p>Slots are entertainment with a built-in cost. Understanding RTP and volatility will not turn them into an income, but it helps you pick games that match the way you want to play and the amount you are comfortable spending.</p>

      <h2 id="myths">Myths and facts</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Common beliefs and what RTP and volatility say</caption>
      <thead><tr><th scope="col">The belief</th><th scope="col">What is actually true</th></tr></thead>
      <tbody>
      <tr><th scope="row">“It hasn't paid for a while, so it's due.”</th><td>Every spin is independent, so a long dry spell makes no difference to the next one.</td></tr>
      <tr><th scope="row">“A high RTP means I'll win.”</th><td>A higher RTP lowers what play costs on average. It says nothing about how your own session will go.</td></tr>
      <tr><th scope="row">“A high-volatility game pays more.”</th><td>Volatility shapes the ride, with long quiet stretches and occasional big wins. It leaves the average cost where it was.</td></tr>
      <tr><th scope="row">“A high hit frequency means a generous game.”</th><td>A win can be smaller than your stake, so even a frequent winner can leave you out of pocket.</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="glossary">A short glossary</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Slot terms in plain language</caption>
      <thead><tr><th scope="col">Term</th><th scope="col">Plain meaning</th><th scope="col">Changes the average cost?</th></tr></thead>
      <tbody>
      <tr><th scope="row">RTP</th><td>The theoretical share of all money wagered that is paid back over a very large number of spins</td><td>Yes, a higher RTP lowers it</td></tr>
      <tr><th scope="row">House edge</th><td>What the game keeps: 100% minus the RTP</td><td>It is the average cost</td></tr>
      <tr><th scope="row">Volatility</th><td>How a slot's wins are distributed</td><td>No, it changes the bumpiness</td></tr>
      <tr><th scope="row">Hit frequency</th><td>How often a spin returns any win at all</td><td>No</td></tr>
      <tr><th scope="row">Wagering requirement</th><td>The amount you must bet before bonus-related funds can be withdrawn</td><td>It multiplies how much betting the house edge applies to</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="faq">Quick answers</h2>
      <div class="faq">
        <details>
          <summary>What is a good RTP for a slot?</summary>
          <p>There is no single good number. Higher is better for the average cost when all else is equal, so compare like with like and read the figure in the game's own information panel. The same game can run at more than one RTP setting.</p>
        </details>
        <details>
          <summary>Does volatility change the RTP?</summary>
          <p>No. Two slots can share the same RTP and feel very different, because the RTP is built from a different mix of small and large wins.</p>
        </details>
        <details>
          <summary>Does RTP apply to a single session?</summary>
          <p>No. It is calculated across enormous numbers of spins, far more than any individual will play, so in one session you can win much more or lose much more than the RTP suggests.</p>
        </details>
        <details>
          <summary>Can the same slot have a different RTP at another casino?</summary>
          <p>Yes. Some providers offer the same game with more than one RTP setting, and the operator can choose which version to run. If you cannot find the RTP, ask support.</p>
        </details>
        <details>
          <summary>Are online pokies legal in Australia?</summary>
          <p>Online casino games, including online pokies, can't lawfully be offered to people in Australia under the Interactive Gambling Act 2001. Pokies in licensed venues are regulated by each state or territory. This is general information, not legal advice.</p>
        </details>
      </div>
      <p class="see-also">For the Australian position and venue rules, see <a href="/understanding-rtp-and-volatility-in-online-slots-australia/">RTP and volatility in online slots for Australians</a> and <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>

      <h2 id="next-step">Your next step: before your next spin</h2>
      <figure class="shot"><?= gw_img('articles/rp-next', 'Limit sliders beside the title Before Your Next Spin', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Open the information panel and note the RTP and any volatility label.</li>
          <li>Check whether the game shows more than one RTP setting.</li>
          <li>Pick a stake that gives the game room to run on your balance.</li>
          <li>Set a deposit limit and a time limit before you start, and stick to them.</li>
        </ol>
      </div>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over, and no slot, RTP figure or system guarantees a win. Never gamble with money you need for bills. If gambling is causing you stress, free and confidential support is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <?php gw_topic_links($a['slug']); ?>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
