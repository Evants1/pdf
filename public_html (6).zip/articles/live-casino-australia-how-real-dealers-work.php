<?php
/**
 * Article: Live Casino Australia – How Real Dealers Actually Work
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. Your original text (opening, note, the four roles, the five-step round, what protects the game, studios and schedules,
 *    what the studio cannot tell you, delay, privacy, both FAQs and the related reading) is kept word for word. ADDED:
 *    the "In short" box, "what each role means for you", "what you can check at each stage", "if the stream freezes",
 *    privacy tips, four more FAQs and the next-step checklist. Edit or delete any added section freely.
 * 2. This page's angle is "the dealer's side of the table: who does what and what you can see". Five live-dealer pages
 *    answer closely related searches (/live-dealer-casino-games-how-they-work/, /live-dealer-casino-games-explained/,
 *    /live-dealer-casino-australia/, /live-casinos-australia-what-to-check/ and this one). Keep them distinct or merge some
 *    with 301 redirects.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. On phones the rail
 *   banner is hidden and the same banner is shown inside the article instead (after the "how a round runs" section).
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('live-casino-australia-how-real-dealers-work');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#roles">The people behind a table</a></li>
            <li><a href="#round">How a round runs</a></li>
            <li><a href="#protect">What protects the game</a></li>
            <li><a href="#studio">Studios and schedules</a></li>
            <li><a href="#not">What the studio cannot tell you</a></li>
            <li><a href="#latency">Delay and why your screen lags</a></li>
            <li><a href="#privacy">Privacy during live play</a></li>
            <li><a href="#faq">Quick answers</a></li>
            <li><a href="#next-step">Before you sit down</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Are live dealers real? Yes, they are real people, working in a purpose-built live casino studio and streamed to your screen. This guide looks at how live dealers work in practice: the roles in a studio, how a round is run, and what protects the game. For the technology that carries the stream, see <a href="/live-dealer-casino-games-how-they-work/">live dealer casino games: how they work</a>, and for the rules and odds, <a href="/live-dealer-casino-games-explained/">live dealer casino games explained</a>.</p>
      <aside class="note">
      <p><strong>Australian readers.</strong> Online casino games cannot lawfully be offered to people in Australia under the Interactive Gambling Act 2001, and an offshore casino sits outside Australian dispute schemes. Live dealer games are not licensed for Australian customers. See our guide to <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>
      </aside>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Live dealers are real people</strong> working in a purpose-built studio, supported by a floor manager, technical staff and chat moderators.</li>
          <li><strong>A round follows a fixed sequence:</strong> betting window, betting closes, the game is played, the result is read, payouts are settled.</li>
          <li><strong>A professional studio says nothing about the casino.</strong> Whether it pays winnings, treats players fairly or is lawful for Australians has to be checked separately.</li>
          <li><strong>Treat a frozen stream as a reason to stop,</strong> not to bet faster.</li>
        </ul>
      </div>

      <h2 id="roles">The people behind a table</h2>
      <figure class="shot"><?= gw_img('articles/ld-roles', 'Casino table with cards beside the title The People Behind a Table', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>The dealer or presenter</strong> runs the game, handles the cards or spins the wheel and talks to players.</li>
          <li><strong>A floor or pit manager</strong> supervises procedures and resolves disputes.</li>
          <li><strong>Technical staff</strong> run cameras, streaming and the game software.</li>
          <li><strong>Chat moderators</strong> may watch player messages.</li>
        </ul>
      </div>
      <h3>What each role means for you</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Role</th><th scope="col">Where you notice it</th><th scope="col">What it means for you</th></tr></thead>
      <tbody>
      <tr><th scope="row">Dealer or presenter</th><td>On screen, running the table and speaking to players</td><td>The person you see makes the game feel live, but the result still follows the rules of the table</td></tr>
      <tr><th scope="row">Floor or pit manager</th><td>Rarely, usually only when something goes wrong</td><td>A person with authority can step in when a card is misdealt or a result is disputed</td></tr>
      <tr><th scope="row">Technical staff</th><td>Never, unless the stream fails</td><td>They keep the video, the game software and the link between them running</td></tr>
      <tr><th scope="row">Chat moderators</th><td>In the chat window</td><td>What you type can be seen and moderated, so write nothing you wouldn't want read</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="round">How a round runs</h2>
      <figure class="shot"><?= gw_img('articles/ld-round', 'Payment list with a clock beside the title A Round Step by Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Betting window.</strong> A timer opens, and you place bets through the interface.</li>
          <li><strong>Betting closes.</strong> The software locks in bets.</li>
          <li><strong>The game is played.</strong> Cards are dealt or the wheel is spun in front of cameras.</li>
          <li><strong>The result is read.</strong> Optical recognition or sensors capture the outcome.</li>
          <li><strong>Payouts are settled</strong> automatically against the recorded result.</li>
        </ol>
      </div>
      <h3>What you can check at each stage</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Stage</th><th scope="col">What you can see</th><th scope="col">What to look for</th></tr></thead>
      <tbody>
      <tr><th scope="row">Betting window</th><td>A countdown timer in the interface</td><td>That the timer is visible and the table tells you when bets close</td></tr>
      <tr><th scope="row">Betting closes</th><td>The interface locking your chips</td><td>That you can't add or change a bet after the close</td></tr>
      <tr><th scope="row">The game is played</th><td>The dealer and the cards or wheel, on camera</td><td>That the action is shown clearly and in one continuous view</td></tr>
      <tr><th scope="row">The result is read</th><td>The result on screen and in the table history</td><td>That the result on screen matches what the cameras showed</td></tr>
      <tr><th scope="row">Payouts are settled</th><td>Your balance updating</td><td>That the payout matches the rules panel for the bet you placed</td></tr>
      </tbody>
      </table>
      </div>
      <p>These are things you can watch for yourself. They don't prove a site is trustworthy, but a table where the timer, the camera view or the history is unclear is worth leaving.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="protect">What protects the game</h2>
      <figure class="shot"><?= gw_img('articles/ld-protect', 'Shield with a tick beside the title Protecting the Game', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Physical equipment</strong> such as shuffling machines and wheels with sensors, which is reported in studio procedures.</li>
          <li><strong>Procedures and supervision</strong> by floor staff.</li>
          <li><strong>Independent testing</strong> of equipment and random elements, which you can verify on the lab's own website. See our <a href="/safe-and-trusted-online-casinos/">safety checks</a>.</li>
        </ul>
      </div>

      <h2 id="studio">Studios and schedules</h2>
      <figure class="shot"><?= gw_img('articles/ld-studio', 'Document with a magnifying glass beside the title Studios and Schedules', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Studios are often run by game providers, who supply tables to many casinos. A provider's studio can serve the same table to several brands, which is why the same dealers can appear in different lobbies. Dealers work in shifts, and table availability follows the schedule.</p>
      <p>In practice, that means the dealer at your table can change during the day, and a favourite table may not be open at every hour. It also means a table's reputation belongs to the studio, while the casino's reputation is a separate question.</p>

      <h2 id="not">What the studio cannot tell you</h2>
      <p>A professional studio says nothing about whether the casino pays winnings, treats players fairly or is lawful for Australians. Check the operator separately, as in <a href="/how-to-choose-a-real-money-online-casino-australia/">how to choose a real-money online casino in Australia</a>.</p>

      <h2 id="latency">Delay and why your screen lags</h2>
      <figure class="shot"><?= gw_img('articles/ld-lag', 'Smartphone beside the title Why Your Screen Lags', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Streams reach you a moment after the dealer acts, and the delay varies by connection. The betting window is set with that in mind, but a weak connection can make you miss a window. Test a table on your own connection before staking real money, and treat sudden freezes as a reason to stop, not to bet faster.</p>
      <h3>If the stream freezes</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Don't bet faster to catch up, and don't place a bet you can't see being resolved.</li>
          <li>Check your connection before you go back to the table.</li>
          <li>If your connection drops mid-round, the round usually carries on without you, so read the table's disconnection rule in its rules panel before you bet.</li>
          <li>Treat repeated freezes as a reason to leave the table.</li>
        </ol>
      </div>

      <h2 id="privacy">Privacy during live play</h2>
      <figure class="shot"><?= gw_img('articles/ld-privacy', 'Dotted circles beside the title Privacy at a Live Table', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Your username, chat and bets are visible to the operator and may be seen by other players, so use a name that does not identify you. Check the privacy policy for how recordings of tables are kept, since studios record rounds for disputes.</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Pick a username that doesn't include your real name or any personal detail.</li>
          <li>Keep personal information out of the chat, which can be seen by other players and moderators.</li>
          <li>Read how long recordings are kept and who can request them.</li>
        </ul>
      </div>

      <h2 id="faq">Quick answers</h2>
      <div class="faq">
        <details>
          <summary>Can the dealer see me?</summary>
          <p>Usually not. Players are shown by chat name or avatar, and the dealer sees the interface, not your camera.</p>
        </details>
        <details>
          <summary>Are the results pre-recorded?</summary>
          <p>Properly run live games are streamed in real time. Check the studio's name and testing details.</p>
        </details>
        <details>
          <summary>Are live dealers real people?</summary>
          <p>Yes. They are real people working in a purpose-built studio and streamed to your screen, supported by a floor or pit manager, technical staff and sometimes chat moderators.</p>
        </details>
        <details>
          <summary>Does a real dealer make the game fairer?</summary>
          <p>It makes the game easier to watch, but fairness depends on the equipment, the procedures and the operator, and a live table still has a house edge built into its rules. A professional studio also says nothing about whether the casino will pay winnings.</p>
        </details>
        <details>
          <summary>Why does the same dealer appear at different casinos?</summary>
          <p>Studios are often run by game providers, who supply tables to many casinos. A provider's studio can serve the same table to several brands, so the same dealer can appear in different lobbies.</p>
        </details>
        <details>
          <summary>Are live dealer games legal in Australia?</summary>
          <p>Online casino games, live dealer versions included, can't lawfully be offered to people in Australia under the Interactive Gambling Act 2001. The Act's offences are aimed at providers rather than players, but that is not approval, and ACMA has the final word.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: before you sit down</h2>
      <figure class="shot"><?= gw_img('articles/ld-next', 'Checklist card beside the title Before You Sit Down', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Check the operator against ACMA's register and blocked list before you rely on the site.</li>
          <li>Check the operator separately from the studio: who runs it, and how it handles withdrawals and complaints.</li>
          <li>Open the table's rules panel and read the payouts and the disconnection rule.</li>
          <li>Watch a few rounds without betting, and check the timer, the camera view and the result history.</li>
          <li>Set a deposit limit and a time limit before you place a bet.</li>
        </ol>
      </div>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over, and no live table, dealer or system guarantees a win. Never gamble with money you need for bills. If gambling is causing you stress, free and confidential support is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/live-dealer-casino-games-how-they-work/">Live Dealer Casino Games: How They Work</a>, <a href="/live-dealer-casino-games-explained/">Live Dealer Casino Games Explained</a>, <a href="/live-casinos-australia-what-to-check/">Top 10 Live Casinos Australia for Real Dealers: 10 Things to Check</a>, <a href="/live-dealer-casino-australia/">Live Dealer Casino Australia: How to Judge Sites for Real Games</a>.</p>

      <?php gw_topic_links($a['slug']); ?>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
