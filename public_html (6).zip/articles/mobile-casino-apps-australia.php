<?php
/**
 * Article: Best Mobile Casino Apps Australia 2026: How to Judge Safety and Quality
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the 10-point checklist).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('mobile-casino-apps-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#law">What the law says in 2026</a></li>
            <li><a href="#app-types">App, web app or mobile site?</a></li>
            <li><a href="#checklist">A 10-point checklist</a></li>
            <li><a href="#pokies">Mobile pokies: what to check</a></li>
            <li><a href="#payments">Paying on your phone</a></li>
            <li><a href="#limits">Limits and support</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">The five-minute check</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Search for “mobile casino Australia” and you'll get pages of top-10 lists promising big bonuses and fast payouts. Those lists rarely mention that no real-money online casino is licensed in Australia. Under the Interactive Gambling Act 2001, providers can't offer online pokies, roulette, blackjack or similar casino games to people here. There is no Australian-licensed casino app to recommend, in 2026 or any other year.</p>
      <p>What gets marketed as casino apps in Australia is almost always an offshore website running in your phone's browser, sometimes with a home-screen icon added. These sites operate outside Australian law. If one refuses to pay you, a local regulator can do very little.</p>
      <p>So this guide doesn't rank operators or quote bonus figures. It explains what the law says, what a “casino app” really is, how to judge the risk of any site yourself, and which legal alternatives exist. It's written for adults aged 18 and over.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>No real-money online casino is licensed in Australia,</strong> so there is no licensed casino app to recommend.</li>
          <li><strong>A “casino app” is usually an offshore website</strong> in your browser, a home-screen shortcut or a sideloaded file.</li>
          <li><strong>Never install an APK</strong> or an unfamiliar profile or developer on your phone.</li>
          <li><strong>The lawful options</strong> are licensed wagering and lottery apps and land-based venues, used with a deposit limit.</li>
        </ul>
      </div>

      <h2 id="law">Mobile casino Australia: what the law actually says in 2026</h2>
      <figure class="shot"><?= gw_img('articles/mca-law', 'Shield with a tick beside the title Mobile Play and the Law in 2026', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act bans</h3>
      <p>The Interactive Gambling Act 2001 is federal law, enforced by the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a>. It makes it illegal for a provider to offer certain gambling services to people in Australia, including online casino-style games played for money, such as pokies and table games. It applies wherever the provider is based, so an overseas licence doesn't make the service lawful here.</p>
      <p>The Act targets providers, not individual players. That isn't legal advice, and it doesn't mean playing is safe. On an illegal service you have none of the protections that come with a licensed one.</p>
      <p>Gambling rules change from time to time, including around advertising, inducements and enforcement. For the current position, go to ACMA's website. It has the final word.</p>
      <h3>What is licensed: wagering and lottery apps</h3>
      <p>The legal ways to gamble, on your phone or off it, are narrower than the search results suggest:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Licensed wagering apps for sports and racing bets, run by operators licensed in an Australian state or territory.</li>
          <li>Lottery apps from licensed lottery operators.</li>
          <li>Land-based venues: casinos, and pokies in pubs and clubs where your state or territory allows them.</li>
        </ul>
      </div>
      <p>None of these offers real-money pokies or table games online. An app that does is not Australian-licensed, whatever its footer says.</p>
      <h3>How to check a site against ACMA's lists</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Go to <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> and open the page on checking whether a gambling operator is legal.</li>
          <li>Search the register of licensed interactive wagering services. Only wagering providers appear there, because no online casino can be on it.</li>
          <li>Look through the list of blocked gambling websites. A site on it has been found to be operating illegally, and ACMA has asked internet providers to block it.</li>
          <li>Don't read absence from the blocked list as approval. New sites and copycat domains appear all the time.</li>
        </ol>
      </div>
      <p>If a site won't load because it has been blocked, treat that as your answer. Don't go looking for a way around it.</p>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="app-types">Casino apps Australia: native app, web app or mobile site?</h2>
      <figure class="shot"><?= gw_img('articles/mca-app-types', 'Smartphone beside the title App Web App or Mobile Site', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>“App” gets used for three different things, and the difference affects both your security and who has vetted what you're using.</p>
      <div class="mini3">
        <div><h3>Store app</h3><p>Reviewed by Apple or Google. Genuine real-money casino apps seldom appear in the Australian stores.</p></div>
        <div><h3>Home-screen web app</h3><p>A progressive web app (PWA) is the mobile website saved to your home screen, with no store review.</p></div>
        <div><h3>Sideloaded APK</h3><p>A file installed from outside the store. It skips the checks Google Play applies.</p></div>
      </div>
      <h3>Why real-money casino apps are rarely in the app stores</h3>
      <p>Apple and Google generally expect real-money gambling apps to be lawfully licensed in each country where they're listed. Online casinos can't be licensed in Australia, so genuine real-money casino apps seldom appear in the Australian stores. What you will find are licensed betting and lottery apps, plus free-to-play social casino games.</p>
      <p>Store policies change, so check the listing itself: the developer name, the age rating and whether the description mentions real-money play. Be wary of anything presented as a simple game that then redirects you to a casino website.</p>
      <h3>Home-screen web apps (PWAs) explained</h3>
      <p>Most “download our app” buttons lead to a progressive web app (PWA), which is the mobile website saved to your home screen. On an iPhone you do this through Safari's Share menu and “Add to Home Screen”. In Chrome on Android it's “Add to Home screen” or “Install app” in the menu.</p>
      <p>The icon opens the site full-screen, so it feels like an app, but neither Apple nor Google has reviewed it. It's the same website, with the same operator, terms and risks.</p>
      <h3>The risk of sideloaded APK files</h3>
      <p>Some sites ask Android users to download an APK file and switch on installation from unknown sources. That skips the checks Google Play applies. You can't easily tell what the file does, which permissions it will use or whether it has been tampered with. And it would sit on the same phone as your banking apps.</p>
      <p>The safe rule is not to install it. On an iPhone, treat requests to install a configuration profile or “trust” an unfamiliar developer the same way.</p>
      <p class="see-also">Compare formats in <a href="/mobile-casino-gaming-apps-vs-browser-2026/">mobile casino gaming apps vs browser in 2026</a>.</p>

      <h2 id="checklist">How to judge the best casino app: a 10-point checklist</h2>
      <figure class="shot"><?= gw_img('articles/mca-checklist', 'Checklist card beside the title A 10-Point Casino App Checklist', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>There is no “best casino app” in the sense of a safe, locally licensed pick, so this checklist has no scores or winners. It shows how much risk a given site carries. Passing every check doesn't make a service lawful in Australia. Failing several is a clear reason to walk away.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Use this 10-point checklist to assess any casino app before you sign up.</caption>
      <thead><tr><th scope="col">Check</th><th scope="col">Why it matters</th><th scope="col">Where to find it</th></tr></thead>
      <tbody>
      <tr><th scope="row">1. ACMA status</th><td>A blocked site has already been found to be operating illegally</td><td>ACMA's register and blocked list</td></tr>
      <tr><th scope="row">2. Named operating company</th><td>You need to know who actually holds your money</td><td>Site footer; opening clauses of the terms</td></tr>
      <tr><th scope="row">3. Licence you can verify</th><td>A logo proves nothing unless the regulator's own site confirms it</td><td>Click the seal, then search the regulator's public register</td></tr>
      <tr><th scope="row">4. Complaints process</th><td>Shows whether anyone independent can review a dispute</td><td>“Complaints” or “Disputes” section of the terms</td></tr>
      <tr><th scope="row">5. Bonus wagering rules</th><td>They decide when bonus funds, and sometimes your deposit, can be withdrawn</td><td>Bonus terms, not the banner</td></tr>
      <tr><th scope="row">6. Withdrawal caps</th><td>Daily, weekly or monthly limits can stretch a payout out</td><td>Withdrawals section of the terms</td></tr>
      <tr><th scope="row">7. ID verification</th><td>Tells you which documents are required and when</td><td>Terms; account verification page</td></tr>
      <tr><th scope="row">8. Fees and currency</th><td>Conversion, withdrawal and dormant-account fees reduce your balance</td><td>Cashier; fees section of the terms</td></tr>
      <tr><th scope="row">9. Limit tools</th><td>Deposit limits, time-outs and self-exclusion should be easy to set</td><td>Account settings; responsible gambling page</td></tr>
      <tr><th scope="row">10. Works on your phone</th><td>You need to reach the cashier, terms and support on a small screen</td><td>Test in your browser before depositing</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Licence and operator checks</h3>
      <p>Checks 1 to 4 are about who you're dealing with. Offshore licences, such as those issued in Curaçao or Anjouan, are a common sight in footers. They may show the operator is registered somewhere, but they don't protect Australians and don't change the service's status under Australian law. If you can't match the company name to a regulator's own register, treat the licence claim as unverified.</p>
      <h3>Terms that matter: wagering, withdrawal caps, ID checks</h3>
      <p>Checks 5 to 8 are where most disputes start. Read the bonus terms for the wagering requirement, the maximum bet while a bonus is active, excluded games and any cap on winnings. Figures quoted on review sites go out of date quickly, so rely on the operator's own terms and screenshot them on the day you sign up.</p>
      <h3>Usability on a small screen</h3>
      <p>For checks 9 and 10, open the site in portrait mode and try to find the terms, cashier, live chat and limit settings without pinching and zooming. If support is unreachable or the limits page is buried before you've deposited, it won't get easier afterwards.</p>
      <p class="see-also">Go deeper in our <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos guide</a> and <a href="/kyc-verification-at-online-casinos-australia/">KYC verification at online casinos in Australia</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="pokies">Mobile pokies Australia: what to check before you spin</h2>
      <figure class="shot"><?= gw_img('articles/mca-pokies', 'Casino coin beside the title Mobile Pokies Check First', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Finding a game's RTP and volatility in its info panel</h3>
      <p>Return to player (RTP) is the theoretical share of all money wagered that a game pays back over a very large number of spins. You don't need a review site to tell you what it is. Open the game, tap the menu or “i” icon and look in the paytable or game rules, where it's shown as a percentage.</p>
      <p>Two cautions. RTP describes the long run, not your session, and it is always set so the house keeps an edge. Some games also come in more than one RTP version, so the figure inside the game you've opened is the one that counts. Volatility, where it's shown, tells you whether wins tend to be small and frequent or rare and larger.</p>
      <h3>Demo mode, data use and battery drain</h3>
      <p>Where a demo mode is offered, use it to learn the features and see how quickly a balance moves at different stakes. Demo results say nothing about what will happen with real money.</p>
      <p>Modern pokies are graphics-heavy. Expect them to drain your battery and warm your phone, and use Wi-Fi if your mobile data is capped. If your connection drops mid-spin, the outcome is normally settled on the game server, so check the game history when you log back in.</p>
      <h3>Social casino apps versus real-money play</h3>
      <p>The pokies apps in the app stores are mostly social casinos. You play with virtual coins and can't cash anything out, which is why they generally aren't treated as gambling under the Act. They can still cost real money through in-app coin packs, and the spinning feels much the same. If you use one, require a password for every purchase in your phone's settings.</p>
      <p class="see-also">For the maths behind these numbers, see <a href="/understanding-rtp-and-volatility-in-online-slots-australia/">understanding RTP and volatility</a>.</p>

      <h2 id="payments">Paying and withdrawing on your phone: PayID, cards, e-wallets and crypto</h2>
      <figure class="shot"><?= gw_img('articles/mca-payments', 'Wallet with payment cards beside the title Phone Payments Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Each method has its own catch with offshore sites, and availability changes often.</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Payment method</p>
          <h3>PayID and bank transfer</h3>
          <p>Familiar, but the payment often goes to a third-party processor, not the casino. Check the payee name your banking app displays before you confirm, because a transfer you authorised is hard to recall.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment method</p>
          <h3>Debit and credit cards</h3>
          <p>May be declined, since many banks restrict gambling transactions. Expect possible international fees and an unfamiliar merchant name on your statement.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment method</p>
          <h3>E-wallets and vouchers</h3>
          <p>Put a layer between your bank and the site, with their own fees, limits and identity checks.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment method</p>
          <h3>Crypto</h3>
          <p>Transactions can't be reversed, prices move, and there's no bank to complain to.</p>
        </article>
      </div>
      <h3>What to confirm in the cashier before depositing</h3>
      <p>Check whether the account is held in AUD or converted, the minimum and maximum deposits and withdrawals, any fees, and whether the method you deposit with can also be used to withdraw. If the cashier and the terms disagree, ask support in writing and keep the reply.</p>
      <h3>Why withdrawals stall: verification and bonus terms</h3>
      <p>The two usual causes are identity checks and bonus conditions. Many sites only ask for ID, proof of address and proof of payment method once you request a withdrawal. Others void winnings over an unmet wagering requirement or a breached maximum bet. Finishing verification before you deposit, and declining bonuses you haven't read, removes most of the surprises.</p>
      <h3>Chargeback and dispute limits with offshore sites</h3>
      <p>Your bank may look at a transaction you didn't authorise. A deposit you made yourself and then played is a much weaker case, and the outcome is up to your bank and the card scheme. PayID transfers and crypto are effectively final. You can report an illegal service to ACMA, but it can't recover your money. For questions about tax and gambling, go to the ATO.</p>
      <p class="see-also">More in <a href="/online-casino-payment-methods/">payment methods compared</a> and <a href="/how-casino-withdrawals-work-speed-and-limits/">how casino withdrawals work</a>.</p>

      <h2 id="limits">Set limits before you play: tools and support for Australians</h2>
      <figure class="shot"><?= gw_img('articles/mca-limits', 'Limit sliders beside the title Set Limits Before You Play', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Gambling is for adults aged 18 and over. Every casino game is built with a house edge, so there are no guaranteed wins and no strategy that beats the maths over time. Only play with money you can afford to lose.</p>
      <h3>Deposit, loss and session limits</h3>
      <p>Decide your limits before you open the site, in dollars and minutes: say, $50 for the week and 30 minutes a session. Licensed Australian wagering apps offer deposit limits as standard. On offshore sites the tools vary and may be easy to undo, so back them up with your phone's own controls, such as app and website time limits in Screen Time on iPhone or Digital Wellbeing on Android.</p>
      <h3>BetStop and bank gambling blocks</h3>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> is the free National Self-Exclusion Register. Signing up excludes you from all licensed online and phone wagering providers in Australia. It does not cover offshore casino sites, which aren't part of the scheme. For those, a gambling block on your debit or credit card is the more useful tool. Several major banks let you switch one on in their app, so check yours or ask your bank.</p>
      <h3>Free help: Gambling Help Online</h3>
      <div class="rg-card">
      <p>If gambling is causing stress, debt or arguments, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support around the clock by online chat, or by phone on <a href="tel:1800858858">1800 858 858</a>. It's also there for family and friends who are worried about someone else.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Mobile casino FAQ</h2>
      <div class="faq">
        <details>
          <summary>Are casino apps legal in Australia?</summary>
          <p>No real-money online casino app is licensed in Australia. The Interactive Gambling Act 2001 makes it illegal for providers to offer online casino games to people here, whatever licence they hold overseas. Licensed sports and racing betting apps and lottery apps are legal, and free-to-play social casino games that pay no cash are generally permitted. For the current rules, check ACMA.</p>
        </details>
        <details>
          <summary>Can I download a real-money casino app from the App Store or Google Play in Australia?</summary>
          <p>Generally not. Both stores expect real-money gambling apps to be licensed where they're offered, and online casinos can't be licensed here. Most offshore casino “apps” are home-screen shortcuts to a website, or APK files from outside the store. Check the listing and developer before installing anything.</p>
        </details>
        <details>
          <summary>What is the safest way to play pokies on my phone?</summary>
          <p>The lowest-risk options are a game's free demo mode or a social casino app with in-app purchases locked, since no gambling money changes hands. For real-money pokies, the lawful option is a land-based venue in your state or territory. Offshore sites can't lawfully be offered here and carry real risk. If you use one regardless, stay in your browser, never install an APK and set a firm limit.</p>
        </details>
        <details>
          <summary>Can I get my money back if an offshore casino won't pay?</summary>
          <p>Often you can't. The operator sits outside Australian law, so ACMA can't recover your funds, although it does take reports about illegal services. Your bank may consider a dispute over a card payment you didn't authorise, but deposits you made yourself, PayID transfers and crypto payments are very hard to reverse. Keep screenshots of the terms, your transactions and any chat logs.</p>
        </details>
        <details>
          <summary>Do mobile casinos accept PayID?</summary>
          <p>Many offshore sites advertise PayID, but the casino itself usually isn't the one receiving the payment. Transfers are commonly routed through third-party processors, the payee name can change between deposits, and availability comes and goes. Confirm the method, limits and fees in the cashier, and check the payee name in your banking app before sending.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: run the five-minute check</h2>
      <figure class="shot"><?= gw_img('articles/mca-next', 'Document with a magnifying glass beside the title Run the Five-Minute Check', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Before you put a dollar into any mobile casino, do three things:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Check ACMA.</strong> Search the register of licensed wagering providers and the blocked websites list at acma.gov.au. If the site is blocked, stop there.</li>
          <li><strong>Read the withdrawal terms.</strong> Find the wagering rules, withdrawal caps and ID requirements, and screenshot them.</li>
          <li><strong>Set a limit.</strong> Pick a dollar amount and a time limit, then lock them in with your bank's gambling block or your phone's screen-time tools.</li>
        </ol>
      </div>
      <p>If a site fails the first check, or you can't find the terms for the second, you have your answer. If what you want is a lawful bet from your phone, a licensed wagering or lottery app, used with a deposit limit, is the only option that comes with Australian consumer protections.</p>
      <p><strong>Related reading:</strong> <a href="/mobile-casino-gaming-apps-vs-browser/">Mobile Casino Gaming: Apps vs Browser Play</a>, <a href="/mobile-casino-gaming-apps-vs-browser-2026/">Mobile Casino Gaming Apps vs Browser 2026</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
