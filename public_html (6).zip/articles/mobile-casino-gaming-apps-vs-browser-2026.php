<?php
/**
 * Article: Mobile Casino Gaming Apps vs Browser 2026
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. This text was supplied together with the page file for the ORIGINAL article /mobile-casino-gaming-apps-vs-browser/,
 *    but its title and keywords ("casino app vs browser", "instant play casino", "download casino app", PWA) match THIS
 *    2026 page, so it was built here. The original article was left unchanged.
 * 2. KEYWORD-OVERLAP RISK: this page, /mobile-casino-gaming-apps-vs-browser/ and /mobile-casino-apps-australia/ cover the
 *    same topic. Consider giving each a distinct angle or merging some with 301 redirects.
 * 3. Re-check: ACMA blocking "since 2019", BetStop "launched in 2023", the credit card ban "in 2024" (other pages say
 *    "11 June 2024"), and the App Store / Google Play policy statements.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the three formats section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('mobile-casino-gaming-apps-vs-browser-2026');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#law">What Australian law means</a></li>
            <li><a href="#formats">Three formats explained</a></li>
            <li><a href="#compare">App vs browser, feature by feature</a></li>
            <li><a href="#risks">APKs, fake listings and permissions</a></li>
            <li><a href="#control">Limits, notifications and help</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Your five-minute check</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">Casino App vs Browser: The Short Answer for Australian Players</h2>
      <figure class="shot"><?= gw_img('articles/ab-short', 'Smartphone beside the title App or Browser The Answer', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>The one-paragraph verdict</h3>
      <p>On the casino app vs browser question, the technical answer is simpler than most comparison pages make it: the games are the same either way. A pokie or blackjack table is delivered from the game provider's servers whether you open it in an app, in Safari or Chrome, or from a home-screen shortcut. An app can feel a little smoother and logs you in faster. A browser needs no install, takes almost no storage and asks for fewer permissions. Neither changes the odds, and neither works without a live internet connection for real-money play. The format matters far less than who is running the service.</p>
      <h3>Why the answer is different in Australia</h3>
      <p>Here, that last point decides most of the question. Online casino services (pokies, roulette, blackjack and similar games played for real money) cannot lawfully be offered to people in Australia. So you won't find a locally licensed real-money casino app in the App Store or Google Play. What you will find are licensed wagering apps, lottery apps and play-money social casinos.</p>
      <p>Anything advertising real-money casino games to Australians, whether it's called instant play, a web app or an Android file to download, is an offshore service operating outside Australian law. For most readers, then, the real choice isn't mobile casino app or browser. It's between a licensed product delivered through an app store and an unlicensed one delivered some other way.</p>
      <p>The rest of this guide covers the law, the three formats and the checks worth running before you install or deposit anything. It is written for adults aged 18 and over, and nothing in it is a recommendation to gamble.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>The games are the same in an app, a browser or a home-screen shortcut.</strong> Neither format changes the odds.</li>
          <li><strong>Who runs the service matters far more than the format.</strong> No real-money online casino can lawfully be offered in Australia.</li>
          <li><strong>The real choice is licensed vs unlicensed:</strong> a licensed wagering or lottery app from a store, or an offshore service delivered another way.</li>
          <li><strong>Never install a casino APK or an unfamiliar profile,</strong> and set limits before any money goes in.</li>
        </ul>
      </div>


      <h2 id="law">What Australian Law Means for Casino Apps</h2>
      <figure class="shot"><?= gw_img('articles/ab-law', 'Shield with a tick beside the title Casino Apps and the Law in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act 2001 prohibits</h3>
      <p>The Interactive Gambling Act 2001 makes it illegal for a provider to offer online casino-style games to people in Australia, or to advertise them here. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces the Act. It investigates complaints, takes action against operators and asks internet providers to block illegal sites.</p>
      <p>The Act's offences are aimed at providers, not individual players. That is not permission to play. If you use an illegal service, you have none of the protections that apply to licensed Australian operators, and no local regulator to turn to if a withdrawal is refused or your account is closed. For the definitive position, read ACMA's guidance at acma.gov.au.</p>
      <h3>What you can legitimately find in the App Store and Google Play</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>Wagering apps from bookmakers licensed in an Australian state or territory, for sports and racing bets.</li>
          <li>Lottery apps from licensed lottery operators and resellers.</li>
          <li>Social casino apps, where pokies and table-style games are played with virtual coins. You can't cash out, so they aren't real-money gambling, but coin packs are in-app purchases that cost real dollars.</li>
        </ul>
      </div>
      <p>Apple and Google both generally require real-money gambling apps to hold the right licence for each country where they are offered. Store policies change, so check the current rules if you want the detail.</p>
      <h3>Recent reforms and ACMA enforcement</h3>
      <p>The rules have tightened over the past few years. ACMA has been asking internet providers to block illegal gambling sites since 2019. BetStop, the national self-exclusion register, launched in 2023, and licensed online wagering providers were banned from accepting credit cards in 2024.</p>
      <p>Further changes, including to gambling advertising, have been debated publicly. Don't rely on a blog post, this one included, for what is currently in force or when a change starts. ACMA and the federal communications department (<a href="https://www.infrastructure.gov.au" rel="noopener">infrastructure.gov.au</a>) are the places to confirm it.</p>
      <p>ACMA also publishes a register of licensed interactive wagering providers and a list of blocked gambling websites. Both change regularly, so check them directly and don't trust a figure quoted on another site.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="formats">Native App, Instant Play Casino or PWA: Three Formats Explained</h2>
      <figure class="shot"><?= gw_img('articles/ab-formats', 'Document with a magnifying glass beside the title Native App Instant Play or PWA', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="mini3">
        <div><h3>Native app</h3><p>Installed software, from a store or an APK file.</p></div>
        <div><h3>Instant play</h3><p>Runs entirely in the mobile browser.</p></div>
        <div><h3>PWA</h3><p>A website saved to your home screen.</p></div>
      </div>
      <h3>Native app (store download or APK file)</h3>
      <p>A native app is software built for iOS or Android and installed on the phone. The normal route is the App Store or Google Play, where the listing has passed the store's review and updates arrive through the store.</p>
      <p>The other route, on Android, is an APK file. This is an installer downloaded straight from a website and "sideloaded" after you allow installs from unknown sources. An APK skips store review entirely. When an offshore site invites you to download casino app software "direct", this is usually what it means.</p>
      <h3>Instant play in Safari or Chrome</h3>
      <p>An instant play casino runs entirely in the mobile browser. You type an address, log in and the games load as web pages. Modern games are built with standard web technology, so no plug-in is needed. Nothing is installed, the site can only use the permissions the browser grants, and closing the tab ends the session.</p>
      <h3>Progressive web app (home-screen install)</h3>
      <p>A progressive web app (PWA) is a website with a few extras. It can be added to your home screen with its own icon, open full-screen without the address bar, and store some files on the phone so menus load faster.</p>
      <p>It looks like an app, but it isn't one in the sense that matters. No app store has reviewed it, and it is still the same website underneath. If a site tells you to tap Share and then "Add to Home Screen", or Chrome offers "Install app", you are creating a browser shortcut, not downloading a vetted app.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="compare">Mobile Casino App or Browser: Feature-by-Feature Comparison</h2>
      <figure class="shot"><?= gw_img('articles/ab-compare', 'Payment list with a clock beside the title App vs Browser Features', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The table below is qualitative on purpose. Performance depends on your phone, your network and the site itself, so a precise figure that wasn't measured on your device tells you very little.</p>
      <p>How casino apps and browser play compare across the features that matter most on mobile.</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Feature</th><th scope="col">Native app</th><th scope="col">Browser (instant play)</th><th scope="col">PWA</th></tr></thead>
      <tbody>
      <tr><th scope="row">How you get it</th><td>App store, or an APK file on Android</td><td>Type the address</td><td>"Add to Home Screen" from the browser</td></tr>
      <tr><th scope="row">Independent review</th><td>Store review for store apps; none for APKs</td><td>None, but confined by the browser</td><td>None; same as the website</td></tr>
      <tr><th scope="row">Storage used</th><td>Most of the three</td><td>Least (cached files only)</td><td>Small</td></tr>
      <tr><th scope="row">Updates</th><td>Through the store; manual for APKs</td><td>Current version on every visit</td><td>Current version on every visit</td></tr>
      <tr><th scope="row">Login</th><td>Can stay signed in; biometric unlock common</td><td>Usually sign in each session</td><td>Often stays signed in</td></tr>
      <tr><th scope="row">Notifications</th><td>Yes, if you allow them</td><td>Only if you grant permission</td><td>Possible; varies by platform and version</td></tr>
      <tr><th scope="row">Device permissions</th><td>Can request many</td><td>Limited to what the browser allows</td><td>Limited to what the browser allows</td></tr>
      <tr><th scope="row">Real-money play offline</th><td>No</td><td>No</td><td>No</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Speed and stability on mobile data</h3>
      <p>An app keeps its menus and graphics on the phone, so the lobby tends to open faster. The games themselves still come from a server in every format, so a weak signal affects all three. Live dealer tables are video streams and are the most sensitive to a patchy connection.</p>
      <p>You can test this yourself. Open the same game in each format on Wi-Fi and again on mobile data, time it with a stopwatch from tap to playable, and repeat a few times. Do it where you actually play, such as on the train, and not only at home on the NBN.</p>
      <h3>Storage, data use and updates</h3>
      <p>Apps take the most storage and browsers the least. Data use during play is driven mostly by the game, not the wrapper, although an app or PWA re-downloads fewer files.</p>
      <p>To see your own numbers on iPhone, Settings &gt; General > iPhone Storage shows app size, and the Mobile section of Settings shows data per app. On Android, look under Settings &gt; Apps and the data usage menu (names vary by manufacturer). Note the counter, play for a set time and compare.</p>
      <p>Store apps update through the store, and browser and PWA versions are current every time you load them. An APK has to be reinstalled by hand, which means going back to the same unvetted source each time.</p>
      <h3>Logins, notifications and payments</h3>
      <p>Apps make it easiest to stay logged in and to receive push notifications. That is convenient. It is also the main way promotions reach you.</p>
      <p>Payments work the same way in any format, because the cashier is a web form whichever way you open it. In Australia that usually means a debit card, a bank transfer or PayID. Licensed Australian online wagering providers are not allowed to accept credit cards.</p>
      <p>PayID is simply a way of addressing a bank transfer. It is not a mark of legitimacy, and seeing it on a site says nothing about whether the operator is licensed. Limits, bonus conditions and withdrawal times are set by the operator, so read its terms and ignore the banner.</p>
      <h3>Which suits iPhone and which suits Android</h3>
      <p>On iPhone, apps come from the App Store and Apple keeps tight control over anything else, so offshore operators lean on Safari and home-screen web apps. What a PWA can do on iOS, including notifications, depends on the iOS version.</p>
      <p>Android is more open. Chrome's PWA support is broader and sideloading APKs is possible, which is why Android users are the main target for "download our app" prompts. For licensed wagering and lottery products, both platforms have store apps and workable mobile sites, so pick whichever you find easier to keep under control.</p>
      <p class="see-also">Compare with <a href="/mobile-casino-apps-australia/">mobile casino apps in Australia: how to judge safety and quality</a>.</p>

      <h2 id="risks">Before You Download a Casino App: APKs, Fake Listings and Permissions</h2>
      <figure class="shot"><?= gw_img('articles/ab-risks', 'Chart with a warning mark beside the title APKs Fakes and Risky Permissions', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Why sideloaded APK files carry extra risk</h3>
      <p>An APK from a website has had no store review, gets no automatic security updates and can request permissions a game has no need for. You are trusting an operator that already works outside Australian law with code on a phone that also holds your banking app, email and SMS codes. Google Play Protect may warn you about the file. A site that tells you to switch it off, or to ignore the warning, has told you what you need to know.</p>
      <h3>How to spot a fake or bait-and-switch app</h3>
      <div class="flags">
        <div class="flag"><h3>Listing doesn't match the app</h3><p class="bad">The listing says one thing and the app does another, such as a puzzle or "social" game that opens a real-money cashier or redirects to a website after install.</p></div>
        <div class="flag"><h3>Unknown developer</h3><p class="bad">The developer name doesn't match the brand, or has no history, website or contact details.</p></div>
        <div class="flag"><h3>Suspicious reviews</h3><p class="bad">The reviews are all recent, generic and five-star.</p></div>
        <div class="flag"><h3>Permissions that don't fit</h3><p class="bad">The permissions don't fit a game, for example SMS, contacts, call logs, accessibility services or the ability to install other apps.</p></div>
        <div class="flag"><h3>Profiles and test builds</h3><p class="bad">On iPhone, you are asked to install a configuration profile, trust an "enterprise" developer or use a test build to get the app.</p></div>
        <div class="flag"><h3>Link from a message or ad</h3><p class="bad">The link came by text, social media ad or messaging group, and you didn't find the app in the store yourself.</p></div>
      </div>
      <h3>Browser safety checks that take one minute</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Check the address.</strong> HTTPS and a padlock are necessary, but they only prove the connection is encrypted. They don't prove the operator is honest.</li>
          <li><strong>Watch for redirects.</strong> A domain that keeps changing, or a supply of "mirror" links, suggests the site is dodging ISP blocks.</li>
          <li><strong>Search ACMA.</strong> Look for the operator on ACMA's register of licensed providers and its blocked gambling websites list.</li>
          <li><strong>Read the PayID payee name.</strong> Your bank shows the account name before you confirm. A personal name, or a different name each time, is a red flag, and bank transfers are hard to reverse.</li>
          <li><strong>Think before sending ID.</strong> Licensed Australian wagering providers must verify identity, so a request alone isn't a warning sign. Sending passport or driver licence photos to an unidentified offshore operator is a real identity-theft risk.</li>
          <li><strong>Decline prompts.</strong> Say no to notification and location requests unless you have a reason to accept.</li>
        </ol>
      </div>
      <p class="see-also">More on spotting risky sites: <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos</a>.</p>

      <h2 id="control">Responsible Gambling on Mobile: Limits, Notifications and Help</h2>
      <figure class="shot"><?= gw_img('articles/ab-control', 'Limit sliders beside the title Staying in Control on Mobile', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Set limits before the first deposit</h3>
      <p>Gambling is for adults aged 18 and over, and no format improves your chances. Every game is built so the operator comes out ahead over time, and there are no guaranteed wins in an app, a browser or a PWA.</p>
      <p>A phone is always within reach, so set your limits while you are calm. Decide on a weekly amount in dollars you could lose without touching rent or bills, and decide how long you will play. Licensed Australian wagering providers must let you set deposit limits, so use them. Screen Time on iPhone and Digital Wellbeing on Android can cap time in any app or browser.</p>
      <h3>Why push notifications deserve a second thought</h3>
      <p>Notifications exist to bring you back. Turn off promotional alerts in the app's settings or in your phone's notification settings, and unsubscribe from marketing emails and texts. Keep account security alerts if the app lets you separate them.</p>
      <h3>BetStop and Gambling Help Online</h3>
      <div class="rg-card">
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, is free and lets you exclude yourself from all licensed Australian online and phone wagering providers in one step. It does not block offshore casino sites or social casino apps.</p>
      <p>For free, confidential support at any hour, call <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or use the chat at gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Casino App vs Browser FAQ</h2>
      <div class="faq">
        <details>
          <summary>Are real-money casino apps legal in Australia?</summary>
          <p>No provider can lawfully offer real-money online casino games to people in Australia under the Interactive Gambling Act 2001, so there are no locally licensed casino apps. App stores carry licensed wagering and lottery apps, plus social casinos played with virtual coins. The Act targets providers, but players using illegal services have no local protections. ACMA has the definitive guidance.</p>
        </details>
        <details>
          <summary>Is it safe to install a casino APK on Android?</summary>
          <p>It carries more risk than a store install. An APK bypasses Google Play's review, doesn't update automatically and can ask for intrusive permissions. In Australia, a real-money casino APK also comes from an operator the law doesn't allow to offer the service here, so you would be relying entirely on its good faith. If a site asks you to disable Play Protect, don't proceed.</p>
        </details>
        <details>
          <summary>Is an instant play casino slower than an app?</summary>
          <p>Sometimes slightly, mainly when the lobby first loads, because a browser fetches files that an app already stores. Once a game is running, every format draws on the same servers, so your connection matters more than the format. The gap depends on your phone and network. Time the same game in each on your own device to find out.</p>
        </details>
        <details>
          <summary>What is a PWA casino and how is it different from a download?</summary>
          <p>A PWA casino is a website saved to your home screen with its own icon and a full-screen view. It installs from the browser, not an app store, so nobody has reviewed it and it has the same limited permissions as the site. A download means a native app from a store or an APK file, which sits on the phone as separate software.</p>
        </details>
        <details>
          <summary>Does browser play use less data and storage than an app?</summary>
          <p>For storage, yes. A browser keeps only cached files, while an app installs its full package. Data is less clear-cut. Games load from a server in every format, and a browser may re-download files an app already holds, so browser play can use the same amount or slightly more. Check your phone's per-app data and storage settings after a set session to compare.</p>
        </details>
      </div>

      <h2 id="next-step">Your Next Step: A Five-Minute Check Before You Play</h2>
      <figure class="shot"><?= gw_img('articles/ab-next', 'Checklist card beside the title Six Quick Checks First', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Look up the operator.</strong> Search ACMA's register of licensed interactive wagering providers. A service offering real-money pokies or table games online won't be on it.</li>
          <li><strong>Check the blocked list.</strong> If the brand or domain appears on ACMA's blocked gambling websites list, ACMA has identified it as an illegal service.</li>
          <li><strong>Verify the install source.</strong> Use the App Store or Google Play only, and confirm the developer name matches the licensed brand. Skip APK files, configuration profiles and links sent by text or social media.</li>
          <li><strong>Review permissions.</strong> Deny anything a betting or lottery app doesn't need, and turn off promotional notifications on day one.</li>
          <li><strong>Set limits first.</strong> Put deposit and time limits in place before any money goes in, and treat that money as spent.</li>
          <li><strong>Save the support details.</strong> Add <a href="tel:1800858858">1800 858 858</a> to your contacts and bookmark <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, so help is two taps away if you need it.</li>
        </ol>
      </div>
      <p>If a service fails step one or two, the format question is settled. Whether it arrives as an app, a browser tab or a home-screen icon, it has no Australian licence and you have no local protection.</p>
      <p><strong>Related reading:</strong> <a href="/mobile-casino-gaming-apps-vs-browser/">Mobile Casino Gaming: Apps vs Browser Play</a>, <a href="/mobile-casino-apps-australia/">Best Mobile Casino Apps Australia 2026: How to Judge Safety and Quality</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
