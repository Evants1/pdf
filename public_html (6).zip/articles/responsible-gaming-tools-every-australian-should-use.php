<?php
/**
 * Article: Responsible Gaming Tools Every Australian Should Use
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. The "Top casino of the month" banner is OFF on this page because it is written for people who want to cut back
 *    or stop gambling. To turn it on, change `$showPromo = false;` below to `true` (the phone copy follows the switch).
 * 2. INCONSISTENCY ACROSS PAGES: the FAQ here says a BetStop exclusion can be cancelled "only in limited circumstances,
 *    after at least three months, through a formal application process". /self-exclusion-australia-guide/ says it
 *    cannot be shortened or cancelled early, and the older responsible-gambling tools page mentions a removal process.
 *    Check the current rule on betstop.gov.au and make every page say the same thing.
 * 3. Also check: the phone numbers (1800 858 858, BetStop 1800 238 786, National Debt Helpline 1800 007 007, Lifeline
 *    13 11 14), "up to five support people", BetBlocker being free and run by a charity, and the three blocking
 *    products named (Gamban, BetBlocker, GamBlock).
 *
 * Layout notes:
 * - The left rail holds the table of contents (and the banner when $showPromo is true). The rail stays in view while
 *   you scroll. On phones the rail banner is hidden and, if enabled, shown inside the article instead.
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$showPromo = false;   // true = show the "Top casino of the month" banner on this page

$a   = gw_article('responsible-gaming-tools-every-australian-should-use');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php if ($showPromo) { gw_promo(); } ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#toolkit">The five layers at a glance</a></li>
            <li><a href="#account">Account limits and reality checks</a></li>
            <li><a href="#betstop">BetStop</a></li>
            <li><a href="#bank">Bank gambling blocks</a></li>
            <li><a href="#software">Blocking software</a></li>
            <li><a href="#help">Free help when limits aren't enough</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#plan">Your 20-minute setup plan</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>The responsible gaming tools that matter most in Australia fall into five layers: limits inside your betting account, the BetStop national self-exclusion register, gambling blocks from your bank, blocking software on your devices, and free professional support. No single one covers everything. Stacked together, they close most of the gaps.</p>
      <p>Each tool has a blind spot. BetStop doesn't touch venue pokies or offshore casino sites. A bank's card block may not stop a PayID transfer. Blocking software does nothing at the pub. This guide sets out what each layer blocks, what it misses, what it costs and where to switch it on.</p>
      <p>Gambling in Australia is for adults 18 and over. Treat it as paid entertainment and set your limits before you play, because no tool or strategy makes a win more likely. If things already feel out of hand, call the National Gambling Helpline on <a href="tel:1800858858">1800 858 858</a> (free, 24/7).</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Five layers work together:</strong> account limits, BetStop, a bank gambling block, blocking software and free support. No single one covers everything.</li>
          <li><strong>Each has a blind spot,</strong> so stack them rather than relying on one.</li>
          <li><strong>If things already feel out of hand,</strong> call the National Gambling Helpline on <a href="tel:1800858858">1800 858 858</a> (free, 24/7), or chat at <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a>.</li>
        </ul>
      </div>

      <h2 id="toolkit">The responsible gaming tools worth setting up first</h2>
      <figure class="shot"><?= gw_img('articles/rt-layers', 'Shield with a tick beside the title Five Layers of Protection That Stack', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>These work as layers, so most people need more than one. The table shows where each one stops working.</p>
      <h3>The five layers at a glance</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Tool</th><th scope="col">What it blocks</th><th scope="col">What it misses</th><th scope="col">Cost</th><th scope="col">Where to set it up</th></tr></thead>
      <tbody>
      <tr><th scope="row">Account limits and reality checks</th><td>Deposits and session time with that one provider</td><td>Every other account, venue and site</td><td>Free</td><td>Bookmaker app, under the safer or responsible gambling settings</td></tr>
      <tr><th scope="row">BetStop</th><td>Betting with all licensed Australian online and phone wagering providers, plus their direct marketing</td><td>Venue pokies, casinos, retail TAB outlets, offshore sites</td><td>Free</td><td><a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a></td></tr>
      <tr><th scope="row">Bank gambling block</th><td>Card payments coded as gambling</td><td>Often PayID, bank transfers, BPAY, cash and some offshore payments</td><td>Typically no fee; confirm with your bank</td><td>Banking app card settings, or by phone</td></tr>
      <tr><th scope="row">Blocking software</th><td>Gambling sites and apps on protected devices, including many offshore sites</td><td>Devices without it, venues, newly launched sites</td><td>Free or paid, depending on the provider</td><td>Gamban, BetBlocker or GamBlock websites</td></tr>
      <tr><th scope="row">Free support</th><td>Nothing directly; it helps with urges, debt and planning</td><td>Not a technical barrier</td><td>Free</td><td><a href="tel:1800858858">1800 858 858</a> or <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a></td></tr>
      </tbody>
      </table>
      </div>
      <h3>Which layer suits your situation</h3>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">If…</p>
          <h3>You bet on sport or racing and want to stay in budget</h3>
          <p>Deposit limits and activity statements, with a bank block as backup.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If…</p>
          <h3>You want to stop online betting altogether</h3>
          <p>BetStop, then a bank block and blocking software so offshore sites don't become the fallback.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If…</p>
          <h3>You've used offshore casino or pokies sites</h3>
          <p>Blocking software and bank controls first, because BetStop can't reach those sites.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If…</p>
          <h3>Your gambling is mostly venue pokies</h3>
          <p>Your state's venue self-exclusion scheme, lower ATM and card limits, and counselling.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If…</p>
          <h3>You're worried about a partner or family member</h3>
          <p>The helpline is open to you too. With their agreement, you can be a BetStop support person or hold the passcode for a device blocker.</p>
        </article>
      </div>

      <h2 id="account">Account limits and the reality check tool: controls inside your betting account</h2>
      <figure class="shot"><?= gw_img('articles/rt-account', 'Limit sliders beside the title Limits and Reality Checks', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Licensed Australian wagering providers must give customers certain protections under the National Consumer Protection Framework for Online Wagering. These include the option to set a deposit limit, regular activity statements and a simple way to close an account. Labels differ between apps, but the path is usually the same:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Log in and tap your account or profile icon.</li>
          <li>Open the section called something like Responsible Gambling, Safer Gambling or Gambling Controls.</li>
          <li>Choose the tool you want (deposit limit, reminder, break or closure) and confirm.</li>
        </ol>
      </div>
      <h3>Deposit limits: set them before you bet, not after a loss</h3>
      <p>A deposit limit caps how much you can put into the account over a set period, such as a day, week or month. Set it with a clear head, ideally when you open the account. Straight after a loss, a higher limit starts to look reasonable.</p>
      <p>As an illustration only: if $50 a week is what you'd comfortably spend on a night out, set a $50 weekly limit. The right figure is one you can lose entirely without touching rent, bills or savings. Lowering a limit generally applies straight away, while raising it normally triggers a waiting period. Check your provider's terms for the specifics.</p>
      <p>A limit applies to one account only. Five accounts with five limits is five times the budget.</p>
      <h3>How a reality check tool and activity statements show your real spend</h3>
      <p>A reality check tool is a pop-up or notification that interrupts a session after a set time. It tells you how long you've been logged in, sometimes with what you've staked and lost. Not every bookmaker app has one, and the name varies ("session reminder" is common). Where it exists, pick the shortest interval you can tolerate.</p>
      <p>Activity statements do the same job over a longer period, listing deposits, withdrawals, bets and your net result. Go straight to the net win/loss line, because it's easy to remember the wins and lose track of the losses. If you hold several accounts, add the net figures together.</p>
      <h3>Time-outs and closing an account</h3>
      <p>A time-out, sometimes called "take a break", locks you out of one account for a period you choose and usually can't be reversed early. Closing the account ends your relationship with that provider. Both help when one particular app is the problem. If the problem is betting generally, use BetStop instead of closing accounts one at a time.</p>
      <h3>Why offshore casino 'tools' are not the same protection</h3>
      <p>Many offshore casino sites advertise deposit limits, cool-offs and self-exclusion. The difference is enforcement. No Australian regulator checks that those tools work, and a limit may be lifted with a quick request to live chat. BetStop doesn't apply, and there's no local complaints path if your money goes missing.</p>
      <p>The legal position, briefly: under the Interactive Gambling Act 2001, online casino games and online pokies cannot legally be offered to people in Australia. What's regulated here is licensed online wagering, such as betting on sport and racing. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> keeps a register of licensed wagering providers and has the final word on what's permitted, so check there before trusting any site's claims.</p>
      <p class="see-also">Step-by-step help: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>.</p>

      <h2 id="betstop">BetStop: what the national self-exclusion register does and doesn't block</h2>
      <figure class="shot"><?= gw_img('articles/rt-betstop', 'Document with a magnifying glass beside the title BetStop Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> is the National Self-Exclusion Register, overseen by ACMA. One free registration excludes you from every licensed Australian online and phone wagering provider at once.</p>
      <p>BetStop is one layer of protection, so it helps to know where its coverage ends.</p>
      <h3>What you need to register and how long it lasts</h3>
      <p>You register at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, and it usually takes only a few minutes. You'll verify your identity with an accepted document (the site lists the current options) and provide contact details such as a mobile number and email address. If you get stuck, the BetStop helpdesk is on <a href="tel:1800238786">1800 238 786</a>.</p>
      <p>You choose how long the exclusion lasts, from a minimum of three months up to lifetime. You can extend it at any time, but you can't shorten it.</p>
      <p>You can also nominate up to five support people, such as a partner, friend or counsellor. For families, this is the most direct way to be involved, but it has to be the person's own decision. You can't register someone else.</p>
      <h3>What happens to your accounts and marketing</h3>
      <p>Once you're registered, licensed providers must not let you place a bet or open a new account, must close accounts you already hold, and must not send you marketing. That covers the texts, emails and app notifications from bookmakers. It won't remove gambling ads from television, sport broadcasts or social media, so add an ad blocker and mute keywords where you can.</p>
      <h3>The gaps: venue pokies, casinos and offshore sites</h3>
      <p>BetStop does not cover:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>pokies in pubs and clubs</li>
          <li>casinos</li>
          <li>betting in person at a TAB or other retail outlet</li>
          <li>online casino games, online pokies or any offshore site</li>
        </ul>
      </div>
      <p>Venue exclusion is handled state by state, with separate schemes for clubs, hotels, TAB outlets and casinos. <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> points you to the scheme for your state or territory, and a counsellor on <a href="tel:1800858858">1800 858 858</a> can help with the paperwork. Offshore sites need the bank and device layers below.</p>
      <p class="see-also">A full walkthrough: <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a>.</p>

      <h2 id="bank">Bank gambling blocks: stopping the money at the source</h2>
      <figure class="shot"><?= gw_img('articles/rt-bank', 'Wallet with payment cards beside the title Bank Gambling Blocks', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A gambling block tells your bank to decline card transactions coded as gambling. Many Australian banks offer one, but features differ, so treat these steps as a guide and confirm the details with your own bank.</p>
      <h3>How to find the gambling block in your banking app</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Open your banking app and go to your card's settings, often under Cards or Card controls.</li>
          <li>Look for an option such as Gambling block or Block gambling transactions.</li>
          <li>Switch it on for every card you hold.</li>
          <li>Ask whether there's a delay before the block can be removed. Some banks build one in, and that delay is what protects you in a weak moment.</li>
        </ol>
      </div>
      <p>Can't find it? Search the app's help section for "gambling" or call the bank. If it doesn't offer a block, ask what it can do instead.</p>
      <h3>What card blocks can miss: PayID, bank transfers and e-wallets</h3>
      <p>Blocks rely on the merchant being identified as a gambling business, and they generally apply to card payments. That leaves gaps:</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>PayID and bank transfers:</strong> these move money account to account, so a card block may not apply.</li>
          <li><strong>BPAY:</strong> the same issue arises where a bookmaker accepts it.</li>
          <li><strong>E-wallets and prepaid vouchers:</strong> the bank sees a payment to the wallet or retailer, not the gambling site.</li>
          <li><strong>Offshore sites:</strong> payments may be processed under descriptions that don't look like gambling.</li>
          <li><strong>Cash:</strong> an ATM withdrawal at a venue isn't a gambling transaction.</li>
        </ul>
      </div>
      <p>Credit cards are already banned as a payment method for online wagering with licensed providers. ACMA publishes the current rules and any exemptions. Debit cards remain a common way to deposit, so the block is still worth having.</p>
      <h3>Extra money controls: daily card limits and a trusted person</h3>
      <p>Lower your daily card, ATM and transfer limits in the app so there's a ceiling even when a payment slips through. Consider having your pay land in an account used only for bills, with a fixed amount moved to a spending account. Some people ask a trusted person to hold a card or help manage an account. Your bank can explain which arrangements it supports.</p>

      <h2 id="software">Gambling blocking software for your phone and computer</h2>
      <figure class="shot"><?= gw_img('articles/rt-software', 'Smartphone beside the title Blocking Software on Every Device', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Gambling blocking software stops gambling websites and apps from loading on the device it's installed on. It's the layer best placed to reach offshore casino and pokies sites, which BetStop can't touch and bank blocks only partly catch.</p>
      <h3>Gambling-specific blockers versus general parental-control apps</h3>
      <p>Gambling-specific blockers keep their own lists of gambling sites and apps, update them regularly, and are deliberately hard to remove once a block period starts. Three well-known ones are Gamban, BetBlocker and GamBlock.</p>
      <p>General parental controls, such as the screen-time settings built into phones, can restrict app downloads and web categories. They suit families when a trusted person holds the passcode, but they aren't built for gambling and are easier to get around. Use them alongside a dedicated blocker, never in place of one.</p>
      <h3>Free and paid options, and how to check current pricing</h3>
      <p>BetBlocker is run by a charity and is free. Gamban and GamBlock are paid products. Pricing, device limits and subscription terms change, so check each provider's website for the current cost in AUD and don't rely on a figure quoted in an article. A Gambling Help counsellor can also talk you through the options.</p>
      <h3>Install it on every device, then test it</h3>
      <p>A blocker on your phone does little if the laptop is open on the couch. Install it on every phone, tablet and computer you use and choose the longest block period you're comfortable with. Then test it by trying to open a betting site in each browser.</p>
      <p>While you're there, delete gambling apps, clear saved card details and passwords, and unsubscribe from marketing emails. Be realistic, too: no blocker catches every site, because new offshore domains keep appearing. The software adds time and friction, and that can be enough to let an urge pass.</p>

      <h2 id="help">Free gambling help tools Australia offers when limits aren't enough</h2>
      <figure class="shot"><?= gw_img('articles/rt-help', 'Dotted circles beside the title Free Help Beyond Limits', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>If you keep raising limits, hunting for ways around a block or hiding statements, it's time to add people to the plan. Plenty of people reach that point, and it doesn't mean you've failed. The gambling help tools Australia provides are free and confidential.</p>
      <h3>Self-assessment and self-help modules on Gambling Help Online</h3>
      <p><a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> has a short self-assessment that gives you a read on where your gambling sits. It also has self-help modules you can work through privately and peer forums. It's a reasonable starting point if you're not ready to talk to anyone yet.</p>
      <h3>Talking to someone: helpline, 24/7 chat and financial counselling</h3>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Free support</p>
          <h3>National Gambling Helpline, <a href="tel:1800858858">1800 858 858</a></h3>
          <p>Free, 24 hours a day, and connects you to the service in your state or territory.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Free support</p>
          <h3>Gambling Help Online chat</h3>
          <p>24/7 online counselling at <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a> if you'd rather type than talk.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Free support</p>
          <h3>Financial counselling</h3>
          <p>Gambling help services can refer you to a free financial counsellor, and the National Debt Helpline is on <a href="tel:1800007007">1800 007 007</a>.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Free support</p>
          <h3>Lifeline, <a href="tel:131114">13 11 14</a></h3>
          <p>Crisis support at any hour. Call 000 if someone is in immediate danger.</p>
        </article>
      </div>
      <p>State services go by different names, including GambleAware in NSW and Gambler's Help in Victoria, but the 1800 number routes to all of them. Partners, parents and adult children can use these services for themselves, whether or not the person gambling is ready to.</p>
      <h3>Apps for cutting back or quitting</h3>
      <p>Several apps help with tracking spend, riding out urges and setting goals. Availability changes, and app stores mix genuine support apps with gambling products. Start from the apps currently recommended by Gambling Help Online or your state service.</p>

      <h2 id="faq">Responsible gaming tools FAQ</h2>
      <div class="faq">
        <details>
          <summary>Does BetStop block online casinos and pokies sites?</summary>
          <p>No. BetStop applies only to licensed Australian online and phone wagering providers. Online casino games and online pokies can't legally be offered in Australia, and the offshore sites that provide them sit outside the register. Use blocking software and bank controls for those, and see <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> for the current scope.</p>
        </details>
        <details>
          <summary>What is a reality check tool and can I change how often it appears?</summary>
          <p>It's a timed reminder inside a betting account that shows how long you've been playing and, in some apps, what you've spent. Whether you can change the interval depends on the provider. Look in the safer gambling settings, or ask the provider's support team if you can't find it.</p>
        </details>
        <details>
          <summary>Is gambling blocking software free in Australia?</summary>
          <p>Some is. BetBlocker is free, while Gamban and GamBlock are paid. Prices change, so check each provider's website for current AUD pricing before subscribing. Gambling Help Online has information on blocking software, and a counsellor on <a href="tel:1800858858">1800 858 858</a> can help you choose one that suits your devices.</p>
        </details>
        <details>
          <summary>Can my bank block gambling transactions?</summary>
          <p>Many Australian banks can block card transactions coded as gambling, usually through the app's card settings or by phone. Coverage varies: PayID, bank transfers and BPAY often aren't included, and removal delays differ. Your bank's help page or call centre is the place to confirm what its block does.</p>
        </details>
        <details>
          <summary>Can I cancel a self-exclusion early?</summary>
          <p>You can't shorten a BetStop exclusion once it's set, only extend it. Cancelling is possible only in limited circumstances, after at least three months, through a formal application process. Rules can change, so read the current conditions on betstop.gov.au. State venue schemes set their own terms.</p>
        </details>
      </div>

      <h2 id="plan">Your 20-minute setup plan</h2>
      <figure class="shot"><?= gw_img('articles/rt-plan', 'Checklist card beside the title A 20-Minute Setup Plan', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Do these in order. With your ID and banking app handy, allow about 20 minutes for the lot.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Set a deposit limit in every betting account you hold, using a figure you could lose without affecting bills.</li>
          <li>Switch on the bank gambling block for every card, then lower your daily card and transfer limits.</li>
          <li>Install a blocker on your phone first, then your other devices, and test it.</li>
          <li>Register with BetStop if you want to stop online betting. Choose the period carefully, because it can be extended but not shortened.</li>
          <li>Save <a href="tel:1800858858">1800 858 858</a> in your contacts and bookmark the Gambling Help Online chat.</li>
        </ol>
      </div>
      <p>Gambling is for adults 18+, it costs money like any other entertainment, and nothing guarantees a win. If the limits you set today don't hold, call the helpline.</p>
      <p><strong>Related reading:</strong> <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">Responsible Gambling Tools, Limits &amp; Self-Exclusion Australia</a>, <a href="/how-to-set-deposit-and-loss-limits-australia/">How to Set Deposit &amp; Loss Limits in Australian Casinos</a>, <a href="/self-exclusion-australia-guide/">Responsible Gambling Self-Exclusion Australia Guide</a>.</p>

<?php if ($showPromo): ?>
      <div class="story-promo-m"><?php gw_promo(); ?></div>
<?php endif; ?>
      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
