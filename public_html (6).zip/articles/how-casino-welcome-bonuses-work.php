<?php
/**
 * Article: How Casino Welcome Bonuses Work, and What to Check First
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. Your original text (opening, note, the four bonus types, the wagering explanation and table, the seven terms, "why
 *    wagering costs you something", the five-point checklist and the closing paragraph) is kept word for word. ADDED: the
 *    "In short" box, "from claim to withdrawal" (with two illustrative figures), "what can void a bonus", "where to find
 *    the terms", five FAQs and a responsible-gambling paragraph. Edit or delete any added section freely.
 * 2. This page's angle is "how a bonus works, step by step". Keep it distinct from /how-casino-welcome-bonuses-are-calculated/
 *    (the arithmetic), /australian-casino-welcome-bonuses-comparison/ (the types), /best-casino-bonuses-for-australian-players/
 *    (choosing by how you play) and /how-casino-welcome-bonuses-work-in-australia/ (the Australian rules).
 * 3. The "sticky bonus at withdrawal" figure (150 balance minus 100 bonus = 50) is illustrative; real terms differ by offer.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. On phones the rail
 *   banner is hidden and the same banner is shown inside the article instead (after the "claim to withdrawal" section).
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('how-casino-welcome-bonuses-work');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#types">The common types of welcome bonus</a></li>
            <li><a href="#wagering">Wagering requirements, with an example</a></li>
            <li><a href="#journey">From claim to withdrawal</a></li>
            <li><a href="#terms">The terms that change the value</a></li>
            <li><a href="#void">What can void a bonus</a></li>
            <li><a href="#find">Where to find the terms</a></li>
            <li><a href="#expected-cost">Why wagering costs you something</a></li>
            <li><a href="#checklist">A pre-claim checklist</a></li>
            <li><a href="#faq">Quick answers</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>A welcome bonus is a marketing tool. It can be good value, but only if you understand the conditions attached to it. This guide explains the common structures and shows how to work out what a bonus is actually worth. We do not list current offers here, because terms change often and the figures that matter are always in the operator's own terms.</p>
      <aside class="note">
      <p><strong>Australian readers.</strong> Licensed Australian wagering providers are generally not allowed to offer sign-up inducements to open an account. Large welcome offers are mainly found on offshore sites, which operate outside Australian consumer protections. See <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>
      </aside>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>A welcome bonus is a marketing tool,</strong> and its value sits in the conditions, not the headline.</li>
          <li><strong>The wagering requirement is the amount you must bet before bonus-related funds can be withdrawn,</strong> and what it applies to changes the workload.</li>
          <li><strong>A withdrawal requested too early can cost you the bonus.</strong> Know the rules before you play.</li>
          <li><strong>Declining a bonus is always acceptable,</strong> and often makes withdrawals simpler.</li>
        </ul>
      </div>

      <h2 id="types">The common types of welcome bonus</h2>
      <figure class="shot"><?= gw_img('articles/hw-types', 'Gift box beside the title Four Types of Bonus', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Match deposit bonus</h3>
      <p>The casino adds bonus funds based on your deposit, for example a 100% match on a deposit up to a stated limit. Deposit 100 and receive 100 in bonus funds, for 200 in total to play with, subject to the terms.</p>
      <h3>Free spins</h3>
      <p>A set number of spins on one or more named slots, usually at a fixed stake per spin. Winnings from free spins are often credited as bonus funds with their own wagering requirement and a cap on how much can be withdrawn.</p>
      <h3>No-deposit bonus</h3>
      <p>Bonus funds or spins awarded without a deposit. These tend to carry strict wagering requirements and low maximum cash-outs, which is how operators control the cost.</p>
      <h3>Cashback</h3>
      <p>A percentage of net losses returned over a period. Check whether it is paid as cash or as bonus funds, because bonus funds usually carry wagering requirements of their own.</p>
      <p class="see-also">Compare them side by side: <a href="/australian-casino-welcome-bonuses-comparison/">how the main welcome bonus types compare</a>.</p>

      <h2 id="wagering">Wagering requirements, with an example</h2>
      <figure class="shot"><?= gw_img('articles/hw-wager', 'Casino coin beside the title Wagering Worked Out', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The wagering requirement, sometimes called playthrough, is the amount you must bet before bonus-related funds can be withdrawn. It is expressed as a multiple. Here is an illustrative example, not a real offer:</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Illustrative wagering arithmetic for a 100 deposit and 100% match</caption>
      <thead><tr><th scope="col">Rule</th><th scope="col">Calculation</th><th scope="col">Total you must bet</th></tr></thead>
      <tbody>
      <tr><th scope="row">35x on the bonus only</th><td>100 bonus x 35</td><td>3,500</td></tr>
      <tr><th scope="row">35x on deposit plus bonus</th><td>200 x 35</td><td>7,000</td></tr>
      </tbody>
      </table>
      </div>
      <p>The same headline multiple can mean very different workloads depending on what it applies to. Always check whether it is calculated on the bonus alone or on deposit plus bonus.</p>
      <p class="see-also">Worked step by step: <a href="/how-casino-welcome-bonuses-are-calculated/">how casino welcome bonuses are calculated</a>.</p>

      <h2 id="journey">From claim to withdrawal: how a bonus moves through your account</h2>
      <figure class="shot"><?= gw_img('articles/hw-journey', 'Payment list with a clock beside the title From Claim to Withdrawal', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>It helps to see a bonus as a sequence, because each step has its own rule. Using the same illustrative offer as above (a 100 deposit, a 100% match and 35x wagering on the bonus only), this is how it moves through your account.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Claim.</strong> You opt in, usually by ticking a box at deposit, entering a code or asking support. The bonus terms apply from that point.</li>
          <li><strong>Deposit.</strong> Your cash is credited, and the match arrives as bonus funds: 200 in total to play with.</li>
          <li><strong>Play.</strong> The terms say which balance is spent first. That order matters a great deal, and it is the difference between a sticky and a non-sticky bonus.</li>
          <li><strong>Wagering.</strong> Each qualifying bet counts towards the requirement, at the game's contribution. Many sites show your progress in an active bonuses or wagering progress area of your account.</li>
          <li><strong>Completion.</strong> Once the requirement is met, the funds unlock, subject to the maximum cash-out and to ID checks.</li>
          <li><strong>Withdrawal.</strong> You request a payout. Asking before the wagering is finished can block the request, or remove the bonus and the winnings attached to it.</li>
        </ol>
      </div>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Wagering progress</p>
          <p class="ex-sum">A$1,750 of A$3,500</p>
          <p class="ex-big">50%</p><p class="ex-lbl">after A$1,750 of qualifying bets</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">A sticky bonus at withdrawal</p>
          <p class="ex-sum">A$150 balance − A$100 bonus</p>
          <p class="ex-big">A$50</p><p class="ex-lbl">is what the player could cash out</p>
        </div>
      </div>
      <p>Both figures are illustrative, in Australian dollars, and the exact rules differ from offer to offer. They show why the order in which balances are spent and the point at which you withdraw both matter.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="terms">The terms that change the value</h2>
      <figure class="shot"><?= gw_img('articles/hw-terms', 'Document with a magnifying glass beside the title Terms That Change Value', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Game contribution.</strong> Slots often count 100% towards wagering while table games and live dealer games count less or nothing.</li>
          <li><strong>Maximum bet.</strong> Many bonuses limit your stake per spin or hand while wagering. Exceeding it can void the bonus.</li>
          <li><strong>Time limit.</strong> Bonuses expire. A big requirement with a short deadline is hard to complete.</li>
          <li><strong>Maximum cash-out.</strong> Some bonuses cap the winnings you can withdraw.</li>
          <li><strong>Sticky or non-sticky.</strong> A sticky bonus cannot be withdrawn and is removed from your balance when you cash out. A non-sticky bonus lets you play with cash first.</li>
          <li><strong>Excluded payment methods.</strong> Some e-wallets or methods may not qualify for a bonus.</li>
          <li><strong>Country restrictions.</strong> Offers can differ by region.</li>
        </ul>
      </div>

      <h2 id="void">What can void a bonus</h2>
      <figure class="shot"><?= gw_img('articles/hw-void', 'Chart with a warning mark beside the title What Can Void a Bonus', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Most bonuses are lost by accident, not by cheating. These are the common ways, and every one of them is written in the terms.</p>
      <div class="flags">
        <div class="flag"><h3>Betting over the maximum</h3><p class="bad">Placing a bet larger than the maximum allowed while the bonus is active, even once.</p></div>
        <div class="flag"><h3>Withdrawing too early</h3><p class="bad">Requesting a payout before the wagering is finished, which can remove the bonus and the winnings attached to it.</p></div>
        <div class="flag"><h3>Playing excluded games</h3><p class="bad">Using games that are excluded from the offer or count for nothing towards wagering.</p></div>
        <div class="flag"><h3>Restricted betting patterns</h3><p class="bad">Betting in a way the terms forbid, such as covering most of a roulette layout.</p></div>
        <div class="flag"><h3>A payment method that doesn't qualify</h3><p class="bad">Funding the account with a method the offer excludes.</p></div>
      </div>

      <h2 id="find">Where to find the terms</h2>
      <p>The promotional summary is not the offer. The terms are. Look in three places, and keep a dated screenshot of what you read.</p>
      <div class="rg-card">
        <ul class="checks">
          <li>The terms linked from the promotion itself.</li>
          <li>The operator's general terms, usually under a bonuses or promotions heading.</li>
          <li>The active bonuses or wagering progress area of your account, once a bonus is live.</li>
        </ul>
      </div>
      <p>If something is unclear, ask live chat or email support and keep the reply. If the terms are missing, contradict the promotion page or give a multiplier without saying what it applies to, you cannot calculate the offer, so skip it.</p>

      <h2 id="expected-cost">Why wagering costs you something</h2>
      <figure class="shot"><?= gw_img('articles/hw-cost', 'Dice and chips beside the title The Cost of Wagering', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Every game has a house edge, which means that over time a portion of what you bet is kept by the casino. The long-run figure for a slot is expressed as return to player, covered in <a href="/understanding-rtp-and-volatility-in-online-slots/">our RTP guide</a>. If a slot has an RTP of 96%, the average long-run cost is 4% of everything you bet. Wagering 3,500 at that rate has an average expected cost of 140, which is more than the 100 bonus in our example. Results vary enormously in the short term, but the arithmetic shows why a high wagering requirement can make a bonus worth less than it looks.</p>

      <h2 id="checklist">A pre-claim checklist</h2>
      <figure class="shot"><?= gw_img('articles/hw-next', 'Checklist card beside the title Pre-Claim Checklist', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Find the full bonus terms, not the promotional summary.</li>
          <li>Note the wagering multiple and what it applies to.</li>
          <li>Check the expiry period, maximum bet and maximum cash-out.</li>
          <li>Check that your payment method and the games you like qualify.</li>
          <li>Decide whether you would still deposit if there were no bonus. If not, skip it.</li>
        </ol>
      </div>
      <p>It is always acceptable to decline a bonus. Most casinos let you opt out at deposit, and doing so can make withdrawals simpler. For a broader view of how bonuses fit into choosing an operator, see <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a> and our permanent <a href="/online-casino-bonuses/">online casino bonuses guide</a>.</p>
      <p class="see-also">Choosing by how you play: <a href="/best-casino-bonuses-for-australian-players/">best bonuses for Australian players</a>. No-deposit offers: <a href="/no-deposit-bonuses-australia/">no-deposit bonuses in Australia</a>.</p>

      <h2 id="faq">Quick answers</h2>
      <div class="faq">
        <details>
          <summary>Is a welcome bonus free money?</summary>
          <p>No. It is a marketing tool, and the wagering requirement means you must bet a multiple of it before bonus-related funds can be withdrawn. Because every game has a house edge, that betting has an average cost, which can be more than the bonus itself.</p>
        </details>
        <details>
          <summary>Can I withdraw my deposit while a bonus is active?</summary>
          <p>Not reliably. A withdrawal requested before the wagering is finished may be blocked or refused, or the bonus and the winnings attached to it may be removed. Read the exact rule in the terms before you ask.</p>
        </details>
        <details>
          <summary>How do I opt out of a bonus?</summary>
          <p>Most casinos let you opt out at deposit, usually by unticking a box. If you have missed that, ask support in writing to remove the bonus before you play with it. After you start betting with bonus funds, its terms normally apply.</p>
        </details>
        <details>
          <summary>Why did my bonus disappear?</summary>
          <p>Usual reasons are that it expired before the wagering was finished, that you went over the maximum bet, that you withdrew early, or that you played excluded games. Each one will be in the terms, so check them against your account history.</p>
        </details>
        <details>
          <summary>Do welcome bonuses work the same in Australia?</summary>
          <p>Licensed Australian wagering providers are generally not allowed to offer sign-up inducements to open an account, so large welcome offers are mainly found on offshore sites, which operate outside Australian consumer protections. Check ACMA for the current rules.</p>
        </details>
      </div>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over, and no bonus guarantees a win. A bonus is a cost to weigh, not a gift, and money you need for bills should never be gambled. If gambling is causing you stress, free and confidential support is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <?php gw_topic_links($a['slug']); ?>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
