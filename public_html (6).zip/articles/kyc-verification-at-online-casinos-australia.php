<?php
/**
 * Article: KYC Verification at Online Casinos Australia
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the documents section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('kyc-verification-at-online-casinos-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#who-checks">Who has to check your ID</a></li>
            <li><a href="#triggers">When verification is triggered</a></li>
            <li><a href="#documents">The Australian document checklist</a></li>
            <li><a href="#first-time">How to pass first time</a></li>
            <li><a href="#stuck">Rejected or stuck?</a></li>
            <li><a href="#safe">Keeping your ID safe</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Before you upload</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>KYC stands for 'know your customer': the checks a gambling operator runs to confirm you are a real adult, that you live where you say you do, and that the money and payment methods on your account are yours. If you searched casino KYC Australia because a site has just asked for ID, here is the short answer. You will normally need three things: government photo ID, a recent proof of address, and proof you own the payment method you are cashing out to.</p>
      <div class="mini3">
        <div><h3>Government photo ID</h3><p>Proves who you are and that you are 18 or over.</p></div>
        <div><h3>Recent proof of address</h3><p>Shows where you live.</p></div>
        <div><h3>Proof of payment method</h3><p>Shows the payout is going to the person who deposited.</p></div>
      </div>
      <p>Two very different sets of rules can sit behind that request. Australian-licensed betting sites must verify you before you can bet. Offshore casino sites are not licensed here at all and check ID under their own terms, usually when you withdraw. This guide covers both, lists the Australian documents commonly accepted, and shows how to avoid a stalled payout. It recommends no casinos.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Expect three documents:</strong> photo ID, a recent proof of address and proof you own the payment method.</li>
          <li><strong>Offshore casinos usually check at your first withdrawal,</strong> under their own terms and not Australian rules.</li>
          <li><strong>Match every detail exactly,</strong> photograph documents properly and send everything in one batch.</li>
          <li><strong>Upload only inside your secure account area,</strong> and never send a CVV, banking password or one-time code.</li>
        </ul>
      </div>

      <h2 id="who-checks">Casino KYC in Australia: Who Actually Has to Check Your ID</h2>
      <figure class="shot"><?= gw_img('articles/kycau-who-checks', 'Shield with a tick beside the title Who Has to Check Your ID', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="vs">
        <div class="vs-col">
          <h3>Licensed Australian betting sites</h3>
          <ul>
            <li>Federal anti-money laundering law applies</li>
            <li>ID is checked before you bet</li>
          </ul>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Offshore casino sites</h3>
          <ul>
            <li>Not licensed in Australia</li>
            <li>Check ID under their own terms, usually at withdrawal</li>
          </ul>
        </div>
      </div>
      <h3>Licensed Australian betting sites: ID before you bet</h3>
      <?php /* OWNER TODO: the AUSTRAC date (29 September 2024) and the reference to AUSTRAC's published indicators of suspicious activity were supplied as text and could not be independently verified when this page was built. Confirm both on austrac.gov.au before relying on them. */ ?>
      <p>Sports and racing betting sites licensed in an Australian state or territory fall under federal anti-money laundering law, supervised by AUSTRAC. According to AUSTRAC, since 29 September 2024 these providers must verify a customer's identity before opening the account or taking a bet, rather than during a grace period afterwards. In practice this is usually an electronic check. You type in your driver licence, passport or Medicare details, they are matched against official records, and you often never upload a photo.</p>
      <h3>Offshore casino sites: not licensed here, their own rules</h3>
      <p>Online casino games and pokies are treated differently. Under the Interactive Gambling Act 2001, these services cannot lawfully be provided to customers in Australia, and there is no Australian licence for them. Operators that offer them anyway, wherever they are based, are the ones in breach. A licence from Curaçao or another overseas jurisdiction does not change that.</p>
      <p>These sites are not bound by the AUSTRAC rule above. They verify under their own terms and conditions, typically at withdrawal. Published legal commentary generally places the Act's offences on those providing or advertising the service rather than on the person playing. That is not legal advice. Nor does it mean playing is approved, or that Australian consumer protection applies if something goes wrong.</p>
      <h3>Where to check the law: ACMA and AUSTRAC</h3>
      <p>The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces the Interactive Gambling Act and is the place to go for the final word on whether a service is legal here. It publishes a register of licensed interactive wagering providers and a list of blocked gambling websites. ACMA also explains the payment rules for licensed online wagering, including the ban on credit cards and digital currency. For the identity rules that apply to licensed providers, go to <a href="https://www.austrac.gov.au" rel="noopener">AUSTRAC</a>.</p>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a> and <a href="/understanding-australian-online-gambling-regulations/">who regulates what in Australian online gambling</a>.</p>

      <h2 id="triggers">When Casino Verification in Australia Gets Triggered</h2>
      <figure class="shot"><?= gw_img('articles/kycau-triggers', 'Payment list with a clock beside the title When Checks Are Triggered', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Operators do not share one timetable, but casino verification in Australia tends to appear at three points.</p>
      <h3>At sign-up or first deposit</h3>
      <p>Licensed Australian betting sites check here because they have to. Some offshore sites also run a light check at registration, such as confirming your email, mobile number and date of birth, then let you deposit without any documents. An easy deposit tells you nothing about how easy the withdrawal will be.</p>
      <h3>At your first withdrawal</h3>
      <p>This is the most common trigger at offshore casino sites. Your request moves to 'pending' while a payments or compliance team reviews your documents. It can feel like an obstacle sprung on you, but it is usually written into the terms you accepted when you signed up.</p>
      <h3>Later re-checks: large amounts, changed details, new payment method</h3>
      <p>Passing once does not always mean you are done. Expect a fresh request when:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>you make a larger withdrawal, or your total withdrawals build up over time</li>
          <li>you change your name, address, email or phone number</li>
          <li>you add a new card, bank account, e-wallet or crypto wallet</li>
          <li>the ID on file expires</li>
          <li>your activity looks unusual, such as depositing and withdrawing with little play, or logging in from another country</li>
        </ul>
      </div>
      <p>Dollar thresholds quoted on comparison sites vary by operator and can change without notice, so treat them with caution. Open the site's terms and search the page for 'verification', 'KYC' and 'withdrawal' to see exactly what it reserves the right to ask for.</p>
      <p class="see-also">See how checks fit into the payout process in <a href="/how-casino-withdrawals-work-speed-and-limits/">how casino withdrawals work: speed and limits</a> and <a href="/how-fast-do-online-casinos-pay-out-australia/">how fast online casinos pay out</a>.</p>

      <h2 id="documents">Documents for Casino Withdrawal: The Australian Checklist</h2>
      <figure class="shot"><?= gw_img('articles/kycau-documents', 'Document with a magnifying glass beside the title Documents for Casino Withdrawal', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Accepted documents vary by operator. The upload page or the email from support is the authority, not this checklist. With that caveat, these are the documents for casino withdrawal checks that Australians are commonly asked to provide.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Have these documents ready before you request your first casino withdrawal.</caption>
      <thead><tr><th scope="col">Check</th><th scope="col">Typical Australian documents</th><th scope="col">What must be visible</th><th scope="col">Common mistakes</th></tr></thead>
      <tbody>
      <tr><th scope="row">Identity and age (18+)</th><td>Driver licence (front and back), passport photo page, state proof of age or photo card</td><td>Full name, date of birth, photo, document number, expiry date</td><td>Expired ID, only one side of the licence, cropped corners, glare over the photo</td></tr>
      <tr><th scope="row">Address</th><td>Electricity, gas, water or internet bill; council rates notice; bank statement</td><td>Full name, residential address, issuer's name or logo, issue date</td><td>Cropped screenshot instead of the full PDF, PO box address, document too old, bill in a partner's name</td></tr>
      <tr><th scope="row">Payment ownership</th><td>Card photo; bank statement or banking-app screenshot; PayID details screen; e-wallet profile; crypto wallet or exchange record</td><td>Your name plus the card, account or wallet identifier used on the site</td><td>Someone else's account, full card number or CVV left exposed, screenshot with no name on it</td></tr>
      <tr><th scope="row">Source of funds</th><td>Payslips, bank statements showing salary, ATO notice of assessment, sale or inheritance paperwork</td><td>Your name, the payer, amounts and dates</td><td>Edited documents, statements that do not cover the period requested</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Proof of identity</h3>
      <p>This proves who you are and that you are 18 or over. A driver licence is the usual choice, photographed on both sides. A passport needs only the photo page. Medicare cards and digital driver licences shown in a state app are accepted by some operators and refused by others, so check the upload page before relying on them. Many sites add a selfie holding the ID or a live camera check.</p>
      <h3>Proof of address</h3>
      <p>This shows where you live. Operators commonly want a recent document, often described as issued within about three months, but each sets its own window. Download the full PDF from your provider or bank rather than screenshotting part of it. Some operators refuse mobile phone bills.</p>
      <h3>Proof of payment method (card, bank or PayID, e-wallet, crypto)</h3>
      <p>This proves the payout is going back to the person who deposited.</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Payment proof</p>
          <h3>Card</h3>
          <p>A photo of the card with the middle digits covered.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment proof</p>
          <h3>Bank transfer or PayID</h3>
          <p>A statement or banking-app screenshot showing the account name alongside the BSB and account number or the PayID.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment proof</p>
          <h3>E-wallet</h3>
          <p>The profile page showing your name and registered email.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Payment proof</p>
          <h3>Crypto</h3>
          <p>The wallet address used, and sometimes an exchange record in your name or a transaction ID.</p>
        </article>
      </div>
      <h3>Source of funds requests</h3>
      <p>Not every player is asked for this. It shows where your gambling money came from and usually follows larger or unusual activity. Send the documents unedited unless the operator says you may blank out unrelated transactions, because altered files are a common reason for rejection.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="first-time">How to Pass Casino ID Verification the First Time</h2>
      <figure class="shot"><?= gw_img('articles/kycau-first-time', 'Checklist card beside the title Pass ID Checks First Time', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Failed casino ID verification attempts often come down to mismatched details or poor photos. Work through these steps before you upload.</p>
      <h3>Match your account details to your ID exactly</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Use your full legal name.</strong> It should appear on the account exactly as printed on your ID, including middle names and hyphens. If the account says 'Dave' and your licence says 'David', ask support to correct it first.</li>
          <li><strong>Check your date of birth and address.</strong> The address on the account should match your proof of address, down to the unit number.</li>
          <li><strong>Use payment methods in your own name only.</strong> AUSTRAC's published indicators of suspicious activity for the betting sector include mismatches between the details on a betting account and the payment method used with it. That is why a partner's card or a mate's PayID is a quick route to a frozen withdrawal.</li>
        </ul>
      </div>
      <h3>Photograph documents properly</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Show all four corners.</strong> Lay the document flat on a plain, dark surface and keep the whole thing in frame.</li>
          <li><strong>Shoot in colour with no glare.</strong> Use daylight, turn the flash off, and tilt the card slightly if a hologram is washing out the text.</li>
          <li><strong>Do not edit the image.</strong> No filters, cropping or black-and-white scans. Check the upload page for accepted file types and size limits.</li>
          <li><strong>Mask cards safely.</strong> Cover the middle digits on the front so only the first six and last four show, and never show the CVV. Follow the operator's own masking instructions where they differ.</li>
        </ul>
      </div>
      <h3>Submit everything in one go and keep records</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>Upload before you request a payout if the account area allows it, so the review is not sitting on top of a pending withdrawal.</li>
          <li><strong>Send every document in one batch.</strong> Drip-feeding files can mean going back into the queue each time.</li>
          <li><strong>Keep records.</strong> Screenshot the upload confirmation, save emails and chat transcripts, and note the date you submitted.</li>
        </ul>
      </div>

      <h2 id="stuck">Verification Rejected or Stuck? Fixes and Escalation</h2>
      <figure class="shot"><?= gw_img('articles/kycau-stuck', 'Chart with a warning mark beside the title Rejected or Stuck Fixes', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Common rejection reasons and the fix for each</h3>
      <div class="table-wrap">
      <table class="data">
      <caption>Why verification fails and the fix</caption>
      <thead><tr><th scope="col">Reason</th><th scope="col">Fix</th></tr></thead>
      <tbody>
      <tr><th scope="row">Blurry or cut-off image</th><td>Retake it in daylight with all four corners in frame.</td></tr>
      <tr><th scope="row">Name or address mismatch</th><td>Ask support to correct the account, or supply a linking document such as a marriage or change-of-name certificate.</td></tr>
      <tr><th scope="row">Expired ID</th><td>Use a current document, such as your passport if your licence renewal is pending.</td></tr>
      <tr><th scope="row">Proof of address too old or the wrong type</th><td>Download a fresh bill or statement as a full PDF.</td></tr>
      <tr><th scope="row">Payment method not in your name</th><td>There is no neat fix. Explain the situation honestly and expect the operator to insist on paying an account you can prove is yours.</td></tr>
      <tr><th scope="row">Edited or masked file</th><td>Resend the untouched original, masking only what the operator allows.</td></tr>
      </tbody>
      </table>
      </div>
      <h3>How to follow up with support</h3>
      <p>Ask in writing which document failed and why, then request a reference number and a written timeframe for the review. Keep everything in one email thread or ticket, because duplicate tickets tend to slow things down. Avoid reversing the withdrawal to keep playing while you wait.</p>
      <h3>Your limited options with an unlicensed operator</h3>
      <p>If the dispute is with a licensed Australian betting provider, you can complain to the state or territory regulator that issued its licence. With an offshore casino, be realistic. ACMA and other Australian regulators cannot recover money from offshore sites or force a payout. You can complain to the overseas licensing body named in the site's footer, but nothing guarantees a result.</p>
      <p>You can still report the site. ACMA accepts complaints about illegal gambling services through the form on its website. It can investigate and ask internet providers to block the site, which protects other people but will not return your balance.</p>
      <p class="see-also">See our <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos guide</a> and <a href="/how-to-withdraw-from-online-casinos-australia/">how to withdraw from online casinos in Australia</a>.</p>

      <h2 id="safe">Keeping Your ID Safe and Your Gambling in Check</h2>
      <figure class="shot"><?= gw_img('articles/kycau-privacy', 'Shield with a tick beside the title Keep Your ID Safe Offshore', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Privacy risks of sending ID offshore</h3>
      <p>A driver licence, a proof of address and a card image together are enough for someone to impersonate you. When the operator sits outside Australian oversight, you cannot assume Australian privacy protections apply or could be enforced if your documents are leaked or misused. These safeguards reduce the risk:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Upload only through the secure account area, never by replying to an email, chat link or social media message.</li>
          <li>Where the operator accepts it, watermark copies with the site name, the purpose and the date, without covering any details it needs to read.</li>
          <li>Never send a full card number, CVV, banking password or one-time code.</li>
          <li>If you think your ID has been misused, contact the agency that issued it and IDCARE, the national identity support service.</li>
        </ul>
      </div>
      <h3>Red flags in a verification request</h3>
      <p>Stop and reconsider if you see any of the following:</p>
      <div class="flags">
        <div class="flag"><h3>Requests outside your account</h3><p class="bad">Requests that arrive outside your account area</p></div>
        <div class="flag"><h3>Fee to release a withdrawal</h3><p class="bad">A fee or extra deposit demanded to 'release' a withdrawal</p></div>
        <div class="flag"><h3>Remote access demands</h3><p class="bad">Requests for remote access to your phone or your banking login</p></div>
        <div class="flag"><h3>Repeated new demands</h3><p class="bad">Repeated demands for new documents after you have supplied everything originally asked for</p></div>
      </div>
      <p>Every extra file you send increases your exposure.</p>
      <h3>Responsible gambling: 18+, limits, BetStop and Gambling Help</h3>
      <div class="rg-card">
      <p>Online gambling is for adults aged 18 and over. No outcome is guaranteed, so only gamble money you can afford to lose and set deposit and time limits before you start. <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, covers licensed Australian online and phone wagering providers only. It will not block offshore casinos. Free, confidential support is available around the clock from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a>.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Casino KYC Australia FAQ</h2>
      <div class="faq">
        <details>
          <summary>Why is the casino asking for ID when I try to withdraw?</summary>
          <p>The operator wants to confirm the payout is going to the adult who owns both the account and the payment method. At offshore casino sites this check is usually written into the terms and held back until the first withdrawal. Licensed Australian betting sites do it earlier, before you can bet, under AUSTRAC rules.</p>
        </details>
        <details>
          <summary>What documents do I need for a casino withdrawal in Australia?</summary>
          <p>Commonly three: government photo ID such as a driver licence (both sides) or passport, a recent proof of address such as a utility bill, rates notice or bank statement, and proof you own the payment method, such as a banking or PayID screenshot showing your account name. Requirements vary, so check the operator's upload page.</p>
        </details>
        <details>
          <summary>How long does casino verification take?</summary>
          <p>There is no standard timeframe, and any figure quoted on a comparison site is not a guarantee. It depends on the operator, how clear your documents are and whether extra checks are triggered. Read the withdrawal section of the terms, then ask support for a written estimate and a reference number.</p>
        </details>
        <details>
          <summary>Is it safe to send my driver licence or passport to an online casino?</summary>
          <p>It carries real risk when the operator is outside Australian oversight, because you cannot count on Australian privacy law to protect you or give you a remedy. If you go ahead, upload only through the secure account area, watermark copies where allowed, mask card numbers and never share a CVV or banking login.</p>
        </details>
        <details>
          <summary>Can I withdraw without verifying my identity?</summary>
          <p>Generally no. Sites advertised as 'no KYC' usually still reserve the right in their terms to request documents before paying out, and may use it at any time. Licensed Australian betting sites cannot open your account without verification. Assume you will be asked, and read the terms before you deposit.</p>
        </details>
      </div>

      <h2 id="next-step">Before You Upload Anything: Your Next Step</h2>
      <figure class="shot"><?= gw_img('articles/kycau-next', 'Limit sliders beside the title Before You Upload Anything', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Do these three things, in this order, before you send a single file:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Check the operator's status with ACMA.</strong> Search the register of licensed wagering providers and the blocked-sites list. If the site is not licensed in Australia, weigh up whether you want it holding your ID at all, knowing your options are limited if things go wrong.</li>
          <li><strong>Read the verification terms.</strong> Search the terms and conditions for 'verification', 'KYC' and 'withdrawal' so you know what can be requested and when.</li>
          <li><strong>Prepare the three core documents.</strong> Have current photo ID, a recent proof of address and proof of your payment method ready, all in your own name and matching your account details exactly.</li>
        </ol>
      </div>
      <p>If anything about the request looks off, pause and ask support to explain it in writing before you upload. And if gambling is costing more time or money than you planned, call Gambling Help Online on <a href="tel:1800858858">1800 858 858</a>.</p>
      <p><strong>Related reading:</strong> <a href="/online-gambling-laws-in-australia/">Online Gambling Laws in Australia: What Players Should Know</a>, <a href="/online-gambling-laws-in-australia-2026/">Online Gambling Laws in Australia 2026</a>, <a href="/understanding-australian-online-gambling-regulations/">Understanding Australian Online Gambling Regulations</a>, <a href="/online-casinos-australia-pros-cons-legality/">Online Casinos Australia – Pros, Cons &amp; Legality</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
