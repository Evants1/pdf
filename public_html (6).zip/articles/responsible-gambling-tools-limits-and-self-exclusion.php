<?php
/**
 * Article: Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. BANNER: this is a protective page, so the "Top casino of the month" banner is switched OFF (like the other
 *    responsible-gambling pages). To turn it on, change `$showPromo = false;` below to `true`; the phone copy follows the switch.
 * 2. Your original text (opening, before you play, the seven-row tools table, self-exclusion, warning signs, independent help
 *    and the closing section) is kept word for word. ADDED: the "In short" box, "where each tool applies", a short note under
 *    the warning signs, "your safer gambling plan in writing" (with two hypothetical figures), "on a hard day",
 *    "if you are worried about someone else" and five FAQs. Edit or delete any added section freely.
 * 3. HELPLINES: please check each number and website on the official sources before relying on them (Gambling Help Online
 *    1800 858 858, Lifeline 13 11 14, BetStop). No new phone numbers were added beyond the ones in your original text.
 * 4. OVERLAP: four other pages cover these tools (/responsible-gaming-tools-every-australian-should-use/,
 *    /responsible-gambling-tools-limits-and-self-exclusion-australia/, /self-exclusion-australia-guide/,
 *    /how-to-set-deposit-and-loss-limits-australia/). This page's angle is "your personal plan in writing". Keep it
 *    distinct or merge some with 301 redirects.
 *
 * Layout notes:
 * - The left rail holds the table of contents (and the banner when $showPromo is true). The rail stays in view while you scroll.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$showPromo = false;   // true = show the "Top casino of the month" banner on this page

$a   = gw_article('responsible-gambling-tools-limits-and-self-exclusion');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php if ($showPromo) { gw_promo(); } ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#before">Before you play</a></li>
            <li><a href="#tools">The main tools</a></li>
            <li><a href="#self-exclusion">Self-exclusion in more detail</a></li>
            <li><a href="#signs">Warning signs</a></li>
            <li><a href="#help">Where to find independent help</a></li>
            <li><a href="#choosing">Choosing a casino that supports you</a></li>
            <li><a href="#plan">Your safer gambling plan</a></li>
            <li><a href="#support">If you are worried about someone</a></li>
            <li><a href="#faq">Quick answers</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Gambling should be entertainment that you pay for, in money and time you can afford. Licensed casinos provide tools to help you stay within your own limits. They work best when you set them up before you start playing, not after a bad session. This guide explains what each tool does and where to find independent help.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Set your limits before you start playing,</strong> not after a bad session. Decide a money limit and a time limit.</li>
          <li><strong>Different tools do different jobs:</strong> deposit and loss limits, reminders, time-outs and self-exclusion.</li>
          <li><strong>BetStop covers licensed online and phone wagering,</strong> not pokies in venues and not offshore casino websites.</li>
          <li><strong>Free, confidential help is available,</strong> from Gambling Help Online on 1800 858 858, 24 hours a day.</li>
        </ul>
      </div>

      <h2 id="before">Before you play</h2>
      <figure class="shot"><?= gw_img('articles/sg-before', 'Limit sliders beside the title Before You Play', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
        <ul class="checks">
          <li>Decide how much you can afford to lose, treating it as the cost of entertainment.</li>
          <li>Never gamble with money needed for rent, bills, food or debts.</li>
          <li>Do not gamble to make money, to recover losses or to escape stress.</li>
          <li>Decide a time limit as well as a money limit.</li>
        </ul>
      </div>

      <h2 id="tools">The main tools</h2>
      <figure class="shot"><?= gw_img('articles/sg-tools', 'Casino table beside the title The Main Safer Tools', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="table-wrap">
      <table class="data">
      <caption>Common safer gambling tools and what they do</caption>
      <thead><tr><th scope="col">Tool</th><th scope="col">What it does</th><th scope="col">Good to know</th></tr></thead>
      <tbody>
      <tr><th scope="row">Deposit limit</th><td>Caps how much you can deposit per day, week or month</td><td>Lowering a limit usually takes effect immediately, while raising one is often delayed</td></tr>
      <tr><th scope="row">Loss limit</th><td>Caps your net losses over a period</td><td>Useful for avoiding chasing losses</td></tr>
      <tr><th scope="row">Wager limit</th><td>Caps the total you can stake in a period</td><td>Not offered by every operator</td></tr>
      <tr><th scope="row">Session time limit</th><td>Ends or warns you when a set time has passed</td><td>Pair with a money limit</td></tr>
      <tr><th scope="row">Reality check</th><td>Pop-up reminders showing how long you have played</td><td>Choose a short interval and do not dismiss it automatically</td></tr>
      <tr><th scope="row">Time-out or cool-off</th><td>Blocks your account for a short, fixed period</td><td>Typically from 24 hours to several weeks</td></tr>
      <tr><th scope="row">Self-exclusion</th><td>Blocks your account for a long period, often six months or more</td><td>Usually cannot be reversed early</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Where each tool applies</h3>
      <p>A tool only works where it is set. A limit on one account does nothing on another, so it helps to know which tool covers which situation.</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Tool</th><th scope="col">Where it applies</th><th scope="col">What it does not cover</th></tr></thead>
      <tbody>
      <tr><th scope="row">Deposit, loss and time limits</th><td>The account where you set them</td><td>Any other account or site</td></tr>
      <tr><th scope="row">BetStop</th><td>Licensed online and phone wagering providers</td><td>Pokies in venues, and offshore casino websites</td></tr>
      <tr><th scope="row">Venue exclusion</th><td>The venue, under its state or territory program</td><td>Online accounts</td></tr>
      <tr><th scope="row">A bank gambling block</th><td>Gambling transactions on the accounts you ask your bank to block</td><td>Accounts at other banks, and other ways of paying</td></tr>
      <tr><th scope="row">Website-blocking software</th><td>The devices it is installed on</td><td>Devices without it</td></tr>
      </tbody>
      </table>
      </div>

      <?php if ($showPromo): ?><div class="story-promo-m"><?php gw_promo(); ?></div><?php endif; ?>

      <h2 id="self-exclusion">Self-exclusion in more detail</h2>
      <figure class="shot"><?= gw_img('articles/sg-self', 'Shield with a tick beside the title Excluding Yourself', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Self-exclusion is a formal agreement to stay away from gambling for a fixed period. In Australia, <strong>BetStop</strong> (<a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>) is the national self-exclusion register for licensed online and phone wagering providers. Register once and all licensed wagering operators must close your accounts and stop sending you marketing. You can choose to exclude for a period or permanently.</p>
      <p>BetStop does not cover pokies in venues, which have their own state and territory venue exclusion programs, and it does not cover offshore casino websites. Some people also use website-blocking software, and many Australian banks offer gambling transaction blocks on request.</p>
      <p class="see-also">Step by step: <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a>.</p>

      <h2 id="signs">Warning signs</h2>
      <figure class="shot"><?= gw_img('articles/sg-signs', 'Document with a magnifying glass beside the title Warning Signs', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Consider taking a break and getting support if you notice that you:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Spend more money or time than you planned, often.</li>
          <li>Chase losses by increasing bets or depositing again.</li>
          <li>Borrow money, sell belongings or hide your gambling.</li>
          <li>Feel anxious, irritable or low when you are not gambling.</li>
          <li>Neglect work, family or other responsibilities.</li>
        </ul>
      </div>
      <p>Noticing one or more of these is a reason to talk to someone, not a reason to be hard on yourself. Limits and time-outs help you stay in control, but they are not treatment. If several of these sound familiar, free and confidential counselling is available, and you do not need to be sure that you have a problem to call.</p>

      <h2 id="help">Where to find independent help</h2>
      <figure class="shot"><?= gw_img('articles/sg-help', 'Smartphone beside the title Finding Free Help', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>These services are free and confidential. Please verify contact details on each organisation's website, because they can change.</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Gambling Help Online:</strong> <a href="tel:1800858858">1800 858 858</a>, 24 hours a day, plus online chat and counselling at gamblinghelponline.org.au.</li>
          <li><strong>BetStop:</strong> <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, to exclude yourself from licensed online wagering.</li>
          <li><strong>Lifeline:</strong> <a href="tel:131114">13 11 14</a> for crisis support.</li>
          <li>In an emergency, call 000.</li>
        </ul>
      </div>
      <p class="see-also">More free help options are listed in <a href="/responsible-gaming-tools-every-australian-should-use/">responsible gaming tools every Australian should use</a>.</p>

      <h2 id="choosing">Choosing a casino that supports you</h2>
      <p>A good operator makes these tools easy to find, applies them immediately and does not push promotions at players who have asked for a break. Check the account settings before you register, as we recommend in <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a>. Our <a href="/responsible-gambling/">responsible gambling page</a> sets out the standards we hold ourselves to. If you are 18 or over and gambling feels out of control, please talk to someone today.</p>

      <h2 id="plan">Your safer gambling plan, in writing</h2>
      <figure class="shot"><?= gw_img('articles/sg-plan', 'Checklist card beside the title Your Written Plan', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A plan is easier to keep when it is written down while you are calm. Fill in each line with numbers that reflect what you can afford, then set the matching tools in your account.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>A five-line safer gambling plan</caption>
      <thead><tr><th scope="col">Plan line</th><th scope="col">Example wording</th><th scope="col">Matching tool</th></tr></thead>
      <tbody>
      <tr><th scope="row">Money limit</th><td>I will deposit no more than A$__ a week</td><td>Deposit limit</td></tr>
      <tr><th scope="row">Time limit</th><td>I will stop after __ minutes</td><td>Session time limit</td></tr>
      <tr><th scope="row">Reminder</th><td>I want a reminder every __ minutes</td><td>Reality check</td></tr>
      <tr><th scope="row">Stop rule</th><td>If I reach my limit, I stop for the day</td><td>Loss limit or time-out</td></tr>
      <tr><th scope="row">Warning rule</th><td>If I borrow, hide my gambling or chase losses, I take a break and talk to someone</td><td>Time-out or self-exclusion</td></tr>
      </tbody>
      </table>
      </div>
      <p>Here is how hypothetical figures add up. They are examples only, and your numbers should reflect what you can afford to lose.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">A hypothetical weekly limit</p>
          <p class="ex-sum">A$30 × 4 weeks</p>
          <p class="ex-big">A$120</p><p class="ex-lbl">the most deposited in four weeks</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">A hypothetical time limit</p>
          <p class="ex-sum">45 minutes × 3 sessions</p>
          <p class="ex-big">2 h 15 min</p><p class="ex-lbl">the most time in a week</p>
        </div>
      </div>
      <h3>On a hard day</h3>
      <p>The moments when a limit feels least convenient are the ones it is for. If you feel pulled to deposit more than you planned, you can:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Put time between the urge and the deposit before you decide anything.</li>
          <li>Start a time-out so the decision is made for you.</li>
          <li>Tell someone you trust how you are feeling.</li>
          <li>Call Gambling Help Online on <a href="tel:1800858858">1800 858 858</a>, which is free, confidential and open 24 hours a day.</li>
        </ul>
      </div>

      <h2 id="support">If you are worried about someone else</h2>
      <figure class="shot"><?= gw_img('articles/sg-support', 'Dotted circles beside the title Helping Someone', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>It can be hard to raise someone else's gambling. A calm start helps more than a confrontation.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Choose a calm, private moment, not straight after a loss or an argument.</li>
          <li>Say what you have noticed, such as the borrowing or the time away, without blaming.</li>
          <li>Listen to their side before you offer solutions.</li>
          <li>Tell them about the free services above, and that they can call without being sure they have a problem.</li>
          <li>Think carefully before paying off gambling debts or lending money, and look after your own wellbeing too.</li>
        </ol>
      </div>
      <p>Gambling Help Online's website can tell you what it offers for family and friends.</p>

      <h2 id="faq">Quick answers</h2>
      <div class="faq">
        <details>
          <summary>Do safer gambling tools stop me gambling?</summary>
          <p>No tool can stop you on its own. They help you stay within limits you set, and they work best when you set them before you start playing.</p>
        </details>
        <details>
          <summary>How quickly do limit changes take effect?</summary>
          <p>Lowering a limit usually takes effect immediately, while raising one is often delayed. That delay is deliberate, to give you time to think.</p>
        </details>
        <details>
          <summary>What is the difference between a time-out and self-exclusion?</summary>
          <p>A time-out blocks your account for a short, fixed period, typically from 24 hours to several weeks. Self-exclusion blocks it for a long period, often six months or more, and usually cannot be reversed early.</p>
        </details>
        <details>
          <summary>Does BetStop cover offshore casinos or pokies venues?</summary>
          <p>No. BetStop is the national self-exclusion register for licensed online and phone wagering providers. Pokies in venues have their own state and territory venue exclusion programs, and BetStop does not cover offshore casino websites.</p>
        </details>
        <details>
          <summary>Where can I get help right now?</summary>
          <p>Gambling Help Online offers free, confidential support on <a href="tel:1800858858">1800 858 858</a>, 24 hours a day, and online chat at gamblinghelponline.org.au. Lifeline is on <a href="tel:131114">13 11 14</a> for crisis support. In an emergency, call 000.</p>
        </details>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">limits and self-exclusion in Australia</a>.</p>

      <?php gw_topic_links($a['slug']); ?>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
