<?php
/**
 * Article: Responsible Gambling Self-Exclusion Australia Guide
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. The "Top casino of the month" banner is OFF on this page because it is written for people who are trying to
 *    stop gambling. To turn it on, change `$showPromo = false;` below to `true` (the phone copy follows the same switch).
 * 2. These supplied details could not be verified when the page was built, so check them on betstop.gov.au and the
 *    state regulators' sites before publishing: BetStop phone 1800 238 786 and "about five minutes"; up to five support
 *    people and what BetStop tells them; the reminder BetStop sends before an exclusion ends; the lifetime-exclusion
 *    removal rules; the accepted ID documents; and the state table (NSW GambleAware, VIC, QLD, WA, SA "barring",
 *    Tasmania's exclusion scheme, ACT, NT). The text names two blocking products (Gamban, BetBlocker): re-check them.
 *
 * Layout notes:
 * - The left rail holds the table of contents (and the banner when $showPromo is true). The rail stays in view while
 *   you scroll. On phones the rail banner is hidden and, if enabled, shown inside the article instead.
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$showPromo = false;   // true = show the "Top casino of the month" banner on this page

$a   = gw_article('self-exclusion-australia-guide');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php if ($showPromo) { gw_promo(); } ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#which">Which scheme covers what</a></li>
            <li><a href="#betstop">BetStop explained</a></li>
            <li><a href="#how">How to register with BetStop</a></li>
            <li><a href="#venues">Pubs, clubs, casinos and TAB</a></li>
            <li><a href="#gaps">Closing the gaps</a></li>
            <li><a href="#after">After you sign up</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>No single scheme covers every kind of gambling.</strong> Most people need more than one sign-up.</li>
          <li><strong>BetStop is free</strong> and covers licensed Australian online and phone wagering. It does not cover venues or offshore casinos.</li>
          <li><strong>Venues run their own programs,</strong> by state, territory or venue.</li>
          <li><strong>Offshore sites need extra layers:</strong> a bank gambling block and blocking software.</li>
        </ul>
      </div>

      <h2 id="which">Self-exclusion Australia: which scheme covers which type of gambling</h2>
      <figure class="shot"><?= gw_img('articles/sx-which', 'Shield with a tick beside the title Which Scheme Covers What', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Self-exclusion is a voluntary ban. You ask to be blocked from gambling, and the provider or venue is then expected to turn you away. The catch with self-exclusion in Australia is that no single scheme covers every form of gambling. Most people need more than one sign-up.</p>
      <h3>The short answer</h3>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Online and phone betting</p>
          <h3>BetStop</h3>
          <p>Online and phone betting with Australian-licensed bookmakers: register once with BetStop, the national register, at betstop.gov.au.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Venues</p>
          <h3>State, territory or venue program</h3>
          <p>Pokies in pubs and clubs, casinos and TAB outlets: use your state or territory program, or the venue's own program.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Everything else</p>
          <h3>Bank and device blocks</h3>
          <p>Everything else, including offshore casino and pokies sites: no Australian register reaches these, so you need extra blocks through your bank and on your devices.</p>
        </article>
      </div>
      <p>This gambling self-exclusion guide promotes no operator and links only to official sources. Gambling in Australia is for adults 18 and over. If things feel urgent right now, Gambling Help Online offers free, confidential counselling around the clock on <a href="tel:1800858858">1800 858 858</a> or by chat at gamblinghelponline.org.au.</p>
      <h3>Quick-match table: how you gamble and where to exclude</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">How you gamble</th><th scope="col">Exclusion you need</th><th scope="col">Where to sign up</th></tr></thead>
      <tbody>
      <tr><th scope="row">Betting apps, websites or phone betting on sport and racing</th><td>BetStop (national)</td><td><a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> or <a href="tel:1800238786">1800 238 786</a></td></tr>
      <tr><th scope="row">Pokies at pubs and clubs</th><td>State or territory venue program</td><td>See the state table below</td></tr>
      <tr><th scope="row">Casino gaming floor</th><td>The casino's own program or a state scheme</td><td>The casino's responsible gambling staff, or your state regulator</td></tr>
      <tr><th scope="row">Cash bets at a TAB outlet or racecourse</th><td>Operator or state retail exclusion</td><td>The operator, or your state regulator</td></tr>
      <tr><th scope="row">Online casino or pokies sites</th><td>No Australian register applies</td><td>Close accounts, add a bank block, install blocking software</td></tr>
      <tr><th scope="row">More than one of the above</th><td>Every scheme that applies</td><td>Start with BetStop, then work down the list</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="betstop">BetStop explained: what the national register does and doesn't cover</h2>
      <figure class="shot"><?= gw_img('articles/sx-betstop', 'Document with a magnifying glass beside the title BetStop Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>BetStop is the National Self-Exclusion Register. It has been running since August 2023, was set up under the Interactive Gambling Act 2001 and is overseen by the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (the ACMA)</a>, with a contracted company running it day to day. It is free to use.</p>
      <p>One registration covers every Australian-licensed online and phone wagering provider: the apps, websites and phone services that take bets on sport and racing. You choose an exclusion period from three months up to a lifetime. You can lengthen it at any time. You can never shorten it.</p>
      <p>The block is all-or-nothing. You can't exclude from some bookmakers and keep an account with another. To check whether a particular brand is covered, use the ACMA's current register of licensed providers.</p>
      <h3>What providers must do once you register</h3>
      <p>Once your name is on the register, licensed providers must:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>close any betting accounts you hold with them</li>
          <li>refund any credit balance, once outstanding bets are settled</li>
          <li>refuse to take bets from you</li>
          <li>not let you open a new account</li>
          <li>stop sending you marketing</li>
        </ul>
      </div>
      <p>Providers check their customers against the register, so matching depends on the personal details held on both sides. An account opened under different details may not be picked up. BetStop is a strong barrier, but it isn't a guarantee.</p>
      <h3>What sits outside BetStop</h3>
      <div class="mini3">
        <div><h3>Venues</h3><p>Pokies in pubs and clubs, casino gaming floors and cash bets at a TAB outlet or racecourse are not covered.</p></div>
        <div><h3>Online casino and pokies sites</h3><p>Anyone using these, or other illegally provided services, gets no protection from the register.</p></div>
        <div><h3>State, territory and single-operator schemes</h3><p>No data flows between BetStop and these programs, so separate sign-ups are unavoidable.</p></div>
      </div>
      <p>Other products, such as lotteries and keno, sit under their own rules. Check with the provider or your state regulator.</p>
      <p>On the legal position: online sports and race betting through licensed providers is regulated in Australia. Online casino and pokies services cannot lawfully be offered to people in Australia under the Interactive Gambling Act 2001. The ACMA has the final word, and its BetStop page sets out the current rules.</p>

      <h2 id="how">How to self-exclude from gambling with BetStop, step by step</h2>
      <figure class="shot"><?= gw_img('articles/sx-steps', 'Checklist card beside the title Sign Up to BetStop Step by Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What to have ready</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>A mobile phone and access to your email</li>
          <li>One identity document: a Medicare card, an Australian passport or a state or territory driver licence</li>
        </ul>
      </div>
      <p>No such document? Call BetStop on <a href="tel:1800238786">1800 238 786</a> and ask about an alternative identity check. BetStop's own estimate for the online form is about five minutes.</p>
      <p>Signing up to BetStop takes only a few minutes and covers all licensed Australian online wagering providers.</p>
      <p>The screens may change over time, but the flow is broadly this:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Type betstop.gov.au into your browser yourself, rather than following a link in an ad or message, and choose to register.</li>
          <li>Enter your email address and mobile number, then confirm them with the codes sent to you.</li>
          <li>Enter your personal details exactly as they appear on your ID.</li>
          <li>Verify your identity with your chosen document.</li>
          <li>Choose your exclusion period.</li>
          <li>Nominate support people if you want to (this is optional).</li>
          <li>Review, submit and keep the confirmation message somewhere you can find it.</li>
        </ol>
      </div>
      <p>You don't need to contact each bookmaker afterwards. Account closures and refunds follow from the registration itself. Watch your bank account for refunded balances over the following days, and contact the provider if money you expected doesn't arrive.</p>
      <h3>Choosing your exclusion period</h3>
      <p>A period can be extended but never reduced, so treat this choice as a firm commitment. Some people pick a term they're certain about and extend it later. Others go longer from the start because they know the urge comes back after a few quiet months.</p>
      <p>Unsure? A <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> counsellor can talk it through before you submit. If you're considering a lifetime exclusion, read the conditions on <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> first. Any rules about removing a lifetime exclusion are set there and may change.</p>
      <h3>Nominating a support person</h3>
      <p>You can nominate up to five support people, such as a partner, friend, family member or counsellor. BetStop contacts the people you name about your registration, and the site explains what they are told, so ask them before you add them. A support person can't stop you gambling. But once someone else is in the loop, it's harder to quietly let an exclusion lapse.</p>

      <h2 id="venues">Self-excluding from pubs, clubs, casinos and TAB outlets in your state</h2>
      <figure class="shot"><?= gw_img('articles/sx-venues', 'Casino table with cards beside the title Pubs Clubs Casinos and TAB Outlets', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Venue exclusion is run at state, territory or venue level, and BetStop registration does nothing here. If you play the pokies, visit a casino or bet over the counter, you need this step as well.</p>
      <h3>How venue exclusion usually works</h3>
      <p>The details differ everywhere, but the general pattern is similar:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>You sign an agreement or form, either at the venue, through a gambling counsellor or (in some places) online or by phone.</li>
          <li>You usually supply a photo so staff can recognise you.</li>
          <li>You nominate the venues or gaming areas you want to be kept out of, for a set period.</li>
          <li>Staff are then expected to refuse you entry to those areas or ask you to leave.</li>
        </ol>
      </div>
      <p>What varies:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>minimum periods and forms</li>
          <li>whether you can cover several venues at once</li>
          <li>whether you can sign up without visiting the venue</li>
          <li>what happens if you breach the exclusion</li>
        </ul>
      </div>
      <p>Don't assume a rule from one state applies in another. Confirm each point with the official source below.</p>
      <p>If walking into a venue to ask feels too hard, a counsellor through <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> (<a href="tel:1800858858">1800 858 858</a>) can often help arrange it, or tell you who can.</p>
      <h3>State and territory starting points</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">State or territory</th><th scope="col">Official starting point</th><th scope="col">Worth knowing</th></tr></thead>
      <tbody>
      <tr><th scope="row">NSW</th><td>GambleAware NSW (regulator: Liquor & Gaming NSW)</td><td>Ask about multi-venue self-exclusion for pubs and clubs. Casinos are arranged separately.</td></tr>
      <tr><th scope="row">Victoria</th><td>Victorian Gambling and Casino Control Commission</td><td>Venue operators must run a self-exclusion program under the Gambling Regulation Act 2003. Gambler's Help can assist with sign-up.</td></tr>
      <tr><th scope="row">Queensland</th><td>Gambling Help Queensland (regulator: Office of Liquor and Gaming Regulation)</td><td>Ask how to exclude from more than one venue.</td></tr>
      <tr><th scope="row">Western Australia</th><td><a href="https://www.wa.gov.au" rel="noopener">wa.gov.au</a> (search for the Gaming and Wagering Commission)</td><td>Pokies aren't in WA pubs and clubs, so the casino and TAB outlets are the main venue settings.</td></tr>
      <tr><th scope="row">South Australia</th><td>Consumer and Business Services</td><td>SA uses the term "barring". Ask about barring yourself from one or several venues.</td></tr>
      <tr><th scope="row">Tasmania</th><td>Tasmanian Liquor and Gaming Commission</td><td>Ask about the Tasmanian Gambling Exclusion Scheme, including periods and revocation rules.</td></tr>
      <tr><th scope="row">ACT</th><td>ACT Gambling and Racing Commission</td><td>Ask about excluding from several clubs in one application.</td></tr>
      <tr><th scope="row">Northern Territory</th><td><a href="https://www.nt.gov.au" rel="noopener">nt.gov.au</a> (search "self-exclusion")</td><td>Covers venues and the casinos. Confirm forms and periods.</td></tr>
      </tbody>
      </table>
      </div>
      <p>For casinos, you can also go straight to the casino's responsible gambling team. For retail TAB betting, ask the operator how its outlet exclusion works in your state. Some arrangements are operator-run and others sit within the state scheme.</p>

      <h2 id="gaps">Closing the gaps: offshore casino sites, bank blocks and blocking software</h2>
      <figure class="shot"><?= gw_img('articles/sx-gaps', 'Smartphone beside the title Bank Blocks and Blocking Software', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Why offshore sites ignore Australian registers</h3>
      <p>Online casino games and online pokies can't lawfully be offered to people in Australia. The sites that offer them anyway are generally based overseas, hold no Australian licence and don't check BetStop. The ACMA investigates these services and can ask internet providers to block them, but new web addresses keep appearing.</p>
      <p>Some of these sites advertise their own "self-exclusion" or cooling-off tools. Don't rely on them. No Australian regulator stands behind those promises, and you have little recourse if the site ignores your request or withholds your money.</p>
      <p>If you already have accounts, ask in writing for them to be closed permanently and keep a copy. That is one layer of protection. Build the others below. You can also report illegal gambling services to the ACMA.</p>
      <h3>Bank gambling blocks</h3>
      <p>Many Australian banks and card issuers offer some form of gambling block, which declines transactions identified as gambling. Features differ from bank to bank, so call or message yours and ask:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Which payments does the block cover (debit card, credit card, PayID, bank transfers)?</li>
          <li>Does it apply to overseas merchants?</li>
          <li>If I ask to remove it, is there a waiting period?</li>
          <li>Can I also lower my daily transfer and card limits?</li>
        </ul>
      </div>
      <p>A block that covers only card payments still helps. Knowing its limits tells you what else to shut off.</p>
      <h3>Device blockers and marketing opt-outs</h3>
      <p>Blocking software stops gambling sites and apps from loading on your phone, tablet and computer, including sites no register reaches. Gamban and BetBlocker are two widely known examples. Check each provider's own site for current pricing and which devices it supports. Install it on every device you use, not just your phone.</p>
      <p>Then cut the prompts:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Delete betting and casino apps and turn off their notifications.</li>
          <li>Unsubscribe from gambling emails and texts.</li>
          <li>Unfollow tipsters and betting accounts on social media.</li>
          <li>Check the ad settings on your social and search accounts, as some platforms let you limit gambling ads.</li>
        </ul>
      </div>
      <p>None of these layers is unbeatable. Together they add enough friction that an impulse has time to pass.</p>
      <p class="see-also">For the bank steps in more detail, see <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>.</p>

      <h2 id="after">After you sign up: expiry, slip-ups and complaints</h2>
      <figure class="shot"><?= gw_img('articles/sx-after', 'Payment list with a clock beside the title Expiry Slip-ups and Complaints', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What happens when your period ends</h3>
      <p>BetStop exclusions expire automatically. Before your end date, BetStop sends a reminder and offers you the chance to extend. If you do nothing, your name comes off the register.</p>
      <p>Your old accounts stay closed, but nothing then stops you from opening new ones. Decide what you want before the reminder arrives, ideally with a counsellor or one of your support people. Extending before the end date is simpler than registering again after a relapse.</p>
      <p>Venue exclusions don't necessarily work the same way. Some end on a set date and others have their own steps for ending or renewing. Check your paperwork or ask the program that set it up.</p>
      <h3>If a provider still lets you bet or sends marketing</h3>
      <p>Say a licensed online or phone betting provider takes a bet from you, lets you open an account or sends you marketing while you're registered. Complain to the ACMA, and keep evidence: screenshots, dates, account names and the messages themselves.</p>
      <p>If a venue lets you gamble despite an exclusion, raise it with the venue's manager and with your state or territory regulator from the table above.</p>
      <p>A slip doesn't mean the exclusion has failed, or that you have. It usually means one door was still open. Tell someone, add the missing layer, consider extending your period and talk to a counsellor. <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> is free, 24 hours a day, on <a href="tel:1800858858">1800 858 858</a>.</p>

      <h2 id="faq">Self-exclusion FAQ</h2>
      <div class="faq">
        <details>
          <summary>Is BetStop free, and how long does it take?</summary>
          <p>Yes, BetStop is free. Its own estimate for the online form is about five minutes, provided you have a mobile phone, email access and a Medicare card, Australian passport or driver licence. Without those documents, call <a href="tel:1800238786">1800 238 786</a> to arrange another identity check. Current details are at betstop.gov.au.</p>
        </details>
        <details>
          <summary>Can I cancel BetStop early?</summary>
          <p>No. You can't shorten your chosen exclusion period, although you can extend it whenever you like. The minimum term is three months. Lifetime exclusions have their own conditions for removal, set out on betstop.gov.au. Read them there before choosing that option rather than guessing at the process.</p>
        </details>
        <details>
          <summary>Does BetStop block online casinos and pokies sites?</summary>
          <p>No. BetStop only binds Australian-licensed online and phone wagering providers. Online casino and pokies sites can't lawfully be offered to people in Australia and don't check the register, so you get no protection from it there. Use a bank gambling block and blocking software instead, and see the ACMA's site for the current legal position.</p>
        </details>
        <details>
          <summary>Will anyone find out I've self-excluded?</summary>
          <p>The register isn't a public list. Licensed wagering providers check their customers against it, and any support people you nominate are contacted by BetStop. For exactly how your information is stored and used, including any question about credit files, read the privacy information on betstop.gov.au.</p>
        </details>
        <details>
          <summary>Can I self-exclude a family member?</summary>
          <p>Not through BetStop. It's voluntary, so the person has to register themselves. You can sit with them while they do it and be one of their support people. Some state and venue schemes have other options, so ask your state regulator. Gambling Help Online also supports family members on <a href="tel:1800858858">1800 858 858</a>.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: ten minutes that cover the most ground</h2>
      <figure class="shot"><?= gw_img('articles/sx-next', 'Limit sliders beside the title Ten Minutes That Cover the Most', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Start with the first item now. It is the five-minute one. The other two are a phone call or a form.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Register with BetStop at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> or call <a href="tel:1800238786">1800 238 786</a>.</li>
          <li>Contact your state or territory venue program using the table above, and ask about covering more than one venue.</li>
          <li>Call or chat with Gambling Help Online on <a href="tel:1800858858">1800 858 858</a> for help with the rest, including bank blocks and blocking software.</li>
        </ol>
      </div>
      <p>Gambling is for adults 18 and over, and it is never a way to make money. If you do gamble, set limits on time and spending before you start. Self-exclusion is a tool, not a guarantee. It works best when you combine these layers and have someone on your side.</p>
      <p class="see-also">Support in one place: our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/responsible-gaming-tools-every-australian-should-use/">Responsible Gaming Tools Every Australian Should Use</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">Responsible Gambling Tools, Limits &amp; Self-Exclusion Australia</a>, <a href="/how-to-set-deposit-and-loss-limits-australia/">How to Set Deposit &amp; Loss Limits in Australian Casinos</a>.</p>

<?php if ($showPromo): ?>
      <div class="story-promo-m"><?php gw_promo(); ?></div>
<?php endif; ?>
      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
