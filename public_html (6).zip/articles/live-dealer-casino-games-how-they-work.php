<?php
/**
 * Article: Live Dealer Casino Games: How They Work
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. KEYWORD-OVERLAP RISK: this page now targets "how live dealers work", "live casino studio", "live dealer streaming"
 *    and "are live dealers real", which are also the focus of /live-casino-australia-how-real-dealers-work/ (and
 *    overlap /live-dealer-casino-games-explained/). Consider differentiating the three pages or merging two of them
 *    with a 301 redirect.
 * 2. The text names three live-game studios (Evolution, Playtech, Pragmatic Play Live) as supplied. It already says
 *    naming a provider implies nothing about legality in Australia; re-check the names before publishing.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the "single round" section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('live-dealer-casino-games-how-they-work');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#studio">Inside a live casino studio</a></li>
            <li><a href="#round">How a single round works</a></li>
            <li><a href="#streaming">Streaming, delay and data</a></li>
            <li><a href="#real">Are live dealers real?</a></li>
            <li><a href="#fairness">What a real dealer means for fairness</a></li>
            <li><a href="#legal">Is live casino legal in Australia?</a></li>
            <li><a href="#responsible">Responsible gambling</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Before you sit down</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Here's how live dealers work: a real person runs a physical table in front of cameras, recognition technology reads the cards or the wheel, and software handles everything involving money. The dealer deals. The computer takes the bets, works out the results and pays.</p>
      <p>Most explanations skip that split. A live table is neither a fully human casino game piped to your phone nor an animation in disguise. It is a broadcast with a game engine attached.</p>
      <p>This guide follows one round from the dealer's hands to your screen, shows which parts are human and which are code, and gives you checks you can run yourself. It also sets out where live casino sits under Australian law, and that comes first: online casino services, live dealer included, can't legally be offered to people in Australia. This is an explainer for adults (18+), not a list of places to play.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>A real dealer deals; software does the money.</strong> It takes bets, works out results and pays.</li>
          <li><strong>Cameras, scanners and sensors turn each card or spin into data.</strong> A supervisor resolves any error.</li>
          <li><strong>Standard live blackjack, roulette and baccarat don't use an RNG</strong> for the result, but some features in the same lobby do.</li>
          <li><strong>A real dealer doesn't change the odds,</strong> and online casino services can't lawfully be offered to people in Australia.</li>
        </ul>
      </div>

      <h2 id="studio">Inside a Live Casino Studio: Tables, Cameras and the Control Room</h2>
      <figure class="shot"><?= gw_img('articles/ldw-studio', 'Live dealer table with cards and chips beside the title Inside a Live Casino Studio', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A live casino studio is closer to a television set than a gaming floor. Everything is arranged for the camera, not for people standing around the table.</p>
      <h3>The set: real tables, cards and wheels</h3>
      <p>The equipment is physical. Blackjack and baccarat tables have real felt, real decks and a shoe to hold the cards. Roulette tables have a real wheel and ball. Around them sit the broadcast pieces:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>studio lighting and a backdrop</li>
          <li>several cameras for wide shots and close-ups</li>
          <li>a microphone on the dealer</li>
          <li>a monitor facing the dealer, showing the betting timer, prompts and the players' text chat</li>
        </ul>
      </div>
      <p>Cards often have oversized markings so they stay readable on a phone screen.</p>
      <h3>Who else is in the room besides the dealer</h3>
      <p>You see one person, but a table is rarely a solo operation. Titles differ between providers, but the roles generally include:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Studio role</p>
          <h3>Floor supervisor</h3>
          <p>A floor supervisor, who watches the games, steps in when a card is misdealt or a result is disputed, and can pause a round.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Studio role</p>
          <h3>Card and equipment handlers</h3>
          <p>Card and equipment handlers, who shuffle, prepare shoes and swap out decks.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Studio role</p>
          <h3>Broadcast and technical staff</h3>
          <p>Broadcast and technical staff, who monitor video, audio and the link between the table and the game software.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Studio role</p>
          <h3>Chat moderators and support</h3>
          <p>Chat moderators and support, who filter messages and handle player queries.</p>
        </article>
      </div>
      <p>Dealers also rotate. A change of dealer mid-session is normal, because presenting to a camera for hours is tiring work.</p>
      <h3>Purpose-built studio vs a stream from a casino floor</h3>
      <p>Most live tables come from dedicated studios run by specialist providers. Evolution, Playtech and Pragmatic Play Live are examples: each operates studios and supplies the same tables to many different casino sites. So the dealer usually works for the studio provider, not for the website whose logo sits in the corner of your screen.</p>
      <p>A smaller number of tables are streamed from the floor of a land-based casino, with online players betting alongside people physically at the table. The old picture of a webcam pointed at a casino table still exists, but it is now the exception.</p>

      <h2 id="round">How Live Dealers Work During a Single Round</h2>
      <figure class="shot"><?= gw_img('articles/ldw-round', 'Payment list with a clock beside the title One Live Round Step by Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Here is one round, start to finish, using blackjack and roulette as examples. The detail reflects how providers generally describe their systems. The exact setup varies by provider and game.</p>
      <p>Every live round follows the same sequence: bets open, bets close, the dealer deals and results are paid.</p>
      <h3>Step 1: The betting window opens and closes</h3>
      <p>A countdown timer appears. You place chips on a digital layout laid over the video. Those bets go to the provider's server, not to the dealer.</p>
      <p>When the timer reaches zero, the server stops accepting bets. In roulette, the dealer typically spins around this point. In blackjack, cards are dealt once bets close, and each player then gets a shorter decision timer to hit, stand, double or split.</p>
      <h3>Step 2: The dealer produces a physical result</h3>
      <p>In blackjack, the dealer slides a card out of the shoe and places it face up. In roulette, the dealer spins the wheel and launches the ball in the opposite direction.</p>
      <p>This is the human, physical part. In a standard live game the outcome comes from real cards in a real order or a real ball on a real wheel, not from software.</p>
      <h3>Step 3: Cameras and sensors turn it into data</h3>
      <p>The software needs to know what just happened, and it can't rely on a dealer typing in every card. Providers describe a few methods:</p>
      <div class="mini3">
        <div><h3>Card recognition</h3><p>Each card is read as it leaves the shoe or lands on the table, either by a scanner reading a code on the card or by optical character recognition (OCR), software that identifies rank and suit from the camera image.</p></div>
        <div><h3>Wheel sensors</h3><p>Sensors built into the roulette wheel detect which pocket the ball has settled in.</p></div>
        <div><h3>Table control hardware</h3><p>A unit at each table ties the video feed to the game data, so the picture and the result stay matched.</p></div>
      </div>
      <p>If a read fails or a card is exposed by mistake, the round is paused and a supervisor resolves it under the game's published rules.</p>
      <h3>Step 4: Software settles every bet</h3>
      <p>Once the result is recorded, the game engine compares it with every bet from every player at once. If you had a $10 chip on red and the ball lands on red, your balance updates according to the paytable. Nobody in the studio does anything to make that happen.</p>
      <p>The dealer never handles your money. They cannot see your balance, change your bet or adjust a payout. Their job is to run the game correctly, keep the pace and talk to the table.</p>
      <p class="see-also">For the rules and house edge of each game, see <a href="/live-dealer-casino-games-explained/">live dealer casino games explained</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="streaming">Live Dealer Streaming: Delay, Data Use and Your NBN Connection</h2>
      <figure class="shot"><?= gw_img('articles/ldw-streaming', 'Smartphone beside the title Streaming Delay and Data Use', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Live dealer streaming is continuous video, so it behaves like any other stream on your phone. The difference is that a timer is running against it.</p>
      <h3>Why there is a short delay and why bets close early</h3>
      <p>Video has to be captured, compressed, sent across the internet and decoded on your device. Each stage adds a little time, and the total differs between players depending on their connection and where the studio is.</p>
      <p>So the server keeps the official clock, not your screen. Betting closes with a margin so nobody can bet after the outcome is visible. Don't leave your bet to the last second: if the server has already closed the round, a late tap won't register.</p>
      <h3>What happens if your stream drops mid-round</h3>
      <p>Your bet lives on the server, not on your phone. If it was accepted before you dropped out, the round normally carries on without you and is settled as usual. You can check the result in your game history when you reconnect.</p>
      <p>Decision games are trickier. If you are mid-hand in blackjack and can't act before the timer expires, the game applies a default action. Which action depends on that table's rules, so read the disconnection or malfunction section of the game rules before you play, not after.</p>
      <h3>Wi-Fi vs mobile data</h3>
      <p>Most live games use adaptive video quality. The stream drops to a lower resolution when your connection weakens rather than freezing, and many games also let you set the quality manually.</p>
      <div class="vs">
        <div class="vs-col">
          <h3>On home NBN</h3>
          <p>Stuttering is often a Wi-Fi issue rather than the line itself. Move closer to the router, and expect dips when the household is streaming in the evening.</p>
        </div>
        <div class="vs-col">
          <h3>On 4G or 5G</h3>
          <p>Video counts against your data allowance. Don't rely on per-hour figures quoted online. Open your phone's mobile data settings, note the usage for that app or browser, play a short session and check again.</p>
        </div>
      </div>
      <p>Lowering the video quality reduces data use and often makes the stream steadier.</p>
      <p class="see-also">Connection tips are also in <a href="/mobile-casino-gaming-apps-vs-browser-2026/">mobile casino gaming apps vs browser in 2026</a>.</p>

      <h2 id="real">Are Live Dealers Real? What Is Human and What Is Software</h2>
      <figure class="shot"><?= gw_img('articles/ldw-real', 'Document with a magnifying glass beside the title Human Physical or Software', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Are live dealers real? At a genuine live table, yes. The person on screen is dealing real cards or spinning a real wheel at that moment. But not everything in a live casino lobby is human or physical, and the labels are not always obvious.</p>
      <h3>Human, physical or software: a quick table</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Part of the game</th><th scope="col">What it is</th><th scope="col">What that means</th></tr></thead>
      <tbody>
      <tr><th scope="row">Dealer</th><td>Human</td><td>A trained presenter running the table in real time</td></tr>
      <tr><th scope="row">Cards, wheel, dice</th><td>Physical</td><td>Real equipment produces the outcome</td></tr>
      <tr><th scope="row">Reading the result</th><td>Software, with human oversight</td><td>OCR, scanners or sensors capture it and a supervisor handles errors</td></tr>
      <tr><th scope="row">Taking and settling bets</th><td>Software</td><td>The server accepts bets and calculates payouts automatically</td></tr>
      <tr><th scope="row">Bonus multipliers in game-show titles</th><td>Software (RNG)</td><td>Random multipliers are generated by computer and applied to the physical result</td></tr>
      <tr><th scope="row">Auto-roulette</th><td>Physical, no dealer</td><td>A real wheel is spun by an automated mechanism, with no presenter</td></tr>
      <tr><th scope="row">Computer-generated tables</th><td>Software only</td><td>Animated cards or wheel, with the outcome decided by an RNG</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Where random number generators still appear</h3>
      <p>A random number generator (RNG) is software that produces unpredictable outcomes. Standard live blackjack, roulette and baccarat don't use one to decide the result. Three things in the same lobby often do:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Multiplier variants of roulette and baccarat, where randomly chosen numbers or cards carry boosted payouts each round.</li>
          <li>Game-show style titles, which may mix a physical wheel with computer-generated bonus rounds.</li>
          <li>Animated tables, sometimes labelled 'RNG', 'virtual' or 'first person', which sit alongside live ones.</li>
        </ul>
      </div>
      <h3>How to tell a live table from an animated one</h3>
      <p>Look for these signs:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>The dealer responds to chat, such as greeting a player by screen name or answering a question.</li>
          <li>You see small imperfections, like a card being straightened, a pause or a dealer handover.</li>
          <li>There is a running betting timer shared by all players, and often a round ID on screen.</li>
          <li>The game's info panel states how outcomes are determined. If it mentions an RNG for the main result, it is not a live-dealt game.</li>
        </ul>
      </div>

      <h2 id="fairness">What a Real Dealer Does and Doesn't Mean for Fairness</h2>
      <figure class="shot"><?= gw_img('articles/ldw-fairness', 'Shield with a tick beside the title What a Real Dealer Means for Fairness', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Watching a human deal lets you see the process. It does not change the odds.</p>
      <h3>The house edge is still built into the rules</h3>
      <p>Every casino game has a mathematical advantage for the house, and it comes from the rules, not from who is dealing. In roulette it comes from the green zero pocket. In blackjack it comes mainly from the fact that you act first and can bust before the dealer draws.</p>
      <p>A real dealer doesn't make wins more likely. No dealer is 'hot', 'cold' or 'due'. Side bets and multiplier features can change how the returns are distributed, so check the figures listed for each bet rather than assuming they match the main game. Over time, the expected result of any casino game is a loss for the player.</p>
      <p>Be wary of blanket claims that live games are 'not rigged'. Fairness depends on the operator's licence and on independent testing, and both are things you can check rather than take on trust.</p>
      <h3>Checks you can run yourself</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Open the info panel.</strong> Look for an 'i', '?' or menu icon inside the game. It should show the full rules, payouts, the theoretical return to player (RTP) for each bet type and the disconnection policy.</li>
          <li><strong>Find the testing certificate.</strong> Reputable games name an independent testing laboratory and link to a certificate. A logo alone proves nothing, so follow the link and confirm it on the lab's own website where you can.</li>
          <li><strong>Check the licence details.</strong> A licence number and regulator are usually listed in the site footer. Look the number up on that regulator's public register. An overseas licence does not make a service legal to offer in Australia.</li>
          <li><strong>Watch the stream cues.</strong> Use the list in the previous section to confirm the table is actually live.</li>
        </ol>
      </div>
      <p>If you can't find the rules, the RTP or a certificate, you have no basis for judging the game's fairness.</p>

      <h2 id="legal">Is Live Casino Legal in Australia?</h2>
      <figure class="shot"><?= gw_img('articles/ldw-legal', 'Dotted circles beside the title Live Play and the Law in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>What follows is general information, not legal advice.</p>
      <h3>What the Interactive Gambling Act covers</h3>
      <p>The Interactive Gambling Act 2001 prohibits providers from offering online casino services to people in Australia. That covers online pokies, blackjack and roulette, live dealer versions included. Putting a human dealer on a stream does not change the category.</p>
      <p>The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces the Act. It investigates illegal services and can have illegal sites blocked by Australian internet providers.</p>
      <p>A site that accepts Australian sign-ups, takes PayID or card deposits, shows balances in AUD or calls itself 'Aussie-friendly' is not licensed here because of any of that. The Act's prohibitions are generally described as directed at operators rather than players, but that is not a green light. If you use an offshore site, Australian consumer protections and dispute options may not apply if something goes wrong.</p>
      <p>The Act is amended from time to time, including its advertising and enforcement provisions. For the current position and the final word, go to acma.gov.au.</p>
      <h3>Where dealer-run table games are licensed</h3>
      <p>Land-based casinos in Australia are licensed and supervised by state and territory regulators. They are the regulated setting for dealer-run blackjack, roulette and baccarat in this country.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="responsible">Responsible gambling: 18+, limits and support</h2>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over. Nothing in this article makes winning more likely, and no system does.</p>
      <ul class="checks">
        <li>Decide on a money limit and a time limit before you start, and stop when you reach either.</li>
        <li>Never chase losses or gamble with money you need for bills.</li>
        <li>Free, confidential support is available 24/7 from Gambling Help Online on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</li>
      </ul>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the national self-exclusion register, covers licensed Australian wagering services. It does not block offshore casino sites.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Live Dealer FAQ</h2>
      <div class="faq">
        <details>
          <summary>Can live dealers see or hear me?</summary>
          <p>No. The video and audio run one way, from the studio to you. Dealers see screen names and typed chat messages on a monitor, usually after moderation, which is why they don't reply to everything and sometimes answer a few seconds late.</p>
        </details>
        <details>
          <summary>Are live dealer games pre-recorded?</summary>
          <p>A genuine live table is broadcast as it happens, which is why the dealer can respond to chat and everyone shares one betting timer. If a game shows a presenter but nobody ever reacts to the table, check the info panel. It may be an RNG game with recorded or animated footage, and it should be labelled as such.</p>
        </details>
        <details>
          <summary>Do live dealer games use a random number generator?</summary>
          <p>Not for the main result of standard live blackjack, roulette or baccarat, where physical cards and wheels decide the outcome. RNGs drive added features such as random multipliers and bonus rounds, and the fully animated tables that often share a lobby with live ones. The game rules should say which applies.</p>
        </details>
        <details>
          <summary>Are the dealers based in Australia?</summary>
          <p>Don't assume so. Studio providers operate in various countries and list their locations on their own websites, so check there. A dealer's accent or a table's name tells you nothing reliable. In Australia, the regulated setting for dealers is a licensed land-based casino.</p>
        </details>
        <details>
          <summary>What happens to my bet if my connection drops?</summary>
          <p>If the server accepted your bet before you disconnected, it normally stands and is settled on the real result. If the bet was never confirmed, it generally was not placed. In games with decisions, a default action applies when your timer expires. The exact rule is in the game's info panel, and your bet history shows what happened.</p>
        </details>
      </div>

      <h2 id="next-step">Before You Sit Down: Three Things to Check</h2>
      <figure class="shot"><?= gw_img('articles/ldw-next', 'Limit sliders beside the title Before You Sit Down Three Checks', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Knowing how the technology works is only useful if it changes what you do. Before joining any dealer-run table, online or in a venue, do these three things in order:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Read ACMA's guidance.</strong> Spend five minutes at <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> on illegal online gambling, so you know what can and can't be offered to people in Australia and what protection you would or wouldn't have.</li>
          <li><strong>Open the info panel.</strong> Find the rules, the RTP for the bets you plan to make, the disconnection policy and the testing certificate. If any of them is missing, treat that as your answer.</li>
          <li><strong>Set two limits.</strong> Pick a dollar amount you can afford to lose and a finish time, and put the finish time in your phone as an alarm.</li>
        </ol>
      </div>
      <p>A real dealer makes the game visible. It doesn't make it safer, cheaper or more winnable. Those depend on the rules, the regulator and the limits you set yourself.</p>
      <p><strong>Related reading:</strong> <a href="/live-dealer-casino-games-explained/">Live Dealer Casino Games Explained</a>, <a href="/live-casino-australia-how-real-dealers-work/">Live Casino Australia – How Real Dealers Actually Work</a>, <a href="/live-casinos-australia-what-to-check/">Top 10 Live Casinos Australia for Real Dealers: 10 Things to Check</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
