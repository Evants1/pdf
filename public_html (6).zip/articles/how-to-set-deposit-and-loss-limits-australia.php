<?php
/**
 * Article: How to Set Deposit & Loss Limits in Australian Casinos
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. The "Top casino of the month" banner is OFF on this page because it is a responsible-gambling tools page, like the
 *    other protective pages. To turn it on, change `$showPromo = false;` below to `true` (the phone copy follows the switch).
 * 2. Specific claims supplied with the text that could not be verified when the page was built; check them on the
 *    official sites: Crown Perth's pokies being card-only "since December 2025", the 12 hours a day / 28 hours a week
 *    caps and compulsory three-hourly breaks, and the one-week cooling-off; the Victorian YourPlay description; the
 *    seven-day delay before an increase under the National Consumer Protection Framework; the University of Sydney figure
 *    (15.8 per cent of nearly 40,000 accounts); the regulator names (NSW Independent Casino Commission, Licensing NT and
 *    the others listed); and BetStop's start date (21 August 2023).
 * 3. The "Test it" step tells readers with an offshore account to try a small deposit over the limit. Treat that line the
 *    way you treat the other test-deposit advice on the site (see the notes on the withdrawal pages).
 *
 * Layout notes:
 * - The left rail holds the table of contents (and the banner when $showPromo is true). The rail stays in view while
 *   you scroll. On phones the rail banner is hidden and, if enabled, shown inside the article instead.
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$showPromo = false;   // true = show the "Top casino of the month" banner on this page

$a   = gw_article('how-to-set-deposit-and-loss-limits-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php if ($showPromo) { gw_promo(); } ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#limits">What deposit limits are</a></li>
            <li><a href="#venue">Limits at a land-based casino</a></li>
            <li><a href="#betting">Limits on a betting account</a></li>
            <li><a href="#online">Online casinos: why limits are weaker</a></li>
            <li><a href="#amount">Choosing a number</a></li>
            <li><a href="#backup">Back-up limits outside the casino</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Set one limit today</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>If you searched for deposit limits Australia and got pages about bank transfer caps, this is the gambling version: how to cap what you put in, or lose, at a casino. The setting lives in one of two places. At a venue such as Crown or The Star, limits attach to your membership card and are set at the membership desk or a kiosk. Online, they sit in the account menu, usually under Responsible gambling or Safer gambling.</p>
      <p>How well the limit holds depends on where you play. A licensed Australian betting account has binding limits backed by national rules. A land-based casino follows state rules, and those differ widely. An offshore casino site offers whatever its own terms say, with no Australian rule behind it. This guide covers all three, then shows how to choose a figure and add back-ups at your bank.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>A deposit limit caps money going in; a loss limit caps what you lose.</strong> Set the figure from your spare money, away from the gambling app.</li>
          <li><strong>How well a limit holds depends on where you play:</strong> binding on a licensed betting account, state-dependent at a venue, and only as reliable as the site's terms offshore.</li>
          <li><strong>Lowering a limit is instant; raising one takes time.</strong> That delay is the point.</li>
          <li><strong>Add back-ups outside the casino:</strong> a bank gambling block, a lower transfer limit and, if needed, self-exclusion. Free support is on <a href="tel:1800858858">1800 858 858</a>.</li>
        </ul>
      </div>

      <h2 id="limits">Deposit limits in Australia: what they are and where they apply</h2>
      <figure class="shot"><?= gw_img('articles/dl-what', 'Limit sliders beside the title Deposit and Loss Limits Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A deposit limit is a cap you choose on how much money you can add to a gambling account over a set period: a day, a week or a month. Once you reach it, further deposits are refused until the period resets.</p>
      <h3>Deposit limit vs loss limit vs the casino's own transaction caps</h3>
      <p>Four things share similar names. Only two of them are tools for you.</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Your tool</p>
          <h3>Deposit limit</h3>
          <p>A self-set cap on money going into an account.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Your tool</p>
          <h3>Loss limit</h3>
          <p>A self-set cap on your net losses over a period, meaning what you staked minus what you won back. This is the usual tool on venue cards.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Operator's cap</p>
          <h3>The casino's transaction caps</h3>
          <p>The minimum and maximum deposit per payment, set by the operator for its own reasons. A high maximum deposit is not a safety feature.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Bank's cap</p>
          <h3>Your bank's transfer cap</h3>
          <p>The daily PayID or transfer ceiling your bank applies to all payments. It can be a useful backstop (covered below), but it is not a gambling limit.</p>
        </article>
      </div>
      <h3>Three settings, three rule sets: venues, licensed betting accounts, offshore casino sites</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Where you play</th><th scope="col">Who sets the limit</th><th scope="col">Is it binding?</th><th scope="col">How fast changes apply</th><th scope="col">Who regulates</th></tr></thead>
      <tbody>
      <tr><th scope="row">Land-based casino</th><td>You, on a membership or pre-commitment card, within state rules</td><td>Depends on the state and venue</td><td>Varies. At Crown Perth, lowering is instant and raising takes a week</td><td>State or territory regulator</td></tr>
      <tr><th scope="row">Licensed Australian betting account (sports and racing)</th><td>You, in the account settings</td><td>Yes. The operator must enforce it</td><td>Lowering is immediate and raising takes seven days</td><td>State and territory licensing bodies, under the national framework</td></tr>
      <tr><th scope="row">Offshore casino site</th><td>You, if the site offers a tool at all</td><td>Not under any Australian rule</td><td>Whatever the site's terms say</td><td>No Australian licence. ACMA enforces the law against operators</td></tr>
      </tbody>
      </table>
      </div>
      <p>Take-up is low even where the tool is standard. A University of Sydney analysis of nearly 40,000 online betting accounts, now several years old, found that 15.8 per cent had used a deposit limit. That figure concerns wagering accounts, not casino play.</p>

      <h2 id="venue">How to set gambling limits at a land-based casino</h2>
      <figure class="shot"><?= gw_img('articles/dl-venue', 'Casino table with cards beside the title Limits at a Land-Based Casino', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Venue limits run through carded play. You insert or tap a membership card, the system tracks your time and spend, and play stops or pauses when you reach a limit. Whether a card is compulsory depends on the state.</p>
      <p>Setting your limit before you start playing makes it easier to stick to.</p>
      <h3>Carded play and pre-commitment: YourPlay in Victoria, Crown Perth's card</h3>
      <p>Crown Perth is the clearest example. Pokies there have been card-only since December 2025, and each membership card carries time and loss limits. Play is capped at 12 hours a day and 28 hours a week, with compulsory breaks every three hours on top. Lowering a limit takes effect straight away. Raising one comes with a week's cooling-off. We haven't quoted dollar loss caps because they can change. Ask at the desk or check the WA Government's page for the current figures.</p>
      <p>In Victoria, YourPlay is the state pre-commitment scheme. You register a card, set time and money limits, and track your pokies play against them. The rules on where a card is compulsory and how much can be loaded onto a machine have been changing. Check with the Victorian Gambling and Casino Control Commission (VGCCC) before relying on any date or dollar figure, including for Crown Melbourne.</p>
      <h3>What to ask at the membership desk</h3>
      <p>Bring photo ID and set the limit before your first session, not after a loss. Ask:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Can I set a daily or weekly loss limit and a time limit on this card?</li>
          <li>When I hit the limit, does the machine stop, or does it only show a message?</li>
          <li>Does the limit cover table games, or only pokies?</li>
          <li>How do I lower it, and how long before an increase takes effect?</li>
          <li>Is there a default limit if I don't choose one?</li>
          <li>Can I get a statement of my play?</li>
        </ol>
      </div>
      <h3>Rules differ by state: where to check</h3>
      <p>We haven't verified casino limit rules beyond the examples above, so don't assume limits are mandatory at your venue. Check with the venue and your regulator:</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>NSW:</strong> NSW Independent Casino Commission and Liquor & Gaming NSW</li>
          <li><strong>Queensland:</strong> Office of Liquor and Gaming Regulation</li>
          <li><strong>South Australia:</strong> Consumer and Business Services</li>
          <li><strong>Tasmania:</strong> Tasmanian Liquor and Gaming Commission</li>
          <li><strong>ACT:</strong> ACT Gambling and Racing Commission</li>
          <li><strong>Northern Territory:</strong> Licensing NT</li>
          <li><strong>Western Australia:</strong> Gaming and Wagering Commission of Western Australia</li>
          <li><strong>Victoria:</strong> VGCCC</li>
        </ul>
      </div>
      <p>Regulator names and structures change. If one has moved, start from your state government's website.</p>

      <h2 id="betting">Setting a deposit limit on a licensed Australian betting account</h2>
      <figure class="shot"><?= gw_img('articles/dl-betting', 'Smartphone beside the title Limits in a Licensed Account', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>This section covers sports and racing wagering with Australian-licensed bookmakers, not casino games. Under the National Consumer Protection Framework for Online Wagering, every licensed provider must offer a deposit-limit tool. The bookmaker has to put the limit question in front of you when you sign up, and again at each yearly review. Once set, the limit is binding. The operator cannot accept deposits beyond it.</p>
      <h3>Where the setting lives in the app</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Log in and open the account menu, usually a profile icon or your balance.</li>
          <li>Look for Deposit limit, Safer gambling or Responsible gambling.</li>
          <li>Choose the period and the amount. The periods on offer vary by bookmaker.</li>
          <li>Confirm, then screenshot the confirmation screen with the date showing.</li>
          <li>Check that it covers every deposit method you use, including PayID, bank transfer and debit card. Contact support if the app doesn't say.</li>
        </ol>
      </div>
      <p>If you skipped the prompt at sign-up, the tool is still there. Can't find it? Ask support to set the limit for you and confirm in writing.</p>
      <h3>Lowering is instant, raising takes a week</h3>
      <div class="vs">
        <div class="vs-col">
          <h3>Lowering a limit</h3>
          <p>Tightening a limit applies immediately.</p>
        </div>
        <div class="vs-col">
          <h3>Raising a limit</h3>
          <p>Loosening one does not. Seven days pass before any increase takes effect.</p>
        </div>
      </div>
      <p>Tightening a limit applies immediately. Loosening one does not. Seven days pass before any increase takes effect.</p>
      <p>That gap is the point of the design. A request to raise a limit made at 11 pm after a losing run has to survive seven ordinary days before it does anything. That is a long time for an impulse to last.</p>
      <p>Use the yearly prompt as a real review, not a box to click through. Compare the limit with what you deposited over the year, which your activity statements will show. Lower it if it sits well above what you can comfortably afford.</p>

      <h2 id="online">Online casino sites: the legal position and why limits there are weaker</h2>
      <figure class="shot"><?= gw_img('articles/dl-offshore', 'Shield with a tick beside the title Offshore Limits Are Weaker', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act means for players</h3>
      <p>You will not find an Australian-licensed online casino. Under the Interactive Gambling Act 2001, it is an offence for an operator to supply online casino games, such as pokies, roulette and blackjack, to people located in Australia. The law is aimed at operators, not individual players. That does not make the sites lawful or safe to use.</p>
      <p>Any casino site accepting Australian customers is therefore offshore and outside Australian licensing. <a href="https://www.acma.gov.au" rel="noopener">ACMA</a> enforces the Act, and its powers include having internet providers block offending sites. A site, and your balance on it, can become unreachable. You also have no Australian regulator to take a dispute to. For the current legal position, ACMA is the final word.</p>
      <p>This is why limits there are weaker. The Framework rules that make a licensed bookmaker's limit binding do not apply. An offshore casino's tool does whatever the site's terms say, the terms can change, and nobody in Australia checks that the site honours them.</p>
      <h3>If you already have an account: find, set and test the limit</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Find it.</strong> Check the account, profile or cashier menus for labels such as Limits or Responsible gaming. Not every site has a tool. If yours doesn't, ask support in writing whether they can apply one.</li>
          <li><strong>Read the terms.</strong> Look for how increases are handled and whether the limit counts every payment method.</li>
          <li>Set it and screenshot the confirmation with the date visible.</li>
          <li><strong>Test it.</strong> Try to deposit a small amount over the limit. If it goes through, the limit is decoration.</li>
        </ol>
      </div>
      <p>If the tool is missing or fails the test, rely on the bank-level backstops below, or withdraw your balance and close the account.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="amount">Choosing a number: casino spending limits you can stick to</h2>
      <figure class="shot"><?= gw_img('articles/dl-amount', 'Casino coin beside the title Choosing a Limit You Can Keep', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A limit only works if the figure survives a bad night. Work it out away from the gambling app, with your banking app open.</p>
      <h3>Start from spare money, not from wins</h3>
      <p>Take your take-home pay for one pay cycle. Subtract rent or mortgage, bills, groceries, transport, debt repayments and savings. What remains is your discretionary money, and gambling is one entertainment line within it, alongside everything else you do for fun. Treat every dollar deposited as spent. Never build expected wins into the figure.</p>
      <p>Illustrative example only: Sam takes home $2,400 a fortnight. Fixed costs and savings come to $2,050, leaving $350 for everything optional. Sam decides gambling gets no more than $60 of that. The limit is $60 a fortnight, or $30 a week where the tool only offers weekly periods. This is not a recommended amount. Your figure might be $20, or nothing.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Spare money</p>
          <p class="ex-sum">$2,400 − $2,050</p>
          <p class="ex-big">$350</p><p class="ex-lbl">a fortnight, for everything optional</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Sam's gambling limit</p>
          <p class="ex-sum">an illustration only</p>
          <p class="ex-big">$60</p><p class="ex-lbl">a fortnight, or $30 a week</p>
        </div>
      </div>
      <h3>Daily, weekly or monthly: match your pay cycle</h3>
      <p>Pick the period that lines up with when money arrives. If you are paid fortnightly, a weekly limit of half your fortnightly figure works well. A monthly limit can be burnt in the first weekend. A daily limit on its own multiplies quickly: $30 a day is $210 a week.</p>
      <p>Where the tool allows, put a small daily limit inside a weekly one. Add a time limit too. Decide your finish time before you start, then hold yourself to it with the venue card's time limit, an app reminder or a phone alarm.</p>
      <h3>When a loss limit beats a deposit limit</h3>
      <p>At a venue there is usually no account deposit to cap, because money goes straight into the machine or onto the table. If you want loss limits at a casino venue, the card is where they live.</p>
      <p>Online, a loss limit is the better tool when you carry a balance. A deposit limit ignores money already sitting in the account, so an old balance can be lost in a single session without triggering it. A loss limit counts that.</p>
      <p>A deposit limit is simpler, and better at stopping you chasing losses with fresh money from PayID or a debit card. If both are offered, set both. Neither changes the odds or protects winnings. They only cap what you spend.</p>

      <h2 id="backup">Back-up limits outside the casino: bank blocks, PayID caps and BetStop</h2>
      <figure class="shot"><?= gw_img('articles/dl-backup', 'Wallet with payment cards beside the title Back-Up Limits at Your Bank', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A limit inside one account does nothing about a second account elsewhere. Add layers that sit above any single operator.</p>
      <h3>Gambling blocks and lower transfer limits in your banking app</h3>
      <p>Many Australian banks offer some form of gambling block, but the features vary by bank and card type. Check your own:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Open your banking app and go to the card settings or card controls. Look for a gambling block or a merchant-type block.</li>
          <li>If you can't see one, ring the number on the back of your card and ask what is available for your account.</li>
          <li>Ask how long the block takes to remove. A delay makes it more useful.</li>
          <li>Ask whether it covers PayID and bank transfers. Card blocks generally act on card payments identified as gambling, so a transfer may not be caught.</li>
        </ol>
      </div>
      <p>For that reason, look at your daily transfer or PayID limit as well. If your bank lets you lower it, a low cap restricts how much can leave in a day by any route. Ask how long an increase takes before you count on it.</p>
      <h3>BetStop, venue self-exclusion and blocking software</h3>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> has been the national self-exclusion register since 21 August 2023. One free registration excludes you from licensed Australian online and phone wagering providers for a period you choose. It does not cover land-based casinos, pokies in pubs and clubs, or offshore casino sites. The BetStop site sets out the exact scope.</p>
      <p>For venues, self-exclusion is arranged through the casino itself or your state's program. Ask at the venue, or call <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> for help setting it up.</p>
      <p>For offshore sites, the closest equivalent is blocking software such as Gamban or BetBlocker, which blocks access to gambling sites on your phone and computer.</p>
      <p class="see-also">More in <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and <a href="/responsible-gaming-tools-every-australian-should-use/">responsible gaming tools every Australian should use</a>.</p>

      <h2 id="faq">FAQ: deposit and loss limits</h2>
      <div class="faq">
        <details>
          <summary>Are deposit limits mandatory in Australia?</summary>
          <p>The tool is mandatory in one place: licensed online wagering providers must offer it and must ask you about it. Using it is your choice. At venues it depends on the state and the casino. Crown Perth's pokies require a card that carries limits. Offshore casino sites have no Australian obligation to offer anything, and some have no tool at all.</p>
        </details>
        <details>
          <summary>What is the difference between a deposit limit and a loss limit?</summary>
          <p>A deposit limit counts fresh money entering an account. A loss limit counts your net result over the period. The two can diverge. Withdraw a win and deposit again, and the deposit counter still moves even though you are ahead. Play from an existing balance, and only the loss limit notices.</p>
        </details>
        <details>
          <summary>How long does it take to raise a limit once it is set?</summary>
          <p>Seven days on a licensed Australian betting account, under the national framework. Crown Perth's pokies card also applies a week's cooling-off to increases. There is no standard anywhere else: other venues follow their state rules and offshore sites follow their own terms. Ask before you set the limit, and get the answer in writing.</p>
        </details>
        <details>
          <summary>Does BetStop cover online casino sites or land-based casinos?</summary>
          <p>No to both. BetStop covers licensed Australian online and phone wagering only. Offshore casino sites sit outside it. So do land-based casinos, which handle self-exclusion through the venue or a state program. Check the current scope at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> before relying on it for anything other than betting accounts.</p>
        </details>
        <details>
          <summary>Can my bank block gambling transactions?</summary>
          <p>Often, yes, but it depends on your bank and the type of card. Look in your app's card settings, or ring the bank and ask what is blocked, whether debit cards are covered as well as credit cards, and how long the block takes to remove. Ask about PayID and transfers too, because a card block may not touch them.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: set one limit today</h2>
      <figure class="shot"><?= gw_img('articles/dl-next', 'Checklist card beside the title Set One Limit Today', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Set one limit.</strong> Do it wherever you play most: at the membership desk, or in the account menu. Choose a figure from your spare money and screenshot the confirmation.</li>
          <li><strong>Add a bank backstop.</strong> Turn on your bank's gambling block if it has one, or lower your daily transfer limit.</li>
          <li><strong>Put a review date in your calendar.</strong> In three months, compare the limit with what you spent. Lower it if it never came close to stopping you.</li>
        </ol>
      </div>
      <div class="rg-card">
      <p><strong>Responsible gambling:</strong> Gambling is for adults aged 18 and over. Treat it as paid entertainment, not income. No limit, system or strategy guarantees a win. If your gambling is worrying you or someone close to you, call <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or visit <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a> for free, confidential support at any hour. To exclude yourself from licensed online and phone wagering, register at <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>.</p>
      </div>
      <p class="see-also">Support in one place: our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/self-exclusion-australia-guide/">Responsible Gambling Self-Exclusion Australia Guide</a>, <a href="/responsible-gaming-tools-every-australian-should-use/">Responsible Gaming Tools Every Australian Should Use</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">Responsible Gambling Tools, Limits &amp; Self-Exclusion Australia</a>.</p>

<?php if ($showPromo): ?>
      <div class="story-promo-m"><?php gw_promo(); ?></div>
<?php endif; ?>
      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
