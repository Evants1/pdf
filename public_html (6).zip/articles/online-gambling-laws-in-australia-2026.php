<?php
/**
 * Article: Online Gambling Laws in Australia 2026
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTE: this page states agency names and dates as supplied (for example the Northern Territory Racing and
 * Wagering Commission "replaced the Northern Territory Racing Commission in 2024", and the state regulator names).
 * They could not be independently verified when the page was built. Re-check them on the regulators' own sites.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the "what you can bet on" section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('online-gambling-laws-in-australia-2026');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#framework">The Act and the states</a></li>
            <li><a href="#what-bets">What you can bet on online</a></li>
            <li><a href="#reforms">2026 reforms to confirm</a></li>
            <li><a href="#offshore">Offshore sites and risks</a></li>
            <li><a href="#check">Check an operator is licensed</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">Is online gambling legal in Australia? The short answer</h2>
      <figure class="shot"><?= gw_img('articles/law26-short-answer', 'Shield with a tick beside the title Is It Legal Online in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Partly. Under online gambling laws in Australia, you can legally bet online on sport and racing, and buy lottery tickets, through an operator licensed by an Australian state or territory. Online casino games, online pokies, online poker and in-play sports bets placed over the internet cannot be offered to people here.</p>
      <p>So the answer to 'is online gambling legal in Australia' depends on the product and the provider. A licensed bookmaker's app taking your bet on Saturday's footy before the first bounce is lawful. A website offering real-money roulette or pokies is a prohibited service, wherever it is based and however polished its ads look.</p>
      <div class="vs">
        <div class="vs-col">
          <h3>Permitted with a licensed Australian operator</h3>
          <ul>
            <li>Online sports betting before the event starts</li>
            <li>Online betting on horse, harness and greyhound racing</li>
            <li>Online lottery tickets from licensed providers</li>
          </ul>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Cannot be offered to people in Australia</h3>
          <ul>
            <li>Online casino games, pokies and poker</li>
            <li>In-play sports bets online or in an app</li>
            <li>Online instant lotteries (scratchies)</li>
          </ul>
        </div>
      </div>
      <p>Further change is on the agenda in 2026. Reform of gambling advertising and some online products has been debated since a 2023 parliamentary inquiry. We could not confirm from primary sources that a reform Act has passed or when any new rules start. This guide therefore sets out the law that can be verified and shows you how to check whether anything newer has commenced.</p>
      <p>This is general information for adult punters (18+), not legal advice. State and territory rules differ, and the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> and your local regulator have the final word.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Partly legal:</strong> sport and racing betting and lotteries through a state or territory licensed operator.</li>
          <li><strong>Online casinos, pokies, poker and in-play online betting</strong> cannot be offered to people in Australia.</li>
          <li><strong>2026 reform dates are unconfirmed here.</strong> Verify any change in the Act's commencement table.</li>
          <li><strong>Offshore sites are unprotected</strong> even though the offences target providers, not players.</li>
        </ul>
      </div>


      <h2 id="framework">How online gambling laws in Australia work: the Interactive Gambling Act and the states</h2>
      <figure class="shot"><?= gw_img('articles/law26-framework', 'Dotted circles beside the title How the Law Is Layered', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Two layers of law apply. A federal Act decides which online services can be offered at all. State and territory law decides who gets a licence and on what conditions.</p>
      <h3>What the Interactive Gambling Act 2001 covers</h3>
      <p>The Interactive Gambling Act 2001 is the main federal law. Its offences and penalties are aimed at the businesses that provide or advertise gambling services, not at individual customers. In broad terms it prohibits:</p>
      <div class="vs-col vs-col--bad">
        <h3>In broad terms, the Act prohibits</h3>
        <ul>
        <li>providing online casino-style games, pokies and poker to customers in Australia</li>
        <li>providing online in-play betting on sport</li>
        <li>providing wagering services to Australians without an Australian state or territory licence</li>
        <li>offering credit to online wagering customers</li>
        <li>advertising prohibited or unlicensed services</li>
        </ul>
      </div>
      <p>The Act has been amended several times. Changes in 2017 strengthened enforcement and closed loopholes around in-play betting. Since 2019 ACMA has also asked internet service providers to block illegal gambling sites, and a credit card ban for online wagering took effect in June 2024.</p>
      <h3>ACMA's role as federal regulator</h3>
      <p>ACMA enforces the Act. It investigates complaints, issues warnings and infringement notices, and can pursue civil penalties. It also publishes a register of licensed wagering providers and oversees BetStop, the national self-exclusion register. ACMA publishes its current enforcement figures on its own site.</p>
      <h3>Where state and territory licensing fits</h3>
      <p>There is no single national gambling licence. Every lawful online bookmaker holds a licence from a state or territory. Lotteries, TAB retail outlets, casinos and pokies in pubs and clubs are also licensed at that level.</p>
      <p>This matters when something goes wrong. A dispute with a licensed bookmaker is usually handled by the regulator that issued its licence, which may not be the one in your state. Many well-known corporate bookmakers are licensed in the Northern Territory, where the regulator is the Northern Territory Racing and Wagering Commission. It replaced the Northern Territory Racing Commission in 2024. The footer of an operator's website names its licensing body.</p>
      <p>The main state and territory regulators are:</p>
      <div class="table-wrap">
      <table class="data">
      <caption>The main state and territory gambling regulators</caption>
      <thead><tr><th scope="col">Jurisdiction</th><th scope="col">Regulator</th></tr></thead>
      <tbody>
      <tr><th scope="row">NSW</th><td>Liquor & Gaming NSW</td></tr>
      <tr><th scope="row">Victoria</th><td>Victorian Gambling and Casino Control Commission</td></tr>
      <tr><th scope="row">Queensland</th><td>Office of Liquor and Gaming Regulation</td></tr>
      <tr><th scope="row">Western Australia</th><td>Gaming and Wagering Commission of Western Australia</td></tr>
      <tr><th scope="row">South Australia</th><td>Consumer and Business Services</td></tr>
      <tr><th scope="row">Tasmania</th><td>Tasmanian Liquor and Gaming Commission</td></tr>
      <tr><th scope="row">ACT</th><td>ACT Gambling and Racing Commission</td></tr>
      <tr><th scope="row">Northern Territory</th><td>Northern Territory Racing and Wagering Commission (wagering)</td></tr>
      </tbody>
      </table>
      </div>
      <p>Agency names and structures change, so confirm the current body on the relevant government website.</p>
      <p class="see-also">For who regulates what, see <a href="/understanding-australian-online-gambling-regulations/">understanding Australian online gambling regulations</a>.</p>

      <h2 id="what-bets">What you can and can't bet on online</h2>
      <figure class="shot"><?= gw_img('articles/law26-what-bets', 'Payment list with a clock beside the title What You Can Bet On Online', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The table below sets out the federal position. Your state or territory may add its own conditions.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Australian law treats licensed sports betting differently from online casino games.</caption>
      <thead><tr><th scope="col">Activity</th><th scope="col">Legal position</th><th scope="col">What to check</th></tr></thead>
      <tbody>
      <tr><th scope="row">Online sports betting before the event starts</th><td>Permitted with a licensed Australian operator</td><td>Operator appears on ACMA's register</td></tr>
      <tr><th scope="row">Online betting on horse, harness and greyhound racing</th><td>Permitted with a licensed Australian operator</td><td>Operator appears on ACMA's register</td></tr>
      <tr><th scope="row">In-play sports betting online or in an app</th><td>Cannot be offered</td><td>Any site taking live sports bets online is not complying with the Act</td></tr>
      <tr><th scope="row">In-play sports betting by phone call or in a venue</th><td>Permitted with a licensed operator</td><td>It must be a genuine voice call or a bet placed in person</td></tr>
      <tr><th scope="row">Online lottery tickets</th><td>Permitted through licensed lottery providers</td><td>The provider's state or territory licence</td></tr>
      <tr><th scope="row">Online instant lotteries (scratchies)</th><td>Cannot be offered</td><td>None, as this is a prohibited service</td></tr>
      <tr><th scope="row">Online keno</th><td>Currently offered by licensed operators in some jurisdictions. A federal ban has been proposed, but we could not confirm that it is law or in force</td><td>The provider's licence, and ACMA for any change</td></tr>
      <tr><th scope="row">Lotteries matched to overseas draws ('foreign matched lotteries')</th><td>Currently sold by some Australian-licensed providers. Betting on a lottery's outcome, as distinct from buying an entry, has been prohibited since 2019. A ban on matched products has been proposed but is unconfirmed</td><td>The provider's licence and exactly what you are buying, and ACMA for any change</td></tr>
      <tr><th scope="row">Online casino games, online pokies and online poker for real money</th><td>Cannot be offered to people in Australia</td><td>None, as no Australian licence exists for these</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Permitted with a licensed Australian operator</h3>
      <p>Betting on sport and racing is the core of legal online gambling here. You can bet through a licensed bookmaker's website or app, or with the TAB, as long as a sports bet goes on before the event starts. Lottery tickets bought online from a licensed provider are also lawful.</p>
      <p>Licensed operators must verify your identity before you can bet. They take deposits in Australian dollars by methods such as debit card, PayID and bank transfer.</p>
      <h3>Prohibited services: online casinos, pokies and poker</h3>
      <p>Any site offering casino games, pokies or poker to Australians for real money is operating outside the Act. That holds even if it has an overseas licence, lists prices in AUD or accepts local payment methods. Pokies in a pub, club or casino are a separate matter, regulated by the states and territories.</p>
      <h3>In-play betting: the online versus phone and venue distinction</h3>
      <p>In-play (or 'live') betting means betting on a sporting event after it has started. The Act stops operators offering this online, including through an app. It does allow in-play bets by telephone, where you speak to an operator, and bets placed in person at a venue such as a TAB outlet.</p>
      <p>The 2017 amendments shut down 'click-to-call' features that mimicked a phone call from inside an app. The restriction applies to sport. Betting on a horse, harness or greyhound race is treated differently under the Act.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="reforms">Australian gambling law 2026: reforms still to be confirmed</h2>
      <figure class="shot"><?= gw_img('articles/law26-reforms', 'Chart with a warning mark beside the title 2026 Law Changes to Verify', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The push for change comes from the 2023 parliamentary inquiry into online gambling harm, often called the Murphy report. Its recommendations included a phased ban on online gambling advertising and a ban on inducements.</p>
      <p>We could not confirm from the Federal Register of Legislation or Parliament's bills pages that a reform Act has passed, what it is called or when it starts. For that reason this guide does not repeat the ad caps, time windows and start dates that circulate in media coverage and on betting sites. Treat any such figure as unconfirmed until you see it in a primary source.</p>
      <h3>The rules that exist today in the areas under debate</h3>
      <div class="mini3">
        <div><h3>Advertising</h3><p>Gambling ads are already banned during live sport broadcasts and streams between 5am and 8.30pm, from five minutes before play starts until five minutes after it ends. Proposals for wider limits are not confirmed as law.</p></div>
        <div><h3>Inducements</h3><p>Offers to open a betting account or refer a friend are already banned under the National Consumer Protection Framework for Online Wagering. A broader ban is a recommendation, not a confirmed rule.</p></div>
        <div><h3>Online keno and overseas-matched lotteries</h3><p>Both are sold by licensed providers today, as the table shows. If you use one, ask the provider whether any change affects it.</p></div>
        <div><h3>Illegal offshore sites</h3><p>ACMA's current tool is asking internet providers to block them. Stronger measures, including blocking payments, have been discussed but we could not confirm them.</p></div>
      </div>
      <h3>Verification box: how to confirm a reform before you rely on it</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Search for the Act on legislation.gov.au.</strong> If it isn't listed there as an Act, it is not law.</li>
          <li><strong>Read the commencement table.</strong> It usually sits in section 2 of a Commonwealth Act and gives the start date for each schedule. Royal Assent does not mean every rule is in force.</li>
          <li>If it is still a Bill, check its progress on Parliament's bills and legislation pages.</li>
          <li>Read the official summary on ACMA's Interactive Gambling Act page or in the Communications Minister's media releases.</li>
          <li>Join any new opt-out or exclusion register only through a .gov.au address.</li>
        </ol>
      </div>
      <h3>What applies now and what is still pending</h3>
      <p>In force now, under existing law:</p>
      <div class="rg-card">
        <ul class="checks">
        <li>the bans on offering online casinos, pokies, poker and online in-play sports betting</li>
        <li>the requirement for wagering operators to hold an Australian licence</li>
        <li>the live sport advertising restrictions and the ban on sign-up inducements</li>
        <li>BetStop self-exclusion, since August 2023</li>
        <li>the credit card ban for online wagering, since June 2024</li>
        </ul>
      </div>
      <p>Pending or unconfirmed: any wider advertising limits, any ban on online keno or overseas-matched lotteries, and any payment-blocking scheme. Use the verification box before relying on any of them.</p>

      <h2 id="offshore">Offshore casino sites: the legal position for players and the real risks</h2>
      <figure class="shot"><?= gw_img('articles/law26-offshore', 'Casino chips beside the title Offshore Sites and Real Risks', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Plenty of websites aimed at Australians claim offshore casinos are 'legal for players'. That claim is misleading.</p>
      <h3>Why 'not an offence for the player' doesn't mean legal or protected</h3>
      <p>The Interactive Gambling Act's offences are directed at the people who provide and advertise prohibited services, not at the customer who places a bet. That much is an accurate description of how the Act is drafted.</p>
      <p>It does not make the service legal. An offshore casino taking bets from Australians is providing a prohibited service, whatever the player's own position. Nor does the Act's focus on providers protect the player in any way. State and territory laws may apply as well, so the federal position is not the whole picture.</p>
      <h3>What you lose outside the Australian system</h3>
      <div class="flags">
        <div class="flag"><h3>No complaint path</h3><p class="bad">If a site refuses to pay or closes your account, no Australian regulator can order it to pay you. ACMA can act against the site but cannot recover your money.</p></div>
        <div class="flag"><h3>Withheld winnings</h3><p class="bad">The operator alone decides disputes over bonus conditions, identity checks or 'irregular play'.</p></div>
        <div class="flag"><h3>Site blocking</h3><p class="bad">A site can become unreachable while it still holds your balance.</p></div>
        <div class="flag"><h3>Declined payments</h3><p class="bad">Some banks decline transactions to gambling sites.</p></div>
        <div class="flag"><h3>No safeguards</h3><p class="bad">BetStop, deposit limit rules and activity statements do not bind an unlicensed operator.</p></div>
        <div class="flag"><h3>Your data</h3><p class="bad">Your identity documents and card details go to a business outside Australian oversight.</p></div>
      </div>
      <p>None of this is a reason to hunt for a 'safer' offshore site. The safer option is to stick to services that are permitted and licensed here.</p>
      <p class="see-also">Read more in <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos</a> and <a href="/online-casinos-australia-pros-cons-legality/">online casinos in Australia: pros, cons and legality</a>.</p>

      <h2 id="check">How to check an operator is licensed and use the protections you're entitled to</h2>
      <figure class="shot"><?= gw_img('articles/law26-check', 'Checklist card beside the title Check an Operator Is Licensed', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Check ACMA's register of licensed wagering providers</h3>
      <p>The check takes a couple of minutes:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Go to acma.gov.au and find the register of licensed interactive wagering providers.</strong> Searching the site for 'check if a gambling operator is legal' will bring it up.</li>
          <li><strong>Search for the operator's brand name.</strong> If nothing appears, try the company name shown in the footer of its website.</li>
          <li><strong>Compare the web address on the register with the one you are using.</strong> Copycat sites sometimes imitate licensed brands.</li>
          <li><strong>If the operator is not listed, don't deposit.</strong> Report it through ACMA's online complaint form for illegal gambling services.</li>
        </ol>
      </div>
      <p>The register covers wagering. For a lottery provider, check with the regulator in the state or territory that licenses it. You can also report gambling ads that you think break the rules to ACMA.</p>
      <h3>BetStop, deposit limits and the credit card ban</h3>
      <p>Betting with a licensed operator brings protections that are required by law:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>BetStop</h3>
          <p>The National Self-Exclusion Register is free, and one registration covers all licensed online and phone wagering providers. Once you are registered, operators must not let you bet, open an account or receive their marketing. See <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> for the exclusion periods and how to sign up.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Deposit limits</h3>
          <p>Licensed operators must offer you the option of setting a deposit limit. Set it when you open the account, before you have a reason to regret skipping it.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>Activity statements</h3>
          <p>You are entitled to regular statements showing what you have deposited, won and lost.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Protection</p>
          <h3>No credit</h3>
          <p>Online wagering operators cannot accept credit cards. The FAQ below sets out what the ban covers.</p>
        </article>
      </div>
      <h3>Responsible gambling: 18+, set limits, get help</h3>
      <div class="rg-card">
      <p>You must be 18 or over to gamble anywhere in Australia. No bet is a sure thing, and no system or tipster can guarantee a win, so only stake money you can afford to lose. Decide your limit before you log in.</p>
      <p>If gambling is causing stress for you or someone close to you, Gambling Help Online offers free, confidential support at any hour. Call <a href="tel:1800858858">1800 858 858</a> or visit gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a>.</p>

      <h2 id="faq">Online gambling laws in Australia: FAQ</h2>
      <div class="faq">
        <details>
          <summary>Can I use a credit card to bet online?</summary>
          <p>Not with an online bookmaker. Since June 2024, online wagering operators cannot accept credit cards, credit-linked digital wallets or digital currency. Debit cards, PayID and bank transfers remain available. Online lottery purchases are exempt from the ban, though a lottery provider or your card issuer may apply its own restrictions.</p>
        </details>
        <details>
          <summary>Does BetStop cover offshore sites?</summary>
          <p>No. BetStop binds Australian-licensed online and phone wagering providers only. An illegal offshore site sits outside it and can keep taking bets and sending marketing after you register. BetStop also doesn't cover pokies venues or casinos, which have separate state and territory self-exclusion programs. Some banks offer a gambling block on your card, which adds another barrier.</p>
        </details>
        <details>
          <summary>When do the new gambling ad rules start?</summary>
          <p>We could not confirm a start date from a primary source, so don't rely on dates quoted in news coverage or on betting sites. The existing live sport restrictions apply now. Any new rule starts on the date set in the Act's commencement provisions, which you can check using the verification box above.</p>
        </details>
        <details>
          <summary>Do I pay tax on gambling winnings?</summary>
          <p>In general, winnings are not treated as taxable income for people who gamble recreationally. The position can differ if your gambling amounts to running a business. The ATO or a registered tax agent can advise on your circumstances.</p>
        </details>
        <details>
          <summary>Who do I complain to about a betting site?</summary>
          <p>For a licensed bookmaker, start with the operator's own complaints process. If that fails, go to the regulator that issued its licence, which is often the Northern Territory Racing and Wagering Commission. For an illegal or unlicensed site, a suspected advertising breach or a BetStop problem, complain to ACMA.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step before placing a bet online</h2>
      <figure class="shot"><?= gw_img('articles/law26-next', 'Limit sliders beside the title Before You Place a Bet Online', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Run through this short checklist before your next bet:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Confirm the licence.</strong> Look the operator up on ACMA's register and check that the web address matches.</li>
          <li><strong>Set a deposit limit.</strong> Do it when you open the account and base it on what you can afford to lose.</li>
          <li><strong>Know BetStop.</strong> Bookmark <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> so you know where to go if you ever need it.</li>
          <li><strong>Verify any reform date yourself.</strong> If you read that an ad rule or a keno or lottery ban has started, check the Act's commencement table before you act on it.</li>
        </ol>
      </div>
      <p>Australian gambling law in 2026 is still moving, and articles like this one go out of date. For the final word, go to ACMA for the federal rules and to the state or territory regulator listed above for local ones.</p>
      <p><strong>Related reading:</strong> <a href="/understanding-australian-online-gambling-regulations/">Understanding Australian Online Gambling Regulations</a>, <a href="/online-casinos-australia-pros-cons-legality/">Online Casinos Australia – Pros, Cons &amp; Legality</a>, <a href="/kyc-verification-at-online-casinos/">KYC Verification at Online Casinos: What to Expect</a>, <a href="/kyc-verification-at-online-casinos-australia/">KYC Verification at Online Casinos Australia</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
