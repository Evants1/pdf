<?php
/**
 * Article: Online Gambling Laws in Australia: What Players Should Know
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. Your original text (opening, the position table, the Act, who regulates what, protections, tax, the four checks and
 *    the closing paragraph) is kept word for word. ADDED: the "In short" box, "which situation are you in", "what the Act does
 *    and does not do", where to check each regulator, "what the protections do not cover", "four myths", "rules can change"
 *    and five FAQs. Every added statement restates something already on your other law pages. Edit or delete freely.
 * 2. LEGAL ACCURACY: this is a law page. Please have an Australian lawyer review the whole page before you rely on it. Points
 *    to verify on official sources: the credit card date ("Since 11 June 2024"), the named state regulators, the tax
 *    statement, and the statements about BetStop and sign-up inducements. The "Updated" date on this page tells readers it is
 *    current, so only keep it if you have checked the content.
 * 3. REFORM WORDING: the "rules can change" section is deliberately neutral. Your pages disagree about whether a reform
 *    package has passed (/online-gambling-laws-in-australia-2026/ says it could not confirm one,
 *    /understanding-australian-online-gambling-regulations/ says Parliament passed one). Check legislation.gov.au and
 *    acma.gov.au and align all pages.
 * 4. KEYWORD OVERLAP: this page's angle is "quick reference for players". The long Q&A is /online-gambling-laws-in-australia-2026/,
 *    the "who does what" map is /understanding-australian-online-gambling-regulations/. Keep them distinct or merge with redirects.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. On phones the rail
 *   banner is hidden and the same banner is shown inside the article instead (after the "which situation" table).
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('online-gambling-laws-in-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#two-things">Wagering and casino games differ</a></li>
            <li><a href="#iga">The Interactive Gambling Act</a></li>
            <li><a href="#who">Who regulates what</a></li>
            <li><a href="#protections">Protections for licensed wagering</a></li>
            <li><a href="#myths">Four myths about the law</a></li>
            <li><a href="#tax">What about tax?</a></li>
            <li><a href="#changes">Rules can change</a></li>
            <li><a href="#checking">How to check where you stand</a></li>
            <li><a href="#faq">Quick answers</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Australia treats two things very differently: online <strong>wagering</strong> (sports and racing betting) and online <strong>casino games</strong> such as pokies, blackjack and roulette. Understanding the difference is the starting point for any Australian reader. This is general information, not legal advice, and the rules change, so confirm details with the regulators named below.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Online sports and racing betting can be offered by operators licensed in Australia.</strong> Online casino games (pokies, table games) can't lawfully be offered to people in Australia.</li>
          <li><strong>The Interactive Gambling Act is aimed mainly at the businesses that provide prohibited services,</strong> not at individual players, but offshore casinos sit outside Australian protections.</li>
          <li><strong>Protections such as BetStop apply to licensed Australian wagering.</strong> They do not follow you to an offshore casino.</li>
          <li><strong>This is general information, not legal advice,</strong> and the rules change, so confirm details with the regulators.</li>
        </ul>
      </div>

      <h2 id="two-things">Wagering and casino games are treated differently</h2>
      <figure class="shot"><?= gw_img('articles/lw-two', 'Casino table beside the title Two Kinds of Online Gambling', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="table-wrap">
      <table class="data">
      <caption>The basic position for people in Australia</caption>
      <thead><tr><th scope="col">Activity</th><th scope="col">Position</th><th scope="col">Who oversees it</th></tr></thead>
      <tbody>
      <tr><th scope="row">Online sports and racing betting</th><td>Can be offered by operators licensed in Australia</td><td>A state or territory regulator, plus national rules</td></tr>
      <tr><th scope="row">Online casino games (pokies, table games)</th><td>The Interactive Gambling Act 2001 prohibits offering them to people in Australia</td><td>The Australian Communications and Media Authority (ACMA)</td></tr>
      <tr><th scope="row">Pokies and casinos in physical venues</th><td>Legal and licensed by each state or territory</td><td>State and territory gambling regulators</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Which situation are you in?</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">If you are using…</th><th scope="col">The position, as described above</th><th scope="col">Protections to expect</th><th scope="col">First thing to check</th></tr></thead>
      <tbody>
      <tr><th scope="row">An online bookmaker for sports or racing</th><td>Can be offered by operators licensed in Australia</td><td>The protections for licensed wagering, including BetStop</td><td>The Australian licence, on the state or territory regulator's website</td></tr>
      <tr><th scope="row">An online casino or pokies site</th><td>The Interactive Gambling Act prohibits offering these to people in Australia</td><td>None from Australia: an offshore casino sits outside Australian protections</td><td>What ACMA says about illegal gambling services</td></tr>
      <tr><th scope="row">Pokies or a casino in a physical venue</th><td>Legal and licensed by each state or territory</td><td>Those set by the state or territory regulator</td><td>The venue's licence and its exclusion program</td></tr>
      <tr><th scope="row">A site that mentions a licence from another country</th><td>A foreign licence does not give permission to offer casino games to people in Australia</td><td>Not Australian ones</td><td>Whether the product is wagering or a casino-style game</td></tr>
      </tbody>
      </table>
      </div>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="iga">The Interactive Gambling Act</h2>
      <figure class="shot"><?= gw_img('articles/lw-iga', 'Document with a magnifying glass beside the title The Interactive Gambling Act', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The Interactive Gambling Act 2001 is a Commonwealth law. It is aimed mainly at the businesses that provide prohibited interactive gambling services to people in Australia, not at individual players. ACMA enforces it, including by issuing warnings and asking internet providers to block offending websites. A casino site holding a licence from another country, for example Malta or Curaçao, does not give that operator permission to offer casino games to people in Australia.</p>
      <p>For players this has a practical consequence. Even where playing is not itself an offence, an offshore casino that is not authorised in Australia sits outside Australian consumer protections, Australian dispute processes and Australian safer gambling schemes. If a withdrawal is refused, there may be no regulator in Australia that can help.</p>
      <h3>What the Act does, and what it does not do</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>It is aimed mainly at the businesses that provide prohibited services, and ACMA enforces it with warnings and by asking internet providers to block sites.</li>
          <li>It does not make an offshore casino safe or regulated for your benefit. A site that is blocked can still hold your balance.</li>
          <li>A licence from another country does not give an operator permission to offer casino games to people in Australia.</li>
          <li>It does not give you a regulator to complain to if an offshore casino refuses a withdrawal.</li>
        </ul>
      </div>

      <h2 id="who">Who regulates what</h2>
      <figure class="shot"><?= gw_img('articles/lw-who', 'Shield with a tick beside the title Who Regulates What', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>ACMA</strong> enforces the Interactive Gambling Act and publishes information on illegal gambling services.</li>
          <li><strong>State and territory regulators</strong> license wagering operators and venues. Examples include the Victorian Gambling and Casino Control Commission, the NSW Independent Liquor and Gaming Authority and the Northern Territory Racing Commission.</li>
          <li><strong>AUSTRAC</strong> supervises anti-money-laundering and counter-terrorism financing obligations for reporting entities, which is why identity checks exist. See <a href="/kyc-verification-at-online-casinos/">our KYC guide</a>.</li>
        </ul>
      </div>
      <p>Each has its own website. For the final word on whether a service is legal here, go to the Australian Communications and Media Authority at <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a>. For the identity rules that apply to licensed providers, go to AUSTRAC at <a href="https://www.austrac.gov.au" rel="noopener">austrac.gov.au</a>.</p>

      <h2 id="protections">Protections for licensed wagering</h2>
      <figure class="shot"><?= gw_img('articles/lw-protect', 'Checklist card beside the title Licensed Betting Protections', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Under national consumer protection measures, licensed Australian online wagering providers are subject to rules that include:</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a></strong> the national self-exclusion register, which lets you exclude yourself from all licensed online and phone wagering providers in one step.</li>
          <li><strong>Identity verification</strong> within a set period of account opening.</li>
          <li><strong>No credit for gambling.</strong> Since 11 June 2024, credit cards cannot be used for online wagering with licensed providers.</li>
          <li><strong>Restrictions on sign-up inducements.</strong> Licensed providers generally cannot offer bonuses to entice people to open an account. That is one reason large welcome offers are mostly associated with offshore sites. See <a href="/how-casino-welcome-bonuses-work/">how welcome bonuses work</a>.</li>
        </ul>
      </div>
      <p>These protections apply to licensed Australian wagering. They do not follow you to an offshore casino.</p>
      <h3>What they do not cover</h3>
      <p>BetStop covers licensed Australian online and phone wagering. It does not block offshore casinos, so if you use one, any exclusion has to be set up with each site separately. The bank-level and venue-level tools in our guides can help, but none of them replaces the protections that licensed wagering has.</p>
      <p class="see-also">See <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>.</p>

      <h2 id="myths">Four myths about the law</h2>
      <figure class="shot"><?= gw_img('articles/lw-myths', 'Chart with a warning mark beside the title Four Law Myths', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="table-wrap">
      <table class="data">
      <caption>Common assumptions and the position</caption>
      <thead><tr><th scope="col">The assumption</th><th scope="col">The position</th></tr></thead>
      <tbody>
      <tr><th scope="row">“It has a Malta or Curaçao licence, so it is legal here.”</th><td>A licence from another country does not give an operator permission to offer casino games to people in Australia.</td></tr>
      <tr><th scope="row">“The law targets providers, so there is nothing at risk for me.”</th><td>The offences are aimed mainly at providers, but an offshore casino sits outside Australian consumer protections, dispute processes and safer gambling schemes. If a withdrawal is refused, there may be no regulator here that can help.</td></tr>
      <tr><th scope="row">“It accepts Australian dollars, so it is an Australian casino.”</th><td>A payment option or a local-sounding name says nothing about who runs the site or which regulator, if any, is behind it.</td></tr>
      <tr><th scope="row">“It takes crypto, so it is lawful or protected.”</th><td>A payment method does not make a casino lawful or protected in Australia.</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="tax">What about tax?</h2>
      <figure class="shot"><?= gw_img('articles/lw-tax', 'Casino coin beside the title What About Tax', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>As we understand it, gambling winnings are generally not treated as taxable income for people who gamble recreationally in Australia, but the position can differ for someone who gambles as a business. Check the <a href="https://www.ato.gov.au" rel="noopener">Australian Taxation Office guidance</a> or ask a registered tax adviser about your circumstances.</p>

      <h2 id="changes">Rules can change: how to stay current</h2>
      <p>Gambling rules in Australia are a topic of ongoing debate and can change. Treat any summary, including this one, as a starting point, and confirm the current position with the primary sources before you rely on it.</p>
      <div class="rg-card">
        <ul class="checks">
          <li>The Australian Communications and Media Authority (<a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a>) for the Interactive Gambling Act and illegal gambling services.</li>
          <li>The Federal Register of Legislation (<a href="https://www.legislation.gov.au" rel="noopener">legislation.gov.au</a>) for the text of the law and any amendments.</li>
          <li>The relevant state or territory regulator for licensed wagering and venues.</li>
        </ul>
      </div>
      <p class="see-also">For how reform has been reported, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="checking">How to check where you stand</h2>
      <figure class="shot"><?= gw_img('articles/lw-check', 'Limit sliders beside the title Check Where You Stand', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Ask whether the product is wagering or a casino-style game. They are regulated very differently.</li>
          <li>For wagering, confirm the operator's Australian licence on the relevant state or territory regulator's website and check that it participates in BetStop.</li>
          <li>For anything else, read what ACMA says about illegal gambling services and consider the lack of local protections before you deposit.</li>
          <li>If in doubt, take advice from a legal professional.</li>
        </ol>
      </div>
      <p>If you would like help setting limits or taking a break, see <a href="/responsible-gambling-tools-limits-and-self-exclusion/">our responsible gambling tools guide</a> and our <a href="/responsible-gambling/">responsible gambling page</a>. For the wider checklist, read <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a> and <a href="/safe-and-trusted-online-casinos/">how to identify a safe and trusted operator</a>.</p>

      <h2 id="faq">Quick answers</h2>
      <div class="faq">
        <details>
          <summary>Is online sports betting legal in Australia?</summary>
          <p>Yes, when it is offered by operators licensed in Australia. They are overseen by a state or territory regulator, plus national rules, and the protections described above apply to them.</p>
        </details>
        <details>
          <summary>Are online pokies legal in Australia?</summary>
          <p>No. Online casino games, including pokies and table games, can't lawfully be offered to people in Australia under the Interactive Gambling Act 2001. Pokies and casinos in physical venues are legal and licensed by each state or territory.</p>
        </details>
        <details>
          <summary>Is it illegal for me to play at an offshore online casino?</summary>
          <p>The Act's offences are aimed mainly at the businesses that provide prohibited services, not at individual players. That is a description of the law, not approval or legal advice, and an offshore casino still sits outside Australian protections. If in doubt, take advice from a legal professional.</p>
        </details>
        <details>
          <summary>Does BetStop cover offshore casinos?</summary>
          <p>No. BetStop covers licensed Australian online and phone wagering providers. It does not block offshore casinos, so any exclusion there has to be set up with each site.</p>
        </details>
        <details>
          <summary>What can I do if an offshore casino won't pay me?</summary>
          <p>There may be no regulator in Australia that can help. Keep your correspondence and screenshots, use the operator's own complaints process, and consider advice from a legal professional. If gambling is affecting you, Gambling Help Online offers free, confidential support.</p>
        </details>
      </div>
      <div class="rg-card">
      <p>Gambling is for adults aged 18 and over, and no licence, bonus or system guarantees a win. Never gamble with money you need for bills. If gambling is causing you stress, free and confidential support is available from <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</p>
      </div>

      <?php gw_topic_links($a['slug']); ?>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
