<?php
/**
 * Article: Best Online Casinos Australia 2026: How Reviews and “Top 10” Lists Work
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the Top 10 checks).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('best-online-casinos-australia-2026');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#why">Why we crown no casino</a></li>
            <li><a href="#law">What the law says in 2026</a></li>
            <li><a href="#reviews">How to read casino reviews</a></li>
            <li><a href="#top-10">The Top 10 checks</a></li>
            <li><a href="#legal-ways">Legal ways to play and bet</a></li>
            <li><a href="#risks">Risks of offshore casinos</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#play-safe">Play safe and your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">Best Online Casinos Australia 2026: The Short Answer</h2>
      <figure class="shot"><?= gw_img('articles/best-short-answer', 'Review card with a magnifying glass beside the title Best Online Casinos Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Real-money online casinos, including online pokies and casino table games, cannot lawfully be offered to people in Australia. So this guide to the best online casinos Australia searchers are after doesn't crown a winner. It shows you how to judge the claims on any ranking page, what the law says, and which regulated options exist.</p>
      <p>Many sites accept AUD, show PayID at the checkout and use Australian-sounding branding. None of that means they're licensed here. Australia doesn't issue licences for online casinos, and that is as true for Australian online casinos in 2026 as it was before. This is general information, not legal advice. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> has the final word on what is and isn't permitted.</p>
      <p>This guide is for adults aged 18 and over.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>No online casino can be licensed in Australia,</strong> so this guide crowns no winner and endorses no offshore operator.</li>
          <li><strong>Ranking pages are mostly affiliate listicles.</strong> Their payout times, RTP figures and bonuses can't be checked.</li>
          <li><strong>Ten checks</strong> let you judge any site yourself. If it fails either of the first two, close the tab.</li>
          <li><strong>The legal options</strong> are licensed wagering, lotteries and land-based venues.</li>
        </ul>
      </div>

      <h2 id="why">Why this guide doesn't crown a single casino</h2>
      <p>Most pages that rank for “top online casinos Australia” are affiliate listicles. They earn a commission when you sign up, and they quote bonuses, payout times and RTP figures you can't check. Some of the brands they list have appeared on ACMA's investigation or blocking lists. We won't name or endorse any offshore operator, because that would imply a legitimacy no such operator has under Australian law.</p>
      <h3>What you'll get instead</h3>
      <div class="rg-card">
        <ul class="checks">
        <li>A plain-English summary of the Interactive Gambling Act and ACMA's role.</li>
        <li>The 2026 reform package and when it is due to start.</li>
        <li>How to read the online casino reviews Australia sites publish, and what to ignore.</li>
        <li>A ten-point checklist you can run on any site. It's our “Top 10”.</li>
        <li>The legal alternatives: licensed wagering, lotteries and land-based venues.</li>
        <li>The risks of offshore sites, including the BetStop gap.</li>
        </ul>
      </div>

      <h2 id="law">What Australian Law Says About Online Casinos in 2026</h2>
      <figure class="shot"><?= gw_img('articles/best-law', 'Shield with a tick beside the title What the Law Says in 2026', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Providers are prohibited from offering online casino services to people in Australia, and there is no local licensing pathway for them. Ranking pages often bury or blur this, so the details are worth knowing.</p>
      <h3>The Interactive Gambling Act 2001 in plain English</h3>
      <p>The Interactive Gambling Act 2001 (IGA) is the federal law covering online gambling. It prohibits operators from providing certain “interactive gambling services” to customers in Australia. In practice that includes real-money online pokies and casino-style games such as roulette and blackjack. The Act carves out some regulated products, notably licensed wagering on sport and racing, and lotteries. Those aren't online casinos.</p>
      <p>The Act is aimed mainly at providers, not individual players. Don't read that as permission. It doesn't tell you a site is legitimate or safe, and state and territory laws also apply. If you need certainty about your own situation, speak to a lawyer or contact ACMA.</p>
      <p>No Australian regulator issues an online casino licence. Any site claiming to be “Australian licensed” for casino games deserves scepticism.</p>
      <h3>ACMA's role and website blocking</h3>
      <p>ACMA is the federal regulator that enforces the IGA against illegal offshore services. It can investigate operators, issue warnings and ask internet service providers to block access to illegal gambling websites. It publishes information about blocked sites on its website. The total changes as sites are added, so check the latest figure and date on ACMA's own page rather than trusting a number quoted by a third party.</p>
      <p>Blocking isn't a perfect barrier. Operators often reappear on new domains, so a site that loads is not evidence that it's lawful.</p>
      <h3>The August 2026 reform package and when it starts</h3>
      <?php /* OWNER TODO: the reform dates and claims in this paragraph (passed Parliament August 2026; most measures from 1 January 2027; bank transaction-blocking duties) were supplied as text and could not be independently verified when this page was built. Confirm them on acma.gov.au, the Department of Infrastructure site and legislation.gov.au, and the 'Reforms' bullet in the risks section, before relying on them. */ ?>
      <p>As we understand it, a reform package targeting illegal offshore gambling passed Parliament in August 2026, with most measures due to start on 1 January 2027. In general terms, the reforms strengthen enforcement powers and add duties for financial institutions to block transactions linked to illegal gambling services. We can't vouch for the finer detail, including which measures start when. Check the ACMA and Department of Infrastructure pages for the current position before relying on any summary, this one included.</p>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a> and <a href="/understanding-australian-online-gambling-regulations/">who regulates what in Australian online gambling</a>.</p>

      <h2 id="reviews">How to Read Online Casino Reviews Australia Sites Publish</h2>
      <figure class="shot"><?= gw_img('articles/best-reviews', 'Document with a magnifying glass beside the title How to Read Casino Reviews', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>A review is only as trustworthy as the incentives behind it. Most online casino reviews in Australia are commercial products first and consumer guides second.</p>
      <h3>Why “tested” and “verified” badges prove little</h3>
      <p>Phrases like “tested with our own money”, “50+ casinos reviewed” or “verified payouts” are self-reported. No independent Australian body checks them. A badge saying a site is “fair” or “audited” means nothing unless you can open the auditor's own website and find that exact operator listed. Even then, a game-fairness certificate says nothing about whether the service is lawful here or whether you can get your money out.</p>
      <h3>Affiliate links and ranking incentives</h3>
      <p>Look for disclosure text near the top or bottom of the page. If every “Visit site” button carries a tracking link, the order of the list may reflect commission rates rather than quality. Rankings that never change, or that put the same brand first in every category, are another signal.</p>
      <h3>Red flags in top online casinos Australia lists</h3>
      <div class="flags">
        <div class="flag"><h3>Precise payout times</h3><p class="bad">Precise payout times such as “withdrawals in minutes”, with no method shown. Speed depends on verification, the payment method and the operator's decisions, and it differs between players.</p></div>
        <div class="flag"><h3>Site-wide RTP figures</h3><p class="bad">Exact RTP numbers quoted as site-wide facts. RTP belongs to individual games, and operators can configure it differently.</p></div>
        <div class="flag"><h3>Euros or pounds</h3><p class="bad">Bonuses in euros or pounds on an “Australian” page. That suggests recycled content written for other markets.</p></div>
        <div class="flag"><h3>Hidden wagering terms</h3><p class="bad">Bonus headlines without the wagering terms, or terms hidden several clicks away.</p></div>
        <div class="flag"><h3>“Australian licensed” branding</h3><p class="bad">“Australian licensed” or “Aussie-approved” branding. Neither exists for online casinos.</p></div>
        <div class="flag"><h3>Offshore licence as protection</h3><p class="bad">An offshore licence presented as protection. A licence from another jurisdiction doesn't make a service lawful in Australia.</p></div>
        <div class="flag"><h3>Legality as a footnote</h3><p class="bad">No mention of the law, or legality reduced to a footnote.</p></div>
        <div class="flag"><h3>Wagering brands in casino lists</h3><p class="bad">Licensed wagering brands mixed into casino lists, which blurs a legal distinction that matters.</p></div>
      </div>
      <p class="see-also">See how we judge a review in our <a href="/online-casino-reviews/">online casino reviews methodology</a>, or read the main guide to the <a href="/best-online-casinos/">best online casinos in Australia</a>.</p>

      <h2 id="top-10">The Top 10 Checks Before Trusting Any Casino Site</h2>
      <figure class="shot"><?= gw_img('articles/best-top10', 'Checklist card beside the title The Top 10 Checks for Any Casino', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Instead of a brand ranking, here is a ten-point checklist. Run it on any gambling site, or on any review that recommends one. If a site fails the first two checks, the rest are largely academic.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Run through these ten checks before you sign up or deposit anywhere.</caption>
      <thead><tr><th scope="col">#</th><th scope="col">Check</th><th scope="col">What to look for</th><th scope="col">How to verify it yourself</th></tr></thead>
      <tbody>
      <tr><th scope="row">1</th><td>ACMA blocked and investigation lists</td><td>Whether the domain or operator appears on ACMA's published lists</td><td>Search the ACMA website for its illegal gambling and blocked-site information. Note the date of the list you checked.</td></tr>
      <tr><th scope="row">2</th><td>Licensing for Australia</td><td>A licence that actually permits the service in Australia. Online casino games have no Australian licence.</td><td>For wagering, confirm the operator holds an Australian licence with the relevant state or territory regulator. Treat offshore licences as irrelevant to legality here.</td></tr>
      <tr><th scope="row">3</th><td>Terms and conditions</td><td>Which company contracts with you, which law governs disputes, and when the operator can void balances</td><td>Read the full terms before depositing, not the summary. Save a copy or screenshot.</td></tr>
      <tr><th scope="row">4</th><td>Wagering terms on bonuses</td><td>Wagering requirements, game weightings, maximum bet limits and expiry dates</td><td>Find them in the bonus terms. If you can't, treat the bonus as unusable. Never rely on a review's summary.</td></tr>
      <tr><th scope="row">5</th><td>Identity verification (KYC)</td><td>When and how ID is requested, and what happens to your documents</td><td>Check the privacy policy. Be wary of sites that take deposits instantly but only ask for ID when you withdraw.</td></tr>
      <tr><th scope="row">6</th><td>Withdrawal limits and fees</td><td>Caps per day, week or month, fees, and any pending periods</td><td>Look in the banking or payments terms. Search independent forums for complaints, keeping in mind that these can be biased either way.</td></tr>
      <tr><th scope="row">7</th><td>AUD handling</td><td>Whether balances are held in AUD or converted, and who sets the exchange rate</td><td>Check the terms and your bank statement after a small test transaction. Conversion fees can apply on both sides.</td></tr>
      <tr><th scope="row">8</th><td>Dispute route</td><td>A named complaints process, and an external body that is real and reachable</td><td>Confirm that the named dispute body exists and lists the operator. For illegal services, expect no Australian regulator complaint route.</td></tr>
      <tr><th scope="row">9</th><td>Responsible gambling tools</td><td>Deposit limits, time limits, cool-offs and self-exclusion that are easy to find and work</td><td>Check the account settings before you deposit. Remember that BetStop covers licensed Australian wagering only.</td></tr>
      <tr><th scope="row">10</th><td>Operator company details</td><td>A named legal entity, registered address, and a history you can trace</td><td>Search the company name independently. Be cautious if details are missing, generic or lead only to a registered-agent address.</td></tr>
      </tbody>
      </table>
      </div>
      <p>A site can pass checks 3 to 10 and still be an illegal service. Checks 1 and 2 decide whether you should be there at all.</p>
      <p class="see-also">Go deeper in our <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos guide</a>, <a href="/kyc-verification-at-online-casinos-australia/">KYC verification at online casinos in Australia</a> and <a href="/how-to-find-the-best-online-casino-australia/">how to find the best online casino in Australia</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="legal-ways">Legal Ways to Play and Bet in Australia</h2>
      <figure class="shot"><?= gw_img('articles/best-legal-ways', 'Dotted circles beside the title Legal Ways to Play and Bet', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>If you enjoy gambling, Australia does have regulated options. They aren't online casinos, and each has its own rules and risks.</p>
      <h3>State-licensed land-based casinos and pokies venues</h3>
      <p>Land-based casinos operate under state and territory licences, and each state has its own regulator. Pokies in pubs and clubs are permitted in most states and territories, but the rules vary a lot. Western Australia, for example, is far more restrictive than the eastern states. Check your own state or territory regulator for venue rules, minimum ages and venue-based self-exclusion programs.</p>
      <h3>Licensed online wagering on sport and racing</h3>
      <p>Online wagering on sport and racing is a different product from an online casino, and it can be lawful when offered by a licensed operator. Australian state and territory authorities issue the licences, and the operator must follow federal and state rules. Before you open an account, confirm the licence with the relevant state or territory regulator, and check that the operator is one BetStop covers. Don't assume a site with “Aussie” branding or a sports section is licensed.</p>
      <p>Licensed wagering operators are covered by BetStop and by national consumer protection measures for the sector. Rules on payment methods, such as limits on credit card use, have changed over time, so check the current requirements with the operator or regulator.</p>
      <h3>Lotteries and other regulated options</h3>
      <p>State and territory lotteries, including Powerball and Saturday Lotto, are regulated, and you can buy tickets in-store or online from licensed operators. Raffles and community fundraising draws are usually regulated at state level too. Be wary of sites that let you “bet on” lottery results instead of selling you an actual ticket. That is a different product with different legal and consumer-protection implications.</p>
      <p>No regulated option makes winning likely. Gambling is entertainment with a cost, and the odds are built to favour the operator over time.</p>

      <h2 id="risks">Risks of Offshore Casinos: Payments, Disputes and the BetStop Gap</h2>
      <figure class="shot"><?= gw_img('articles/best-offshore-risks', 'Wallet with payment cards beside the title Offshore Casino Risks', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>If you already use offshore sites, this is what the risks look like in practice.</p>
      <h3>Why BetStop doesn't cover offshore casinos</h3>
      <p>BetStop is the National Self-Exclusion Register. It covers licensed Australian online and phone wagering providers. Offshore casinos sit outside it because they aren't licensed here. Registering with BetStop won't stop an offshore casino from accepting your deposit or sending you promotional messages. Check <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> for its current scope.</p>
      <p>This is a real gap. If you're trying to cut back, don't rely on BetStop alone. Bank-level gambling blocks and blocking software add protection, and they're covered in the last section.</p>
      <h3>Banks, PayID and crypto: what can go wrong</h3>
      <div class="mini3">
        <div><h3>PayID and bank transfers</h3><p>Instant deposits are easy, but they're generally hard to reverse. Banks can also flag or decline transactions, and may close accounts linked to certain activity.</p></div>
        <div><h3>BPAY and cards</h3><p>The merchant name on your statement may not match the casino, which makes it harder to follow your spending.</p></div>
        <div><h3>Crypto</h3><p>Transfers are typically irreversible, and values can swing between deposit and withdrawal. Tax and record-keeping can also get complicated.</p></div>
        <div><h3>Reforms</h3><p>The 2026 package adds bank transaction-blocking duties. Once those start, payments to illegal gambling services may be more likely to fail or be stopped, so don't assume a method that works today will keep working.</p></div>
      </div>
      <h3>What to do if a withdrawal is refused</h3>
      <p>With an illegal service, there is no Australian regulator complaint route and no Australian consumer protection you can count on. Your options are limited:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Keep records:</strong> screenshots, emails, transaction IDs and the terms as they stood when you signed up.</li>
          <li>Use the site's own complaints process, in writing, and note any deadlines.</li>
          <li>Talk to your bank about the transaction, but don't expect a reversal.</li>
          <li>Report the service to ACMA, which collects complaints about illegal gambling even though it doesn't recover debts for individuals.</li>
          <li>Be wary of “chargeback” or “fund recovery” services that ask for upfront fees. Recovery scams target people in exactly this situation.</li>
        </ol>
      </div>
      <p class="see-also">More on limits and exclusion: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a>.</p>

      <h2 id="faq">Best Online Casinos Australia FAQ</h2>
      <div class="faq">
        <details>
          <summary>Is it legal to play at online casinos in Australia?</summary>
          <p>The Interactive Gambling Act prohibits providers from offering online casino services to people in Australia. The Act is aimed at providers, but that isn't permission to play, and state and territory laws also apply. Ask ACMA or a lawyer if you need a definitive answer for your circumstances.</p>
        </details>
        <details>
          <summary>Are there any Australian-licensed online casinos?</summary>
          <p>No. Australia doesn't issue licences for real-money online casino games, so treat any claim of an “Australian licensed online casino” with suspicion. Licensed Australian wagering operators exist, but they offer sport and racing betting, not casino games.</p>
        </details>
        <details>
          <summary>Are online pokies for real money legal in Australia?</summary>
          <p>Real-money online pokies cannot lawfully be offered to people in Australia under the IGA. Pokies in licensed pubs, clubs and casinos are regulated separately by states and territories. Check your state or territory regulator for details.</p>
        </details>
        <details>
          <summary>Does BetStop block online casinos?</summary>
          <p>No. BetStop covers licensed Australian online and phone wagering providers, and offshore casinos aren't part of it. Confirm the current scope at betstop.gov.au.</p>
        </details>
        <details>
          <summary>How can I tell if a casino site is blocked by ACMA?</summary>
          <p>ACMA publishes information about blocked illegal gambling websites on its site. Search for the domain there and note the date of the list, since new domains are added regularly. A site missing from the list isn't necessarily lawful, and a site that loads isn't proof it's licensed.</p>
        </details>
      </div>

      <h2 id="play-safe">Play Safe: Responsible Gambling and Your Next Step</h2>
      <figure class="shot"><?= gw_img('articles/best-play-safe', 'Limit sliders beside the title Play Safe and Your Next Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card">
      <p>You must be 18 or over to gamble in Australia. Gambling is not a way to make money, and no site, system or bonus can make winning likely.</p>
      <h3>Limits, blocks and free support (18+)</h3>
      <ul class="checks">
        <li><strong>Set limits first:</strong> decide on deposit and time limits before you start, and treat the amount as money already spent.</li>
        <li><strong>Use bank tools:</strong> many Australian banks let you block gambling transactions or set merchant category blocks. Ask yours what's available.</li>
        <li><strong>Install blocking software:</strong> filters can block gambling sites on your devices, including offshore ones.</li>
        <li>Register with BetStop at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> to exclude yourself from licensed Australian wagering. It doesn't cover offshore casinos.</li>
        <li><strong>Get free support:</strong> Gambling Help Online is free, confidential and available 24/7 on <a href="tel:1800858858">1800 858 858</a>, or online at gamblinghelponline.org.au. You can call for yourself or for someone close to you.</li>
      </ul>
      </div>
      <h3>Your next step</h3>
      <p>Before any deposit, run the ten checks above, starting with a search of ACMA's lists for the site. If it fails either of the first two, close the tab. If you want to gamble legally, choose a regulated option: a licensed land-based venue, a state lottery, or an operator you've confirmed as a licensed wagering provider.</p>
      <p class="see-also">Support and tools: our <a href="/responsible-gambling/">responsible gambling page</a> and <a href="/responsible-gaming-tools-every-australian-should-use/">responsible gaming tools every Australian should use</a>.</p>
      <p><strong>Related reading:</strong> <a href="/new-online-casinos-australia-2026/">New Online Casinos Australia 2026: What to Check Before You Try One</a>, <a href="/online-casino-trends-australia-2026/">2026 Online Casino Trends Australia: What’s Next</a>, <a href="/how-to-choose-a-real-money-online-casino/">How to Choose a Real-Money Online Casino</a>, <a href="/how-to-choose-a-real-money-online-casino-australia/">How to Choose a Real-Money Online Casino Australia</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
