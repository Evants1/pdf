<?php
/**
 * Article: Mobile Casino Gaming: Apps vs Browser Play
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. NEAR-DUPLICATE RISK (important): /mobile-casino-gaming-apps-vs-browser-2026/ now carries a different article with a
 *    very similar title idea ("Casino App vs Browser: the short answer for Australian players"), the same sections
 *    (law, native apps / PWAs / APKs / instant play, comparison table, security, limits, FAQ, five-step check) and many
 *    near-identical ideas and phrases. Search engines may treat the two as one and drop one. Strongly consider merging
 *    them (keep the better text and 301-redirect the other) or giving each a clearly different angle.
 *    /mobile-casino-apps-australia/ covers the same ground a third time.
 * 2. Re-check before publishing: that ACMA lists "online in-play sports betting" among the services it names as
 *    prohibited; the Apple and Google policy references (App Store Review Guidelines, Google Play Developer Policy
 *    Centre); the menu paths on iPhone and Android (Settings > Mobile, Network & internet, Privacy & Security); and the
 *    named networks (Telstra, Optus, Vodafone) and Curaçao.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the formats section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('mobile-casino-gaming-apps-vs-browser');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#law">What Australian law says</a></li>
            <li><a href="#formats">What "casino apps" really means</a></li>
            <li><a href="#compare">App vs browser, side by side</a></li>
            <li><a href="#security">Where each option goes wrong</a></li>
            <li><a href="#control">Notifications, limits and help</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Five checks before you tap</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">Casino app vs browser: the short answer for Australians</h2>
      <figure class="shot"><?= gw_img('articles/mb-short', 'Smartphone beside the title Casino App vs Browser The Answer', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>For Australians, the casino app vs browser question largely answers itself: the browser is the default, and usually the only real option. You're unlikely to find a genuine real-money casino app in the Australian App Store or Google Play. Most things marketed as an 'app' turn out to be the mobile website, a home-screen shortcut to that website, or an Android file you're asked to install yourself.</p>
      <p>One caveat first. Online casino games such as pokies, roulette and blackjack are a prohibited service under the Interactive Gambling Act 2001 when they're provided to people in Australia, whether through an app or a website. This guide explains the formats and their risks. It doesn't suggest either route is lawful or protected, and the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> has the final word.</p>
      <p>Here is how the formats compare:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Format</p>
          <h3>Browser (instant play)</h3>
          <p>Nothing to install, the least access to your phone, and the easiest to close and walk away from.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Format</p>
          <h3>Home-screen shortcut or PWA</h3>
          <p>The same website with an icon. It adds convenience, not capability.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Format</p>
          <h3>Sideloaded Android APK</h3>
          <p>The highest-risk route, because it skips app-store checks and can ask for broad permissions.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">The odds</p>
          <h3>The odds</h3>
          <p>Identical in every format. Game maths is set on the server, and every real-money game needs a live connection.</p>
        </article>
      </div>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>The browser is the default for Australians.</strong> A genuine real-money casino app is unlikely to appear in the App Store or Google Play.</li>
          <li><strong>The odds are identical in every format.</strong> Game maths is set on the server.</li>
          <li><strong>A sideloaded APK is the highest-risk route.</strong> It skips store checks and can ask for broad permissions.</li>
          <li><strong>Check ACMA first.</strong> A real-money casino service aimed at Australians is prohibited, however it reaches your phone.</li>
        </ul>
      </div>


      <h2 id="law">What Australian law says before you search 'mobile casino Australia'</h2>
      <figure class="shot"><?= gw_img('articles/mb-law', 'Shield with a tick beside the title Casino Apps and the Law', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Many pages that rank for 'mobile casino Australia' list offshore brands without mentioning the law. Here is the plain-English version.</p>
      <h3>What the Interactive Gambling Act restricts</h3>
      <p>The Interactive Gambling Act 2001 makes it an offence to provide, or advertise, certain online gambling services to people in Australia. ACMA, which enforces the Act, lists online casinos, online pokies and online poker among them, along with online in-play sports betting and wagering services that don't hold an Australian licence. Browser play is not a loophole. The prohibition applies to the service, however it reaches your phone.</p>
      <p>A licence from another jurisdiction, such as Curaçao, doesn't make a service lawful here. The Act's offences are aimed at providers rather than individual players, but that doesn't make playing legal or safe. If an offshore site withholds a withdrawal or closes your account, there is no Australian regulator or dispute scheme to turn to.</p>
      <h3>What is permitted on your phone</h3>
      <p>Online betting on racing and sport is allowed through providers licensed in an Australian state or territory, as are lotteries from licensed operators. These are the gambling apps you will find in the app stores. They come with their own rules, including identity checks and a ban on using credit cards for online wagering, which ACMA explains on its site. None of them can lawfully offer you online pokies or table games.</p>
      <h3>How to check a service with ACMA</h3>
      <p>ACMA publishes a register of licensed interactive wagering providers. If a service isn't on it, treat it as unlicensed. ACMA also publishes the list of illegal gambling sites it has asked internet providers to block, and takes complaints about illegal services through a form on its website. The rules and ACMA's enforcement powers change from time to time, so confirm the current position at <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> and don't rely on any third-party article, this one included.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="formats">What 'casino apps Australia' actually means: native apps, PWAs, APKs and instant play</h2>
      <figure class="shot"><?= gw_img('articles/mb-formats', 'Document with a magnifying glass beside the title Four Formats Under One Label', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Search for 'casino apps Australia' and you will be offered four quite different things under one label. Work out which one is in front of you before you tap anything.</p>
      <h3>Native app-store apps</h3>
      <p>A native app is software built for iOS or Android, reviewed by Apple or Google and installed from the App Store or Google Play. Both companies restrict real-money gambling apps, broadly to operators that hold the right licence for the country where the app is offered. Their current rules are in Apple's App Store Review Guidelines and Google Play's Developer Policy Centre. That is why a store search in Australia turns up licensed betting and lottery apps and play-money 'social casino' games, which don't pay out cash, but not real-money casinos.</p>
      <h3>Home-screen shortcuts and PWAs</h3>
      <p>A progressive web app (PWA) is a website built so it can be 'installed' from the browser. On an iPhone you tap Share, then Add to Home Screen in Safari. On Android, Chrome offers Add to Home screen or Install app. You get an icon and a full-screen window, but it is still the website, with no app-store review behind it. When a casino site says 'download our app' and nothing really downloads, this is what you're getting.</p>
      <h3>Sideloaded Android APKs</h3>
      <p>An APK is an Android installation file. Sideloading means downloading one from a website and installing it yourself, after giving your browser or file manager permission to install unknown apps. It bypasses Google Play's checks and automatic updates. iPhones don't use APKs, so if a site asks you to install a configuration profile or 'trust' a developer in Settings, treat that as a warning sign.</p>
      <h3>Instant play casino sites in Safari or Chrome</h3>
      <p>An instant play casino is a site that runs in Safari or Chrome with nothing to install. Games are typically built in HTML5, load from the game provider's servers and resize to fit your screen. Most mobile casino play works this way, and the other formats are mostly different doors into the same site.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="compare">Casino app vs browser compared side by side</h2>
      <figure class="shot"><?= gw_img('articles/mb-compare', 'Payment list with a clock beside the title App vs Browser Side by Side', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The table covers what you can observe on your own phone. It leaves out speed and data figures on purpose, because they depend on your handset, your network and the site.</p>
      <p>How casino apps and browser play compare on the features that matter most.</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Factor</th><th scope="col">Installed app (store app or APK)</th><th scope="col">PWA or home-screen shortcut</th><th scope="col">Browser (instant play)</th></tr></thead>
      <tbody>
      <tr><th scope="row">Speed</th><td>Menus may open quickly because interface files sit on the phone; games still load from the server</td><td>Same as the site, with some caching</td><td>Depends on your connection and browser</td></tr>
      <tr><th scope="row">Storage</th><td>Takes up space and grows with cached data</td><td>Very little</td><td>Browser cache only</td></tr>
      <tr><th scope="row">Updates</th><td>Through the store, or a manual re-download for APKs</td><td>Automatic when the site changes</td><td>Automatic</td></tr>
      <tr><th scope="row">Notifications</th><td>Push notifications, usually requested at first launch</td><td>Possible if you allow them</td><td>Only if you accept a site prompt</td></tr>
      <tr><th scope="row">Login</th><td>Often stays signed in; may offer Face ID or fingerprint</td><td>Often stays signed in</td><td>Sign in each session unless you save the password</td></tr>
      <tr><th scope="row">Privacy</th><td>Can request device permissions such as location, contacts, files or SMS</td><td>Limited to browser permissions</td><td>Cookies and browser permissions; private tabs available</td></tr>
      <tr><th scope="row">Shared devices</th><td>Visible icon, one tap from the account</td><td>Visible icon</td><td>No icon; history can be cleared</td></tr>
      <tr><th scope="row">Offline play</th><td>No</td><td>No</td><td>No</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Speed and stability on 4G, 5G and Wi-Fi</h3>
      <p>Operators often say their app is faster. Treat that as a claim to test, not a fact. Many casino 'apps' are a shell around the same web pages, and the games come from the provider's servers whichever way you open them. Your connection matters far more than the format. On a strong Telstra, Optus or Vodafone 5G signal or home Wi-Fi, the format is unlikely to be the bottleneck. On weak 4G in a regional area or on a train, live dealer video is likely to stutter in all of them.</p>
      <p>Real-money games need a live connection in every format. There is no offline play, because each spin or hand is decided on a server. If your connection drops mid-round, the outcome has usually been recorded at the other end already. How an interrupted round is settled is set out in the operator's terms, so read them.</p>
      <h3>Storage, updates and data use</h3>
      <p>A browser session costs you no storage beyond cache. An installed app takes space and needs updating, and a sideloaded APK won't update itself. Security fixes only arrive if you go back and download the file again from wherever you found it.</p>
      <p>Data use depends mainly on what you play, not how you open it. Pokies are relatively light after the first load. Live dealer tables are video streams and use much more. Measure your own use instead of trusting anyone's estimate:</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>iPhone:</strong> Settings &gt; Mobile (Mobile Service on newer iOS versions), then scroll to the list of apps. Browser play shows under Safari or Chrome.</li>
          <li><strong>Android:</strong> Settings &gt; Network &amp; internet (Connections on Samsung) &gt; Data usage, then view usage by app. Menu names vary by brand.</li>
        </ul>
      </div>
      <p>If you're on a capped plan, check the figure before and after a session.</p>
      <h3>Logins, notifications and payments</h3>
      <p>Apps and PWAs tend to keep you signed in. That is convenient, and it is also the problem: anyone holding your unlocked phone is one tap from your balance. In a browser, signing out and not saving the password gives you a natural pause.</p>
      <p>Payments work the same way in each format, because the cashier is nearly always a web page. Australian players will recognise PayID and Visa or Mastercard debit options, with amounts shown in AUD ($). Don't assume any of them will go through. Banks may block or decline gambling payments, particularly to offshore merchants. Processing times, fees and withdrawal conditions are in the operator's terms, so read them before depositing. Be just as sceptical of 'app-only' bonuses. They are a marketing claim to verify, not a reason to install anything.</p>
      <p class="see-also">Compare with <a href="/mobile-casino-gaming-apps-vs-browser-2026/">mobile casino gaming apps vs browser 2026</a> and <a href="/mobile-casino-apps-australia/">mobile casino apps in Australia</a>.</p>

      <h2 id="security">Security and privacy: where each option can go wrong</h2>
      <figure class="shot"><?= gw_img('articles/mb-security', 'Chart with a warning mark beside the title Where Each Option Goes Wrong', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Real-money casino services aimed at Australians sit outside local regulation, so nobody is vetting the software or the sites on your behalf. These are the three places it tends to go wrong.</p>
      <h3>Fake apps and unofficial APK downloads</h3>
      <p>An APK from a casino site, a chat group or a 'download' button in an ad has had no independent review. A malicious or cloned file can look identical to the real thing while capturing your login, card details or one-time codes. Red flags include:</p>
      <div class="flags">
        <div class="flag"><h3>Link from a message or ad</h3><p class="bad">A download link that arrives by SMS, social media or pop-up, not from an address you typed yourself</p></div>
        <div class="flag"><h3>Switch off protection</h3><p class="bad">Instructions to switch off Google Play Protect or allow installs from unknown sources</p></div>
        <div class="flag"><h3>Intrusive permissions</h3><p class="bad">Requests for Accessibility access, SMS, contacts or device administrator rights</p></div>
        <div class="flag"><h3>Profiles on iPhone</h3><p class="bad">On iPhone, being told to install a profile or trust an enterprise developer</p></div>
      </div>
      <p>Store listings aren't immune either. Apps can slip through review disguised as something else, so a casino turning up in a store search is not proof it is permitted here.</p>
      <h3>App permissions versus browser cookies</h3>
      <p>An installed app can ask for your location, contacts, photos, files and notifications. A casino game needs almost none of that. On Android, check Settings &gt; Apps &gt; the app &gt; Permissions. On iPhone, look under Settings &gt; Privacy &amp; Security. Remove anything unnecessary, and uninstall the app if it refuses to run without it.</p>
      <p>A browser is more contained. A site can set cookies and ask for location or notifications, and you can refuse, clear site data or use a private tab. It can still track you, and it still holds your ID documents and payment details once you register. 'More contained' does not mean 'private'.</p>
      <h3>Mirror sites and blocked domains</h3>
      <p>ACMA regularly asks Australian internet providers to block illegal gambling sites. Operators respond by moving to new 'mirror' addresses, often passed around by email or chat. That creates two risks. A domain can vanish overnight with your balance on the other side of it. And a lookalike mirror may be a phishing page run by someone else entirely. Getting around a block with a VPN or alternative DNS doesn't change the service's status or give you any protection. You still can't take an offshore casino to an Australian regulator or ombudsman.</p>
      <p class="see-also">More on spotting risky sites: <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos</a>.</p>

      <h2 id="control">Staying in control: notifications, limits and responsible gambling</h2>
      <figure class="shot"><?= gw_img('articles/mb-control', 'Limit sliders beside the title Staying in Control on Mobile', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Gambling is for adults aged 18 and over, and no app, browser or setting improves your chances. The house edge is built into every game. Your phone setup can only change how easy it is to start and how easy it is to stop.</p>
      <h3>Why push notifications matter</h3>
      <p>This is the most underrated difference between formats. An installed app or PWA can put a bonus offer on your lock screen late at night or on payday. A closed browser tab can't, unless you allowed site notifications. Those prompts exist to bring you back, so turn them off under Settings &gt; Notifications on either platform. Decline when a site asks to send notifications in Safari or Chrome, and unsubscribe from marketing emails and texts in your account settings.</p>
      <h3>Limits, BetStop and where to get help</h3>
      <div class="rg-card">
      <p>Decide on a spend and a time limit before you open anything, and treat the money as the cost of entertainment, never as a way to earn. Use deposit and session limits where an operator offers them. Back them up with tools you control: Screen Time on iPhone, Digital Wellbeing on Android, and the gambling blocks some Australian banks offer on cards.</p>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, lets you exclude yourself from licensed Australian online and phone wagering providers in one step. It doesn't extend to offshore casino sites, which is another protection you lose with them. Check the details at betstop.gov.au.</p>
      <p>If gambling is causing stress, debt or arguments, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support around the clock on <a href="tel:1800858858">1800 858 858</a> or at gamblinghelponline.org.au.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Frequently asked questions</h2>
      <div class="faq">
        <details>
          <summary>Are real-money casino apps legal in Australia?</summary>
          <p>No operator can lawfully offer one here. Under the Interactive Gambling Act 2001, providing online casino games such as pokies, roulette or blackjack to people in Australia is prohibited, whether through an app or a website. Licensed apps for sports betting, racing and lotteries are a separate category. ACMA is the regulator, so check <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> for the current position on any service.</p>
        </details>
        <details>
          <summary>Why can't I find casino apps in the App Store or Google Play?</summary>
          <p>Apple and Google restrict real-money gambling apps to operators properly licensed for the country where the app is listed, and online casino services can't lawfully be offered in Australia. What you will find are licensed betting and lottery apps and play-money social casino games. Both companies publish their current gambling rules in their developer policies.</p>
        </details>
        <details>
          <summary>Is it safe to install a casino APK on Android?</summary>
          <p>It carries real risk. A sideloaded APK skips Google Play's review, doesn't update automatically and can request sweeping permissions. A cloned or fake app can be used to steal logins and payment details. The underlying service is also unregulated here, so there is no one to complain to if something goes wrong. A browser exposes far less of your phone.</p>
        </details>
        <details>
          <summary>Do games pay differently in an app than in a browser?</summary>
          <p>No. Game results and return settings are determined on the game provider's or operator's servers, and your phone only displays the outcome. Opening the same game through an app, a PWA or a browser doesn't change the maths. Any claim that one format 'pays better' is marketing, and no format improves your chance of winning.</p>
        </details>
        <details>
          <summary>Does an app use less mobile data than a browser?</summary>
          <p>Not reliably. An app may store some interface files on the phone, but the games and any live video still travel over your connection. What you play matters most, and live dealer tables use much more data than pokies. Check actual use under Settings &gt; Mobile on iPhone, or the data usage screen in Android's network settings.</p>
        </details>
      </div>

      <h2 id="next-step">Your next step: five checks before you tap 'install' or 'play'</h2>
      <figure class="shot"><?= gw_img('articles/mb-next', 'Checklist card beside the title Five Checks Before You Tap Install', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Run through these in order. They take a few minutes, and the first one may settle the question on its own.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Check ACMA first.</strong> Look the service up on ACMA's register and its blocked list. If it offers real-money pokies or table games to Australians, it is a prohibited service whatever licence it advertises.</li>
          <li><strong>Identify the format.</strong> Is it a store app, a home-screen shortcut, an APK or just a website? If nothing came from the App Store or Google Play, it isn't a native app.</li>
          <li><strong>Verify the source.</strong> Never install from a link in a text, ad or chat group. Type addresses yourself and be wary of mirror domains.</li>
          <li><strong>Review permissions.</strong> Deny anything a game doesn't need, refuse notification prompts, and delete any app that insists on SMS, contacts or Accessibility access.</li>
          <li><strong>Set limits before you play.</strong> Fix a budget in AUD and a time limit, switch off promotional notifications, and keep BetStop and Gambling Help Online (<a href="tel:1800858858">1800 858 858</a>) in mind if it stops being fun.</li>
        </ol>
      </div>
      <p>If a service fails the first check, the casino app vs browser question matters far less than who, if anyone, is accountable for your money.</p>
      <p><strong>Related reading:</strong> <a href="/mobile-casino-gaming-apps-vs-browser-2026/">Mobile Casino Gaming Apps vs Browser 2026</a>, <a href="/mobile-casino-apps-australia/">Best Mobile Casino Apps Australia 2026: How to Judge Safety and Quality</a>.</p>

      <?php gw_topic_links($a['slug']); ?>
      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
