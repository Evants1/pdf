<?php
/**
 * Private dashboard (served at /gw-admin/). Not linked from anywhere, not in the sitemap and marked noindex.
 *
 * Protection: login with a hashed password, lockout after 5 failed attempts per 15 minutes, 30-minute idle timeout,
 * a CSRF token on every action, a strict session cookie limited to /gw-admin/, no scripts on the page, and an optional IP
 * allowlist ('allow_ips' in includes/admin-seed.php).
 *
 * Sending: uses PHP mail() in small batches. That is fine for a small list. If your list grows past a few hundred,
 * connect a proper email service.
 */
declare(strict_types=1);

// 1) Optional IP allowlist: anyone else just sees the normal "page not found".
$seed = require __DIR__ . '/includes/admin-seed.php';
if (!empty($seed['allow_ips']) && !in_array($_SERVER['REMOTE_ADDR'] ?? '', (array) $seed['allow_ips'], true)) {
    require __DIR__ . '/404.php';
    exit;
}

require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/newsletter.php';

header('X-Robots-Tag: noindex, nofollow, noarchive');
header('Cache-Control: no-store');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header("Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'");

/* ------------------------------------------------------------------ helpers */

function gwa_head(string $title, bool $nav = false, string $active = ''): void
{
    echo '<!doctype html><html lang="en-AU"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
       . '<meta name="robots" content="noindex,nofollow"><title>' . e($title) . ' | GrandWhisper dashboard</title><style>'
       . ':root{--ink:#1f1b2e;--mut:#6b6880;--line:#e3e0ee;--bg:#f6f5fb;--card:#fff;--acc:#7b2cbf;--bad:#b3261e;--ok:#1e7a4a}'
       . '*{box-sizing:border-box}body{margin:0;font:15px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:var(--ink);background:var(--bg)}'
       . 'a{color:var(--acc)}header.top{background:#241a3d;color:#fff;padding:.7rem 1rem;display:flex;gap:1rem;align-items:center;flex-wrap:wrap}'
       . 'header.top strong{margin-right:.5rem}header.top a{color:#d9ccff;text-decoration:none;padding:.25rem .6rem;border-radius:6px}'
       . 'header.top a.on,header.top a:hover{background:#3a2c63;color:#fff}header.top form{margin-left:auto}'
       . 'main{max-width:1000px;margin:1.2rem auto;padding:0 1rem}h1{font-size:1.4rem;margin:.2rem 0 1rem}h2{font-size:1.1rem;margin:1.6rem 0 .6rem}'
       . '.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:.8rem}.card{background:var(--card);border:1px solid var(--line);border-radius:10px;padding:.9rem 1rem}'
       . '.card b{display:block;font-size:1.7rem;line-height:1.1}.card span{color:var(--mut);font-size:.85rem}'
       . 'table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:10px;overflow:hidden}'
       . 'th,td{padding:.5rem .7rem;border-bottom:1px solid var(--line);text-align:left;vertical-align:top;font-size:.92rem}th{background:#efedf7;font-size:.8rem;text-transform:uppercase;letter-spacing:.03em;color:var(--mut)}'
       . '.wrapx{overflow-x:auto}label{display:block;font-weight:600;margin:.8rem 0 .25rem}input[type=text],input[type=password],input[type=email],input[type=number],select,textarea{width:100%;max-width:560px;padding:.5rem .6rem;border:1px solid #cfcade;border-radius:8px;font:inherit;background:#fff}'
       . 'textarea{min-height:260px;max-width:100%}button,.btn{font:inherit;padding:.45rem .9rem;border-radius:8px;border:1px solid var(--acc);background:var(--acc);color:#fff;cursor:pointer}'
       . 'button.alt{background:#fff;color:var(--acc)}button.del{background:#fff;color:var(--bad);border-color:var(--bad)}button.sm{padding:.2rem .55rem;font-size:.82rem}'
       . '.row{display:flex;gap:.5rem;flex-wrap:wrap;align-items:end}.msg{padding:.6rem .9rem;border-radius:8px;margin:0 0 1rem;border:1px solid}'
       . '.msg.ok{background:#e9f7ef;border-color:#a8dcc0;color:#14532d}.msg.err{background:#fdecea;border-color:#f3b4af;color:#7a1710}.msg.note{background:#fff8e1;border-color:#f0dc9c;color:#5c4a00}'
       . '.pill{display:inline-block;padding:.05rem .5rem;border-radius:99px;font-size:.78rem;border:1px solid var(--line);background:#fff}.pill.confirmed{color:var(--ok);border-color:#a8dcc0}.pill.pending{color:#8a6100;border-color:#f0dc9c}.pill.unsubscribed{color:var(--mut)}'
       . '.muted{color:var(--mut);font-size:.88rem}form.inline{display:inline}.login{max-width:380px;margin:12vh auto}.bar{height:8px;background:#e9e5f5;border-radius:99px;overflow:hidden;max-width:360px}.bar i{display:block;height:100%;background:var(--acc)}'
       . '</style></head><body>';
    if ($nav) {
        $links = ['overview' => 'Overview', 'subs' => 'Subscribers', 'send' => 'Send an email', 'settings' => 'Settings'];
        echo '<header class="top"><strong>GrandWhisper</strong>';
        foreach ($links as $k => $label) {
            echo '<a class="' . ($active === $k ? 'on' : '') . '" href="/gw-admin/?p=' . $k . '">' . e($label) . '</a>';
        }
        echo '<form method="post" action="/gw-admin/"><input type="hidden" name="csrf" value="' . e($_SESSION['csrf'] ?? '') . '"><input type="hidden" name="act" value="logout"><button class="alt sm" type="submit">Log out</button></form></header>';
    }
    echo '<main>';
}

function gwa_foot(): void
{
    echo '</main></body></html>';
}

function gwa_fmt(?string $iso): string
{
    $t = $iso ? strtotime($iso) : false;
    return $t ? gmdate('j M Y H:i', $t) . ' UTC' : '—';
}

function gwa_form(string $act, array $hidden, string $label, string $class = ''): string
{
    $h = '<form class="inline" method="post" action="/gw-admin/"><input type="hidden" name="csrf" value="' . e($_SESSION['csrf'] ?? '') . '"><input type="hidden" name="act" value="' . e($act) . '">';
    foreach ($hidden as $k => $v) {
        $h .= '<input type="hidden" name="' . e($k) . '" value="' . e((string) $v) . '">';
    }
    return $h . '<button class="sm ' . e($class) . '" type="submit">' . e($label) . '</button></form>';
}

function gwa_go(string $to, ?array $flash = null): void
{
    if ($flash) {
        $_SESSION['flash'] = $flash;
    }
    header('Location: /gw-admin/' . $to, true, 303);
    exit;
}

function gwa_csv_cell(string $v): string
{
    if ($v !== '' && strpbrk($v[0], "=+-@\t\r") !== false) {
        $v = "'" . $v;   // stops spreadsheet programs treating a cell as a formula
    }
    return '"' . str_replace('"', '""', $v) . '"';
}

/* ------------------------------------------------------------------ session */

$https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_name('gwadm');
session_set_cookie_params(['lifetime' => 0, 'path' => '/gw-admin/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Strict']);
session_start();
if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}

try {
    $db = gw_db();
} catch (Throwable $e) {
    error_log('GrandWhisper dashboard: ' . $e->getMessage());
    http_response_code(503);
    gwa_head('Unavailable');
    echo '<div class="login"><h1>Dashboard unavailable</h1><p class="muted">The subscriber database could not be opened. On the host, check that the PHP extension <b>pdo_sqlite</b> is enabled and that the <b>data</b> folder is writable, then reload.</p></div>';
    gwa_foot();
    exit;
}

$adminUser  = (string) gw_setting('admin_user');
$adminHash  = (string) gw_setting('admin_hash');
$mustChange = gw_setting('admin_must_change') === '1';
$notice     = null;
$authed     = false;

if (!empty($_SESSION['uid'])) {
    $idle = time() - (int) ($_SESSION['last'] ?? 0);
    $age  = time() - (int) ($_SESSION['start'] ?? 0);
    if ($idle > 1800 || $age > 28800) {
        $_SESSION = [];
        session_regenerate_id(true);
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
        $notice = ['note', 'You were logged out because the session timed out. Please log in again.'];
    } else {
        $authed = true;
        $_SESSION['last'] = time();
    }
}

$method = $_SERVER['REQUEST_METHOD'];
$act    = $method === 'POST' ? (string) ($_POST['act'] ?? '') : '';
$csrfOk = $method === 'POST' && hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''));

/* ------------------------------------------------------------------ login */

if (!$authed) {
    if ($act === 'login') {
        $key = 'login|' . gw_ip_key();
        if (!$csrfOk) {
            $notice = ['err', 'The form expired. Please try again.'];
        } elseif (gw_rate_count($key, 900) >= 5) {
            $notice = ['err', 'Too many failed attempts. Please wait 15 minutes and try again.'];
        } else {
            $uOk = hash_equals($adminUser, trim((string) ($_POST['username'] ?? '')));
            $pOk = password_verify((string) ($_POST['password'] ?? ''), $adminHash);
            if ($uOk && $pOk) {
                session_regenerate_id(true);
                $_SESSION = ['uid' => 1, 'start' => time(), 'last' => time(), 'csrf' => bin2hex(random_bytes(16))];
                gw_rate_clear($key);
                gwa_go('?p=overview');
            }
            gw_rate_add($key);
            usleep(400000);
            $notice = ['err', 'Incorrect username or password.'];
        }
    }
    gwa_head('Log in');
    echo '<div class="login"><h1>Dashboard login</h1>';
    if ($notice) {
        echo '<p class="msg ' . e($notice[0]) . '">' . e($notice[1]) . '</p>';
    }
    echo '<form method="post" action="/gw-admin/" autocomplete="off"><input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '"><input type="hidden" name="act" value="login">'
       . '<label for="u">Username</label><input id="u" type="text" name="username" required autofocus>'
       . '<label for="p">Password</label><input id="p" type="password" name="password" required>'
       . '<p><button type="submit">Log in</button></p></form></div>';
    gwa_foot();
    exit;
}

/* ------------------------------------------------------------------ actions (logged in) */

if ($method === 'POST') {
    if (!$csrfOk) {
        http_response_code(403);
        gwa_head('Blocked', true);
        echo '<p class="msg err">That request was blocked because its security token did not match. Go back, reload the page and try again.</p>';
        gwa_foot();
        exit;
    }
    if ($act === 'logout') {
        $_SESSION = [];
        session_destroy();
        header('Location: /gw-admin/', true, 303);
        exit;
    }
    if ($act === 'change_password') {
        $cur = (string) ($_POST['current'] ?? '');
        $new = (string) ($_POST['new'] ?? '');
        $rep = (string) ($_POST['repeat'] ?? '');
        if (!password_verify($cur, $adminHash)) {
            gwa_go('?p=settings', ['err', 'Your current password is not correct.']);
        } elseif (strlen($new) < 12) {
            gwa_go('?p=settings', ['err', 'The new password must be at least 12 characters.']);
        } elseif ($new !== $rep) {
            gwa_go('?p=settings', ['err', 'The two new passwords do not match.']);
        } elseif ($new === $cur) {
            gwa_go('?p=settings', ['err', 'Please choose a password different from the current one.']);
        }
        gw_set_setting('admin_hash', password_hash($new, PASSWORD_DEFAULT));
        gw_set_setting('admin_must_change', '0');
        session_regenerate_id(true);
        gwa_go('?p=settings', ['ok', 'Password changed. Use the new one next time you log in.']);
    }
    if ($mustChange) {
        gwa_go('?p=settings', ['note', 'Please choose your own password first.']);
    }

    if ($act === 'delete' || $act === 'unsub' || $act === 'resend') {
        $id = (int) ($_POST['id'] ?? 0);
        $st = $db->prepare('SELECT * FROM subscribers WHERE id = ?');
        $st->execute([$id]);
        $row = $st->fetch();
        if (!$row) {
            gwa_go('?p=subs', ['err', 'That subscriber no longer exists.']);
        }
        if ($act === 'delete') {
            $db->prepare('DELETE FROM subscribers WHERE id = ?')->execute([$id]);
            gwa_go('?p=subs', ['ok', 'Deleted ' . $row['email'] . ' completely.']);
        }
        if ($act === 'unsub') {
            $db->prepare('UPDATE subscribers SET status = \'unsubscribed\', unsubscribed_at = ? WHERE id = ?')->execute([gmdate('c'), $id]);
            gwa_go('?p=subs', ['ok', $row['email'] . ' marked as unsubscribed.']);
        }
        if ($row['status'] !== 'pending') {
            gwa_go('?p=subs', ['err', 'Only pending sign-ups can be sent a confirmation email.']);
        }
        $db->prepare('UPDATE subscribers SET confirm_token = ? WHERE id = ?')->execute([gw_nl_token(), $id]);
        $ok = gw_nl_send_confirmation(gw_nl_find($row['email']));
        gwa_go('?p=subs&status=pending', $ok ? ['ok', 'Confirmation email sent to ' . $row['email'] . '.'] : ['err', 'The server would not send the email to ' . $row['email'] . '.']);
    }

    if ($act === 'confirm_pending') {
        $rows = $db->query('SELECT * FROM subscribers WHERE status = \'pending\' AND confirm_sent_at IS NULL ORDER BY id LIMIT 25')->fetchAll();
        $ok = $bad = 0;
        foreach ($rows as $row) {
            $db->prepare('UPDATE subscribers SET confirm_token = ? WHERE id = ?')->execute([gw_nl_token(), $row['id']]);
            gw_nl_send_confirmation(gw_nl_find($row['email'])) ? $ok++ : $bad++;
            usleep(200000);
        }
        gwa_go('?p=overview', ['ok', "Confirmation emails sent: $ok" . ($bad ? ", failed: $bad" : '') . '. Run it again if more are waiting.']);
    }

    if ($act === 'export') {
        $scope = ($_POST['scope'] ?? 'confirmed') === 'all' ? 'all' : 'confirmed';
        $rows  = $scope === 'all'
            ? $db->query('SELECT email,status,source,created_at,confirmed_at,unsubscribed_at FROM subscribers ORDER BY id')->fetchAll()
            : $db->query('SELECT email,status,source,created_at,confirmed_at,unsubscribed_at FROM subscribers WHERE status = \'confirmed\' ORDER BY id')->fetchAll();
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="grandwhisper-subscribers-' . $scope . '-' . gmdate('Y-m-d') . '.csv"');
        echo "email,status,source,signed_up,confirmed,unsubscribed\n";
        foreach ($rows as $r) {
            echo implode(',', array_map('gwa_csv_cell', array_map('strval', array_values($r)))) . "\n";
        }
        exit;
    }

    if ($act === 'test' || $act === 'send' || $act === 'next') {
        $subject = trim((string) ($_POST['subject'] ?? ''));
        $body    = trim(str_replace("\r\n", "\n", (string) ($_POST['body'] ?? '')));
        $batch   = max(1, min(50, (int) ($_POST['batch'] ?? 25)));
        if ($act === 'next') {
            $cid = (int) ($_POST['cid'] ?? 0);
            $res = gw_nl_send_batch($cid, $batch);
            $pr  = gw_nl_campaign_progress($cid);
            gwa_go('?p=send', ['ok', "Batch finished: {$res['sent']} sent" . ($res['failed'] ? ", {$res['failed']} failed" : '') . ". {$pr['remaining']} still to go."]);
        }
        if ($subject === '' || strlen($subject) > 150 || $body === '' || strlen($body) > 20000) {
            gwa_go('?p=send', ['err', 'Please enter a subject (up to 150 characters) and a message (up to 20,000 characters).']);
        }
        if ($act === 'test') {
            $to = trim((string) ($_POST['to'] ?? ''));
            if (!gw_nl_valid($to)) {
                gwa_go('?p=send', ['err', 'Please enter a valid address to send the test to.']);
            }
            $ok = gw_mail($to, '[TEST] ' . $subject, $body . gw_nl_footer(null));
            gwa_go('?p=send', $ok ? ['ok', "Test email sent to $to. Check the inbox and the spam folder."] : ['err', 'The server would not send the test email.']);
        }
        if (empty($_POST['confirm'])) {
            gwa_go('?p=send', ['err', 'Please tick the box to confirm before sending to your subscribers.']);
        }
        if (gw_nl_counts()['confirmed'] < 1) {
            gwa_go('?p=send', ['err', 'There are no confirmed subscribers to send to yet.']);
        }
        $cid = gw_nl_campaign_create($subject, $body);
        $res = gw_nl_send_batch($cid, $batch);
        $pr  = gw_nl_campaign_progress($cid);
        gwa_go('?p=send', ['ok', "Sending started: {$res['sent']} sent" . ($res['failed'] ? ", {$res['failed']} failed" : '') . ". {$pr['remaining']} still to go. Press 'Send next batch' to continue."]);
    }
    gwa_go('?p=overview');
}

/* ------------------------------------------------------------------ views */

$view = (string) ($_GET['p'] ?? 'overview');
if (!in_array($view, ['overview', 'subs', 'send', 'settings'], true) || $mustChange) {
    $view = $mustChange ? 'settings' : 'overview';
}
$flash = $_SESSION['flash'] ?? $notice;
unset($_SESSION['flash']);

gwa_head(ucfirst($view), true, $view);
if ($flash) {
    echo '<p class="msg ' . e($flash[0]) . '">' . e($flash[1]) . '</p>';
}

if ($view === 'overview') {
    $c = gw_nl_counts();
    $n7  = (int) $db->query('SELECT COUNT(*) FROM subscribers WHERE confirmed_at >= \'' . gmdate('c', time() - 7 * 86400) . '\'')->fetchColumn();
    $n30 = (int) $db->query('SELECT COUNT(*) FROM subscribers WHERE confirmed_at >= \'' . gmdate('c', time() - 30 * 86400) . '\'')->fetchColumn();
    $legacy = (int) $db->query('SELECT COUNT(*) FROM subscribers WHERE status = \'pending\' AND confirm_sent_at IS NULL')->fetchColumn();
    echo '<h1>Overview</h1><div class="cards">'
       . '<div class="card"><b>' . $c['confirmed'] . '</b><span>Confirmed subscribers</span></div>'
       . '<div class="card"><b>' . $c['pending'] . '</b><span>Waiting to confirm</span></div>'
       . '<div class="card"><b>' . $c['unsubscribed'] . '</b><span>Unsubscribed</span></div>'
       . '<div class="card"><b>' . $n7 . '</b><span>New in the last 7 days</span></div>'
       . '<div class="card"><b>' . $n30 . '</b><span>New in the last 30 days</span></div></div>';
    if ($legacy > 0) {
        echo '<h2>Sign-ups waiting for a confirmation email</h2><p class="muted">' . $legacy . ' address(es) were collected before confirmation existed. They cannot receive newsletters until they confirm. Send them a one-off confirmation request, 25 at a time.</p>'
           . gwa_form('confirm_pending', [], 'Email confirmation requests (up to 25)');
    }
    echo '<h2>Latest sign-ups</h2><div class="wrapx"><table><tr><th>Email</th><th>Status</th><th>Signed up</th></tr>';
    foreach ($db->query('SELECT email,status,created_at FROM subscribers ORDER BY id DESC LIMIT 8') as $r) {
        echo '<tr><td>' . e($r['email']) . '</td><td><span class="pill ' . e($r['status']) . '">' . e($r['status']) . '</span></td><td>' . e(gwa_fmt($r['created_at'])) . '</td></tr>';
    }
    echo '</table></div><h2>System check</h2><table>'
       . '<tr><td>Database</td><td>SQLite ' . e((string) $db->query('select sqlite_version()')->fetchColumn()) . ', ' . e(number_format((int) @filesize(gw_nl_dir() . '/gw.sqlite') / 1024, 1)) . ' KB</td></tr>'
       . '<tr><td>Data folder writable</td><td>' . (is_writable(gw_nl_dir()) ? 'Yes' : '<b>No</b>') . '</td></tr>'
       . '<tr><td>Email sending</td><td>' . (function_exists('mail') ? 'PHP mail() is available' : '<b>mail() is disabled on this server</b>') . ', sent from ' . e(MAIL_FROM) . ', replies go to ' . e(CONTACT_EMAIL) . '</td></tr>'
       . '</table><p class="muted">For emails to reach inboxes, make sure SPF, DKIM and DMARC are set up for grandwhisper.com in Hostinger, and that the mailboxes above exist.</p>';
}

if ($view === 'subs') {
    $status = in_array($_GET['status'] ?? '', ['confirmed', 'pending', 'unsubscribed'], true) ? (string) $_GET['status'] : '';
    $q      = trim((string) ($_GET['q'] ?? ''));
    $page   = max(1, (int) ($_GET['page'] ?? 1));
    $per    = 50;
    $where  = [];
    $args   = [];
    if ($status !== '') {
        $where[] = 'status = ?';
        $args[]  = $status;
    }
    if ($q !== '') {
        $where[] = 'email LIKE ? ESCAPE \'\\\'';
        $args[]  = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
    }
    $w  = $where ? 'WHERE ' . implode(' AND ', $where) : '';
    $st = $db->prepare("SELECT COUNT(*) FROM subscribers $w");
    $st->execute($args);
    $total = (int) $st->fetchColumn();
    $pages = max(1, (int) ceil($total / $per));
    $page  = min($page, $pages);
    $st = $db->prepare("SELECT * FROM subscribers $w ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
    $st->execute($args);
    $rows = $st->fetchAll();
    $qs = http_build_query(array_filter(['p' => 'subs', 'status' => $status, 'q' => $q]));

    echo '<h1>Subscribers</h1><form class="row" method="get" action="/gw-admin/"><input type="hidden" name="p" value="subs">'
       . '<div><label for="f-s">Show</label><select id="f-s" name="status"><option value="">All</option>';
    foreach (['confirmed', 'pending', 'unsubscribed'] as $s) {
        echo '<option value="' . $s . '"' . ($status === $s ? ' selected' : '') . '>' . ucfirst($s) . '</option>';
    }
    echo '</select></div><div><label for="f-q">Search email</label><input id="f-q" type="text" name="q" value="' . e($q) . '" maxlength="60"></div><div><button type="submit">Filter</button></div></form>'
       . '<p class="muted">' . $total . ' result(s). Export: ' . gwa_form('export', ['scope' => 'confirmed'], 'Confirmed (CSV)', 'alt') . ' ' . gwa_form('export', ['scope' => 'all'], 'Everyone (CSV)', 'alt') . '</p>'
       . '<div class="wrapx"><table><tr><th>Email</th><th>Status</th><th>Source</th><th>Signed up</th><th>Confirmed</th><th>Actions</th></tr>';
    foreach ($rows as $r) {
        echo '<tr><td>' . e($r['email']) . '</td><td><span class="pill ' . e($r['status']) . '">' . e($r['status']) . '</span></td><td>' . e($r['source']) . '</td><td>' . e(gwa_fmt($r['created_at'])) . '</td><td>' . e(gwa_fmt($r['confirmed_at'])) . '</td><td>';
        if ($r['status'] === 'pending') {
            echo gwa_form('resend', ['id' => $r['id']], 'Resend confirmation', 'alt') . ' ';
        }
        if ($r['status'] !== 'unsubscribed') {
            echo gwa_form('unsub', ['id' => $r['id']], 'Unsubscribe', 'alt') . ' ';
        }
        echo gwa_form('delete', ['id' => $r['id']], 'Delete', 'del') . '</td></tr>';
    }
    if (!$rows) {
        echo '<tr><td colspan="6" class="muted">No subscribers match.</td></tr>';
    }
    echo '</table></div>';
    if ($pages > 1) {
        echo '<p class="muted">Page ' . $page . ' of ' . $pages . ': ';
        if ($page > 1) {
            echo '<a href="/gw-admin/?' . e($qs) . '&amp;page=' . ($page - 1) . '">Previous</a> ';
        }
        if ($page < $pages) {
            echo '<a href="/gw-admin/?' . e($qs) . '&amp;page=' . ($page + 1) . '">Next</a>';
        }
        echo '</p>';
    }
    echo '<p class="muted">Delete removes a person completely. Unsubscribe keeps a do-not-email record so they are not added again by mistake.</p>';
}

if ($view === 'send') {
    $c = gw_nl_counts();
    echo '<h1>Send an email</h1><p class="muted">This goes to your <b>' . $c['confirmed'] . '</b> confirmed subscriber(s) only, in small batches. Every email gets a one-click unsubscribe link, the business details and a short responsible-gambling line added automatically. Plain text only.</p>'
       . '<form method="post" action="/gw-admin/"><input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '">'
       . '<label for="subj">Subject</label><input id="subj" type="text" name="subject" maxlength="150" required>'
       . '<label for="body">Message</label><textarea id="body" name="body" maxlength="20000" required></textarea>'
       . '<label for="to">Send a test to</label><input id="to" type="email" name="to" value="' . e(CONTACT_EMAIL) . '" maxlength="120">'
       . '<div class="row"><div><label for="batch">Batch size</label><select id="batch" name="batch"><option>10</option><option selected>25</option><option>50</option></select></div></div>'
       . '<label><input type="checkbox" name="confirm" value="1"> I have sent myself a test and the message is ready for my subscribers.</label>'
       . '<p class="row"><button class="alt" type="submit" name="act" value="test">Send test only</button> <button type="submit" name="act" value="send">Send to subscribers</button></p></form>';
    echo '<h2>Previous emails</h2><div class="wrapx"><table><tr><th>Subject</th><th>Created</th><th>Sent</th><th>Failed</th><th>To go</th><th></th></tr>';
    $camps = $db->query('SELECT * FROM campaigns ORDER BY id DESC LIMIT 20')->fetchAll();
    foreach ($camps as $cp) {
        $pr = gw_nl_campaign_progress((int) $cp['id']);
        echo '<tr><td>' . e($cp['subject']) . '</td><td>' . e(gwa_fmt($cp['created_at'])) . '</td><td>' . $pr['sent'] . '</td><td>' . $pr['failed'] . '</td><td>' . $pr['remaining'] . '</td><td>';
        if ($pr['remaining'] > 0) {
            echo gwa_form('next', ['cid' => $cp['id'], 'batch' => 25], 'Send next batch');
        }
        echo '</td></tr>';
    }
    if (!$camps) {
        echo '<tr><td colspan="6" class="muted">Nothing sent yet.</td></tr>';
    }
    echo '</table></div><p class="muted">If "Failed" is above zero the server refused those messages (usually a mailbox or hosting email limit). Those people are not retried automatically.</p>';
}

if ($view === 'settings') {
    echo '<h1>Settings</h1>';
    if ($mustChange) {
        echo '<p class="msg note"><b>First login:</b> please choose your own password now. The starting password is only for this first visit.</p>';
    }
    echo '<h2>Change password</h2><form method="post" action="/gw-admin/" autocomplete="off"><input type="hidden" name="csrf" value="' . e($_SESSION['csrf']) . '"><input type="hidden" name="act" value="change_password">'
       . '<label for="c">Current password</label><input id="c" type="password" name="current" required>'
       . '<label for="n">New password (at least 12 characters)</label><input id="n" type="password" name="new" minlength="12" required>'
       . '<label for="r">Repeat new password</label><input id="r" type="password" name="repeat" minlength="12" required>'
       . '<p><button type="submit">Change password</button></p></form>'
       . '<h2>Good to know</h2><ul class="muted"><li>Username: <b>' . e($adminUser) . '</b>. You are logged out after 30 minutes without activity.</li>'
       . '<li>After 5 wrong passwords from one connection, login is blocked for 15 minutes.</li>'
       . '<li>To limit the dashboard to your own connection, list your IP address under <b>allow_ips</b> in <b>includes/admin-seed.php</b>. Anyone else will see "page not found". Only do this if your IP address is stable.</li>'
       . '<li>Back up <b>data/gw.sqlite</b> from the hosting file manager now and then. Never upload over the <b>data</b> folder.</li></ul>';
}
gwa_foot();
