<?php
/** Site search (served at /search/?q=term). Noindex: search result pages should not appear in Google. */
require __DIR__ . '/includes/functions.php';

$q = trim((string) ($_GET['q'] ?? ''));
$q = preg_replace('/\s+/', ' ', $q);
$q = mb_substr($q, 0, 80);
$results = [];

if ($q !== '') {
    $terms = array_filter(explode(' ', mb_strtolower($q)), fn($t) => mb_strlen($t) >= 2);

    // Build a searchable list of articles and pages.
    $items = [];
    foreach (gw_articles() as $a) {
        $items[] = ['title' => $a['title'], 'url' => '/' . $a['slug'] . '/', 'text' => $a['excerpt'] . ' ' . $a['description'], 'kind' => gw_category($a['category'])['label'], 'blurb' => $a['excerpt']];
    }
    foreach (gw_pages() as $p) {
        $items[] = ['title' => $p['title'], 'url' => $p['path'], 'text' => $p['summary'], 'kind' => 'Guide', 'blurb' => $p['summary']];
    }
    foreach (gw_site_pages() as $p) {
        $items[] = ['title' => $p['title'], 'url' => $p['path'], 'text' => $p['summary'], 'kind' => 'Page', 'blurb' => $p['summary']];
    }

    foreach ($items as $it) {
        $title = mb_strtolower($it['title']);
        $text  = mb_strtolower($it['text']);
        $score = 0;
        foreach ($terms as $t) {
            $inTitle = mb_strpos($title, $t) !== false;
            $inText  = mb_strpos($text, $t) !== false;
            if (!$inTitle && !$inText) { $score = 0; break; }   // every word must match
            $score += $inTitle ? 3 : 1;
        }
        if ($score > 0) { $it['score'] = $score; $results[] = $it; }
    }
    usort($results, fn($a, $b) => $b['score'] <=> $a['score']);
}

$seo = [
    'title'       => 'Search',
    'description' => 'Search GrandWhisper for casino guides, bonus explainers, payment method comparisons and safety advice.',
    'path'        => '/search/',
    'robots'      => 'noindex,follow',
    'body_class'  => 'is-search',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap search-page">
    <h1>Search</h1>
    <form class="search" role="search" action="/search/" method="get">
      <label class="sr" for="page-q">Search the magazine</label>
      <input id="page-q" type="search" name="q" value="<?= e($q) ?>" placeholder="Try: withdrawals, bonuses, crypto" maxlength="80" required>
      <button type="submit">Search</button>
    </form>

<?php if ($q === ''): ?>
    <p>Type a word or two above. Or start with one of our guides:</p>
    <ul class="chips">
      <li><a href="/best-online-casinos/">Best online casinos</a></li>
      <li><a href="/online-casino-bonuses/">Bonuses</a></li>
      <li><a href="/online-casino-payment-methods/">Payment methods</a></li>
      <li><a href="/safe-and-trusted-online-casinos/">Safe casinos</a></li>
    </ul>
<?php elseif (!$results): ?>
    <p>Nothing matched <strong><?= e($q) ?></strong>. Try a shorter or more general word, or browse the <a href="/category/casino-guides/">casino guides</a> and <a href="/category/casino-news/">casino news</a>.</p>
<?php else: ?>
    <p><?= count($results) ?> result<?= count($results) === 1 ? '' : 's' ?> for <strong><?= e($q) ?></strong></p>
    <ul class="results">
<?php foreach ($results as $r): ?>
      <li>
        <span class="kind"><?= e($r['kind']) ?></span><br>
        <a href="<?= e($r['url']) ?>"><?= e($r['title']) ?></a>
        <p><?= e($r['blurb']) ?></p>
      </li>
<?php endforeach; ?>
    </ul>
<?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
