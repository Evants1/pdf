# GrandWhisper.com: Installation Guide (Hostinger shared hosting)

This is a plain PHP website. There is **no database, no Node.js and no build step**. Upload the files, edit one config file, and the site works.

You can delete this file after installing. The included `.htaccess` stops it being downloaded anyway.

---

## 1. Requirements

| Item | Needed |
|---|---|
| Hosting | Hostinger shared hosting (or any Apache/LiteSpeed host that reads `.htaccess`) |
| PHP | 7.4 or newer. 8.1+ recommended (hPanel > Advanced > PHP Configuration) |
| PHP extensions | `mbstring` (enabled by default on Hostinger) |
| Database | **None.** MySQL is not used by this site |
| SSL | Free SSL from hPanel (Security > SSL), installed **before** step 4 |

## 2. Upload the files

1. In hPanel, open **Files > File Manager** and go into `public_html`.
2. Delete Hostinger's default placeholder (`default.php` or similar) if it is there.
3. Upload `GrandWhisper-Website.zip` into `public_html` and choose **Extract** so the files sit directly in `public_html` (not in a sub-folder). You should see `index.php`, `.htaccess`, `includes/`, `assets/` and so on right inside `public_html`.
4. **Check that `.htaccess` is there.** It is a hidden file. In File Manager, open Settings and tick "Show hidden files". If you use FTP, make sure your client shows hidden files.
5. Delete the ZIP file from `public_html` once extracted.

Suggested permissions (Hostinger's defaults are fine): folders `755`, files `644`. The `data/` folder must be writable by PHP if you keep the newsletter (it normally is).

## 3. Edit the configuration

Open `includes/config.php` and set:

| Setting | What it does |
|---|---|
| `SITE_URL` | Your live address with `https://` and **no trailing slash**. Used for canonical URLs, the sitemap, social tags and structured data |
| `CONTACT_EMAIL` | Where contact-form messages are delivered |
| `MAIL_FROM` | Sender address for those messages. **Must be a mailbox on your own domain** (create it in hPanel > Emails) or Hostinger may not deliver the mail |
| `HERO_SLUG` | Which article is featured in the homepage hero |
| `ASSET_VERSION` | Increase the number after you edit `style.css` or `main.js` so visitors get the new file |

Also open `robots.txt` and update the `Sitemap:` line if your domain is different from `grandwhisper.com`.

## 4. Turn on HTTPS

1. In hPanel, install the free SSL certificate for the domain and wait until it shows as active.
2. Visit `https://grandwhisper.com`. The `.htaccess` file already redirects `http://` to `https://` and `www.` to the bare domain.
3. If you use Cloudflare, set SSL/TLS mode to **Full (strict)**, not "Flexible", otherwise the redirect can loop.
4. Optional: once everything works on HTTPS, uncomment the `Strict-Transport-Security` line in `.htaccess`.

## 5. Launch checks

- [ ] Home page loads at the domain root, and the images appear.
- [ ] Open a few pages (for example `/best-online-casinos/` and `/category/casino-news/`). Clean URLs with a trailing slash should all load.
- [ ] `/sitemap.xml` shows XML and `/robots.txt` shows the rules.
- [ ] Send a test message through `/contact/` and confirm it arrives.
- [ ] Try the search box. Subscribe once with a test address on the homepage, then check `data/subscribers.csv` in File Manager.
- [ ] Visit a made-up URL such as `/nothing-here/` and confirm the friendly 404 page appears.
- [ ] Submit `https://grandwhisper.com/sitemap.xml` in Google Search Console and Bing Webmaster Tools.

## 6. How the site is organised

```
public_html/
├── index.php                      Homepage (own layout)
├── about.php  contact.php  privacy-policy.php
├── terms-and-conditions.php  responsible-gambling.php
├── best-online-casinos.php        The five permanent landing pages
├── online-casino-reviews.php      (each has its own layout and content)
├── online-casino-bonuses.php
├── online-casino-payment-methods.php
├── safe-and-trusted-online-casinos.php
├── search.php  subscribe.php  404.php  sitemap.xml.php  robots.txt
├── articles/                      One PHP file per article (10 starter articles)
├── categories/                    casino-news.php, casino-guides.php
├── includes/
│   ├── config.php                 Site settings
│   ├── content.php                List of articles and pages (cards, SEO titles, dates)
│   ├── functions.php              Small helper functions, SEO head output, schema
│   ├── header.php  footer.php     The only shared page parts
│   └── .htaccess                  Blocks direct web access
├── assets/ css/style.css  js/main.js  images/
├── data/                          Newsletter list (blocked from the web)
└── .htaccess                      Clean URLs, HTTPS, security, caching
```

URL mapping (done by `.htaccess`, no routing code):

| Visitor opens | File served |
|---|---|
| `/` | `index.php` |
| `/about/`, `/best-online-casinos/` ... | `about.php`, `best-online-casinos.php` ... |
| `/category/casino-news/` | `categories/casino-news.php` |
| `/how-casino-welcome-bonuses-work/` | `articles/how-casino-welcome-bonuses-work.php` |
| `/sitemap.xml` | `sitemap.xml.php` |

Old-style addresses such as `/about.php` or `/articles/x.php` redirect (301) to the clean URL.

## 7. Everyday editing

**Edit a page's text:** open its `.php` file in File Manager and change the HTML. Every page is its own file, so changing one never affects another.

**Edit an article's title, description, excerpt or dates:** change its entry in `includes/content.php`. That one entry controls the article's card, SEO title, meta description, Open Graph data and sitemap date. Update the `updated` date when you revise an article.

**Add a new article:**
1. Copy any file in `articles/` to a new name, for example `articles/my-new-article.php`. The name (without `.php`) becomes the URL: `/my-new-article/`.
2. Inside the copy, change the slug in `gw_article('...')`, the table of contents and the article text.
3. Add a matching entry to `gw_articles_all()` in `includes/content.php` (slug, title, seo_title, description, excerpt, category, date, updated, alt, minutes, related).
4. Add images to `assets/images/articles/`: `my-new-article.webp` (1200x675), `my-new-article-600.webp` (600x338) and `my-new-article.jpg` (1200x630, used for social sharing).
5. The homepage, category page, search, sitemap and related-article blocks update automatically.

**Add a new permanent page:** copy one of the root pages, change the `$seo` array and content, then add it to `gw_pages()` or `gw_site_pages()` in `includes/content.php` so it appears in the sitemap and search.

**Change colours or fonts:** all design tokens are at the top of `assets/css/style.css` (`:root`). The site uses system fonts, so there are no font downloads.

**Hero article:** change `HERO_SLUG` in `config.php`.

## 8a. Australian focus and legal care

The site is written for readers in Australia (en-AU locale, AUD context, Australian help services, 18+ wording). Under the Interactive Gambling Act 2001, offering online casino games to people in Australia is prohibited, and ACMA enforces it. Advertising or affiliate promotion of offshore casinos to Australians can carry legal and reputational risk. This build therefore lists no casino operators and keeps its casino content educational. **Get advice from an Australian lawyer before adding operator links or promotional content.**

### Comparison tables

The five permanent pages show a comparison table from `includes/comparison.php`. The four brands in it are **fictional samples** (every figure invented) and are labelled as an illustrative example, with no outbound links. To use real data, edit `gw_comparison_brands()`, add each brand's `url`, then set `GW_COMPARISON_IS_SAMPLE` to `false`. The button then reads "Claim Bonus Now" (change `GW_CTA_LABEL`), and `'url' => '#'` works as a placeholder until you have your real tracking links. Add logos to `assets/images/brands/` and reference them with `'logo' => 'file.webp'`. Only publish facts you have verified, show the date you checked them, and get Australian legal advice first.

## 8. Things you must do before relying on this site

These are important. The content was written without access to live search data or your business details.

1. **Review all facts.** The articles are general, evergreen explainers and deliberately avoid current offers, named operators and statistics. Regulation and licensing summaries (especially in *How Online Casino Regulation Differs by Region*), help-organisation names and links, and any bonus or payment details must be checked against current official sources. Update the `updated` date when you do.
2. **Research real search demand.** Use Google Search Console, Google Trends or your SEO tool to confirm which topics to expand. The homepage "Trending casino topics" list is a hand-picked list, not live data. Edit it in `index.php` to match what you find.
3. **Add real operator reviews and affiliate links** only for operators you have personally verified (licence, terms, banking). `best-online-casinos.php` contains a commented template. Use `rel="sponsored nofollow noopener"` on affiliate links. Make sure the methods described on `online-casino-reviews.php` match what you actually do.
4. **Legal pages.** The privacy policy, terms and responsible gambling pages are starter texts that match what this code does. Have them reviewed for your jurisdiction, and update them if you add analytics, ads or other tracking.
5. **Local gambling advertising rules.** Many countries regulate how gambling can be marketed and require licences or specific warnings for affiliates. Check the rules for every market you target.
6. **Newsletter.** Sign-ups are saved to `data/subscribers.csv` with no confirmation email. For a real newsletter, connect an email-marketing service with double opt-in and an unsubscribe link, and update the privacy policy.
7. **Images.** The illustrations are original artwork generated for this project (no stock photos, nothing to license). Replace them with your own photography if you prefer. Keep the same file names and sizes.

## 9. Troubleshooting

| Problem | Likely fix |
|---|---|
| Every page except the homepage shows a 404 | `.htaccess` is missing. Re-upload it with hidden files shown |
| 500 error after upload | Rename `.htaccess` temporarily. If the site loads, the host dislikes a directive: email Hostinger support with the line that fails |
| Redirect loop after enabling HTTPS | Check Cloudflare SSL mode (use Full strict) and that the SSL certificate is active |
| Contact form says it could not send | `MAIL_FROM` must be a mailbox on your domain. Check spam folders too |
| CSS changes do not show | Increase `ASSET_VERSION` in `config.php` and clear any caching plugin or CDN cache |
| Blank page | Temporarily add `ini_set('display_errors','1');` at the top of `includes/config.php` to see the error, then remove it |

## 10. What is in the build

- 1 homepage, 5 permanent SEO pages, 10 starter articles, 2 category pages, About, Contact, Privacy, Terms, Responsible Gambling, Search, Newsletter, 404
- Canonical URLs, unique titles and meta descriptions, Open Graph and Twitter/X cards
- JSON-LD: Organization, WebSite (with search action), BreadcrumbList on every inner page, Article on articles
- XML sitemap generated automatically, `robots.txt`, `noindex` on search, newsletter and 404 pages
- Responsive layout, accessible navigation (skip link, keyboard-friendly menu, visible focus), lazy-loaded images with `srcset`, WebP artwork, system fonts, one small CSS file and one tiny JavaScript file
- Pagination is not needed at this size (the category pages list every article). If a category grows past about 20 articles, add pagination to that category file.
