<?php
/**
 * Unsubscribe (served at /unsubscribe/?t=TOKEN). The token is personal to each subscriber and is in every newsletter.
 * GET shows a confirm button (so email scanners cannot unsubscribe people). POST unsubscribes. The POST also works when a mail
 * app uses the List-Unsubscribe one-click header (the token is then in the query string).
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/newsletter.php';

$token = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$state = 'invalid';   // valid | done | already | invalid | down
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $res   = gw_nl_unsubscribe($token);
        $state = $res === 'ok' ? 'done' : $res;
    } else {
        $row   = gw_nl_by_token('unsub_token', $token);
        $state = !$row ? 'invalid' : ($row['status'] === 'unsubscribed' ? 'already' : 'valid');
    }
} catch (Throwable $e) {
    error_log('GrandWhisper newsletter unsubscribe failed: ' . get_class($e));
    $state = 'down';
}

header('Referrer-Policy: no-referrer');
$seo = [
    'title'       => 'Unsubscribe',
    'description' => 'Unsubscribe from the GrandWhisper newsletter.',
    'path'        => '/unsubscribe/',
    'robots'      => 'noindex,nofollow',
    'no_canonical'=> true,
    'body_class'  => 'is-doc',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap search-page">
    <h1>Unsubscribe</h1>
<?php if ($state === 'valid'): ?>
    <p>Press the button to stop receiving GrandWhisper emails.</p>
    <form class="form" action="/unsubscribe/" method="post">
      <input type="hidden" name="t" value="<?= e($token) ?>">
      <button class="btn btn--ruby" type="submit">Unsubscribe me</button>
    </form>
<?php elseif ($state === 'done'): ?>
    <p class="alert alert--ok" role="status">You have been unsubscribed. We will not email you again. We keep your address on a do-not-email record so you are not added by mistake. If you would like it deleted completely, <a href="/contact/">contact us</a>.</p>
    <p><a href="/">Back to the magazine</a></p>
<?php elseif ($state === 'already'): ?>
    <p class="alert alert--ok" role="status">You are already unsubscribed. Nothing more to do.</p>
    <p><a href="/">Back to the magazine</a></p>
<?php elseif ($state === 'down'): ?>
    <p class="alert alert--err" role="alert">Sorry, we could not process this just now. Please try again later or <a href="/contact/">contact us</a> and we will remove you.</p>
<?php else: ?>
    <p class="alert alert--err" role="alert">This unsubscribe link is not valid. If you would like to stop receiving emails, please <a href="/contact/">contact us</a> and we will remove you.</p>
<?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
