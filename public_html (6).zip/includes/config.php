<?php
/**
 * GrandWhisper - site configuration.
 * Edit the values below, then upload. No database is used.
 */

// Production address WITHOUT a trailing slash. Used for canonical URLs,
// the XML sitemap, Open Graph tags and structured data.
define('SITE_URL', 'https://grandwhisper.com');

define('SITE_NAME', 'GrandWhisper');
define('SITE_TAGLINE', 'Casino magazine for Australia');

// Where contact-form messages are delivered. Create this mailbox in hPanel > Emails.
define('CONTACT_EMAIL', 'contact@grandwhisper.com');
// Sender used for outgoing mail. Must be a mailbox on your own domain for Hostinger to deliver it.
define('MAIL_FROM', 'no-reply@grandwhisper.com');

// Article shown in the homepage hero ("editor's pick"). Use any article slug.
define('HERO_SLUG', 'how-casino-welcome-bonuses-work');

// Bump this number after editing style.css or main.js so browsers fetch the new file.
define('ASSET_VERSION', '1');

// Never show PHP errors to visitors on the live site.
ini_set('display_errors', '0');
error_reporting(E_ALL);
date_default_timezone_set('UTC');
