<?php
/**
 * Newsletter system for GrandWhisper.
 *
 * - Subscribers live in a SQLite database at data/gw.sqlite (created automatically on first use).
 *   The data/ folder is blocked from the web by .htaccess (rule 3 and data/.htaccess).
 * - Double opt-in: a sign-up is "pending" until the person clicks the link in the confirmation email.
 * - Every newsletter carries a one-click unsubscribe link, the sender's identity and contact details (Spam Act 2003).
 * - Requires the PHP extension pdo_sqlite (enabled by default on most hosts; in hPanel check PHP Configuration > Extensions).
 *
 * NEVER upload data/gw.sqlite, data/secret.key or anything else from data/ over the live site: they hold your subscribers.
 */

require_once __DIR__ . '/operator.php';

const GW_NL_CONFIRM_DAYS = 14;

/* ---------------------------------------------------------------- secrets and tokens */

function gw_nl_dir(): string
{
    return dirname(__DIR__) . '/data';
}

/** A private random secret kept in data/secret.key. Used for HMACs only (form timing token, hashed IPs, rate-limit keys). */
function gw_secret(): string
{
    static $secret = null;
    if ($secret !== null) {
        return $secret;
    }
    $dir  = gw_nl_dir();
    $file = $dir . '/secret.key';
    if (is_readable($file)) {
        $v = trim((string) @file_get_contents($file));
        if (strlen($v) >= 32) {
            return $secret = $v;
        }
    }
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $v = bin2hex(random_bytes(32));
    if (is_dir($dir) && is_writable($dir)) {
        @file_put_contents($file, $v, LOCK_EX);
        @chmod($file, 0600);
        return $secret = $v;
    }
    // Folder not writable: fall back to a fixed per-site value so tokens still work within a request.
    return $secret = hash('sha256', __DIR__ . '|' . php_uname('n'));
}

function gw_hmac(string $s): string
{
    return hash_hmac('sha256', $s, gw_secret());
}

/** A short one-way key for the visitor's IP address. The real address is never stored. */
function gw_ip_key(): string
{
    return substr(gw_hmac('ip|' . ($_SERVER['REMOTE_ADDR'] ?? '')), 0, 24);
}

/** Hidden "time trap" token for the sign-up forms: bots that post instantly or with no token are ignored. */
function gw_form_token(): string
{
    $t = time();
    return $t . '.' . substr(gw_hmac('form|' . $t), 0, 24);
}

function gw_form_token_ok(string $tok): bool
{
    if (!preg_match('/^(\d{9,11})\.([a-f0-9]{24})$/', $tok, $m)) {
        return false;
    }
    $age = time() - (int) $m[1];
    if ($age < 3 || $age > 86400) {
        return false;
    }
    return hash_equals(substr(gw_hmac('form|' . $m[1]), 0, 24), $m[2]);
}

function gw_nl_token(): string
{
    return bin2hex(random_bytes(20));
}

/* ---------------------------------------------------------------- database */

function gw_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    if (!extension_loaded('pdo_sqlite')) {
        throw new RuntimeException('The PHP extension pdo_sqlite is not available on this server.');
    }
    $dir = gw_nl_dir();
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (!is_dir($dir) || !is_writable($dir)) {
        throw new RuntimeException('The data folder is not writable.');
    }
    $file = $dir . '/gw.sqlite';
    $new  = !is_file($file);
    $pdo  = new PDO('sqlite:' . $file, null, null, [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    ]);
    $pdo->exec('PRAGMA busy_timeout = 5000');
    $pdo->exec('PRAGMA foreign_keys = ON');
    gw_db_init($pdo);
    if ($new) {
        @chmod($file, 0640);
    }
    return $pdo;
}

function gw_db_init(PDO $db): void
{
    $db->exec('CREATE TABLE IF NOT EXISTS subscribers (
        id              INTEGER PRIMARY KEY AUTOINCREMENT,
        email           TEXT NOT NULL UNIQUE COLLATE NOCASE,
        status          TEXT NOT NULL DEFAULT \'pending\',
        confirm_token   TEXT NOT NULL,
        unsub_token     TEXT NOT NULL,
        source          TEXT NOT NULL DEFAULT \'website\',
        created_at      TEXT NOT NULL,
        confirm_sent_at TEXT,
        confirmed_at    TEXT,
        unsubscribed_at TEXT,
        consent_ip_key  TEXT
    )');
    $db->exec('CREATE INDEX IF NOT EXISTS idx_sub_status ON subscribers(status)');
    $db->exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_sub_unsub ON subscribers(unsub_token)');
    $db->exec('CREATE TABLE IF NOT EXISTS campaigns (
        id         INTEGER PRIMARY KEY AUTOINCREMENT,
        subject    TEXT NOT NULL,
        body       TEXT NOT NULL,
        created_at TEXT NOT NULL
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS sends (
        campaign_id   INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
        subscriber_id INTEGER NOT NULL REFERENCES subscribers(id) ON DELETE CASCADE,
        sent_at       TEXT NOT NULL,
        ok            INTEGER NOT NULL,
        PRIMARY KEY (campaign_id, subscriber_id)
    )');
    $db->exec('CREATE TABLE IF NOT EXISTS settings (k TEXT PRIMARY KEY, v TEXT NOT NULL)');
    $db->exec('CREATE TABLE IF NOT EXISTS rate (k TEXT NOT NULL, t INTEGER NOT NULL)');
    $db->exec('CREATE INDEX IF NOT EXISTS idx_rate ON rate(k, t)');

    // First run: seed the dashboard login from includes/admin-seed.php. The person must choose their own password at first login.
    if (gw_setting_raw($db, 'admin_hash') === null) {
        $seed = require __DIR__ . '/admin-seed.php';
        gw_set_setting_raw($db, 'admin_user', (string) $seed['user']);
        gw_set_setting_raw($db, 'admin_hash', (string) $seed['hash']);
        gw_set_setting_raw($db, 'admin_must_change', '1');
    }

    gw_nl_import_legacy($db);
    gw_db_maintenance($db);
}

function gw_setting_raw(PDO $db, string $k): ?string
{
    $st = $db->prepare('SELECT v FROM settings WHERE k = ?');
    $st->execute([$k]);
    $v = $st->fetchColumn();
    return $v === false ? null : (string) $v;
}

function gw_set_setting_raw(PDO $db, string $k, string $v): void
{
    $st = $db->prepare('INSERT INTO settings (k, v) VALUES (?, ?) ON CONFLICT(k) DO UPDATE SET v = excluded.v');
    $st->execute([$k, $v]);
}

function gw_setting(string $k): ?string
{
    return gw_setting_raw(gw_db(), $k);
}

function gw_set_setting(string $k, string $v): void
{
    gw_set_setting_raw(gw_db(), $k, $v);
}

/** Old sign-ups saved by the previous system (data/subscribers.csv) are imported as PENDING: consent must be confirmed. */
function gw_nl_import_legacy(PDO $db): void
{
    $file = gw_nl_dir() . '/subscribers.csv';
    if (!is_readable($file)) {
        return;
    }
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $ins   = $db->prepare('INSERT OR IGNORE INTO subscribers (email, status, confirm_token, unsub_token, source, created_at) VALUES (?, \'pending\', ?, ?, \'legacy\', ?)');
    $db->beginTransaction();
    foreach ($lines as $line) {
        $cols = str_getcsv($line);
        $email = strtolower(trim((string) ($cols[0] ?? '')));
        if (!gw_nl_valid($email)) {
            continue;
        }
        $when = !empty($cols[1]) && strtotime((string) $cols[1]) ? gmdate('c', strtotime((string) $cols[1])) : gmdate('c');
        $ins->execute([$email, gw_nl_token(), gw_nl_token(), $when]);
    }
    $db->commit();
    @rename($file, gw_nl_dir() . '/subscribers.imported.bak');
}

/** Once a day: remove old unconfirmed sign-ups and old rate-limit rows. */
function gw_db_maintenance(PDO $db): void
{
    $today = gmdate('Y-m-d');
    if (gw_setting_raw($db, 'last_clean') === $today) {
        return;
    }
    $db->prepare('DELETE FROM subscribers WHERE status = \'pending\' AND confirm_sent_at IS NOT NULL AND confirm_sent_at < ?')
       ->execute([gmdate('c', time() - 30 * 86400)]);
    $db->prepare('DELETE FROM rate WHERE t < ?')->execute([time() - 2 * 86400]);
    gw_set_setting_raw($db, 'last_clean', $today);
}

/* ---------------------------------------------------------------- rate limiting */

function gw_rate_count(string $key, int $window): int
{
    $st = gw_db()->prepare('SELECT COUNT(*) FROM rate WHERE k = ? AND t >= ?');
    $st->execute([$key, time() - $window]);
    return (int) $st->fetchColumn();
}

function gw_rate_add(string $key): void
{
    gw_db()->prepare('INSERT INTO rate (k, t) VALUES (?, ?)')->execute([$key, time()]);
}

function gw_rate_clear(string $key): void
{
    gw_db()->prepare('DELETE FROM rate WHERE k = ?')->execute([$key]);
}

/* ---------------------------------------------------------------- mail */

function gw_mail_clean(string $s): string
{
    return trim(str_replace(["\r", "\n", "\0"], ' ', $s));
}

/** Sends a plain-text email with PHP mail(). Returns true if the server accepted it (that is not proof of delivery). */
function gw_mail(string $to, string $subject, string $body, array $headers = []): bool
{
    $to      = gw_mail_clean($to);
    $subject = gw_mail_clean($subject);
    $h = array_merge([
        'From'                      => gw_mail_clean(SITE_NAME) . ' <' . MAIL_FROM . '>',
        'Reply-To'                  => CONTACT_EMAIL,
        'MIME-Version'              => '1.0',
        'Content-Type'              => 'text/plain; charset=UTF-8',
        'Content-Transfer-Encoding' => '8bit',
    ], $headers);
    foreach ($h as $k => $v) {
        $h[$k] = gw_mail_clean((string) $v);
    }
    $body = wordwrap(str_replace("\r\n", "\n", $body), 78, "\n", false);

    $testLog = getenv('GW_MAIL_TEST');   // only ever set by the developer's test server
    if ($testLog) {
        file_put_contents($testLog, json_encode(['to' => $to, 'subject' => $subject, 'headers' => $h, 'body' => $body]) . "\n", FILE_APPEND | LOCK_EX);
        return true;
    }
    return @mail($to, '=?UTF-8?B?' . base64_encode($subject) . '?=', $body, $h);
}

function gw_nl_identity(): string
{
    return trim(gw_operator_line()) . ' Contact: ' . CONTACT_EMAIL;
}

function gw_nl_footer(?array $sub): string
{
    $unsub = $sub
        ? 'Unsubscribe in one click: ' . gw_abs('/unsubscribe/?t=' . $sub['unsub_token'])
        : 'Unsubscribe: (test email, so there is no personal link)';
    return "\n\n--\n"
         . ($sub ? 'You are receiving this because you subscribed to GrandWhisper at grandwhisper.com.' : 'This is a test email.') . "\n"
         . $unsub . "\n"
         . gw_nl_identity() . "\n"
         . '18+ only. Gambling can be harmful. Free, confidential help: Gambling Help Online, 1800 858 858.' . "\n";
}

function gw_nl_send_confirmation(array $row): bool
{
    $url  = gw_abs('/subscribe-confirm/?t=' . $row['confirm_token']);
    $body = "Hello,\n\n"
          . "Someone (hopefully you) asked to receive new-article emails from GrandWhisper (grandwhisper.com).\n\n"
          . "To confirm, open this link and press the confirm button:\n" . $url . "\n\n"
          . 'The link works for ' . GW_NL_CONFIRM_DAYS . " days.\n\n"
          . "If this was not you, ignore this email. You will not hear from us again and nothing will be sent.\n\n--\n"
          . gw_nl_identity() . "\n";
    $ok = gw_mail($row['email'], 'Confirm your GrandWhisper subscription', $body);
    if ($ok) {
        gw_db()->prepare('UPDATE subscribers SET confirm_sent_at = ? WHERE id = ?')->execute([gmdate('c'), $row['id']]);
    }
    return $ok;
}

/* ---------------------------------------------------------------- subscribers */

function gw_nl_valid(string $e): bool
{
    return $e !== '' && strlen($e) <= 120 && filter_var($e, FILTER_VALIDATE_EMAIL) !== false;
}

function gw_nl_find(string $email): ?array
{
    $st = gw_db()->prepare('SELECT * FROM subscribers WHERE email = ?');
    $st->execute([strtolower(trim($email))]);
    $r = $st->fetch();
    return $r ?: null;
}

/**
 * Starts a sign-up. Returns 'sent' (confirmation emailed), 'already' (already confirmed), 'wait' (a recent email was already sent
 * or too many requests) or 'error' (the email could not be sent). The visitor sees the same neutral message for the first three.
 */
function gw_nl_subscribe(string $email): string
{
    $db    = gw_db();
    $email = strtolower(trim($email));
    $now   = gmdate('c');
    $row   = gw_nl_find($email);

    if ($row && $row['status'] === 'confirmed') {
        return 'already';
    }
    if ($row && $row['status'] === 'pending' && !empty($row['confirm_sent_at']) && strtotime($row['confirm_sent_at']) > time() - 3600) {
        return 'wait';
    }
    $emailKey = 'conf|' . substr(gw_hmac('em|' . $email), 0, 24);
    if (gw_rate_count($emailKey, 86400) >= 3) {
        return 'wait';
    }

    if (!$row) {
        $db->prepare('INSERT INTO subscribers (email, status, confirm_token, unsub_token, source, created_at) VALUES (?, \'pending\', ?, ?, \'website\', ?)')
           ->execute([$email, gw_nl_token(), gw_nl_token(), $now]);
    } elseif ($row['status'] === 'unsubscribed') {
        $db->prepare('UPDATE subscribers SET status = \'pending\', confirm_token = ?, unsub_token = ?, created_at = ?, confirm_sent_at = NULL, confirmed_at = NULL, unsubscribed_at = NULL WHERE id = ?')
           ->execute([gw_nl_token(), gw_nl_token(), $now, $row['id']]);
    } else {
        $db->prepare('UPDATE subscribers SET confirm_token = ? WHERE id = ?')->execute([gw_nl_token(), $row['id']]);
    }
    gw_rate_add($emailKey);
    return gw_nl_send_confirmation(gw_nl_find($email)) ? 'sent' : 'error';
}

function gw_nl_by_token(string $col, string $token): ?array
{
    if (!preg_match('/^[a-f0-9]{40}$/', $token) || !in_array($col, ['confirm_token', 'unsub_token'], true)) {
        return null;
    }
    $st = gw_db()->prepare("SELECT * FROM subscribers WHERE $col = ?");
    $st->execute([$token]);
    $r = $st->fetch();
    return $r ?: null;
}

/** Looks at a confirmation link without changing anything: 'valid', 'already' or 'invalid'. */
function gw_nl_confirm_state(string $token): string
{
    $row = gw_nl_by_token('confirm_token', $token);
    if (!$row) {
        return 'invalid';
    }
    if ($row['status'] === 'confirmed') {
        return 'already';
    }
    if ($row['status'] === 'pending' && !empty($row['confirm_sent_at']) && strtotime($row['confirm_sent_at']) > time() - GW_NL_CONFIRM_DAYS * 86400) {
        return 'valid';
    }
    return 'invalid';
}

/** Confirms the subscription. Returns 'ok', 'already' or 'invalid'. */
function gw_nl_confirm(string $token): string
{
    $state = gw_nl_confirm_state($token);
    if ($state !== 'valid') {
        return $state;
    }
    $row = gw_nl_by_token('confirm_token', $token);
    gw_db()->prepare('UPDATE subscribers SET status = \'confirmed\', confirmed_at = ?, consent_ip_key = ? WHERE id = ?')
           ->execute([gmdate('c'), gw_ip_key(), $row['id']]);
    return 'ok';
}

/** Unsubscribes by the personal link token. Returns 'ok', 'already' or 'invalid'. */
function gw_nl_unsubscribe(string $token): string
{
    $row = gw_nl_by_token('unsub_token', $token);
    if (!$row) {
        return 'invalid';
    }
    if ($row['status'] === 'unsubscribed') {
        return 'already';
    }
    gw_db()->prepare('UPDATE subscribers SET status = \'unsubscribed\', unsubscribed_at = ? WHERE id = ?')->execute([gmdate('c'), $row['id']]);
    return 'ok';
}

function gw_nl_counts(): array
{
    $c = ['confirmed' => 0, 'pending' => 0, 'unsubscribed' => 0];
    foreach (gw_db()->query('SELECT status, COUNT(*) AS n FROM subscribers GROUP BY status') as $r) {
        $c[$r['status']] = (int) $r['n'];
    }
    $c['total'] = array_sum($c);
    return $c;
}

/* ---------------------------------------------------------------- campaigns */

function gw_nl_campaign_create(string $subject, string $body): int
{
    $db = gw_db();
    $db->prepare('INSERT INTO campaigns (subject, body, created_at) VALUES (?, ?, ?)')->execute([$subject, $body, gmdate('c')]);
    return (int) $db->lastInsertId();
}

function gw_nl_campaign_progress(int $id): array
{
    $db = gw_db();
    $st = $db->prepare('SELECT COALESCE(SUM(ok = 1), 0) AS sent, COALESCE(SUM(ok = 0), 0) AS failed FROM sends WHERE campaign_id = ?');
    $st->execute([$id]);
    $r = $st->fetch();
    $st = $db->prepare('SELECT COUNT(*) FROM subscribers s WHERE s.status = \'confirmed\' AND NOT EXISTS (SELECT 1 FROM sends x WHERE x.campaign_id = ? AND x.subscriber_id = s.id)');
    $st->execute([$id]);
    return ['sent' => (int) $r['sent'], 'failed' => (int) $r['failed'], 'remaining' => (int) $st->fetchColumn()];
}

/** Sends the next batch of a campaign to confirmed subscribers who have not had it yet. */
function gw_nl_send_batch(int $campaignId, int $limit): array
{
    $db = gw_db();
    $st = $db->prepare('SELECT * FROM campaigns WHERE id = ?');
    $st->execute([$campaignId]);
    $camp = $st->fetch();
    if (!$camp) {
        return ['sent' => 0, 'failed' => 0];
    }
    $st = $db->prepare('SELECT * FROM subscribers s WHERE s.status = \'confirmed\' AND NOT EXISTS (SELECT 1 FROM sends x WHERE x.campaign_id = ? AND x.subscriber_id = s.id) ORDER BY s.id LIMIT ?');
    $st->bindValue(1, $campaignId, PDO::PARAM_INT);
    $st->bindValue(2, max(1, min(50, $limit)), PDO::PARAM_INT);
    $st->execute();
    $ins = $db->prepare('INSERT OR REPLACE INTO sends (campaign_id, subscriber_id, sent_at, ok) VALUES (?, ?, ?, ?)');
    $sent = $failed = 0;
    foreach ($st->fetchAll() as $sub) {
        $unsubUrl = gw_abs('/unsubscribe/?t=' . $sub['unsub_token']);
        $ok = gw_mail($sub['email'], $camp['subject'], $camp['body'] . gw_nl_footer($sub), [
            'List-Unsubscribe'      => '<' . $unsubUrl . '>',
            'List-Unsubscribe-Post' => 'List-Unsubscribe=One-Click',
        ]);
        $ins->execute([$campaignId, $sub['id'], gmdate('c'), $ok ? 1 : 0]);
        $ok ? $sent++ : $failed++;
        usleep(200000);   // gentle pace for shared hosting
    }
    return ['sent' => $sent, 'failed' => $failed];
}
