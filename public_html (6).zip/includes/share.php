<?php
/**
 * Page widgets shown by includes/footer.php:
 *  - a "back to top" button (every page, bottom right; it appears after the visitor has scrolled down);
 *  - a share bar on content pages (articles, categories, the five guide pages and the homepage).
 *
 * The share buttons are ordinary links. Nothing is loaded from any social network until a visitor clicks one, so the site
 * still loads no third-party scripts, pixels or trackers. On wide screens the bar sits at the far left; on narrower screens
 * a floating Share button opens the phone's own share sheet (or a short list of the same links).
 *
 * Networks chosen for Australia: Facebook, X, WhatsApp, Reddit, LinkedIn, plus email and copy-link.
 */
function gw_share_targets(string $url, string $title): array
{
    $u = rawurlencode($url);
    $t = rawurlencode($title);
    return [
        ['fb',    'Share on Facebook', 'https://www.facebook.com/sharer/sharer.php?u=' . $u, true],
        ['x',     'Share on X',        'https://x.com/intent/post?url=' . $u . '&text=' . $t, true],
        ['wa',    'Share on WhatsApp', 'https://wa.me/?text=' . $t . '%20' . $u, true],
        ['rd',    'Share on Reddit',   'https://www.reddit.com/submit?url=' . $u . '&title=' . $t, true],
        ['li',    'Share on LinkedIn', 'https://www.linkedin.com/sharing/share-offsite/?url=' . $u, true],
        ['mail',  'Share by email',    'mailto:?subject=' . $t . '&body=' . $u, false],
    ];
}

function gw_share_icon(string $key): string
{
    $open = '<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true" focusable="false">';
    switch ($key) {
        case 'fb':
            return $open . '<path fill="currentColor" d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"/></svg>';
        case 'x':
            return $open . '<path fill="currentColor" d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>';
        case 'wa':
            return $open . '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/><path fill="currentColor" d="M9 8.6c0 3.2 3.2 6.4 6.4 6.4l1-1.6-2.1-1-1 .8c-1-.4-1.8-1.2-2.2-2.2l.8-1-1-2.1z"/></svg>';
        case 'rd':
            return $open . '<circle cx="5" cy="11.2" r="1.9" fill="currentColor"/><circle cx="19" cy="11.2" r="1.9" fill="currentColor"/><ellipse cx="12" cy="14" rx="7.2" ry="5.4" fill="currentColor"/><circle cx="9.2" cy="13.2" r="1.25" style="fill:var(--tile)"/><circle cx="14.8" cy="13.2" r="1.25" style="fill:var(--tile)"/><path d="M9.2 16.3c1.7 1.1 3.9 1.1 5.6 0" fill="none" style="stroke:var(--tile)" stroke-width="1.2" stroke-linecap="round"/><path d="M12 8.6l1.3-4.3 3.4.8" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><circle cx="17.3" cy="5.3" r="1.4" fill="currentColor"/></svg>';
        case 'li':
            return $open . '<path fill="currentColor" d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"/><rect x="2" y="9" width="4" height="12" fill="currentColor"/><circle cx="4" cy="4" r="2" fill="currentColor"/></svg>';
        case 'mail':
            return $open . '<path fill="none" stroke="currentColor" stroke-width="2" stroke-linejoin="round" d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" d="M22 6l-10 7L2 6"/></svg>';
        case 'link':
            return $open . '<g fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></g></svg>';
        case 'share':
            return $open . '<g fill="currentColor"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/></g><path fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" d="M8.6 10.6l6.8-4.1M8.6 13.4l6.8 4.1"/></svg>';
        case 'up':
            return $open . '<path fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" d="M12 19V5M5 12l7-7 7 7"/></svg>';
    }
    return '';
}

/** Prints the widgets. $seo is the page's own $seo array (title, path, body_class, robots). */
function gw_page_widgets(array $seo): void
{
    $cls   = (string) ($seo['body_class'] ?? '');
    $path  = (string) ($seo['path'] ?? '/');
    $share = in_array($cls, ['is-article', 'is-category', 'is-landing', 'is-home'], true);   // not contact, legal, search or error pages

    if ($share) {
        $url   = gw_abs($path);
        $title = (string) ($seo['title'] ?? SITE_NAME);
        if (!empty($seo['raw_title'])) { $title = preg_replace('/\s*\|\s*GrandWhisper.*$/', '', $title); }
        ?>
<div class="share" id="share" data-url="<?= e($url) ?>" data-title="<?= e($title) ?>">
  <button class="share-toggle" type="button" aria-expanded="false" aria-controls="share-list" aria-label="Share this page"><?= gw_share_icon('share') ?></button>
  <ul class="share-list" id="share-list" aria-label="Share this page">
<?php foreach (gw_share_targets($url, $title) as [$key, $label, $href, $ext]): ?>
    <li><a class="sh sh--<?= e($key) ?>" href="<?= e($href) ?>"<?= $ext ? ' target="_blank" rel="noopener noreferrer"' : '' ?> aria-label="<?= e($label) ?>"><?= gw_share_icon($key) ?></a></li>
<?php endforeach; ?>
    <li><button class="sh sh--copy" type="button" aria-label="Copy link"><?= gw_share_icon('link') ?></button></li>
  </ul>
  <span class="share-note sr" role="status" aria-live="polite"></span>
</div>
<?php } ?>
<button class="to-top" type="button" aria-label="Back to top" hidden><?= gw_share_icon('up') ?></button>
<?php
}
