<?php
/**
 * Shared header: <head>, age notice, logo, navigation and search.
 * The including page must define $seo first (see functions.php > gw_head).
 * This file opens <body> and closes </header>. Each page opens its own <main id="main">.
 */
require_once __DIR__ . '/functions.php';
$gwPath = $seo['path'] ?? '';
$gwNav  = [];
foreach (gw_pages() as $p) {
    $gwNav[] = [$p['nav'], $p['path']];
}
$gwNav[] = ['News', '/category/casino-news/'];
$gwNav[] = ['Guides', '/category/casino-guides/'];
?>
<!DOCTYPE html>
<html lang="en-AU" class="no-js">
<head>
<link rel="preload" href="/assets/fonts/dm-sans-latin-wght-normal.woff2" as="font" type="font/woff2" crossorigin>
<?php gw_head($seo); ?>
<script>document.documentElement.className='js';</script>
</head>
<body class="<?= e($seo['body_class'] ?? '') ?>">
<a class="skip" href="#main">Skip to content</a>
<div class="agebar"><p>18+ only. Gambling can be addictive. <a href="/responsible-gambling/">Play responsibly</a>.</p></div>
<header class="site-head">
  <div class="wrap head-row">
    <a class="brand" href="/" aria-label="<?= e(SITE_NAME) ?> home">
      <svg class="brand-mark" width="38" height="38" viewBox="0 0 40 40" aria-hidden="true" focusable="false"><rect width="40" height="40" rx="11" fill="#2A1A44"/><path d="M20 7.5 29 20l-9 12.5L11 20z" fill="#B1243B"/><path d="M20 12.5 25 20l-5 7.5L15 20z" fill="#F4F2F8" opacity=".92"/></svg>
      <span class="brand-text"><span class="brand-name"><?= e(SITE_NAME) ?></span><span class="brand-sub"><?= e(SITE_TAGLINE) ?></span></span>
    </a>
    <button class="nav-toggle" type="button" aria-expanded="false" aria-controls="site-nav"><span class="nav-toggle-label">Menu</span><span class="nav-toggle-bars" aria-hidden="true"></span></button>
    <nav id="site-nav" class="site-nav" aria-label="Main">
      <ul>
<?php foreach ($gwNav as $item): $active = ($gwPath === $item[1]); ?>
        <li><a href="<?= e($item[1]) ?>"<?= $active ? ' aria-current="page"' : '' ?>><?= e($item[0]) ?></a></li>
<?php endforeach; ?>
      </ul>
      <form class="search" role="search" action="/search/" method="get">
        <label class="sr" for="site-q">Search articles</label>
        <input id="site-q" type="search" name="q" placeholder="Search articles" maxlength="80" required>
        <button type="submit">Search</button>
      </form>
    </nav>
  </div>
</header>
