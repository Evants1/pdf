<?php
/**
 * Comparison table component used on the five permanent pages.
 *
 * IMPORTANT: the four brands below are FICTIONAL SAMPLES for layout purposes. Every figure, licence
 * reference and offer is invented. While GW_COMPARISON_IS_SAMPLE is true the table is labelled as an
 * illustrative example and shows no outbound links. Before you replace the sample data with real
 * operators: verify every fact yourself, show the date you checked it, label affiliate links, and take
 * Australian legal advice (the Interactive Gambling Act restricts providing and advertising online
 * casino games to people in Australia). Then set GW_COMPARISON_IS_SAMPLE to false.
 *
 * LOGOS: do NOT add real operators' logos without written permission from each operator AND Australian legal advice.
 * A logo is copyrighted artwork and a trademark, and showing real casino brands to Australian readers is a legal question,
 * not only a copyright one. While GW_COMPARISON_IS_SAMPLE is true the code below ignores any 'logo' value, so a logo can
 * never appear by accident on the sample table or the sidebar banner.
 */
require_once __DIR__ . '/functions.php';

const GW_COMPARISON_IS_SAMPLE = true;

/**
 * GO-LIVE SWITCHES. Nothing was deleted: the table and the banner are only switched OFF.
 *   GW_SHOW_COMPARISON  true = show the comparison table on the five guide pages (and the pages go back to "noindex"
 *                       while GW_COMPARISON_IS_SAMPLE is true). false = the whole table section and its menu link disappear.
 *   GW_SHOW_PROMO       true = show the "Top casino of the month" banner in the sidebar. false = hidden everywhere.
 * To bring them back later, change false to true. The sample data, scores and layout below are all still here.
 * Before you put real operators in, read the notes at the top of this file and take Australian legal advice.
 */
const GW_SHOW_COMPARISON = false;
const GW_SHOW_PROMO      = false;

/** True while either sample item is on a page, so the About, Terms and copyright pages only describe what is actually shown. */
function gw_sample_visible(): bool
{
    return GW_SHOW_COMPARISON || GW_SHOW_PROMO;
}

/** Button text used for live brands (when GW_COMPARISON_IS_SAMPLE is false). */
const GW_CTA_LABEL = 'Claim Bonus Now';

/**
 * Big button shown on the SAMPLE table. The brands are fictional, so the button must not pretend you can play or claim
 * anything: it opens the bonus calculator instead. Do not change this to "Play Now" while the brands are samples.
 */
const GW_SAMPLE_CTA_LABEL = 'See the real cost';
const GW_SAMPLE_CTA_URL   = '/online-casino-bonuses/#calculator';

/** Score weights (sum 100). They match the eight areas and weights published on the Online Casino Reviews page. */
function gw_score_weights(): array
{
    return ['licensing' => 20, 'security' => 15, 'banking' => 20, 'bonus' => 15, 'games' => 8, 'safer' => 10, 'support' => 8, 'mobile' => 4];
}

function gw_score_labels(): array
{
    return ['licensing' => 'Licence', 'security' => 'Security', 'banking' => 'Payments', 'bonus' => 'Bonus terms', 'games' => 'Games', 'safer' => 'Safer gambling', 'support' => 'Support', 'mobile' => 'Mobile'];
}

/**
 * The brands. Add 'url' (an https address, or '#' as a placeholder) to switch a brand's button on, and
 * optionally 'logo' => 'file.webp' (a file in assets/images/brands/) to replace the initial tile.
 */
function gw_comparison_brands(): array
{
    $brands = [
        [
            'name' => 'Aurora Sample', 'initial' => 'A', 'tone' => 0, 'url' => '',
            'calc' => ['match' => 1.0, 'cap' => 500, 'mult' => 35, 'base' => 'bonus'],
            'tagline' => 'All-rounder with strong safety tools',
            'scores' => ['licensing' => 9.4, 'security' => 8.9, 'banking' => 8.8, 'bonus' => 8.1, 'games' => 9.0, 'safer' => 9.2, 'support' => 8.6, 'mobile' => 8.6],
            'offer' => '100% match up to $500', 'offer_note' => 'Plus 50 free spins on one named slot',
            'wagering' => '35x bonus only', 'min_deposit' => '$20', 'max_cashout' => '10x bonus', 'expiry' => '14 days',
            'payments' => ['PayID', 'BPAY', 'Visa debit', 'Apple Pay'], 'payout' => '1 to 2 business days', 'limits' => '$10,000 per week',
            'regulator' => 'Sample Regulator (fictional)', 'licence_ref' => 'SAMPLE-0001', 'verification' => 'ID check before first withdrawal',
            'safer_tools' => ['Deposit limits', 'Loss limits', 'Time-out', 'Self-exclusion'],
            'games' => '1,200 slots, 60 table games, live dealer', 'support' => '24/7 live chat, email', 'checked' => '2026-11-01',
            'pros' => ['Clear, findable bonus terms', 'Fast PayID withdrawals', 'Limits set in under two minutes'],
            'cons' => ['Smaller free spin offer', 'Live chat is slower at weekends'],
        ],
        [
            'name' => 'Beacon Sample', 'initial' => 'B', 'tone' => 1, 'url' => '',
            'calc' => ['match' => 0.5, 'cap' => 300, 'mult' => 20, 'base' => 'bonus'],
            'tagline' => 'Built around fast, low-fee banking',
            'scores' => ['licensing' => 9.0, 'security' => 8.4, 'banking' => 9.5, 'bonus' => 7.2, 'games' => 8.2, 'safer' => 8.5, 'support' => 8.0, 'mobile' => 9.0],
            'offer' => '50% match up to $300', 'offer_note' => 'Low wagering, no free spins',
            'wagering' => '20x bonus only', 'min_deposit' => '$10', 'max_cashout' => 'None stated', 'expiry' => '30 days',
            'payments' => ['PayID', 'Osko', 'E-wallet', 'Bank transfer'], 'payout' => 'Same day after approval', 'limits' => '$15,000 per week',
            'regulator' => 'Sample Regulator (fictional)', 'licence_ref' => 'SAMPLE-0002', 'verification' => 'Electronic ID check at sign-up',
            'safer_tools' => ['Deposit limits', 'Reality checks', 'Time-out', 'Self-exclusion'],
            'games' => '800 slots, 40 table games', 'support' => 'Live chat 8am to midnight, email', 'checked' => '2026-11-01',
            'pros' => ['Lowest wagering in this comparison', 'No withdrawal fees', 'Clear payout limits'],
            'cons' => ['No live dealer games', 'Support not available overnight'],
        ],
        [
            'name' => 'Cedar Sample', 'initial' => 'C', 'tone' => 2, 'url' => '',
            'calc' => ['match' => 2.0, 'cap' => 1000, 'mult' => 40, 'base' => 'both'],
            'tagline' => 'Biggest offer, with the strictest terms',
            'scores' => ['licensing' => 8.6, 'security' => 7.6, 'banking' => 7.8, 'bonus' => 9.3, 'games' => 8.7, 'safer' => 7.9, 'support' => 7.4, 'mobile' => 8.2],
            'offer' => '200% match up to $1,000', 'offer_note' => 'Plus 100 free spins over five days',
            'wagering' => '40x deposit plus bonus', 'min_deposit' => '$30', 'max_cashout' => '5x bonus', 'expiry' => '7 days',
            'payments' => ['Visa debit', 'E-wallet', 'Crypto', 'Bank transfer'], 'payout' => '2 to 4 business days', 'limits' => '$5,000 per week',
            'regulator' => 'Sample Regulator (fictional)', 'licence_ref' => 'SAMPLE-0003', 'verification' => 'Documents requested at first withdrawal',
            'safer_tools' => ['Deposit limits', 'Time-out', 'Self-exclusion'],
            'games' => '2,000 slots, 90 table games, live dealer', 'support' => 'Email and chat, business hours', 'checked' => '2026-11-01',
            'pros' => ['Largest game library', 'Generous headline offer'],
            'cons' => ['Short seven-day expiry', 'Cash-out cap on bonus winnings', 'Lower weekly withdrawal limit'],
        ],
        [
            'name' => 'Delta Sample', 'initial' => 'D', 'tone' => 3, 'url' => '',
            'calc' => null,
            'tagline' => 'Safer gambling and support first',
            'scores' => ['licensing' => 9.6, 'security' => 9.3, 'banking' => 8.1, 'bonus' => 6.8, 'games' => 7.6, 'safer' => 9.7, 'support' => 9.0, 'mobile' => 7.8],
            'offer' => 'Cashback on net losses', 'offer_note' => 'Paid as cash, no wagering',
            'wagering' => 'None on cashback', 'min_deposit' => '$20', 'max_cashout' => 'Not applicable', 'expiry' => 'Weekly',
            'payments' => ['PayID', 'BPAY', 'Visa debit'], 'payout' => '1 to 3 business days', 'limits' => '$8,000 per week',
            'regulator' => 'Sample Regulator (fictional)', 'licence_ref' => 'SAMPLE-0004', 'verification' => 'Electronic ID check at sign-up',
            'safer_tools' => ['Deposit limits', 'Loss limits', 'Reality checks', 'Time-out', 'Self-exclusion'],
            'games' => '600 slots, 30 table games', 'support' => '24/7 phone, chat and email', 'checked' => '2026-11-01',
            'pros' => ['Most complete safer gambling tools', 'Human support around the clock', 'Cashback with no wagering'],
            'cons' => ['Smallest game library', 'Modest headline offer'],
        ],
    ];
    $w = gw_score_weights();
    foreach ($brands as &$b) {
        $sum = 0;
        foreach ($w as $k => $weight) { $sum += $b['scores'][$k] * $weight; }
        $b['rating'] = round($sum / array_sum($w), 1);
        $b['safety']  = round(($b['scores']['licensing'] + $b['scores']['security'] + $b['scores']['safer']) / 3, 1);
    }
    return $brands;
}

/**
 * Worked example for a sample deposit: the bonus, the bets needed and the average cost of those bets.
 * Assumes a 96% return on every bet and that every bet counts in full (a simplified average, not a forecast).
 * Returns null when a brand has no wagering requirement to work out.
 */
function gw_brand_example(array $b, int $deposit = 100): ?array
{
    $c = $b['calc'] ?? null;
    if (!$c) {
        return null;
    }
    $bonus    = min($deposit * $c['match'], $c['cap']);
    $turnover = $c['mult'] * ($c['base'] === 'both' ? $deposit + $bonus : $bonus);
    $cost     = $turnover * 0.04;
    return ['deposit' => $deposit, 'bonus' => $bonus, 'turnover' => $turnover, 'cost' => $cost, 'diff' => $cost - $bonus];
}

/**
 * Plain-language "watch for" and "good sign" notes worked out from a brand's own terms (no brand artwork needed).
 * Returns a list of ['warn' or 'ok', text]. Warnings come first.
 */
function gw_brand_flags(array $b): array
{
    $warn = [];
    $ok   = [];
    if (preg_match('/(\d+)\s*days?/i', (string) $b['expiry'], $m) && (int) $m[1] <= 7) {
        $warn[] = 'Short expiry: ' . (int) $m[1] . ' days';
    }
    if (stripos((string) $b['wagering'], 'deposit plus bonus') !== false) {
        $warn[] = 'Wagering applies to deposit plus bonus';
    }
    if (preg_match('/(\d+)x/', (string) $b['wagering'], $m) && (int) $m[1] <= 20) {
        $ok[] = 'Low wagering: ' . (int) $m[1] . 'x';
    }
    if (!preg_match('/none|not applicable/i', (string) $b['max_cashout'])) {
        $warn[] = 'Cash-out cap: ' . $b['max_cashout'];
    }
    if (stripos((string) $b['verification'], 'withdrawal') !== false) {
        $warn[] = 'ID check at withdrawal time: verify early';
    } elseif (stripos((string) $b['verification'], 'sign-up') !== false) {
        $ok[] = 'ID check at sign-up';
    }
    if (preg_match('/(\d+) to (\d+) business days/i', (string) $b['payout'], $m) && (int) $m[2] >= 4) {
        $warn[] = 'Slower payouts: ' . $b['payout'];
    } elseif (stripos((string) $b['payout'], 'same day') !== false) {
        $ok[] = 'Same-day payouts after approval';
    }
    $tools = count($b['safer_tools']);
    if ($tools <= 3) {
        $warn[] = 'Fewer safer-gambling tools (' . $tools . ')';
    } elseif ($tools >= 5) {
        $ok[] = 'Full set of safer-gambling tools';
    }
    $out = [];
    foreach (array_slice($warn, 0, 4) as $t) { $out[] = ['warn', $t]; }
    foreach (array_slice($ok, 0, 2) as $t)   { $out[] = ['ok', $t]; }
    return $out;
}

/**
 * Print the comparison section.
 * $focus: overall | bonus | banking | safety | reviews. It decides the sort order and the badge.
 */
function gw_comparison(string $focus, string $heading, string $intro): void
{
    if (!GW_SHOW_COMPARISON) {
        return;
    }
    $brands = gw_comparison_brands();
    $key = ['overall' => 'rating', 'reviews' => 'rating', 'bonus' => 'bonus', 'banking' => 'banking', 'safety' => 'safety'][$focus] ?? 'rating';
    $focusName = ['overall' => 'overall rating', 'reviews' => 'overall rating', 'bonus' => 'bonus terms', 'banking' => 'banking', 'safety' => 'safety'][$focus] ?? 'overall rating';
    $val = fn($b) => $key === 'rating' || $key === 'safety' ? $b[$key] : $b['scores'][$key];
    usort($brands, fn($a, $b) => [$val($b), $b['rating']] <=> [$val($a), $a['rating']]);
    $tones = ['#6B2A7E,#B1243B', '#2C4A7E,#4F7FC4', '#8A2B4A,#D9803F', '#1F6F5C,#5BB59A'];
    $labels = gw_score_labels();
    $sample = GW_COMPARISON_IS_SAMPLE;
    ?>
  <div class="cmp-head">
    <h2 id="compare-title"><?= e($heading) ?></h2>
    <p><?= e($intro) ?></p>
<?php if ($sample): ?>
    <p class="cmp-flag"><strong>Illustrative example.</strong> These four brands are fictional and every figure is invented, to show how a comparison works. They are not real operators and not recommendations.</p>
<?php endif; ?>
  </div>

  <div class="cmp" role="region" aria-labelledby="compare-title" tabindex="0">
    <table class="cmp-table">
      <caption class="sr">Comparison of four <?= $sample ? 'sample ' : '' ?>brands, ranked by <?= e($focusName) ?></caption>
      <thead>
        <tr><th scope="col">Brand</th><th scope="col">Offer</th><th scope="col">Key terms</th><th scope="col">Banking</th><th scope="col">Licence and safety</th><th scope="col"><span class="sr">Link</span></th></tr>
      </thead>
<?php foreach ($brands as $i => $b): $c = explode(',', $tones[$b['tone'] % 4]); ?>
      <tbody class="cmp-brand<?= $i === 0 ? ' is-top' : '' ?>">
        <tr class="cmp-main">
          <th scope="row" class="c-brand">
            <span class="rank" aria-label="Rank <?= $i + 1 ?>"><?= $i + 1 ?></span>
<?php if (!$sample && !empty($b['logo'])): ?>
            <span class="mono mono--img"><img src="/assets/images/brands/<?= e($b['logo']) ?>" width="96" height="96" alt="<?= e($b['name']) ?> logo" loading="lazy" decoding="async"></span>
<?php else: ?>
            <span class="mono" style="--a:<?= e($c[0]) ?>;--b:<?= e($c[1]) ?>" aria-hidden="true"><?= e($b['initial']) ?></span>
<?php endif; ?>
            <span class="c-name">
              <strong><?= e($b['name']) ?></strong>
              <span class="c-tag"><?= e($b['tagline']) ?></span>
              <?php if ($i === 0): ?><span class="badge">Top for <?= e($focusName) ?></span><?php endif; ?>
            </span>
            <span class="ring" style="--p:<?= (int) round($b['rating'] * 10) ?>" role="img" aria-label="Rating <?= e($b['rating']) ?> out of 10"><b><?= e(number_format($b['rating'], 1)) ?></b></span>
          </th>
          <td data-label="Offer">
            <strong class="offer"><?= e($b['offer']) ?></strong>
            <span class="offer-note"><?= e($b['offer_note']) ?></span>
          </td>
          <td data-label="Key terms">
            <dl class="kv">
              <div><dt>Wagering</dt><dd><?= e($b['wagering']) ?></dd></div>
              <div><dt>Min deposit</dt><dd><?= e($b['min_deposit']) ?></dd></div>
              <div><dt>Max cash-out</dt><dd><?= e($b['max_cashout']) ?></dd></div>
              <div><dt>Expires</dt><dd><?= e($b['expiry']) ?></dd></div>
            </dl>
          </td>
          <td data-label="Banking">
            <ul class="pay"><?php foreach ($b['payments'] as $m): ?><li><?= e($m) ?></li><?php endforeach; ?></ul>
            <dl class="kv">
              <div><dt>Payouts</dt><dd><?= e($b['payout']) ?></dd></div>
              <div><dt>Limits</dt><dd><?= e($b['limits']) ?></dd></div>
            </dl>
          </td>
          <td data-label="Licence and safety">
            <dl class="kv">
              <div><dt>Regulator</dt><dd><?= e($b['regulator']) ?></dd></div>
              <div><dt>Licence ref.</dt><dd><?= e($b['licence_ref']) ?></dd></div>
              <div><dt>ID checks</dt><dd><?= e($b['verification']) ?></dd></div>
            </dl>
            <ul class="ticks"><?php foreach ($b['safer_tools'] as $t): ?><li><?= e($t) ?></li><?php endforeach; ?></ul>
          </td>
          <td class="c-cta">
<?php if (!$sample && $b['url']): ?>
            <a class="cta" href="<?= e($b['url']) ?>" rel="sponsored nofollow noopener" target="_blank"><?= e(GW_CTA_LABEL) ?><span class="sr">: <?= e($b['name']) ?></span></a>
            <span class="cta-fine">18+. T&amp;Cs apply. Advertising link</span>
<?php else: ?>
            <a class="cta cta--big" href="<?= e(GW_SAMPLE_CTA_URL) ?>"><?= e(GW_SAMPLE_CTA_LABEL) ?><span class="sr">: <?= e($b['name']) ?> (sample offer)</span></a>
            <span class="cta-fine">Sample offer. No real link.</span>
<?php endif; ?>
          </td>
        </tr>
        <tr class="cmp-detail">
          <td colspan="6">
            <div class="detail">
              <div>
                <p class="cmp-h">Score breakdown</p>
                <ul class="sbars">
<?php foreach ($labels as $k => $label): ?>
                  <li<?= $k === $key ? ' class="is-focus"' : '' ?>><span><?= e($label) ?></span><i class="bar"><i style="width:<?= (int) round($b['scores'][$k] * 10) ?>%"></i></i><b><?= e(number_format($b['scores'][$k], 1)) ?></b></li>
<?php endforeach; ?>
                </ul>
              </div>
              <div>
                <p class="cmp-h">What stands out</p>
                <ul class="pc pc--pro"><?php foreach ($b['pros'] as $x): ?><li><?= e($x) ?></li><?php endforeach; ?></ul>
                <ul class="pc pc--con"><?php foreach ($b['cons'] as $x): ?><li><?= e($x) ?></li><?php endforeach; ?></ul>
              </div>
              <div>
                <p class="cmp-h">Good to know</p>
                <dl class="kv kv--plain">
                  <div><dt>Games</dt><dd><?= e($b['games']) ?></dd></div>
                  <div><dt>Support</dt><dd><?= e($b['support']) ?></dd></div>
                  <div><dt>Last checked</dt><dd><time datetime="<?= e($b['checked']) ?>"><?= e(gw_date($b['checked'])) ?></time></dd></div>
                </dl>
              </div>
            </div>
<?php $ex = gw_brand_example($b); $fl = gw_brand_flags($b); ?>
            <div class="cmp-extra">
              <div>
                <p class="cmp-h">What the offer costs on a $100 deposit</p>
<?php if ($ex): ?>
                <dl class="kv">
                  <div><dt>Bonus received</dt><dd>$<?= e(number_format($ex['bonus'])) ?></dd></div>
                  <div><dt>Bets to place before withdrawing</dt><dd>$<?= e(number_format($ex['turnover'])) ?></dd></div>
                  <div><dt>Average cost of those bets</dt><dd>about $<?= e(number_format($ex['cost'])) ?></dd></div>
                </dl>
                <p class="cmp-fine">That is $<?= e(number_format(abs($ex['diff']))) ?> <?= $ex['diff'] > 0 ? 'more' : 'less' ?> than the bonus itself. Assumes a 96% return on every bet and that every bet counts in full, so it is a simplified average, not a forecast.</p>
<?php else: ?>
                <p class="cmp-fine">This offer has no wagering requirement to work out. Check how the offer is paid and what it applies to in the full terms.</p>
<?php endif; ?>
              </div>
              <div>
                <p class="cmp-h">Watch for, and good signs</p>
                <ul class="cmp-chips">
<?php foreach ($fl as [$kind, $text]): ?>
                  <li class="<?= e($kind) ?>"><span class="sr"><?= $kind === 'warn' ? 'Watch for: ' : 'Good sign: ' ?></span><?= e($text) ?></li>
<?php endforeach; ?>
                </ul>
              </div>
            </div>
          </td>
        </tr>
      </tbody>
<?php endforeach; ?>
    </table>
  </div>

  <div class="cmp-check">
    <p class="cmp-h">Check any brand yourself before you trust it</p>
    <ul>
      <li><a href="/safe-and-trusted-online-casinos/">Check the licence</a></li>
      <li><a href="/how-casino-welcome-bonuses-work/">Read the bonus terms</a></li>
      <li><a href="/online-casino-bonuses/">Work out the real cost</a></li>
      <li><a href="/what-affects-casino-withdrawal-speed/">Check withdrawal rules</a></li>
      <li><a href="https://www.acma.gov.au" rel="noopener">Check ACMA's guidance</a></li>
    </ul>
  </div>

  <p class="cmp-foot">
<?php if ($sample): ?>Sample data for layout purposes only. <?php endif; ?>18+ only. Gambling can be addictive: <a href="/responsible-gambling/">get help</a>. Under the Interactive Gambling Act 2001, online casino games cannot lawfully be offered to people in Australia: see <a href="/online-gambling-laws-in-australia/">our guide to the law</a>. Our <a href="/online-casino-reviews/#scorecard">review method</a> explains how ratings are weighted<?php if ($sample): ?>; the sample scores here use the same eight areas and weights, with invented values<?php endif; ?>. <?php if (!$sample): ?><strong>Advertising disclosure:</strong> we may receive compensation if you follow links in this table. <?php endif; ?>Read our <a href="/about/#disclosure">affiliate disclosure</a>.
  </p>
<?php
}


/**
 * Sidebar banner: "Top casino of the month". Uses the highest-rated brand from gw_comparison_brands().
 * Same rules as the table: labelled as a sample while GW_COMPARISON_IS_SAMPLE is true, no link until live.
 */
function gw_promo(): void
{
    if (!GW_SHOW_PROMO) {
        return;
    }
    $brands = gw_comparison_brands();
    usort($brands, fn($a, $b) => $b['rating'] <=> $a['rating']);
    $b = $brands[0];
    $sample = GW_COMPARISON_IS_SAMPLE;
    $tones = ['#6B2A7E,#B1243B', '#2C4A7E,#4F7FC4', '#8A2B4A,#D9803F', '#1F6F5C,#5BB59A'];
    $c = explode(',', $tones[$b['tone'] % 4]);
    ?>
<aside class="promo" aria-label="Top casino of the month">
  <p class="promo-ribbon">Top casino of the month</p>
  <p class="promo-month"><?= e(date('F Y')) ?></p>
  <div class="promo-brand">
<?php if (!$sample && !empty($b['logo'])): ?>
    <span class="mono mono--img"><img src="/assets/images/brands/<?= e($b['logo']) ?>" width="96" height="96" alt="<?= e($b['name']) ?> logo" loading="lazy" decoding="async"></span>
<?php else: ?>
    <span class="mono" style="--a:<?= e($c[0]) ?>;--b:<?= e($c[1]) ?>" aria-hidden="true"><?= e($b['initial']) ?></span>
<?php endif; ?>
    <div>
      <strong><?= e($b['name']) ?></strong>
      <span class="promo-score" aria-label="Rating <?= e($b['rating']) ?> out of 10"><b><?= e(number_format($b['rating'], 1)) ?></b>/10</span>
    </div>
  </div>
  <p class="promo-offer"><?= e($b['offer']) ?></p>
  <ul class="promo-facts">
    <li><span>Min deposit</span><b><?= e($b['min_deposit']) ?></b></li>
    <li><span>Wagering</span><b><?= e($b['wagering']) ?></b></li>
    <li><span>Payouts</span><b><?= e($b['payout']) ?></b></li>
  </ul>
<?php if (!$sample && $b['url']): ?>
  <a class="cta" href="<?= e($b['url']) ?>" rel="sponsored nofollow noopener" target="_blank"><?= e(GW_CTA_LABEL) ?><span class="sr">: <?= e($b['name']) ?></span></a>
  <p class="promo-fine">18+. T&amp;Cs apply. <strong>Advertising disclosure:</strong> we may receive compensation if you follow this link. <a href="/about/#disclosure">Read more</a>.</p>
<?php else: ?>
  <span class="cta cta--off">Sample only</span>
  <p class="promo-fine">Illustrative example. Fictional brand, invented figures.</p>
<?php endif; ?>
</aside>
<?php
}