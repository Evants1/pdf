<?php
/**
 * Starting login for the private dashboard at /gw-admin/. Only a one-way HASH of the password is stored here, never the password itself.
 *
 * - The first time you log in you are asked to choose your own password. That new password is stored (hashed) in the database,
 *   so uploading this file again later does NOT reset it.
 * - 'allow_ips' (optional): list the IP addresses allowed to open the dashboard, for example ['203.0.113.7'].
 *   Leave it empty to allow any address (the login, lockout and session protections still apply).
 * - If you lose access: replace the hash below with a new one and ask for the reset steps. The database keeps your own password,
 *   so a reset means removing the 'admin_hash' row from the settings table.
 */
return [
    'user'      => 'owner',
    'hash'      => '$2y$10$gHf/fgGRsdnX2S3D8GLOPuzHtTPsTiqfao1FiTTWfCUIrnPv9uzxS',
    'allow_ips' => [],
];
