<?php
/** Shared footer. Closes the page opened in header.php. */
$gwFootGuides = gw_pages();
?>
<footer class="site-foot">
  <div class="wrap foot-grid">
    <div class="foot-brand">
      <p class="foot-logo"><?= e(SITE_NAME) ?></p>
      <p>An online casino magazine for Australian readers: guides, explainers and educational reviews for people who want to understand what they are signing up for.</p>
    </div>
    <nav aria-label="Casino guides">
      <h2>Casino guides</h2>
      <ul>
<?php foreach ($gwFootGuides as $p): ?>
        <li><a href="<?= e($p['path']) ?>"><?= e($p['title']) ?></a></li>
<?php endforeach; ?>
      </ul>
    </nav>
    <nav aria-label="Magazine">
      <h2>Magazine</h2>
      <ul>
        <li><a href="/category/casino-news/">Casino News</a></li>
        <li><a href="/category/casino-guides/">Casino Guides</a></li>
        <li><a href="/online-gambling-laws-in-australia-2026/">Australian law</a></li>
        <li><a href="/about/">About us</a></li>
        <li><a href="/contact/">Contact</a></li>
      </ul>
    </nav>
    <nav aria-label="Legal">
      <h2>Legal and safety</h2>
      <ul>
        <li><a href="/responsible-gambling/">Responsible gambling</a></li>
        <li><a href="/privacy-policy/">Privacy policy</a></li>
        <li><a href="/terms-and-conditions/">Terms and conditions</a></li>
        <li><a href="/copyright-and-dmca/">Copyright and DMCA</a></li>
      </ul>
    </nav>
  </div>
  <div class="wrap foot-note">
    <p><strong>18+ only.</strong> Gambling involves risk and can be addictive. Never gamble more than you can afford to lose. If gambling is causing you harm, see our <a href="/responsible-gambling/">responsible gambling page</a> for free, confidential help. In Australia, call Gambling Help Online on 1800 858 858 or visit <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> to self-exclude from licensed wagering.</p>
    <p>Some links on this site may be affiliate links, which means we may earn a commission if you sign up with an operator, at no extra cost to you. Read how this works in our <a href="/about/#disclosure">affiliate disclosure</a>. In Australia, online casino games cannot lawfully be offered to people in Australia under the Interactive Gambling Act 2001. See our <a href="/online-gambling-laws-in-australia-2026/">guide to Australian law</a>.</p>
    <p class="copy">&copy; <?= date('Y') ?> <?= e(SITE_NAME) ?>. All rights reserved.</p>
  </div>
</footer>
<?php require_once __DIR__ . '/share.php'; gw_page_widgets(isset($seo) && is_array($seo) ? $seo : []); ?>
<script src="<?= e(gw_asset('js/main.js')) ?>" defer></script>
<script src="<?= e(gw_asset('js/extras.js')) ?>" defer></script>
</body>
</html>
