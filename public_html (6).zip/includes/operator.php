<?php

function gw_operator(): array
{
    return [
    'name'    => 'Grand Whisper',
    'abn'     => '',   // add your ABN here when you have confirmed it, for example '12 345 678 901'
    'address' => 'an online business based in Australia',
    // 'phone' is intentionally not shown anywhere. Add it only after you have confirmed it is a real, working number.
    ];
}

function gw_operator_line(): string
{
    $o = gw_operator();
    if (empty($o['name'])) {
        return '';
    }
    $line = 'GrandWhisper is published by ' . $o['name'];
    if (!empty($o['abn']))     { $line .= ' (ABN ' . $o['abn'] . ')'; }
    if (!empty($o['address'])) { $line .= ', ' . $o['address']; }
    return $line . '.';
}