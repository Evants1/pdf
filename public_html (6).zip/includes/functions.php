<?php
/**
 * GrandWhisper - shared helper functions.
 * Kept deliberately small: escaping, URLs, images, article cards, SEO head output.
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/content.php';

/* Fallbacks so the site still works on a PHP build without the mbstring extension. */
if (!function_exists('mb_strlen')) {
    function mb_strlen($s) { $n = preg_match_all('/./us', (string) $s); return $n === false ? strlen((string) $s) : $n; }
}
if (!function_exists('mb_substr')) {
    function mb_substr($s, $start, $len = null) {
        $chars = preg_split('//u', (string) $s, -1, PREG_SPLIT_NO_EMPTY);
        if ($chars === false) { return substr((string) $s, $start, $len); }
        return implode('', array_slice($chars, $start, $len));
    }
}
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($s) { return strtolower((string) $s); }
}
if (!function_exists('mb_strpos')) {
    function mb_strpos($h, $n) { return strpos((string) $h, (string) $n); }
}

/** Escape a value for safe HTML output. */
function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Absolute URL for a site path such as "/about/". */
function gw_abs(string $path): string
{
    return SITE_URL . $path;
}

/** Versioned URL for CSS/JS in /assets/. */
function gw_asset(string $path): string
{
    return '/assets/' . ltrim($path, '/') . '?v=' . ASSET_VERSION;
}

/** Format a Y-m-d date for readers, e.g. "7 November 2026". */
function gw_date(string $date, string $format = 'j F Y'): string
{
    $time = strtotime($date);
    return $time ? date($format, $time) : '';
}

/** All articles, newest first. */
function gw_articles(?string $category = null, ?int $limit = null): array
{
    $list = gw_articles_all();
    usort($list, fn($a, $b) => strcmp($b['date'], $a['date']));
    if ($category !== null) {
        $list = array_values(array_filter($list, fn($a) => $a['category'] === $category));
    }
    return $limit ? array_slice($list, 0, $limit) : $list;
}

/** One article by slug, or null. */
function gw_article(string $slug): ?array
{
    foreach (gw_articles_all() as $article) {
        if ($article['slug'] === $slug) {
            return $article;
        }
    }
    return null;
}

/** One category by slug, or null. */
function gw_category(string $slug): ?array
{
    $all = gw_categories();
    return $all[$slug] ?? null;
}

/**
 * Responsive image. $base is a path under /assets/images without extension,
 * e.g. "articles/my-slug". Expects my-slug.webp (1200w) and my-slug-600.webp (600w).
 */
function gw_img(string $base, string $alt, array $o = []): string
{
    $sizes = $o['sizes'] ?? '(min-width: 900px) 600px, 100vw';
    $class = isset($o['class']) ? ' class="' . e($o['class']) . '"' : '';
    $eager = !empty($o['eager']);
    $src   = '/assets/images/' . $base;
    return '<img' . $class
        . ' src="' . e($src) . '.webp"'
        . ' srcset="' . e($src) . '-600.webp 600w, ' . e($src) . '.webp 1200w"'
        . ' sizes="' . e($sizes) . '"'
        . ' width="1200" height="675"'
        . ' alt="' . e($alt) . '"'
        . ($eager ? ' fetchpriority="high"' : ' loading="lazy"')
        . ' decoding="async">';
}

/**
 * Article card. Variants: "std" (default), "feature", "side", "mini".
 * $level is the heading level of the card title (3 under an h2 section, 2 directly under the page h1).
 */
function gw_card(array $a, string $variant = 'std', int $level = 3): string
{
    $cat   = gw_category($a['category']);
    $url   = '/' . $a['slug'] . '/';
    $sizes = $variant === 'feature' ? '(min-width: 900px) 720px, 100vw' : '(min-width: 900px) 380px, 100vw';
    $h     = 'h' . max(2, min(4, $level));
    ob_start(); ?>
<article class="card card--<?= e($variant) ?>">
  <a class="card-img" href="<?= e($url) ?>" tabindex="-1" aria-hidden="true"><?= gw_img('articles/' . $a['slug'], $a['alt'], ['sizes' => $sizes]) ?></a>
  <div class="card-body">
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <<?= $h ?> class="card-title"><a href="<?= e($url) ?>"><?= e($a['title']) ?></a></<?= $h ?>>
    <?php if ($variant !== 'mini'): ?><p class="card-excerpt"><?= e($a['excerpt']) ?></p><?php endif; ?>
    <p class="card-meta"><?php $au = gw_authors()[$a['author'] ?? ''] ?? null; if ($au): ?><span>By <?= e($au['name']) ?></span><?php endif; ?><time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time><span><?= (int) $a['minutes'] ?> min read</span></p>
    <?php if ($variant === 'feature' || $variant === 'std'): ?><a class="card-more" href="<?= e($url) ?>">Read more<span class="sr"> about <?= e($a['title']) ?></span></a><?php endif; ?>
  </div>
</article>
<?php
    return ob_get_clean();
}

/** Visible breadcrumb trail. $crumbs = [[label, path], ...]; the last item is the current page. */
function gw_breadcrumbs(array $crumbs): string
{
    $out = '<nav class="crumbs" aria-label="Breadcrumb"><ol>';
    $last = count($crumbs) - 1;
    foreach ($crumbs as $i => $c) {
        if ($i === $last) {
            $out .= '<li aria-current="page">' . e($c[0]) . '</li>';
        } else {
            $out .= '<li><a href="' . e($c[1]) . '">' . e($c[0]) . '</a></li>';
        }
    }
    return $out . '</ol></nav>';
}

/** JSON-LD for the article schema. */
function gw_article_schema(array $a): array
{
    return [
        '@type'            => 'Article',
        '@id'              => gw_abs('/' . $a['slug'] . '/') . '#article',
        'headline'         => $a['title'],
        'description'      => $a['description'],
        'image'            => [gw_abs('/assets/images/articles/' . $a['slug'] . '.jpg')],
        'datePublished'    => $a['date'] . 'T08:00:00+00:00',
        'dateModified'     => $a['updated'] . 'T08:00:00+00:00',
        'author'           => ['@type' => 'Organization', 'name' => SITE_NAME . ' Editorial', 'url' => gw_abs('/about/')],
        'publisher'        => ['@id' => gw_abs('/') . '#organization'],
        'mainEntityOfPage' => ['@type' => 'WebPage', '@id' => gw_abs('/' . $a['slug'] . '/')],
        'articleSection'   => gw_category($a['category'])['label'] ?? '',
        'inLanguage'       => 'en-AU',
    ];
}

/**
 * Output everything that belongs inside <head>.
 * Each page sets $seo before including header.php. Keys:
 *   title (required), description (required), path (required, e.g. "/about/"),
 *   robots, og_type, image (path under /assets/images), image_alt,
 *   published, modified, section, breadcrumbs, schema (extra JSON-LD nodes), raw_title
 */
function gw_head(array $seo): void
{
    $title    = $seo['title'];
    $fullTitle = !empty($seo['raw_title']) ? $title : $title . ' | ' . SITE_NAME;
    $desc     = $seo['description'];
    $path     = $seo['path'];
    $canon    = gw_abs($path);
    $robots   = $seo['robots'] ?? 'index,follow,max-image-preview:large';
    $ogType   = $seo['og_type'] ?? 'website';
    $image    = gw_abs('/assets/images/' . ($seo['image'] ?? 'pages/og-default.jpg'));
    $imageAlt = $seo['image_alt'] ?? SITE_NAME . ' online casino magazine';

    echo '<meta charset="utf-8">' . "\n";
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">' . "\n";
    echo '<title>' . e($fullTitle) . '</title>' . "\n";
    echo '<meta name="description" content="' . e($desc) . '">' . "\n";
    echo '<meta name="robots" content="' . e($robots) . '">' . "\n";
    if (empty($seo['no_canonical'])) {
        echo '<link rel="canonical" href="' . e($canon) . '">' . "\n";
    }
    echo '<meta name="theme-color" content="#FFFFFF">' . "\n";
    echo '<link rel="icon" href="/assets/images/favicon.svg" type="image/svg+xml">' . "\n";
    echo '<link rel="icon" href="/assets/images/favicon-32.png" sizes="32x32" type="image/png">' . "\n";
    echo '<link rel="apple-touch-icon" href="/assets/images/apple-touch-icon.png">' . "\n";

    // Open Graph
    echo '<meta property="og:locale" content="en_AU">' . "\n";
    echo '<meta property="og:site_name" content="' . e(SITE_NAME) . '">' . "\n";
    echo '<meta property="og:type" content="' . e($ogType) . '">' . "\n";
    echo '<meta property="og:title" content="' . e($fullTitle) . '">' . "\n";
    echo '<meta property="og:description" content="' . e($desc) . '">' . "\n";
    echo '<meta property="og:url" content="' . e($canon) . '">' . "\n";
    echo '<meta property="og:image" content="' . e($image) . '">' . "\n";
    echo '<meta property="og:image:width" content="1200">' . "\n";
    echo '<meta property="og:image:height" content="630">' . "\n";
    echo '<meta property="og:image:alt" content="' . e($imageAlt) . '">' . "\n";
    if ($ogType === 'article') {
        if (!empty($seo['published'])) echo '<meta property="article:published_time" content="' . e($seo['published']) . 'T08:00:00+00:00">' . "\n";
        if (!empty($seo['modified']))  echo '<meta property="article:modified_time" content="' . e($seo['modified']) . 'T08:00:00+00:00">' . "\n";
        if (!empty($seo['section']))   echo '<meta property="article:section" content="' . e($seo['section']) . '">' . "\n";
    }

    // Twitter / X
    echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
    echo '<meta name="twitter:title" content="' . e($fullTitle) . '">' . "\n";
    echo '<meta name="twitter:description" content="' . e($desc) . '">' . "\n";
    echo '<meta name="twitter:image" content="' . e($image) . '">' . "\n";
    echo '<meta name="twitter:image:alt" content="' . e($imageAlt) . '">' . "\n";

    if (!empty($seo['head_extra'])) {
        echo $seo['head_extra'] . "\n";   // trusted markup built by the page itself (e.g. an image preload)
    }
    echo '<link rel="stylesheet" href="' . e(gw_asset('css/style.css')) . '">' . "\n";

    // Structured data: Organization + WebSite on every page, BreadcrumbList when set.
    $graph = [
        [
            '@type' => 'Organization',
            '@id'   => gw_abs('/') . '#organization',
            'name'  => SITE_NAME,
            'url'   => gw_abs('/'),
            'logo'  => ['@type' => 'ImageObject', 'url' => gw_abs('/assets/images/logo.png'), 'width' => 512, 'height' => 512],
        ],
        [
            '@type'     => 'WebSite',
            '@id'       => gw_abs('/') . '#website',
            'url'       => gw_abs('/'),
            'name'      => SITE_NAME,
            'description' => 'An online casino magazine for Australian readers, with guides, explainers and educational reviews.',
            'publisher' => ['@id' => gw_abs('/') . '#organization'],
            'inLanguage' => 'en-AU',
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => ['@type' => 'EntryPoint', 'urlTemplate' => gw_abs('/search/') . '?q={search_term_string}'],
                'query-input' => 'required name=search_term_string',
            ],
        ],
    ];
    if (!empty($seo['breadcrumbs'])) {
        $items = [];
        foreach ($seo['breadcrumbs'] as $i => $c) {
            $items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'name' => $c[0], 'item' => gw_abs($c[1])];
        }
        $graph[] = ['@type' => 'BreadcrumbList', '@id' => $canon . '#breadcrumb', 'itemListElement' => $items];
    }
    foreach ($seo['schema'] ?? [] as $node) {
        $graph[] = $node;
    }
    $json = json_encode(['@context' => 'https://schema.org', '@graph' => $graph],
        JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_HEX_TAG | JSON_HEX_AMP);
    echo '<script type="application/ld+json">' . $json . '</script>' . "\n";
}

require_once __DIR__ . '/topics.php';
