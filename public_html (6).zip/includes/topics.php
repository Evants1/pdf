<?php
/**
 * Topic map: used to build the "More on this topic" box at the bottom of every article and the
 * "Related guides" block on the hub pages. It is the ONE place that decides how articles link to each other.
 *
 *  - 'slugs'    : the articles in the topic (every article should appear in exactly one topic).
 *  - 'flagship' : the article other topics link to.
 *  - 'related'  : other topics that are worth a link from this one.
 *
 * A slug that does not exist is skipped automatically, so a typo here can never create a 404 link.
 * New articles that are not listed here simply do not get a topic box until you add them below.
 */

function gw_topics(): array
{
    return [
        'withdrawals' => [
            'title'    => 'Withdrawals and payout speed',
            'short'    => 'Withdrawals',
            'flagship' => 'how-fast-do-online-casinos-pay-out-australia',
            'related'  => ['kyc', 'bonuses', 'crypto'],
            'slugs'    => ['how-fast-do-online-casinos-pay-out-australia', 'what-affects-casino-withdrawal-speed', 'how-to-withdraw-from-online-casinos-australia', 'how-casino-withdrawals-work-speed-and-limits', 'casino-withdrawal-speed-test-what-matters', 'instant-withdrawal-casinos-australia', 'instant-payout-casinos-australia', 'top-australian-casino-sites-with-fastest-withdrawals'],
        ],
        'bonuses' => [
            'title'    => 'Welcome bonuses and no-deposit offers',
            'short'    => 'Bonuses',
            'flagship' => 'how-casino-welcome-bonuses-are-calculated',
            'related'  => ['withdrawals', 'games', 'choosing'],
            'slugs'    => ['how-casino-welcome-bonuses-are-calculated', 'how-casino-welcome-bonuses-work', 'how-casino-welcome-bonuses-work-in-australia', 'australian-casino-welcome-bonuses-comparison', 'best-casino-bonuses-for-australian-players', 'no-deposit-bonuses-australia', 'best-no-deposit-casino-offers-australia'],
        ],
        'choosing' => [
            'title'    => 'Choosing and judging a casino',
            'short'    => 'Choosing a casino',
            'flagship' => 'how-to-find-the-best-online-casino-australia',
            'related'  => ['law', 'kyc', 'control'],
            'slugs'    => ['how-to-find-the-best-online-casino-australia', 'how-to-choose-a-real-money-online-casino', 'how-to-choose-a-real-money-online-casino-australia', 'best-online-casinos-australia-2026', 'new-online-casinos-australia-2026'],
        ],
        'kyc' => [
            'title'    => 'ID checks and verification',
            'short'    => 'ID checks (KYC)',
            'flagship' => 'kyc-verification-at-online-casinos-australia',
            'related'  => ['withdrawals', 'law'],
            'slugs'    => ['kyc-verification-at-online-casinos-australia', 'kyc-verification-at-online-casinos'],
        ],
        'games' => [
            'title'    => 'Pokies, RTP and casino games',
            'short'    => 'Pokies and RTP',
            'flagship' => 'understanding-rtp-and-volatility-in-online-slots-australia',
            'related'  => ['bonuses', 'live', 'control'],
            'slugs'    => ['understanding-rtp-and-volatility-in-online-slots-australia', 'understanding-rtp-and-volatility-in-online-slots', 'pokies-and-slots-australia-rtp-themes-paylines', 'high-rtp-slots-australia', 'jackpot-pokies-australia', 'australian-players-top-10-casino-games-2026'],
        ],
        'live' => [
            'title'    => 'Live dealer games',
            'short'    => 'Live dealer',
            'flagship' => 'live-dealer-casino-australia',
            'related'  => ['games', 'mobile', 'law'],
            'slugs'    => ['live-dealer-casino-australia', 'live-dealer-casino-games-how-they-work', 'live-dealer-casino-games-explained', 'live-casino-australia-how-real-dealers-work', 'live-casinos-australia-what-to-check'],
        ],
        'mobile' => [
            'title'    => 'Mobile casino play',
            'short'    => 'Mobile play',
            'flagship' => 'mobile-casino-apps-australia',
            'related'  => ['live', 'control', 'crypto'],
            'slugs'    => ['mobile-casino-apps-australia', 'mobile-casino-gaming-apps-vs-browser', 'mobile-casino-gaming-apps-vs-browser-2026'],
        ],
        'crypto' => [
            'title'    => 'Crypto casinos and payments',
            'short'    => 'Crypto',
            'flagship' => 'crypto-casinos-australia-bitcoin-gambling-guide',
            'related'  => ['withdrawals', 'law', 'mobile'],
            'slugs'    => ['crypto-casinos-australia-bitcoin-gambling-guide', 'crypto-casinos-explained-benefits-and-risks', 'bitcoin-casinos-australia-why-crypto', 'crypto-casinos-australia-2026-how-to-evaluate'],
        ],
        'law' => [
            'title'    => 'Australian gambling law and regulation',
            'short'    => 'Law and regulation',
            'flagship' => 'online-gambling-laws-in-australia-2026',
            'related'  => ['choosing', 'control', 'crypto'],
            'slugs'    => ['online-gambling-laws-in-australia-2026', 'understanding-australian-online-gambling-regulations', 'online-gambling-laws-in-australia', 'online-casinos-australia-pros-cons-legality', 'online-casino-trends-australia-2026'],
        ],
        'control' => [
            'title'    => 'Limits, self-exclusion and staying in control',
            'short'    => 'Limits and self-exclusion',
            'flagship' => 'how-to-set-deposit-and-loss-limits-australia',
            'related'  => ['law', 'games', 'bonuses'],
            'slugs'    => ['how-to-set-deposit-and-loss-limits-australia', 'responsible-gaming-tools-every-australian-should-use', 'responsible-gambling-tools-limits-and-self-exclusion', 'responsible-gambling-tools-limits-and-self-exclusion-australia', 'self-exclusion-australia-guide'],
        ],
    ];
}

/** Which topic an article belongs to (or null). */
function gw_topic_of(string $slug): ?string
{
    foreach (gw_topics() as $key => $t) {
        if (in_array($slug, $t['slugs'], true)) { return $key; }
    }
    return null;
}

/** "More on this topic" box shown at the end of every article. */
function gw_topic_links(string $slug): void
{
    $topics = gw_topics();
    $key = gw_topic_of($slug);
    if ($key === null) { return; }
    $t = $topics[$key];

    // the next articles in the topic after this one, wrapping round, so inbound links spread evenly
    $slugs = $t['slugs'];
    $pos = array_search($slug, $slugs, true);
    $ordered = array_merge(array_slice($slugs, $pos + 1), array_slice($slugs, 0, $pos));
    $links = [];
    foreach ($ordered as $s) {
        $a = gw_article($s);
        if ($a) { $links[] = $a; }
        if (count($links) >= 6) { break; }
    }
    $rel = [];
    foreach ($t['related'] as $rk) {
        if (!isset($topics[$rk])) { continue; }
        $fa = gw_article($topics[$rk]['flagship']);
        if ($fa && $fa['slug'] !== $slug) { $rel[] = [$topics[$rk]['short'], $fa['slug']]; }
    }
    if (!$links && !$rel) { return; }
    ?>
      <nav class="topic-links" aria-label="More on this topic">
        <p class="topic-links-title">More on <?= e(strtolower($t['title'])) ?></p>
<?php if ($links): ?>
        <ul>
<?php foreach ($links as $a): ?>
          <li><a href="/<?= e($a['slug']) ?>/"><?= e($a['title']) ?></a></li>
<?php endforeach; ?>
        </ul>
<?php endif; ?>
<?php if ($rel): ?>
        <p class="topic-links-related"><strong>Related topics:</strong>
<?php foreach ($rel as $i => [$label, $s]): ?>
          <a href="/<?= e($s) ?>/"><?= e($label) ?></a><?= $i < count($rel) - 1 ? ' &middot;' : '' ?>
<?php endforeach; ?>
        </p>
<?php endif; ?>
      </nav>
<?php
}

/** "Related guides" block for the hub pages: pass the topic keys to show. */
function gw_topic_block(array $keys, string $heading = 'Related guides'): void
{
    $topics = gw_topics();
    $cols = [];
    foreach ($keys as $k) {
        if (!isset($topics[$k])) { continue; }
        $items = [];
        foreach ($topics[$k]['slugs'] as $s) {
            $a = gw_article($s);
            if ($a) { $items[] = $a; }
            if (count($items) >= 4) { break; }
        }
        if ($items) { $cols[] = [$topics[$k]['title'], $items]; }
    }
    if (!$cols) { return; }
    ?>
  <section class="wrap topic-hub" aria-label="<?= e($heading) ?>">
    <h2><?= e($heading) ?></h2>
    <div class="topic-hub-grid">
<?php foreach ($cols as [$title, $items]): ?>
      <div>
        <h3><?= e($title) ?></h3>
        <ul>
<?php foreach ($items as $a): ?>
          <li><a href="/<?= e($a['slug']) ?>/"><?= e($a['title']) ?></a></li>
<?php endforeach; ?>
        </ul>
      </div>
<?php endforeach; ?>
    </div>
  </section>
<?php
}
