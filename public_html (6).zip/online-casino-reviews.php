<?php
/**
 * Permanent page: Online Casino Reviews (served at /online-casino-reviews/).
 * Explains the review method. Ranks no sites, quotes no offers, names no operators and links to no casino.
 * The ratings section has id="scorecard" because the comparison tables on other pages link to it.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/comparison.php';

// Visible FAQ. The same array feeds the FAQPage structured data, so the two always match.
$faq = [
    ['q' => 'Are online casino reviews reliable?', 'a' => 'It depends on the evidence and independence behind them. A trustworthy review states its criteria, discloses how the site earns money, shows what was and was not verified, and includes real negatives. See the section on judging a review site for a checklist.'],
    ['q' => 'Is it legal to play at online casinos in Australia?', 'a' => 'The Interactive Gambling Act 2001 primarily targets providers: it makes it an offence for operators to offer certain online casino games to customers in Australia, whether the operator is based in Australia or overseas. The Act does not generally make customers the target of that provider offence. That does not mean offshore services are safe, regulated for Australian consumers or covered by Australian consumer protections. Check ACMA for the current rules, and take legal advice if you need certainty.'],
    ['q' => 'How do I check an online casino\'s licence?', 'a' => 'Find the licence number and regulator in the site\'s footer or terms, then search the regulator\'s own register through its official website, not a badge on the casino. Check that the company name, address and status match, and that the licence covers online casino games. A licence never makes a service lawful in Australia.'],
    ['q' => 'Does a high rating mean I will get paid quickly?', 'a' => 'No. Payment speed depends on the method, the amount, verification, bonus conditions, banking hours and the operator\'s own processing, and a site that paid one reviewer quickly may be slower for you. The payout section above explains what to look for in any speed claim.'],
    ['q' => 'Do reviewers really test with their own money?', 'a' => 'Some do, and a claim of real-money testing is easy to make and hard to confirm. Look for dated evidence such as a logged first withdrawal with method, amount and timestamps, and for honest notes on what was not tested.'],
];

// INDEXING SWITCH FOR THIS PAGE. true = Google may index it (and it is listed in the sitemap).
// Set to false to hide it from search engines. The fictional comparison table is clearly labelled as an illustration.
$allowIndex = true;

// DATES. $updated = date of the last real edit. $legalChecked = date YOU verified the legal section against ACMA and the
// Federal Register of Legislation (null = nothing is shown). Do not set it unless you have done the check.
$updated      = '2026-11-10';
$legalChecked = null;

// OPTIONAL SECTION "How we document our reviews". It is hidden while this is null. Fill it in ONLY with processes you
// genuinely follow, one entry per item, for example:
// $reviewDocs = [
//     ['Who performs the checks', 'Your real answer.'],
//     ['What evidence is kept',   'Your real answer.'],
//     ['Real-money testing',      'Your real answer, including "we do not test with real money" if that is the case.'],
//     ['How complaints are weighed', 'Your real answer.'],
//     ['How often reviews are updated', 'Your real answer.'],
//     ['Who approves corrections', 'Your real answer.'],
// ];
$reviewDocs = null;

$seo = [
    'title'       => 'Online Casino Reviews Australia: Our Method',
    'description' => 'How we assess online casino reviews in Australia, including licensing, security, payments, bonus terms, scoring criteria and the Australian legal position.',
    'path'        => '/online-casino-reviews/',
    'image'       => 'pages/online-casino-reviews.jpg',
    'image_alt'   => 'Guide graphic with a review scorecard and magnifying glass and the title How We Review Casinos',
    // Indexing is controlled by $allowIndex above, NOT by the sample-table flag: this is a permanent educational guide.
    'robots'      => $allowIndex ? 'index,follow,max-image-preview:large' : 'noindex,follow',
    'head_extra'  => '<link rel="preload" as="image" href="/assets/images/pages/online-casino-reviews.webp" imagesrcset="/assets/images/pages/online-casino-reviews-600.webp 600w, /assets/images/pages/online-casino-reviews.webp 1200w" imagesizes="(min-width: 960px) 520px, 100vw" fetchpriority="high">',
    'body_class'  => 'is-landing',
    'breadcrumbs' => [['Home', '/'], ['Online Casino Reviews', '/online-casino-reviews/']],
    'schema'      => [
        [
            '@type'        => 'WebPage',
            '@id'          => gw_abs('/online-casino-reviews/') . '#webpage',
            'url'          => gw_abs('/online-casino-reviews/'),
            'name'         => 'Online Casino Reviews Australia: Our Method',
            'dateModified' => $updated,
            'inLanguage'   => 'en-AU',
            'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
            'mainEntity'   => ['@id' => gw_abs('/online-casino-reviews/') . '#article'],
        ],
        [
            '@type'            => 'Article',
            '@id'              => gw_abs('/online-casino-reviews/') . '#article',
            'headline'         => 'How We Review Online Casinos: Method, Scoring and the Australian Legal Position',
            'description'      => 'How we assess online casino reviews in Australia, including licensing, security, payments, bonus terms, scoring criteria and the Australian legal position.',
            'image'            => [gw_abs('/assets/images/pages/online-casino-reviews.jpg')],
            'datePublished'    => '2026-11-08T08:00:00+00:00',
            'dateModified'     => $updated . 'T08:00:00+00:00',
            'author'           => ['@type' => 'Organization', 'name' => SITE_NAME . ' Editorial Team', 'url' => gw_abs('/about/')],
            'publisher'        => ['@id' => gw_abs('/') . '#organization'],
            'mainEntityOfPage' => ['@id' => gw_abs('/online-casino-reviews/') . '#webpage'],
            'inLanguage'       => 'en-AU',
        ],
        [
            '@type'      => 'FAQPage',
            '@id'        => gw_abs('/online-casino-reviews/') . '#faq',
            'isPartOf'   => ['@id' => gw_abs('/online-casino-reviews/') . '#webpage'],
            'mainEntity' => array_map(fn($f) => [
                '@type' => 'Question',
                'name'  => $f['q'],
                'acceptedAnswer' => ['@type' => 'Answer', 'text' => trim(html_entity_decode(strip_tags($f['a']), ENT_QUOTES, 'UTF-8'))],
            ], $faq),
        ],
    ],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">

  <header class="lp-hero on-dark">
    <div class="wrap lp-hero-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <p class="tag">Educational guide</p>
        <h1>How We Review Online Casinos: Method, Scoring and the Australian Legal Position</h1>
        <p class="lead">How we review online casinos for Australian readers comes down to a fixed set of checks, applied in the same order, with evidence recorded so a reader can repeat them. This page explains the method so you can judge any review you read. It ranks no sites, quotes no offers and names no operators.</p>
        <p class="lp-hero-meta cred">
          <span>Written by: <?= e(SITE_NAME) ?> Editorial Team</span>
          <span>Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></span>
          <span><a href="/about/">About us</a></span>
          <span><a href="/about/#disclosure">Affiliate disclosure</a></span>
          <span><a href="/contact/">Report an error</a></span>
        </p>
      </div>
      <figure class="lp-hero-art"><?= gw_img('pages/online-casino-reviews', $seo['image_alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 520px, 100vw']) ?></figure>
    </div>
  </header>

<?php if (GW_SHOW_COMPARISON): ?>
  <section class="wrap cmp-sec" id="compare" aria-labelledby="compare-title">
<?php gw_comparison('reviews', 'What a review scorecard looks like', 'An illustration of how a review scorecard is built: each fictional brand is scored out of 10 across the same eight areas and weights described below, with a breakdown under every brand. The brands and every figure are invented and are not real reviews or ratings.'); ?>
  </section>
<?php endif; ?>

  <div class="wrap lp-layout">
    <div class="lp-side">
      <?php gw_promo(); ?>
      <aside class="lp-toc" aria-label="On this page">
        <h2>On this page</h2>
        <ul>
<?php if (GW_SHOW_COMPARISON): ?>
          <li><a href="#compare">Comparison table</a></li>
<?php endif; ?>
          <li><a href="#short-answer">The short answer</a></li>
          <li><a href="#areas">The eight areas we score</a></li>
          <li><a href="#law">The legal position first</a></li>
          <li><a href="#safety">Safety, licence, complaints</a></li>
          <li><a href="#payouts">Payout checks</a></li>
          <li><a href="#bonuses">Bonus terms</a></li>
          <li><a href="#other-areas">Games, tools, support, mobile</a></li>
          <li><a href="#scorecard">Ratings, weights, updates</a></li>
<?php if (!empty($reviewDocs)): ?>
          <li><a href="#documentation">How we document reviews</a></li>
<?php endif; ?>
          <li><a href="#judge">Judging any review site</a></li>
          <li><a href="#responsible">Responsible gambling</a></li>
          <li><a href="#resources">Official resources</a></li>
          <li><a href="#faq">FAQ</a></li>
        </ul>
      </aside>
      <aside class="help-card" aria-label="Need help">
        <p class="help-title">Need to talk to someone?</p>
        <p>Gambling Help Online is free and confidential, 24 hours a day.</p>
        <a class="help-num" href="tel:1800858858">1800 858 858</a>
      </aside>
    </div>

    <div class="lp-main lp-main--wide">

      <section class="lp-sec" id="short-answer">
        <h2>How we review online casinos: the short answer</h2>
        <p>A reviewer starts with the Australian legal position, then checks the licence, the operating company and security. Next come deposits and withdrawals, then the bonus terms line by line, then games, responsible gambling tools, support and mobile use. Only after that is a score assigned. A weak result in the early checks caps the final rating, however good the game lobby looks.</p>
        <div class="formula tldr" role="note" aria-label="Short summary">
          <p class="formula-label">In short</p>
          <ul class="checks">
            <li><strong>Same checks, same order.</strong> Legal position, then licence, company and security, then payments, bonus terms, games, responsible gambling tools, support and mobile. The score comes last.</li>
            <li><strong>Eight areas with stated weights.</strong> Licence, security and complaints, and payments together carry 55%, because they decide whether you can get your money back.</li>
            <li><strong>Weak early results cap the rating.</strong> A failed licence or ownership check, or a documented pattern of non-payment, limits the overall rating to 4/10.</li>
            <li><strong>A rating cannot promise safety, winnings, payment or legality.</strong> Operators are prohibited from offering online casino games to people in Australia. Check <a href="https://www.acma.gov.au" rel="noopener">ACMA</a>.</li>
            <li><strong>Judge any review site the same way.</strong> Look for disclosure, a published method and dated evidence.</li>
          </ul>
        </div>
        <div class="keyfacts">
          <div class="kf"><span class="kf-top">Same checks, same order</span><p>A fixed set of checks, applied in sequence, with evidence recorded so a reader can repeat them.</p></div>
          <div class="kf"><span class="kf-top">Legal position first</span><p>Many review pages bury or soften it. For Australians it is the most relevant fact.</p></div>
          <div class="kf"><span class="kf-top">Weak early results cap the score</span><p>A failed licence or ownership check limits the rating, however good the games look.</p></div>
        </div>
        <p>This page explains casino review methodology. It does not rank sites, quote bonus offers, name operators or link to any casino. A best-casinos list would need current licence checks, terms and payment records for every site, all of which change, and it would imply an endorsement of services that may be prohibited in Australia. What the page does is let you apply the same online casino evaluation criteria to any review you read and decide how far to trust it. Reliable casino review sites should publish their assessment criteria, explain their scoring system, provide dated evidence and disclose commercial relationships.</p>
        <aside class="lead-note">
          <strong>One point comes before any criterion.</strong> Under Australian federal law, offering online casino games such as pokies and table games to people in Australia is prohibited, and no review, rating or offshore licence changes that. <a href="#law">The legal section below</a> gives the full explanation. Check ACMA for the current position.
        </aside>
      </section>

      <section class="lp-sec" id="areas">
        <h2>Casino review methodology: the eight areas we score</h2>
        <p>Each review covers the same eight areas. The list, the sections of this page and the scoring table later on all use this order.</p>
        <div class="criteria">
          <div class="criterion"><h3>1. Licence, ownership and legal transparency</h3><p>Whether the licence number appears on the issuing regulator's own register, whether it matches the company named in the terms, and what the Interactive Gambling Act means for Australian access.</p></div>
          <div class="criterion"><h3>2. Security, privacy and complaint record</h3><p>How accounts, identity documents and data are protected, and what patterns appear in complaints.</p></div>
          <div class="criterion"><h3>3. Payments and withdrawals</h3><p>Methods, limits, fees, ID checks and what happens on a first withdrawal.</p></div>
          <div class="criterion"><h3>4. Bonus terms</h3><p>Wagering, game contribution, maximum bet, maximum cashout, expiry and clauses that void winnings.</p></div>
          <div class="criterion"><h3>5. Games and fairness information</h3><p>Variety, published return-to-player (RTP) details and independent testing evidence.</p></div>
          <div class="criterion"><h3>6. Responsible gambling tools</h3><p>Deposit limits, cooling-off, self-exclusion and how easy they are to find.</p></div>
          <div class="criterion"><h3>7. Support quality</h3><p>Contact channels, hours across Australian time zones and the accuracy of answers.</p></div>
          <div class="criterion"><h3>8. Mobile and usability</h3><p>Performance on phones, the cashier layout and whether terms are readable on a small screen.</p></div>
        </div>
        <p class="see-also"><strong>Our standard</strong> is that a review records what was checked, how a reader can verify it and what counts as a red flag, and says so plainly when an area could not be verified. Where this page says "our standard", it describes how a review should be done. The check date and evidence shown on any individual review are what tell you whether that happened.</p>

        <h3>What a review cannot promise</h3>
        <p>Online casino ratings summarise what a reviewer could check at one point in time. They cannot promise:</p>
        <div class="reasons">
          <div class="reason"><span class="ic" aria-hidden="true">!</span><div><h3>Safety</h3><p>A high score means a site passed the checks that could be run. It does not mean your money or data is protected, and overseas operators sit outside Australian consumer protections in ways no reviewer can fully assess.</p></div></div>
          <div class="reason"><span class="ic" aria-hidden="true">!</span><div><h3>Winnings</h3><p>Casino games carry a built-in house edge. No rating, strategy or bonus changes that, and you can lose every dollar you deposit.</p></div></div>
          <div class="reason"><span class="ic" aria-hidden="true">!</span><div><h3>Payment</h3><p>A site that paid a reviewer promptly can still delay or refuse another player's withdrawal.</p></div></div>
          <div class="reason"><span class="ic" aria-hidden="true">!</span><div><h3>Legality or permanence</h3><p>A review can describe the law but cannot make a prohibited service lawful. Terms, licences, ownership and domains also change, so a review is only as current as its last check.</p></div></div>
        </div>
      </section>

      <section class="lp-sec" id="law">
        <h2>The Australian legal position and why it comes first</h2>
        <figure class="shot"><?= gw_img('pages/rv-law', 'Shield with a tick beside the title The Law Comes First', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p class="lead-note">The legal position comes first because many review pages bury or soften it. This section is general information, not legal advice. Rules and enforcement approaches change, so check ACMA for the current position.</p>

        <h3>What the Interactive Gambling Act covers</h3>
        <p>The Interactive Gambling Act 2001 is the main federal law on online gambling in Australia. In general terms:</p>
        <ul class="checks">
          <li>It makes it an offence for operators to provide certain online gambling services, including casino-style games such as pokies and table games, to customers in Australia.</li>
          <li>It restricts advertising of those prohibited services.</li>
          <li>It treats other products differently. Licensed wagering on sports and racing, and lotteries, are regulated under separate arrangements, mainly through state and territory authorities. They are not online casinos, and the rules differ.</li>
        </ul>
        <p>The Interactive Gambling Act 2001 primarily targets providers of prohibited online gambling services. It makes it an offence for operators to offer certain online casino games to customers in Australia, whether the operator is based in Australia or overseas. The Act does not generally make customers the target of this provider offence. However, that does not mean offshore gambling services are safe, regulated for Australian consumers or covered by Australian consumer protections. To find out how the law applies to you personally, ask ACMA or a qualified lawyer rather than a review site, whose view may be shaped by commercial interests. Land-based pokies in pubs and clubs, and casinos operating under state or territory licences, are a separate matter and are not covered here. Our <a href="/online-gambling-laws-in-australia/">guide to Australian gambling law</a> goes further.</p>

        <h3>Why an overseas licence does not make a casino legal in Australia</h3>
        <p>Many online casinos display a licence from a foreign regulator. That shows only that the operator has some relationship with the regulator that issued it. It does not mean:</p>
        <div class="vs">
          <div class="vs-col vs-col--bad">
            <h3>What a foreign licence does not give you</h3>
            <ul>
              <li>Permission to offer casino games to people in Australia.</li>
              <li>Oversight by an Australian regulator.</li>
              <li>Australian consumer protection or dispute processes if something goes wrong.</li>
              <li>A guarantee the site stays reachable. ACMA can take steps against prohibited services, including requesting that access be blocked.</li>
            </ul>
          </div>
          <div class="vs-col">
            <h3>What the licence check is for</h3>
            <ul>
              <li>Identifying who runs the site and where.</li>
              <li>It is not a certificate that the site is acceptable for Australians.</li>
              <li>No licensing regulator should be treated as a guarantee of fair treatment.</li>
            </ul>
          </div>
        </div>

        <h3>Reforms to the law: what to check</h3>
        <?php
        /*
         * OWNER TODO (legal accuracy): replace the paragraph below with a short, VERIFIED summary of the amendments to the
         * Interactive Gambling Act: what was enacted, which provisions are already in force and which start later, using only
         * ACMA and the Federal Register of Legislation (legislation.gov.au).
         *
         * An SEO review of this site claims, and I could NOT verify: that the Interactive Gambling Amendment (Gambling
         * Reform) Act 2026 received Royal Assent on 26 August 2026, that most schedules commence on 1 January 2027, and that
         * Schedule 5 commenced on 27 August 2026. Check each of these on legislation.gov.au before publishing any of it.
         * Then set $legalChecked at the top of this file to the date you checked. Do not publish an unchecked date.
         */
        ?>
<?php if ($legalChecked): ?>
        <p class="see-also"><strong>Legal information last checked:</strong> <time datetime="<?= e($legalChecked) ?>"><?= e(gw_date($legalChecked)) ?></time>, against ACMA and the Federal Register of Legislation.</p>
<?php endif; ?>
        <p>The Interactive Gambling Act has been amended over time, and further reforms have been enacted or proposed in recent years. Which provisions are enacted, which are already in force and which start on a later date changes, and a general summary can be wrong or out of date. Check <a href="https://www.legislation.gov.au" rel="noopener">the Federal Register of Legislation</a> and <a href="https://www.acma.gov.au" rel="noopener">ACMA</a> for the current position, and do not assume that every reform is already in force.</p>

        <h3>Where to check the current position: ACMA</h3>
        <p>The Australian Communications and Media Authority (<a href="https://www.acma.gov.au" rel="noopener">ACMA</a>) is the federal regulator that enforces the Act's prohibitions on offering and advertising prohibited online gambling services. Its website explains the rules in plain language and publishes enforcement information, including blocked services. Rules and enforcement tools are updated from time to time, so check it for the current position. In practice, our standard is that no review presents a casino as a recommendation, that it flags when a site appears to target Australians, and that it says plainly when Australian consumer protections or dispute pathways are unlikely to apply.</p>
        <aside class="note"><p><strong>Important: BetStop does not cover offshore casinos.</strong> The national self-exclusion register applies to licensed Australian wagering services. Registering with it will not block access to an overseas casino, so do not treat it as protection against one. The <a href="#responsible">responsible gambling section</a> covers tools that do help.</p></aside>
      </section>

      <section class="lp-sec" id="safety">
        <h2>Online casino safety reviews: licence, ownership, security and complaints</h2>
        <figure class="shot"><?= gw_img('pages/rv-safety', 'Document with a magnifying glass beside the title Licence and Security Checks', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Online casino safety reviews should begin with who is behind a site and what recourse you would have. Games and bonuses come later. Everything in this section can be checked with a browser and a few minutes. Our guide to <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos</a> covers the wider picture.</p>

        <h3>Verifying the licence and operating company</h3>
        <p>Our standard is to verify a licence on the regulator's own register, never through a link or badge supplied by the casino. You can repeat the check:</p>
        <ol class="steps">
          <li><strong>Find the details.</strong> The licence number, licence holder and regulator's name are in the site's footer or terms.</li>
          <li><strong>Find the regulator yourself.</strong> Search for its official website and use its licence or operator register.</li>
          <li><strong>Match the details.</strong> The licence holder's name, the website address and the status (active, suspended, expired) should all match.</li>
          <li><strong>Check the scope.</strong> The licence should cover online casino games, not only another activity such as sports betting.</li>
          <li><strong>Check the company.</strong> Search the operating company named in the terms in the official company registry of the jurisdiction it claims, and note its registered address and any parent group.</li>
        </ol>
        <p>Fake or borrowed licence badges are a known tactic. A genuine register entry shows that the operator exists and is accountable to someone. It does not give you Australian consumer protection, and it does not guarantee fair treatment. Some findings stop a review and cap the rating before any time is spent on bonuses or games:</p>
        <div class="flags">
          <div class="flag"><h3>No verifiable licence</h3><p class="bad">No licence number, or a number that does not appear on the regulator's register.</p></div>
          <div class="flag"><h3>Mismatched holder</h3><p class="bad">A licence holder that does not match the company named in the terms.</p></div>
          <div class="flag"><h3>Hidden operator</h3><p class="bad">An operator that will not say who it is or where it is registered.</p></div>
          <div class="flag"><h3>Contradictory terms</h3><p class="bad">Terms that contradict each other or change without notice.</p></div>
          <div class="flag"><h3>Payout pattern</h3><p class="bad">A documented pattern of withheld or reduced payouts, or demands for extra deposits before a withdrawal.</p></div>
          <div class="flag"><h3>Copied brands</h3><p class="bad">Near-identical terms copied across many unrelated sites, which can suggest a network of thin brands.</p></div>
        </div>

        <h3>Security, privacy and complaint record</h3>
        <p>Casinos typically hold identity documents, payment details and transaction history, and an overseas operator may store that data under foreign privacy rules that differ from Australian expectations. A reviewer should work through the checks below and report what was found, not just a pass or fail.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Security, privacy and complaint checks</caption>
            <thead><tr><th scope="col">Check</th><th scope="col">How to verify it</th><th scope="col">Red flag</th></tr></thead>
            <tbody>
              <tr><th scope="row">Encrypted connection</th><td>Look for the padlock on every page, including the cashier. It shows only that the connection is encrypted, not that the operator is trustworthy.</td><td>A secure login page but an unsecured cashier or document upload.</td></tr>
              <tr><th scope="row">Login protection</th><td>Look in account settings for two-factor authentication and read how password resets work.</td><td>No option for stronger login protection.</td></tr>
              <tr><th scope="row">Privacy policy</th><td>Read it before registering. Look for plain statements on what is collected, how long it is kept, who it is shared with and how to request deletion.</td><td>Missing or vague policy, or sharing with marketing partners with no opt-out.</td></tr>
              <tr><th scope="row">Document handling</th><td>Confirm that ID is uploaded through a secure page inside your account.</td><td>Requests to send ID by email or chat.</td></tr>
              <tr><th scope="row">Complaint patterns</th><td>Search the casino's name with words such as complaint, withdrawal and verification on independent forums. Read the operator's replies, not just the complaints.</td><td>The same complaint repeated by many unconnected people, such as delayed withdrawals after a big win or accounts closed after a bonus was cleared.</td></tr>
              <tr><th scope="row">Dispute route</th><td>Read the site's complaints procedure and check whether it names an external dispute body and whether the licence regulator takes player complaints at all.</td><td>No external route, or an assumption that an Australian body can help with an overseas operator.</td></tr>
            </tbody>
          </table>
        </div>
        <p>One angry post tells you little, while the same story from many unrelated people tells you a lot. A pattern of complaints is not automatic proof of misconduct, so a reviewer should check credibility and corroboration: whether complaints are specific, whether the same details appear independently, and whether the operator's replies address them. Treat glowing and furious posts with equal caution, since either can be planted.</p>

        <h3>Scams, banks and Scamwatch</h3>
        <p>Some fake casino sites exist only to collect deposits and identity documents. If you suspect a site is a scam, stop depositing, do not send more documents and report it to <a href="https://www.scamwatch.gov.au" rel="noopener">Scamwatch</a>. If you have shared card or bank details, or think a payment was fraudulent, contact your bank straight away, because time matters. Be realistic about chargebacks: a bank may be able to act on an unauthorised or fraudulent transaction, but outcomes depend on your bank, the payment scheme and the circumstances, and a deposit you made yourself and then lost gambling may not be reversed. Offshore operators also sit outside Australian dispute schemes. If you have given identity documents to a site you no longer trust, <a href="https://www.idcare.org" rel="noopener">IDCARE</a> offers free support on protecting your identity.</p>
      </section>

      <section class="lp-sec" id="payouts">
        <h2>Casino payout reviews: how deposits and withdrawals are checked</h2>
        <figure class="shot"><?= gw_img('pages/rv-payout', 'Transaction list beside a clock and the title Payout Review Checks', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Casino payout reviews matter because the real test of a casino is whether you get your money back, not how easily you can put it in. This page does not recommend using any site, but if you are weighing a payment method, the checks below apply. Our <a href="/online-casino-payment-methods/">payment methods guide</a> compares the options in more detail.</p>

        <h3>Payment methods and current availability</h3>
        <p>A reviewer should list deposit and withdrawal methods separately, since they often differ.</p>
        <div class="mini3">
          <div><h4>PayID and bank transfer</h4><p>Familiar and convenient, but availability varies by site and by bank. Confirm that the site supports it for withdrawals as well as deposits.</p></div>
          <div><h4>POLi and similar services</h4><p>Availability has changed over time and varies by site, so verify that it is currently offered.</p></div>
          <div><h4>Debit and credit cards</h4><p>Widely listed, but banks may block or flag gambling transactions, and a declined payment does not always mean a problem with the casino. Credit cards mean gambling with borrowed money, which we advise against.</p></div>
          <div><h4>E-wallets and vouchers</h4><p>They add a layer between your bank and the site but may carry fees and limits, and are sometimes excluded from bonus offers.</p></div>
          <div><h4>Cryptocurrency</h4><p>Transfers are generally irreversible, values can swing between deposit and withdrawal, and network and exchange fees add up. Converting back to AUD is an extra step.</p></div>
        </div>
        <p>Check current availability with your bank and the site itself, because neither a review nor this page can keep pace with changes. A method that is easy for deposits may be unavailable or slow for withdrawals, and some sites require withdrawals to go back to the method used to deposit. Also check whether the site holds AUD accounts or converts from another currency, which can add exchange fees.</p>

        <h3>Withdrawal limits, fees and ID verification</h3>
        <p>The terms and the cashier should agree. A reviewer should record each item below and note where the two disagree.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Withdrawal checks</caption>
            <thead><tr><th scope="col">Check</th><th scope="col">How to verify it</th><th scope="col">Red flag</th></tr></thead>
            <tbody>
              <tr><th scope="row">Minimum, maximum and periodic caps</th><td>Search the terms for withdrawal, limit and pending. Note per-transaction amounts and any daily, weekly or monthly caps.</td><td>Caps found only in the terms and not in the cashier. A large win may be released in instalments.</td></tr>
              <tr><th scope="row">Fees</th><td>Compare the cashier with the terms. For illustration only, a hypothetical A$10 fee on a A$50 withdrawal takes 20% of it.</td><td>Unstated fees, or flat fees that swallow small withdrawals.</td></tr>
              <tr><th scope="row">ID verification (KYC)</th><td>Read which documents are required (commonly photo ID, proof of address and proof of payment method ownership) and when they are requested. See <a href="/kyc-verification-at-online-casinos/">our KYC guide</a>.</td><td>Verification demanded only after you request a withdrawal, requirements that change after a win, or repeated requests for the same documents.</td></tr>
              <tr><th scope="row">Pending period</th><td>Look for how long a withdrawal sits before it is approved, and whether you can cancel it.</td><td>Long pending periods, especially if you can cancel and keep playing.</td></tr>
            </tbody>
          </table>
        </div>
        <p>Completing verification early can speed processing. Never send documents to anyone who contacts you unprompted claiming to be the casino.</p>

        <h3>Logging a first withdrawal</h3>
        <p>A reviewer who tests with real money should keep a simple log, and a review should say whether one exists. This page does not suggest readers deposit in order to repeat it. A good log contains:</p>
        <ol class="steps">
          <li><strong>The deposit.</strong> Date, time, method, amount and any fee.</li>
          <li><strong>Verification.</strong> Which documents were requested, and when.</li>
          <li><strong>The request.</strong> The time, method and amount of the withdrawal request.</li>
          <li><strong>Each status change.</strong> Pending, approved, processing, with timestamps.</li>
          <li><strong>The arrival.</strong> When the funds arrived, the amount received, any deductions, and whether a weekend or public holiday fell in between.</li>
        </ol>
        <p>A single test is one data point. It shows how the process worked once, cannot establish consistent payout performance, and does not forecast what will happen to someone else's larger withdrawal.</p>

        <h3>Why advertised payout speeds need checking</h3>
        <p>Headline phrases such as instant or same-day withdrawals describe the best case. An internal approval period often comes before the payment is sent, and the advertised speed may cover only the second step. Your bank's processing time and the chosen method add to the total, first withdrawals and larger amounts are more likely to be reviewed manually, and verification, bonus conditions and weekends can all cause delays. For that reason a review should present payout times only as observed on a specific occasion, with the method and date logged. When you read any payout claim, look for the method, the amount, whether verification was already complete and whether the figure includes the pending period. See also <a href="/what-affects-casino-withdrawal-speed/">what affects withdrawal speed</a>.</p>
      </section>

      <section class="lp-sec" id="bonuses">
        <h2>Casino bonus reviews: reading the terms behind the headline offer</h2>
        <p>Casino bonus reviews that only repeat the headline offer are advertising. The value of a bonus sits in its terms. This page does not list offers, but it shows how to read them. Our <a href="/online-casino-bonuses/">bonuses guide</a> goes further, with a calculator.</p>

        <h3>Wagering requirements and game contribution</h3>
        <p>The wagering requirement is how many times a sum must be bet before bonus-related winnings can be withdrawn. The first thing to find is what it applies to: the bonus alone, or the deposit plus the bonus. The second is the game contribution table, which shows what share of each bet counts. Pokies often count in full, while table games and live dealer games commonly count for much less or not at all, though this varies by site. Read the bonus terms page, not the promotional banner. Check whether the bonus is sticky, meaning the bonus amount itself is removed from any withdrawal.</p>

        <h3>Maximum bet, maximum cashout and expiry</h3>
        <div class="mini3 mini3--4">
          <div><h4>Maximum bet</h4><p>Many sites cap bet size while a bonus is active. Going over the cap, even by accident, can void the bonus and any winnings from it.</p></div>
          <div><h4>Maximum cashout</h4><p>Some bonuses cap how much you can withdraw from bonus-related winnings, however much you win. Check whether the cap also applies to free spins winnings.</p></div>
          <div><h4>Expiry</h4><p>Bonuses and free spins usually expire after a set period. A short window combined with a heavy requirement can make completion unrealistic.</p></div>
          <div><h4>Restricted games and methods</h4><p>Some games are excluded, and some deposit methods, such as certain e-wallets, may not qualify for the bonus at all.</p></div>
        </div>
        <p>Search the terms for the words maximum, cap, expire, excluded and void. If the bonus terms and the general terms disagree, note which one the site says takes priority.</p>

        <h3>A worked example in AUD</h3>
        <p>The numbers are hypothetical and chosen for simple arithmetic. They do not describe any specific casino. Suppose a site offers a 100% match on a A$100 deposit, so you hold A$100 of your own money plus a A$100 bonus. The terms say wagering is 30 times the bonus amount, pokies contribute 100% and table games 10%, the maximum bet is A$5, and the maximum cashout from bonus-related winnings is A$500.</p>
        <div class="example" role="group" aria-label="Worked example of wagering on bonus only versus deposit plus bonus">
          <div class="ex-col">
            <p class="ex-title">Wagering on the bonus only</p>
            <p class="ex-sum">30 x A$100</p>
            <p class="ex-big">A$3,000</p><p class="ex-lbl">of bets on pokies</p>
            <p class="ex-big ex-big--cost">about A$120</p><p class="ex-lbl">expected cost at a 4% edge</p>
          </div>
          <div class="ex-col ex-col--hot">
            <p class="ex-title">Wagering on deposit plus bonus</p>
            <p class="ex-sum">30 x A$200</p>
            <p class="ex-big">A$6,000</p><p class="ex-lbl">of bets on pokies</p>
            <p class="ex-big ex-big--cost">about A$240</p><p class="ex-lbl">expected cost at a 4% edge</p>
          </div>
        </div>
        <div class="mini3">
          <div><h4>Effect of contribution</h4><p>On table games at 10%, each A$10 bet counts as A$1, so clearing A$3,000 would take A$30,000 of bets.</p></div>
          <div><h4>Effect of the house edge</h4><p>Assume, purely for arithmetic, a pokie returning 96% long run: an average theoretical loss of 4%, which is A$120 on A$3,000. The expected cost then exceeds what a A$100 bonus is worth. Expected cost is a simplified theoretical estimate, not a guaranteed loss, and real sessions vary widely around that average.</p></div>
          <div><h4>Effect of the caps</h4><p>At a A$5 maximum bet you need at least 600 bets to place A$3,000 in wagers, one oversized bet could void the bonus, and even a large win could be capped at A$500.</p></div>
        </div>
        <p>The point is not that every bonus is a bad deal. It is that the headline number tells you very little until the arithmetic is done with the real terms. A good bonus review shows this working and describes the outcome in plain language rather than a star rating alone.</p>

        <h3>Terms that make a bonus poor value</h3>
        <div class="vs">
          <div class="vs-col vs-col--bad">
            <h3>Mark it down, or skip it, if</h3>
            <ul>
              <li>A high wagering multiple applies to deposit plus bonus, combined with a short expiry.</li>
              <li>The maximum cashout is very low compared with the deposit needed, or the maximum bet is so low that completion is impractical.</li>
              <li>Vague clauses allow the operator to void winnings for unspecified irregular play.</li>
              <li>Terms can change after you accept the bonus, without notice.</li>
              <li>The bonus locks your own deposit until the requirement is met, with no clear way to forfeit it and withdraw, or you are pressed to deposit more to keep it alive.</li>
            </ul>
          </div>
          <div class="vs-col">
            <h3>Remember</h3>
            <ul>
              <li>Declining a bonus is usually allowed and often simpler.</li>
              <li>Check how to opt out before you deposit.</li>
              <li>A generous-looking bonus never lifts a rating above what the safety and payment scores allow.</li>
            </ul>
          </div>
        </div>
      </section>

      <section class="lp-sec" id="other-areas">
        <h2>Games, responsible gambling tools, support and mobile use</h2>
        <p>Game selection is the part most readers enjoy comparing, but it carries the least weight in judging safety. A large lobby says nothing about whether a site is trustworthy, which is why these four areas carry less weight than licence, security, payments and bonus terms.</p>
        <div class="bcards">
          <article class="bc">
            <p class="opt-tag">Area 5</p>
            <h3>Games and fairness information</h3>
            <p>A reviewer should look at the range across pokies, table games and live dealer, which providers supply them, and whether RTP information is published. RTP is the long-run percentage of money wagered that a game is designed to return over a very large number of plays. It is not a promise about your session, and some providers let operators choose between several RTP settings for the same game. If the RTP is not shown, treat that as a gap in transparency.</p>
            <p class="bc-check"><strong>Check:</strong> badges from independent testing laboratories are a prompt to check, not proof. A certificate shows a game was tested at a point in time, not that the operator pays winnings. Go to the lab's own website and see whether it lists the operator or provider. A badge that links nowhere is a weak signal. See <a href="/understanding-rtp-and-volatility-in-online-slots/">our RTP guide</a>.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Area 6</p>
            <h3>Responsible gambling tools</h3>
            <p>These are a scored criterion, not an afterthought. A reviewer should check whether the site offers deposit limits (daily, weekly or monthly, with a decrease applying immediately and a raise taking effect after a delay), loss limits and session time reminders, cooling-off or time-out periods, and self-exclusion, with how long it lasts and how it can be reversed.</p>
            <p class="bc-check"><strong>Check:</strong> that these tools are easy to reach without contacting support, with links to support organisations. Because BetStop does not cover offshore casinos, check each site's own self-exclusion process, and use blocking tools on your devices or ask your bank about gambling blocks. See <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools</a>.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Area 7</p>
            <h3>Support quality</h3>
            <p>A reviewer should record the contact options (live chat, email, phone), the hours they cover and whether those hours make sense across Australian time zones. They should then ask a specific question about the bonus terms or withdrawal process, record how long a reply takes and compare the answer with the written terms.</p>
            <p class="bc-check"><strong>Check:</strong> support that is quick but vague or contradictory scores poorly. Save any written answer so you have a record if it later differs from the terms.</p>
          </article>
          <article class="bc">
            <p class="opt-tag">Area 8</p>
            <h3>Mobile performance and usability</h3>
            <p>Many people play on phones, so a review should test the site in a mobile browser and, where one exists, the app. Check load times, whether the cashier works smoothly, whether games run properly and whether terms and limits are readable on a small screen.</p>
            <p class="bc-check"><strong>Check:</strong> whether an app comes from a recognised app store or must be installed from the casino's own site, which carries added risk. See <a href="/mobile-casino-gaming-apps-vs-browser/">apps vs browser play</a>.</p>
          </article>
        </div>
      </section>

      <section class="lp-sec" id="scorecard">
        <h2>Online casino ratings: scoring, weights and updates</h2>
        <figure class="shot"><?= gw_img('pages/rv-rating', 'Checklist card beside the title How Ratings Work', ['sizes' => '(min-width: 960px) 760px, 100vw']) ?></figure>
        <p>Online casino ratings look objective because they are numbers, but a number depends on the weights behind it and who set them. Stating the weights lets you disagree with them.</p>

        <h3>How online casino ratings are weighted</h3>
        <p>The table is an illustrative framework with the same eight areas, in the same order, as the list near the top of this page. It is not an industry standard, and other reviewers will weight things differently. Each area is scored out of 10 and multiplied by its weight, giving an overall score out of 10.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Illustrative scoring weights across eight areas</caption>
            <thead><tr><th scope="col">Area</th><th scope="col">Weight</th><th scope="col">What it covers</th></tr></thead>
            <tbody>
              <tr><th scope="row">1. Licence, ownership and legal transparency</th><td>20%</td><td>Register check, matching company details, Australian-access position</td></tr>
              <tr><th scope="row">2. Security, privacy and complaint record</th><td>15%</td><td>Account protection, privacy terms, complaint patterns, dispute route</td></tr>
              <tr><th scope="row">3. Payments and withdrawals</th><td>20%</td><td>Methods, limits, fees, verification, first-withdrawal log</td></tr>
              <tr><th scope="row">4. Bonus terms</th><td>15%</td><td>Wagering, contribution, caps, expiry, clarity</td></tr>
              <tr><th scope="row">5. Games and fairness information</th><td>8%</td><td>Variety, published RTP, testing evidence</td></tr>
              <tr><th scope="row">6. Responsible gambling tools</th><td>10%</td><td>Limits, cooling-off, self-exclusion, visibility</td></tr>
              <tr><th scope="row">7. Support quality</th><td>8%</td><td>Channels, hours, accuracy of answers</td></tr>
              <tr><th scope="row">8. Mobile and usability</th><td>4%</td><td>Performance, layout, cashier on phones</td></tr>
              <tr><th scope="row">Total</th><td><strong>100%</strong></td><td>Each area scored out of 10, then weighted</td></tr>
            </tbody>
          </table>
        </div>
        <p>The weights are editorial judgement, not a formula from any regulator. Licence, security and complaint record, and payments together make up 55%, because they decide whether you can get your money back and whether your data is handled safely. Bonus terms carry 15% because that is where costs hide. Games carry 8% because lobby size says little about trustworthiness. You may weigh things differently, and the point is that the weights are stated. Three rules sit on top of the table:</p>
        <div class="mini3">
          <div><h4>Gating</h4><p>If a site fails the licence or ownership check, or shows a documented pattern of non-payment, the overall rating is capped at 4/10 whatever the other scores. A rating of 4/10 or lower is a warning, not a mid-range result.</p></div>
          <div><h4>Evidence and transparency</h4><p>A score is given only where there is something to point to, such as a register entry, a quoted clause or a logged test. Otherwise the area is marked not verified and treated as a gap, not a pass. Each review shows its last-checked date.</p></div>
          <div><h4>No bonus inflation</h4><p>A generous-looking bonus cannot lift a rating above what the safety and payment scores allow.</p></div>
        </div>
        <p>A high score does not reduce the house edge, predict faster payment or make a site legal for Australians. It reflects how well a site did against these criteria when it was last checked.</p>

        <h3>A worked calculation of an overall score</h3>
        <p>Each area score is multiplied by its weight, and the eight results are added. These scores are invented for illustration and describe no real casino.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Example of how eight area scores combine into one overall rating</caption>
            <thead><tr><th scope="col">Area</th><th scope="col">Score out of 10</th><th scope="col">Weight</th><th scope="col">Weighted contribution</th></tr></thead>
            <tbody>
              <tr><th scope="row">1. Licence, ownership and legal transparency</th><td>8</td><td>20%</td><td>1.60</td></tr>
              <tr><th scope="row">2. Security, privacy and complaint record</th><td>7</td><td>15%</td><td>1.05</td></tr>
              <tr><th scope="row">3. Payments and withdrawals</th><td>6</td><td>20%</td><td>1.20</td></tr>
              <tr><th scope="row">4. Bonus terms</th><td>6</td><td>15%</td><td>0.90</td></tr>
              <tr><th scope="row">5. Games and fairness information</th><td>8</td><td>8%</td><td>0.64</td></tr>
              <tr><th scope="row">6. Responsible gambling tools</th><td>7</td><td>10%</td><td>0.70</td></tr>
              <tr><th scope="row">7. Support quality</th><td>7</td><td>8%</td><td>0.56</td></tr>
              <tr><th scope="row">8. Mobile and usability</th><td>8</td><td>4%</td><td>0.32</td></tr>
              <tr><th scope="row">Overall before gating</th><td></td><td><strong>100%</strong></td><td><strong>6.97, shown as 7.0 out of 10</strong></td></tr>
            </tbody>
          </table>
        </div>
        <p>The gating rules are applied after this sum. If the same site had failed the licence or ownership check, the 7.0 would be capped at 4/10.</p>

        <h3>How verification status affects a score</h3>
        <?php
        /*
         * OWNER NOTE: the rule below is a proposed, illustrative method. Change the numbers to whatever you actually apply,
         * and only publish it if reviews really work this way.
         */
        ?>
        <p>Every area is labelled with one of three statuses, so that a reader can see how much evidence sits behind a number.</p>
        <div class="mini3">
          <div><h4>Verified</h4><p>Supported by direct evidence or an official source, such as a register entry, a quoted clause or a logged test. The area is scored in full.</p></div>
          <div><h4>Partially verified</h4><p>Some evidence exists, but important details remain unconfirmed. The area is scored only on what was confirmed, and capped at 6 out of 10.</p></div>
          <div><h4>Not verified</h4><p>No reliable evidence was available. The area scores 0 and is labelled as a gap, never treated as a pass.</p></div>
        </div>

        <h3>When reviews should be re-checked</h3>
        <p>A review that is never revisited becomes misleading. It should be re-checked when any of these happen:</p>
        <ul class="checks">
          <li>Bonus, withdrawal or general terms change.</li>
          <li>A licence is suspended, expires, is replaced or moves to a different company.</li>
          <li>A new pattern of similar complaints appears, particularly about payments.</li>
          <li>The site changes owner, rebrands or moves domains.</li>
          <li>ACMA or the issuing regulator takes relevant action, or a credible reader correction arrives.</li>
        </ul>
        <p>Reviews should also be re-checked on a regular schedule even if nothing seems to have changed. A review with no check date, or one untouched for a long time, should be read as historical.</p>

        <h3>Affiliate links, disclosure and editorial independence</h3>
        <p>Many casino review sites earn money when readers click through to a casino and sign up. That is a conflict of interest, and it can bias which sites are featured and how they are scored. GrandWhisper may earn a commission in the same way, so you should know how we aim to manage it: see our <a href="/about/#disclosure">affiliate disclosure</a>. Our standard is:</p>
        <ul class="checks">
          <li>Any review containing a commercial link says so clearly, near the top, in plain language, not only in a footer.</li>
          <li>Commission, sponsorship or advertising does not influence ratings, and operators cannot buy a better score or the removal of a finding.</li>
          <li>Negative findings such as slow payments or abusive terms are published even where a commercial relationship exists.</li>
          <li>Casinos are ordered by score, not commission rate, and corrections are made when evidence supports them.</li>
        </ul>
      </section>

<?php if (!empty($reviewDocs)): ?>
      <section class="lp-sec" id="documentation">
        <h2>How we document our reviews</h2>
        <div class="mini3 mini3--4">
<?php foreach ($reviewDocs as $row): ?>
          <div><h4><?= e($row[0]) ?></h4><p><?= e($row[1]) ?></p></div>
<?php endforeach; ?>
        </div>
      </section>
<?php endif; ?>

      <section class="lp-sec" id="judge">
        <h2>How to judge any casino review site</h2>
        <p>Use these eight questions on any source of trusted online casino reviews, including this one:</p>
        <div class="rg-card checklist-card">
          <ol class="checks checks--num">
            <li><strong>Does it start with the legal position?</strong> A review that never mentions the Interactive Gambling Act or ACMA leaves out the most relevant fact for Australians.</li>
            <li><strong>Is it clear how the site makes money?</strong> Affiliate disclosure should be prominent, not buried.</li>
            <li><strong>Is the method published?</strong> Look for named criteria, weights and rules for capping scores, not just a claim of rigorous testing.</li>
            <li><strong>Can you verify the claims?</strong> Be sceptical of boasts about hours spent, casinos reviewed or real money tested unless there is evidence such as dated logs or screenshots.</li>
            <li><strong>Does it say what it could not check, and include negatives?</strong> If every casino scores in a narrow high band, the ratings are probably marketing.</li>
            <li><strong>Are licence details checkable?</strong> You should be able to match licence numbers to official registers.</li>
            <li><strong>Are bonus and payout claims specific?</strong> Good reviews do the arithmetic, mention caps and exclusions, and name the method, amount and verification status behind any payout time.</li>
            <li><strong>Is it current and realistic?</strong> It should show when it was last checked, cover responsible gambling beyond a footer logo, and never imply guaranteed wins, beat-the-house strategies or risk-free offers.</li>
          </ol>
        </div>
      </section>

      <section class="lp-sec" id="responsible">
        <h2>Responsible gambling note</h2>
        <div class="rg-card">
          <p>You must be 18 or over to gamble. Set deposit and time limits before you start, never chase losses and never treat gambling as a way to make money. No winnings are guaranteed, and RTP figures describe long-run averages only.</p>
          <p>If gambling is affecting you or someone close to you, Gambling Help Online (<a href="tel:1800858858">1800 858 858</a>) offers free, confidential support and can connect you with services in your state or territory. If you are in crisis, Lifeline is on <a href="tel:131114">13 11 14</a>. More support is on our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
        </div>
      </section>

      <section class="lp-sec" id="resources">
        <h2>Official Australian resources</h2>
        <p>Check important points yourself with the official sources below. Laws and enforcement approaches change, so confirm current details with them directly.</p>
        <div class="table-wrap">
          <table class="data">
            <caption>Official resources and what they are for</caption>
            <thead><tr><th scope="col">Resource</th><th scope="col">What it is for</th></tr></thead>
            <tbody>
              <tr><th scope="row"><a href="https://www.acma.gov.au" rel="noopener">ACMA</a></th><td>Interactive gambling law, enforcement and blocked services</td></tr>
              <tr><th scope="row"><a href="https://www.scamwatch.gov.au" rel="noopener">Scamwatch</a></th><td>Reporting and avoiding scams</td></tr>
              <tr><th scope="row"><a href="https://www.idcare.org" rel="noopener">IDCARE</a></th><td>Free support if your identity documents or details have been compromised</td></tr>
              <tr><th scope="row"><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a></th><td>National self-exclusion register for licensed online and phone wagering</td></tr>
              <tr><th scope="row"><a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a></th><td>Free, confidential support, 24 hours a day on 1800 858 858</td></tr>
              <tr><th scope="row"><a href="https://www.lifeline.org.au" rel="noopener">Lifeline</a></th><td>Crisis support on 13 11 14</td></tr>
            </tbody>
          </table>
        </div>
      </section>

      <section class="lp-sec faq" id="faq">
        <h2>FAQ: online casino reviews in Australia</h2>
<?php foreach ($faq as $item): ?>
        <details>
          <summary><?= e($item['q']) ?></summary>
          <p><?= $item['a'] ?></p>
        </details>
<?php endforeach; ?>
      </section>

      <div class="callout-link">
        <p><strong>Your next step: check before you trust any review</strong> Read ACMA's information on online gambling so you have the legal position in front of you. Test any review you rely on against the eight questions above, and confirm its licence details on the regulator's own register. If you gamble at all, set firm deposit and time limits in advance.</p>
        <a class="btn btn--ruby" href="/online-gambling-laws-in-australia/">Read the law guide</a>
      </div>

      <aside class="note">
        <p><strong>Play responsibly.</strong> Gambling is for adults only (18+), and no review or rating can guarantee safety or winnings. If gambling stops feeling like a choice, call Gambling Help Online on <a href="tel:1800858858">1800 858 858</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Related guides</h2>
      <div class="related-grid">
<?php foreach (['how-to-choose-a-real-money-online-casino', 'kyc-verification-at-online-casinos', 'what-affects-casino-withdrawal-speed', 'best-online-casinos-australia-2026', 'casino-withdrawal-speed-test-what-matters', 'new-online-casinos-australia-2026'] as $slug) { if ($r = gw_article($slug)) { echo gw_card($r, 'std'); } } ?>
      </div>
    </div>
  </section>
<?php gw_topic_block(['choosing', 'kyc', 'control']); ?>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>