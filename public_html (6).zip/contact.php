<?php
/**
 * Contact page (served at /contact/).
 * Sends mail with PHP mail(). Protected by a CSRF token, a honeypot, server-side validation, a 30-second per-session
 * limit and a persistent per-visitor limit (a one-way hashed IP kept in data/contact-throttle.json for under an hour).
 *
 * OWNER NOTES:
 * - mail() returning true only means the server accepted the message, not that it was delivered. MAIL_FROM (config.php)
 *   must be a mailbox on your own domain, and you should set up SPF, DKIM and DMARC for it in Hostinger.
 * - Failures are written to the server error log WITHOUT the visitor's message.
 * - The privacy policy describes the short-lived throttle record. Keep the two in step if you change either.
 */

// Session cookie hardening (the session is used only for the form's security token and the 30-second limit).
$isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
        || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/contact/',
    'secure'   => $isHttps,
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();
require __DIR__ . '/includes/functions.php';

/**
 * Persistent throttle: at most 5 attempts per visitor per 10 minutes, counting failed attempts too.
 * Stores only a salted one-way hash of the IP address and timestamps, and deletes entries after an hour.
 * Returns true if the attempt is allowed. If the data folder cannot be written, it fails open.
 */
function gw_contact_allowed(): bool
{
    $dir  = __DIR__ . '/data';
    $file = $dir . '/contact-throttle.json';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (!is_dir($dir) || !is_writable($dir)) {
        return true;
    }
    $fh = @fopen($file, 'c+');
    if (!$fh) {
        return true;
    }
    flock($fh, LOCK_EX);
    $data = json_decode((string) stream_get_contents($fh), true);
    if (!is_array($data) || empty($data['salt']) || !isset($data['hits']) || !is_array($data['hits'])) {
        $data = ['salt' => bin2hex(random_bytes(16)), 'hits' => []];
    }
    $now = time();
    foreach ($data['hits'] as $k => $times) {
        $times = array_values(array_filter((array) $times, fn($t) => $now - (int) $t < 3600));
        if ($times) { $data['hits'][$k] = $times; } else { unset($data['hits'][$k]); }
    }
    $key     = hash_hmac('sha256', (string) ($_SERVER['REMOTE_ADDR'] ?? ''), $data['salt']);
    $recent  = array_filter($data['hits'][$key] ?? [], fn($t) => $now - $t < 600);
    $allowed = count($recent) < 5;
    $data['hits'][$key]   = array_slice(array_merge($data['hits'][$key] ?? [], [$now]), -20);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($data));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $allowed;
}

$topics = ['General question', 'Report an error or correction', 'Copyright or takedown notice', 'Partnership or advertising', 'Something else'];
$errors = [];
$sent   = false;
$old    = ['name' => '', 'email' => '', 'topic' => $topics[0], 'message' => ''];

if (empty($_SESSION['gw_csrf'])) {
    $_SESSION['gw_csrf'] = bin2hex(random_bytes(16));
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['name']    = trim((string) ($_POST['name'] ?? ''));
    $old['email']   = trim((string) ($_POST['email'] ?? ''));
    $old['topic']   = (string) ($_POST['topic'] ?? '');
    $old['message'] = trim((string) ($_POST['message'] ?? ''));

    if (!hash_equals($_SESSION['gw_csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $errors[] = 'Your session expired. Please reload the page and try again.';
    } elseif (!gw_contact_allowed()) {
        $errors[] = 'Too many attempts. Please wait a few minutes and try again.';
    } elseif (!empty($_POST['website'])) {
        // Honeypot filled in: pretend success, send nothing.
        $sent = true;
    } else {
        if ($old['name'] === '' || mb_strlen($old['name']) > 80) $errors[] = 'Please enter your name (up to 80 characters).';
        if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || strlen($old['email']) > 120) $errors[] = 'Please enter a valid email address.';
        if (!in_array($old['topic'], $topics, true)) {
            $errors[] = 'Please select a valid topic.';
            $old['topic'] = $topics[0];
        }
        $len = mb_strlen($old['message']);
        if ($len < 10 || $len > 3000) $errors[] = 'Please write a message between 10 and 3000 characters.';
        if (!empty($_SESSION['gw_last']) && time() - $_SESSION['gw_last'] < 30) $errors[] = 'Please wait a moment before sending another message.';

        if (!$errors) {
            $name  = str_replace(["\r", "\n"], ' ', $old['name']);
            $email = str_replace(["\r", "\n"], '', $old['email']);
            $body  = "Name: $name\nEmail: $email\nTopic: {$old['topic']}\n\n{$old['message']}\n";
            $headers = [
                'From'         => SITE_NAME . ' <' . MAIL_FROM . '>',
                'Reply-To'     => $email,
                'Content-Type' => 'text/plain; charset=UTF-8',
                'X-Mailer'     => 'PHP/' . PHP_VERSION,
            ];
            $ok = @mail(CONTACT_EMAIL, '[' . SITE_NAME . '] ' . $old['topic'], $body, $headers);
            if ($ok) {
                $sent = true;
                $_SESSION['gw_last'] = time();
                $_SESSION['gw_csrf'] = bin2hex(random_bytes(16));
                $old = ['name' => '', 'email' => '', 'topic' => $topics[0], 'message' => ''];
            } else {
                error_log('GrandWhisper contact form: mail() returned false (message content not logged).');
                $errors[] = 'Sorry, your message could not be sent. Please email us directly at ' . CONTACT_EMAIL . '.';
            }
        }
    }
}

$seo = [
    'title'       => 'Contact GrandWhisper',
    'description' => 'Contact GrandWhisper with questions, corrections or partnership enquiries. Find out how to reach our editorial team.',
    'path'        => '/contact/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Contact', '/contact/']],
    'schema'      => [[
        '@type'     => 'ContactPage',
        '@id'       => gw_abs('/contact/') . '#webpage',
        'url'       => gw_abs('/contact/'),
        'name'      => 'Contact GrandWhisper',
        'inLanguage'=> 'en-AU',
        'isPartOf'  => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Contact us</h1>
      <p class="lead">Questions, corrections and partnership enquiries are all welcome.</p>
    </div>
  </header>

  <div class="wrap contact-grid">
    <div>
      <?php if ($sent): ?>
        <p class="alert alert--ok" role="status">Thank you. Your message has been submitted successfully. We will review your enquiry and respond if a reply is required.</p>
      <?php endif; ?>
      <?php if ($errors): ?>
        <div class="alert alert--err" role="alert"><ul style="margin:0;padding-left:1.1rem"><?php foreach ($errors as $err): ?><li><?= e($err) ?></li><?php endforeach; ?></ul></div>
      <?php endif; ?>

      <form class="form" action="/contact/" method="post">
        <input type="hidden" name="csrf" value="<?= e($_SESSION['gw_csrf']) ?>">
        <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
        <div class="field">
          <label for="f-name">Your name</label>
          <input id="f-name" name="name" type="text" maxlength="80" autocomplete="name" required value="<?= e($old['name']) ?>">
        </div>
        <div class="field">
          <label for="f-email">Email address</label>
          <input id="f-email" name="email" type="email" maxlength="120" autocomplete="email" required value="<?= e($old['email']) ?>">
        </div>
        <div class="field">
          <label for="f-topic">What is this about?</label>
          <select id="f-topic" name="topic">
            <?php foreach ($topics as $t): ?><option<?= $old['topic'] === $t ? ' selected' : '' ?>><?= e($t) ?></option><?php endforeach; ?>
          </select>
        </div>
        <div class="field">
          <label for="f-message">Message</label>
          <textarea id="f-message" name="message" maxlength="3000" required><?= e($old['message']) ?></textarea>
          <small>We use the information you provide to handle your enquiry and respond to you. See our <a href="/privacy-policy/">privacy policy</a> for details about how we handle personal information.</small>
        </div>
        <button class="btn btn--ruby" type="submit">Send message</button>
      </form>
    </div>

    <aside class="about-aside" aria-label="Before you write">
      <h2>Before you write</h2>
      <ul>
        <li>We cannot help recover money from a casino or judge individual disputes, but our <a href="/safe-and-trusted-online-casinos/">trusted casinos guide</a> explains where to take a complaint.</li>
        <li>If gambling is causing you harm, please see <a href="/responsible-gambling/">our responsible gambling page</a> for free, confidential help.</li>
        <li>Spotted an error? Tell us which page and what is wrong, and include a source if you can.</li>
      </ul>
    </aside>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>