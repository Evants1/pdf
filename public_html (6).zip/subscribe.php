<?php
/**
 * Newsletter sign-up (served at /subscribe/).
 * Double opt-in: the visitor is added as "pending" and emailed a confirmation link (see subscribe-confirm.php).
 * Protections: honeypot field, a timing token, and a limit of 5 attempts per hour per visitor (stored as a one-way hash).
 * The visitor always sees the same neutral message, so the form cannot be used to find out who is subscribed.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/newsletter.php';

$messages = [
    'sent'    => ['ok',  'Thank you. If that address can be subscribed, we have just emailed it a confirmation link. Please open the email and press the confirm button. Nothing is sent to you until you do. If it has not arrived after a few minutes, check your spam folder.'],
    'invalid' => ['err', 'That email address does not look right. Please check it and try again.'],
    'expired' => ['err', 'The form timed out. Please try again.'],
    'busy'    => ['err', 'There have been too many sign-up attempts from this connection. Please try again in an hour.'],
    'error'   => ['err', 'Sorry, we could not send the confirmation email just now. Please try again later or use our contact page.'],
    'down'    => ['err', 'Sign-ups are temporarily unavailable. Please try again later.'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $go = function (string $r): void {
        header('Location: /subscribe/?r=' . $r, true, 303);
        exit;
    };
    $email = trim((string) ($_POST['email'] ?? ''));
    if (!empty($_POST['website'])) {
        $go('sent');                                   // honeypot filled in: pretend success, do nothing
    }
    if (!gw_nl_valid($email)) {
        $go('invalid');
    }
    if (!gw_form_token_ok((string) ($_POST['ts'] ?? ''))) {
        $go('expired');
    }
    try {
        $key = 'sub|' . gw_ip_key();
        if (gw_rate_count($key, 3600) >= 5) {
            $go('busy');
        }
        gw_rate_add($key);
        $go(gw_nl_subscribe($email) === 'error' ? 'error' : 'sent');
    } catch (Throwable $e) {
        error_log('GrandWhisper newsletter sign-up failed: ' . get_class($e));
        $go('down');
    }
}

$r = (string) ($_GET['r'] ?? '');
$notice = $messages[$r] ?? null;

$seo = [
    'title'       => 'Newsletter Sign-up',
    'description' => 'Subscribe to the GrandWhisper newsletter for new casino guides and explainers.',
    'path'        => '/subscribe/',
    'robots'      => 'noindex,follow',
    'body_class'  => 'is-doc',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap search-page">
    <h1>Newsletter</h1>
<?php if ($notice): ?>
    <p class="alert alert--<?= e($notice[0]) ?>" role="<?= $notice[0] === 'ok' ? 'status' : 'alert' ?>"><?= e($notice[1]) ?></p>
<?php endif; ?>
<?php if ($r === 'sent'): ?>
    <p><a href="/">Back to the magazine</a></p>
<?php else: ?>
    <p>New guides and explainers by email, nothing else. We email a confirmation link first, and every email has a one-click unsubscribe link. You must be 18 or over.</p>
    <form class="form" action="/subscribe/" method="post">
      <div class="field">
        <label for="s-email">Email address</label>
        <input id="s-email" type="email" name="email" maxlength="120" autocomplete="email" required>
      </div>
      <input type="hidden" name="ts" value="<?= e(gw_form_token()) ?>">
      <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
      <button class="btn btn--ruby" type="submit">Subscribe</button>
      <p class="calc-fine">See our <a href="/privacy-policy/">privacy policy</a>.</p>
    </form>
<?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
