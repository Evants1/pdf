<?php
/**
 * Terms and Conditions (served at /terms-and-conditions/).
 *
 * OWNER NOTES (read before publishing). These are starter terms, not legal advice. Have them reviewed by a qualified
 * Australian lawyer, in particular the operator identity, affiliate arrangements, governing law and the liability clause.
 * 1. OPERATOR: set in includes/operator.php (Grand Whisper, an online business based in Australia). "We" in these terms means
 *    that operator. Add the ABN there once confirmed: it will then show here, on the About page and in the privacy policy.
 * 2. GOVERNING LAW: set $governingLaw below to the Australian state or territory whose law should govern, for example
 *    'New South Wales', ONLY after confirming it with your lawyer (it should relate to where the operator actually is).
 *    While it is empty, a general clause is shown instead. If the operator is outside Australia, get advice first.
 * 4. NEWSLETTER: section 13 describes the real newsletter system (confirmation link, unsubscribe link, 18+). Keep it in step
 *    with the privacy policy and with how /gw-admin/ is actually used.
 * 3. AFFILIATE RULES: an SEO review of this site claims that 2026 reforms to the Interactive Gambling Act restrict
 *    commissions to affiliates based on customer activity, with most changes commencing on 1 January 2027. I could NOT
 *    verify that. Check ACMA and legislation.gov.au, and have a lawyer review your real affiliate agreements. Changing
 *    the wording of these terms does not make an arrangement lawful.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/operator.php';

$updated      = '2026-11-20';
$governingLaw = '';   // e.g. 'New South Wales'. Leave empty until confirmed.

$seo = [
    'title'       => 'Terms and Conditions',
    'description' => 'Read the GrandWhisper website terms covering access, content, affiliate disclosures, third-party links, intellectual property and legal responsibilities.',
    'path'        => '/terms-and-conditions/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Terms and Conditions', '/terms-and-conditions/']],
    'schema'      => [[
        '@type'        => 'WebPage',
        '@id'          => gw_abs('/terms-and-conditions/') . '#webpage',
        'url'          => gw_abs('/terms-and-conditions/'),
        'name'         => 'Terms and Conditions',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Terms and Conditions</h1>
      <p class="lead">Please read these terms before using the GrandWhisper website.</p>
    </div>
  </header>

  <div class="wrap">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></p>

      <h2>1. About these terms</h2>
      <p>These Terms and Conditions apply to your access to and use of <?= e(SITE_NAME) ?> (<?= e(SITE_URL) ?>) and its content, features and services.</p>
      <p>By accessing or using this website, you agree to comply with these terms and any applicable laws. If you do not agree, please stop using the website.</p>
      <p>References to "we", "us" and "our" mean the person or entity responsible for operating this website<?php if (gw_operator_line() !== ''): ?>, which is set out below<?php endif; ?>. Contact details are available through our <a href="/contact/">contact page</a>.</p>
<?php if (gw_operator_line() !== ''): ?>
      <p><?= e(gw_operator_line()) ?></p>
<?php endif; ?>

      <h2>2. Age and location requirements</h2>
      <p>This website is intended for adults. You must be at least 18 years old to access content about gambling, and you must comply with any age requirement that applies in your location.</p>
      <p>Gambling laws differ between countries, states and territories. You are responsible for understanding the laws that apply to you before you access or act on information about gambling services.</p>
      <p>In Australia, the <em>Interactive Gambling Act 2001</em> prohibits the provision of certain online gambling services to customers in Australia. These include online casino-style services such as internet pokies, roulette and blackjack. The legislation primarily regulates service providers, rather than customers.</p>
      <p>Nothing on this website should be read as an invitation or encouragement to use a gambling service that is prohibited or unlawful in your location. For further information, consult the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a>.</p>

      <h2>3. Nature of our content</h2>
      <p>GrandWhisper publishes general information, guides, explanations, news and editorial commentary about online casinos and gambling-related topics.</p>
      <p>Our content is provided for general informational and educational purposes only. It is not legal, financial, tax, investment or professional gambling advice, and you should not rely on it as a substitute for advice from a suitably qualified professional.</p>
      <p>We do not guarantee gambling outcomes, winnings, operator performance, payment processing times or the availability of any particular service.</p>
      <p>Information about laws, regulations, licences, payment methods, bonuses and third-party services may change. Although we aim to keep our content accurate and up to date, we cannot guarantee that every page is complete, current or free from errors. Please verify important information with the relevant regulator, service provider or official source before making a decision.</p>

      <h2>4. No gambling service provided</h2>
      <p>GrandWhisper is an information and publishing website. It does not itself accept bets, operate casino games, hold player deposits or manage gambling accounts.</p>
      <p>References to gambling operators, games, products or services are provided for information. They do not mean that a service is legal, licensed, safe, suitable or available in your location.</p>
      <p>Some articles show an illustrative comparison card for a fictional brand (&ldquo;Aurora Sample&rdquo;) with invented figures. It is an example only. It is not an offer, a recommendation or a real operator.</p>

      <h2>5. Responsible gambling</h2>
      <p>Gambling carries financial risk and can be harmful. It should never be treated as a way to earn income or recover losses. Only gamble with money you can afford to lose, and only where it is lawful. If gambling is affecting you or someone close to you, free and confidential support is available. See our <a href="/responsible-gambling/">responsible gambling page</a> for support options.</p>

      <h2>6. Affiliate links and commercial relationships</h2>
      <p>Some pages may contain affiliate links, sponsored content or other commercial placements, and we may receive compensation through certain commercial relationships.</p>
      <p>Where applicable, we aim to identify commercial relationships clearly. Further information is in our <a href="/about/#disclosure">affiliate disclosure</a>.</p>
      <p>A commercial relationship does not guarantee the quality, legality, reliability or suitability of a third-party service. Please review the relevant disclosures and verify information independently before dealing with any provider.</p>
      <p>Our affiliate and advertising activities are subject to applicable laws and regulations. Nothing in these terms is permission to promote, or to receive compensation for, an activity that the law prohibits.</p>

      <h2>7. Third-party websites and services</h2>
      <p>This website may contain links to third-party websites, organisations, regulators and service providers. These links are provided for convenience and information.</p>
      <p>We do not own or control external websites, and we are not responsible for their content, accuracy, availability, privacy practices, security, products or services. When you leave GrandWhisper, your use of another website is governed by that website's own terms and policies, which you should review before providing personal information, making payments or using an external service.</p>
      <p>A link to a third-party website does not necessarily mean that we endorse or guarantee that website or its services.</p>

      <h2>8. Intellectual property</h2>
      <p>Unless otherwise stated, the original text, design, graphics, illustrations and other materials on this website are owned by, or licensed to, the website operator and are protected by applicable intellectual property laws.</p>
      <p>You may access the website for personal, non-commercial use. You may also share links to our pages and quote short extracts where the law permits, provided you include appropriate attribution and a link to the original page.</p>
      <p>You must not reproduce, republish, distribute, commercially exploit or create substantial copies of our content without permission, except where the law allows. Third-party names, logos, trademarks and other materials remain the property of their respective owners. To report a copyright concern, see our <a href="/copyright-and-dmca/">Copyright and DMCA page</a>.</p>

      <h2>9. Acceptable use</h2>
      <p>You agree not to use this website in a way that is unlawful, harmful or likely to interfere with its operation or with other visitors' access. Prohibited activities include:</p>
      <ul>
        <li>attempting to gain unauthorised access to the website, server or associated systems;</li>
        <li>introducing malicious software, harmful code or automated attacks;</li>
        <li>interfering with the security, availability or normal operation of the website;</li>
        <li>using automated tools to scrape or collect content in a way that breaches applicable law, bypasses access controls or places unreasonable strain on the website;</li>
        <li>submitting spam, fraudulent messages, abusive content or unlawful material through our contact form; and</li>
        <li>using website content in a misleading, deceptive or unlawful manner.</li>
      </ul>
      <p>We may take reasonable steps to restrict access where we believe these terms have been breached, or where necessary to protect the website and its users.</p>

      <h2>10. Website availability and accuracy</h2>
      <p>We aim to keep GrandWhisper available and working properly, but we do not guarantee uninterrupted access, error-free operation or that the website will always be available. We may modify, suspend, remove or discontinue content or features at any time where reasonably necessary, including for maintenance, security, technical or editorial reasons.</p>

      <h2>11. Limitation of liability</h2>
      <p>To the extent permitted by applicable law, we are not responsible for losses arising from your use of, or inability to use, this website, including losses resulting from reliance on general information, outdated content, third-party websites or services, or technical interruptions.</p>
      <p>We are not responsible for gambling losses, for transactions with third-party operators, or for decisions made based on information published on this website.</p>
      <p>Nothing in these terms excludes, restricts or modifies any consumer guarantee, right or remedy that cannot lawfully be excluded, restricted or modified, including under the Australian Consumer Law where it applies. Where the law permits a limitation of liability, it applies only to the extent the law allows.</p>

      <h2>12. Privacy</h2>
      <p>Your use of this website may involve the collection and handling of personal information, including information you send through our contact form or newsletter sign-up. Our <a href="/privacy-policy/">Privacy Policy</a> explains what we collect, why, how it is handled and how to contact us about a privacy concern.</p>

      <h2>13. Newsletter and email</h2>
      <p>If you subscribe to our newsletter, you must be 18 or over. We email you a confirmation link first, and we add you to the mailing list only after you confirm. Every newsletter includes an unsubscribe link, and you can unsubscribe at any time.</p>
      <p>We use your email address to send you the newsletter and to keep a record that you subscribed or unsubscribed, as our <a href="/privacy-policy/">Privacy Policy</a> explains. We do not guarantee that any email will be delivered or arrive on time.</p>

      <h2>14. Changes to these terms</h2>
      <p>We may update these terms to reflect changes to the website, our practices or the law. When we do, we will update the "Last updated" date at the top of this page. Changes apply from the date they are published unless we say otherwise or the law requires otherwise. Please review this page from time to time.</p>

      <h2>15. If part of these terms cannot be enforced</h2>
      <p>If a provision of these terms is found to be invalid or unenforceable, the rest of the terms continue to apply.</p>

      <h2>16. Governing law</h2>
<?php if (!empty($governingLaw)): ?>
      <p>These terms are governed by the laws of <?= e($governingLaw) ?>, Australia. You and we submit to the non-exclusive jurisdiction of the courts of <?= e($governingLaw) ?>, subject to any mandatory consumer protection laws that apply to you.</p>
<?php else: ?>
      <p>These terms are intended to operate subject to applicable Australian law, including any mandatory consumer protections that apply to your use of this website. Nothing in this section removes rights you may have under mandatory laws that apply in your location.</p>
<?php endif; ?>

      <h2>17. Contact us</h2>
      <p>If you have questions about these Terms and Conditions, please contact us through our <a href="/contact/">contact page</a> or by email at <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a>.</p>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>