<?php
/**
 * Confirms a newsletter sign-up (served at /subscribe-confirm/?t=TOKEN).
 * Opening the link only shows a button. The subscription is confirmed when the button is pressed, which stops email
 * security scanners (which open links automatically) from confirming someone by accident, and gives a clear record of consent.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/newsletter.php';

$token = (string) ($_GET['t'] ?? $_POST['t'] ?? '');
$state = 'invalid';   // valid | done | already | invalid | down
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $res   = gw_nl_confirm($token);
        $state = $res === 'ok' ? 'done' : $res;
    } else {
        $state = gw_nl_confirm_state($token);
    }
} catch (Throwable $e) {
    error_log('GrandWhisper newsletter confirm failed: ' . get_class($e));
    $state = 'down';
}

header('Referrer-Policy: no-referrer');
$seo = [
    'title'       => 'Confirm your subscription',
    'description' => 'Confirm your GrandWhisper newsletter subscription.',
    'path'        => '/subscribe-confirm/',
    'robots'      => 'noindex,nofollow',
    'no_canonical'=> true,
    'body_class'  => 'is-doc',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap search-page">
    <h1>Confirm your subscription</h1>
<?php if ($state === 'valid'): ?>
    <p>Press the button to confirm that you want to receive new-article emails from GrandWhisper. You can unsubscribe in one click from any email.</p>
    <form class="form" action="/subscribe-confirm/" method="post">
      <input type="hidden" name="t" value="<?= e($token) ?>">
      <button class="btn btn--ruby" type="submit">Yes, subscribe me</button>
    </form>
<?php elseif ($state === 'done'): ?>
    <p class="alert alert--ok" role="status">You are subscribed. Thank you. We will email you when we publish something worth reading, and every email has a one-click unsubscribe link.</p>
    <p><a href="/">Back to the magazine</a></p>
<?php elseif ($state === 'already'): ?>
    <p class="alert alert--ok" role="status">This subscription is already confirmed. Nothing more to do.</p>
    <p><a href="/">Back to the magazine</a></p>
<?php elseif ($state === 'down'): ?>
    <p class="alert alert--err" role="alert">Sorry, we could not check this link just now. Please try again later.</p>
<?php else: ?>
    <p class="alert alert--err" role="alert">This confirmation link is not valid or has expired. Links work for <?= (int) GW_NL_CONFIRM_DAYS ?> days.</p>
    <p>You can <a href="/subscribe/">sign up again</a> and we will send a new link.</p>
<?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
