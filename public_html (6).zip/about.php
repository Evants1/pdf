<?php
/**
 * About page (served at /about/). Includes the affiliate disclosure at #disclosure (other pages link to that anchor).
 *
 * OWNER NOTES:
 * 1. The publisher (Grand Whisper, an online business based in Australia) is set in includes/operator.php and appears here,
 *    on the privacy policy and on the terms. Add the ABN there once confirmed. No phone number is shown: add one only after
 *    confirming it is real and working.
 * 2. AFFILIATE RULES (check before relying on any casino affiliate income): an SEO review of this site claims that 2026
 *    reforms to the Interactive Gambling Act restrict affiliate commissions based on customer activity, with most
 *    reforms commencing on 1 January 2027, and that ACMA publishes enforcement information about affiliate sites that
 *    promote prohibited services. I could NOT verify these claims. Check them on acma.gov.au and legislation.gov.au, and
 *    have an Australian lawyer review your affiliate agreements, your pay model and the commercial pages before launch.
 * 3. Statements below describe how the site AIMS to work. Only keep each one if it is true of your practice.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/operator.php';

$updated = '2026-11-20';

$seo = [
    'title'       => 'About GrandWhisper: Standards and Funding',
    'description' => 'Learn what GrandWhisper publishes, how we approach editorial standards, how the site is funded and how we handle affiliate relationships.',
    'path'        => '/about/',
    'image'       => 'pages/about.jpg',
    'image_alt'   => 'Illustration of a fan of playing cards',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['About', '/about/']],
    'schema'      => [[
        '@type'        => 'AboutPage',
        '@id'          => gw_abs('/about/') . '#webpage',
        'url'          => gw_abs('/about/'),
        'name'         => 'About GrandWhisper: Standards and Funding',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
        'about'        => ['@id' => gw_abs('/') . '#organization'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>About GrandWhisper</h1>
      <p class="lead">Clear, practical information about online casinos, gambling-related topics and the rules that affect Australian readers.</p>
    </div>
  </header>

  <div class="wrap about-grid">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></p>

      <h2>What we publish</h2>
      <p>GrandWhisper is an online casino and gambling information magazine. We publish guides and explainers covering topics such as bonus conditions, payment methods, withdrawal processes, identity verification, casino game mathematics and gambling regulation.</p>
      <p>Our aim is to explain these subjects in straightforward language, identify important terms and risks, and help readers understand the information before making decisions. Our content is informational and should not be treated as financial, legal or gambling advice.</p>
      <p>Our main content areas include <a href="/category/casino-guides/">casino guides</a>, which cover practical topics, and <a href="/category/casino-news/">casino news</a>, which looks at developments in technology, payments and regulation.</p>
      <p>We also maintain guides on <a href="/best-online-casinos/">how to assess online casinos</a>, <a href="/online-casino-reviews/">our review methodology</a>, <a href="/online-casino-bonuses/">casino bonuses</a>, <a href="/online-casino-payment-methods/">payment methods</a> and <a href="/safe-and-trusted-online-casinos/">online casino safety checks</a>.</p>
<?php if (gw_operator_line() !== ''): ?>

      <h2>Who publishes this site</h2>
      <p><?= e(gw_operator_line()) ?> You can reach us through our <a href="/contact/">contact page</a>.</p>
      <ul>
        <li><strong>Business:</strong> <?= e(gw_operator()['name']) ?></li>
        <li><strong>Country:</strong> Australia</li>
        <li><strong>Type:</strong> online publishing business</li>
        <li><strong>Email:</strong> <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a></li>
        <li><strong>Contact form:</strong> <a href="/contact/">grandwhisper.com/contact</a></li>
      </ul>
<?php endif; ?>

      <h2>Who writes and checks our content</h2>
      <p>Articles are published under the byline <strong>GrandWhisper Editorial</strong>. Every article is written and checked against the same standards set out below, and shows its publication date and, where it has been revised, its update date. We do not currently publish individual author profiles. If that changes, the authors will be named on their articles.</p>

      <h2>How we check information</h2>
      <ul>
        <li><strong>Regulators first:</strong> statements about the law, licensing and identity checks point to the regulator or official body concerned, such as ACMA, AUSTRAC, BetStop and the Australian Taxation Office, so you can read the source yourself.</li>
        <li><strong>Checks, not rankings:</strong> our guides explain how to check an operator and how bonus, payment and withdrawal terms work. They do not name, rank or recommend real online casino operators, and they do not publish live offers.</li>
        <li><strong>Examples are labelled:</strong> where we use figures to show how something works, such as wagering arithmetic or RTP, they are hypothetical, are shown in Australian dollars and say so.</li>
        <li><strong>Dates matter:</strong> terms, rules and reforms change, so we show dates and tell readers to confirm important details with the official source.</li>
      </ul>

      <h2>Our editorial standards</h2>
      <p>We aim to make our content useful, accurate and transparent. Our editorial approach includes these principles:</p>
      <ul>
        <li><strong>Accuracy:</strong> we aim to verify factual claims, including published terms, payment information, licensing details and statistics, before including them.</li>
        <li><strong>Clear explanations:</strong> we explain important conditions, limitations and risks rather than relying on promotional claims.</li>
        <li><strong>Risk awareness:</strong> we explain that gambling involves financial risk, that casino games generally have a mathematical house edge, and that no strategy can guarantee a profit.</li>
        <li><strong>Source transparency:</strong> where appropriate, we link to regulators, official documents and independent organisations so readers can check important information themselves.</li>
        <li><strong>Corrections:</strong> we welcome reports of factual errors and review correction requests. You can contact us through our <a href="/contact/">contact page</a>.</li>
        <li><strong>Updates:</strong> we review content when important information changes and aim to show relevant publication or update dates.</li>
      </ul>
      <p>For more detail about how we assess casino-related information, read our <a href="/online-casino-reviews/">review methodology</a>.</p>

      <h2 id="disclosure">How GrandWhisper is funded: affiliate disclosure</h2>
      <p>GrandWhisper may earn revenue through affiliate relationships with third-party websites and services. This means we may receive compensation when a reader follows certain links or completes a qualifying action with a partner.</p>
      <p>Where a page contains affiliate links or other paid placements, the commercial relationship should be disclosed clearly near the relevant link or content. This page gives a general explanation of how affiliate funding works. It does not replace the disclosures on individual pages.</p>
      <p>Commercial relationships can create a conflict of interest. We aim to keep editorial assessments separate from commercial arrangements and to explain the criteria used in our reviews. Please consider our disclosures alongside the evidence and limitations presented in each article.</p>
      <p>Affiliate compensation does not make a gambling service legal in Australia, guarantee that an operator is safe, or mean that a service is suitable for any reader. We encourage readers to check the relevant laws and official regulatory information before acting on anything they read.</p>

      <h3>About the sample comparison card</h3>
      <p>Many articles show a card headed &ldquo;Top casino of the month&rdquo;. It features <strong>Aurora Sample</strong>, a fictional brand with invented figures, and it is marked &ldquo;Sample only&rdquo;. It illustrates how a comparison card works. It is not a recommendation, a ranking of a real operator or a paid placement. Our guides do not name or rank real online casino operators.</p>
      <p>If we add affiliate links to named services in future, we will label them next to the link, explain the relationship and update this page.</p>

      <h2>Australian audience and legal information</h2>
      <p>GrandWhisper is written primarily for readers in Australia. Australian law distinguishes between different types of online gambling services. Under the <em>Interactive Gambling Act 2001</em>, providing prohibited online casino-style gambling services, such as online pokies, roulette and blackjack, to customers in Australia is unlawful. The law primarily targets service providers rather than people who use or consider using these services.</p>
      <p>Reading information about an online gambling service does not make that service lawful. Please consult the <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> for current information about online gambling rules and prohibited services. You can also read our guide to <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>

      <h2>Responsible gambling</h2>
      <p>Our content is intended for adults. Gambling involves the risk of financial loss and can cause harm. It should never be treated as a way to earn income, recover losses or solve financial difficulties.</p>
      <p>Age restrictions and gambling laws vary depending on the activity and location. Being over 18 does not make every online gambling service lawful or appropriate to use in Australia.</p>
      <p>If gambling is causing problems for you or someone you know, support is available. Visit our <a href="/responsible-gambling/">responsible gambling page</a> for information about support options.</p>

      <h2>Corrections and contact</h2>
      <p>If you have a question about our content, want to report an error or have an editorial enquiry, please use our <a href="/contact/">contact page</a>. Our <a href="/privacy-policy/">privacy policy</a> explains how we handle the information you send us.</p>
      <p>When we confirm a factual error, we aim to correct the article and update its date. You can also email us at <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a>.</p>
    </div>

    <aside class="about-aside" aria-label="Quick links">
      <?= gw_img('pages/about', 'Illustration of a fan of playing cards', ['sizes' => '340px']) ?>
      <h2>Start reading</h2>
      <ul>
        <li><a href="/how-to-choose-a-real-money-online-casino/">How to choose a real-money online casino</a></li>
        <li><a href="/how-casino-welcome-bonuses-work/">How welcome bonuses work</a></li>
        <li><a href="/safe-and-trusted-online-casinos/">Online casino safety checks</a></li>
        <li><a href="/online-gambling-laws-in-australia/">Australian online gambling laws</a></li>
        <li><a href="/responsible-gambling/">Responsible gambling</a></li>
        <li><a href="/category/casino-guides/">All casino guides</a></li>
        <li><a href="/category/casino-news/">Casino news and explainers</a></li>
      </ul>
    </aside>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>