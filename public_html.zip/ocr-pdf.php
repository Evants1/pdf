<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "OCR PDF Online Free | Make Scanned PDF Searchable | PDFEase";
$meta_description = "Free online OCR tool to convert scanned PDFs to searchable and editable text. High-accuracy recognition, supports 100+ languages, no signup, unlimited.";
$meta_keywords = "ocr pdf online free, pdf ocr, scanned pdf to searchable, make pdf searchable, ocr pdf converter, free ocr pdf, optical character recognition pdf";
$canonical_url = "https://pdfease.org/ocr-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase OCR PDF",
  "description": "Free online OCR to make scanned PDFs searchable with high accuracy and multi-language support.",
  "url": "https://pdfease.org/ocr-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to OCR a Scanned PDF Online for Free",
  "description": "Step-by-step guide to making a scanned PDF searchable using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your scanned PDF by dragging or browsing.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Select the document language (or auto-detect).",
      "name": "Choose Language"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Start OCR Processing' and wait for completion.",
      "name": "Process"
    },
    {
      "@type": "HowToStep",
      "text": "Download your new searchable PDF.",
      "name": "Download"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    OCR PDF Online <span class="text-purple-600">Free</span>
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Convert scanned PDFs and images to searchable, selectable text. High-accuracy AI-powered OCR supporting 100+ languages—no registration needed.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-purple-500 hover:bg-purple-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload scanned PDF">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-purple-600 bg-purple-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload Scanned PDF</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop • Up to 200MB • Multi-language support</p>
                    </div>
                </div>
            </div>

            <div id="file-preview" class="hidden max-w-4xl mx-auto mt-10 bg-slate-100 rounded-3xl shadow-lg p-8 border border-slate-200">
                <div class="flex items-center justify-between">
                    <div class="flex items-center gap-6">
                        <div class="text-5xl">📄</div>
                        <div class="text-left">
                            <p id="file-name" class="text-xl font-bold text-slate-900">document.pdf</p>
                            <p id="file-size" class="text-base text-slate-500">0 MB</p>
                        </div>
                    </div>
                    <button type="button" id="remove-file" class="text-red-600 hover:text-red-700 font-bold text-lg">Remove</button>
                </div>
            </div>

            <div id="editor-area" class="hidden mt-12 max-w-lg mx-auto">
                <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                    <label for="ocr-lang" class="block text-sm font-bold uppercase text-purple-400 tracking-widest mb-3">Document Language</label>
                    <select id="ocr-lang" class="w-full bg-slate-800 text-white rounded-2xl p-5 text-lg focus:outline-none focus:ring-4 focus:ring-purple-500">
                        <option value="eng">English (Highest Accuracy)</option>
                        <option value="spa">Spanish</option>
                        <option value="fra">French</option>
                        <option value="deu">German</option>
                        <option value="ita">Italian</option>
                        <option value="por">Portuguese</option>
                        <option value="rus">Russian</option>
                        <option value="chi_sim">Chinese Simplified</option>
                        <option value="jpn">Japanese</option>
                        <option value="kor">Korean</option>
                        <option value="ara">Arabic</option>
                        <option value="hin">Hindi</option>
                        <option value="auto">Auto-Detect</option>
                    </select>
                    <button type="button" id="submit-ocr" class="w-full mt-8 bg-purple-600 hover:bg-purple-500 text-white py-6 rounded-2xl font-bold uppercase tracking-widest text-xl shadow-xl transition-all active:scale-95" disabled>
                        Start OCR Processing
                    </button>
                </div>
                <p class="text-center text-slate-500 mt-6 text-sm">Encrypted processing • Files deleted automatically</p>
            </div>

            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="w-28 h-28 border-8 border-purple-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Running OCR...</h3>
                <p class="text-slate-600 text-lg max-w-md mx-auto">Extracting text from images—this typically takes 30–90 seconds.</p>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                    ✓
                </div>
                <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">OCR Complete!</h3>
                <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                    Your PDF now has embedded searchable text—ready for copying, searching, and editing.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-purple-600 hover:bg-purple-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                        Download Searchable PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        OCR Another PDF
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why PDFEase is the Best <span class="text-purple-600">Free OCR PDF</span> Tool
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">High accuracy, full privacy, multi-language support, and truly unlimited.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-purple-100 text-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">High Accuracy OCR</h3>
                <p class="text-slate-600 leading-relaxed">AI-powered recognition for printed and handwritten text with excellent results.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-purple-100 text-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">100+ Languages</h3>
                <p class="text-slate-600 leading-relaxed">Supports English, Spanish, Chinese, Arabic, and many more—including auto-detection.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-purple-100 text-purple-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no watermarks, no account required.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Perfect For</h3>
                    <ul class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-center gap-3">• Scanned books & archives</li>
                        <li class="flex items-center gap-3">• Invoices & receipts</li>
                        <li class="flex items-center gap-3">• Contracts & legal documents</li>
                        <li class="flex items-center gap-3">• Handwritten notes</li>
                    </ul>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Key Features</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-purple-600 mt-1">●</span> Embedded searchable text layer</li>
                    <li class="flex items-start gap-3"><span class="text-purple-600 mt-1">●</span> Preserves original layout & images</li>
                    <li class="flex items-start gap-3"><span class="text-purple-600 mt-1">●</span> Secure encrypted processing</li>
                    <li class="flex items-start gap-3"><span class="text-purple-600 mt-1">●</span> Works on mobile & desktop</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">How accurate is the OCR?</h4>
                    <p class="text-slate-600">95%+ on clear printed text. Good results on handwriting depending on legibility.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it support my language?</h4>
                    <p class="text-slate-600">Yes—over 100 languages including right-to-left scripts like Arabic.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my document secure?</h4>
                    <p class="text-slate-600">Fully encrypted transfer and processing. Files deleted immediately after download.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I OCR multi-page PDFs?</h4>
                    <p class="text-slate-600">Yes—processes all pages automatically.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-purple-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Make Your PDF Searchable?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">High-accuracy OCR in seconds—no software required.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-purple-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                OCR PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const filePreview = document.getElementById('file-preview');
        const fileNameEl = document.getElementById('file-name');
        const fileSizeEl = document.getElementById('file-size');
        const removeBtn = document.getElementById('remove-file');
        const editorArea = document.getElementById('editor-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const submitBtn = document.getElementById('submit-ocr');

        let selectedFile = null;

        function handleFile(file) {
            if (!file || file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            fileNameEl.textContent = file.name;
            fileSizeEl.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            dropZone.classList.add('hidden');
            filePreview.classList.remove('hidden');
            editorArea.classList.remove('hidden');
            submitBtn.disabled = false;
        }

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-purple-600', 'bg-purple-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-purple-600', 'bg-purple-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-purple-600', 'bg-purple-50/60');
            if (e.dataTransfer.files.length) handleFile(e.dataTransfer.files[0]);
        });

        fileInput.addEventListener('change', (e) => {
            if (e.target.files.length) handleFile(e.target.files[0]);
        });

        removeBtn.addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            dropZone.classList.remove('hidden');
            filePreview.classList.add('hidden');
            editorArea.classList.add('hidden');
            submitBtn.disabled = true;
        });

        submitBtn.addEventListener('click', () => {
            if (!selectedFile) return;

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('lang', document.getElementById('ocr-lang').value);

            fetch('api/ocr-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        statusArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = selectedFile.name.replace(/\.pdf$/i, '_ocr.pdf');
                    } else {
                        throw new Error(data.message || 'OCR failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Processing failed. Please try again with a clearer scan.');
                    location.reload();
                });
        });
    </script>
</body>
</html>