<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Reorder PDF Pages Online Free | Rearrange & Organize PDF Pages Easily | PDFEase";
$meta_description = "Free online tool to reorder PDF pages. Drag and drop thumbnails to rearrange, sort, or organize pages in your PDF visually. No registration, secure client-side rendering, fast processing.";
$meta_keywords = "reorder pdf pages online free, rearrange pdf pages, organize pdf pages, sort pdf pages, move pdf pages, change pdf page order online, free pdf page organizer";
$canonical_url = "https://pdfease.org/reorder-pages";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Reorder PDF Pages",
  "description": "Free online tool to visually reorder and organize pages in PDF documents using drag-and-drop.",
  "url": "https://pdfease.org/reorder-pages",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Reorder PDF Pages Online for Free",
  "description": "Step-by-step guide to rearranging pages in a PDF using PDFEase's free drag-and-drop tool.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file by clicking or dragging it into the upload area.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "View page thumbnails and drag them to your desired order.",
      "name": "Rearrange Pages"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Apply New Order' to process and download the reordered PDF.",
      "name": "Download Reordered PDF"
    }
  ]
}
</script>
<body class="bg-white font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-slate-50 pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight italic">
                    Reorder <span class="text-indigo-600 underline decoration-indigo-200">PDF Pages</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Easily rearrange, sort, and organize pages in your PDF with our intuitive drag-and-drop interface. No downloads, no sign-up—100% free and secure.
                </p>
            </div>
            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-200 rounded-[3rem] p-12 md:p-20 transition-all duration-300 hover:border-indigo-400 hover:bg-indigo-50/30 group relative shadow-sm cursor-pointer" aria-label="PDF upload area">
                <div class="mb-6 inline-flex items-center justify-center w-20 h-20 bg-indigo-600 text-white rounded-3xl group-hover:scale-110 transition-transform duration-300 transform rotate-3 group-hover:rotate-0 shadow-xl shadow-indigo-100">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </div>
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Upload PDF file">
                <label for="file-upload" class="cursor-pointer space-y-4 block">
                    <span class="text-3xl font-black block text-slate-900 tracking-tight uppercase">Select or Drag PDF to Reorder Pages</span>
                    <p class="text-slate-400 font-mono text-xs tracking-[0.2em] font-bold uppercase">Drag & Drop Supported • No Registration Required</p>
                    <p class="text-slate-500 mt-4 max-w-md mx-auto">Supports large PDFs • Client-side thumbnail generation for privacy</p>
                </label>
            </div>
            <div id="editor-area" class="hidden mt-12 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div class="sticky top-6 z-50 max-w-5xl mx-auto bg-slate-900 text-white p-4 md:p-6 rounded-[2.5rem] mb-12 flex flex-wrap justify-between items-center shadow-2xl border-4 border-slate-800">
                    <div class="text-left px-4">
                        <p class="text-[10px] uppercase font-black text-indigo-400 tracking-[0.2em] mb-1">Sorting Mode Active</p>
                        <p class="text-sm font-bold text-slate-300">Drag thumbnails to rearrange • Use keyboard arrows for fine control on desktop</p>
                    </div>
                    <div class="flex items-center gap-6 px-4">
                        <button type="button" onclick="location.reload()" class="text-xs font-black uppercase text-slate-500 hover:text-white transition-colors tracking-widest">Reset</button>
                        <button type="button" id="submit-reorder" class="bg-indigo-600 hover:bg-indigo-500 px-10 py-4 rounded-2xl font-black uppercase tracking-widest transition shadow-xl shadow-indigo-900/40 active:scale-95">
                            Apply New Order
                        </button>
                    </div>
                </div>
                <div class="bg-slate-200 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-100">
                    <div id="page-grid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-8" role="region" aria-label="PDF page thumbnails for reordering">
                    </div>
                </div>
            </div>
            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="flex flex-col items-center">
                    <div class="relative w-20 h-20 mb-8">
                        <div class="absolute inset-0 border-4 border-indigo-100 rounded-full"></div>
                        <div class="absolute inset-0 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                    <p class="text-3xl font-black text-slate-900 tracking-tight italic">Processing Your Reordered PDF...</p>
                    <p class="text-slate-500 mt-4">This may take a moment for larger files.</p>
                </div>
            </div>
            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-500" aria-live="polite">
                <div class="w-24 h-24 bg-emerald-500 text-white rounded-[2rem] flex items-center justify-center mx-auto mb-8 text-4xl shadow-xl shadow-emerald-100 -rotate-6">✓</div>
                <h2 class="text-5xl font-black text-slate-900 mb-4 tracking-tight italic">PDF Successfully Reordered!</h2>
                <p class="text-slate-500 mb-12 font-medium max-w-lg mx-auto leading-relaxed text-lg">Your pages are now in the perfect order.</p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-6">
                    <a id="download-link" href="#" download class="bg-slate-900 text-white px-16 py-6 rounded-[2rem] font-black text-2xl shadow-2xl hover:bg-slate-800 transition-all hover:-translate-y-1 block md:inline-block">
                        Download Reordered PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-400 font-bold hover:text-slate-900 transition-colors uppercase tracking-widest text-xs">Start New Reorder</button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight italic uppercase">Why Choose PDFEase to <span class="text-indigo-600">Reorder PDF Pages</span>?</h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Fast, private, and completely free—no watermarks, no limits.</p>
        </div>
        <div class="grid md:grid-cols-3 gap-12 mb-24">
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">1</div>
                <h3 class="text-2xl font-black mb-4">Visual Drag & Drop</h3>
                <p class="text-slate-600 leading-relaxed">See thumbnails of every page and rearrange them intuitively—no guessing page numbers.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">2</div>
                <h3 class="text-2xl font-black mb-4">100% Free & No Signup</h3>
                <p class="text-slate-600 leading-relaxed">Unlimited use with no account required. Process as many PDFs as you need.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">3</div>
                <h3 class="text-2xl font-black mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Thumbnails generated in your browser. Files deleted from server immediately after processing.</p>
            </div>
        </div>

        <div class="text-center mb-16">
            <h2 class="text-4xl font-black text-slate-900 mb-4 tracking-tight italic uppercase">Frequently Asked <span class="text-indigo-600">Questions</span></h2>
            <p class="text-slate-500 font-medium">Answers to common queries about reordering PDF pages online.</p>
        </div>
        <div class="grid md:grid-cols-2 gap-12">
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    Is this PDF reorder tool really free?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    Yes! Completely free with no hidden fees, watermarks, or usage limits.
                </p>
            </div>
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    How secure is the process?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    Very secure. Page thumbnails are rendered client-side in your browser (no upload of page content). The full file is only sent once for reordering and deleted immediately after.
                </p>
            </div>
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    Does it work on mobile devices?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    Yes—fully responsive with touch-friendly drag-and-drop support.
                </p>
            </div>
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    What file sizes are supported?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    Up to 200MB and hundreds of pages. Larger files may take longer to generate thumbnails.
                </p>
            </div>
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    Can I rotate or delete pages too?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    This tool focuses on reordering. Check our other free tools for rotation, deletion, merging, and more.
                </p>
            </div>
            <div class="space-y-3">
                <h4 class="text-xl font-black text-slate-900 tracking-tight flex items-start gap-3">
                    <span class="text-indigo-600 mt-1">●</span>
                    Is the original PDF changed?
                </h4>
                <p class="text-slate-600 leading-relaxed pl-7 font-medium">
                    No—a brand new reordered PDF is created. Your original remains untouched.
                </p>
            </div>
        </div>
    </section>

    <section class="bg-slate-100 py-20 border-t border-slate-200">
        <div class="max-w-5xl mx-auto px-6 text-center">
            <h2 class="text-4xl font-black text-slate-900 mb-8 tracking-tight italic">Ready to Organize Your PDF?</h2>
            <p class="text-xl text-slate-600 mb-12 max-w-2xl mx-auto">Start reordering pages in seconds—no software installation needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-indigo-600 text-white px-16 py-6 rounded-[2rem] font-black text-2xl shadow-2xl hover:bg-indigo-500 transition-all hover:-translate-y-1">
                Reorder PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const pageGrid = document.getElementById('page-grid');
        let selectedFile = null;

        // Drag-over visual feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-indigo-600', 'bg-indigo-50');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-indigo-600', 'bg-indigo-50');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-indigo-600', 'bg-indigo-50');
        });

        fileInput.addEventListener('change', async (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            dropZone.classList.add('hidden');
            document.getElementById('editor-area').classList.remove('hidden');
            pageGrid.innerHTML = '<p class="col-span-full text-center text-slate-500 py-12">Generating thumbnails...</p>';

            const arrayBuffer = await selectedFile.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            pageGrid.innerHTML = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const viewport = page.getViewport({ scale: 0.5 }); // Slightly larger thumbnails for better visibility
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                await page.render({ canvasContext: context, viewport: viewport }).promise;

                const div = document.createElement('div');
                div.setAttribute('data-page-index', i);
                div.setAttribute('role', 'listitem');
                div.setAttribute('aria-label', `Page ${i}`);
                div.className = "relative bg-white p-4 rounded-[2rem] shadow-md border-2 border-slate-100 cursor-grab active:cursor-grabbing hover:border-indigo-400 transition-all group focus:outline-none focus:border-indigo-600 focus:ring-4 focus:ring-indigo-200";
                div.tabIndex = 0; // Make keyboard focusable
                div.innerHTML = `
                    <div class="absolute top-4 left-4 z-10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                        <div class="bg-slate-900 text-white p-2 rounded-lg shadow-lg">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M4 8h16M4 16h16"></path></svg>
                        </div>
                    </div>
                    <div class="overflow-hidden rounded-2xl border border-slate-50 shadow-sm">
                        <img src="${canvas.toDataURL()}" alt="Thumbnail of page ${i}" class="w-full pointer-events-none">
                    </div>
                    <div class="text-center mt-4 font-black text-indigo-600 text-sm uppercase tracking-wider">Page ${i}</div>
                `;
                pageGrid.appendChild(div);
            }

            const sortable = new Sortable(pageGrid, {
                animation: 300,
                ghostClass: 'opacity-30 bg-indigo-100',
                chosenClass: 'scale-110 shadow-2xl',
                dragClass: 'rotate-3',
                forceFallback: true,
                onEnd: () => {
                    // Update page numbers after drag
                    Array.from(pageGrid.children).forEach((child, index) => {
                        child.querySelector('.text-sm').textContent = `Page ${index + 1} (new position)`;
                    });
                }
            });
        });

        document.getElementById('submit-reorder').addEventListener('click', () => {
            const newOrder = Array.from(pageGrid.children).map(child => parseInt(child.getAttribute('data-page-index')));
            if (newOrder.length === 0) return;

            document.getElementById('editor-area').classList.add('hidden');
            document.getElementById('status-area').classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('page_order', newOrder.join(','));

            fetch('api/reorder-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status-area').classList.add('hidden');
                        document.getElementById('download-area').classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Processing failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert("An error occurred while reordering your PDF. Please try again.");
                    location.reload();
                });
        });
    </script>
</body>
</html>