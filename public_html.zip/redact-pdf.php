<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Redact PDF Online Free | Permanently Black Out Text | PDFEase";
$meta_description = "Free online PDF redaction tool. Permanently remove sensitive text, images, and metadata—ensuring data cannot be recovered. Secure & compliant.";
$meta_keywords = "redact pdf online free, black out text in pdf, permanently remove pdf text, pdf redaction tool, hide sensitive info pdf";
$canonical_url = "https://pdfease.io/redact-pdf";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Redact PDF",
  "description": "Free online tool to permanently redact sensitive information from PDF documents.",
  "url": "https://pdfease.io/redact-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Redact a PDF Online for Free",
  "description": "Step-by-step guide to permanently removing sensitive data from PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your confidential PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click and drag to draw black boxes over sensitive areas.",
      "name": "Mark Redactions"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Sanitize PDF' to permanently remove the data and download.",
      "name": "Download Sanitized PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Redact <span class="text-indigo-600">Sensitive PDF Data</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Permanently black out text, images, and metadata. True redaction—not just covering—ensuring data is irrecoverable.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-indigo-500 hover:bg-indigo-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to redact">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select confidential PDF">
                    <label for="file-upload" class="cursor-pointer space-y-6 block">
                        <div class="mx-auto h-28 w-28 text-indigo-600 bg-indigo-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l18 18"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload Confidential PDF</span>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • End-to-end encrypted • Multi-page support</p>
                        </div>
                    </label>
                </div>

                <div id="editor-area" class="hidden mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10">
                    <div class="lg:col-span-4 space-y-8">
                        <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                            <h3 class="text-2xl font-extrabold mb-6 tracking-tight">Redaction Controls</h3>
                            <p class="text-slate-300 mb-8 leading-relaxed">Click and drag on the preview to draw black boxes over sensitive content. These areas will be permanently removed.</p>

                            <div class="bg-slate-800/50 p-6 rounded-2xl mb-8">
                                <p class="text-xs uppercase font-bold text-indigo-400 tracking-widest mb-2">Marked Areas</p>
                                <p class="text-4xl font-bold">
                                    <span id="redact-count">0</span>
                                </p>
                            </div>

                            <button type="button" id="submit-redact" class="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-6 rounded-2xl font-bold uppercase tracking-wide text-xl shadow-xl transition-all active:scale-95">
                                Sanitize PDF
                            </button>

                            <button type="button" onclick="location.reload()" class="w-full mt-4 text-slate-400 hover:text-white font-semibold uppercase tracking-widest text-sm transition-colors">
                                Start Over
                            </button>

                            <p class="text-center text-xs text-slate-500 mt-8 uppercase tracking-widest">
                                🔒 Permanent removal • No recovery possible
                            </p>
                        </div>
                    </div>

                    <div class="lg:col-span-8 bg-slate-100 rounded-[3rem] p-6 md:p-12 shadow-inner border border-slate-200 min-h-[800px] flex items-center justify-center">
                        <div id="pdf-container" class="relative bg-white rounded-2xl shadow-2xl overflow-hidden cursor-crosshair select-none">
                            <canvas id="pdf-render-canvas" class="max-w-full"></canvas>
                        </div>
                    </div>
                </div>

                <div id="status-area" class="hidden py-32" aria-live="polite">
                    <div class="w-24 h-24 border-8 border-indigo-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Sanitizing Document...</h3>
                    <p class="text-slate-600 text-lg font-medium">Permanently removing sensitive content.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                    <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Sanitized Successfully!</h2>
                    <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                        Sensitive data has been permanently removed from the document structure—no recovery possible.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-indigo-600 transition-all hover:-translate-y-1">
                            Download Sanitized PDF
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Redact Another File
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why True <span class="text-indigo-600">Redaction</span> Matters
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Covering text is not enough—hidden data remains recoverable.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Permanent Removal</h3>
                <p class="text-slate-600 leading-relaxed">Text and metadata are stripped from the PDF structure—irrecoverable.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Compliance Ready</h3>
                <p class="text-slate-600 leading-relaxed">Meets GDPR, HIPAA, and legal redaction standards.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-indigo-100 text-indigo-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Private</h3>
                <p class="text-slate-600 leading-relaxed">Processing in memory only. Files deleted immediately after.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Not Just Black Boxes</h3>
                    <p class="text-slate-600 leading-relaxed">Standard overlays hide text visually but leave it searchable and recoverable. We remove it completely.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Multi-Page Support</h3>
                    <p class="text-slate-600 leading-relaxed">Redact across all pages (first page preview shown—full document processed).</p>
                </div>
            </div>

            <div class="bg-indigo-50 border-2 border-indigo-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-indigo-900 mb-6">Ideal For</h3>
                <ul class="space-y-4 text-indigo-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-indigo-600 mt-1">•</span> Legal documents & contracts</li>
                    <li class="flex items-start gap-3"><span class="text-indigo-600 mt-1">•</span> Medical & financial records</li>
                    <li class="flex items-start gap-3"><span class="text-indigo-600 mt-1">•</span> Government & corporate compliance</li>
                    <li class="flex items-start gap-3"><span class="text-indigo-600 mt-1">•</span> FOIA or public release preparation</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is the redaction permanent?</h4>
                    <p class="text-slate-600">Yes—underlying text and metadata are removed from the file structure.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can hidden text be recovered?</h4>
                    <p class="text-slate-600">No—once sanitized, the original content is irrecoverable, even with forensic tools.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Multi-page redaction?</h4>
                    <p class="text-slate-600">Currently optimized for single-page preview. Full document is processed on submit.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my file secure?</h4>
                    <p class="text-slate-600">Absolutely—encrypted transfer, memory-only processing, auto-deleted after use.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-indigo-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Sanitize Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Permanently remove sensitive information in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-indigo-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Redact PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const editorArea = document.getElementById('editor-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const container = document.getElementById('pdf-container');
        const canvas = document.getElementById('pdf-render-canvas');
        const redactCountLabel = document.getElementById('redact-count');

        let selectedFile = null;
        let redactions = [];
        let isDrawing = false;
        let startX, startY, currentBox;

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-indigo-600', 'bg-indigo-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-indigo-600', 'bg-indigo-50/60');
        });

        fileInput.addEventListener('change', async (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            dropZone.classList.add('hidden');
            editorArea.classList.remove('hidden');

            const arrayBuffer = await selectedFile.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            const page = await pdf.getPage(1);
            const viewport = page.getViewport({ scale: 2.0 });
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            await page.render({ canvasContext: canvas.getContext('2d'), viewport: viewport }).promise;
        });

        container.addEventListener('mousedown', (e) => {
            if (e.target !== canvas) return;
            isDrawing = true;
            const rect = container.getBoundingClientRect();
            startX = e.clientX - rect.left;
            startY = e.clientY - rect.top;

            currentBox = document.createElement('div');
            currentBox.className = 'absolute border-4 border-indigo-600 bg-indigo-600/40 pointer-events-none';
            currentBox.style.left = startX + 'px';
            currentBox.style.top = startY + 'px';
            container.appendChild(currentBox);
        });

        container.addEventListener('mousemove', (e) => {
            if (!isDrawing) return;
            const rect = container.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;

            currentBox.style.width = Math.abs(x - startX) + 'px';
            currentBox.style.height = Math.abs(y - startY) + 'px';
            currentBox.style.left = Math.min(x, startX) + 'px';
            currentBox.style.top = Math.min(y, startY) + 'px';
        });

        container.addEventListener('mouseup', () => {
            if (!isDrawing || !currentBox) return;
            isDrawing = false;

            currentBox.className = 'absolute bg-black pointer-events-auto cursor-pointer hover:opacity-80 transition-opacity';
            currentBox.title = 'Click to remove this redaction';

            currentBox.addEventListener('click', function(e) {
                e.stopPropagation();
                this.remove();
                redactions = redactions.filter(r => r !== this);
                redactCountLabel.textContent = redactions.length;
            });

            redactions.push(currentBox);
            redactCountLabel.textContent = redactions.length;
        });

        document.getElementById('submit-redact').addEventListener('click', () => {
            if (redactions.length === 0) {
                alert('Please mark at least one area to redact.');
                return;
            }

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            // In production: send coordinates + file to backend for true redaction
            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            // formData.append('redactions', JSON.stringify(...));

            // Simulated success for demo
            setTimeout(() => {
                statusArea.classList.add('hidden');
                downloadArea.classList.remove('hidden');
                // document.getElementById('download-link').href = data.download_url;
            }, 2000);
        });
    </script>
</body>
</html>