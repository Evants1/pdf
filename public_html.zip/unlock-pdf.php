<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Unlock PDF Online Free | Remove PDF Password & Restrictions | PDFEase";
$meta_description = "Free online tool to remove passwords and restrictions from protected PDFs. Unlock for editing, printing, copying—no registration required.";
$meta_keywords = "unlock pdf online free, remove pdf password, decrypt pdf, pdf password remover, remove pdf restrictions, free pdf unlocker";
$canonical_url = "https://pdfease.io/unlock-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Unlock PDF",
  "description": "Free online tool to remove passwords and editing/printing restrictions from protected PDF files.",
  "url": "https://pdfease.io/unlock-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Unlock a Protected PDF Online for Free",
  "description": "Step-by-step guide to removing passwords and restrictions from PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your protected PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Enter the password if required (leave blank for permission-only restrictions).",
      "name": "Enter Password"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Unlock Document' and download the unrestricted PDF.",
      "name": "Download Unlocked PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Unlock <span class="text-emerald-600">Protected PDFs</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Remove passwords, printing, editing, and copying restrictions instantly. Regain full control—secure and 100% free.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-emerald-500 hover:bg-emerald-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload protected PDF">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select protected PDF">
                    <label for="file-upload" class="cursor-pointer space-y-6 block">
                        <div class="mx-auto h-28 w-28 text-emerald-600 bg-emerald-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload Locked PDF</span>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • End-to-end encrypted • No signup</p>
                        </div>
                    </label>
                </div>

                <div id="editor-area" class="hidden mt-12 max-w-2xl mx-auto">
                    <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl border border-slate-800">
                        <div class="flex items-center gap-6 mb-8">
                            <div class="text-5xl">🔒</div>
                            <div class="text-left">
                                <p id="file-name-display" class="text-2xl font-bold">document.pdf</p>
                                <p class="text-sm text-slate-400 mt-1">Protected file ready for unlocking</p>
                            </div>
                        </div>

                        <div class="space-y-4">
                            <label for="pdf-pass" class="block text-sm font-bold text-emerald-400 uppercase tracking-wide">Password (if required)</label>
                            <input type="password" id="pdf-pass" placeholder="Enter password or leave blank for restrictions only" class="w-full bg-slate-800 border-2 border-slate-700 rounded-2xl px-6 py-4 text-white focus:outline-none focus:border-emerald-500 transition-all text-base">

                            <p class="text-xs text-slate-400 leading-relaxed">
                                <strong>Note:</strong> If the PDF opens but restricts printing/editing/copying, leave password blank.
                            </p>
                        </div>

                        <button type="button" id="submit-unlock" class="w-full mt-8 bg-emerald-600 hover:bg-emerald-500 text-white py-6 rounded-2xl font-bold text-xl uppercase tracking-wide shadow-xl transition-all active:scale-95">
                            Unlock PDF Now
                        </button>

                        <p class="text-center text-xs text-slate-500 mt-6 uppercase tracking-widest">
                            🔒 End-to-end encryption • Password never stored
                        </p>
                    </div>
                </div>

                <div id="status-area" class="hidden py-32" aria-live="polite">
                    <div class="w-24 h-24 border-8 border-emerald-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Removing Restrictions...</h3>
                    <p class="text-slate-600 text-lg font-medium">Processing securely in memory.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-28 h-28 bg-emerald-600 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">🔓</div>
                    <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Unlocked Successfully!</h2>
                    <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                        All passwords and restrictions have been removed. Your document is now fully editable.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-emerald-600 transition-all hover:-translate-y-1">
                            Download Unlocked PDF
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Unlock Another File
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Use PDFEase to <span class="text-emerald-600">Unlock PDFs</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Secure, fast, and completely free—no software installation needed.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Full Restriction Removal</h3>
                <p class="text-slate-600 leading-relaxed">Removes owner passwords, printing, editing, and copying locks permanently.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Maximum Privacy</h3>
                <p class="text-slate-600 leading-relaxed">End-to-end encryption. Files and passwords processed in memory only—deleted immediately.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-emerald-100 text-emerald-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No accounts, no limits, no watermarks.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Supports All Protection Types</h3>
                    <ul class="space-y-3 text-slate-600">
                        <li class="flex items-center gap-3"><span class="text-emerald-600">✓</span> User (open) password removal</li>
                        <li class="flex items-center gap-3"><span class="text-emerald-600">✓</span> Owner restrictions (print/edit/copy)</li>
                        <li class="flex items-center gap-3"><span class="text-emerald-600">✓</span> 128-bit & 256-bit AES encryption</li>
                    </ul>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Zero Data Retention</h3>
                    <p class="text-slate-600 leading-relaxed">Your file and password are never logged or stored. Processing occurs in volatile memory for maximum security.</p>
                </div>
            </div>

            <div class="bg-emerald-50 border-2 border-emerald-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-emerald-900 mb-6">Common Scenarios</h3>
                <ul class="space-y-4 text-emerald-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-emerald-600 mt-1">•</span> Forgotten password on old documents</li>
                    <li class="flex items-start gap-3"><span class="text-emerald-600 mt-1">•</span> Bank/e-statements with print restrictions</li>
                    <li class="flex items-start gap-3"><span class="text-emerald-600 mt-1">•</span> Secured contracts needing edits</li>
                    <li class="flex items-start gap-3"><span class="text-emerald-600 mt-1">•</span> Shared files with copy protection</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is this legal and ethical?</h4>
                    <p class="text-slate-600">Yes—only unlock PDFs you own or have permission to modify. We do not support illegal decryption.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What if I don't know the password?</h4>
                    <p class="text-slate-600">If it's only owner restrictions (file opens but restricted actions), leave password blank.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my files secure?</h4>
                    <p class="text-slate-600">Absolutely—TLS encryption in transit, processed in memory, deleted immediately after.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it work on all PDFs?</h4>
                    <p class="text-slate-600">Supports most standard encrypted PDFs (AES 128/256). Rare legacy formats may not be compatible.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-emerald-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Unlock Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Remove restrictions in seconds—no software required.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-emerald-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Unlock PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const editorArea = document.getElementById('editor-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const fileNameDisplay = document.getElementById('file-name-display');

        let selectedFile = null;

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-emerald-600', 'bg-emerald-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-emerald-600', 'bg-emerald-50/60');
        });

        fileInput.addEventListener('change', (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            fileNameDisplay.textContent = selectedFile.name;
            dropZone.classList.add('hidden');
            editorArea.classList.remove('hidden');
        });

        document.getElementById('submit-unlock').addEventListener('click', () => {
            const password = document.getElementById('pdf-pass').value;

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('password', password);

            fetch('api/unlock-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    statusArea.classList.add('hidden');
                    if (data.success) {
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        alert('Unlock failed: ' + (data.message || 'Invalid password or unsupported encryption.'));
                        location.reload();
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>