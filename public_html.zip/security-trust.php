<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Security & Trust | PDFEase - Safe PDF Processing";
$meta_description = "PDFEase.io prioritizes your security. Learn about our encryption, automatic file deletion, isolated processing, and commitment to keeping your documents safe.";
$meta_keywords = "pdfease security, secure pdf tools, pdf privacy, file encryption, trust pdfease";
$canonical_url = "https://pdfease.org/security-trust";
?>
<?php include 'static/head.php'; ?>

<body class="bg-white font-sans text-slate-900 antialiased">
    <?php include 'static/nav.php'; ?>

    <section class="bg-slate-50 pt-20 pb-16 border-b border-slate-100">
        <div class="max-w-4xl mx-auto px-6 text-center">
            <div class="inline-flex items-center gap-2 bg-emerald-100 text-emerald-700 px-4 py-2 rounded-full text-xs font-black uppercase tracking-widest mb-6">
                <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 5.225-3.34 9.67-8 11.317C5.34 16.67 2 12.225 2 7c0-.682.057-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd"></path></svg>
                Enterprise-Grade Privacy
            </div>
            <h1 class="text-5xl md:text-7xl font-black text-slate-900 mb-6 tracking-tight italic uppercase">
                Security <span class="text-emerald-600">&</span> Trust
            </h1>
            <p class="text-xl text-slate-500 font-medium leading-relaxed">
                Your documents are your business. Keeping them private is ours. 
                We’ve engineered PDFEase to be a "zero-retention" platform.
            </p>
        </div>
    </section>

    <section class="max-w-7xl mx-auto px-6 py-24">
        <div class="grid md:grid-cols-3 gap-12">
            <div class="space-y-4">
                <div class="w-14 h-14 bg-slate-900 text-white rounded-2xl flex items-center justify-center shadow-xl mb-6 rotate-3">
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z"></path></svg>
                </div>
                <h3 class="text-2xl font-black text-slate-900 uppercase tracking-tighter italic">End-to-End Encryption</h3>
                <p class="text-slate-600 leading-relaxed font-medium">All transfers use <strong>TLS 1.3 (256-bit)</strong> encryption. Your data is tunneled through a secure path, identical to high-level banking transactions.</p>
            </div>

            <div class="space-y-4">
                <div class="w-14 h-14 bg-emerald-600 text-white rounded-2xl flex items-center justify-center shadow-xl mb-6 -rotate-3">
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                </div>
                <h3 class="text-2xl font-black text-slate-900 uppercase tracking-tighter italic">Auto-Destruct Policy</h3>
                <p class="text-slate-600 leading-relaxed font-medium">We don't collect files. Every document is <strong>permanently purged</strong> from our servers within 60 minutes. No backups, no hidden logs.</p>
            </div>

            <div class="space-y-4">
                <div class="w-14 h-14 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-xl mb-6 rotate-6">
                    <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path></svg>
                </div>
                <h3 class="text-2xl font-black text-slate-900 uppercase tracking-tighter italic">Isolated Sandboxing</h3>
                <p class="text-slate-600 leading-relaxed font-medium">Each file is processed in a <strong>one-time virtual container</strong>. Your files are never "mixed" with other users' data or stored in shared directories.</p>
            </div>
        </div>
    </section>

    <section class="bg-slate-900 py-24">
        <div class="max-w-5xl mx-auto px-6">
            <div class="grid lg:grid-cols-2 gap-16 items-center">
                <div>
                    <h2 class="text-4xl font-black text-white mb-6 italic uppercase tracking-tight">The PDFEase <span class="text-emerald-400">Security Stack</span></h2>
                    <ul class="space-y-6">
                        <li class="flex items-start gap-4">
                            <div class="mt-1 bg-emerald-500/20 p-1 rounded-full"><svg class="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg></div>
                            <p class="text-slate-300 font-medium"><strong>No Accounts Required:</strong> We don't ask for your name or email. What we don't have, we can't lose.</p>
                        </li>
                        <li class="flex items-start gap-4">
                            <div class="mt-1 bg-emerald-500/20 p-1 rounded-full"><svg class="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg></div>
                            <p class="text-slate-300 font-medium"><strong>Zero Human Access:</strong> Our algorithms are 100% automated. No employee can ever "preview" your document content.</p>
                        </li>
                        <li class="flex items-start gap-4">
                            <div class="mt-1 bg-emerald-500/20 p-1 rounded-full"><svg class="w-4 h-4 text-emerald-400" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clip-rule="evenodd"></path></svg></div>
                            <p class="text-slate-300 font-medium"><strong>GDPR Ready:</strong> We follow strict data privacy regulations to ensure your right to digital privacy is respected worldwide.</p>
                        </li>
                    </ul>
                </div>
                <div class="bg-slate-800 p-8 rounded-[3rem] border border-slate-700 shadow-3xl text-center">
                    <div class="text-5xl mb-4 text-emerald-400 font-black italic uppercase">100%</div>
                    <div class="text-white font-bold tracking-widest uppercase text-xs mb-6">Safe Processing</div>
                    <p class="text-slate-400 text-sm leading-relaxed mb-8">Have a specific compliance question? Our lead engineer personally handles security inquiries.</p>
                    <a href="mailto:support@pdfease.io" class="inline-block bg-white text-slate-900 px-8 py-3 rounded-2xl font-black uppercase tracking-widest hover:bg-emerald-400 transition-colors">Contact Security Team</a>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-3xl mx-auto px-6 py-24 text-center">
        <h2 class="text-3xl font-black text-slate-900 mb-6 italic uppercase tracking-tighter">Continuous Improvement</h2>
        <p class="text-slate-600 leading-relaxed font-medium mb-12">
            Security isn’t a destination; it’s a constant practice. We conduct regular code reviews and vulnerability scans to ensure PDFEase remains the safest place for your documents on the web.
        </p>
        <div class="h-px bg-slate-100 w-24 mx-auto mb-12"></div>
        <p class="text-slate-400 italic font-medium text-sm">Thank you for trusting PDFEase with your important files.</p>
    </section>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>