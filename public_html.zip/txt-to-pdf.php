<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert TXT to PDF Online Free | Text File to PDF Converter | PDFEase";
$meta_description = "Free online TXT to PDF converter. Turn plain text or Notepad files into professional, print-ready PDFs instantly. No signup, secure processing.";
$meta_keywords = "txt to pdf online free, convert txt to pdf, notepad to pdf, text file to pdf, plain text to pdf converter";
$canonical_url = "https://pdfease.org/txt-to-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase TXT to PDF Converter",
  "description": "Free online tool to convert plain text (.txt) files to professional PDF documents with perfect formatting.",
  "url": "https://pdfease.org/txt-to-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert TXT to PDF Online for Free",
  "description": "Step-by-step guide to converting a plain text file to PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Click or drag your .txt file into the upload area.",
      "name": "Upload TXT File"
    },
    {
      "@type": "HowToStep",
      "text": "Review file details and click 'Convert to PDF'.",
      "name": "Start Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your professionally formatted PDF.",
      "name": "Download PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-blue-600">TXT to PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Transform plain text or Notepad files into clean, professional PDFs. Perfect formatting, print-ready layout—no registration required.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload TXT file">
                    <input type="file" id="file-upload" class="hidden" accept=".txt,text/plain" aria-label="Select TXT file">

                    <div id="upload-prompt" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-blue-600 hover:bg-blue-500 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose TXT File
                            </button>
                            <p class="text-slate-500 font-medium text-base">or drag & drop your Notepad file here • Up to 100MB</p>
                        </div>
                    </div>

                    <div id="convert-area" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📄</div>
                            <div class="text-left">
                                <p id="filename-display" class="text-xl font-bold text-slate-900">notes.txt</p>
                                <p id="filesize-display" class="text-sm text-slate-500">0 KB</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-convert" class="px-20 py-7 bg-blue-600 hover:bg-blue-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Convert to PDF
                        </button>

                        <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Use Different File
                        </button>
                    </div>

                    <div id="processing-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Formatting Your Document...</h3>
                        <p class="text-slate-600 text-lg font-medium">Applying professional layout, margins, and fonts.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-blue-600 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Ready!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your text file has been converted into a clean, professional PDF.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-blue-600 transition-all hover:-translate-y-1">
                                Download PDF
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Convert Another File
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert <span class="text-blue-600">TXT to PDF</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Turn simple text into polished, universally compatible documents.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Universal Compatibility</h3>
                <p class="text-slate-600 leading-relaxed">PDFs look identical on any device or OS—unlike TXT files that vary by editor.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Professional Layout</h3>
                <p class="text-slate-600 leading-relaxed">Standard A4/Letter pages with proper margins and clean typography—ideal for printing.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Files processed securely and automatically deleted after conversion.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Perfect for Developers & Coders</h3>
                    <p class="text-slate-600 leading-relaxed">Convert logs, README files, scripts, or code snippets into formatted PDFs for reports, archiving, or sharing.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Preserves Content Integrity</h3>
                    <p class="text-slate-600 leading-relaxed">Line breaks, spacing, indentation, and special characters (UTF-8) are maintained accurately.</p>
                </div>
            </div>

            <div class="bg-slate-100 rounded-[3rem] p-12 border border-slate-200">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Archiving console output or logs</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Sharing plain notes or drafts professionally</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Creating printable versions of code</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Converting documentation or manuals</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is formatting preserved?</h4>
                    <p class="text-slate-600">Yes—line breaks, paragraphs, indentation, and special characters are accurately reproduced.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What font is used?</h4>
                    <p class="text-slate-600">We use clean, readable fonts (monospaced for code-like content, proportional for general text).</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Supports files up to 100MB. Most text files process instantly.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I convert code files?</h4>
                    <p class="text-slate-600">Yes—upload .py, .js, .log, etc., as plain text. Content will be preserved beautifully.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Convert Your TXT File?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Create professional PDFs from text in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert TXT to PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const filenameDisplay = document.getElementById('filename-display');
        const filesizeDisplay = document.getElementById('filesize-display');

        let selectedFile = null;

        function handleFiles(files) {
            if (files.length === 0) return;
            const file = files[0];
            if (!file.name.toLowerCase().endsWith('.txt') && file.type !== 'text/plain') {
                alert('Please select a valid .txt file.');
                return;
            }
            selectedFile = file;
            filenameDisplay.textContent = file.name;
            filesizeDisplay.textContent = '(' + (file.size / 1024).toFixed(1) + ' KB)';
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            handleFiles(e.dataTransfer.files);
        });

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('txt_file', selectedFile);

            fetch('api/convert-txt-to-pdf.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || 'converted.pdf';
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>