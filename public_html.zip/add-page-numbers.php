<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Add Page Numbers to PDF Online Free | PDF Page Numbering Tool | PDFEase";
$meta_description = "Free online tool to add page numbers to PDF. Customize position, format, and style with live preview. Secure, no signup, no watermarks—unlimited usage.";
$meta_keywords = "add page numbers to pdf online free, pdf page numbering, insert page numbers pdf, paginate pdf, bates numbering pdf, number pdf pages free";
$canonical_url = "https://pdfease.org/add-page-numbers";
?>
<?php include 'static/head.php'; ?>

<!-- pdf.js for live preview -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Add Page Numbers to PDF",
  "description": "Free online tool to add customizable page numbers to PDF documents.",
  "url": "https://pdfease.org/add-page-numbers",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Add Page Numbers to PDF Online for Free",
  "description": "Step-by-step guide to adding page numbers to PDFs using PDFEase.",
  "step": [
    { "@type": "HowToStep", "text": "Upload your PDF file.", "name": "Upload PDF" },
    { "@type": "HowToStep", "text": "Choose position and numbering format with live preview.", "name": "Customize" },
    { "@type": "HowToStep", "text": "Click 'Apply & Generate' and download your numbered PDF.", "name": "Download Numbered PDF" }
  ]
}
</script>

<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>

    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Add Page Numbers to <span class="text-blue-600">PDF</span> Online
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Customize position, format, and style with real-time preview. Perfect for reports, theses, contracts—secure, unlimited, no registration.
                </p>
            </div>

            <!-- Upload Area -->
            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer">
                <input type="file" id="file-upload" class="hidden" accept=".pdf">
                <div class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Number Pages</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • Custom positions • Up to 200MB</p>
                    </div>
                </div>
            </div>

            <!-- Editor Area -->
            <div id="editor-area" class="hidden mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10 max-w-6xl mx-auto">
                <div class="lg:col-span-4 space-y-8 lg:sticky lg:top-8 lg:h-fit">
                    <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                        <div class="flex justify-between items-center mb-8">
                            <h3 class="text-2xl font-extrabold tracking-tight">Page Number Settings</h3>
                            <button type="button" onclick="location.reload()" class="text-slate-400 hover:text-white text-sm font-semibold uppercase tracking-wide">
                                Change File
                            </button>
                        </div>

                        <div class="space-y-8">
                            <div>
                                <label class="block text-sm font-bold uppercase text-slate-400 tracking-widest mb-4">Position</label>
                                <div class="grid grid-cols-3 gap-4">
                                    <button type="button" onclick="setPos('top-left')" class="pos-btn h-20 rounded-2xl bg-slate-800 border-2 border-slate-700 hover:border-blue-500 transition flex items-center justify-center">
                                        <span class="text-xs font-bold uppercase">Top Left</span>
                                    </button>
                                    <button type="button" onclick="setPos('top-center')" class="pos-btn h-20 rounded-2xl bg-slate-800 border-2 border-slate-700 hover:border-blue-500 transition flex items-center justify-center">
                                        <span class="text-xs font-bold uppercase">Top Center</span>
                                    </button>
                                    <button type="button" onclick="setPos('top-right')" class="pos-btn h-20 rounded-2xl bg-slate-800 border-2 border-slate-700 hover:border-blue-500 transition flex items-center justify-center">
                                        <span class="text-xs font-bold uppercase">Top Right</span>
                                    </button>
                                    <button type="button" onclick="setPos('bottom-left')" class="pos-btn h-20 rounded-2xl bg-slate-800 border-2 border-slate-700 hover:border-blue-500 transition flex items-center justify-center">
                                        <span class="text-xs font-bold uppercase">Bottom Left</span>
                                    </button>
                                    <button type="button" onclick="setPos('bottom-center')" class="pos-btn h-20 rounded-2xl bg-slate-700 border-4 border-blue-500 transition flex items-center justify-center shadow-lg">
                                        <span class="text-xs font-bold uppercase">Bottom Center</span>
                                    </button>
                                    <button type="button" onclick="setPos('bottom-right')" class="pos-btn h-20 rounded-2xl bg-slate-800 border-2 border-slate-700 hover:border-blue-500 transition flex items-center justify-center">
                                        <span class="text-xs font-bold uppercase">Bottom Right</span>
                                    </button>
                                </div>
                            </div>

                            <div>
                                <label for="num-format" class="block text-sm font-bold uppercase text-slate-400 tracking-widest mb-3">Number Format</label>
                                <select id="num-format" class="w-full bg-slate-800 text-white rounded-2xl p-5 text-lg focus:outline-none focus:ring-4 focus:ring-blue-500">
                                    <option value="{PAGE}">1</option>
                                    <option value="{PAGE} of {TOTAL}">1 of 10</option>
                                    <option value="Page {PAGE}">Page 1</option>
                                    <option value="Page {PAGE} of {TOTAL}" selected>Page 1 of 10</option>
                                    <option value="- {PAGE} -">- 1 -</option>
                                </select>
                            </div>
                        </div>

                        <button type="button" id="submit-numbering" class="w-full mt-10 bg-blue-600 hover:bg-blue-500 text-white py-6 rounded-2xl font-bold uppercase tracking-widest text-xl shadow-xl transition-all active:scale-95">
                            Apply to All Pages
                        </button>
                    </div>

                    <div class="bg-blue-50 border border-blue-200 rounded-3xl p-8">
                        <p class="text-blue-900 font-medium leading-relaxed">
                            <strong>Tip:</strong> "Page X of Y" format is ideal for professional documents like reports and theses.
                        </p>
                    </div>
                </div>

                <!-- Live Preview -->
                <div class="lg:col-span-8 bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200 min-h-[700px] flex flex-col items-center justify-center">
                    <p class="text-lg font-bold text-slate-700 mb-8 uppercase tracking-wide">Live Preview (Page 1)</p>
                    <div id="preview-container" class="relative max-w-full bg-white rounded-2xl shadow-2xl overflow-hidden">
                        <canvas id="pdf-preview-canvas" class="max-w-full"></canvas>
                        <div id="num-marker" class="absolute bottom-8 left-1/2 -translate-x-1/2 bg-blue-600 text-white px-4 py-2 rounded-lg font-bold text-sm shadow-lg">
                            Page 1 of 10
                        </div>
                    </div>
                </div>
            </div>

            <!-- Processing Status -->
            <div id="status-area" class="hidden py-32 text-center" aria-live="polite">
                <div class="w-28 h-28 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Adding Page Numbers...</h3>
                <p class="text-slate-600 text-lg">Processing all pages—this may take a few seconds.</p>
            </div>

            <!-- Download Area -->
            <div id="download-area" class="hidden py-32 text-center" aria-live="polite">
                <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                    ✓
                </div>
                <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">Page Numbers Added!</h3>
                <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                    Your PDF now has professional page numbering on every page.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-blue-600 hover:bg-blue-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                        Download Numbered PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Number Another PDF
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- Features Section -->
    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Add Page Numbers with <span class="text-blue-600">PDFEase</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Professional numbering, full customization, complete privacy—truly free and unlimited.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Multiple Positions</h3>
                <p class="text-slate-600 leading-relaxed">Top/bottom, left/center/right—choose exactly where numbers appear.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Custom Formats</h3>
                <p class="text-slate-600 leading-relaxed">"Page X of Y", simple numbers, or dashed styles.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no signup, no watermarks added.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">1</span> Upload your PDF</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">2</span> Select position and format</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">3</span> Apply to all pages and download</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Academic theses & papers</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Legal documents & Bates numbering</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Business reports & proposals</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Ebooks & manuscripts</li>
                </ul>
            </div>
        </div>

        <!-- FAQ -->
        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h3 class="text-xl font-bold text-slate-900 mb-3">Can I customize the format?</h3>
                    <p class="text-slate-600">Yes—choose from "Page X of Y", simple numbers, or other styles.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h3 class="text-xl font-bold text-slate-900 mb-3">Does it work on all pages?</h3>
                    <p class="text-slate-600">Yes—numbers are applied consistently to every page automatically.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h3 class="text-xl font-bold text-slate-900 mb-3">Is my PDF secure?</h3>
                    <p class="text-slate-600">Yes—everything happens in your browser. Your file never leaves your device.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h3 class="text-xl font-bold text-slate-900 mb-3">Are there any watermarks added?</h3>
                    <p class="text-slate-600">No—your numbered PDF is clean and professional.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- CTA Section -->
    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Number Your PDF Pages?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Professional page numbering in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Add Page Numbers Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>

    <!-- Main JavaScript -->
    <script>
        // Set pdf.js worker early
        pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const editorArea = document.getElementById('editor-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const canvas = document.getElementById('pdf-preview-canvas');
        const numMarker = document.getElementById('num-marker');
        const numFormatSelect = document.getElementById('num-format');

        let selectedFile = null;
        let pdfDoc = null;
        let currentPos = 'bottom-center';

        // Click on drop zone opens file picker
        dropZone.addEventListener('click', () => fileInput.click());

        // Drag & drop feedback
        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            const file = e.dataTransfer.files[0];
            if (file) processFile(file);
        });

        fileInput.addEventListener('change', e => {
            const file = e.target.files[0];
            if (file) processFile(file);
        });

        async function processFile(file) {
            if (file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            dropZone.classList.add('hidden');
            editorArea.classList.remove('hidden');

            const arrayBuffer = await file.arrayBuffer();
            pdfDoc = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            renderPreviewPage(1);
        }

        async function renderPreviewPage(pageNum) {
            const page = await pdfDoc.getPage(pageNum);
            const scale = 1.5;
            const viewport = page.getViewport({ scale });
            canvas.width = viewport.width;
            canvas.height = viewport.height;

            const context = canvas.getContext('2d');
            await page.render({ canvasContext: context, viewport }).promise;
            updateMarkerPreview();
        }

        function updateMarkerPreview() {
            const format = numFormatSelect.value;
            const total = pdfDoc ? pdfDoc.numPages : 'N';
            const previewText = format.replace('{PAGE}', '1').replace('{TOTAL}', total);
            numMarker.textContent = previewText;

            // Reset position classes
            numMarker.classList.remove('top-8', 'bottom-8', 'left-8', 'right-8', 'left-1/2', '-translate-x-1/2');

            // Vertical
            if (currentPos.includes('top')) {
                numMarker.classList.add('top-8');
            } else {
                numMarker.classList.add('bottom-8');
            }

            // Horizontal
            if (currentPos.includes('left')) {
                numMarker.classList.add('left-8');
            } else if (currentPos.includes('right')) {
                numMarker.classList.add('right-8');
            } else {
                numMarker.classList.add('left-1/2', '-translate-x-1/2');
            }
        }

        function setPos(pos) {
            currentPos = pos;

            // Update button styles
            document.querySelectorAll('.pos-btn').forEach(btn => {
                btn.classList.remove('bg-slate-700', 'border-blue-500', 'border-4', 'shadow-lg');
                btn.classList.add('bg-slate-800', 'border-slate-700', 'border-2');
            });
            const activeBtn = document.querySelector(`[onclick="setPos('${pos}')"]`);
            if (activeBtn) {
                activeBtn.classList.remove('bg-slate-800', 'border-slate-700', 'border-2');
                activeBtn.classList.add('bg-slate-700', 'border-blue-500', 'border-4', 'shadow-lg');
            }

            updateMarkerPreview();
        }

        numFormatSelect.addEventListener('change', updateMarkerPreview);

        // Apply page numbers (using dynamic import of pdf-lib – this fixes all previous errors)
        document.getElementById('submit-numbering').addEventListener('click', async () => {
            if (!selectedFile) return;

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            try {
                // Dynamically import pdf-lib to ensure it's fully loaded
                const { PDFDocument, StandardFonts, rgb } = await import('https://cdn.jsdelivr.net/npm/pdf-lib@1.17.1/+esm');

                const existingBytes = await selectedFile.arrayBuffer();
                const pdfDoc = await PDFDocument.load(existingBytes);

                const pages = pdfDoc.getPages();
                const totalPages = pages.length;
                const font = await pdfDoc.embedFont(StandardFonts.Helvetica);
                const fontSize = 12;
                const color = rgb(0, 0, 0);

                pages.forEach((page, index) => {
                    const pageNumber = index + 1;
                    let text = numFormatSelect.value
                        .replace('{PAGE}', pageNumber)
                        .replace('{TOTAL}', totalPages);

                    const { width, height } = page.getSize();
                    const textWidth = font.widthOfTextAtSize(text, fontSize);

                    let x, y;

                    // Vertical position (40pt margin)
                    if (currentPos.includes('top')) {
                        y = height - 40;
                    } else {
                        y = 40;
                    }

                    // Horizontal position
                    if (currentPos.includes('left')) {
                        x = 50;
                    } else if (currentPos.includes('right')) {
                        x = width - 50 - textWidth;
                    } else { // center
                        x = (width - textWidth) / 2;
                    }

                    page.drawText(text, {
                        x,
                        y,
                        size: fontSize,
                        font,
                        color,
                    });
                });

                const pdfBytes = await pdfDoc.save();
                const blob = new Blob([pdfBytes], { type: 'application/pdf' });
                const url = URL.createObjectURL(blob);

                statusArea.classList.add('hidden');
                downloadArea.classList.remove('hidden');

                const downloadLink = document.getElementById('download-link');
                downloadLink.href = url;
                downloadLink.download = 'numbered_' + selectedFile.name;

            } catch (error) {
                console.error('PDF processing error:', error);
                alert('Error adding page numbers. Please try a different PDF or refresh the page.');
                location.reload();
            }
        });
    </script>
</body>
</html>