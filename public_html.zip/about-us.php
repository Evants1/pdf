<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "About PDFEase - Simplifying PDF Management for Everyone";
$meta_description = "Learn about PDFEase.io: A free online PDF platform developed by a dedicated team. We offer intuitive tools with emerging AI features, robust privacy measures, and a commitment to making document management effortless and accessible.";
$meta_keywords = "About PDFEase, PDF tools, free PDF management";
$canonical_url = "https://pdfease.org/about-us";
$og_image = "https://pdfease.org/images/PDF_Ease_logo-en.webp";
?>
<?php include 'static/head.php'; ?>
<body class="bg-slate-50 text-slate-800 font-sans leading-relaxed antialiased">
  
<?php include 'static/nav.php'; ?>
  
    <header class="relative bg-white border-b border-slate-200 py-12 md:py-20">
        <div class="max-w-5xl mx-auto px-6 text-center">
            <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 tracking-tight">
                About <span class="text-blue-600">PDFEase</span>
            </h1>
            <p class="mt-6 text-slate-600 text-lg md:text-xl max-w-2xl mx-auto leading-relaxed">
                Empowering users with fast, secure, and intuitive PDF tools—completely free, with no hidden costs.
            </p>
        </div>
    </header>
    <main class="max-w-5xl mx-auto px-6 py-12 md:py-24">
        <div class="space-y-20">
            
            <section class="max-w-4xl mx-auto">
                <div class="prose prose-lg prose-slate max-w-none">
                    <p class="text-xl text-slate-700 leading-relaxed mb-8">
                        At <strong class="text-blue-600 font-bold">PDFEase</strong>, we are dedicated to making PDF management <span class="text-slate-900 font-semibold uppercase text-xs tracking-widest bg-slate-100 px-2 py-1 rounded">simple, secure, and accessible</span> for everyone.
                    </p>
                    <p class="text-slate-600">
                        Founded by a team of experienced developers and document management experts, PDFEase emerged from a common challenge: Traditional PDF tools are often cumbersome, expensive, or overly restrictive. We set out to change that by creating a free platform that prioritizes user experience without compromising on quality or security.
                    </p>
                    <p class="text-slate-600 mt-4">
                        Our service is entirely free, allowing you to handle unlimited tasks throughout the day. Whether you're merging files, converting documents, or extracting text, PDFEase is designed to support your workflow seamlessly—no subscriptions, no limits on daily usage.
                    </p>
                </div>
            </section>
            
            <section class="max-w-4xl mx-auto">
                <h2 class="text-3xl font-bold text-slate-900 mb-8">Our Mission</h2>
                <div class="grid md:grid-cols-2 gap-10">
                    <p class="text-slate-600 leading-relaxed">
                        We aim to democratize access to powerful PDF tools, leveraging emerging technologies like AI to streamline everyday document tasks. From students and freelancers to businesses, our goal is to save time and reduce frustration in handling PDFs.
                    </p>
                    <ul class="space-y-4">
                        <li class="flex items-start">
                            <span class="text-blue-600 mr-3 text-xl leading-none">✓</span>
                            <span class="text-slate-600">High-quality, free tools without ads or upsells.</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-blue-600 mr-3 text-xl leading-none">✓</span>
                            <span class="text-slate-600">AI-driven features for smarter document processing.</span>
                        </li>
                        <li class="flex items-start">
                            <span class="text-blue-600 mr-3 text-xl leading-none">✓</span>
                            <span class="text-slate-600">Top-tier privacy and data security for all users.</span>
                        </li>
                    </ul>
                </div>
            </section>
            
            <section class="grid md:grid-cols-3 gap-8">
                <div class="group p-8 bg-white rounded-3xl border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1">
                    <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-6 font-bold text-sm tracking-tighter" aria-hidden="true">AI</div>
                    <h3 class="font-bold text-slate-900 mb-3 text-xl">Emerging AI</h3>
                    <p class="text-slate-600 text-sm leading-relaxed">Intelligent summarization, rewriting, and automation to handle complex documents effortlessly.</p>
                </div>

                <div class="group p-8 bg-white rounded-3xl border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1">
                    <div class="w-12 h-12 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-6 text-xl" role="img" aria-label="Privacy Shield">🔒</div>
                    <h3 class="font-bold text-slate-900 mb-3 text-xl">Privacy First</h3>
                    <p class="text-slate-600 text-sm leading-relaxed">End-to-end encryption and automatic file deletion after processing to protect your data.</p>
                </div>

                <div class="group p-8 bg-white rounded-3xl border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1">
                    <div class="w-12 h-12 bg-purple-50 text-purple-600 rounded-2xl flex items-center justify-center mb-6 text-2xl font-light" aria-hidden="true">∞</div>
                    <h3 class="font-bold text-slate-900 mb-3 text-xl">Unlimited Use</h3>
                    <p class="text-slate-600 text-sm leading-relaxed">Use our tools as often as you need, every day—completely free with no restrictions.</p>
                </div>
            </section>
            
            <div class="grid md:grid-cols-2 gap-16 max-w-4xl mx-auto border-t border-slate-200 pt-16">
                <section>
                    <h2 class="text-2xl font-bold text-slate-900 mb-4">Our Team & Values</h2>
                    <p class="text-slate-600 text-sm leading-relaxed mb-4">
                        Our passionate team is distributed globally, united by a commitment to innovation and user-centric design. We value transparency and continuous improvement.
                    </p>
                    <p class="text-slate-600 text-sm leading-relaxed italic">
                        As an open-source inspired project, we encourage contributions and collaboration.
                    </p>
                </section>
                <section>
                    <h2 class="text-2xl font-bold text-slate-900 mb-4">Future Plans</h2>
                    <p class="text-slate-600 text-sm leading-relaxed">
                        We are constantly expanding. Upcoming additions include advanced AI integrations for OCR, collaborative editing, and mobile optimization.
                    </p>
                </section>
            </div>
            
            <section class="bg-slate-900 rounded-[2.5rem] p-12 text-center text-white shadow-2xl relative overflow-hidden">
                <div class="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl"></div>
                
                <div class="relative z-10">
                    <h2 class="text-3xl md:text-4xl font-bold mb-6">Ready to Simplify Your Workflow?</h2>
                    <p class="text-slate-400 mb-8 max-w-lg mx-auto">Join thousands of users who trust PDFEase for their document needs every day.</p>
                    <a href="/register" class="inline-block bg-blue-600 text-white px-10 py-4 rounded-2xl font-bold hover:bg-blue-500 transition-all shadow-lg shadow-blue-900/40">
                        Get Started for Free
                    </a>
                </div>
            </section>
        </div>
    </main>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>