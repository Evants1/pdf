<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert PDF to Text Online Free | Extract Text from PDF | PDFEase";
$meta_description = "Free online PDF to text converter. Extract clean plain text from PDFs instantly with high accuracy. Ideal for AI prompts, data analysis, and content repurposing—no signup.";
$meta_keywords = "pdf to text online free, extract text from pdf, pdf to txt, pdf text extractor, convert pdf to plain text";
$canonical_url = "https://pdfease.io/pdf-to-text";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase PDF to Text Converter",
  "description": "Free online tool to extract plain text from PDF documents quickly and accurately.",
  "url": "https://pdfease.io/pdf-to-text",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Extract Text from PDF Online for Free",
  "description": "Step-by-step guide to converting PDF to plain text using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Extract Text' to process.",
      "name": "Start Extraction"
    },
    {
      "@type": "HowToStep",
      "text": "Download your clean .txt file.",
      "name": "Download Text"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-green-600">PDF to Text</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Extract clean, raw text from PDFs instantly. Perfect for AI prompts, data processing, coding, and analysis—no formatting preserved.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-green-500 hover:bg-green-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to extract text">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">

                    <div id="upload-ui" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-green-600 bg-green-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 14h1m2 0h4m-6 3h1m2 0h4" class="animate-pulse"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-green-600 hover:bg-green-500 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose PDF File
                            </button>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • Clean UTF-8 output</p>
                        </div>
                    </div>

                    <div id="file-selected-ui" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📄</div>
                            <div class="text-left">
                                <p id="file-name" class="text-xl font-bold text-slate-900">document.pdf</p>
                                <p id="file-size" class="text-sm text-slate-500">0 MB</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-convert" class="px-20 py-7 bg-green-600 hover:bg-green-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Extract Text Now
                        </button>

                        <button type="button" onclick="location.reload()" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Choose Different File
                        </button>
                    </div>

                    <div id="status-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-green-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Extracting Text...</h3>
                        <p class="text-slate-600 text-lg font-medium">Isolating raw content from your PDF.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-green-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">Text Extracted Successfully!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your PDF content is now clean plain text—ready for use.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-green-600 transition-all hover:-translate-y-1">
                                Download .txt File
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Extract from Another PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Extract <span class="text-green-600">Text from PDF</span> with PDFEase?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Clean, accurate text output—ideal for AI and data tasks.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Clean Raw Text</h3>
                <p class="text-slate-600 leading-relaxed">No formatting, images, or layout—just pure readable content.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">AI & LLM Ready</h3>
                <p class="text-slate-600 leading-relaxed">Optimized for prompts, reducing tokens and improving accuracy.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Encrypted processing. Files deleted automatically.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Perfect for Developers & Analysts</h3>
                    <p class="text-slate-600 leading-relaxed">Extract reports, logs, or documents for scripting, NLP, or data pipelines.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Native Text Only</h3>
                    <p class="text-slate-600 leading-relaxed">Best results on text-based PDFs. For scanned docs, use our OCR tool first.</p>
                </div>
            </div>

            <div class="bg-green-50 border-2 border-green-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-green-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-green-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-green-600 mt-1">•</span> Feeding documents to AI models</li>
                    <li class="flex items-start gap-3"><span class="text-green-600 mt-1">•</span> Data extraction for analysis</li>
                    <li class="flex items-start gap-3"><span class="text-green-600 mt-1">•</span> Research and content repurposing</li>
                    <li class="flex items-start gap-3"><span class="text-green-600 mt-1">•</span> Automation and scripting input</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is formatting preserved?</h4>
                    <p class="text-slate-600">No—outputs clean plain text only (no bold, tables, etc.).</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Scanned PDFs supported?</h4>
                    <p class="text-slate-600">Native text only. Use our OCR tool for image-based PDFs.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB—handles large documents easily.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Data privacy?</h4>
                    <p class="text-slate-600">Files encrypted and deleted after processing—no storage.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-green-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Extract Text from PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Clean plain text in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-green-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Extract Text Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadUi = document.getElementById('upload-ui');
        const fileSelectedUi = document.getElementById('file-selected-ui');
        const fileNameDisp = document.getElementById('file-name');
        const fileSizeDisp = document.getElementById('file-size');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');

        let activeFile = null;

        function showFileState(file) {
            if (!file || file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            activeFile = file;
            fileNameDisp.textContent = file.name;
            fileSizeDisp.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            uploadUi.classList.add('hidden');
            fileSelectedUi.classList.remove('hidden');
        }

        fileInput.addEventListener('change', e => {
            if (e.target.files.length > 0) showFileState(e.target.files[0]);
        });

        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('border-green-600', 'bg-green-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-green-600', 'bg-green-50/60');
        });
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('border-green-600', 'bg-green-50/60');
            if (e.dataTransfer.files.length > 0) showFileState(e.dataTransfer.files[0]);
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!activeFile) return;

            fileSelectedUi.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', activeFile);

            fetch('api/text-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        statusArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Extraction failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>