<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Extract PDF Pages Online Free | Pull Specific Pages from PDF | PDFEase";
$meta_description = "Free online tool to extract specific pages from PDF. Visually select pages with thumbnails to create a new PDF—no registration, no watermarks, unlimited.";
$meta_keywords = "extract pdf pages online free, extract pages from pdf, pull pages from pdf, pdf page extractor, separate pdf pages, save specific pdf pages";
$canonical_url = "https://pdfease.io/extract-pages";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Extract PDF Pages",
  "description": "Free online tool to visually extract specific pages from a PDF document.",
  "url": "https://pdfease.io/extract-pages",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Extract Pages from a PDF Online for Free",
  "description": "Step-by-step guide to pulling specific pages from a PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click on page thumbnails to select the ones you want to keep.",
      "name": "Select Pages"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Create New PDF' to generate and download the extracted document.",
      "name": "Download Extracted PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Extract <span class="text-blue-600">PDF Pages</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Visually select and pull any pages from your PDF to create a new document. Perfect quality, secure, unlimited—no signup required.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to extract pages">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Extract Pages</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • Visual selection • Up to 200MB</p>
                    </div>
                </div>
            </div>

            <div id="loading-render" class="hidden py-32" aria-live="polite">
                <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <p class="text-2xl font-bold text-slate-700">Generating Page Previews...</p>
            </div>

            <div id="editor-area" class="hidden mt-12">
                <div class="sticky top-6 z-50 max-w-5xl mx-auto bg-slate-900 text-white p-6 md:p-8 rounded-[3rem] mb-12 flex flex-wrap justify-between items-center shadow-2xl border-4 border-slate-800">
                    <div class="px-4">
                        <p class="text-sm uppercase font-bold text-blue-400 tracking-widest mb-1">Selection Mode</p>
                        <p id="page-count-display" class="text-2xl font-black">0 Pages Selected</p>
                        <p class="text-xs text-slate-400 mt-2">Click thumbnails to select/deselect • Use buttons for bulk actions</p>
                    </div>
                    <div class="flex flex-wrap gap-4 px-4">
                        <button type="button" onclick="selectAll()" class="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-2xl font-bold uppercase tracking-wide transition active:scale-95">
                            Select All
                        </button>
                        <button type="button" onclick="clearAll()" class="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-2xl font-bold uppercase tracking-wide transition active:scale-95">
                            Clear Selection
                        </button>
                        <button type="button" id="submit-extract" class="bg-blue-600 hover:bg-blue-500 px-10 py-4 rounded-2xl font-bold uppercase tracking-wide text-lg transition shadow-xl active:scale-95">
                            Create New PDF
                        </button>
                    </div>
                </div>

                <div class="bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200">
                    <div id="page-grid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-8" role="region" aria-label="PDF page thumbnails for extraction"></div>
                </div>
            </div>

            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="w-28 h-28 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Extracting Selected Pages...</h3>
                <p class="text-slate-600 text-lg">Creating your new PDF—this may take a few seconds.</p>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                    ✓
                </div>
                <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">Pages Extracted Successfully!</h3>
                <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                    Your new PDF contains only the pages you selected, with full original quality.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-blue-600 hover:bg-blue-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                        Download Extracted PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Extract from Another PDF
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Choose PDFEase to <span class="text-blue-600">Extract PDF Pages</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Visual selection, perfect quality, complete privacy—truly unlimited and free.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Visual Thumbnail Selection</h3>
                <p class="text-slate-600 leading-relaxed">See every page clearly and click to select—no typing page numbers.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Preserves Everything</h3>
                <p class="text-slate-600 leading-relaxed">Original quality, searchable text, links, and formatting remain intact.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no signup, no watermarks—extract as often as needed.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">1</span> Upload your PDF</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">2</span> Click thumbnails to select pages</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">3</span> Download your new extracted PDF</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Perfect For</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Pulling chapters from ebooks</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Extracting sections from reports</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Separating contract pages</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Creating custom document subsets</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I extract non-consecutive pages?</h4>
                    <p class="text-slate-600">Yes—click any pages in any order. The new PDF will contain exactly your selection.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is the original quality preserved?</h4>
                    <p class="text-slate-600">Absolutely—extracted pages retain full resolution, fonts, images, and searchable text.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my files secure?</h4>
                    <p class="text-slate-600">Yes—end-to-end encryption and automatic deletion after processing.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What file sizes are supported?</h4>
                    <p class="text-slate-600">Up to 200MB—larger files may take longer to generate thumbnails.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Extract Pages from Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Visual selection in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Extract Pages Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const loadingRender = document.getElementById('loading-render');
        const editorArea = document.getElementById('editor-area');
        const pageGrid = document.getElementById('page-grid');
        const pageCountDisplay = document.getElementById('page-count-display');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');

        let selectedFile = null;
        let pagesToExtract = new Set();
        let totalPages = 0;

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            const file = e.dataTransfer.files[0];
            if (file) processFile(file);
        });

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) processFile(file);
        });

        async function processFile(file) {
            if (file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            dropZone.classList.add('hidden');
            loadingRender.classList.remove('hidden');

            const arrayBuffer = await file.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            totalPages = pdf.numPages;
            pageGrid.innerHTML = '';

            for (let i = 1; i <= totalPages; i++) {
                const page = await pdf.getPage(i);
                const viewport = page.getViewport({ scale: 0.6 });
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                await page.render({ canvasContext: context, viewport: viewport }).promise;

                const div = document.createElement('div');
                div.id = `page-container-${i}`;
                div.className = "relative bg-white p-5 rounded-[2.5rem] shadow-md border-2 border-slate-100 cursor-pointer hover:border-blue-400 transition-all group overflow-hidden";
                div.innerHTML = `
                    <div class="overflow-hidden rounded-2xl mb-4 shadow-sm">
                        <img src="${canvas.toDataURL()}" alt="Preview of page ${i}" class="w-full pointer-events-none">
                    </div>
                    <div class="absolute inset-0 bg-blue-600/10 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"></div>
                    <div class="check-icon absolute top-4 right-4 bg-blue-600 text-white w-10 h-10 rounded-full flex items-center justify-center opacity-0 transition-opacity shadow-lg">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path>
                        </svg>
                    </div>
                    <p class="text-center font-bold text-slate-700 text-sm uppercase tracking-wider">Page ${i}</p>
                `;
                div.onclick = () => togglePage(i, div);
                pageGrid.appendChild(div);
            }

            loadingRender.classList.add('hidden');
            editorArea.classList.remove('hidden');
        }

        function togglePage(pageNum, div) {
            if (pagesToExtract.has(pageNum)) {
                pagesToExtract.delete(pageNum);
                div.classList.remove('border-blue-600', 'shadow-blue-200', 'shadow-2xl');
                div.querySelector('.check-icon').classList.remove('opacity-100');
            } else {
                pagesToExtract.add(pageNum);
                div.classList.add('border-blue-600', 'shadow-blue-200', 'shadow-2xl');
                div.querySelector('.check-icon').classList.add('opacity-100');
            }
            pageCountDisplay.textContent = `${pagesToExtract.size} Page${pagesToExtract.size !== 1 ? 's' : ''} Selected`;
        }

        function selectAll() {
            for (let i = 1; i <= totalPages; i++) {
                if (!pagesToExtract.has(i)) {
                    const div = document.getElementById(`page-container-${i}`);
                    togglePage(i, div);
                }
            }
        }

        function clearAll() {
            const copy = new Set(pagesToExtract);
            copy.forEach(num => {
                const div = document.getElementById(`page-container-${num}`);
                togglePage(num, div);
            });
        }

        document.getElementById('submit-extract').addEventListener('click', () => {
            if (pagesToExtract.size === 0) {
                alert('Please select at least one page to extract.');
                return;
            }

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const sortedPages = Array.from(pagesToExtract).sort((a, b) => a - b);

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('pages', sortedPages.join(','));

            fetch('api/extract-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        statusArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Extraction failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during extraction. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>