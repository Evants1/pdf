<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert PDF to Excel Online Free | PDF to XLSX Converter | PDFEase";
$meta_description = "Free online PDF to Excel converter. Extract tables from scanned or native PDFs to editable XLSX accurately. No signup, no watermarks, unlimited & secure.";
$meta_keywords = "pdf to excel online free, convert pdf to excel, pdf to xlsx, pdf to spreadsheet, scanned pdf to excel, extract tables from pdf, free pdf to excel converter";
$canonical_url = "https://pdfease.org/pdf-to-excel";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase PDF to Excel Converter",
  "description": "Free online tool to convert PDF tables to editable Excel (XLSX) files, including scanned documents via OCR.",
  "url": "https://pdfease.org/pdf-to-excel",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert PDF to Excel Online for Free",
  "description": "Simple steps to extract tables from PDF to editable Excel using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file by clicking or dragging it into the upload area.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Extract to Excel Now' to start automatic table detection and conversion.",
      "name": "Convert"
    },
    {
      "@type": "HowToStep",
      "text": "Download your fully editable XLSX spreadsheet.",
      "name": "Download Excel"
    }
  ]
}
</script>
<body class="bg-white font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-slate-50 pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert PDF to <span class="text-green-600">Excel</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Extract tables from scanned or digital PDFs into fully editable XLSX spreadsheets. Accurate, secure, and unlimited—no registration required.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-green-500 hover:bg-green-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF for conversion">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div id="upload-prompt" class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-green-600 bg-green-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:-rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 17v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2m3 2h12a3 3 0 003-3V7a3 3 0 00-3-3H4a3 3 0 00-3 3v10a3 3 0 003 3z"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Convert</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • Scanned PDFs OK</p>
                    </div>
                </div>

                <div id="convert-area" class="hidden space-y-10">
                    <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                        <div class="text-5xl">📊</div>
                        <div class="text-left">
                            <p id="filename-display" class="text-xl font-bold text-slate-900">document.pdf</p>
                            <p id="filesize-display" class="text-base text-slate-500">0 MB</p>
                        </div>
                    </div>

                    <button type="button" id="trigger-convert" class="px-20 py-7 bg-green-600 hover:bg-green-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                        Extract to Excel Now
                    </button>

                    <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Change File
                    </button>
                </div>

                <div id="processing-area" class="hidden py-32" aria-live="polite">
                    <div class="w-28 h-28 border-8 border-green-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Analyzing & Extracting Tables...</h3>
                    <p class="text-slate-600 text-lg">Advanced OCR and table detection in progress—this may take 10–60 seconds.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                        ✓
                    </div>
                    <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">Excel File Ready!</h3>
                    <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                        Your tables have been accurately extracted into an editable XLSX spreadsheet.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-green-600 hover:bg-green-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                            Download XLSX
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Convert Another PDF
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why PDFEase is the Best <span class="text-green-600">PDF to Excel</span> Converter
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">High accuracy, full privacy, and truly unlimited free conversions.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Superior Accuracy</h3>
                <p class="text-slate-600 leading-relaxed">AI-powered table detection preserves structure, formatting, and data types—even in complex layouts.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Scanned PDFs Supported</h3>
                <p class="text-slate-600 leading-relaxed">Built-in OCR extracts tables from image-based and scanned documents reliably.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-green-100 text-green-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no signup, no watermarks—convert as many files as you need.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700">
                        <li class="flex items-start gap-4"><span class="text-green-600 font-bold text-xl">1</span> Upload your PDF (digital or scanned)</li>
                        <li class="flex items-start gap-4"><span class="text-green-600 font-bold text-xl">2</span> Our engine detects and extracts all tables automatically</li>
                        <li class="flex items-start gap-4"><span class="text-green-600 font-bold text-xl">3</span> Download a clean, editable XLSX file</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Perfect For</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-center gap-3">• Financial reports & invoices</li>
                    <li class="flex items-center gap-3">• Research data & surveys</li>
                    <li class="flex items-center gap-3">• Scanned receipts & statements</li>
                    <li class="flex items-center gap-3">• Any tabular data locked in PDF</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is the conversion accurate for complex tables?</h4>
                    <p class="text-slate-600">Yes—our advanced algorithms handle merged cells, borders, and multi-page tables with high fidelity.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it work with scanned PDFs?</h4>
                    <p class="text-slate-600">Absolutely—integrated OCR extracts text and tables from image-only PDFs reliably.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my files secure and private?</h4>
                    <p class="text-slate-600">Yes—end-to-end encryption and automatic deletion after processing. No data retained.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I use the output in Google Sheets?</h4>
                    <p class="text-slate-600">Yes—native XLSX format works perfectly in Excel, Google Sheets, LibreOffice, and more.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-green-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Unlock Your PDF Data?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Convert tables to editable Excel in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-green-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert PDF to Excel Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const filenameDisplay = document.getElementById('filename-display');
        const filesizeDisplay = document.getElementById('filesize-display');

        let selectedFile = null;

        function handleFiles(files) {
            if (files.length === 0) return;
            const file = files[0];
            if (file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            filenameDisplay.textContent = file.name;
            filesizeDisplay.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-green-600', 'bg-green-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-green-600', 'bg-green-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-green-600', 'bg-green-50/60');
            handleFiles(e.dataTransfer.files);
        });

        fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);

            fetch('api/convert-pdf-to-xlsx.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || selectedFile.name.replace(/\.pdf$/i, '.xlsx');
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Conversion failed. Please try again or use a smaller/simpler PDF.');
                    location.reload();
                });
        });
    </script>
    <script>
        // Simple accordion for FAQ (if kept, but removed in final markup for simplicity)
        // In this version, FAQ is static cards—no JS needed
    </script>
</body>
</html>