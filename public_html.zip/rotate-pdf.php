<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Rotate PDF Pages Online Free | Permanently Fix Sideways PDFs | PDFEase";
$meta_description = "Free online PDF rotator to permanently fix upside-down or sideways pages. Rotate individual pages or the entire document with visual preview—no software needed.";
$meta_keywords = "rotate pdf pages online free, rotate pdf 90 degrees, fix sideways pdf, permanent pdf rotation, flip pdf pages, online pdf rotator";
$canonical_url = "https://pdfease.io/rotate-pdf";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Rotate PDF Pages",
  "description": "Free online tool to permanently rotate PDF pages individually or all at once with visual thumbnails.",
  "url": "https://pdfease.io/rotate-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Rotate PDF Pages Online for Free",
  "description": "Step-by-step guide to permanently rotating pages in a PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF by clicking or dragging it into the upload zone.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Preview thumbnails and click rotate buttons on individual pages, or use 'Rotate All'.",
      "name": "Rotate Pages"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Save Changes' to process and download the permanently rotated PDF.",
      "name": "Download Rotated PDF"
    }
  ]
}
</script>
<body class="bg-white font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-slate-50 pt-16 pb-24 border-b border-slate-100 overflow-hidden">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight italic">
                    Rotate <span class="text-orange-500 underline decoration-orange-200">PDF Pages</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Permanently fix sideways or upside-down PDFs. Rotate individual pages or the entire document with an intuitive visual editor—no installation required.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-200 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-orange-500 hover:bg-orange-50/40 group relative shadow-lg cursor-pointer" aria-label="PDF upload area">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Upload PDF file">
                <label for="file-upload" class="cursor-pointer space-y-6 block">
                    <div class="mx-auto h-28 w-28 text-orange-500 bg-orange-50 rounded-[3rem] flex items-center justify-center shadow-2xl shadow-orange-100 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-black block text-slate-900 tracking-tight uppercase">Select or Drag PDF to Rotate</span>
                        <p class="text-slate-400 font-mono text-sm tracking-[0.2em] font-bold uppercase">Drag & Drop • Permanent Rotation</p>
                        <p class="text-slate-500 mt-4 max-w-md mx-auto text-base">Supports large files • Client-side preview for privacy</p>
                    </div>
                </label>
            </div>

            <div id="editor-area" class="hidden mt-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div class="sticky top-6 z-50 max-w-6xl mx-auto bg-slate-900 text-white p-5 md:p-8 rounded-[3rem] mb-12 flex flex-wrap justify-between items-center shadow-2xl border-4 border-slate-800">
                    <div class="flex flex-wrap items-center gap-4 px-4">
                        <button type="button" onclick="rotateAll(90)" class="bg-orange-600 hover:bg-orange-500 px-6 py-3 rounded-2xl text-sm font-black uppercase tracking-widest transition flex items-center gap-3 active:scale-95">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            Rotate All Clockwise 90°
                        </button>
                        <button type="button" onclick="rotateAll(-90)" class="bg-slate-700 hover:bg-slate-600 px-6 py-3 rounded-2xl text-sm font-black uppercase tracking-widest transition flex items-center gap-3 active:scale-95">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                            Counter-Clockwise
                        </button>
                        <button type="button" onclick="location.reload()" class="text-slate-400 hover:text-white text-xs font-black uppercase tracking-widest">Reset All</button>
                    </div>
                    <button type="button" id="submit-rotate" class="bg-orange-500 hover:bg-orange-400 px-12 py-5 rounded-3xl font-black uppercase tracking-widest text-lg transition shadow-2xl shadow-orange-900/40 active:scale-95">
                        Save Rotated PDF
                    </button>
                </div>

                <div class="bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200">
                    <div id="page-grid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-7 gap-8" role="region" aria-label="PDF page thumbnails for rotation">
                    </div>
                </div>
            </div>

            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="flex flex-col items-center">
                    <div class="relative w-24 h-24 mb-10">
                        <div class="absolute inset-0 border-8 border-orange-100 rounded-full"></div>
                        <div class="absolute inset-0 border-8 border-orange-500 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                    <p class="text-4xl font-black text-slate-900 tracking-tight italic">Applying Permanent Rotations...</p>
                    <p class="text-slate-500 mt-4 text-lg">Updating metadata—this won't alter page content quality.</p>
                </div>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl shadow-emerald-200 rotate-12">✓</div>
                <h2 class="text-5xl md:text-6xl font-black text-slate-900 mb-6 tracking-tight italic">PDF Rotated Successfully!</h2>
                <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto leading-relaxed text-lg">
                    All selected rotations are now permanently applied. Your document will display correctly everywhere.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-black text-2xl shadow-2xl hover:bg-slate-800 transition-all hover:-translate-y-1">
                        Download Rotated PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-500 font-bold hover:text-slate-900 transition-colors uppercase tracking-widest text-sm">
                        Rotate Another File
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-black text-slate-900 mb-6 tracking-tight italic uppercase">
                Why Choose PDFEase to <span class="text-orange-500">Rotate PDFs</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Fast, accurate, and completely free—permanent fixes without quality loss.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">1</div>
                <h3 class="text-2xl font-black mb-4">Permanent Rotation</h3>
                <p class="text-slate-600 leading-relaxed">Updates PDF metadata so pages stay correctly oriented on all devices and viewers.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">2</div>
                <h3 class="text-2xl font-black mb-4">Visual & Precise</h3>
                <p class="text-slate-600 leading-relaxed">See live thumbnails and rotate only the pages you need—no guesswork.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-black shadow-lg">3</div>
                <h3 class="text-2xl font-black mb-4">100% Free & Secure</h3>
                <p class="text-slate-600 leading-relaxed">No signup, no watermarks. Files deleted automatically after processing.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <div class="prose prose-lg max-w-none">
                <h2 class="text-4xl font-black text-slate-900 mb-8 tracking-tight italic">The Most Reliable Way to Fix Sideways PDFs</h2>
                <p class="text-lg text-slate-600 leading-relaxed font-medium">
                    Scanned documents, mobile photos, or improperly exported files often end up with pages in the wrong orientation. Temporary viewer rotations don't fix the underlying issue—our tool does.
                </p>
                <p class="text-lg text-slate-600 leading-relaxed font-medium mt-6">
                    We modify the internal <strong>/Rotate</strong> attribute in the PDF specification, ensuring correct display on phones, tablets, desktops, and printers—permanently.
                </p>
            </div>
            <div class="grid grid-cols-1 gap-8">
                <div class="bg-slate-50 p-10 rounded-[3rem] border border-slate-100 shadow-md">
                    <h4 class="text-xl font-black text-slate-900 mb-4 uppercase tracking-tight flex items-center gap-4">
                        <span class="text-orange-500 text-3xl">↻</span> Individual Page Control
                    </h4>
                    <p class="text-slate-600 font-medium">Hover over any thumbnail and use clockwise/counter-clockwise buttons for precise fixes.</p>
                </div>
                <div class="bg-slate-50 p-10 rounded-[3rem] border border-slate-100 shadow-md">
                    <h4 class="text-xl font-black text-slate-900 mb-4 uppercase tracking-tight flex items-center gap-4">
                        <span class="text-orange-500 text-3xl">↺</span> Bulk Rotation
                    </h4>
                    <p class="text-slate-600 font-medium">Apply 90° clockwise or counter-clockwise to every page with one click.</p>
                </div>
            </div>
        </div>

        <div class="mt-20">
            <h2 class="text-4xl font-black text-center text-slate-900 mb-12 tracking-tight italic uppercase">Frequently Asked <span class="text-orange-500">Questions</span></h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="space-y-4">
                    <h4 class="text-xl font-black text-slate-900 flex items-start gap-3">
                        <span class="text-orange-500 mt-1">●</span>
                        Is the rotation permanent?
                    </h4>
                    <p class="text-slate-600 pl-8 font-medium">Yes—unlike viewer-only rotation, we update the PDF's internal metadata so it displays correctly everywhere.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-black text-slate-900 flex items-start gap-3">
                        <span class="text-orange-500 mt-1">●</span>
                        Does it reduce quality?
                    </h4>
                    <p class="text-slate-600 pl-8 font-medium">No. Rotation only changes orientation metadata—page content remains untouched at original quality.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-black text-slate-900 flex items-start gap-3">
                        <span class="text-orange-500 mt-1">●</span>
                        Can I rotate only some pages?
                    </h4>
                    <p class="text-slate-600 pl-8 font-medium">Absolutely. Use individual controls for mixed-orientation documents.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-black text-slate-900 flex items-start gap-3">
                        <span class="text-orange-500 mt-1">●</span>
                        Are my files private?
                    </h4>
                    <p class="text-slate-600 pl-8 font-medium">Yes. Thumbnails are generated in your browser, and uploaded files are deleted shortly after processing.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-slate-100 py-20 border-t border-slate-200">
        <div class="max-w-5xl mx-auto px-6 text-center">
            <h2 class="text-4xl md:text-5xl font-black text-slate-900 mb-8 tracking-tight italic">Ready to Fix Your PDF Orientation?</h2>
            <p class="text-xl text-slate-600 mb-12 max-w-2xl mx-auto">Rotate pages permanently in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-orange-500 text-white px-20 py-7 rounded-[3rem] font-black text-2xl shadow-2xl hover:bg-orange-400 transition-all hover:-translate-y-1">
                Rotate PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const pageGrid = document.getElementById('page-grid');
        let selectedFile = null;
        let pageRotations = {};

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-orange-600', 'bg-orange-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-orange-600', 'bg-orange-50/60');
        });

        fileInput.addEventListener('change', async (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            dropZone.classList.add('hidden');
            document.getElementById('editor-area').classList.remove('hidden');
            pageGrid.innerHTML = '<p class="col-span-full text-center text-slate-500 py-16 text-lg">Generating page previews...</p>';

            const arrayBuffer = await selectedFile.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            pageGrid.innerHTML = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                pageRotations[i] = 0;
                const page = await pdf.getPage(i);
                const viewport = page.getViewport({ scale: 0.6 });
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                await page.render({ canvasContext: context, viewport: viewport }).promise;

                const div = document.createElement('div');
                div.className = "flex flex-col items-center group relative";
                div.innerHTML = `
                    <div class="relative bg-white p-5 rounded-[2.5rem] shadow-md border-2 border-slate-100 group-hover:border-orange-400 transition-all duration-300 overflow-hidden">
                        <div class="thumbnail-wrapper transition-transform duration-500 ease-in-out">
                            <img src="${canvas.toDataURL()}" alt="Preview of page ${i}" class="rounded-lg shadow-sm max-w-full max-h-full">
                        </div>
                        <div class="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6 pointer-events-none">
                            <button type="button" class="rotate-btn-ccw bg-white text-slate-900 p-4 rounded-2xl shadow-2xl hover:bg-orange-500 hover:text-white transition-all pointer-events-auto scale-100 hover:scale-110">
                                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M10 19l-7-7m0 0l7-7m-7 7h18"></path></svg>
                            </button>
                            <button type="button" class="rotate-btn-cw bg-white text-slate-900 p-4 rounded-2xl shadow-2xl hover:bg-orange-500 hover:text-white transition-all pointer-events-auto scale-100 hover:scale-110">
                                <svg class="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                            </button>
                        </div>
                    </div>
                    <div class="mt-5 text-sm font-black text-orange-600 uppercase tracking-wider">Page ${i}</div>
                `;

                const thumb = div.querySelector('.thumbnail-wrapper');
                div.querySelector('.rotate-btn-cw').onclick = (e) => {
                    e.stopPropagation();
                    pageRotations[i] = (pageRotations[i] + 90) % 360;
                    thumb.style.transform = `rotate(${pageRotations[i]}deg)`;
                };
                div.querySelector('.rotate-btn-ccw').onclick = (e) => {
                    e.stopPropagation();
                    pageRotations[i] = (pageRotations[i] - 90 + 360) % 360;
                    thumb.style.transform = `rotate(${pageRotations[i]}deg)`;
                };

                pageGrid.appendChild(div);
            }
        });

        function rotateAll(deg) {
            Object.keys(pageRotations).forEach((key) => {
                pageRotations[key] = (pageRotations[key] + deg + 360) % 360;
            });
            document.querySelectorAll('.thumbnail-wrapper').forEach((wrapper, idx) => {
                wrapper.style.transform = `rotate(${Object.values(pageRotations)[idx]}deg)`;
            });
        }

        document.getElementById('submit-rotate').addEventListener('click', () => {
            document.getElementById('editor-area').classList.add('hidden');
            document.getElementById('status-area').classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('rotations', JSON.stringify(pageRotations));

            fetch('api/rotate-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status-area').classList.add('hidden');
                        document.getElementById('download-area').classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Processing failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred while saving rotations. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>