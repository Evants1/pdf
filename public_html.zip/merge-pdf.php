<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Merge PDF Online Free | Combine Multiple PDFs | PDFEase";
$meta_description = "Free online PDF merger to combine multiple PDF files into one. Drag & drop to reorder, perfect quality, secure—no signup, no watermarks, unlimited.";
$meta_keywords = "merge pdf online free, combine pdf files, pdf merger, join pdfs, concatenate pdf, free pdf joiner, merge multiple pdfs";
$canonical_url = "https://pdfease.org/merge-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Merge PDF",
  "description": "Free online tool to merge and combine multiple PDF files into one document with drag-and-drop reordering.",
  "url": "https://pdfease.org/merge-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Merge PDF Files Online for Free",
  "description": "Step-by-step guide to combining multiple PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload multiple PDF files by clicking or dragging them into the upload area.",
      "name": "Upload PDFs"
    },
    {
      "@type": "HowToStep",
      "text": "Drag thumbnails to reorder files as needed.",
      "name": "Reorder Files"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Merge PDFs Now' to combine and download the unified document.",
      "name": "Merge & Download"
    }
  ]
}
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Sortable/1.15.0/Sortable.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Merge <span class="text-blue-600">PDF Files</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Combine multiple PDFs into one seamless document. Drag & drop to reorder, perfect quality—secure, unlimited, no registration.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDFs to merge">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" multiple aria-label="Select multiple PDF files">
                <div id="upload-prompt" class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDFs to Merge</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop multiple files • Reorder freely • Up to 200MB total</p>
                    </div>
                </div>
            </div>

            <div id="file-list-area" class="hidden mt-12 max-w-5xl mx-auto">
                <div class="bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200">
                    <p class="text-lg font-bold text-slate-700 mb-6">Drag to reorder files</p>
                    <div id="file-list" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-8" role="list" aria-label="Uploaded PDF files"></div>
                </div>

                <div class="mt-10 flex flex-col sm:flex-row items-center justify-center gap-8">
                    <button type="button" id="trigger-convert" class="px-20 py-7 bg-blue-600 hover:bg-blue-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                        Merge PDFs Now
                    </button>
                    <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Clear All Files
                    </button>
                </div>
            </div>

            <div id="processing-area" class="hidden py-32" aria-live="polite">
                <div class="w-28 h-28 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Merging Your PDFs...</h3>
                <p class="text-slate-600 text-lg">Combining files securely—this may take a few seconds.</p>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                    ✓
                </div>
                <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">PDFs Merged Successfully!</h3>
                <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                    Your files have been combined into one perfect PDF.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-green-600 hover:bg-green-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                        Download Merged PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Merge More PDFs
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why PDFEase is the Best <span class="text-blue-600">PDF Merger</span>
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Fast, secure, and truly unlimited—no watermarks or restrictions.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Drag & Drop Reordering</h3>
                <p class="text-slate-600 leading-relaxed">Easily rearrange files before merging with intuitive thumbnails.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Preserves Everything</h3>
                <p class="text-slate-600 leading-relaxed">Bookmarks, links, forms, and annotations remain intact.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">Merge as many files as you want, anytime—no limits.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">1</span> Upload multiple PDFs</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">2</span> Drag thumbnails to set perfect order</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">3</span> Merge and download instantly</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Combining reports & invoices</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Assembling contracts & appendices</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Creating eBooks or manuals</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Merging scanned documents</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is there a limit on files or size?</h4>
                    <p class="text-slate-600">No file count limit. Total size up to 200MB for optimal speed.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are bookmarks and links preserved?</h4>
                    <p class="text-slate-600">Yes—internal links, bookmarks, forms, and annotations are fully maintained.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I merge encrypted PDFs?</h4>
                    <p class="text-slate-600">Only if unlocked. Password-protected files must be decrypted first.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my data secure?</h4>
                    <p class="text-slate-600">Yes—end-to-end encryption. Files deleted immediately after processing.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Combine Your PDFs?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Merge files in seconds with perfect order and quality.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Merge PDFs Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const fileListArea = document.getElementById('file-list-area');
        const fileList = document.getElementById('file-list');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');

        let uploadedFiles = [];

        function handleFiles(files) {
            const pdfFiles = Array.from(files).filter(f => f.type === 'application/pdf' || f.name.toLowerCase().endsWith('.pdf'));
            if (pdfFiles.length === 0) {
                alert('Please select valid PDF files only.');
                return;
            }
            if (pdfFiles.length < 2) {
                alert('Please select at least 2 PDF files to merge.');
                return;
            }
            uploadedFiles = pdfFiles;
            renderFileList();
            uploadPrompt.classList.add('hidden');
            dropZone.classList.add('hidden');
            fileListArea.classList.remove('hidden');
        }

        function renderFileList() {
            fileList.innerHTML = '';
            uploadedFiles.forEach((file, index) => {
                const div = document.createElement('div');
                div.className = "relative bg-white rounded-3xl shadow-md border-2 border-slate-200 p-6 cursor-grab active:cursor-grabbing hover:border-blue-400 transition-all group overflow-hidden";
                div.innerHTML = `
                    <div class="text-center">
                        <div class="text-4xl mb-4">📄</div>
                        <p class="font-bold text-slate-900 truncate text-sm">${file.name}</p>
                        <p class="text-xs text-slate-500 mt-1">${(file.size / 1024 / 1024).toFixed(1)} MB</p>
                        <div class="absolute top-2 right-2 bg-slate-800 text-white text-xs px-2 py-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                            ${index + 1}
                        </div>
                    </div>
                `;
                fileList.appendChild(div);
            });

            new Sortable(fileList, {
                animation: 300,
                ghostClass: 'opacity-30 bg-blue-100',
                chosenClass: 'scale-110 shadow-2xl',
                dragClass: 'rotate-3',
                forceFallback: true,
                onEnd: () => {
                    const newOrder = Array.from(fileList.children).map(child => {
                        const index = Array.from(fileList.children).indexOf(child);
                        child.querySelector('.absolute').textContent = index + 1;
                        return uploadedFiles[index];
                    });
                    uploadedFiles = newOrder;
                }
            });
        }

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            handleFiles(e.dataTransfer.files);
        });

        fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

        document.getElementById('reset-upload').addEventListener('click', () => location.reload());

        document.getElementById('trigger-convert').addEventListener('click', () => {
            fileListArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            uploadedFiles.forEach((file, index) => {
                formData.append(`pdf_files[${index}]`, file);
            });

            fetch('api/merge.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Merge failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during merging. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>