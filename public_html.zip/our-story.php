<!DOCTYPE html>
<html lang="en">
<?php
// SEO variables - UNCHANGED AS REQUESTED
$page_title = "Our Story & Mission | PDFEase - Free Online PDF Tools";
$meta_description = "Discover the story behind PDFEase.io: a passion project to make PDF management simple, free, and accessible for everyone, powered by intuitive tools and emerging AI.";
$meta_keywords = "pdfease story, pdfease mission, about pdfease, free pdf tools mission";
$canonical_url = "https://pdfease.org/our-story";
$og_image = "https://pdfease.org/images/PDF_Ease_logo-en.webp";
?>

<?php include 'static/head.php'; ?>

<body class="bg-[#fcfcfd] text-slate-800 font-sans leading-relaxed selection:bg-blue-100 selection:text-blue-900">
    
    <?php include 'static/nav.php'; ?>
    
    <header class="relative bg-white border-b border-slate-100 py-16 md:py-28 overflow-hidden">
        <div class="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-50 rounded-full blur-3xl opacity-50"></div>
        <div class="absolute bottom-0 left-0 -ml-20 -mb-20 w-72 h-72 bg-purple-50 rounded-full blur-3xl opacity-50"></div>

        <div class="relative max-w-5xl mx-auto px-6 text-center">
            <h1 class="text-5xl md:text-7xl font-black text-slate-900 tracking-tight leading-[1.1]">
                Our <span class="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Story & Mission</span>
            </h1>
            <p class="mt-8 text-slate-500 text-xl md:text-2xl max-w-2xl mx-auto leading-relaxed font-light italic">
                “We’re on a mission to make working with PDFs effortless — for everyone, everywhere.”
            </p>
        </div>
    </header>

    <main class="max-w-5xl mx-auto px-6 py-16 md:py-32">
        <div class="space-y-24">
            
            <section class="grid lg:grid-cols-12 gap-12 items-start">
                <div class="lg:col-span-5">
                    <h2 class="text-4xl font-black text-slate-900 mb-6">How It <br class="hidden lg:block">Started</h2>
                    <div class="h-1.5 w-20 bg-blue-600 rounded-full"></div>
                </div>
                <div class="lg:col-span-7 prose prose-lg prose-slate text-slate-600">
                    <p class="text-xl font-medium text-slate-700 leading-relaxed">
                        PDFEase began with a simple frustration we all shared: PDFs are everywhere, yet managing them often feels clunky, expensive, or overly complicated.
                    </p>
                    <p>
                        Whether it was merging reports for work, compressing files for email, or trying to extract information from a long document — the available tools either required paid software, forced sign-ups, or added watermarks. 
                    </p>
                    <p>
                        We decided to build a platform that just works — <strong class="text-blue-600 font-bold decoration-blue-200 underline decoration-4 underline-offset-4">no accounts, no hidden fees, no nonsense.</strong>
                    </p>
                </div>
            </section>

            <section class="grid md:grid-cols-2 gap-8">
                <div class="group p-10 bg-white rounded-[2.5rem] border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1">
                    <div class="w-16 h-16 bg-blue-50 text-blue-600 rounded-2xl flex items-center justify-center mb-8 text-3xl transform group-hover:rotate-12 transition-transform">🎯</div>
                    <h4 class="font-black text-slate-900 mb-4 text-2xl uppercase tracking-tight">The Mission</h4>
                    <p class="text-slate-500 text-lg leading-relaxed font-medium">
                        Making PDF tasks truly easy and accessible for students, professionals, and small businesses alike.
                    </p>
                </div>
                
                <div class="group p-10 bg-white rounded-[2.5rem] border border-slate-200 shadow-sm transition-all hover:shadow-xl hover:-translate-y-1">
                    <div class="w-16 h-16 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center mb-8 text-3xl transform group-hover:-rotate-12 transition-transform">🛡️</div>
                    <h4 class="font-black text-slate-900 mb-4 text-2xl uppercase tracking-tight">Our Values</h4>
                    <p class="text-slate-500 text-lg leading-relaxed font-medium">
                        We believe powerful tools shouldn't be locked behind paywalls and that your privacy matters most.
                    </p>
                </div>
            </section>

            <section class="bg-white rounded-[3rem] p-8 md:p-16 border border-slate-100 shadow-inner">
                <div class="grid md:grid-cols-2 gap-16">
                    <div>
                        <h3 class="text-2xl font-black text-slate-900 mb-6 flex items-center">
                            <span class="w-8 h-8 bg-slate-900 text-white text-xs flex items-center justify-center rounded-full mr-3">01</span>
                            What We’re Building
                        </h3>
                        <p class="text-slate-600 leading-relaxed text-lg">
                            A growing set of reliable, fast PDF tools you can trust: from core essentials like merge and compress to smart AI features that help you summarize long documents and extract insights instantly.
                        </p>
                    </div>
                    <div>
                        <h3 class="text-2xl font-black text-slate-900 mb-6 flex items-center">
                            <span class="w-8 h-8 bg-slate-900 text-white text-xs flex items-center justify-center rounded-full mr-3">02</span>
                            Where We’re Going
                        </h3>
                        <p class="text-slate-600 leading-relaxed text-lg">
                            We’re just getting started. Our goal is to become the go-to place for anyone who needs to handle a PDF quickly and for free. We’re independent, community-driven, and fully committed to staying user-first.
                        </p>
                    </div>
                </div>
            </section>

            <section class="relative bg-slate-900 rounded-[3rem] p-12 md:p-20 text-center text-white shadow-2xl overflow-hidden">
                <div class="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-green-500"></div>
                
                <h2 class="text-3xl md:text-5xl font-black mb-6 leading-tight">Together, let’s make <br>document life simpler.</h2>
                <p class="text-slate-400 text-lg md:text-xl mb-10 max-w-xl mx-auto">
                    Have ideas, feedback, or suggestions? We’d love to hear from you.
                </p>
                
                <div class="flex flex-col sm:flex-row items-center justify-center gap-4">
                    <a href="/contact-us" class="group relative inline-flex items-center bg-blue-600 text-white px-12 py-5 rounded-2xl font-black text-lg hover:bg-blue-500 transition-all shadow-xl shadow-blue-900/40">
                        Contact Us
                        <svg class="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                    </a>
                </div>
            </section>
        </div>
    </main>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>