<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert HTML to PDF Online Free | Webpage to PDF Converter | PDFEase";
$meta_description = "Free online HTML to PDF converter. Turn webpages (URL) or local HTML files into perfect PDFs with CSS, images, and layout preserved. Unlimited, secure, no signup.";
$meta_keywords = "html to pdf online free, convert html to pdf, webpage to pdf, url to pdf, website to pdf converter, save webpage as pdf, free html to pdf";
$canonical_url = "https://pdfease.org/html-to-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase HTML to PDF Converter",
  "description": "Free online tool to convert webpages or HTML files to high-quality PDFs with full styling preserved.",
  "url": "https://pdfease.org/html-to-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert HTML or Webpage to PDF Online for Free",
  "description": "Simple steps to save a webpage or HTML file as PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Paste a webpage URL or upload a local HTML file.",
      "name": "Input Source"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Convert to PDF Now' to render the page with full CSS and images.",
      "name": "Convert"
    },
    {
      "@type": "HowToStep",
      "text": "Download your perfect PDF instantly.",
      "name": "Download PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert HTML to <span class="text-orange-600">PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Save webpages or local HTML files as perfect PDFs. Full CSS, images, fonts, and clickable links preserved—secure, unlimited, no registration.
                </p>
            </div>

            <div id="drop-zone" class="max-w-5xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-orange-500 hover:bg-orange-50/30 group relative shadow-lg cursor-pointer" aria-label="Input HTML source for conversion">
                <div id="upload-prompt" class="space-y-8">
                    <div class="mx-auto h-28 w-28 text-orange-600 bg-orange-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4"></path>
                        </svg>
                    </div>

                    <div class="space-y-6 max-w-2xl mx-auto">
                        <div>
                            <label class="block text-left text-sm font-bold uppercase text-slate-600 tracking-wide mb-2">Enter Webpage URL</label>
                            <div class="flex gap-4">
                                <input type="url" id="url-input" placeholder="https://example.com/page.html" class="flex-1 px-6 py-4 rounded-2xl border-2 border-slate-200 focus:border-orange-500 focus:outline-none text-lg">
                                <button type="button" id="trigger-url" class="bg-slate-800 hover:bg-slate-700 text-white px-8 py-4 rounded-2xl font-bold uppercase tracking-wide transition-all active:scale-95">
                                    Load URL
                                </button>
                            </div>
                        </div>

                        <div class="relative flex items-center my-8">
                            <div class="flex-grow border-t-2 border-slate-300"></div>
                            <span class="px-6 text-slate-500 font-bold uppercase tracking-widest text-sm bg-white">OR</span>
                            <div class="flex-grow border-t-2 border-slate-300"></div>
                        </div>

                        <div>
                            <label class="block text-left text-sm font-bold uppercase text-slate-600 tracking-wide mb-2">Upload Local HTML File</label>
                            <input type="file" id="file-upload" class="hidden" accept=".html,.htm,text/html">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="w-full bg-orange-600 hover:bg-orange-500 text-white py-5 rounded-2xl font-bold uppercase tracking-widest text-xl shadow-xl transition-all active:scale-95">
                                Choose HTML File
                            </button>
                        </div>

                        <p class="text-slate-500 text-sm">Supports live webpages • Preserves styling & links • Up to 200MB</p>
                    </div>
                </div>

                <div id="convert-area" class="hidden space-y-10">
                    <div class="bg-slate-100 px-10 py-6 rounded-3xl shadow-lg border border-slate-200 max-w-2xl mx-auto">
                        <p id="source-display" class="text-xl font-bold text-slate-900 break-all"></p>
                    </div>

                    <button type="button" id="trigger-convert" class="px-20 py-7 bg-orange-600 hover:bg-orange-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                        Convert to PDF Now
                    </button>

                    <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Change Source
                    </button>
                </div>

                <div id="processing-area" class="hidden py-32" aria-live="polite">
                    <div class="w-28 h-28 border-8 border-orange-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Rendering Webpage...</h3>
                    <p class="text-slate-600 text-lg max-w-md mx-auto">Loading CSS, fonts, images, and layout—this may take 10–60 seconds.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                        ✓
                    </div>
                    <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">PDF Generated Successfully!</h3>
                    <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                        Your webpage is now a pixel-perfect, print-ready PDF with clickable links.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-orange-600 hover:bg-orange-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                            Download PDF
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Convert Another
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why PDFEase is the Best <span class="text-orange-600">HTML to PDF</span> Converter
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Pixel-perfect rendering, full privacy, truly unlimited free conversions.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Pixel-Perfect Output</h3>
                <p class="text-slate-600 leading-relaxed">Full CSS, fonts, images, and responsive layouts preserved exactly as rendered.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Clickable Links</h3>
                <p class="text-slate-600 leading-relaxed">Hyperlinks remain functional in the generated PDF.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-orange-100 text-orange-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no signup, no watermarks—convert as often as needed.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-4"><span class="text-orange-600 font-bold text-xl">1</span> Enter a URL or upload an HTML file</li>
                        <li class="flex items-start gap-4"><span class="text-orange-600 font-bold text-xl">2</span> Full browser-grade rendering engine processes the page</li>
                        <li class="flex items-start gap-4"><span class="text-orange-600 font-bold text-xl">3</span> Download your high-fidelity PDF instantly</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Ideal For</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-orange-600 mt-1">•</span> Archiving articles & blog posts</li>
                    <li class="flex items-start gap-3"><span class="text-orange-600 mt-1">•</span> Saving invoices & receipts</li>
                    <li class="flex items-start gap-3"><span class="text-orange-600 mt-1">•</span> Converting HTML emails/reports</li>
                    <li class="flex items-start gap-3"><span class="text-orange-600 mt-1">•</span> Documenting web designs</li>
                    <li class="flex items-start gap-3"><span class="text-orange-600 mt-1">•</span> Offline technical documentation</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it support JavaScript-heavy pages?</h4>
                    <p class="text-slate-600">Basic dynamic content is rendered. For complex SPAs, save as static HTML first for best results.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are links clickable in the PDF?</h4>
                    <p class="text-slate-600">Yes—internal and external hyperlinks remain functional.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I convert login-protected pages?</h4>
                    <p class="text-slate-600">No—use browser "Save As" to download HTML locally, then upload the file.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my data secure?</h4>
                    <p class="text-slate-600">Yes—end-to-end encryption and automatic file deletion after processing.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-orange-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Save Your Webpage as PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Pixel-perfect conversion in seconds—no software required.</p>
            <button onclick="document.querySelector('#drop-zone').scrollIntoView({behavior: 'smooth'})" class="bg-white text-orange-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert HTML to PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const urlInput = document.getElementById('url-input');
        const triggerUrl = document.getElementById('trigger-url');
        const triggerConvert = document.getElementById('trigger-convert');
        const sourceDisplay = document.getElementById('source-display');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');

        let selectedFile = null;
        let selectedUrl = null;

        fileInput.addEventListener('change', (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile) return;
            selectedUrl = null;
            sourceDisplay.textContent = `File: ${selectedFile.name}`;
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        });

        triggerUrl.addEventListener('click', () => {
            const url = urlInput.value.trim();
            if (!url) {
                alert('Please enter a valid URL.');
                return;
            }
            if (!/^https?:\/\//i.test(url)) {
                alert('URL must start with http:// or https://');
                return;
            }
            selectedUrl = url;
            selectedFile = null;
            sourceDisplay.textContent = `URL: ${selectedUrl}`;
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        });

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            selectedUrl = null;
            fileInput.value = '';
            urlInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        triggerConvert.addEventListener('click', () => {
            if (!selectedFile && !selectedUrl) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            if (selectedFile) formData.append('html_file', selectedFile);
            if (selectedUrl) formData.append('html_url', selectedUrl);

            fetch('api/convert-html-to-pdf.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || 'webpage.pdf';
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Conversion failed. Please try again or use a simpler page.');
                    location.reload();
                });
        });
    </script>
</body>
</html>