<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert Text to PDF Online Free | TXT to PDF Converter | PDFEase";
$meta_description = "Free online tool to convert plain text (.txt) files to professional PDF documents. Clean formatting, perfect readability—no registration required.";
$meta_keywords = "text to pdf online free, txt to pdf, convert text file to pdf, plain text to pdf, free txt converter";
$canonical_url = "https://pdfease.io/text-to-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Text to PDF Converter",
  "description": "Free online tool to convert plain text files to beautifully formatted PDF documents instantly.",
  "url": "https://pdfease.io/text-to-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert Text to PDF Online for Free",
  "description": "Simple steps to turn a plain text file into a professional PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Click or drag your .txt file into the upload area.",
      "name": "Upload Text File"
    },
    {
      "@type": "HowToStep",
      "text": "Our tool automatically formats and converts it to PDF.",
      "name": "Automatic Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your clean, print-ready PDF document.",
      "name": "Download PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-blue-600">Text to PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Transform plain text files (.txt) into professional, print-ready PDFs instantly. Perfect formatting, preserved content—no signup needed.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload text file">
                    <input type="file" id="file-upload" class="hidden" accept=".txt,text/plain" aria-label="Select .txt file">
                    <label for="file-upload" class="cursor-pointer space-y-6 block">
                        <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload Your Text File</span>
                            <p class="text-slate-500 font-medium text-base">Drag & drop .txt files • Up to 100MB • Secure processing</p>
                        </div>
                    </label>
                </div>

                <div id="status-area" class="hidden py-32 text-center" aria-live="polite">
                    <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Converting to PDF...</h3>
                    <p class="text-slate-600 text-lg font-medium">Applying professional layout and formatting.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-28 h-28 bg-blue-600 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                    <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Created Successfully!</h2>
                    <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                        Your text is now a clean, professional PDF—ready for sharing or printing.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-blue-600 transition-all hover:-translate-y-1">
                            Download PDF
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Convert Another File
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert <span class="text-blue-600">Text to PDF</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Give your plain text the professional presentation it deserves.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Consistent Appearance</h3>
                <p class="text-slate-600 leading-relaxed">PDFs display exactly the same on every device—unlike text files that change with fonts and editors.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Print-Ready Layout</h3>
                <p class="text-slate-600 leading-relaxed">Standard A4/Letter sizing with proper margins—perfect for printing without cut-off text.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Professional & Shareable</h3>
                <p class="text-slate-600 leading-relaxed">Turn logs, notes, code, or reports into polished documents clients and colleagues expect.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Ideal for Developers & Writers</h3>
                    <p class="text-slate-600 leading-relaxed">Convert README files, code comments, log outputs, or draft manuscripts into clean PDFs for sharing or archiving.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Privacy Guaranteed</h3>
                    <p class="text-slate-600 leading-relaxed">All processing happens securely. Files are deleted from our servers within 60 minutes—no storage, no sharing.</p>
                </div>
            </div>
            <div class="bg-blue-50 border-2 border-blue-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-blue-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-blue-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Archiving terminal logs or console output</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Sharing plain text notes professionally</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Creating print versions of code snippets</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Converting README.md or documentation drafts</li>
                </ul>
            </div>
        </div>

        <div class="mt-20">
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What font is used in the PDF?</h4>
                    <p class="text-slate-600">We use a clean, monospaced font (Courier) for code/logs and a proportional serif font for regular text—optimized for readability.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are line breaks preserved?</h4>
                    <p class="text-slate-600">Yes—your original formatting, spacing, and indentation are maintained as closely as possible.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is there a file size limit?</h4>
                    <p class="text-slate-600">Supports text files up to 100MB. Larger files may be processed slower.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I convert other formats?</h4>
                    <p class="text-slate-600">This tool is optimized for .txt. For Markdown, HTML, or Word, check our other conversion tools.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Convert Your Text?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Create professional PDFs from plain text in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert to PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');

        // Drag visual feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (!file || !file.name.endsWith('.txt')) {
                alert('Please select a valid .txt file.');
                return;
            }

            dropZone.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('text_file', file);

            fetch('api/txt-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    statusArea.classList.add('hidden');
                    if (data.success) {
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again with a smaller file.');
                    location.reload();
                });
        });
    </script>
</body>
</html>