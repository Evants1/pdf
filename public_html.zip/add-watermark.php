<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Add Watermark to PDF Online Free | Text Watermark PDF | PDFEase";
$meta_description = "Free online PDF watermark tool. Add customizable text watermarks with adjustable opacity, rotation, and position. Secure, no signup, no watermarks added—unlimited usage.";
$meta_keywords = "add watermark to pdf online free, pdf watermark tool, text watermark pdf, add confidential watermark, diagonal watermark pdf, protect pdf with watermark, free pdf stamper";
$canonical_url = "https://pdfease.org/add-watermark";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Add Watermark to PDF",
  "description": "Free online tool to add customizable text watermarks to PDF documents.",
  "url": "https://pdfease.org/add-watermark",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Add Watermark to PDF Online for Free",
  "description": "Step-by-step guide to adding text watermarks to PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Customize watermark text, opacity, and rotation with live preview.",
      "name": "Customize Watermark"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Stamp All Pages' and download your watermarked PDF.",
      "name": "Download Watermarked PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Add Watermark to <span class="text-blue-600">PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Customize text, opacity, and rotation with real-time preview. Protect documents, mark drafts, or brand files—secure, unlimited, no registration.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to add watermark">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Watermark</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • Custom text & opacity • Up to 200MB</p>
                    </div>
                </div>
            </div>

            <div id="editor-area" class="hidden mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10 max-w-6xl mx-auto">
                <div class="lg:col-span-4 space-y-8 lg:sticky lg:top-8 lg:h-fit">
                    <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                        <div class="flex justify-between items-center mb-8">
                            <h3 class="text-2xl font-extrabold tracking-tight">Watermark Settings</h3>
                            <button type="button" onclick="location.reload()" class="text-slate-400 hover:text-white text-sm font-semibold uppercase tracking-wide">
                                Change File
                            </button>
                        </div>

                        <div class="space-y-8">
                            <div>
                                <label for="wm-text" class="block text-sm font-bold uppercase text-slate-400 tracking-widest mb-3">Watermark Text</label>
                                <input type="text" id="wm-text" value="CONFIDENTIAL" placeholder="e.g., DRAFT, DO NOT COPY" class="w-full bg-slate-800 text-white rounded-2xl p-5 text-lg focus:outline-none focus:ring-4 focus:ring-blue-500">
                            </div>

                            <div class="space-y-6 bg-slate-800/50 rounded-3xl p-6 border border-slate-700/50">
                                <div>
                                    <div class="flex justify-between items-center mb-3">
                                        <label class="text-sm font-bold uppercase text-slate-400 tracking-widest">Opacity</label>
                                        <span id="opacity-val" class="text-lg font-mono text-blue-400">50%</span>
                                    </div>
                                    <input type="range" id="wm-opacity-range" min="10" max="100" value="50" class="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500">
                                </div>

                                <div>
                                    <div class="flex justify-between items-center mb-3">
                                        <label class="text-sm font-bold uppercase text-slate-400 tracking-widest">Rotation</label>
                                        <span id="rotation-val" class="text-lg font-mono text-blue-400">45°</span>
                                    </div>
                                    <input type="range" id="wm-rotation-range" min="-180" max="180" step="1" value="45" class="w-full h-3 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500">
                                </div>
                            </div>
                        </div>

                        <button type="button" id="submit-watermark" class="w-full mt-10 bg-blue-600 hover:bg-blue-500 text-white py-6 rounded-2xl font-bold uppercase tracking-widest text-xl shadow-xl transition-all active:scale-95">
                            Stamp All Pages
                        </button>
                    </div>

                    <div class="bg-blue-50 border border-blue-200 rounded-3xl p-8">
                        <p class="text-blue-900 font-medium leading-relaxed">
                            <strong>Tip:</strong> Use "CONFIDENTIAL", "DRAFT", or your company name. Adjust opacity for subtle or bold marks.
                        </p>
                    </div>
                </div>

                <div class="lg:col-span-8 bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200 min-h-[700px] flex flex-col items-center justify-center">
                    <p class="text-lg font-bold text-slate-700 mb-8 uppercase tracking-wide">Live Preview</p>
                    <div id="preview-container" class="relative max-w-full bg-white rounded-2xl shadow-2xl overflow-hidden">
                        <canvas id="pdf-preview-canvas" class="max-w-full"></canvas>
                        <div id="wm-overlay" class="absolute inset-0 flex items-center justify-center pointer-events-none select-none font-black text-7xl text-center text-slate-900/50" style="transform: rotate(45deg);">
                            CONFIDENTIAL
                        </div>
                    </div>
                </div>
            </div>

            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="w-28 h-28 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Applying Watermark...</h3>
                <p class="text-slate-600 text-lg">Processing all pages—this may take a few seconds.</p>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-32 h-32 bg-green-100 text-green-600 rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">
                    ✓
                </div>
                <h3 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6">Watermark Applied!</h3>
                <p class="text-slate-600 mb-12 text-lg max-w-lg mx-auto">
                    Your PDF now has permanent watermarks on all pages.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-blue-600 hover:bg-blue-500 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl transition-all hover:-translate-y-1">
                        Download Watermarked PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Watermark Another PDF
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Add Watermarks with <span class="text-blue-600">PDFEase</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Professional protection, full customization, complete privacy—truly free and unlimited.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Fully Customizable</h3>
                <p class="text-slate-600 leading-relaxed">Adjust text, opacity, and rotation with real-time preview.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Permanent Protection</h3>
                <p class="text-slate-600 leading-relaxed">Watermarks are embedded permanently across all pages.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no signup, no watermarks added by us.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">How It Works</h3>
                    <ol class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">1</span> Upload your PDF</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">2</span> Customize watermark with live preview</li>
                        <li class="flex items-start gap-4"><span class="text-blue-600 font-bold text-xl">3</span> Apply to all pages and download</li>
                    </ol>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Marking documents as CONFIDENTIAL or DRAFT</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Adding company branding or copyright</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Protecting contracts and proposals</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Preventing unauthorized distribution</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is the watermark permanent?</h4>
                    <p class="text-slate-600">Yes—embedded into the PDF structure across all pages.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I add image watermarks?</h4>
                    <p class="text-slate-600">Currently text only. Image watermark support coming soon.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my files secure?</h4>
                    <p class="text-slate-600">Yes—end-to-end encryption and automatic deletion after processing.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it work on multi-page PDFs?</h4>
                    <p class="text-slate-600">Yes—applies the same watermark to every page automatically.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Protect Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Add professional watermarks in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Add Watermark Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const editorArea = document.getElementById('editor-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const canvas = document.getElementById('pdf-preview-canvas');
        const wmOverlay = document.getElementById('wm-overlay');
        const wmText = document.getElementById('wm-text');
        const wmOpacityRange = document.getElementById('wm-opacity-range');
        const wmRotationRange = document.getElementById('wm-rotation-range');
        const opacityVal = document.getElementById('opacity-val');
        const rotationVal = document.getElementById('rotation-val');

        let selectedFile = null;
        let pdfDoc = null;

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            const file = e.dataTransfer.files[0];
            if (file) processFile(file);
        });

        fileInput.addEventListener('change', (e) => {
            const file = e.target.files[0];
            if (file) processFile(file);
        });

        async function processFile(file) {
            if (file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            dropZone.classList.add('hidden');
            editorArea.classList.remove('hidden');

            const arrayBuffer = await file.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            pdfDoc = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            renderPreviewPage(1);
        }

        async function renderPreviewPage(num) {
            const page = await pdfDoc.getPage(num);
            const viewport = page.getViewport({ scale: 1.5 });
            canvas.width = viewport.width;
            canvas.height = viewport.height;

            const renderContext = {
                canvasContext: canvas.getContext('2d'),
                viewport: viewport
            };
            await page.render(renderContext).promise;
        }

        function updatePreview() {
            const text = wmText.value || 'WATERMARK';
            wmOverlay.textContent = text;
            wmOverlay.style.opacity = wmOpacityRange.value / 100;
            wmOverlay.style.transform = `rotate(${wmRotationRange.value}deg)`;
            opacityVal.textContent = `${wmOpacityRange.value}%`;
            rotationVal.textContent = `${wmRotationRange.value}°`;
        }

        wmText.addEventListener('input', updatePreview);
        wmOpacityRange.addEventListener('input', updatePreview);
        wmRotationRange.addEventListener('input', updatePreview);

        document.getElementById('submit-watermark').addEventListener('click', () => {
            if (!selectedFile) return;

            editorArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('text', wmText.value || 'WATERMARK');
            formData.append('opacity', wmOpacityRange.value / 100);
            formData.append('rotation', wmRotationRange.value);

            fetch('api/watermark-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success && data.download_url) {
                        statusArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Watermark failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>