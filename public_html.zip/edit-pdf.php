<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Free Online PDF Editor | Edit PDF No Sign Up | PDFEase";
$meta_description = "Edit PDF online for free—no downloads or signup. Add text, draw, highlight, annotate, and sign PDFs directly in your browser. 100% private: all processing on your device.";
$meta_keywords = "free pdf editor online, edit pdf free no signup, annotate pdf online, add text to pdf, draw on pdf, highlight pdf free, pdf annotator, browser pdf editor";
$canonical_url = "https://pdfease.org/edit-pdf";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fabric.js/5.3.1/fabric.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Online PDF Editor",
  "description": "Free browser-based PDF editor to add text, draw, annotate, highlight, and sign PDFs with full privacy—no files leave your device.",
  "url": "https://pdfease.org/edit-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Edit a PDF Online for Free",
  "description": "Simple steps to edit PDFs using PDFEase's browser-based editor.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Use tools to add text, draw, highlight, or annotate.",
      "name": "Edit Document"
    },
    {
      "@type": "HowToStep",
      "text": "Export your edited PDF.",
      "name": "Download Edited PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Free Online <span class="text-blue-600">PDF Editor</span>
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Add text, draw, highlight, annotate, and sign PDFs directly in your browser. 100% private—no files leave your device, no signup required.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to edit">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m3.75 9v6m3-3H9m1.5-12H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Edit</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • All processing in your browser • Completely private</p>
                    </div>
                </div>
            </div>

            <div id="canvas-wrapper" class="hidden mt-12">
                <div class="sticky top-6 z-50 max-w-6xl mx-auto bg-slate-900 text-white p-6 md:p-8 rounded-[3rem] mb-12 flex flex-wrap justify-center gap-6 shadow-2xl border-4 border-slate-800">
                    <button type="button" onclick="addText()" class="px-8 py-4 bg-blue-600 hover:bg-blue-500 rounded-2xl font-bold uppercase tracking-widest transition active:scale-95 shadow-lg">
                        Add Text
                    </button>
                    <button type="button" onclick="toggleDraw()" id="draw-btn" class="px-8 py-4 bg-slate-700 hover:bg-slate-600 rounded-2xl font-bold uppercase tracking-widest transition active:scale-95">
                        Freehand Draw
                    </button>
                    <button type="button" onclick="deleteObject()" class="px-8 py-4 bg-red-600 hover:bg-red-500 rounded-2xl font-bold uppercase tracking-widest transition active:scale-95">
                        Delete Selected
                    </button>
                    <button type="button" id="save-pdf" class="px-10 py-5 bg-emerald-500 hover:bg-emerald-400 text-slate-900 rounded-2xl font-bold uppercase tracking-widest text-lg transition shadow-xl active:scale-95">
                        Export PDF
                    </button>
                </div>

                <div class="bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200">
                    <div class="canvas-container mx-auto bg-white rounded-2xl shadow-2xl overflow-hidden">
                        <canvas id="pdf-canvas"></canvas>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why PDFEase is the Best <span class="text-blue-600">Free PDF Editor</span>
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Full-featured editing with complete privacy and no limitations.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">100% Private Editing</h3>
                <p class="text-slate-600 leading-relaxed">All processing happens in your browser—files never leave your device.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Powerful Tools</h3>
                <p class="text-slate-600 leading-relaxed">Add text, draw freehand, annotate, highlight, and more.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Truly Free</h3>
                <p class="text-slate-600 leading-relaxed">No signup, no watermarks, unlimited use—no hidden costs.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Key Features</h3>
                    <ul class="space-y-4 text-slate-700 text-lg">
                        <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">●</span> Add editable text boxes</li>
                        <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">●</span> Freehand drawing & highlighting</li>
                        <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">●</span> Delete or move annotations</li>
                        <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">●</span> High-quality export</li>
                    </ul>
                </div>
            </div>
            <div class="bg-slate-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Perfect For</h3>
                <ul class="space-y-4 text-slate-700 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Signing contracts & forms</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Annotating reports & reviews</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Highlighting ebooks & documents</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Quick edits without software</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my files private?</h4>
                    <p class="text-slate-600">Yes—everything processes locally in your browser. No upload to servers.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I edit existing text?</h4>
                    <p class="text-slate-600">You can overlay new text and annotations. Direct text replacement coming soon.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is it really free?</h4>
                    <p class="text-slate-600">Yes—unlimited edits, no watermarks, no account needed.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it work on mobile?</h4>
                    <p class="text-slate-600">Yes—touch-friendly drawing and editing on phones and tablets.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Edit Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Professional editing with complete privacy—in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Edit PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        let canvas, pdfDoc = null;
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const canvasWrapper = document.getElementById('canvas-wrapper');

        canvas = new fabric.Canvas('pdf-canvas', {
            preserveObjectStacking: true,
            isDrawingMode: false
        });

        function deleteObject() {
            const active = canvas.getActiveObject();
            if (active) {
                canvas.remove(active);
                canvas.renderAll();
            }
        }

        window.addEventListener('keydown', (e) => {
            if ((e.key === 'Delete' || e.key === 'Backspace') && canvas.getActiveObject()) {
                deleteObject();
            }
        });

        fileInput.addEventListener('change', handleUpload);
        dropZone.addEventListener('dragover', (e) => e.preventDefault());
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            if (e.dataTransfer.files.length) {
                handleUpload({ target: { files: e.dataTransfer.files } });
            }
        });

        async function handleUpload(e) {
            const file = e.target.files[0];
            if (!file || file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }

            dropZone.classList.add('hidden');
            canvasWrapper.classList.remove('hidden');

            const arrayBuffer = await file.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            pdfDoc = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
            renderPage(1);
        }

        async function renderPage(num) {
            const page = await pdfDoc.getPage(num);
            const viewport = page.getViewport({ scale: 2.0 });
            canvas.setDimensions({ width: viewport.width, height: viewport.height });

            const renderContext = {
                canvasContext: canvas.getContext('2d'),
                viewport: viewport
            };
            await page.render(renderContext).promise;
        }

        function addText() {
            const text = new fabric.IText('Click to edit text', {
                left: 100,
                top: 100,
                fontFamily: 'Helvetica',
                fontSize: 30,
                fill: '#1e40af',
                fontWeight: 'bold'
            });
            canvas.add(text);
            canvas.setActiveObject(text);
            text.enterEditing();
        }

        function toggleDraw() {
            canvas.isDrawingMode = !canvas.isDrawingMode;
            const btn = document.getElementById('draw-btn');
            if (canvas.isDrawingMode) {
                canvas.freeDrawingBrush.width = 5;
                canvas.freeDrawingBrush.color = '#1e40af';
                btn.classList.add('bg-blue-600');
                btn.classList.remove('bg-slate-700');
            } else {
                btn.classList.remove('bg-blue-600');
                btn.classList.add('bg-slate-700');
            }
        }

        document.getElementById('save-pdf').addEventListener('click', () => {
            const dataURL = canvas.toDataURL({
                format: 'png',
                multiplier: 2
            });

            const { jsPDF } = window.jspdf;
            const img = new Image();
            img.src = dataURL;
            img.onload = () => {
                const pdf = new jsPDF({
                    orientation: img.width > img.height ? 'landscape' : 'portrait',
                    unit: 'px',
                    format: [img.width, img.height]
                });
                pdf.addImage(dataURL, 'PNG', 0, 0, img.width, img.height);
                pdf.save('PDFEase-edited.pdf');
            };
        });
    </script>
</body>
</html>