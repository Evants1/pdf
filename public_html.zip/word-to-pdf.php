<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert Word to PDF Online Free | DOCX to PDF Converter | PDFEase";
$meta_description = "Free online Word to PDF converter. Convert DOCX and DOC files to professional PDFs with perfect formatting preservation. No signup, secure.";
$meta_keywords = "word to pdf online free, convert docx to pdf, doc to pdf, free word to pdf converter, online docx converter";
$canonical_url = "https://pdfease.org/word-to-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Word to PDF Converter",
  "description": "Free online tool to convert Microsoft Word (DOCX/DOC) files to high-quality PDF documents with perfect layout preservation.",
  "url": "https://pdfease.org/word-to-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert Word to PDF Online for Free",
  "description": "Step-by-step guide to converting DOCX/DOC files to PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your Word document (.docx or .doc).",
      "name": "Upload Word File"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Convert to PDF' to process.",
      "name": "Start Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your perfectly formatted PDF.",
      "name": "Download PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-blue-600">Word to PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Transform DOCX and DOC files into professional, print-ready PDFs. Perfect layout, fonts, and images preserved—no registration needed.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload Word document">
                    <input type="file" id="file-upload" class="hidden" accept=".doc,.docx,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document" aria-label="Select Word file">

                    <div id="upload-prompt" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-blue-600 hover:bg-blue-500 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose Word File
                            </button>
                            <p class="text-slate-500 font-medium text-base">Drag & drop .docx or .doc files • Up to 100MB • Secure</p>
                        </div>
                    </div>

                    <div id="convert-area" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📄</div>
                            <div class="text-left">
                                <p id="filename-display" class="text-xl font-bold text-slate-900">document.docx</p>
                                <p id="filesize-display" class="text-sm text-slate-500">0 MB</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-convert" class="px-20 py-7 bg-blue-600 hover:bg-blue-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Convert to PDF
                        </button>

                        <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Cancel & Choose Another
                        </button>
                    </div>

                    <div id="processing-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Converting Document...</h3>
                        <p class="text-slate-600 text-lg font-medium">Rendering layout, fonts, and images with precision.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-blue-600 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Created Successfully!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your Word document is now a professional, fixed-layout PDF.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-blue-600 transition-all hover:-translate-y-1">
                                Download PDF
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Convert Another File
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert <span class="text-blue-600">Word to PDF</span> with PDFEase?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Professional results with zero hassle—trusted accuracy and privacy.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Pixel-Perfect Conversion</h3>
                <p class="text-slate-600 leading-relaxed">Fonts, images, tables, and layouts preserved exactly as in Word.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">End-to-end encryption. Files deleted automatically after processing.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free</h3>
                <p class="text-slate-600 leading-relaxed">No limits, no watermarks, no signup required.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Supports All Word Features</h3>
                    <ul class="space-y-3 text-slate-600">
                        <li class="flex items-center gap-3"><span class="text-blue-600">✓</span> Headers, footers, page numbers</li>
                        <li class="flex items-center gap-3"><span class="text-blue-600">✓</span> Tables, images, and charts</li>
                        <li class="flex items-center gap-3"><span class="text-blue-600">✓</span> Hyperlinks and bookmarks</li>
                        <li class="flex items-center gap-3"><span class="text-blue-600">✓</span> Both .docx and legacy .doc</li>
                    </ul>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Universal Compatibility</h3>
                    <p class="text-slate-600 leading-relaxed">PDFs display consistently across all devices and platforms—perfect for sharing and archiving.</p>
                </div>
            </div>

            <div class="bg-blue-50 border-2 border-blue-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-blue-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-blue-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Sharing contracts or reports professionally</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Submitting assignments or applications</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Archiving editable documents securely</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Preparing print-ready business materials</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is formatting fully preserved?</h4>
                    <p class="text-slate-600">Yes—our advanced rendering engine ensures pixel-perfect conversion of layouts, fonts, and styles.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it support older .doc files?</h4>
                    <p class="text-slate-600">Absolutely—both modern .docx and legacy .doc (Word 97–2003) are fully supported.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 100MB. Complex documents with images may take slightly longer.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are my documents private?</h4>
                    <p class="text-slate-600">Yes—files are processed securely and automatically deleted after conversion.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Convert Your Word Document?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Professional PDFs in seconds—no installation required.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert Word to PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const filenameDisplay = document.getElementById('filename-display');
        const filesizeDisplay = document.getElementById('filesize-display');

        let selectedFile = null;

        function handleFiles(files) {
            if (files.length === 0) return;
            const file = files[0];
            const validTypes = [
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/msword'
            ];
            const validExt = ['.doc', '.docx'];
            const isValid = validTypes.includes(file.type) || validExt.some(ext => file.name.toLowerCase().endsWith(ext));

            if (!isValid) {
                alert('Please select a valid Word document (.doc or .docx).');
                return;
            }

            selectedFile = file;
            filenameDisplay.textContent = file.name;
            filesizeDisplay.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            handleFiles(e.dataTransfer.files);
        });

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('word_file', selectedFile);

            fetch('api/convert-word-to-pdf.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || 'converted.pdf';
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>