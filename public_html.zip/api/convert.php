<?php
// api/convert.php - FIXED (Removed Engine Constraint)

require '../vendor/autoload.php'; 

use CloudConvert\CloudConvert;
use CloudConvert\Models\Job;
use CloudConvert\Models\Task;

header('Content-Type: application/json');

// --- YOUR KEY CONFIGURATION ---
// I've kept the key you provided earlier.
// SECURITY NOTE: Please regenerate this key in your dashboard after testing for safety.
$apiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNjMwNDEyN2ZlZjhkN2Q2YWZjY2IwODE1YmE0YjJiNTY1YTA3YjVjZjJiMTQ5N2FmMWFmMTY4YmIyYzEwNDVkOWI1NTEzMDA0Y2NiNTVkZDMiLCJpYXQiOjE3NjU3ODg1OTYuOTYxMjY5LCJuYmYiOjE3NjU3ODg1OTYuOTYxMjcxLCJleHAiOjQ5MjE0NjIxOTYuOTUyNjUsInN1YiI6IjYyNjY5OTE1Iiwic2NvcGVzIjpbInVzZXIucmVhZCIsInVzZXIud3JpdGUiLCJ0YXNrLnJlYWQiLCJ0YXNrLndyaXRlIiwid2ViaG9vay5yZWFkIiwid2ViaG9vay53cml0ZSIsInByZXNldC5yZWFkIiwicHJlc2V0LndyaXRlIl19.gw10PUN2kGTbSFwHtrxZe8horT0uo3Eeq-q1WWkV1XkeWbJXFH-XqjB699CPEHQFmZZfIwljl3tvSgSlqsgNaXskuqtDTnpl8ry3bZyGIyrVH7FtItTmT1wNNL7S0CVz37fp3jp7GlTFu2uOoePKfcolw1KUdASHq8GZt8rj3-a7w_ZArDzdMv0BviAWbqohTctdulFiBJqRhi-3h-_a8cX0hSm_cKN3nXKHP_8eSCZSyjf-3snXXUcDD9aS4ft7Y5zvw1q24fK86SSP2qd32CpX1MaWF7VYS0KKqYFMPUpSUvlIbQidfqRcyrON3rb8qhrLDTHBGgFPZ88RtRyWHsu7d4WvZVtgNNMyWjZ3Bers8QoEi16rDIbH-mrRU-a2Eu59Op1eWGrY0rx396Y0FHg4Qv3EqQJAKH0OMDSs0jE_C0pJWGAOEr4anxgvg5dvhN0bNECmtTnTRhnLOA9-5vrMeLvqcp1tFnxrZOEo7sjgZA6-cdcU4aYO4QzQzDuySqEweshSIdJ6VQeoUTaNloEFyGudhO4Xpn104zjMIn5wG59D0o2WUBXHWEReTz6V_EFmYjomS-3OoGmjCrU46Aoe1yDcB28FYM-25mFVJzzrdqFwVjb74S2-Gy6m1g3PMtehvRzb-nTCzFrEB2uP7JC6S_sTwHWzNLxYSaeXmC8';

try {
    // 1. Basic Validation
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new Exception("Invalid request method");
    if (!isset($_FILES['pdf_file']) || $_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) throw new Exception("File upload failed.");

    $file = $_FILES['pdf_file'];
    
    // 2. Setup Directories
    $uploadDir = '../uploads/';
    if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

    $cleanName = preg_replace('/[^a-zA-Z0-9_-]/', '', pathinfo($file['name'], PATHINFO_FILENAME)); 
    $uniqueId = uniqid();
    $pdfPath = $uploadDir . $cleanName . '_' . $uniqueId . '.pdf';
    $wordFilename = $cleanName . '_' . $uniqueId . '.docx';
    $wordPath = $uploadDir . $wordFilename;

    if (!move_uploaded_file($file['tmp_name'], $pdfPath)) throw new Exception("Server failed to move uploaded file.");

    // 3. Initialize CloudConvert
    $cloudConvert = new CloudConvert(['api_key' => $apiKey]);

    // 4. Create Job Structure
    $job = (new Job())
        ->addTask(
            (new Task('import/upload', 'upload-file'))
        )
        ->addTask(
            (new Task('convert', 'convert-file'))
                ->set('input', 'upload-file')
                ->set('input_format', 'pdf')
                ->set('output_format', 'docx')
                // ->set('engine', 'office') <--- REMOVED THIS LINE
        )
        ->addTask(
            (new Task('export/url', 'export-file'))
                ->set('input', 'convert-file')
        );

    $cloudConvert->jobs()->create($job);

    // 5. Upload File Stream
    $uploadTask = $job->getTasks()->whereName('upload-file')[0];
    $inputStream = fopen($pdfPath, 'r');
    if (!$inputStream) throw new Exception("Could not open PDF file for reading.");
    
    $cloudConvert->tasks()->upload($uploadTask, $inputStream);

    // 6. Wait for Result (Polling)
    $job = $cloudConvert->jobs()->wait($job); 

    // 7. Check Status & Handle Errors
    if ($job->getStatus() === 'error') {
        $failedTask = null;
        foreach ($job->getTasks() as $task) {
            if ($task->getStatus() === 'error') {
                $failedTask = $task;
                break;
            }
        }
        $errorMsg = $failedTask ? $failedTask->getMessage() : "Unknown CloudConvert Error";
        throw new Exception("CloudConvert Failed: " . $errorMsg);
    }

    // 8. Download Result
    $exportTask = $job->getTasks()->whereName('export-file')[0];
    if ($exportTask->getStatus() === 'finished') {
        $fileResult = $exportTask->getResult()->files[0];
        
        $ch = curl_init($fileResult->url);
        $fp = fopen($wordPath, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);

        // Success Response
        echo json_encode([
            'success' => true, 
            'download_url' => 'uploads/' . $wordFilename,
            'file_name' => $cleanName . '.docx'
        ]);
        
        // Cleanup PDF
        @unlink($pdfPath);
    } else {
        throw new Exception("Conversion finished but no file was returned.");
    }

} catch (Exception $e) {
    // Log error
    error_log("PDF Conversion Error: " . $e->getMessage());
    
    // Send error to frontend
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    
    // Cleanup if exists
    if (isset($pdfPath) && file_exists($pdfPath)) @unlink($pdfPath);
}
?>