<?php
/**
 * api/convert-pdf-to-xlsx.php
 * PDFEase - PDF to Excel API Handler
 */

require '../vendor/autoload.php'; 

use CloudConvert\CloudConvert;
use CloudConvert\Models\Job;
use CloudConvert\Models\Task;

header('Content-Type: application/json');

// Your CloudConvert API Key
$apiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNjMwNDEyN2ZlZjhkN2Q2YWZjY2IwODE1YmE0YjJiNTY1YTA3YjVjZjJiMTQ5N2FmMWFmMTY4YmIyYzEwNDVkOWI1NTEzMDA0Y2NiNTVkZDMiLCJpYXQiOjE3NjU3ODg1OTYuOTYxMjY5LCJuYmYiOjE3NjU3ODg1OTYuOTYxMjcxLCJleHAiOjQ5MjE0NjIxOTYuOTUyNjUsInN1YiI6IjYyNjY5OTE1Iiwic2NvcGVzIjpbInVzZXIucmVhZCIsInVzZXIud3JpdGUiLCJ0YXNrLnJlYWQiLCJ0YXNrLndyaXRlIiwid2ViaG9vay5yZWFkIiwid2ViaG9vay53cml0ZSIsInByZXNldC5yZWFkIiwicHJlc2V0LndyaXRlIl19.gw10PUN2kGTbSFwHtrxZe8horT0uo3Eeq-q1WWkV1XkeWbJXFH-XqjB699CPEHQFmZZfIwljl3tvSgSlqsgNaXskuqtDTnpl8ry3bZyGIyrVH7FtItTmT1wNNL7S0CVz37fp3jp7GlTFu2uOoePKfcolw1KUdASHq8GZt8rj3-a7w_ZArDzdMv0BviAWbqohTctdulFiBJqRhi-3h-_a8cX0hSm_cKN3nXKHP_8eSCZSyjf-3snXXUcDD9aS4ft7Y5zvw1q24fK86SSP2qd32CpX1MaWF7VYS0KKqYFMPUpSUvlIbQidfqRcyrON3rb8qhrLDTHBGgFPZ88RtRyWHsu7d4WvZVtgNNMyWjZ3Bers8QoEi16rDIbH-mrRU-a2Eu59Op1eWGrY0rx396Y0FHg4Qv3EqQJAKH0OMDSs0jE_C0pJWGAOEr4anxgvg5dvhN0bNECmtTnTRhnLOA9-5vrMeLvqcp1tFnxrZOEo7sjgZA6-cdcU4aYO4QzQzDuySqEweshSIdJ6VQeoUTaNloEFyGudhO4Xpn104zjMIn5wG59D0o2WUBXHWEReTz6V_EFmYjomS-3OoGmjCrU46Aoe1yDcB28FYM-25mFVJzzrdqFwVjb74S2-Gy6m1g3PMtehvRzb-nTCzFrEB2uP7JC6S_sTwHWzNLxYSaeXmC8'; 

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new Exception("Invalid request method.");
    }

    if (!isset($_FILES['pdf_file']) || $_FILES['pdf_file']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception("File upload failed.");
    }

    $file = $_FILES['pdf_file'];
    $uploadDir = '../uploads/';

    // Ensure upload directory exists
    if (!file_exists($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    // Generate unique filenames to prevent collisions
    $originalName = pathinfo($file['name'], PATHINFO_FILENAME);
    $cleanName = preg_replace('/[^a-zA-Z0-9_-]/', '', $originalName);
    $uniqueId = uniqid();
    $pdfPath = $uploadDir . $cleanName . '_' . $uniqueId . '.pdf';
    $xlsxFilename = $cleanName . '_' . $uniqueId . '.xlsx';
    $xlsxPath = $uploadDir . $xlsxFilename;

    if (!move_uploaded_file($file['tmp_name'], $pdfPath)) {
        throw new Exception("Failed to save file to server.");
    }

    // Initialize CloudConvert
    $cloudConvert = new CloudConvert(['api_key' => $apiKey]);

    // Create a conversion job
    $job = (new Job())
        ->addTask((new Task('import/upload', 'upload-file')))
        ->addTask(
            (new Task('convert', 'convert-file'))
                ->set('input', 'upload-file')
                ->set('input_format', 'pdf')
                ->set('output_format', 'xlsx')
                ->set('engine', 'office') // Best for table recognition
        )
        ->addTask(
            (new Task('export/url', 'export-file'))
                ->set('input', 'convert-file')
        );

    $cloudConvert->jobs()->create($job);

    // Upload the PDF
    $uploadTask = $job->getTasks()->whereName('upload-file')[0];
    $cloudConvert->tasks()->upload($uploadTask, fopen($pdfPath, 'r'));

    // Wait for the job to finish
    $job = $cloudConvert->jobs()->wait($job); 

    if ($job->getStatus() === 'error') {
        throw new Exception("Conversion error: " . $job->getTasks()->whereStatus('error')[0]->getMessage());
    }

    // Export the file
    $exportTask = $job->getTasks()->whereName('export-file')[0];
    if ($exportTask->getStatus() === 'finished') {
        $fileResult = $exportTask->getResult()->files[0];
        
        // Download the file from CloudConvert to our server
        $ch = curl_init($fileResult->url);
        $fp = fopen($xlsxPath, 'wb');
        curl_setopt($ch, CURLOPT_FILE, $fp);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_exec($ch);
        curl_close($ch);
        fclose($fp);

        // Success Response
        echo json_encode([
            'success' => true, 
            'download_url' => 'uploads/' . $xlsxFilename,
            'file_name' => $originalName . '.xlsx'
        ]);
        
        // Cleanup: Remove original PDF
        @unlink($pdfPath);
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    if (isset($pdfPath) && file_exists($pdfPath)) @unlink($pdfPath);
}