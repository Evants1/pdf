<?php
/**
 * api/convert-pdf-to-txt.php
 * PDFEase - PDF to TXT API Handler
 */

require '../vendor/autoload.php'; 

use CloudConvert\CloudConvert;
use CloudConvert\Models\Job;
use CloudConvert\Models\Task;

header('Content-Type: application/json');

$apiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNjMwNDEyN2ZlZjhkN2Q2YWZjY2IwODE1YmE0YjJiNTY1YTA3YjVjZjJiMTQ5N2FmMWFmMTY4YmIyYzEwNDVkOWI1NTEzMDA0Y2NiNTVkZDMiLCJpYXQiOjE3NjU3ODg1OTYuOTYxMjY5LCJuYmYiOjE3NjU3ODg1OTYuOTYxMjcxLCJleHAiOjQ5MjE0NjIxOTYuOTUyNjUsInN1YiI6IjYyNjY5OTE1Iiwic2NvcGVzIjpbInVzZXIucmVhZCIsInVzZXIud3JpdGUiLCJ0YXNrLnJlYWQiLCJ0YXNrLndyaXRlIiwid2ViaG9vay5yZWFkIiwid2ViaG9vay53cml0ZSIsInByZXNldC5yZWFkIiwicHJlc2V0LndyaXRlIl19.gw10PUN2kGTbSFwHtrxZe8horT0uo3Eeq-q1WWkV1XkeWbJXFH-XqjB699CPEHQFmZZfIwljl3tvSgSlqsgNaXskuqtDTnpl8ry3bZyGIyrVH7FtItTmT1wNNL7S0CVz37fp3jp7GlTFu2uOoePKfcolw1KUdASHq8GZt8rj3-a7w_ZArDzdMv0BviAWbqohTctdulFiBJqRhi-3h-_a8cX0hSm_cKN3nXKHP_8eSCZSyjf-3snXXUcDD9aS4ft7Y5zvw1q24fK86SSP2qd32CpX1MaWF7VYS0KKqYFMPUpSUvlIbQidfqRcyrON3rb8qhrLDTHBGgFPZ88RtRyWHsu7d4WvZVtgNNMyWjZ3Bers8QoEi16rDIbH-mrRU-a2Eu59Op1eWGrY0rx396Y0FHg4Qv3EqQJAKH0OMDSs0jE_C0pJWGAOEr4anxgvg5dvhN0bNECmtTnTRhnLOA9-5vrMeLvqcp1tFnxrZOEo7sjgZA6-cdcU4aYO4QzQzDuySqEweshSIdJ6VQeoUTaNloEFyGudhO4Xpn104zjMIn5wG59D0o2WUBXHWEReTz6V_EFmYjomS-3OoGmjCrU46Aoe1yDcB28FYM-25mFVJzzrdqFwVjb74S2-Gy6m1g3PMtehvRzb-nTCzFrEB2uP7JC6S_sTwHWzNLxYSaeXmC8'; 

try {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') throw new Exception("Invalid request.");
    if (!isset($_FILES['pdf_file'])) throw new Exception("No file uploaded.");

    $file = $_FILES['pdf_file'];
    $uploadDir = '../uploads/';
    if (!file_exists($uploadDir)) mkdir($uploadDir, 0777, true);

    $originalName = pathinfo($file['name'], PATHINFO_FILENAME);
    $uniqueId = uniqid();
    $pdfPath = $uploadDir . $uniqueId . '.pdf';
    
    if (!move_uploaded_file($file['tmp_name'], $pdfPath)) throw new Exception("Upload error.");

    $cloudConvert = new CloudConvert(['api_key' => $apiKey]);

    $job = new Job();

    // Task 1: Upload
    $job->addTask(new Task('import/upload', 'upload-file'));

    // Task 2: Convert to TXT
    $convertTask = new Task('convert', 'convert-file');
    $convertTask->set('input', 'upload-file');
    $convertTask->set('output_format', 'txt');
    $job->addTask($convertTask);

    // Task 3: Export
    $exportTask = new Task('export/url', 'export-file');
    $exportTask->set('input', 'convert-file');
    $job->addTask($exportTask);

    $cloudConvert->jobs()->create($job);
    
    $uploadTask = $job->getTasks()->whereName('upload-file')[0];
    $cloudConvert->tasks()->upload($uploadTask, fopen($pdfPath, 'r'));

    $job = $cloudConvert->jobs()->wait($job); 
    
    if ($job->getStatus() === 'finished') {
        $exportTask = $job->getTasks()->whereName('export-file')[0];
        $fileResult = $exportTask->getResult()->files[0];
        
        $finalName = $originalName . '_' . $uniqueId . '.txt';
        $finalPath = $uploadDir . $finalName;

        $content = file_get_contents($fileResult->url);
        if($content === false) throw new Exception("Failed to download text.");
        file_put_contents($finalPath, $content);

        echo json_encode([
            'success' => true, 
            'download_url' => 'uploads/' . $finalName,
            'file_name' => $originalName . '.txt'
        ]);
        
        @unlink($pdfPath);
    } else {
        throw new Exception("Extraction failed.");
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    if (isset($pdfPath) && file_exists($pdfPath)) @unlink($pdfPath);
}