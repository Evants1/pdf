<?php
require '../vendor/autoload.php';
use CloudConvert\CloudConvert;
use CloudConvert\Models\Job;
use CloudConvert\Models\Task;

header('Content-Type: application/json');

$apiKey = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiNjMwNDEyN2ZlZjhkN2Q2YWZjY2IwODE1YmE0YjJiNTY1YTA3YjVjZjJiMTQ5N2FmMWFmMTY4YmIyYzEwNDVkOWI1NTEzMDA0Y2NiNTVkZDMiLCJpYXQiOjE3NjU3ODg1OTYuOTYxMjY5LCJuYmYiOjE3NjU3ODg1OTYuOTYxMjcxLCJleHAiOjQ5MjE0NjIxOTYuOTUyNjUsInN1YiI6IjYyNjY5OTE1Iiwic2NvcGVzIjpbInVzZXIucmVhZCIsInVzZXIud3JpdGUiLCJ0YXNrLnJlYWQiLCJ0YXNrLndyaXRlIiwid2ViaG9vay5yZWFkIiwid2ViaG9vay53cml0ZSIsInByZXNldC5yZWFkIiwicHJlc2V0LndyaXRlIl19.gw10PUN2kGTbSFwHtrxZe8horT0uo3Eeq-q1WWkV1XkeWbJXFH-XqjB699CPEHQFmZZfIwljl3tvSgSlqsgNaXskuqtDTnpl8ry3bZyGIyrVH7FtItTmT1wNNL7S0CVz37fp3jp7GlTFu2uOoePKfcolw1KUdASHq8GZt8rj3-a7w_ZArDzdMv0BviAWbqohTctdulFiBJqRhi-3h-_a8cX0hSm_cKN3nXKHP_8eSCZSyjf-3snXXUcDD9aS4ft7Y5zvw1q24fK86SSP2qd32CpX1MaWF7VYS0KKqYFMPUpSUvlIbQidfqRcyrON3rb8qhrLDTHBGgFPZ88RtRyWHsu7d4WvZVtgNNMyWjZ3Bers8QoEi16rDIbH-mrRU-a2Eu59Op1eWGrY0rx396Y0FHg4Qv3EqQJAKH0OMDSs0jE_C0pJWGAOEr4anxgvg5dvhN0bNECmtTnTRhnLOA9-5vrMeLvqcp1tFnxrZOEo7sjgZA6-cdcU4aYO4QzQzDuySqEweshSIdJ6VQeoUTaNloEFyGudhO4Xpn104zjMIn5wG59D0o2WUBXHWEReTz6V_EFmYjomS-3OoGmjCrU46Aoe1yDcB28FYM-25mFVJzzrdqFwVjb74S2-Gy6m1g3PMtehvRzb-nTCzFrEB2uP7JC6S_sTwHWzNLxYSaeXmC8';

try {
    if (!isset($_FILES['ppt_file'])) {
        throw new Exception("No PowerPoint file uploaded.");
    }

    $pptFile = $_FILES['ppt_file'];
    $cloudConvert = new CloudConvert(['api_key' => $apiKey]);

    $job = (new Job())
        // Step 1: Upload the PPT/PPTX
        ->addTask(new Task('import/upload', 'import-ppt'))
        
        // Step 2: Convert to PDF
        ->addTask(
            (new Task('convert', 'convert-ppt'))
                ->set('input', 'import-ppt')
                ->set('output_format', 'pdf')
        )
        
        // Step 3: Export the result
        ->addTask(
            (new Task('export/url', 'export-ppt'))
                ->set('input', 'convert-ppt')
        );

    $cloudConvert->jobs()->create($job);

    // Upload content to the specific import task
    $uploadTask = $job->getTasks()->whereName('import-ppt')[0];
    $cloudConvert->tasks()->upload($uploadTask, fopen($pptFile['tmp_name'], 'r'));

    // Wait for the server to process the slides
    $job = $cloudConvert->jobs()->wait($job);
    
    // Grab results from the export task
    $exportTask = $job->getTasks()->whereName('export-ppt')[0];
    $fileResult = $exportTask->getResult()->files[0];

    // Store file locally with unique name
    $outFilename = 'presentation_' . bin2hex(random_bytes(6)) . '.pdf';
    file_put_contents('../uploads/' . $outFilename, file_get_contents($fileResult->url));

    echo json_encode([
        'success' => true, 
        'download_url' => 'uploads/' . $outFilename
    ]);

} catch (Exception $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'Conversion failed: ' . $e->getMessage()
    ]);
}