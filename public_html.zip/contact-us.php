<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Contact Us | PDFEase - Get in Touch";
$meta_description = "Have questions, feedback, or suggestions for PDFEase.io? Reach out to our team—we're here to help as we build free online PDF tools.";
$meta_keywords = "contact pdfease, pdf support, feedback, pdf tools help";
$canonical_url = "https://pdfease.org/contact-us";
$og_image = "https://pdfease.org/images/PDF_Ease_logo-en.webp";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdn.tailwindcss.com"></script>

<body class="bg-gray-50 text-slate-800 font-sans">
  
<?php include 'static/nav.php'; ?>
  
    <section id="hero" class="bg-slate-900 py-16 md:py-24">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold text-white animate-fade-up tracking-tight">Contact Us</h1>
            <p class="text-slate-400 mt-4 text-lg max-w-2xl mx-auto">We're here to help with any questions, feedback, or suggestions as we develop PDFEase.</p>
        </div>
    </section>

    <div class="container mx-auto px-4 -mt-12 mb-20">
        <section id="contact" class="bg-white rounded-2xl shadow-xl overflow-hidden border border-slate-100">
            <div class="flex flex-wrap">
                
                <div class="w-full lg:w-2/3 p-8 md:p-12">
                    <h3 class="text-2xl font-bold text-slate-900 mb-6">Send Us a Message</h3>
                    
                    <form class="space-y-6" action="https://formspree.io/f/your-form-id" method="POST">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label for="name" class="block text-sm font-semibold text-slate-700 mb-2">Your Name</label>
                                <input type="text" id="name" name="name" required 
                                    class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                                    placeholder="John Doe">
                            </div>
                            <div>
                                <label for="email" class="block text-sm font-semibold text-slate-700 mb-2">Your Email Address</label>
                                <input type="email" id="email" name="email" required 
                                    class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                                    placeholder="john@example.com">
                            </div>
                        </div>

                        <div>
                            <label for="subject" class="block text-sm font-semibold text-slate-700 mb-2">Subject</label>
                            <select id="subject" name="subject" required 
                                class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all bg-white">
                                <option value="" disabled selected>Select a topic...</option>
                                <option value="general">General Inquiry</option>
                                <option value="technical">Technical Support</option>
                                <option value="billing">Billing & Premium</option>
                                <option value="feature">Feature Request</option>
                                <option value="business">Business & API</option>
                                <option value="report-error">Report an Error</option>
                            </select>
                        </div>

                        <div>
                            <label for="message" class="block text-sm font-semibold text-slate-700 mb-2">Your Message</label>
                            <textarea id="message" name="message" rows="5" required 
                                class="w-full px-4 py-3 rounded-lg border border-slate-200 focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all"
                                placeholder="How can we help you?"></textarea>
                        </div>

                        <button type="submit" 
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 px-8 rounded-lg transition-colors shadow-lg shadow-blue-200 inline-block w-full md:w-auto text-center">
                            Send Message
                        </button>
                    </form>
                </div>

                <div class="w-full lg:w-1/3 bg-slate-50 p-8 md:p-12 border-t lg:border-t-0 lg:border-l border-slate-100">
                    <h3 class="text-xl font-bold text-slate-900 mb-8">Support Options</h3>
                    
                    <div class="space-y-8">
                        <div class="flex items-start gap-4">
                            <div class="bg-blue-100 p-3 rounded-lg">
                                <svg class="w-6 h-6 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900">Email Us</h4>
                                <p class="text-blue-600 font-medium">support@pdfease.org</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="bg-slate-200 p-3 rounded-lg">
                                <svg class="w-6 h-6 text-slate-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900">FAQ</h4>
                                <p class="text-sm text-slate-600">Check our upcoming FAQ for common questions about tools and features.</p>
                            </div>
                        </div>

                        <div class="flex items-start gap-4">
                            <div class="bg-green-100 p-3 rounded-lg">
                                <svg class="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path></svg>
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900">Feedback Welcome</h4>
                                <p class="text-sm text-slate-600">We value your input to improve the platform daily.</p>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </section>
    </div>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>