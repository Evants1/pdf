<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Terms of Use | PDFEase - Free Online PDF Tools";
$meta_description = "Read the Terms of Use for PDFEase.io. By using our free PDF tools, you agree to these simple rules for fair and responsible use.";
$meta_keywords = "pdfease terms of use, terms and conditions, pdf tools terms, acceptable use";
$canonical_url = "https://pdfease.org/terms-of-use";
?>
<?php include 'static/head.php'; ?>

<body class="bg-white font-sans text-slate-900 antialiased selection:bg-slate-900 selection:text-white">
    <?php include 'static/nav.php'; ?>

    <div id="progress-bar" class="fixed top-0 left-0 h-1 bg-slate-900 z-50 transition-all duration-150" style="width: 0%"></div>

    <section class="bg-slate-50 pt-24 pb-16 border-b border-slate-100">
        <div class="max-w-4xl mx-auto px-6">
            <div class="flex flex-col md:flex-row md:items-end justify-between gap-6">
                <div>
                    <h1 class="text-5xl md:text-7xl font-black text-slate-900 tracking-tighter italic uppercase">
                        Terms <span class="text-slate-400">of</span> Use
                    </h1>
                    <p class="mt-4 text-slate-500 font-medium">Last updated: December 14, 2025</p>
                </div>
                <div class="hidden md:block">
                    <a href="mailto:support@pdfease.io" class="text-sm font-black uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-colors">Legal Inquiry →</a>
                </div>
            </div>
        </div>
    </section>

    <main class="max-w-6xl mx-auto px-6 py-20">
        <div class="grid lg:grid-cols-12 gap-16">
            
            <aside class="lg:col-span-3 hidden lg:block">
                <nav class="sticky top-12 space-y-4">
                    <p class="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400 mb-6">Contents</p>
                    <ul class="space-y-3">
                        <li><a href="#service" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">01. Service Use</a></li>
                        <li><a href="#acceptable" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">02. Acceptable Use</a></li>
                        <li><a href="#responsibility" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">03. Responsibility</a></li>
                        <li><a href="#warranties" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">04. Warranties</a></li>
                        <li><a href="#liability" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">05. Liability</a></li>
                        <li><a href="#contact" class="text-sm font-bold text-slate-500 hover:text-slate-900 transition-colors">06. Contact</a></li>
                    </ul>
                </nav>
            </aside>

            <div class="lg:col-span-9 prose prose-slate prose-lg max-w-none prose-headings:italic prose-headings:font-black prose-headings:uppercase prose-headings:tracking-tighter">
                <p class="lead text-xl text-slate-600 font-medium">
                    Welcome to <strong>pdfease.io</strong>. These terms govern your use of our free browser-based tools. By using this site, you agree to these simple rules for fair and responsible use.
                </p>

                <hr class="border-slate-100 my-12" />

                <section id="service">
                    <h2>01. Use of Our Service</h2>
                    <p>PDFEase provides free tools for viewing, editing, merging, and compressing PDF files. You may use this service for both personal and commercial purposes without registration.</p>
                    <div class="bg-slate-50 p-6 rounded-3xl border border-slate-100 not-prose mb-8">
                        <p class="text-xs font-black uppercase text-slate-400 mb-2 tracking-widest italic">In Plain English</p>
                        <p class="text-slate-600 font-medium">Use it for work or home. No account needed. We might update the tools whenever we want.</p>
                    </div>
                </section>

                <section id="acceptable">
                    <h2>02. Acceptable Use</h2>
                    <p>You agree not to engage in any activity that compromises the security or integrity of our platform. This includes, but is not limited to:</p>
                    <ul>
                        <li>Uploading malware or harmful code.</li>
                        <li>Processing illegal, obscene, or copyright-infringing content.</li>
                        <li>Using automated scraping or DDoS attacks to overload our servers.</li>
                    </ul>
                </section>

                <section id="responsibility">
                    <h2>03. Your Content & Responsibility</h2>
                    <p>You own your files. We do not claim ownership of your documents. However, by uploading, you grant us a <strong>temporary license</strong> to process them solely to provide the service.</p>
                    <blockquote>
                        <strong>Notice:</strong> Your files are automatically deleted after 60 minutes. We cannot recover them once deleted.
                    </blockquote>
                </section>

                <section id="warranties">
                    <h2>04. No Warranties</h2>
                    <p>The service is provided “as is.” We do not guarantee that the service will be uninterrupted, error-free, or that the processed files will meet specific expectations.</p>
                </section>

                <section id="liability">
                    <h2>05. Limitation of Liability</h2>
                    <p>PDFEase and its operators are not liable for any indirect or incidental damages—including loss of data—arising from your use of the service.</p>
                </section>

                <section id="contact" class="pt-12">
                    <div class="bg-slate-900 text-white p-10 md:p-16 rounded-[3rem] shadow-2xl shadow-slate-200 text-center">
                        <h2 class="text-white mt-0 mb-4">Questions?</h2>
                        <p class="text-slate-400 font-medium mb-8">If you have concerns about these terms or legal compliance, our team is here to help.</p>
                        <a href="mailto:support@pdfease.io" class="inline-block bg-white text-slate-900 px-10 py-4 rounded-2xl font-black uppercase tracking-widest hover:bg-slate-200 transition-colors">
                            Email Support
                        </a>
                    </div>
                </section>

                <p class="mt-20 text-slate-400 text-sm italic font-medium">
                    Thank you for choosing PDFEase. We’re committed to making PDF tasks simple and free—responsibly and respectfully.
                </p>
            </div>
        </div>
    </main>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>

    <script>
        // Progress bar logic
        window.onscroll = function() {
            var winScroll = document.body.scrollTop || document.documentElement.scrollTop;
            var height = document.documentElement.scrollHeight - document.documentElement.clientHeight;
            var scrolled = (winScroll / height) * 100;
            document.getElementById("progress-bar").style.width = scrolled + "%";
        };
    </script>
</body>
</html>