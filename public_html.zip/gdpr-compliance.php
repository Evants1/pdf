<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "GDPR Compliance | PDFEase - Free Online PDF Tools";
$meta_description = "PDFEase.io is designed with GDPR compliance in mind. We minimize data collection, automatically delete files, and respect your rights over personal data.";
$meta_keywords = "pdfease gdpr, gdpr compliance, eu data protection, pdf gdpr, privacy rights";
$canonical_url = "https://pdfease.org/gdpr-compliance";
$og_image = "https://pdfease.org/images/PDF_Ease_logo-en.webp";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdn.tailwindcss.com"></script>

<body class="bg-slate-50 font-sans text-gray-800 flex flex-col min-h-screen antialiased">

<?php include 'static/nav.php'; ?>

    <section class="bg-white border-b border-slate-200 pt-16 pb-12 lg:pt-24 lg:pb-20">
        <div class="max-w-4xl mx-auto px-6 text-center">
            <div class="inline-flex items-center px-3 py-1 rounded-full bg-blue-50 text-blue-600 text-sm font-bold mb-6">
                EU Data Protection Standard
            </div>
            <h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tight mb-6">
                GDPR <span class="text-blue-600">Compliance</span>
            </h1>
            <p class="text-lg text-slate-500 max-w-2xl mx-auto leading-relaxed">
                Last updated: <span class="font-semibold text-slate-700">December 14, 2025</span>. <br>
                We’ve built PDFEase to respect your privacy by default, ensuring your data stays yours.
            </p>
        </div>
    </section>

    <div class="max-w-5xl mx-auto px-6 -mt-10 mb-16">
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div class="w-10 h-10 bg-green-100 text-green-600 rounded-lg flex items-center justify-center mb-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1-1v3M4 7h16"></path></svg>
                </div>
                <h3 class="font-bold text-slate-900">Auto-Deletion</h3>
                <p class="text-sm text-slate-500 mt-2">All files are permanently deleted within 60 minutes.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div class="w-10 h-10 bg-blue-100 text-blue-600 rounded-lg flex items-center justify-center mb-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                </div>
                <h3 class="font-bold text-slate-900">HTTPS Encryption</h3>
                <p class="text-sm text-slate-500 mt-2">Secure end-to-end encryption for every transfer.</p>
            </div>
            <div class="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <div class="w-10 h-10 bg-purple-100 text-purple-600 rounded-lg flex items-center justify-center mb-4">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                </div>
                <h3 class="font-bold text-slate-900">No Accounts</h3>
                <p class="text-sm text-slate-500 mt-2">Use all tools anonymously with no registration.</p>
            </div>
        </div>
    </div>

    <main class="max-w-4xl mx-auto px-6 pb-24">
        <article class="prose prose-slate prose-lg max-w-none">
            <p class="lead text-xl text-slate-600">
                At <strong><a href="/" class="text-blue-600 hover:underline">pdfease.io</a></strong>, we take data protection seriously. The General Data Protection Regulation (GDPR) sets high standards for handling personal data—standards we respect from the ground up.
            </p>

            <h2 class="text-3xl font-bold text-slate-900 mt-12 mb-6">Our Approach to GDPR</h2>
            <p>PDFEase.io is a privacy-first PDF utility. We minimize data collection to the absolute technical minimum required to process your files:</p>
            
            <div class="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6">
                <div class="flex items-start gap-4">
                    <div class="mt-1 text-blue-600 font-bold">01</div>
                    <div>
                        <strong class="text-slate-900">Data Minimization</strong>
                        <p class="text-slate-600 mt-1">We do not require accounts, logins, or email addresses. Most users remain 100% anonymous.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4 border-t border-slate-100 pt-6">
                    <div class="mt-1 text-blue-600 font-bold">02</div>
                    <div>
                        <strong class="text-slate-900">No Unnecessary Tracking</strong>
                        <p class="text-slate-600 mt-1">We avoid cookies for advertising or invasive cross-site analytics.</p>
                    </div>
                </div>
                <div class="flex items-start gap-4 border-t border-slate-100 pt-6">
                    <div class="mt-1 text-blue-600 font-bold">03</div>
                    <div>
                        <strong class="text-slate-900">Temporary Processing</strong>
                        <p class="text-slate-600 mt-1">Uploaded files are processed in isolated memory sessions and purged within 1 hour.</p>
                    </div>
                </div>
            </div>

            

            <h2 class="text-3xl font-bold text-slate-900 mt-16 mb-6">Key Principles We Follow</h2>
            <ul class="grid grid-cols-1 md:grid-cols-2 gap-4 list-none p-0">
                <li class="bg-slate-100 p-5 rounded-xl border border-slate-200">
                    <strong class="block text-slate-900 mb-1">Lawful Processing</strong>
                    Processing only occurs to deliver the specific service you request.
                </li>
                <li class="bg-slate-100 p-5 rounded-xl border border-slate-200">
                    <strong class="block text-slate-900 mb-1">Security & Integrity</strong>
                    All files are transferred via HTTPS and never accessed by human eyes.
                </li>
                <li class="bg-slate-100 p-5 rounded-xl border border-slate-200">
                    <strong class="block text-slate-900 mb-1">Storage Limitation</strong>
                    Data is never retained longer than technically necessary.
                </li>
                <li class="bg-slate-100 p-5 rounded-xl border border-slate-200">
                    <strong class="block text-slate-900 mb-1">Zero Data Selling</strong>
                    We never sell or share your information with marketing third-parties.
                </li>
            </ul>

            <h2 class="text-3xl font-bold text-slate-900 mt-16 mb-6">Your GDPR Rights</h2>
            <p>Under the GDPR, you have the following rights regarding your personal data:</p>
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-x-12 gap-y-4 mb-8">
                <div class="flex items-center gap-2">
                    <span class="text-blue-500">✔</span> <span>Right to Access</span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-blue-500">✔</span> <span>Right to Erasure</span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-blue-500">✔</span> <span>Right to Rectification</span>
                </div>
                <div class="flex items-center gap-2">
                    <span class="text-blue-500">✔</span> <span>Right to Portability</span>
                </div>
            </div>
            
            <div class="bg-blue-600 rounded-3xl p-8 text-white">
                <h3 class="text-white text-xl font-bold mb-4">Exercise Your Rights</h3>
                <p class="text-blue-100 mb-6">To exercise these rights or ask questions, email our data team. We respond to all inquiries within 30 days.</p>
                <a href="mailto:support@pdfease.io" class="inline-block bg-white text-blue-600 px-6 py-3 rounded-xl font-bold hover:bg-blue-50 transition">
                    Email Support
                </a>
            </div>

            <div class="mt-16 border-t border-slate-200 pt-12 text-sm text-slate-500 leading-relaxed">
                <h3 class="text-slate-900 font-bold mb-2">Data Controller</h3>
                <p>PDFEase.io acts as the data controller for the limited processing we perform. For further details on third-party compliant hosting providers, please refer to our <a href="/privacy-policy" class="underline">Privacy Policy</a>.</p>
            </div>
        </article>
    </main>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>

</body>
</html>