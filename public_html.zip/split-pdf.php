<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Split PDF Online Free | Extract Pages from PDF | PDFEase";
$meta_description = "Free online PDF splitter to extract specific pages or separate every page into individual files. Fast, secure, no registration—download as ZIP.";
$meta_keywords = "split pdf online free, extract pdf pages, separate pdf pages, pdf splitter, divide pdf file, free pdf extractor";
$canonical_url = "https://pdfease.org/split-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Split PDF",
  "description": "Free online tool to split PDF files—extract page ranges or separate every page into individual documents.",
  "url": "https://pdfease.org/split-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Split a PDF Online for Free",
  "description": "Step-by-step guide to splitting or extracting pages from a PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file by clicking or dragging it into the upload area.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Choose 'Every page separate' or 'Extract range' and enter page numbers if needed.",
      "name": "Select Split Mode"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Split PDF Now' and download the resulting ZIP file.",
      "name": "Download Split PDFs"
    }
  ]
}
</script>
<body class="bg-gray-50 font-sans text-gray-800 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-gray-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-gray-900 mb-6 tracking-tight">
                    Split <span class="text-blue-600">PDF Files</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-gray-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Extract specific pages or separate every page into individual PDFs. Fast, secure, and completely free—no signup required.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-gray-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-xl cursor-pointer" aria-label="Upload PDF to split">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <div id="upload-prompt" class="space-y-6">
                    <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758L5 19m0-14l4.121 4.121"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-gray-900 tracking-tight">Upload PDF to Split</span>
                        <p class="text-gray-500 font-medium text-base">Drag & drop supported • Up to 200MB • End-to-end encrypted</p>
                    </div>
                </div>

                <div id="convert-area" class="hidden space-y-8">
                    <div class="inline-flex items-center gap-4 bg-white px-8 py-5 rounded-3xl shadow-lg border border-gray-100">
                        <div class="text-4xl">📄</div>
                        <div class="text-left">
                            <p id="filename-display" class="text-lg font-bold text-gray-900">document.pdf</p>
                            <p id="filesize-display" class="text-sm text-gray-500">0 MB</p>
                        </div>
                    </div>

                    <div class="max-w-md mx-auto space-y-4">
                        <label for="split-mode" class="block text-left text-sm font-bold text-gray-700 uppercase tracking-wide">Split Mode</label>
                        <select id="split-mode" class="w-full p-4 rounded-2xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none text-base">
                            <option value="all">Split every page into separate PDF</option>
                            <option value="range">Extract specific page range</option>
                        </select>
                        <input type="text" id="page-range" placeholder="e.g. 1-5, 8, 10-12" class="hidden w-full p-4 rounded-2xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none mt-2" aria-label="Page range">
                    </div>

                    <button type="button" id="trigger-convert" class="px-16 py-6 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xl rounded-[2rem] shadow-2xl transition-all active:scale-95">
                        Split PDF Now
                    </button>

                    <button type="button" id="reset-upload" class="text-sm text-gray-500 hover:text-gray-900 font-semibold uppercase tracking-wide">
                        Change File
                    </button>
                </div>

                <div id="processing-area" class="hidden py-32" aria-live="polite">
                    <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-3xl font-extrabold text-gray-900">Processing Your PDF...</h3>
                    <p class="text-gray-600 mt-4 text-lg">Splitting pages—this may take a few seconds.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="text-8xl mb-8">📦</div>
                    <h3 class="text-5xl font-extrabold text-gray-900 mb-4">PDF Split Complete!</h3>
                    <p class="text-gray-600 mb-12 text-lg max-w-md mx-auto">Your pages have been successfully separated and packed into a ZIP file.</p>
                    <a id="download-link" href="#" download class="inline-block px-20 py-7 bg-green-600 hover:bg-green-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all hover:-translate-y-1">
                        Download ZIP File
                    </a>
                    <div class="mt-8">
                        <button type="button" onclick="location.reload()" class="text-gray-600 hover:text-gray-900 font-semibold uppercase tracking-wide text-sm">
                            Split Another PDF
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-gray-900 mb-6 tracking-tight">
                Why Choose PDFEase to <span class="text-blue-600">Split PDFs</span>?
            </h2>
            <p class="text-xl text-gray-600 font-medium max-w-3xl mx-auto">Professional-grade splitting with privacy and ease—no watermarks or limits.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Two Powerful Modes</h3>
                <p class="text-gray-600 leading-relaxed">Split every page separately or extract custom ranges with precision.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-gray-600 leading-relaxed">256-bit encryption. Files automatically deleted after processing.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free</h3>
                <p class="text-gray-600 leading-relaxed">Unlimited splits, no signup, no hidden fees.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100">
                    <h3 class="text-2xl font-bold mb-4">Split Every Page</h3>
                    <p class="text-gray-600 leading-relaxed">Ideal for scanned documents, invoices, or forms—each page becomes its own clean PDF file.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-gray-100">
                    <h3 class="text-2xl font-bold mb-4">Extract Custom Ranges</h3>
                    <p class="text-gray-600 leading-relaxed">Enter page numbers like “1-5, 8, 10-15” to pull only the sections you need.</p>
                </div>
            </div>
            <div class="bg-gray-100 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-gray-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-gray-700">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> <strong>Legal:</strong> Separate exhibits or appendices</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> <strong>Education:</strong> Extract chapters from textbooks</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> <strong>Business:</strong> Divide reports for different departments</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> <strong>Email:</strong> Reduce file size by sending only needed pages</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-gray-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-gray-100">
                    <h4 class="text-xl font-bold text-gray-900 mb-3">Is my data secure?</h4>
                    <p class="text-gray-600">Yes—files are transferred via 256-bit SSL and automatically deleted from our servers within 1 hour.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-gray-100">
                    <h4 class="text-xl font-bold text-gray-900 mb-3">What file sizes are supported?</h4>
                    <p class="text-gray-600">Up to 200MB. Larger files can be compressed first using our free compressor tool.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-gray-100">
                    <h4 class="text-xl font-bold text-gray-900 mb-3">Does splitting affect quality?</h4>
                    <p class="text-gray-600">No—original quality, fonts, images, and hyperlinks are fully preserved.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-gray-100">
                    <h4 class="text-xl font-bold text-gray-900 mb-3">Can I use this on mobile?</h4>
                    <p class="text-gray-600">Fully responsive—works perfectly on phones and tablets.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Split Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Extract pages in seconds with the most reliable online tool.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-gray-100 transition-all hover:-translate-y-1">
                Split PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const splitMode = document.getElementById('split-mode');
        const pageRangeInput = document.getElementById('page-range');

        let selectedFile = null;

        // Show/hide page range input
        splitMode.addEventListener('change', () => {
            if (splitMode.value === 'range') {
                pageRangeInput.classList.remove('hidden');
            } else {
                pageRangeInput.classList.add('hidden');
            }
        });

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });

        fileInput.addEventListener('change', (e) => {
            const files = e.target.files;
            if (files.length > 0 && files[0].type === 'application/pdf') {
                selectedFile = files[0];
                document.getElementById('filename-display').textContent = selectedFile.name;
                document.getElementById('filesize-display').textContent = (selectedFile.size / 1024 / 1024).toFixed(1) + ' MB';
                uploadPrompt.classList.add('hidden');
                convertArea.classList.remove('hidden');
            } else {
                alert('Please select a valid PDF file.');
            }
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            let range = '';
            if (splitMode.value === 'range') {
                range = pageRangeInput.value.trim();
                if (!range) {
                    alert('Please enter a page range (e.g., 1-5).');
                    return;
                }
            }

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('mode', splitMode.value);
            if (range) formData.append('range', range);

            fetch('api/split.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Split failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during splitting. Please try again.');
                    location.reload();
                });
        });

        document.getElementById('reset-upload').addEventListener('click', () => location.reload());
    </script>
</body>
</html>