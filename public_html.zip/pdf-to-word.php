<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert PDF to Word Online Free | PDF to DOCX Converter | PDFEase";
$meta_description = "Free online PDF to Word converter. Turn PDFs into fully editable DOCX files with preserved formatting, tables, and images. No signup, secure.";
$meta_keywords = "pdf to word online free, convert pdf to docx, pdf to word converter, editable pdf, free pdf to word";
$canonical_url = "https://pdfease.org/pdf-to-word";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase PDF to Word Converter",
  "description": "Free online tool to convert PDF documents to editable Microsoft Word (DOCX) files with high accuracy.",
  "url": "https://pdfease.org/pdf-to-word",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert PDF to Word Online for Free",
  "description": "Step-by-step guide to converting PDF to editable Word using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Convert to Word' to process.",
      "name": "Start Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your editable DOCX file.",
      "name": "Download Word Document"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-blue-600">PDF to Word</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Turn static PDFs into fully editable DOCX files. Preserve formatting, tables, images, and text—no registration required.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-blue-500 hover:bg-blue-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to convert">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf,application/pdf" aria-label="Select PDF file">

                    <div id="upload-prompt" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-blue-600 bg-blue-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-blue-600 hover:bg-blue-500 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose PDF File
                            </button>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • Supports scanned PDFs</p>
                        </div>
                    </div>

                    <div id="convert-area" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📄</div>
                            <div class="text-left">
                                <p id="filename-display" class="text-xl font-bold text-slate-900">document.pdf</p>
                                <p id="filesize-display" class="text-sm text-slate-500">0 MB</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-convert" class="px-20 py-7 bg-blue-600 hover:bg-blue-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Convert to Word
                        </button>

                        <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Choose Different File
                        </button>
                    </div>

                    <div id="processing-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-blue-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Converting to Word...</h3>
                        <p class="text-slate-600 text-lg font-medium">Preserving layout, tables, and images with OCR for scanned PDFs.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">Conversion Complete!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your PDF is now a fully editable Word document.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-blue-600 transition-all hover:-translate-y-1">
                                Download DOCX
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Convert Another PDF
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert <span class="text-blue-600">PDF to Word</span> with PDFEase?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Accurate, secure, and completely free—no limits or watermarks.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">High Accuracy</h3>
                <p class="text-slate-600 leading-relaxed">Preserves fonts, tables, images, and layout—even complex documents.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Scanned PDFs Supported</h3>
                <p class="text-slate-600 leading-relaxed">Built-in OCR extracts editable text from image-based PDFs.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-blue-100 text-blue-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Encrypted processing. Files deleted automatically.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Fully Editable Output</h3>
                    <p class="text-slate-600 leading-relaxed">Native DOCX files compatible with Microsoft Word, Google Docs, and LibreOffice.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">No Installation Needed</h3>
                    <p class="text-slate-600 leading-relaxed">Works in any browser on desktop or mobile—no software download.</p>
                </div>
            </div>

            <div class="bg-blue-50 border-2 border-blue-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-blue-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-blue-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Editing contracts or reports</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Extracting text from scanned documents</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Reusing content from fixed-layout PDFs</li>
                    <li class="flex items-start gap-3"><span class="text-blue-600 mt-1">•</span> Collaborating on shared documents</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is formatting preserved?</h4>
                    <p class="text-slate-600">Yes—advanced conversion maintains layout, tables, images, and fonts as closely as possible.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it work with scanned PDFs?</h4>
                    <p class="text-slate-600">Yes—built-in OCR makes text from images editable.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB—handles large and complex documents.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are files secure?</h4>
                    <p class="text-slate-600">Yes—encrypted transfer and automatic deletion after conversion.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-blue-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Edit Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Convert to fully editable Word in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-blue-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert PDF to Word Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const filenameDisplay = document.getElementById('filename-display');
        const filesizeDisplay = document.getElementById('filesize-display');

        let selectedFile = null;

        function handleFiles(files) {
            if (files.length === 0) return;
            const file = files[0];
            if (file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }

            selectedFile = file;
            filenameDisplay.textContent = file.name;
            filesizeDisplay.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        fileInput.addEventListener('change', e => handleFiles(e.target.files));

        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
        });
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('border-blue-600', 'bg-blue-50/60');
            handleFiles(e.dataTransfer.files);
        });

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);

            fetch('api/convert.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || selectedFile.name.replace(/\.pdf$/i, '.docx');
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>