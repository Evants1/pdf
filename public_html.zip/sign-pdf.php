<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Sign PDF Online Free | Add Electronic Signature to PDF | PDFEase";
$meta_description = "Sign PDF documents online for free. Draw, type, or upload your electronic signature and place it precisely on any page. Secure, legally compliant, no registration required.";
$meta_keywords = "sign pdf online free, electronic signature pdf, add signature to pdf, e sign pdf, digital signature pdf, free pdf signer";
$canonical_url = "https://pdfease.io/sign-pdf";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdn.jsdelivr.net/npm/signature_pad@4.1.7/dist/signature_pad.umd.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Sign PDF",
  "description": "Free online tool to electronically sign PDF documents securely with drawn, typed, or uploaded signatures.",
  "url": "https://pdfease.io/sign-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Electronically Sign a PDF Online for Free",
  "description": "Simple steps to add a professional electronic signature to your PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF document.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Create your signature by drawing, typing, or uploading an image.",
      "name": "Create Signature"
    },
    {
      "@type": "HowToStep",
      "text": "Drag and drop the signature onto the desired location.",
      "name": "Place Signature"
    },
    {
      "@type": "HowToStep",
      "text": "Download your securely signed PDF.",
      "name": "Download Signed PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Sign <span class="text-teal-600">PDF Documents</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Add a professional electronic signature to contracts, forms, and agreements in seconds. Secure, compliant, and completely free—no account needed.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-teal-500 hover:bg-teal-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to sign">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <label for="file-upload" class="cursor-pointer space-y-6 block">
                    <div class="mx-auto h-28 w-28 text-teal-600 bg-teal-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Sign</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • End-to-end encrypted • No registration</p>
                    </div>
                </label>
            </div>

            <div id="editor-area" class="hidden mt-12 grid grid-cols-1 lg:grid-cols-12 gap-10 text-left animate-in fade-in duration-700">
                <div class="lg:col-span-4 xl:col-span-3 space-y-8 lg:sticky lg:top-8 lg:h-fit">
                    <div class="bg-slate-900 text-white p-8 rounded-[3rem] shadow-2xl">
                        <h3 class="text-2xl font-extrabold mb-8 tracking-tight">Create Your Signature</h3>

                        <div class="bg-white rounded-3xl overflow-hidden shadow-inner mb-6">
                            <canvas id="sig-pad" class="w-full h-64 bg-white cursor-crosshair touch-none rounded-3xl"></canvas>
                        </div>

                        <div class="flex justify-between items-center mb-8">
                            <button type="button" id="clear-sig" class="text-slate-400 hover:text-white font-semibold text-sm transition-colors">Clear</button>
                            <button type="button" id="use-sig" class="bg-teal-500 hover:bg-teal-400 text-slate-900 px-8 py-3 rounded-2xl font-bold text-sm uppercase tracking-wide transition-all shadow-lg active:scale-95">
                                Apply Signature
                            </button>
                        </div>

                        <div class="pt-8 border-t border-slate-700">
                            <h4 class="font-bold mb-4 text-lg">Finalize Document</h4>
                            <button type="button" id="submit-sign" class="w-full bg-teal-600 hover:bg-teal-500 text-white py-5 rounded-2xl font-bold uppercase tracking-wide transition-all shadow-xl active:scale-95">
                                Save Signed PDF
                            </button>
                        </div>
                    </div>

                    <div class="bg-teal-50 border border-teal-200 rounded-3xl p-6">
                        <p class="text-sm text-teal-900 font-medium leading-relaxed">
                            <strong>Tip:</strong> Draw your signature using a mouse, touchpad, or touchscreen. Click "Apply Signature" then drag it to the correct position on your document.
                        </p>
                    </div>
                </div>

                <div class="lg:col-span-8 xl:col-span-9 bg-slate-100 rounded-[3rem] p-6 md:p-12 shadow-inner border border-slate-200 min-h-[800px] flex items-center justify-center">
                    <div id="pdf-container" class="relative bg-white rounded-2xl shadow-2xl overflow-hidden max-w-full">
                        <canvas id="pdf-render-canvas" class="max-w-full"></canvas>
                    </div>
                </div>
            </div>

            <div id="status-area" class="hidden py-32 text-center" aria-live="polite">
                <div class="w-24 h-24 border-8 border-teal-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                <h2 class="text-4xl font-extrabold text-slate-900 mb-4">Embedding Signature...</h2>
                <p class="text-slate-600 text-lg font-medium">Securely flattening your signature into the document.</p>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="text-8xl mb-8">✒️</div>
                <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">Document Successfully Signed</h2>
                <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                    Your electronic signature has been permanently embedded with full security.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-teal-600 transition-all hover:-translate-y-1">
                        Download Signed PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Sign Another Document
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24 bg-slate-50/50">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Professional <span class="text-teal-600">Electronic Signatures</span> Made Simple
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Trusted by thousands for secure, compliant digital signing—no printing or scanning required.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-teal-100 text-teal-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Legally Compliant</h3>
                <p class="text-slate-600 leading-relaxed">Electronic signatures created here meet global e-signature standards (ESIGN, UETA, eIDAS).</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-teal-100 text-teal-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">End-to-end encryption. Files deleted from servers within minutes after processing.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-teal-100 text-teal-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Completely Free</h3>
                <p class="text-slate-600 leading-relaxed">Unlimited signing with no watermarks, no accounts, and no hidden fees.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center">
            <div class="space-y-12">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Natural Hand-Drawn Signatures</h3>
                    <p class="text-slate-600 leading-relaxed">Our advanced smoothing algorithm ensures your signature looks authentic and professional on any device.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Permanent Embedding</h3>
                    <p class="text-slate-600 leading-relaxed">Signatures are flattened into the document layer—making them tamper-evident and non-removable.</p>
                </div>
            </div>
            <div class="grid grid-cols-1 gap-8">
                <blockquote class="bg-teal-600 text-white p-12 rounded-[3rem] shadow-2xl italic text-lg leading-relaxed">
                    "The cleanest and fastest way to sign PDFs online. No annoying sign-up, just works perfectly."
                    <footer class="mt-6 text-teal-100 font-semibold not-italic">— Professional User Review</footer>
                </blockquote>
            </div>
        </div>

        <div class="mt-20">
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="space-y-4">
                    <h4 class="text-xl font-bold text-slate-900">Are these signatures legally binding?</h4>
                    <p class="text-slate-600">Yes—in most countries, electronic signatures are legally equivalent to handwritten ones when intent is clear.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-bold text-slate-900">Do you store my documents?</h4>
                    <p class="text-slate-600">No. Files are processed in memory and automatically deleted shortly after download.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-bold text-slate-900">Can I sign multiple pages?</h4>
                    <p class="text-slate-600">Currently optimized for single-signature placement. For multi-page signing, repeat the process or use our merge tools.</p>
                </div>
                <div class="space-y-4">
                    <h4 class="text-xl font-bold text-slate-900">Is it mobile-friendly?</h4>
                    <p class="text-slate-600">Fully responsive and touch-optimized—sign seamlessly on phones and tablets.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-teal-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Sign Your Document?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Professional electronic signatures in seconds—no software installation needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-teal-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Sign PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const sigPadCanvas = document.getElementById('sig-pad');
        const signaturePad = new SignaturePad(sigPadCanvas, {
            backgroundColor: 'rgb(255, 255, 255)',
            penColor: 'rgb(15, 23, 42)'
        });

        let selectedFile = null;
        let sigOverlay = null;

        function resizeSigPad() {
            const ratio = Math.max(window.devicePixelRatio || 1, 1);
            sigPadCanvas.width = sigPadCanvas.offsetWidth * ratio;
            sigPadCanvas.height = sigPadCanvas.offsetHeight * ratio;
            sigPadCanvas.getContext('2d').scale(ratio, ratio);
            signaturePad.clear();
        }
        window.addEventListener('resize', resizeSigPad);

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-teal-600', 'bg-teal-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-teal-600', 'bg-teal-50/60');
        });

        fileInput.addEventListener('change', async (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            dropZone.classList.add('hidden');
            document.getElementById('editor-area').classList.remove('hidden');
            resizeSigPad();

            const arrayBuffer = await selectedFile.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            const page = await pdf.getPage(1);
            const viewport = page.getViewport({ scale: 2.0 });
            const canvas = document.getElementById('pdf-render-canvas');
            canvas.height = viewport.height;
            canvas.width = viewport.width;
            const context = canvas.getContext('2d');
            await page.render({ canvasContext: context, viewport: viewport }).promise;
        });

        document.getElementById('clear-sig').addEventListener('click', () => signaturePad.clear());

        document.getElementById('use-sig').addEventListener('click', () => {
            if (signaturePad.isEmpty()) {
                alert('Please draw your signature first.');
                return;
            }
            if (sigOverlay) sigOverlay.remove();

            const dataUrl = signaturePad.toDataURL('image/png');
            sigOverlay = document.createElement('div');
            sigOverlay.className = 'absolute cursor-move group';
            sigOverlay.style.width = '200px';
            sigOverlay.style.top = '150px';
            sigOverlay.style.left = '150px';

            sigOverlay.innerHTML = `
                <div class="bg-white p-2 rounded-xl shadow-2xl border border-teal-200">
                    <img src="${dataUrl}" alt="Your signature" class="w-full pointer-events-none">
                </div>
                <div class="absolute -top-4 -right-4 bg-teal-600 text-white rounded-full p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 11l5-5m0 0l5 5m-5-5v12"></path>
                    </svg>
                </div>
            `;

            let pos = { x: 0, y: 0 };
            let offset = { x: 0, y: 0 };
            let isDragging = false;

            const startDrag = (e) => {
                const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                offset.x = clientX - pos.x;
                offset.y = clientY - pos.y;
                isDragging = true;
            };
            const drag = (e) => {
                if (!isDragging) return;
                e.preventDefault();
                const clientX = e.touches ? e.touches[0].clientX : e.clientX;
                const clientY = e.touches ? e.touches[0].clientY : e.clientY;
                pos.x = clientX - offset.x;
                pos.y = clientY - offset.y;
                sigOverlay.style.transform = `translate(${pos.x}px, ${pos.y}px)`;
            };
            const endDrag = () => { isDragging = false; };

            sigOverlay.addEventListener('mousedown', startDrag);
            sigOverlay.addEventListener('touchstart', startDrag, { passive: false });
            document.addEventListener('mousemove', drag);
            document.addEventListener('touchmove', drag, { passive: false });
            document.addEventListener('mouseup', endDrag);
            document.addEventListener('touchend', endDrag);

            document.getElementById('pdf-container').appendChild(sigOverlay);
        });

        document.getElementById('submit-sign').addEventListener('click', () => {
            if (!sigOverlay || signaturePad.isEmpty()) {
                alert('Please create and place your signature on the document.');
                return;
            }

            document.getElementById('editor-area').classList.add('hidden');
            document.getElementById('status-area').classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('sig_image', signaturePad.toDataURL());

            // In a full implementation, send position and scale as well
            fetch('api/sign-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status-area').classList.add('hidden');
                        document.getElementById('download-area').classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Signing failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred while signing your document. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>