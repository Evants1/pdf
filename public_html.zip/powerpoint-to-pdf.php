<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert PowerPoint to PDF Online Free | PPTX to PDF | PDFEase";
$meta_description = "Free online PowerPoint to PDF converter. Turn PPTX and PPT presentations into high-quality PDFs with perfect slide rendering. No signup, secure.";
$meta_keywords = "powerpoint to pdf online free, convert pptx to pdf, ppt to pdf, free powerpoint converter, slides to pdf";
$canonical_url = "https://pdfease.org/powerpoint-to-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase PowerPoint to PDF Converter",
  "description": "Free online tool to convert PowerPoint (PPTX/PPT) presentations to professional PDF documents.",
  "url": "https://pdfease.org/powerpoint-to-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert PowerPoint to PDF Online for Free",
  "description": "Step-by-step guide to converting PPTX/PPT files to PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PowerPoint presentation (.pptx or .ppt).",
      "name": "Upload Presentation"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Convert to PDF' to process.",
      "name": "Start Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your high-quality PDF.",
      "name": "Download PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-red-600">PowerPoint to PDF</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Transform PPTX and PPT presentations into professional PDFs. Perfect slide rendering, fonts, and layout preserved.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-red-500 hover:bg-red-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PowerPoint file">
                    <input type="file" id="file-upload" class="hidden" accept=".ppt,.pptx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation" aria-label="Select PowerPoint file">

                    <div id="upload-prompt" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-red-600 bg-red-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-red-600 hover:bg-red-500 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose PowerPoint File
                            </button>
                            <p class="text-slate-500 font-medium text-base">Drag & drop .pptx or .ppt files • Up to 200MB • Secure</p>
                        </div>
                    </div>

                    <div id="convert-area" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📊</div>
                            <div class="text-left">
                                <p id="filename-display" class="text-xl font-bold text-slate-900">presentation.pptx</p>
                                <p id="filesize-display" class="text-sm text-slate-500">0 MB</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-convert" class="px-20 py-7 bg-red-600 hover:bg-red-500 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Convert to PDF
                        </button>

                        <button type="button" id="reset-upload" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Choose Different File
                        </button>
                    </div>

                    <div id="processing-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Rendering Slides...</h3>
                        <p class="text-slate-600 text-lg font-medium">Preserving layout, fonts, images, and animations.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Created Successfully!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your PowerPoint presentation is now a professional PDF document.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-red-600 transition-all hover:-translate-y-1">
                                Download PDF
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Convert Another Presentation
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert <span class="text-red-600">PowerPoint to PDF</span> with PDFEase?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">High-fidelity conversion with complete privacy and ease.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Perfect Fidelity</h3>
                <p class="text-slate-600 leading-relaxed">Slides, fonts, images, charts, and layout preserved exactly.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">End-to-end encryption. Files deleted after processing.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free</h3>
                <p class="text-slate-600 leading-relaxed">Unlimited conversions, no watermarks, no signup.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Full Feature Support</h3>
                    <ul class="space-y-3 text-slate-600">
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> All slide elements & transitions (static)</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> Embedded fonts & high-res images</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> Hyperlinks and speaker notes</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> Both .pptx and legacy .ppt</li>
                    </ul>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Universal Sharing</h3>
                    <p class="text-slate-600 leading-relaxed">PDFs ensure your presentation looks identical on any device—perfect for clients and printing.</p>
                </div>
            </div>

            <div class="bg-red-50 border-2 border-red-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-red-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-red-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Sharing presentations professionally</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Creating print handouts</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Archiving slide decks securely</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Emailing large decks reliably</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is layout perfectly preserved?</h4>
                    <p class="text-slate-600">Yes—high-fidelity rendering ensures slides look exactly as designed.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What about animations?</h4>
                    <p class="text-slate-600">Animations are flattened (static per slide)—standard for PDF format.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB—handles large presentations with images/videos.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Are files private?</h4>
                    <p class="text-slate-600">Yes—encrypted transfer, auto-deleted after conversion.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-red-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Convert Your Presentation?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Professional PDFs from PowerPoint in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-red-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert PowerPoint to PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const processingArea = document.getElementById('processing-area');
        const downloadArea = document.getElementById('download-area');
        const filenameDisplay = document.getElementById('filename-display');
        const filesizeDisplay = document.getElementById('filesize-display');

        let selectedFile = null;

        function handleFiles(files) {
            if (files.length === 0) return;
            const file = files[0];
            const validTypes = [
                'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                'application/vnd.ms-powerpoint'
            ];
            const validExt = ['.ppt', '.pptx'];
            const isValid = validTypes.includes(file.type) || validExt.some(ext => file.name.toLowerCase().endsWith(ext));

            if (!isValid) {
                alert('Please select a valid PowerPoint file (.ppt or .pptx).');
                return;
            }

            selectedFile = file;
            filenameDisplay.textContent = file.name;
            filesizeDisplay.textContent = (file.size / 1024 / 1024).toFixed(1) + ' MB';
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        fileInput.addEventListener('change', (e) => handleFiles(e.target.files));

        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-red-600', 'bg-red-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-red-600', 'bg-red-50/60');
        });
        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-red-600', 'bg-red-50/60');
            handleFiles(e.dataTransfer.files);
        });

        document.getElementById('reset-upload').addEventListener('click', () => {
            selectedFile = null;
            fileInput.value = '';
            convertArea.classList.add('hidden');
            uploadPrompt.classList.remove('hidden');
        });

        document.getElementById('trigger-convert').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            processingArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pptx_file', selectedFile);

            fetch('api/convert-pptx-to-pdf.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        processingArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = data.file_name || selectedFile.name.replace(/\.(ppt|pptx)$/i, '.pdf');
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>