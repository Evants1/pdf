<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Protect PDF Online Free | Add Password to PDF | PDFEase";
$meta_description = "Free online tool to password-protect PDFs with AES-256 encryption. Secure sensitive documents instantly—no signup, no watermarks.";
$meta_keywords = "protect pdf online free, add password to pdf, encrypt pdf with password, lock pdf file, pdf password protection free";
$canonical_url = "https://pdfease.io/protect-pdf";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Protect PDF",
  "description": "Free online tool to add strong password protection to PDF files using AES-256 encryption.",
  "url": "https://pdfease.io/protect-pdf",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Password Protect a PDF Online for Free",
  "description": "Step-by-step guide to adding password protection to PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Enter a strong password (our meter helps ensure security).",
      "name": "Set Password"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Lock Document' and download the encrypted PDF.",
      "name": "Download Protected PDF"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Protect <span class="text-red-600">PDF Files</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Add military-grade AES-256 password protection to secure sensitive documents. Fast, private, and completely free.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-red-500 hover:bg-red-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to protect">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                    <label for="file-upload" class="cursor-pointer space-y-6 block">
                        <div class="mx-auto h-28 w-28 text-red-600 bg-red-50 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:-rotate-3 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight">Upload PDF to Protect</span>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • AES-256 encryption</p>
                        </div>
                    </label>
                </div>

                <div id="editor-area" class="hidden mt-12 max-w-2xl mx-auto">
                    <div class="bg-slate-900 text-white p-10 rounded-[3rem] shadow-2xl">
                        <div class="flex items-center gap-6 mb-8">
                            <div class="text-5xl">🔒</div>
                            <div class="text-left">
                                <p id="selected-filename" class="text-2xl font-bold">document.pdf</p>
                                <p class="text-sm text-slate-400 mt-1">Ready for password protection</p>
                            </div>
                        </div>

                        <div class="space-y-4">
                            <label for="pdf-pass" class="block text-sm font-bold text-red-400 uppercase tracking-wide">Enter Strong Password</label>
                            <input type="password" id="pdf-pass" placeholder="Minimum 8 characters recommended" class="w-full bg-slate-800 border-2 border-slate-700 rounded-2xl px-6 py-5 text-white focus:outline-none focus:border-red-500 transition-all text-lg">

                            <div>
                                <div class="flex justify-between text-xs font-bold uppercase mb-2">
                                    <span class="text-slate-400">Password Strength</span>
                                    <span id="strength-text" class="text-red-500">Weak</span>
                                </div>
                                <div class="h-3 bg-slate-800 rounded-full overflow-hidden">
                                    <div id="strength-bar" class="h-full w-0 bg-red-500 transition-all duration-500"></div>
                                </div>
                            </div>
                        </div>

                        <button type="button" id="submit-protect" class="w-full mt-10 bg-red-600 hover:bg-red-500 text-white py-6 rounded-2xl font-bold uppercase tracking-wide text-xl shadow-xl transition-all active:scale-95">
                            Lock PDF Now
                        </button>

                        <button type="button" onclick="location.reload()" class="w-full mt-4 text-slate-400 hover:text-white font-semibold uppercase tracking-widest text-sm transition-colors">
                            Cancel
                        </button>

                        <p class="text-center text-xs text-slate-500 mt-8 uppercase tracking-widest">
                            🔒 Password never stored • Processed in memory only
                        </p>
                    </div>
                </div>

                <div id="status-area" class="hidden py-32" aria-live="polite">
                    <div class="w-24 h-24 border-8 border-red-600 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Encrypting Document...</h3>
                    <p class="text-slate-600 text-lg font-medium">Applying AES-256 protection.</p>
                </div>

                <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                    <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                    <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Protected Successfully!</h2>
                    <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                        Your document is now secured with strong password encryption.
                    </p>
                    <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                        <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-red-600 transition-all hover:-translate-y-1">
                            Download Protected PDF
                        </a>
                        <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Protect Another File
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Protect PDFs with <span class="text-red-600">PDFEase</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Industry-leading security with complete privacy.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">AES-256 Encryption</h3>
                <p class="text-slate-600 leading-relaxed">The same standard used by governments and banks for top-secret data.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Zero Knowledge</h3>
                <p class="text-slate-600 leading-relaxed">Your password is never stored or logged—processed only in memory.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">100% Free & Unlimited</h3>
                <p class="text-slate-600 leading-relaxed">Protect as many files as you need—no limits or hidden fees.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Maximum Security Features</h3>
                    <ul class="space-y-3 text-slate-600">
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> 256-bit AES encryption</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> Open password protection</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> Prevents unauthorized access</li>
                        <li class="flex items-center gap-3"><span class="text-red-600">✓</span> No data retention</li>
                    </ul>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Easy & Fast</h3>
                    <p class="text-slate-600 leading-relaxed">Simple interface with password strength meter—no technical knowledge required.</p>
                </div>
            </div>

            <div class="bg-red-50 border-2 border-red-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-red-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-red-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Securing financial statements</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Protecting legal contracts</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Safeguarding medical records</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Sharing sensitive reports safely</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">How strong is the encryption?</h4>
                    <p class="text-slate-600">AES-256—the highest standard, trusted by governments worldwide.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my password stored?</h4>
                    <p class="text-slate-600">Never. It’s used only during processing and immediately discarded.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB—plenty for most documents.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I remove the password later?</h4>
                    <p class="text-slate-600">Yes—use our free Unlock PDF tool if you know the password.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-red-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Secure Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Add unbreakable password protection in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-red-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Protect PDF Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const pdfPass = document.getElementById('pdf-pass');
        const strengthBar = document.getElementById('strength-bar');
        const strengthText = document.getElementById('strength-text');
        const filenameLabel = document.getElementById('selected-filename');

        let selectedFile = null;

        // Password strength
        pdfPass.addEventListener('input', () => {
            const val = pdfPass.value;
            let score = 0;
            if (val.length >= 8) score += 25;
            if (val.length >= 12) score += 25;
            if (val.match(/[a-z]/) && val.match(/[A-Z]/)) score += 20;
            if (val.match(/[0-9]/)) score += 15;
            if (val.match(/[^A-Za-z0-9]/)) score += 15;

            strengthBar.style.width = score + '%';

            if (score < 40) {
                strengthBar.className = 'h-full bg-red-500 transition-all';
                strengthText.textContent = 'Weak';
                strengthText.className = 'text-red-500';
            } else if (score < 75) {
                strengthBar.className = 'h-full bg-amber-500 transition-all';
                strengthText.textContent = 'Medium';
                strengthText.className = 'text-amber-500';
            } else {
                strengthBar.className = 'h-full bg-emerald-500 transition-all';
                strengthText.textContent = 'Strong';
                strengthText.className = 'text-emerald-500';
            }
        });

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-red-600', 'bg-red-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-red-600', 'bg-red-50/60');
        });

        function handleFile(file) {
            if (!file || file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            filenameLabel.textContent = file.name;
            dropZone.classList.add('hidden');
            document.getElementById('editor-area').classList.remove('hidden');
        }

        fileInput.addEventListener('change', (e) => handleFile(e.target.files[0]));

        dropZone.addEventListener('drop', (e) => {
            e.preventDefault();
            dropZone.classList.remove('border-red-600', 'bg-red-50/60');
            handleFile(e.dataTransfer.files[0]);
        });

        document.getElementById('submit-protect').addEventListener('click', () => {
            if (!pdfPass.value || pdfPass.value.length < 6) {
                alert('Please enter a strong password (at least 6 characters).');
                return;
            }

            document.getElementById('editor-area').classList.add('hidden');
            document.getElementById('status-area').classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('password', pdfPass.value);

            fetch('api/protect-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status-area').classList.add('hidden');
                        document.getElementById('download-area').classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                        document.getElementById('download-link').download = 'protected_' + selectedFile.name;
                    } else {
                        throw new Error(data.message || 'Encryption failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>