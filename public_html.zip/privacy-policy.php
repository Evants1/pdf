<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Privacy Policy | PDFEase - Secure & Private PDF Management";
$meta_description = "Our commitment to your privacy: Automatic 60-minute file deletion, no account required, and bank-level SSL encryption for all PDF processing.";
$meta_keywords = "pdf privacy, data protection, secure file conversion, GDPR compliant pdf, no-log pdf tool";
$canonical_url = "https://pdfease.org/privacy-policy";
?>
<?php include 'static/head.php'; ?>
<body class="font-sans text-slate-900 bg-white antialiased">

<?php include 'static/nav.php'; ?>

    <header class="bg-slate-50 border-b border-slate-100 py-20 md:py-32">
        <div class="container mx-auto px-4">
            <div class="max-w-4xl mx-auto text-center">
                <h1 class="text-5xl md:text-7xl font-black text-slate-900 mb-10 tracking-tight animate-in fade-in slide-in-from-bottom-4 duration-700">
                    Privacy <span class="text-indigo-600">Policy</span>
                </h1>
                <p class="text-xl text-slate-500 font-medium tracking-wide">Last updated: January 7, 2026</p>
            </div>
        </div>
    </header>

    <section class="py-12 -mt-16">
        <div class="container mx-auto px-4">
            <div class="max-w-5xl mx-auto grid md:grid-cols-3 gap-8">
                <div class="bg-white p-10 rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-slate-100 flex flex-col items-center text-center hover:shadow-indigo-100 transition-shadow">
                    <div class="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center mb-6 text-3xl">🗑️</div>
                    <h3 class="font-black text-slate-900 mb-3 text-lg tracking-tight">Auto-Purge</h3>
                    <p class="text-sm text-slate-500 font-medium leading-relaxed">Files are permanently erased from our infrastructure within 60 minutes.</p>
                </div>
                <div class="bg-white p-10 rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-slate-100 flex flex-col items-center text-center hover:shadow-indigo-100 transition-shadow">
                    <div class="w-14 h-14 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center mb-6 text-3xl">🛡️</div>
                    <h3 class="font-black text-slate-900 mb-3 text-lg tracking-tight">No Tracking</h3>
                    <p class="text-sm text-slate-500 font-medium leading-relaxed">No Google Analytics, no pixels, and no third-party marketing cookies.</p>
                </div>
                <div class="bg-white p-10 rounded-[2.5rem] shadow-xl shadow-slate-200/60 border border-slate-100 flex flex-col items-center text-center hover:shadow-indigo-100 transition-shadow">
                    <div class="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center mb-6 text-3xl">🔒</div>
                    <h3 class="font-black text-slate-900 mb-3 text-lg tracking-tight">End-to-End</h3>
                    <p class="text-sm text-slate-500 font-medium leading-relaxed">SSL/TLS 1.3 encryption ensures secure transit of all document data.</p>
                </div>
            </div>
        </div>
    </section>

    <main class="py-24">
        <div class="container mx-auto px-4">
            <div class="max-w-5xl mx-auto flex flex-col md:flex-row gap-20">
                
                <aside class="hidden md:block w-64 flex-shrink-0">
                    <div class="sticky top-24">
                        <h4 class="text-xs font-black uppercase tracking-widest text-slate-400 mb-8">Policy Sections</h4>
                        <nav class="space-y-6 text-sm font-bold text-slate-500">
                            <a href="#processing" class="block hover:text-indigo-600 transition-colors">1. Data Processing</a>
                            <a href="#retention" class="block hover:text-indigo-600 transition-colors">2. File Retention</a>
                            <a href="#analytics" class="block hover:text-indigo-600 transition-colors">3. Cookie Policy</a>
                            <a href="#compliance" class="block hover:text-indigo-600 transition-colors">4. Global Compliance</a>
                            <a href="#contact" class="block hover:text-indigo-600 transition-colors">5. Support Access</a>
                        </nav>
                    </div>
                </aside>

                <article class="max-w-none text-slate-600">
                    
                    <div class="mb-16">
                        <p class="text-2xl leading-relaxed font-medium text-slate-600 italic">
                            At PDFEase, we operate under the principle of <strong>Data Minimization</strong>. We only collect the absolute minimum information required to process your documents, ensuring your digital footprint remains as small as possible.
                        </p>
                    </div>

                    <div class="space-y-16">
                        <section id="processing">
                            <h2 class="text-3xl font-black text-slate-900 mb-8 tracking-tight uppercase">1. Information Collection & Use</h2>
                            <div class="space-y-6 text-lg leading-relaxed">
                                <p><strong>File Processing Data:</strong> When you upload a document, we process it on our secure servers. This data is handled in volatile memory or temporary ephemeral storage for the sole purpose of executing your requested task (e.g., converting, merging, or compressing).</p>
                                <p><strong>Communication Data:</strong> If you utilize our support channels, we collect your email address and the contents of your inquiry to resolve your request. This information is never used for marketing purposes.</p>
                                <p><strong>User Identity:</strong> PDFEase is an "Account-Free" service. We do not maintain user profiles, passwords, or personal databases.</p>
                            </div>
                        </section>

                        <section id="retention" class="bg-slate-900 text-white p-12 md:p-16 rounded-[3rem] shadow-2xl shadow-slate-200">
                            <h2 class="text-3xl font-black text-white mb-10 tracking-tight uppercase">2. Secure Retention Policy</h2>
                            <div class="space-y-8 text-lg leading-relaxed">
                                <p class="text-slate-300">Our automated cleanup protocol is strictly enforced to protect your privacy:</p>
                                <ul class="space-y-6 text-slate-100">
                                    <li class="flex items-start gap-4"><span class="text-indigo-400 font-bold">▶</span> All file transfers use HTTPS (SSL/TLS 1.3) encryption.</li>
                                    <li class="flex items-start gap-4"><span class="text-indigo-400 font-bold">▶</span> Your PDFs are processed in cryptographically isolated sessions.</li>
                                    <li class="flex items-start gap-4"><span class="text-indigo-400 font-bold">▶</span> Files are <strong>automatically deleted within 1 hour</strong> after processing—no exceptions.</li>
                                    <li class="flex items-start gap-4"><span class="text-indigo-400 font-bold">▶</span> We do not keep backups of your documents or metadata.</li>
                                </ul>
                            </div>
                        </section>

                        <section id="analytics">
                            <h2 class="text-3xl font-black text-slate-900 mb-8 tracking-tight uppercase">3. Cookies & Tracking</h2>
                            <div class="space-y-6 text-lg leading-relaxed">
                                <p>To prioritize user privacy, PDFEase does <strong>not</strong> use third-party tracking cookies, Google Analytics, or advertising identifiers. We utilize only <em>Strictly Necessary Cookies</em> required for site functionality.</p>
                                <p>In the future, we may add lightweight, privacy-friendly analytics to improve the tools—we will update this policy accordingly.</p>
                            </div>
                        </section>

                        <section id="compliance">
                            <h2 class="text-3xl font-black text-slate-900 mb-8 tracking-tight uppercase">4. Data Sharing & Compliance</h2>
                            <div class="space-y-6 text-lg leading-relaxed">
                                <p>We do not sell, trade, or otherwise transfer your documents or personal information to outside parties. We comply with major global privacy standards, including <strong>GDPR</strong> and <strong>CCPA</strong>.</p>
                                <p>Because we delete files automatically, the "Right to be Forgotten" is built into our core architecture by default.</p>
                            </div>
                        </section>

                        <section id="contact" class="pt-16 border-t border-slate-100 text-center">
                            <h2 class="text-3xl font-black text-slate-900 mb-8 tracking-tight uppercase">5. Support Access</h2>
                            <p class="text-xl text-slate-500 mb-10 font-medium">Questions about this Privacy Policy? Email us anytime:</p>
                            <a href="mailto:support@pdfease.io" class="inline-block bg-indigo-600 text-white font-black text-2xl py-6 px-12 rounded-[2rem] shadow-xl shadow-indigo-100 hover:bg-indigo-500 transition-all hover:-translate-y-1">
                                support@pdfease.io
                            </a>
                            <p class="mt-16 text-slate-400 font-bold italic tracking-wide">
                                Your trust is our most valuable asset.
                            </p>
                        </section>
                    </div>

                </article>
            </div>
        </div>
    </main>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>