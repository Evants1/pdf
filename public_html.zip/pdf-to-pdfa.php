<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Convert PDF to PDF/A Online Free | Archival PDF Converter | PDFEase";
$meta_description = "Free online PDF to PDF/A converter. Create ISO-compliant archival PDFs for long-term preservation. Embed fonts, ensure readability—no signup.";
$meta_keywords = "pdf to pdf/a online free, convert pdf to pdfa, pdf archival format, iso 19005 converter, pdf/a-2b, long term pdf preservation";
$canonical_url = "https://pdfease.io/pdf-to-pdfa";
?>
<?php include 'static/head.php'; ?>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase PDF to PDF/A Converter",
  "description": "Free online tool to convert PDFs to ISO-compliant PDF/A format for long-term archival preservation.",
  "url": "https://pdfease.io/pdf-to-pdfa",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Convert PDF to PDF/A Online for Free",
  "description": "Step-by-step guide to creating archival PDFs using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Standardize to PDF/A' to process.",
      "name": "Start Conversion"
    },
    {
      "@type": "HowToStep",
      "text": "Download your ISO-compliant archival PDF.",
      "name": "Download PDF/A"
    }
  ]
}
</script>
<body class="bg-slate-50 font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-white pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Convert <span class="text-slate-600">PDF to PDF/A</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Create ISO-compliant archival PDFs for long-term preservation. Embed fonts, remove dependencies—ensure future readability.
                </p>
            </div>

            <div class="max-w-4xl mx-auto">
                <div id="drop-zone" class="bg-white border-4 border-dashed border-slate-300 rounded-[3rem] p-16 md:p-24 transition-all duration-300 hover:border-slate-500 hover:bg-slate-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF for PDF/A conversion">
                    <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">

                    <div id="upload-prompt" class="space-y-6">
                        <div class="mx-auto h-28 w-28 text-slate-700 bg-white rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 transition-all duration-500">
                            <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"></path>
                            </svg>
                        </div>
                        <div class="space-y-3">
                            <button type="button" onclick="document.getElementById('file-upload').click()" class="bg-slate-900 hover:bg-slate-800 text-white px-16 py-6 rounded-[2rem] font-bold text-xl shadow-2xl transition-all active:scale-95">
                                Choose PDF File
                            </button>
                            <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • PDF/A-2b compliant</p>
                        </div>
                    </div>

                    <div id="convert-area" class="hidden space-y-8">
                        <div class="inline-flex items-center gap-6 bg-slate-50 px-8 py-6 rounded-3xl shadow-lg border border-slate-100">
                            <div class="text-5xl">📜</div>
                            <div class="text-left">
                                <p id="filename-display" class="text-xl font-bold text-slate-900">document.pdf</p>
                                <p class="text-sm text-slate-500">Ready for archival conversion</p>
                            </div>
                        </div>

                        <button type="button" id="trigger-archive" class="px-20 py-7 bg-slate-900 hover:bg-slate-800 text-white font-bold text-2xl rounded-[3rem] shadow-2xl transition-all active:scale-95">
                            Convert to PDF/A
                        </button>

                        <button type="button" onclick="location.reload()" class="text-slate-500 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                            Choose Different File
                        </button>
                    </div>

                    <div id="status-area" class="hidden py-32" aria-live="polite">
                        <div class="w-24 h-24 border-8 border-slate-900 border-t-transparent rounded-full animate-spin mx-auto mb-10"></div>
                        <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Creating Archival PDF...</h3>
                        <p class="text-slate-600 text-lg font-medium">Embedding fonts, validating compliance.</p>
                    </div>

                    <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                        <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl">✓</div>
                        <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF/A Created Successfully!</h2>
                        <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                            Your document is now ISO-compliant and ready for long-term archiving.
                        </p>
                        <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                            <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-800 transition-all hover:-translate-y-1">
                                Download PDF/A
                            </a>
                            <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                                Archive Another File
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Convert to <span class="text-slate-600">PDF/A</span> with PDFEase?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Ensure your documents remain readable and compliant for decades.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-slate-100 text-slate-700 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">ISO Compliance</h3>
                <p class="text-slate-600 leading-relaxed">PDF/A-2b standard for legal and institutional archiving.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-slate-100 text-slate-700 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">Future-Proof</h3>
                <p class="text-slate-600 leading-relaxed">No external dependencies—readable forever.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-slate-100 text-slate-700 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Encrypted processing. Files deleted automatically.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Archival Standards</h3>
                    <ul class="space-y-3 text-slate-600">
                        <li class="flex items-center gap-3"><span class="text-slate-700">✓</span> All fonts embedded</li>
                        <li class="flex items-center gap-3"><span class="text-slate-700">✓</span> No JavaScript or external links</li>
                        <li class="flex items-center gap-3"><span class="text-slate-700">✓</span> Color profiles preserved</li>
                        <li class="flex items-center gap-3"><span class="text-slate-700">✓</span> Metadata standardized</li>
                    </ul>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Long-Term Reliability</h3>
                    <p class="text-slate-600 leading-relaxed">Ideal for legal records, research papers, contracts, and institutional archives.</p>
                </div>
            </div>

            <div class="bg-slate-100 border-2 border-slate-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-slate-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-slate-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-slate-700 mt-1">•</span> Legal and court documents</li>
                    <li class="flex items-start gap-3"><span class="text-slate-700 mt-1">•</span> Government and compliance records</li>
                    <li class="flex items-start gap-3"><span class="text-slate-700 mt-1">•</span> Academic theses and research</li>
                    <li class="flex items-start gap-3"><span class="text-slate-700 mt-1">•</span> Medical and patient histories</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">What is PDF/A?</h4>
                    <p class="text-slate-600">ISO 19005 standard for long-term document archiving—self-contained and future-proof.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Will quality change?</h4>
                    <p class="text-slate-600">No—original content preserved with embedded fonts and metadata.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB—suitable for most archival documents.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is it secure?</h4>
                    <p class="text-slate-600">Yes—encrypted transfer and automatic file deletion.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-slate-900 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Archive Your Documents?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Create compliant PDF/A files in seconds.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-slate-900 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Convert to PDF/A Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const dropZone = document.getElementById('drop-zone');
        const fileInput = document.getElementById('file-upload');
        const uploadPrompt = document.getElementById('upload-prompt');
        const convertArea = document.getElementById('convert-area');
        const statusArea = document.getElementById('status-area');
        const downloadArea = document.getElementById('download-area');
        const fileNameDisplay = document.getElementById('filename-display');

        let selectedFile = null;

        function handleFile(file) {
            if (!file || file.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            selectedFile = file;
            fileNameDisplay.textContent = file.name;
            uploadPrompt.classList.add('hidden');
            convertArea.classList.remove('hidden');
        }

        fileInput.addEventListener('change', e => {
            if (e.target.files.length > 0) handleFile(e.target.files[0]);
        });

        dropZone.addEventListener('dragover', e => {
            e.preventDefault();
            dropZone.classList.add('border-slate-600', 'bg-slate-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-slate-600', 'bg-slate-50/60');
        });
        dropZone.addEventListener('drop', e => {
            e.preventDefault();
            dropZone.classList.remove('border-slate-600', 'bg-slate-50/60');
            if (e.dataTransfer.files.length > 0) handleFile(e.dataTransfer.files[0]);
        });

        document.getElementById('trigger-archive').addEventListener('click', () => {
            if (!selectedFile) return;

            convertArea.classList.add('hidden');
            statusArea.classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);

            fetch('api/pdfa-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        statusArea.classList.add('hidden');
                        downloadArea.classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Conversion failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred during conversion. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>