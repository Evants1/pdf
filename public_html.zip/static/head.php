<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'Default Title'; ?></title>
    <meta name="description" content="<?php echo $meta_description ?? 'Default description'; ?>">
    <meta name="keywords" content="<?php echo $meta_keywords ?? ''; ?>">
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="canonical" href="<?php echo $canonical_url ?? ''; ?>">
    <link rel="stylesheet" href="/style/style.css">
    <meta property="og:title" content="<?php echo $page_title ?? 'Default Title'; ?>">
    <meta property="og:description" content="<?php echo $meta_description ?? 'Default description'; ?>">
    <meta property="og:image" content="<?php echo $og_image ?? '/default-og.jpg'; ?>">
    <meta property="og:url" content="<?php echo $canonical_url ?? ''; ?>">
    <meta property="og:type" content="website">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo $page_title ?? 'Default Title'; ?>">
    <meta name="twitter:description" content="<?php echo $meta_description ?? 'Default description'; ?>">
    <meta name="twitter:image" content="<?php echo $og_image ?? '/default-og.jpg'; ?>">

    <link rel="icon" href="/images/favicon.ico" type="image/x-icon">
</head>
