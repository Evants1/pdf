<header class="fixed top-0 left-0 right-0 z-[100] bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm">
    <div class="container mx-auto px-4">
        <div class="flex items-center justify-between h-20">
            
            <a href="/" class="flex-shrink-0 transition-transform hover:scale-105 active:scale-95">
                <img src="/images/logo.webp" alt="PDF Ease logo" class="h-10 w-auto" />
            </a>

            <nav class="hidden lg:flex items-center space-x-1">
                <a href="/" class="px-4 py-2 text-sm font-semibold text-gray-700 hover:text-blue-600 transition-colors rounded-lg hover:bg-gray-50">Home</a>
                
                <div class="group static">
                    <button class="flex items-center px-4 py-2 text-sm font-semibold text-gray-700 group-hover:text-blue-600 group-hover:bg-blue-50 transition-all rounded-lg focus:outline-none">
                        All PDF Tools 
                        <svg class="ml-1.5 w-4 h-4 transition-transform group-hover:rotate-180" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>
                    </button>

                    <div class="absolute left-0 top-[79px] w-full bg-white border-b border-gray-200 shadow-[0_20px_50px_rgba(0,0,0,0.1)] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-300 ease-out transform translate-y-2 group-hover:translate-y-0">
                        <div class="container mx-auto px-6 py-12 grid grid-cols-5 gap-10">
                            
                            <div>
                                <div class="flex items-center space-x-2 text-blue-600 font-bold mb-6 uppercase text-[11px] tracking-widest">
                                    <span class="p-1.5 bg-blue-50 rounded-md">📂</span>
                                    <span>Organize</span>
                                </div>
                                <ul class="space-y-3">
                                    <li><a href="/merge-pdf" class="group/item flex items-center text-gray-600 hover:text-blue-600 text-sm transition-colors">Merge PDF</a></li>
                                    <li><a href="/split-pdf" class="group/item flex items-center text-gray-600 hover:text-blue-600 text-sm transition-colors">Split PDF</a></li>
                                    <li><a href="/remove-pages" class="group/item flex items-center text-gray-600 hover:text-blue-600 text-sm transition-colors">Remove Pages</a></li>
                                    <li><a href="/extract-pages" class="group/item flex items-center text-gray-600 hover:text-blue-600 text-sm transition-colors">Extract Pages</a></li>
                                </ul>
                            </div>

                            <div>
                                <div class="flex items-center space-x-2 text-orange-600 font-bold mb-6 uppercase text-[11px] tracking-widest">
                                    <span class="p-1.5 bg-orange-50 rounded-md">✏️</span>
                                    <span>Edit</span>
                                </div>
                                <ul class="space-y-3">
                                    <li><a href="/edit-pdf" class="font-bold text-gray-900 hover:text-blue-600 text-sm transition-colors">Edit PDF Online</a></li>
                                    <li><a href="/compress-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Compress PDF</a></li>
                                    <li><a href="/ocr-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">OCR (Scan to Text)</a></li>
                                    <li><a href="/add-watermark" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Add Watermark</a></li>
                                </ul>
                            </div>

                            <div>
                                <div class="flex items-center space-x-2 text-green-600 font-bold mb-6 uppercase text-[11px] tracking-widest">
                                    <span class="p-1.5 bg-green-50 rounded-md">🔐</span>
                                    <span>Security</span>
                                </div>
                                <ul class="space-y-3">
                                    <li><a href="/protect-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Add Password</a></li>
                                    <li><a href="/unlock-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Unlock PDF</a></li>
                                    <li><a href="/sign-pdf" class="font-bold text-gray-900 hover:text-blue-600 text-sm transition-colors">Sign PDF</a></li>
                                    <li><a href="/redact-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Redact PDF</a></li>
                                </ul>
                            </div>

                            <div>
                                <div class="flex items-center space-x-2 text-purple-600 font-bold mb-6 uppercase text-[11px] tracking-widest">
                                    <span class="p-1.5 bg-purple-50 rounded-md">🔄</span>
                                    <span>To PDF</span>
                                </div>
                                <ul class="space-y-3">
                                    <li><a href="/word-to-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Word to PDF</a></li>
                                    <li><a href="/jpg-to-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">JPG to PDF</a></li>
                                    <li><a href="/html-to-pdf" class="text-blue-600 font-bold italic text-sm transition-colors">HTML to PDF</a></li>
                                    <li><a href="/excel-to-pdf" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">Excel to PDF</a></li>
                                </ul>
                            </div>

                            <div>
                                <div class="flex items-center space-x-2 text-red-600 font-bold mb-6 uppercase text-[11px] tracking-widest">
                                    <span class="p-1.5 bg-red-50 rounded-md">📄</span>
                                    <span>From PDF</span>
                                </div>
                                <ul class="space-y-3">
                                    <li><a href="/pdf-to-word" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">PDF to Word</a></li>
                                    <li><a href="/pdf-to-jpg" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">PDF to JPG</a></li>
                                    <li><a href="/pdf-to-excel" class="text-gray-600 hover:text-blue-600 text-sm transition-colors">PDF to Excel</a></li>
                                    <li class="pt-2 border-t border-gray-50">
                                        <a href="/pdf-to-pdfa" class="text-gray-400 text-[11px] uppercase tracking-tighter hover:text-gray-600 transition-colors italic">PDF/A Archive</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>

                <a href="/blogs" class="px-4 py-2 text-sm font-semibold text-gray-700 hover:text-blue-600 transition-colors rounded-lg hover:bg-gray-50">Blog</a>
            </nav>

            <div class="flex items-center space-x-4">
                <a href="/login" class="hidden sm:block text-sm font-bold text-gray-600 hover:text-blue-600 transition-colors">Log In</a>
                <a href="/register" class="bg-blue-600 text-white text-sm font-bold py-3 px-7 rounded-xl hover:bg-blue-700 transition-all shadow-lg shadow-blue-200/50 active:scale-95">
                    Free Trial
                </a>
                
                <button onclick="toggleMobileMenu()" class="lg:hidden p-2.5 text-gray-600 hover:bg-gray-100 rounded-xl transition-colors">
                    <svg id="menuIcon" class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                </button>
            </div>
        </div>
    </div>

    <div id="mobileMenu" class="hidden fixed inset-0 top-20 bg-white z-[99] overflow-y-auto lg:hidden">
        <div class="p-6 space-y-10">
            <div class="grid grid-cols-2 gap-4">
                <div class="col-span-2 text-[11px] font-black text-gray-400 uppercase tracking-widest">Popular Tools</div>
                <a href="/merge-pdf" class="flex items-center p-4 bg-gray-50 rounded-2xl text-gray-800 font-bold text-sm">Merge PDF</a>
                <a href="/edit-pdf" class="flex items-center p-4 bg-gray-50 rounded-2xl text-gray-800 font-bold text-sm">Edit PDF</a>
                <a href="/compress-pdf" class="flex items-center p-4 bg-gray-50 rounded-2xl text-gray-800 font-bold text-sm">Compress</a>
                <a href="/sign-pdf" class="flex items-center p-4 bg-gray-50 rounded-2xl text-gray-800 font-bold text-sm">Sign PDF</a>
            </div>

            <div class="space-y-6">
                 <div>
                    <p class="text-[11px] font-black text-blue-600 uppercase tracking-widest mb-4">All Conversions</p>
                    <div class="grid grid-cols-1 gap-3 text-sm">
                        <a href="/word-to-pdf" class="text-gray-600 py-1">Word to PDF</a>
                        <a href="/pdf-to-word" class="text-gray-600 py-1">PDF to Word</a>
                        <a href="/jpg-to-pdf" class="text-gray-600 py-1">JPG to PDF</a>
                        <a href="/html-to-pdf" class="text-blue-600 py-1 font-bold">HTML to PDF</a>
                    </div>
                </div>
            </div>

            <div class="pt-8 border-t border-gray-100 flex flex-col gap-6">
                <a href="/blogs" class="text-xl font-bold text-gray-900">Blog</a>
                <a href="/login" class="text-xl font-bold text-gray-900">Log In</a>
                <a href="/register" class="w-full text-center bg-gray-900 text-white py-4 rounded-2xl font-bold">Start Free Trial</a>
            </div>
        </div>
    </div>
</header>