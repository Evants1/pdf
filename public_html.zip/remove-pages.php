<!DOCTYPE html>
<html lang="en">
<?php
$page_title = "Remove PDF Pages Online Free | Delete Pages from PDF | PDFEase";
$meta_description = "Free online tool to delete unwanted pages from PDF files. Visual thumbnails let you select and remove specific pages instantly—no software needed.";
$meta_keywords = "remove pdf pages online free, delete pages from pdf, pdf page remover, extract pages from pdf, free pdf page delete";
$canonical_url = "https://pdfease.org/remove-pages";
?>
<?php include 'static/head.php'; ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.min.js" integrity="sha512-..." crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "WebApplication",
  "name": "PDFEase Remove PDF Pages",
  "description": "Free online tool to visually select and delete unwanted pages from PDF documents.",
  "url": "https://pdfease.org/remove-pages",
  "applicationCategory": "UtilityApplication",
  "operatingSystem": "All",
  "offers": {
    "@type": "Offer",
    "price": "0"
  }
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "HowTo",
  "name": "How to Remove Pages from a PDF Online for Free",
  "description": "Step-by-step guide to deleting specific pages from a PDF using PDFEase.",
  "step": [
    {
      "@type": "HowToStep",
      "text": "Upload your PDF file.",
      "name": "Upload PDF"
    },
    {
      "@type": "HowToStep",
      "text": "Click on thumbnails of pages you want to delete.",
      "name": "Select Pages"
    },
    {
      "@type": "HowToStep",
      "text": "Click 'Rebuild PDF' and download the cleaned document.",
      "name": "Download Updated PDF"
    }
  ]
}
</script>
<body class="bg-white font-sans text-slate-900 flex flex-col min-h-screen antialiased">
    <?php include 'static/nav.php'; ?>
    <section class="relative bg-slate-50 pt-16 pb-24 border-b border-slate-100">
        <div class="max-w-7xl mx-auto px-4 text-center">
            <div class="mb-12">
                <h1 class="text-4xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">
                    Remove <span class="text-red-600">PDF Pages</span> Online Free
                </h1>
                <p class="text-xl md:text-2xl text-slate-600 max-w-3xl mx-auto font-medium leading-relaxed">
                    Delete unwanted pages visually. Click thumbnails to select what to remove—fast, secure, and 100% free.
                </p>
            </div>

            <div id="drop-zone" class="max-w-4xl mx-auto bg-white border-4 border-dashed border-slate-200 rounded-[3rem] p-12 md:p-20 transition-all duration-300 hover:border-red-500 hover:bg-red-50/30 group relative shadow-lg cursor-pointer" aria-label="Upload PDF to remove pages">
                <input type="file" id="file-upload" class="hidden" accept=".pdf" aria-label="Select PDF file">
                <label for="file-upload" class="cursor-pointer space-y-6 block">
                    <div class="mx-auto h-28 w-28 bg-red-50 text-red-600 rounded-[3rem] flex items-center justify-center shadow-2xl group-hover:scale-110 group-hover:-rotate-3 transition-all duration-500">
                        <svg class="w-14 h-14" fill="none" stroke="currentColor" viewBox="0 0 24 24" aria-hidden="true">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-4v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                        </svg>
                    </div>
                    <div class="space-y-3">
                        <span class="text-3xl md:text-4xl font-extrabold block text-slate-900 tracking-tight uppercase">Upload PDF to Clean</span>
                        <p class="text-slate-500 font-medium text-base">Drag & drop supported • Up to 200MB • Client-side thumbnails</p>
                    </div>
                </label>
            </div>

            <div id="editor-area" class="hidden mt-12 animate-in fade-in slide-in-from-bottom-8 duration-700">
                <div class="sticky top-6 z-50 max-w-6xl mx-auto bg-slate-900 text-white p-5 md:p-8 rounded-[3rem] mb-12 flex flex-wrap justify-between items-center shadow-2xl border-4 border-slate-800">
                    <div class="px-4">
                        <p class="text-xs uppercase font-bold text-slate-400 tracking-widest mb-1">Selection Summary</p>
                        <p class="text-lg font-bold">
                            <span id="remove-count" class="text-3xl font-extrabold text-red-500">0</span>
                            <span class="text-slate-300"> pages selected for removal</span>
                        </p>
                    </div>
                    <div class="flex items-center gap-6 px-4">
                        <button type="button" onclick="location.reload()" class="text-sm font-bold uppercase text-slate-400 hover:text-white tracking-widest transition-colors">
                            Cancel
                        </button>
                        <button type="button" id="submit-remove" class="bg-red-600 hover:bg-red-500 px-12 py-5 rounded-3xl font-bold uppercase tracking-widest text-lg transition shadow-2xl active:scale-95">
                            Rebuild PDF
                        </button>
                    </div>
                </div>

                <div class="bg-slate-100 rounded-[3rem] p-8 md:p-12 shadow-inner border-4 border-slate-200">
                    <div id="page-grid" class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 xl:grid-cols-8 gap-8" role="region" aria-label="PDF page thumbnails">
                    </div>
                </div>
            </div>

            <div id="status-area" class="hidden py-32" aria-live="polite">
                <div class="flex flex-col items-center">
                    <div class="relative w-28 h-28 mb-10">
                        <div class="absolute inset-0 border-8 border-red-100 rounded-full"></div>
                        <div class="absolute inset-0 border-8 border-red-600 border-t-transparent rounded-full animate-spin"></div>
                    </div>
                    <h3 class="text-4xl font-extrabold text-slate-900 mb-4">Rebuilding Document...</h3>
                    <p class="text-slate-600 text-lg font-medium">Removing selected pages securely.</p>
                </div>
            </div>

            <div id="download-area" class="hidden py-32 text-center animate-in zoom-in-95 duration-700" aria-live="polite">
                <div class="w-28 h-28 bg-emerald-500 text-white rounded-[3rem] flex items-center justify-center mx-auto mb-10 text-6xl shadow-2xl rotate-12">✓</div>
                <h2 class="text-5xl md:text-6xl font-extrabold text-slate-900 mb-6 tracking-tight">PDF Cleaned Successfully!</h2>
                <p class="text-slate-600 mb-12 font-medium max-w-lg mx-auto text-lg">
                    Unwanted pages removed. Your streamlined document is ready.
                </p>
                <div class="flex flex-col md:flex-row items-center justify-center gap-8">
                    <a id="download-link" href="#" download class="bg-slate-900 text-white px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-800 transition-all hover:-translate-y-1">
                        Download Cleaned PDF
                    </a>
                    <button type="button" onclick="location.reload()" class="text-slate-600 hover:text-slate-900 font-semibold uppercase tracking-wide text-sm">
                        Clean Another File
                    </button>
                </div>
            </div>
        </div>
    </section>

    <section class="max-w-6xl mx-auto px-6 py-24">
        <div class="text-center mb-16">
            <h2 class="text-4xl md:text-5xl font-extrabold text-slate-900 mb-6 tracking-tight">
                Why Choose PDFEase to <span class="text-red-600">Remove PDF Pages</span>?
            </h2>
            <p class="text-xl text-slate-600 font-medium max-w-3xl mx-auto">Intuitive, secure, and completely free—no watermarks or limits.</p>
        </div>

        <div class="grid md:grid-cols-3 gap-12 mb-20">
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">1</div>
                <h3 class="text-2xl font-bold mb-4">Visual Selection</h3>
                <p class="text-slate-600 leading-relaxed">See thumbnails and click to mark pages—no typing page numbers.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">2</div>
                <h3 class="text-2xl font-bold mb-4">No Quality Loss</h3>
                <p class="text-slate-600 leading-relaxed">Original images, fonts, and vectors preserved perfectly.</p>
            </div>
            <div class="text-center">
                <div class="w-20 h-20 bg-red-100 text-red-600 rounded-3xl flex items-center justify-center mx-auto mb-6 text-3xl font-bold shadow-lg">3</div>
                <h3 class="text-2xl font-bold mb-4">Secure & Private</h3>
                <p class="text-slate-600 leading-relaxed">Thumbnails rendered in your browser. Files deleted after processing.</p>
            </div>
        </div>

        <div class="grid lg:grid-cols-2 gap-16 items-center mb-20">
            <div class="space-y-10">
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Intuitive Click-to-Delete</h3>
                    <p class="text-slate-600 leading-relaxed">Toggle pages with a single click. Live counter shows how many will be removed.</p>
                </div>
                <div class="bg-white p-10 rounded-[3rem] shadow-xl border border-slate-100">
                    <h3 class="text-2xl font-bold mb-4">Works with Protected PDFs</h3>
                    <p class="text-slate-600 leading-relaxed">First unlock restrictions using our free Unlock tool, then remove pages easily.</p>
                </div>
            </div>

            <div class="bg-red-50 border-2 border-red-200 rounded-[3rem] p-12">
                <h3 class="text-3xl font-bold text-red-900 mb-6">Common Use Cases</h3>
                <ul class="space-y-4 text-red-800 text-lg">
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Removing blank or duplicate pages</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Deleting sensitive sections before sharing</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Cleaning up scanned multi-page documents</li>
                    <li class="flex items-start gap-3"><span class="text-red-600 mt-1">•</span> Reducing file size by removing extras</li>
                </ul>
            </div>
        </div>

        <div>
            <h2 class="text-4xl font-extrabold text-center text-slate-900 mb-12 tracking-tight">Frequently Asked Questions</h2>
            <div class="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Can I undo a deletion?</h4>
                    <p class="text-slate-600">Keep your original file as backup. Once rebuilt, removed pages are permanently gone.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Does it affect quality?</h4>
                    <p class="text-slate-600">No—remaining content is untouched and retains original sharpness.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">File size limits?</h4>
                    <p class="text-slate-600">Up to 200MB and hundreds of pages supported.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Protected PDFs?</h4>
                    <p class="text-slate-600">Unlock restrictions first with our free Unlock tool.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Is my content private?</h4>
                    <p class="text-slate-600">Yes—thumbnails generated in-browser. Server sees only page numbers to remove.</p>
                </div>
                <div class="bg-white p-8 rounded-3xl shadow-md border border-slate-100">
                    <h4 class="text-xl font-bold text-slate-900 mb-3">Mobile friendly?</h4>
                    <p class="text-slate-600">Fully responsive—works great on phones and tablets.</p>
                </div>
            </div>
        </div>
    </section>

    <section class="bg-red-600 py-20">
        <div class="max-w-5xl mx-auto px-6 text-center text-white">
            <h2 class="text-4xl md:text-5xl font-extrabold mb-8 tracking-tight">Ready to Clean Your PDF?</h2>
            <p class="text-xl mb-12 max-w-2xl mx-auto opacity-90">Remove unwanted pages in seconds—no software needed.</p>
            <button onclick="document.getElementById('file-upload').click();" class="bg-white text-red-600 px-20 py-7 rounded-[3rem] font-bold text-2xl shadow-2xl hover:bg-slate-100 transition-all hover:-translate-y-1">
                Remove Pages Now
            </button>
        </div>
    </section>

    <?php include 'static/footer.php'; ?>
    <script>
        const fileInput = document.getElementById('file-upload');
        const dropZone = document.getElementById('drop-zone');
        const pageGrid = document.getElementById('page-grid');
        const removeCountLabel = document.getElementById('remove-count');
        let selectedFile = null;
        let pagesToRemove = new Set();

        // Drag feedback
        dropZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            dropZone.classList.add('border-red-600', 'bg-red-50/60');
        });
        dropZone.addEventListener('dragleave', () => {
            dropZone.classList.remove('border-red-600', 'bg-red-50/60');
        });

        fileInput.addEventListener('change', async (e) => {
            selectedFile = e.target.files[0];
            if (!selectedFile || selectedFile.type !== 'application/pdf') {
                alert('Please select a valid PDF file.');
                return;
            }
            dropZone.classList.add('hidden');
            document.getElementById('editor-area').classList.remove('hidden');
            pageGrid.innerHTML = '<p class="col-span-full text-center text-slate-500 py-16 text-lg">Generating thumbnails...</p>';

            const arrayBuffer = await selectedFile.arrayBuffer();
            pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.4.120/pdf.worker.min.js';

            const pdf = await pdfjsLib.getDocument(arrayBuffer).promise;
            pageGrid.innerHTML = '';

            for (let i = 1; i <= pdf.numPages; i++) {
                const page = await pdf.getPage(i);
                const viewport = page.getViewport({ scale: 0.5 });
                const canvas = document.createElement('canvas');
                const context = canvas.getContext('2d');
                canvas.height = viewport.height;
                canvas.width = viewport.width;
                await page.render({ canvasContext: context, viewport: viewport }).promise;

                const div = document.createElement('div');
                div.className = "relative bg-white p-4 rounded-[2.5rem] shadow-md border-2 border-slate-100 hover:border-red-400 transition-all cursor-pointer group";
                div.innerHTML = `
                    <div class="overflow-hidden rounded-2xl shadow-sm">
                        <img src="${canvas.toDataURL()}" alt="Page ${i}" class="w-full pointer-events-none">
                    </div>
                    <div class="text-center mt-4 font-bold text-slate-600 text-sm uppercase tracking-wider">Page ${i}</div>
                    <div class="absolute inset-0 bg-red-600/90 rounded-[2.5rem] flex flex-col items-center justify-center hidden removed-overlay">
                        <svg class="w-16 h-16 text-white mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M6 18L18 6M6 6l12 12"></path>
                        </svg>
                        <span class="text-white font-bold text-lg uppercase">Delete</span>
                    </div>
                    <div class="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div class="bg-red-600 text-white p-3 rounded-2xl shadow-2xl">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-4v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path>
                            </svg>
                        </div>
                    </div>
                `;

                div.addEventListener('click', () => {
                    if (pagesToRemove.has(i)) {
                        pagesToRemove.delete(i);
                        div.querySelector('.removed-overlay').classList.add('hidden');
                        div.classList.replace('border-red-600', 'border-slate-100');
                    } else {
                        pagesToRemove.add(i);
                        div.querySelector('.removed-overlay').classList.remove('hidden');
                        div.classList.replace('border-slate-100', 'border-red-600');
                    }
                    removeCountLabel.textContent = pagesToRemove.size;
                });

                pageGrid.appendChild(div);
            }
        });

        document.getElementById('submit-remove').addEventListener('click', () => {
            if (pagesToRemove.size === 0) {
                alert('Please select at least one page to remove.');
                return;
            }

            document.getElementById('editor-area').classList.add('hidden');
            document.getElementById('status-area').classList.remove('hidden');

            const formData = new FormData();
            formData.append('pdf_file', selectedFile);
            formData.append('remove_pages', Array.from(pagesToRemove).sort((a, b) => a - b).join(','));

            fetch('api/remove-pages-api.php', { method: 'POST', body: formData })
                .then(res => res.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('status-area').classList.add('hidden');
                        document.getElementById('download-area').classList.remove('hidden');
                        document.getElementById('download-link').href = data.download_url;
                    } else {
                        throw new Error(data.message || 'Processing failed');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('An error occurred while rebuilding your PDF. Please try again.');
                    location.reload();
                });
        });
    </script>
</body>
</html>