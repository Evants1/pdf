<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// BULLETPROOF PATH: Connect to your database
require_once __DIR__ . '/../../db.php'; 

// --- DATE & TIME LOGIC FOR SEO ---
$currentTimestamp = time();
$currentDate = date('d F Y', $currentTimestamp);
$currentDateSeo = date('F j, Y', $currentTimestamp);

// --- FETCH LAST 100 DRAWS FOR DEEP ANALYSIS ---
$analyzeLimit = 100;
$stmt = $pdo->prepare("SELECT ball_1, ball_2, ball_3, ball_4, ball_5, powerball, draw_date FROM powerball_results ORDER BY draw_date DESC LIMIT :limit");
$stmt->bindValue(':limit', $analyzeLimit, PDO::PARAM_INT);
$stmt->execute();
$historyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- DATA PROCESSING & ALGORITHM (50 MAIN BALLS, 20 POWERBALLS) ---
$numberFrequency = array_fill(1, 50, 0);
$pbFrequency = array_fill(1, 20, 0);
$trendingFrequency = array_fill(1, 50, 0); // For the "Recently Hot" main balls (last 20 draws)
$lastSeen = array_fill(1, 50, null);
$lastSeenPb = array_fill(1, 20, null);
$pairCounts = [];
$tripletCounts = [];

$drawCount = 0;
$latestDrawDateStr = $historyResults[0]['draw_date'] ?? date('Y-m-d');
$latestDrawFormatted = date('d F Y', strtotime($latestDrawDateStr));

foreach ($historyResults as $draw) {
    $drawDate = $draw['draw_date'];
    $ballsInDraw = [];
    $drawCount++;
    
    // Process single numbers (Main 5 Balls)
    for ($i = 1; $i <= 5; $i++) {
        $ball = (int)$draw['ball_' . $i];
        if ($ball >= 1 && $ball <= 50) {
            $numberFrequency[$ball]++;
            $ballsInDraw[] = $ball;
            
            // Track trending (last 20 draws)
            if ($drawCount <= 20) {
                $trendingFrequency[$ball]++;
            }

            // Track last seen date
            if ($lastSeen[$ball] === null || $drawDate > $lastSeen[$ball]) {
                $lastSeen[$ball] = $drawDate;
            }
        }
    }
    
    // Process PowerBall
    $pb = (int)$draw['powerball'];
    if ($pb >= 1 && $pb <= 20) {
        $pbFrequency[$pb]++;
        if ($lastSeenPb[$pb] === null || $drawDate > $lastSeenPb[$pb]) {
            $lastSeenPb[$pb] = $drawDate;
        }
    }
    
    // Process Pairs and Triplets (Main Balls Only)
    sort($ballsInDraw);
    $len = count($ballsInDraw);
    
    if ($len >= 2) {
        for ($i = 0; $i < $len - 1; $i++) {
            for ($j = $i + 1; $j < $len; $j++) {
                $pair = $ballsInDraw[$i] . ',' . $ballsInDraw[$j];
                $pairCounts[$pair] = ($pairCounts[$pair] ?? 0) + 1;
            }
        }
    }
    
    if ($len >= 3) {
        for ($i = 0; $i < $len - 2; $i++) {
            for ($j = $i + 1; $j < $len - 1; $j++) {
                for ($k = $j + 1; $k < $len; $k++) {
                    $triplet = $ballsInDraw[$i] . ',' . $ballsInDraw[$j] . ',' . $ballsInDraw[$k];
                    $tripletCounts[$triplet] = ($tripletCounts[$triplet] ?? 0) + 1;
                }
            }
        }
    }
}

// Sort main frequency (Hot to Cold)
arsort($numberFrequency);
$hotNumbersAll = array_keys($numberFrequency);

// Create Cold Frequency Array for Main Balls (Sort ascending)
$coldNumberFrequency = $numberFrequency;
asort($coldNumberFrequency);
$coldNumbersAll = array_keys($coldNumberFrequency);

// Sort PowerBall frequency (Hot to Cold)
arsort($pbFrequency);
$hotPbAll = array_keys($pbFrequency);

// Create Cold Frequency Array for PowerBalls (Sort ascending)
$coldPbFrequency = $pbFrequency;
asort($coldPbFrequency);
$coldPbAll = array_keys($coldPbFrequency);

// Sort Trending Main Balls
arsort($trendingFrequency);
$trendingNumbersTop = array_slice(array_keys($trendingFrequency), 0, 5, true);

// Sort Pairs and Triplets
arsort($pairCounts);
arsort($tripletCounts);
$topPairs = array_slice($pairCounts, 0, 5, true);
$topTriplets = array_slice($tripletCounts, 0, 3, true);

// Extract Top Subsets
$top5HotMain = array_slice($hotNumbersAll, 0, 5);
$top5ColdMain = array_slice($coldNumbersAll, 0, 5);
$top3HotPb = array_slice($hotPbAll, 0, 3);
$top3ColdPb = array_slice($coldPbAll, 0, 3);

// Prepare Chart Data (Top 15 Hot Main Balls)
$chartLabels = array_slice($hotNumbersAll, 0, 15);
$chartData = [];
foreach ($chartLabels as $num) {
    $chartData[] = $numberFrequency[$num];
}

// --- FRESHNESS SIGNAL ---
$lastUpdatedText = date('F j, Y \a\t g:i A');

// --- SEO METADATA ---
$pageTitle = "SA PowerBall Hot and Cold Numbers Today ({$currentDateSeo}) – Latest 100 Draw Stats";
$metaDesc = "View today's SA PowerBall hot and cold numbers based on the latest 100 draws. Find the most drawn main numbers, overdue PowerBalls, and statistical trends updated daily.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?');

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "PowerBall", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/powerball"],
    ["name" => "Hot & Cold Numbers", "url" => $currentUrl]
];

// --- PAGE SPECIFIC FAQs ---
$pageFaqs = [
    [
        "question" => "What are the hottest SA PowerBall numbers today?",
        "answer" => "The hottest SA PowerBall numbers are the specific lottery balls that have been drawn the most frequently. On this page, we define 'hot' as the numbers with the highest appearance rate over the last 100 official South African PowerBall draws."
    ],
    [
        "question" => "Why are the main numbers and PowerBall tracked separately?",
        "answer" => "Because the SA PowerBall uses a dual-matrix system. Five numbers are drawn from a main pool of 50 balls, and one bonus PowerBall is drawn from a completely separate machine with 20 balls. For statistical accuracy, these two completely different probabilities must be tracked independently."
    ],
    [
        "question" => "What are cold numbers, and why track them?",
        "answer" => "Cold numbers are the balls that have appeared the least over our 100-draw sample size, making them statistically 'overdue'. Many players use cold numbers in their strategy under the mathematical belief that probability will eventually balance out across both the 50-ball and 20-ball pools."
    ],
    [
        "question" => "Do playing hot or cold numbers increase my chances of winning?",
        "answer" => "Lottery draws are purely random. While mathematical frequency shows which numbers have trended recently, playing hot or cold numbers does not guarantee a win. It is simply a statistical strategy used by players who prefer data-driven choices over random guessing."
    ],
    [
        "question" => "When is this hot and cold numbers data updated?",
        "answer" => "Our database is dynamically updated every Tuesday and Friday night immediately following the official SA PowerBall draw at 21:00 SAST. This ensures our transparency charts and tables reflect the absolute latest factual data."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo $currentUrl; ?>">
    <meta property="og:image" content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/powerball-hot-cold.jpg">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <script defer src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Automatically includes your main style if available */
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* --- CENTERING FIX --- */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }

        /* --- SIDEBAR PAGE LAYOUT STYLES --- */
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }
        .lotto-sidebar { position: sticky; top: 100px; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        
        /* Red Theme for PowerBall Sidebar Header */
        .sidebar-menu-header { background: linear-gradient(135deg, #e11d48, #9f1239); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; }
        
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover { background: #fff1f2; color: #0f172a; border-left-color: #fda4af; }
        .sidebar-links a.active { background: #fff1f2; color: #e11d48; border-left-color: #e11d48; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* --- TRANSPARENCY & FRESHNESS --- */
        .data-transparency-box { background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #10b981; padding: 16px 20px; border-radius: 8px; margin-bottom: 30px; display: flex; align-items: center; gap: 12px; }
        .data-icon { font-size: 1.5rem; }
        .data-text { font-size: 0.95rem; color: #475569; line-height: 1.5; margin: 0; }
        .data-text strong { color: #0f172a; }

        .freshness-badge { display: inline-flex; align-items: center; background: #ecfdf5; color: #059669; padding: 8px 14px; border-radius: 999px; font-size: 0.85rem; font-weight: 700; margin-bottom: 20px; border: 1px solid #a7f3d0; }
        .freshness-dot { width: 8px; height: 8px; background-color: #10b981; border-radius: 50%; margin-right: 8px; animation: pulse-green 2s infinite; }
        @keyframes pulse-green { 0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); } 70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); } 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); } }

        /* --- TRENDING / TOP BLOCKS --- */
        .highlights-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 40px; }
        .highlight-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .highlight-card h3 { margin: 0 0 16px 0; font-size: 1.05rem; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 8px; }
        .balls-row { display: flex; gap: 8px; flex-wrap: wrap; }
        
        .lotto-ball { display: flex; align-items: center; justify-content: center; width: 42px; height: 42px; border-radius: 50%; background: #f8fafc; border: 2px solid #cbd5e1; font-weight: 800; font-size: 1rem; color: #334155; }
        .lotto-ball.hot { border-color: #fca5a5; background: #fef2f2; color: #b91c1c; }
        .lotto-ball.cold { border-color: #93c5fd; background: #eff6ff; color: #1d4ed8; }
        .lotto-ball.trending { border-color: #fcd34d; background: #fffbeb; color: #b45309; }
        
        .lotto-ball.powerball-hot { border-color: #9f1239; background: #e11d48; color: #ffffff; }
        .lotto-ball.powerball-cold { border-color: #3b82f6; background: #2563eb; color: #ffffff; }

        .highlight-desc { font-size: 0.85rem; color: #64748b; margin-top: 12px; margin-bottom: 0; line-height: 1.4; }

        /* --- HOT NUMBERS DATA TABLE --- */
        .table-section-title { font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-bottom: 16px; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }
        .table-container { width: 100%; overflow-x: auto; margin-bottom: 40px; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .hot-table { width: 100%; border-collapse: collapse; text-align: left; }
        .hot-table th { background: #f8fafc; padding: 16px 20px; font-weight: 700; color: #334155; border-bottom: 2px solid #e2e8f0; font-size: 0.95rem; white-space: nowrap; }
        .hot-table td { padding: 16px 20px; border-bottom: 1px solid #f1f5f9; color: #475569; font-size: 0.95rem; vertical-align: middle; }
        .hot-table tr:hover td { background: #f8fafc; }
        .hot-table tr:last-child td { border-bottom: none; }
        
        .td-ball { font-weight: 800; color: #0f172a; font-size: 1.1rem; display: flex; align-items: center; gap: 10px; }
        .td-ball span.circle { display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; background: #fef2f2; color: #b91c1c; border-radius: 50%; border: 1px solid #fca5a5; font-size: 0.9rem; }
        .td-freq { font-weight: 700; color: #e11d48; }
        .td-date { font-size: 0.85rem; color: #64748b; }
        .status-badge { padding: 4px 10px; border-radius: 999px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .status-very-hot { background: #fee2e2; color: #991b1b; }
        .status-hot { background: #ffedd5; color: #c2410c; }
        .status-warm { background: #f1f5f9; color: #475569; }

        /* --- CHART & PAIRS --- */
        .chart-container { position: relative; height: 350px; width: 100%; margin-top: 20px; margin-bottom: 40px; background: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; box-sizing: border-box; }
        
        .combinations-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; margin-bottom: 40px; }
        .combo-card { background: #ffffff; border-radius: 12px; padding: 24px; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .combo-card h3 { font-size: 1.2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
        .combo-list { list-style: none; padding: 0; margin: 0; }
        .combo-list li { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px dashed #e2e8f0; }
        .combo-list li:last-child { border-bottom: none; padding-bottom: 0; }
        .combo-numbers { display: flex; gap: 6px; }
        .combo-ball { width: 32px; height: 32px; border-radius: 50%; background: #1e293b; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; font-weight: 700; }
        .combo-freq { font-size: 0.85rem; color: #64748b; font-weight: 600; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; }

        /* --- EXPLANATION & FAQ --- */
        .explanation-box { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; }
        .explanation-box h2 { margin-top: 0; font-size: 1.4rem; font-weight: 800; color: #0f172a; }
        .explanation-box p, .explanation-box ul { color: #475569; line-height: 1.7; }
        
        .faq-section { margin-top: 40px; margin-bottom: 24px; }
        .faq-header { font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-left: 14px; border-left: 5px solid #e11d48; line-height: 1.2; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 600; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #e11d48; font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* --- INTERNAL LINKS --- */
        .modern-internal-links { margin-top: 40px; margin-bottom: 32px; background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; }
        .modern-internal-links h2 { font-size: 1.3rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; }
        .modern-internal-links .nav-pills { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 12px; }
        .modern-internal-links .nav-pills a { display: inline-flex; align-items: center; background: #f8fafc; color: #334155; text-decoration: none; padding: 12px 20px; border-radius: 999px; font-size: 0.95rem; font-weight: 600; border: 1px solid #e2e8f0; transition: all 0.2s ease; }
        .modern-internal-links .nav-pills a:hover { background: #e11d48; color: #ffffff; border-color: #e11d48; box-shadow: 0 4px 10px -2px rgba(225, 29, 72, 0.25); }

        @media(max-width: 1024px) {
            .layout-with-sidebar { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
            .combinations-grid { grid-template-columns: 1fr; }
            .highlights-grid { grid-template-columns: 1fr; }
        }
    </style>

    <!-- Article Schema -->
    <script type="application/ld+json">
    {
      "@context":"https://schema.org",
      "@type":"Article",
      "headline":"<?php echo $pageTitle; ?>",
      "description":"<?php echo $metaDesc; ?>",
      "datePublished":"<?php echo date('c', strtotime($latestDrawDateStr)); ?>",
      "dateModified":"<?php echo date('c'); ?>",
      "author":{
        "@type":"Organization",
        "name":"Your Website Name"
      },
      "publisher":{
        "@type":"Organization",
        "name":"Your Website Name"
      },
      "mainEntityOfPage":{
        "@type":"WebPage",
        "@id":"<?php echo $currentUrl; ?>"
      }
    }
    </script>

    <!-- Breadcrumb Schema -->
    <script type="application/ld+json">
    {
     "@context":"https://schema.org",
     "@type":"BreadcrumbList",
     "itemListElement":[
       <?php foreach($breadcrumbs as $index => $crumb): ?>
       {
         "@type":"ListItem",
         "position": <?php echo $index+1; ?>,
         "name":"<?php echo $crumb['name']; ?>",
         "item":"<?php echo $crumb['url']; ?>"
       }<?php echo $index < count($breadcrumbs)-1 ? ',' : ''; ?>
       <?php endforeach; ?>
     ]
    }
    </script>

    <!-- FAQ Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        <nav class="breadcrumb">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>
        
        <div class="layout-with-sidebar">
            <div class="content-area">
                
                <div class="freshness-badge">
                    <div class="freshness-dot"></div>
                    Data Updated: 
                    <time datetime="<?php echo date('c'); ?>">
                        <?php echo $lastUpdatedText; ?>
                    </time>
                </div>

                <h1 style="font-size: 2.2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2;">
                    SA PowerBall Hot and Cold Numbers Today
                </h1>
                
                <div style="font-size: 1.1rem; color: #475569; line-height: 1.6; margin-bottom: 24px;">
                    <p>Welcome to your ultimate tool for tracking <strong>SA PowerBall number trends</strong>. Whether you are hunting for the <strong>most frequent PowerBall numbers</strong> or tracking down the most <strong>overdue PowerBall numbers</strong>, our database breaks down the math so you don't have to.</p>
                    <p><strong>Understanding the Dual Matrix:</strong> PowerBall is unique because it uses two different drum machines. Five main balls are drawn from a pool of 50, and one bonus ball is drawn from a separate pool of 20. Because the odds are completely different, we mathematically isolate the <strong>hottest main combinations</strong> from the <strong>lucky PowerBalls</strong>.</p>
                    <p><strong>What do hot numbers mean?</strong> Hot numbers have appeared more frequently than expected over our 100-draw sample. Many players use these recent statistical favorites to anchor their tickets.</p>
                    <p><strong>What do cold numbers mean?</strong> Cold numbers have been stubbornly hiding in the machine. Because probability suggests all balls will eventually be drawn equally, many South African players view these neglected balls as mathematically "overdue."</p>
                    <p><strong>Why use our data?</strong> We automatically scrape and calculate frequency from the exact official results every Tuesday and Friday. Reviewing this data allows players to craft calculated, data-driven tickets rather than leaving it purely to quick-pick algorithms.</p>
                </div>

                <div class="data-transparency-box">
                    <div class="data-icon">📊</div>
                    <p class="data-text">
                        <strong>Data Source Authenticity:</strong> This frequency analysis is dynamically generated based on the <strong>last 100 official SA PowerBall draws</strong>. It was last updated after the draw on <?php echo $latestDrawFormatted; ?>.
                    </p>
                </div>

                <div class="highlights-grid">
                    <!-- HOT HIGHLIGHT (MAIN) -->
                    <div class="highlight-card">
                        <h2>🔥 Top 5 Hottest (Main)</h2>
                        <div class="balls-row">
                            <?php foreach($top5HotMain as $num): ?>
                                <div class="lotto-ball hot"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Most drawn from the 50-ball main pool over 100 draws.</p>
                    </div>

                    <!-- COLD HIGHLIGHT (MAIN) -->
                    <div class="highlight-card">
                        <h2>❄️ Overdue Daily Lotto Numbers (Main)</h2>
                        <div class="balls-row">
                            <?php foreach($top5ColdMain as $num): ?>
                                <div class="lotto-ball cold"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Most overdue numbers, appearing the least in the main pool.</p>
                    </div>
                    
                    <!-- HOT/COLD PB HIGHLIGHT -->
                    <div class="highlight-card">
                        <h2>🎯 Hottest & Coldest PowerBalls</h2>
                        <div class="balls-row">
                            <!-- Show 2 Hot PB, 2 Cold PB -->
                            <div class="lotto-ball powerball-hot" title="Hot PowerBall"><?php echo $top3HotPb[0] ?? ''; ?></div>
                            <div class="lotto-ball powerball-hot" title="Hot PowerBall"><?php echo $top3HotPb[1] ?? ''; ?></div>
                            <div class="lotto-ball powerball-cold" title="Overdue PowerBall"><?php echo $top3ColdPb[0] ?? ''; ?></div>
                            <div class="lotto-ball powerball-cold" title="Overdue PowerBall"><?php echo $top3ColdPb[1] ?? ''; ?></div>
                        </div>
                        <p class="highlight-desc">Red = Most Frequent PB. Blue = Most Overdue PB.</p>
                    </div>

                    <!-- TRENDING HIGHLIGHT -->
                    <div class="highlight-card">
                        <h2>📈 Trending PowerBall Numbers</h2>
                        <div class="balls-row">
                            <?php foreach($trendingNumbersTop as $num => $count): ?>
                                <div class="lotto-ball trending"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Main balls currently surging in frequency over the last 20 draws.</p>
                    </div>
                </div>

                <h2 class="table-section-title">Most Drawn PowerBall Numbers Today (Main Balls)</h2>
                <div class="table-container">
                    <table class="hot-table">
                        <thead>
                            <tr>
                                <th>Main Ball (1-50)</th>
                                <th>Times Drawn (Last 100)</th>
                                <th>Last Seen Date</th>
                                <th>Current Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Display top 15 hot main numbers in the table for SEO depth
                            $displayLimit = 15;
                            $count = 0;
                            foreach($numberFrequency as $num => $freq): 
                                if($count >= $displayLimit) break;
                                
                                // Determine Badge
                                if ($count < 5) {
                                    $badgeClass = "status-very-hot";
                                    $badgeText = "🔥 Very Hot";
                                } elseif ($count < 10) {
                                    $badgeClass = "status-hot";
                                    $badgeText = "🔥 Hot";
                                } else {
                                    $badgeClass = "status-warm";
                                    $badgeText = "Warm";
                                }
                                
                                $dateSeen = $lastSeen[$num] ? date('d M Y', strtotime($lastSeen[$num])) : 'N/A';
                            ?>
                            <tr>
                                <td class="td-ball"><span class="circle"><?php echo $num; ?></span> Ball <?php echo $num; ?></td>
                                <td class="td-freq"><?php echo $freq; ?>x</td>
                                <td class="td-date"><?php echo $dateSeen; ?></td>
                                <td><span class="status-badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span></td>
                            </tr>
                            <?php 
                                $count++;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>

                <h2 class="table-section-title" style="border:none; margin-bottom: 0;">Main Ball Frequency Distribution</h2>
                <p style="color: #64748b; margin-top: 4px;">Visual representation of the Top 15 hottest main numbers in the SA PowerBall.</p>
                <div class="chart-container">
                    <canvas id="hotChart"></canvas>
                </div>

                <div class="combinations-grid">
                    <div class="combo-card">
                        <h2>Best PowerBall Number Pairs</h2>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Main balls most frequently drawn together.</p>
                        <ul class="combo-list">
                            <?php foreach ($topPairs as $pairStr => $count): 
                                $nums = explode(',', $pairStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?>x</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="combo-card">
                        <h2>Best PowerBall Number Triplets</h2>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Main triplets most frequently drawn together.</p>
                        <ul class="combo-list">
                            <?php foreach ($topTriplets as $tripStr => $count): 
                                $nums = explode(',', $tripStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[2]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?>x</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <section class="explanation-box">
                    <h2>Understanding the PowerBall Dual-Matrix Logic</h2>
                    <p>When analyzing <strong>latest powerball hot numbers South Africa</strong>, the system is fundamentally different from a normal lotto. You are looking at two entirely different probabilities:</p>
                    <ul>
                        <li><strong>The Main Pool (1-50):</strong> 5 balls are drawn from this set. Use the Hot and Cold main numbers above to structure the core of your ticket.</li>
                        <li><strong>The PowerBall Pool (1-20):</strong> 1 ball is drawn from this entirely separate machine. We never mix frequency data between the two pools because a ball being "hot" in the main drum has absolutely zero mathematical bearing on the bonus drum.</li>
                    </ul>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">SA PowerBall Numbers FAQ</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="modern-internal-links">
                    <h2>Enhance Your Lottery Strategy</h2>
                    <p style="color: #64748b; margin-bottom: 20px;">Use these hot numbers alongside our other statistical tools to build a balanced ticket.</p>
                    <ul class="nav-pills">
                        <li><a href="/results/powerball/predictions">PowerBall Predictions for Today</a></li>
                        <li><a href="/results/powerball">Latest PowerBall Results</a></li>
                        <li><a href="/results/powerball/history">100-Draw History Archive</a></li>
                        <li><a href="/results/powerball/generator">Random Number Generator</a></li>
                    </ul>
                </section>
                
                <section class="modern-internal-links" style="margin-top: 20px;">
                    <h2>Explore Other Lottery Trends</h2>
                    <p style="color: #64748b; margin-bottom: 20px;">Check the hot and cold statistical trends for other major South African lotteries.</p>
                    <ul class="nav-pills">
                        <li><a href="/results/lotto/hot-cold">Lotto Hot Numbers</a></li>
                        <li><a href="/results/lotto-plus-2/hot-cold">Lotto Plus 2 Hot Numbers</a></li>
                        <li><a href="/results/daily-lotto/hot-cold">Daily Lotto Hot Numbers</a></li>
                    </ul>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="PowerBall navigation">
                    <div class="sidebar-menu-header">PowerBall Panel</div>
                    <ul class="sidebar-links">
                        <li><a href="/results/powerball">Latest Results</a></li>
                        <li><a href="/results/powerball/history">Draw History</a></li>
                        <li><a href="/results/powerball/predictions">Smart Predictions</a></li>
                        <li><a href="/results/powerball/check-tickets">Check Tickets</a></li>
                        <li><a href="/results/powerball/hot-cold" class="active">Hot & Cold Numbers</a></li>
                        <li><a href="/results/powerball/payouts">Prize Payouts</a></li>
                        <li><a href="/how-to-play">How to Play</a></li>
                        <li><a href="https://affiliates.hollywoodbets.net/" class="highlight" target="_blank" rel="noopener nofollow">Play Online &rarr;</a></li>
                    </ul>
                </nav>
            </aside>
            
        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });

            // Chart.js Rendering
            const ctx = document.getElementById('hotChart');
            if (ctx) {
                const chartLabels = <?php echo json_encode(array_map(function($val){ return "Ball " . $val; }, $chartLabels)); ?>;
                const chartData = <?php echo json_encode($chartData); ?>;

                new Chart(ctx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: chartLabels,
                        datasets: [{
                            label: 'Times Drawn (Last 100 Draws)',
                            data: chartData,
                            backgroundColor: '#e11d48', // Red theme for chart
                            borderRadius: 4,
                            hoverBackgroundColor: '#9f1239'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#1e293b',
                                padding: 12,
                                titleFont: { family: 'Inter', size: 14 },
                                bodyFont: { family: 'Inter', size: 13 }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: '#f1f5f9' },
                                ticks: { precision: 0, font: { family: 'Inter' } }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { font: { family: 'Inter', weight: 'bold' } }
                            }
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>