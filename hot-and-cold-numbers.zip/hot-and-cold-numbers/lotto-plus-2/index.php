<?php
// Turn on error reporting temporarily
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

date_default_timezone_set('Africa/Johannesburg');

// BULLETPROOF PATH: Connect to your database
require_once __DIR__ . '/../../db.php'; 

// --- DATE & TIME LOGIC FOR SEO ---
$currentTimestamp = time();
$currentDate = date('d F Y', $currentTimestamp);
$currentDateSeo = date('F j, Y', $currentTimestamp);

// --- FETCH LAST 100 DRAWS FOR DEEP ANALYSIS ---
$analyzeLimit = 100;
$stmt = $pdo->prepare("SELECT ball_1, ball_2, ball_3, ball_4, ball_5, ball_6, draw_date FROM lotto_plus_2_results ORDER BY draw_date DESC LIMIT :limit");
$stmt->bindValue(':limit', $analyzeLimit, PDO::PARAM_INT);
$stmt->execute();
$historyResults = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- DATA PROCESSING & ALGORITHM (52 BALLS, 6 DRAWN) ---
$numberFrequency = array_fill(1, 52, 0);
$trendingFrequency = array_fill(1, 52, 0); // For the "Recently Hot" (last 20 draws)
$lastSeen = array_fill(1, 52, null);
$pairCounts = [];
$tripletCounts = [];

$drawCount = 0;
$latestDrawDateStr = $historyResults[0]['draw_date'] ?? date('Y-m-d');
$latestDrawFormatted = date('d F Y', strtotime($latestDrawDateStr));

foreach ($historyResults as $draw) {
    $drawDate = $draw['draw_date'];
    $ballsInDraw = [];
    $drawCount++;
    
    // Process single numbers (Main 6 Balls)
    for ($i = 1; $i <= 6; $i++) {
        $ball = (int)$draw['ball_' . $i];
        if ($ball >= 1 && $ball <= 52) {
            $numberFrequency[$ball]++;
            $ballsInDraw[] = $ball;
            
            // Track trending (last 20 draws)
            if ($drawCount <= 20) {
                $trendingFrequency[$ball]++;
            }

            // Track last seen date
            if ($lastSeen[$ball] === null || $drawDate > $lastSeen[$ball]) {
                $lastSeen[$ball] = $drawDate;
            }
        }
    }
    
    // Process Pairs and Triplets
    sort($ballsInDraw);
    $len = count($ballsInDraw);
    
    if ($len >= 2) {
        for ($i = 0; $i < $len - 1; $i++) {
            for ($j = $i + 1; $j < $len; $j++) {
                $pair = $ballsInDraw[$i] . ',' . $ballsInDraw[$j];
                $pairCounts[$pair] = ($pairCounts[$pair] ?? 0) + 1;
            }
        }
    }
    
    if ($len >= 3) {
        for ($i = 0; $i < $len - 2; $i++) {
            for ($j = $i + 1; $j < $len - 1; $j++) {
                for ($k = $j + 1; $k < $len; $k++) {
                    $triplet = $ballsInDraw[$i] . ',' . $ballsInDraw[$j] . ',' . $ballsInDraw[$k];
                    $tripletCounts[$triplet] = ($tripletCounts[$triplet] ?? 0) + 1;
                }
            }
        }
    }
}

// Sort main frequency (Hot to Cold)
arsort($numberFrequency);
$hotNumbersAll = array_keys($numberFrequency);

// Create Cold Frequency Array (Sort ascending)
$coldNumberFrequency = $numberFrequency;
asort($coldNumberFrequency);
$coldNumbersAll = array_keys($coldNumberFrequency);

// Sort Trending
arsort($trendingFrequency);
$trendingNumbersTop = array_slice(array_keys($trendingFrequency), 0, 6, true);

// Sort Pairs and Triplets
arsort($pairCounts);
arsort($tripletCounts);
$topPairs = array_slice($pairCounts, 0, 5, true);
$topTriplets = array_slice($tripletCounts, 0, 3, true);

// Extract Top Subsets (Top 6 for Lotto Plus 2)
$top6Hot = array_slice($hotNumbersAll, 0, 6);
$top6Cold = array_slice($coldNumbersAll, 0, 6);

// Prepare Chart Data (Top 15 Hot)
$chartLabels = array_slice($hotNumbersAll, 0, 15);
$chartData = [];
foreach ($chartLabels as $num) {
    $chartData[] = $numberFrequency[$num];
}

// --- FRESHNESS SIGNAL ---
$lastUpdatedText = date('F j, Y \a\t g:i A');

// --- SEO METADATA ---
$pageTitle = "SA Lotto Plus 2 Hot and Cold Numbers Today ({$currentDateSeo}) – Latest 100 Draw Stats";
$metaDesc = "View today's SA Lotto Plus 2 hot and cold numbers based on the latest 100 draws. Find the most drawn, overdue, and trending Lotto Plus 2 numbers updated daily.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . strtok($_SERVER['REQUEST_URI'], '?');

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Lotto Plus 2", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/results/lotto-plus-2"],
    ["name" => "Hot & Cold Numbers", "url" => $currentUrl]
];

// --- PAGE SPECIFIC FAQs ---
$pageFaqs = [
    [
        "question" => "What are the hottest SA Lotto Plus 2 numbers today?",
        "answer" => "The hottest Lotto Plus 2 numbers are the specific lottery balls that have been drawn the most frequently over a specified period. On this page, we define 'hot' as the numbers with the highest appearance rate over the last 100 official South African Lotto Plus 2 draws."
    ],
    [
        "question" => "What are cold numbers, and why track them?",
        "answer" => "Cold numbers are the balls that have appeared the least over our 100-draw sample size, making them statistically 'overdue'. Many players use cold numbers in their strategy under the belief that probability will eventually balance out across the 52-ball pool and these missing numbers will be drawn."
    ],
    [
        "question" => "How are these Lotto Plus 2 statistics calculated?",
        "answer" => "Our algorithm extracts the exact results from the last 100 SA Lotto Plus 2 draws. It counts how many times each of the 52 main balls has appeared, ranking them from highest frequency (hot) to lowest (cold). We also track 'Trending' numbers by isolating the frequency of just the last 20 draws."
    ],
    [
        "question" => "Do playing hot or cold numbers increase my chances of winning?",
        "answer" => "Lottery draws are purely random. While mathematical frequency shows which numbers have trended recently, playing hot or cold numbers does not guarantee a win. It is simply a statistical strategy used by players who prefer data-driven choices over random guessing."
    ],
    [
        "question" => "When is this hot and cold numbers data updated?",
        "answer" => "Our database is dynamically updated every Wednesday and Saturday night immediately following the official SA Lotto Plus 2 draw at 20:56 SAST. This ensures our transparency charts and tables reflect the absolute latest factual data."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="article">
    <meta property="og:url" content="<?php echo $currentUrl; ?>">
    <meta property="og:image" content="https://<?php echo $_SERVER['HTTP_HOST']; ?>/images/lotto-plus-2-hot-cold.jpg">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <script defer src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        /* Automatically includes your main style if available */
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* --- CENTERING FIX --- */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }

        /* --- SIDEBAR PAGE LAYOUT STYLES --- */
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }
        .lotto-sidebar { position: sticky; top: 100px; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        
        /* Deep Purple Theme for Lotto Plus 2 Sidebar Header */
        .sidebar-menu-header { background: linear-gradient(135deg, #7c3aed, #4c1d95); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; }
        
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover { background: #f5f3ff; color: #0f172a; border-left-color: #c4b5fd; }
        .sidebar-links a.active { background: #f5f3ff; color: #7c3aed; border-left-color: #7c3aed; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* --- TRANSPARENCY & FRESHNESS --- */
        .data-transparency-box { background: #f8fafc; border: 1px solid #e2e8f0; border-left: 4px solid #10b981; padding: 16px 20px; border-radius: 8px; margin-bottom: 30px; display: flex; align-items: center; gap: 12px; }
        .data-icon { font-size: 1.5rem; }
        .data-text { font-size: 0.95rem; color: #475569; line-height: 1.5; margin: 0; }
        .data-text strong { color: #0f172a; }

        .freshness-badge { display: inline-flex; align-items: center; background: #ecfdf5; color: #059669; padding: 8px 14px; border-radius: 999px; font-size: 0.85rem; font-weight: 700; margin-bottom: 20px; border: 1px solid #a7f3d0; }
        .freshness-dot { width: 8px; height: 8px; background-color: #10b981; border-radius: 50%; margin-right: 8px; animation: pulse-green 2s infinite; }
        @keyframes pulse-green { 0% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.4); } 70% { box-shadow: 0 0 0 6px rgba(16, 185, 129, 0); } 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0); } }

        /* --- TRENDING / TOP BLOCKS --- */
        .highlights-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px; }
        .highlight-card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 24px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .highlight-card h3 { margin: 0 0 16px 0; font-size: 1.1rem; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 8px; }
        .balls-row { display: flex; gap: 8px; flex-wrap: wrap; }
        .lotto-ball { display: flex; align-items: center; justify-content: center; width: 42px; height: 42px; border-radius: 50%; background: #f8fafc; border: 2px solid #cbd5e1; font-weight: 800; font-size: 1rem; color: #334155; }
        
        .lotto-ball.hot { border-color: #fca5a5; background: #fef2f2; color: #b91c1c; }
        .lotto-ball.cold { border-color: #93c5fd; background: #eff6ff; color: #1d4ed8; }
        .lotto-ball.trending { border-color: #fcd34d; background: #fffbeb; color: #b45309; }
        
        .highlight-desc { font-size: 0.85rem; color: #64748b; margin-top: 12px; margin-bottom: 0; line-height: 1.4; }

        /* --- HOT NUMBERS DATA TABLE --- */
        .table-section-title { font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-bottom: 16px; border-bottom: 2px solid #e2e8f0; padding-bottom: 12px; }
        .table-container { width: 100%; overflow-x: auto; margin-bottom: 40px; background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .hot-table { width: 100%; border-collapse: collapse; text-align: left; }
        .hot-table th { background: #f8fafc; padding: 16px 20px; font-weight: 700; color: #334155; border-bottom: 2px solid #e2e8f0; font-size: 0.95rem; white-space: nowrap; }
        .hot-table td { padding: 16px 20px; border-bottom: 1px solid #f1f5f9; color: #475569; font-size: 0.95rem; vertical-align: middle; }
        .hot-table tr:hover td { background: #f8fafc; }
        .hot-table tr:last-child td { border-bottom: none; }
        
        .td-ball { font-weight: 800; color: #0f172a; font-size: 1.1rem; display: flex; align-items: center; gap: 10px; }
        .td-ball span.circle { display: inline-flex; align-items: center; justify-content: center; width: 32px; height: 32px; background: #f5f3ff; color: #7c3aed; border-radius: 50%; border: 1px solid #c4b5fd; font-size: 0.9rem; }
        .td-freq { font-weight: 700; color: #ef4444; }
        .td-date { font-size: 0.85rem; color: #64748b; }
        .status-badge { padding: 4px 10px; border-radius: 999px; font-size: 0.75rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px; }
        .status-very-hot { background: #fee2e2; color: #991b1b; }
        .status-hot { background: #ffedd5; color: #c2410c; }
        .status-warm { background: #f1f5f9; color: #475569; }

        /* --- CHART & PAIRS --- */
        .chart-container { position: relative; height: 350px; width: 100%; margin-top: 20px; margin-bottom: 40px; background: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; box-sizing: border-box; }
        
        .combinations-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; margin-bottom: 40px; }
        .combo-card { background: #ffffff; border-radius: 12px; padding: 24px; border: 1px solid #e2e8f0; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .combo-card h3 { font-size: 1.2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; display: flex; align-items: center; gap: 8px; }
        .combo-list { list-style: none; padding: 0; margin: 0; }
        .combo-list li { display: flex; justify-content: space-between; align-items: center; padding: 12px 0; border-bottom: 1px dashed #e2e8f0; }
        .combo-list li:last-child { border-bottom: none; padding-bottom: 0; }
        .combo-numbers { display: flex; gap: 6px; }
        .combo-ball { width: 32px; height: 32px; border-radius: 50%; background: #1e293b; color: #ffffff; display: flex; align-items: center; justify-content: center; font-size: 0.85rem; font-weight: 700; }
        .combo-freq { font-size: 0.85rem; color: #64748b; font-weight: 600; background: #f1f5f9; padding: 4px 8px; border-radius: 4px; }

        /* --- EXPLANATION & FAQ --- */
        .explanation-box { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; }
        .explanation-box h2 { margin-top: 0; font-size: 1.4rem; font-weight: 800; color: #0f172a; }
        .explanation-box p, .explanation-box ul { color: #475569; line-height: 1.7; }
        
        .faq-section { margin-top: 40px; margin-bottom: 24px; }
        .faq-header { font-size: 1.4rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-left: 14px; border-left: 5px solid #7c3aed; line-height: 1.2; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 600; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #7c3aed; font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }

        /* --- INTERNAL LINKS --- */
        .modern-internal-links { margin-top: 40px; margin-bottom: 32px; background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; }
        .modern-internal-links h2 { font-size: 1.3rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 20px; }
        .modern-internal-links .nav-pills { list-style: none; padding: 0; margin: 0; display: flex; flex-wrap: wrap; gap: 12px; }
        .modern-internal-links .nav-pills a { display: inline-flex; align-items: center; background: #f8fafc; color: #334155; text-decoration: none; padding: 12px 20px; border-radius: 999px; font-size: 0.95rem; font-weight: 600; border: 1px solid #e2e8f0; transition: all 0.2s ease; }
        .modern-internal-links .nav-pills a:hover { background: #7c3aed; color: #ffffff; border-color: #7c3aed; box-shadow: 0 4px 10px -2px rgba(124, 58, 237, 0.25); }

        @media(max-width: 1024px) {
            .layout-with-sidebar { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
            .combinations-grid { grid-template-columns: 1fr; }
            .highlights-grid { grid-template-columns: 1fr; } /* Stack on mobile */
        }
    </style>

    <!-- Article Schema -->
    <script type="application/ld+json">
    {
      "@context":"https://schema.org",
      "@type":"Article",
      "headline":"<?php echo $pageTitle; ?>",
      "description":"<?php echo $metaDesc; ?>",
      "datePublished":"<?php echo date('c', strtotime($latestDrawDateStr)); ?>",
      "dateModified":"<?php echo date('c'); ?>",
      "author":{
        "@type":"Organization",
        "name":"Your Website Name"
      },
      "publisher":{
        "@type":"Organization",
        "name":"Your Website Name"
      },
      "mainEntityOfPage":{
        "@type":"WebPage",
        "@id":"<?php echo $currentUrl; ?>"
      }
    }
    </script>

    <!-- Breadcrumb Schema -->
    <script type="application/ld+json">
    {
     "@context":"https://schema.org",
     "@type":"BreadcrumbList",
     "itemListElement":[
       <?php foreach($breadcrumbs as $index => $crumb): ?>
       {
         "@type":"ListItem",
         "position": <?php echo $index+1; ?>,
         "name":"<?php echo $crumb['name']; ?>",
         "item":"<?php echo $crumb['url']; ?>"
       }<?php echo $index < count($breadcrumbs)-1 ? ',' : ''; ?>
       <?php endforeach; ?>
     ]
    }
    </script>

    <!-- FAQ Schema -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
</head>
<body>

    <?php include __DIR__ . '/../../static/nav.php'; ?>

    <main class="container">
        <nav class="breadcrumb">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>
        
        <div class="layout-with-sidebar">
            <div class="content-area">
                
                <div class="freshness-badge">
                    <div class="freshness-dot"></div>
                    Data Updated: 
                    <time datetime="<?php echo date('c'); ?>">
                        <?php echo $lastUpdatedText; ?>
                    </time>
                </div>

                <h1 style="font-size: 2.2rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2;">
                    SA Lotto Plus 2 Hot and Cold Numbers Today
                </h1>
                
                <div style="font-size: 1.1rem; color: #475569; line-height: 1.6; margin-bottom: 24px;">
                    <p>Welcome to your ultimate guide for tracking <strong>Lotto Plus 2 number trends</strong>. Whether you are searching for the <strong>most frequent Lotto Plus 2 numbers</strong> or trying to spot the most <strong>overdue Lotto Plus 2 numbers</strong>, our rigorous mathematical analysis has you covered.</p>
                    <p><strong>What do hot numbers mean?</strong> "Hot" numbers are those from the 52-ball pool that have appeared more frequently than the statistical average over our 100-draw sample. Many South African players view these as their <strong>lucky Lotto Plus 2 numbers</strong> to anchor their tickets.</p>
                    <p><strong>What do cold numbers mean?</strong> Cold numbers are the complete opposite. Because mathematical probability dictates that all 52 balls should eventually balance out over a long enough timeline, the balls that have been drawn the least recently are considered mathematically "overdue."</p>
                    <p><strong>How is this data calculated?</strong> Our algorithm continuously pulls official draw results. We dynamically aggregate the appearances of all drawn balls, identifying the <strong>hottest Lotto Plus 2 combinations</strong> alongside the ones that have been hiding.</p>
                    <p><strong>Why track them?</strong> While the lottery is always a random game of chance, analyzing frequency statistics allows players to make calculated, data-driven decisions rather than relying entirely on blind guessing.</p>
                </div>

                <div class="data-transparency-box">
                    <div class="data-icon">📊</div>
                    <p class="data-text">
                        <strong>Data Source Authenticity:</strong> This frequency analysis is dynamically generated based on the <strong>last 100 official SA Lotto Plus 2 draws</strong>. It was last updated after the draw on <?php echo $latestDrawFormatted; ?>.
                    </p>
                </div>

                <div class="highlights-grid">
                    <!-- HOT HIGHLIGHT -->
                    <div class="highlight-card">
                        <h2>🔥 Top 6 Hottest</h2>
                        <div class="balls-row">
                            <?php foreach($top6Hot as $num): ?>
                                <div class="lotto-ball hot"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Most drawn numbers across the entire 100-draw period.</p>
                    </div>

                    <!-- COLD HIGHLIGHT -->
                    <div class="highlight-card">
                        <h2>❄️ Overdue Lotto Plus 2 Numbers</h2>
                        <div class="balls-row">
                            <?php foreach($top6Cold as $num): ?>
                                <div class="lotto-ball cold"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Most overdue numbers, appearing the least in our 100-draw sample.</p>
                    </div>
                    
                    <!-- TRENDING HIGHLIGHT -->
                    <div class="highlight-card">
                        <h2>📈 Trending Lotto Plus 2 Numbers</h2>
                        <div class="balls-row">
                            <?php foreach($trendingNumbersTop as $num => $count): ?>
                                <div class="lotto-ball trending"><?php echo $num; ?></div>
                            <?php endforeach; ?>
                        </div>
                        <p class="highlight-desc">Numbers currently surging in frequency over the last 20 draws.</p>
                    </div>
                </div>

                <h2 class="table-section-title">Most Drawn Lotto Plus 2 Numbers Today</h2>
                <div class="table-container">
                    <table class="hot-table">
                        <thead>
                            <tr>
                                <th>Lotto Ball</th>
                                <th>Times Drawn (Last 100)</th>
                                <th>Last Seen Date</th>
                                <th>Current Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            // Display top 15 hot numbers in the table for SEO depth
                            $displayLimit = 15;
                            $count = 0;
                            foreach($numberFrequency as $num => $freq): 
                                if($count >= $displayLimit) break;
                                
                                // Determine Badge
                                if ($count < 6) {
                                    $badgeClass = "status-very-hot";
                                    $badgeText = "🔥 Very Hot";
                                } elseif ($count < 12) {
                                    $badgeClass = "status-hot";
                                    $badgeText = "🔥 Hot";
                                } else {
                                    $badgeClass = "status-warm";
                                    $badgeText = "Warm";
                                }
                                
                                $dateSeen = $lastSeen[$num] ? date('d M Y', strtotime($lastSeen[$num])) : 'N/A';
                            ?>
                            <tr>
                                <td class="td-ball"><span class="circle"><?php echo $num; ?></span> Ball <?php echo $num; ?></td>
                                <td class="td-freq"><?php echo $freq; ?>x</td>
                                <td class="td-date"><?php echo $dateSeen; ?></td>
                                <td><span class="status-badge <?php echo $badgeClass; ?>"><?php echo $badgeText; ?></span></td>
                            </tr>
                            <?php 
                                $count++;
                            endforeach; 
                            ?>
                        </tbody>
                    </table>
                </div>

                <div class="chart-container">
                    <canvas id="hotChart"></canvas>
                </div>

                <div class="combinations-grid">
                    <div class="combo-card">
                        <h2>Best Lotto Plus 2 Number Pairs</h2>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Pairs of numbers most frequently drawn together.</p>
                        <ul class="combo-list">
                            <?php foreach ($topPairs as $pairStr => $count): 
                                $nums = explode(',', $pairStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?>x</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>

                    <div class="combo-card">
                        <h2>Best Lotto Plus 2 Number Triplets</h2>
                        <p style="font-size: 0.9rem; color: #64748b; margin-top: 0; margin-bottom: 16px;">Triplets most frequently drawn together.</p>
                        <ul class="combo-list">
                            <?php foreach ($topTriplets as $tripStr => $count): 
                                $nums = explode(',', $tripStr);
                            ?>
                            <li>
                                <div class="combo-numbers">
                                    <span class="combo-ball"><?php echo $nums[0]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[1]; ?></span>
                                    <span class="combo-ball"><?php echo $nums[2]; ?></span>
                                </div>
                                <span class="combo-freq">Drawn <?php echo $count; ?>x</span>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>

                <section class="explanation-box">
                    <h2>Understanding Lotto Plus 2 Number Trends</h2>
                    <p>When studying the latest statistics for the 52-ball machine, it is highly recommended to build tickets combining both ends of the mathematical spectrum.</p>
                    <ul>
                        <li><strong>Hot Numbers (Frequent):</strong> These are balls that have exited the machine more often than the statistical average dictates recently. </li>
                        <li><strong>Cold Numbers (Overdue):</strong> Due to the Law of Large Numbers, all 52 balls should technically be drawn equally over infinite time. Cold numbers are currently lagging behind expected probability and are considered mathematically overdue.</li>
                        <li><strong>Trending Variance:</strong> Pay close attention to "Trending" numbers. A ball might be generally cold over the entire 100 draws, but extremely "Hot" in the very recent past.</li>
                    </ul>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">Lotto Plus 2 Numbers FAQ</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section class="modern-internal-links">
                    <h2>Enhance Your Lottery Strategy</h2>
                    <p style="color: #64748b; margin-bottom: 20px;">Mix these hot and cold numbers alongside our other statistical tools to build a balanced ticket.</p>
                    <ul class="nav-pills">
                        <li><a href="/results/lotto-plus-2/predictions">Lotto Plus 2 Predictions for Today</a></li>
                        <li><a href="/results/lotto-plus-2">Latest Lotto Plus 2 Results</a></li>
                        <li><a href="/results/lotto-plus-2/history">100-Draw History Archive</a></li>
                        <li><a href="/results/lotto-plus-2/generator">Random Number Generator</a></li>
                    </ul>
                </section>
                
                <section class="modern-internal-links" style="margin-top: 20px;">
                    <h2>Explore Other Lottery Trends</h2>
                    <p style="color: #64748b; margin-bottom: 20px;">Check the hot and cold statistical trends for other major South African lotteries.</p>
                    <ul class="nav-pills">
                        <li><a href="/results/powerball/hot-cold">PowerBall Hot Numbers</a></li>
                        <li><a href="/results/lotto/hot-cold">Lotto Hot Numbers</a></li>
                        <li><a href="/results/daily-lotto/hot-cold">Daily Lotto Hot Numbers</a></li>
                    </ul>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lotto Plus 2 navigation">
                    <div class="sidebar-menu-header">Lotto Plus 2 Panel</div>
                    <ul class="sidebar-links">
                        <li><a href="/results/lotto-plus-2">Latest Results</a></li>
                        <li><a href="/results/lotto-plus-2/history">Draw History</a></li>
                        <li><a href="/results/lotto-plus-2/predictions">Smart Predictions</a></li>
                        <li><a href="/results/lotto-plus-2/check-tickets">Check Tickets</a></li>
                        <li><a href="/results/lotto-plus-2/hot-cold" class="active">Hot & Cold Numbers</a></li>
                        <li><a href="/results/lotto-plus-2/payouts">Prize Payouts</a></li>
                        <li><a href="/how-to-play">How to Play</a></li>
                        <li><a href="https://affiliates.hollywoodbets.net/" class="highlight" target="_blank" rel="noopener nofollow">Play Online &rarr;</a></li>
                    </ul>
                </nav>
            </aside>
            
        </div>
    </main>

    <?php include __DIR__ . '/../../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    faqItem.classList.toggle('active');
                });
            });

            // Chart.js Rendering
            const ctx = document.getElementById('hotChart');
            if (ctx) {
                const chartLabels = <?php echo json_encode(array_map(function($val){ return "Ball " . $val; }, $chartLabels)); ?>;
                const chartData = <?php echo json_encode($chartData); ?>;

                new Chart(ctx.getContext('2d'), {
                    type: 'bar',
                    data: {
                        labels: chartLabels,
                        datasets: [{
                            label: 'Times Drawn (Last 100 Draws)',
                            data: chartData,
                            backgroundColor: '#7c3aed', // Purple theme for chart
                            borderRadius: 4,
                            hoverBackgroundColor: '#5b21b6'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                backgroundColor: '#1e293b',
                                padding: 12,
                                titleFont: { family: 'Inter', size: 14 },
                                bodyFont: { family: 'Inter', size: 13 }
                            }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                grid: { color: '#f1f5f9' },
                                ticks: { precision: 0, font: { family: 'Inter' } }
                            },
                            x: {
                                grid: { display: false },
                                ticks: { font: { family: 'Inter', weight: 'bold' } }
                            }
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>