<?php
// Set timezone
date_default_timezone_set('Africa/Johannesburg');

// --- SEO METADATA ---
$pageTitle = "Smart Ticket Checker | Verify SA Lottery Numbers | NextDrawLogic";
$metaDesc = "Instantly check your South African lottery tickets. Select your game to verify your numbers for PowerBall, Lotto, and Daily Lotto against official Ithuba draw results.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Ticket Checker", "url" => $currentUrl]
];

// --- PAGE SPECIFIC FAQs FOR SEO ---
$pageFaqs = [
    [
        "question" => "How far back does the ticket checker search?",
        "answer" => "Our smart ticket checker scans the last 100 official draws for your selected game. This covers several months of historical gameplay to ensure you haven't missed a recent payout."
    ],
    [
        "question" => "Does this checker claim my winnings automatically?",
        "answer" => "No. This tool is strictly informational. To legally claim your prize, you must present the original winning ticket to an authorized National Lottery retailer, claim via your banking app, or visit a regional Ithuba office for major jackpots."
    ],
    [
        "question" => "Can I check older tickets?",
        "answer" => "If you need to verify a ticket that is older than 100 draws, you can browse our comprehensive Results Archive pages to manually check the historical draw data."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="keywords" content="check lotto ticket online, verify sa lottery numbers, check powerball numbers south africa, daily lotto ticket checker">
    
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $currentUrl; ?>">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
    
    <style>
        /* Base site styles */
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* --- CENTERING & LAYOUT --- */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* --- SIDEBAR STYLES (NON-STICKY) --- */
        .lotto-sidebar { position: relative; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover { background: #f8fafc; color: #0f172a; border-left-color: #94a3b8; }
        .sidebar-links a.active { background: #f8fafc; color: #3b82f6; border-left-color: #3b82f6; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* --- HUB HEADER --- */
        .hub-header { margin-bottom: 40px; }
        .hub-header h1 { font-size: 2.4rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; }
        .hub-header p { font-size: 1.1rem; color: #475569; line-height: 1.6; margin: 0; }

        /* --- MODERN UL GRID CARDS --- */
        .checker-hub-list { 
            list-style: none; 
            padding: 0; 
            margin: 0 0 48px 0; 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 20px; 
        }

        .hub-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: inherit;
            box-shadow: 0 2px 4px -1px rgba(0,0,0,0.02);
            position: relative;
            overflow: hidden;
        }

        .hub-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -2px rgba(0,0,0,0.04);
            border-color: #cbd5e1;
        }

        .game-icon {
            width: 54px; 
            height: 54px; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 1.4rem; 
            font-weight: 800; 
            color: white;
            flex-shrink: 0;
            z-index: 2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        /* Color Themes */
        .dl-bg { background: linear-gradient(135deg, #f59e0b, #d97706); } /* Gold */
        .pb-bg { background: linear-gradient(135deg, #e11d48, #9f1239); } /* Red */
        .pbp-bg { background: linear-gradient(135deg, #be123c, #881337); } /* Dark Red */
        .lt-bg { background: linear-gradient(135deg, #10b981, #047857); } /* Green */
        .lt1-bg { background: linear-gradient(135deg, #059669, #065f46); } /* Dark Green */
        .lt2-bg { background: linear-gradient(135deg, #047857, #064e3b); } /* Darker Green */

        .card-content { z-index: 2; }
        .card-content h2 { margin: 0 0 4px 0; font-size: 1.15rem; font-weight: 800; color: #0f172a; }
        .card-content p { margin: 0; font-size: 0.85rem; color: #64748b; line-height: 1.4; }
        
        .arrow { 
            margin-left: auto; 
            color: #cbd5e1; 
            font-size: 1.3rem; 
            transition: transform 0.3s ease, color 0.3s ease; 
            z-index: 2;
            font-weight: bold;
        }
        .hub-card:hover .arrow { 
            color: #0f172a; 
            transform: translateX(4px); 
        }

        /* --- SEO CONTENT SECTIONS --- */
        .seo-content-box { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-content-box h2 { margin-top: 0; font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 20px; }
        .seo-content-box h3 { font-size: 1.2rem; font-weight: 700; color: #1e293b; margin-top: 24px; margin-bottom: 12px; }
        .seo-content-box p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-heading-with-icon { display: flex; align-items: center; gap: 12px; margin-bottom: 16px; }
        .seo-heading-with-icon .icon { font-size: 1.8rem; line-height: 1; }

        /* --- FAQ SECTION --- */
        .faq-section { margin-bottom: 40px; }
        .faq-header { font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-left: 14px; border-left: 5px solid #3b82f6; line-height: 1.2; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #3b82f6; font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }

        @media(max-width: 1024px) {
            .layout-with-sidebar { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
        }
        @media(max-width: 768px) {
            .hub-header h1 { font-size: 2rem; }
            .checker-hub-list { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>

    <?php include __DIR__ . '/../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <header class="hub-header">
                    <h1>South African Lottery Ticket Checker</h1>
                    <p>Stop squinting at old newspapers or searching through endless lists of past results. Choose your game below to automatically verify your lucky numbers against our 100-draw certified database.</p>
                </header>

                <ul class="checker-hub-list">
                    
                    <li>
                        <a href="/check-tickets/daily-lotto/" class="hub-card">
                            <div class="game-icon dl-bg">DL</div>
                            <div class="card-content">
                                <h2>Check Daily Lotto</h2>
                                <p>Scan your 5 numbers for daily draw matches.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/check-tickets/powerball/" class="hub-card">
                            <div class="game-icon pb-bg">PB</div>
                            <div class="card-content">
                                <h2>Check PowerBall</h2>
                                <p>Verify your tickets for the massive Tuesday/Friday jackpots.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/check-tickets/powerball-plus/" class="hub-card">
                            <div class="game-icon pbp-bg">P+</div>
                            <div class="card-content">
                                <h2>Check PowerBall Plus</h2>
                                <p>Scan secondary draw numbers for additional payouts.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/check-tickets/lotto/" class="hub-card">
                            <div class="game-icon lt-bg">LT</div>
                            <div class="card-content">
                                <h2>Check Lotto</h2>
                                <p>Verify your classic 6-number combinations.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/check-tickets/lotto-plus-1/" class="hub-card">
                            <div class="game-icon lt1-bg">L1</div>
                            <div class="card-content">
                                <h2>Check Lotto Plus 1</h2>
                                <p>Check the Wednesday and Saturday Plus 1 draws.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/check-tickets/lotto-plus-2/" class="hub-card">
                            <div class="game-icon lt2-bg">L2</div>
                            <div class="card-content">
                                <h2>Check Lotto Plus 2</h2>
                                <p>Scan your final Plus 2 combinations instantly.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                </ul>

                <section class="seo-content-box">
                    <div class="seo-heading-with-icon">
                        <span class="icon">📂</span>
                        <h2>Your Trusted Ticket Verification Engine</h2>
                    </div>
                    <p>Whether you are checking <strong>Daily Lotto results yesterday</strong> or verifying a <strong>PowerBall ticket</strong> from weeks ago, NextDrawLogic provides the most accurate and responsive checking tool in South Africa. Our team ensures that every number processed by our smart ticket checker is validated directly against the official Ithuba draw database.</p>

                    <div class="seo-heading-with-icon" style="margin-top: 32px;">
                        <span class="icon">📈</span>
                        <h3>Why Check Previous Results Automatically?</h3>
                    </div>
                    <p>Smart players understand that manual checking leads to human error. It is incredibly easy to overlook a winning combination, especially in games with complex structures like Lotto Plus 1 and Plus 2, or PowerBall's dual-matrix system.</p>
                    <p>By using our automated engine, your custom input is scanned across <strong>100 historical datasets</strong> in milliseconds. We highlight matched balls in blue and bonus payouts in gold, ensuring you never leave unclaimed money on the table.</p>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/hot-and-cold-numbers/">Hot & Cold Hub</a></li>
                        <li><a href="/predictions/">Smart Predictions</a></li>
                        <li><a href="/results/">Results Archive</a></li>
                        <li><a href="/check-tickets/" class="active">Ticket Checker</a></li>
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    
                    // Close others
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    
                    // Toggle clicked
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>