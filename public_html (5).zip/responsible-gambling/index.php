<?php
$pageTitle = "Responsible Gambling South Africa | Next Draw Logic";
$metaDesc = "Lottery games should be fun. Find resources, toll-free helplines, warning signs, and information on responsible gambling in South Africa.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <link rel="stylesheet" href="/style/style.css">
    <style>
        /* Modern Wrapper & Layout */
        .legal-wrapper {
            padding: 60px 20px;
            background-color: #f8fafc;
            min-height: 100vh;
        }
        
        .page-header {
    position: unset !important;
    z-index: unset !important;
}


        .legal-container { 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 50px 60px; 
            background: #ffffff; 
            border-radius: 24px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0; 
            line-height: 1.8; 
            color: #475569; 
            font-size: 1.05rem;
        }

        .page-header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
        }

        .legal-container h1 { 
            font-size: 2.8rem; 
            color: #0f172a; 
            margin: 0 0 16px 0; 
            font-weight: 800; 
            letter-spacing: -0.03em;
        }

        .legal-container h2 { 
            font-size: 1.4rem; 
            color: #0f172a; 
            margin: 40px 0 16px 0; 
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .legal-container h2::before {
            content: '';
            display: block;
            width: 24px;
            height: 4px;
            background: #059669; /* Green accent for safety */
            border-radius: 4px;
        }

        /* Emergency Alert Box */
        .alert-box { 
            background: #fef2f2; 
            border: 1px solid #fecaca; 
            border-left: 6px solid #dc2626; 
            padding: 32px; 
            border-radius: 12px; 
            margin: 32px 0; 
            box-shadow: 0 4px 12px rgba(220, 38, 38, 0.05);
        }
        .alert-box h3 { color: #991b1b; margin-top: 0; font-size: 1.4rem; font-weight: 800; }
        .helpline { font-size: 1.8rem; font-weight: 800; color: #dc2626; display: block; margin: 16px 0; letter-spacing: 1px;}
        .alert-box p { color: #7f1d1d; margin-bottom: 0; }

        /* Contact Cards (Instead of lists) */
        .contact-card {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 20px 24px;
            border-radius: 12px;
            margin-bottom: 16px;
        }
        .contact-card a { color: #2563eb; font-weight: 700; text-decoration: none; }
        .contact-card a:hover { text-decoration: underline; }

        /* Custom List Base */
        .legal-container ul {
            list-style: none;
            padding: 0;
            margin: 24px 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .legal-container ul li {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 16px 20px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            color: #1e293b;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.2s ease;
        }

        /* Good List (Rules for Safe Play) */
        .good-list li:hover {
            border-color: #10b981; 
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.08);
            transform: translateX(4px); 
        }
        .good-list li::before {
            content: '✓';
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: #d1fae5;
            color: #059669;
            border-radius: 50%;
            margin-right: 16px;
            font-weight: 800;
            font-size: 1rem;
            flex-shrink: 0;
        }

        /* Warning List (Signs of a Problem) */
        .warning-list li:hover {
            border-color: #ef4444; 
            box-shadow: 0 4px 12px rgba(239, 68, 68, 0.08);
            transform: translateX(4px); 
        }
        .warning-list li::before {
            content: '!';
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: #fee2e2;
            color: #dc2626;
            border-radius: 50%;
            margin-right: 16px;
            font-weight: 800;
            font-size: 1.2rem;
            flex-shrink: 0;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .legal-wrapper { padding: 20px 10px; }
            .legal-container { padding: 30px 20px; border-radius: 16px; }
            .legal-container h1 { font-size: 2.2rem; }
            .helpline { font-size: 1.4rem; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../static/nav.php'; ?>

    <div class="legal-wrapper">
        <main class="legal-container">
            
            <header class="page-header">
                <h1>Responsible Gambling</h1>
                <p style="font-size: 1.15rem; color: #64748b; margin: 0 auto; max-width: 600px;">
                    At Next Draw Logic, we believe that playing the National Lottery should be an entertaining and enjoyable experience, never a financial burden.
                </p>
            </header>

            <div class="alert-box">
                <h3>Need Help Now?</h3>
                <p>If you or someone you know has a gambling problem, free, professional, and confidential help is available in South Africa 24/7.</p>
                <span class="helpline">📞 Toll-Free Helpline: 0800 006 008</span>
                <p>Or WhatsApp "HELP" to <strong>076 675 0710</strong></p>
            </div>

            <h2>Recognizing a Gambling Problem</h2>
            <p>Gambling addiction can affect anyone. It is important to be honest with yourself about your habits. You may be at risk if you experience any of the following:</p>
            <ul class="warning-list">
                <li>Spending more money or time on the lottery than you can afford or originally planned.</li>
                <li>Borrowing money, selling personal items, or using bill money to buy tickets.</li>
                <li>"Chasing losses"—playing more to try and win back money you have already lost.</li>
                <li>Lying to friends or family members about how much you play.</li>
                <li>Feeling anxious, irritable, or depressed when you are unable to gamble.</li>
            </ul>

            <h2>Rules for Safe Play</h2>
            <p>To keep the lottery fun and safe, we recommend following these standard responsible play guidelines:</p>
            <ul class="good-list">
                <li><strong>Entertainment Only:</strong> Treat lottery tickets as an entertainment expense, not a primary way to make money or an investment strategy.</li>
                <li><strong>Set a Strict Budget:</strong> Decide on a fixed amount you are willing to lose each month, and stick to it regardless of the jackpot size.</li>
                <li><strong>Play When Sober:</strong> Avoid buying tickets or making gambling decisions when under the influence of alcohol or experiencing emotional distress.</li>
                <li><strong>Take Breaks:</strong> If you find yourself obsessively checking numbers or playing every single draw, take a forced break for a few weeks.</li>
            </ul>

            <h2>Self-Exclusion Options</h2>
            <p>If you feel you are losing control, South Africa offers a <strong>National Responsible Gambling Programme (NRGP)</strong> self-exclusion process. This legal mechanism allows you to ban yourself from participating in licensed gambling activities for a minimum of six months.</p>
            <p>You can request self-exclusion directly through your online betting provider (such as Hollywoodbets or Betway), or by contacting the NRGP helpline.</p>

            <h2>Protection of Minors</h2>
            <p><strong>18+ Only:</strong> It is strictly illegal for anyone under the age of 18 to play the South African National Lottery or use online betting platforms.</p>
            <p>If you share your computer or mobile device with minors, we highly recommend using parental control software (such as NetNanny or CyberPatrol) to block access to gambling-related websites and apps.</p>

            <h2>National Resources (SARGF)</h2>
            <p>The South African Responsible Gambling Foundation (SARGF) offers free counseling, outpatient treatment, and support for problem gamblers and their families across the country.</p>
            
            <div class="contact-card">
                <strong>🌐 Official Website:</strong> <br>
                <a href="https://responsiblegambling.org.za/" target="_blank" rel="noopener nofollow">responsiblegambling.org.za</a>
            </div>
            
            <div class="contact-card">
                <strong>✉️ Email Support:</strong> <br>
                <a href="mailto:helpline@responsiblegambling.org.za">helpline@responsiblegambling.org.za</a>
            </div>

        </main>
    </div>

    <?php include __DIR__ . '/../static/footer.php'; ?>
</body>
</html>