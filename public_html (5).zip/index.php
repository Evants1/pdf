<?php
/**
 * Homepage - completely independent layout.
 * Order: intro + featured article, Australian law notice, latest articles, guides, topics,
 * news and guides (only articles not already shown), editorial standards, responsible gambling, newsletter.
 * Article data comes from includes/content.php. The featured article is set by HERO_SLUG in includes/config.php.
 */
require __DIR__ . '/includes/functions.php';

$seo = [
    'title'       => 'GrandWhisper | Online Gambling Guides & News Australia',
    'raw_title'   => true,
    'description' => 'Online gambling guides, news and explainers for Australian readers: the law, bonuses, payments, withdrawals, safety and responsible gambling.',
    'path'        => '/',
    'body_class'  => 'is-home',
];

// Content is loaded defensively: an empty site must not cause a fatal error.
$all  = gw_articles();                                    // newest first
$hero = gw_article(HERO_SLUG) ?: ($all[0] ?? null);
if (!$hero) {
    http_response_code(503);
    exit('Homepage content is currently unavailable.');
}
$heroCat = gw_category($hero['category']);

// The featured article is not repeated in the grid. Every article is loaded once and reused below.
$latest = array_slice(array_values(array_filter($all, fn($a) => $a['slug'] !== $hero['slug'])), 0, 10);
$shown  = array_merge([$hero['slug']], array_column($latest, 'slug'));
$rest   = array_values(array_filter($all, fn($a) => !in_array($a['slug'], $shown, true)));
$news   = array_slice(array_values(array_filter($rest, fn($a) => $a['category'] === 'casino-news')), 0, 4);
$guides = array_slice(array_values(array_filter($rest, fn($a) => $a['category'] === 'casino-guides')), 0, 4);
$authors = gw_authors();

// LCP: preload the hero image (same files and sizes that gw_img() outputs for it).
$heroSrc = '/assets/images/articles/' . $hero['slug'];
$seo['head_extra'] = '<link rel="preload" as="image" href="' . e($heroSrc) . '.webp" imagesrcset="' . e($heroSrc) . '-600.webp 600w, ' . e($heroSrc) . '.webp 1200w" imagesizes="(min-width: 960px) 560px, 100vw" fetchpriority="high">';

// Structured data: this page is a collection of articles. Full Article markup stays on each article's own page.
$items = [];
foreach (array_merge([$hero], $latest) as $i => $a) {
    $items[] = ['@type' => 'ListItem', 'position' => $i + 1, 'url' => gw_abs('/' . $a['slug'] . '/'), 'name' => $a['title']];
}
$seo['schema'] = [[
    '@type'              => 'CollectionPage',
    '@id'                => gw_abs('/') . '#webpage',
    'url'                => gw_abs('/'),
    'name'               => 'Online Gambling Guides, News and Insights for Australia',
    'description'        => $seo['description'],
    'inLanguage'         => 'en-AU',
    'isPartOf'           => ['@id' => gw_abs('/') . '#website'],
    'publisher'          => ['@id' => gw_abs('/') . '#organization'],
    'primaryImageOfPage' => ['@type' => 'ImageObject', 'url' => gw_abs($heroSrc . '.jpg')],
    'mainEntity'         => ['@type' => 'ItemList', 'itemListElement' => $items],
]];

require __DIR__ . '/includes/header.php';
?>
<main id="main">

  <!-- Intro and featured article -->
  <section class="hero" aria-labelledby="home-title">
    <div class="wrap">
      <div class="hero-intro">
        <h1 id="home-title">Online Gambling Guides, News and Insights for Australia</h1>
        <p>Plain-English explainers on Australian gambling law, bonuses, payments, withdrawals and safer play.</p>
      </div>
      <div class="hero-grid">
        <div class="hero-copy">
          <p class="tag tag--<?= e($hero['category']) ?>"><a href="<?= e($heroCat['path']) ?>"><?= e($heroCat['label']) ?></a></p>
          <h2 class="hero-title"><a href="/<?= e($hero['slug']) ?>/"><?= e($hero['title']) ?></a></h2>
          <p class="hero-dek"><?= e($hero['description']) ?></p>
          <p class="hero-meta">
            <span>Editor's pick</span>
            <span>Published <time datetime="<?= e($hero['date']) ?>"><?= e(gw_date($hero['date'])) ?></time></span>
            <span><?= (int) $hero['minutes'] ?> min read</span>
          </p>
          <div class="hero-actions">
            <a class="btn btn--ruby" href="/<?= e($hero['slug']) ?>/">Read the article<span class="sr">: <?= e($hero['title']) ?></span></a>
            <a class="hero-all" href="/category/casino-guides/">All our guides and explainers</a>
          </div>
        </div>
        <figure class="hero-art">
          <?= gw_img('articles/' . $hero['slug'], $hero['alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 560px, 100vw']) ?>
        </figure>
      </div>
    </div>
  </section>

  <!-- Australian law notice -->
  <section class="au-notice" aria-label="Australian law notice">
    <div class="wrap">
      <p><strong>Reading from Australia?</strong> Under the Interactive Gambling Act 2001, online casino games, including online pokies, are prohibited services that cannot lawfully be offered to people in Australia, and the Australian Communications and Media Authority (ACMA) enforces this. Licensed Australian operators may offer online sports and racing wagering. Nothing on this site is an invitation to use a prohibited service. Read <a href="/online-gambling-laws-in-australia/">what the law means for you</a>, or see the <a href="https://www.acma.gov.au" rel="noopener">ACMA website</a> for official guidance.</p>
    </div>
  </section>

  <!-- Latest articles (featured article excluded) -->
  <section class="section" aria-labelledby="latest-title">
    <div class="wrap">
      <div class="section-head">
        <h2 id="latest-title">Latest articles</h2>
        <p>Our newest explainers, written to help you understand the fine print.</p>
      </div>
      <div class="latest-grid">
<?php foreach ($latest as $i => $a):
        $variant = $i === 0 ? 'feature' : ($i <= 2 ? 'side' : ($i <= 5 ? 'std' : 'mini'));
        echo gw_card($a, $variant);
      endforeach; ?>
      </div>
    </div>
  </section>

  <!-- Popular guides: the five permanent pages -->
  <section class="section section--tint" aria-labelledby="guides-title">
    <div class="wrap">
      <div class="section-head">
        <h2 id="guides-title">Popular casino guides</h2>
        <p>Five in-depth guides to read before you sign up to anything.</p>
      </div>
      <div class="gcards">
<?php foreach (gw_pages() as $p): ?>
        <article class="gcard">
          <a href="<?= e($p['path']) ?>" tabindex="-1" aria-hidden="true"><?= gw_img($p['image'], $p['alt'], ['sizes' => '(min-width: 1080px) 220px, (min-width: 640px) 33vw, 100vw']) ?></a>
          <div>
            <h3><a href="<?= e($p['path']) ?>"><?= e($p['title']) ?></a></h3>
            <p><?= e($p['summary']) ?></p>
          </div>
        </article>
<?php endforeach; ?>
      </div>
    </div>
  </section>

  <!-- Popular topics (hand-picked: refine it later using Google Search Console data) -->
  <section class="section" aria-labelledby="topics-title">
    <div class="wrap">
      <div class="section-head">
        <h2 id="topics-title">Explore popular gambling topics</h2>
        <p>Explore our latest explainers, industry insights and responsible gambling guides.</p>
      </div>
      <ul class="chips">
        <li><a href="/online-gambling-laws-in-australia/">Australian gambling law</a></li>
        <li><a href="/how-casino-welcome-bonuses-work/">Welcome bonuses</a></li>
        <li><a href="/what-affects-casino-withdrawal-speed/">Withdrawal speed</a></li>
        <li><a href="/kyc-verification-at-online-casinos/">ID verification</a></li>
        <li><a href="/crypto-casinos-explained-benefits-and-risks/">Crypto and gambling</a></li>
        <li><a href="/mobile-casino-gaming-apps-vs-browser/">Mobile play</a></li>
        <li><a href="/understanding-rtp-and-volatility-in-online-slots/">RTP and volatility</a></li>
        <li><a href="/live-dealer-casino-games-how-they-work/">Live dealer games</a></li>
        <li><a href="/responsible-gambling-tools-limits-and-self-exclusion/">Limits and self-exclusion</a></li>
        <li><a href="/safe-and-trusted-online-casinos/">Safe and trusted operators</a></li>
      </ul>
    </div>
  </section>

  <!-- More news and guides: only articles not already shown above; falls back to category links -->
<?php if ($news || $guides): ?>
  <section class="section section--tint" aria-label="More from each category">
    <div class="wrap duo">
<?php foreach ([['More casino news', $news, '/category/casino-news/', 'All casino news'], ['More casino guides', $guides, '/category/casino-guides/', 'All casino guides']] as [$heading, $list, $href, $linkText]): if (!$list) continue; ?>
      <div>
        <h2><?= e($heading) ?></h2>
        <ul class="rows">
<?php foreach ($list as $a): ?>
          <li>
            <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'], 'j M Y')) ?></time>
            <div><a href="/<?= e($a['slug']) ?>/"><?= e($a['title']) ?></a></div>
            <p><?= e($a['excerpt']) ?></p>
          </li>
<?php endforeach; ?>
        </ul>
        <p class="rows-more"><a href="<?= e($href) ?>"><?= e($linkText) ?></a></p>
      </div>
<?php endforeach; ?>
    </div>
  </section>
<?php else: ?>
  <section class="section section--tint" aria-labelledby="browse-title">
    <div class="wrap">
      <div class="section-head">
        <h2 id="browse-title">Browse the archive</h2>
        <p>Every article we have published, grouped by type.</p>
      </div>
      <div class="cat-links">
<?php foreach (gw_categories() as $slug => $c): ?>
        <a class="cat-link" href="<?= e($c['path']) ?>">
          <?= gw_img($c['image'], $c['alt'], ['sizes' => '(min-width: 960px) 260px, 40vw']) ?>
          <span><strong><?= e($c['label']) ?></strong><?= e($c['description']) ?></span>
        </a>
<?php endforeach; ?>
      </div>
    </div>
  </section>
<?php endif; ?>

  <!-- Editorial team (real authors only) or research standards -->
  <section class="section" aria-labelledby="editorial-title">
    <div class="wrap">
<?php if ($authors): ?>
      <div class="section-head">
        <h2 id="editorial-title">Meet our editorial team</h2>
        <p>The people who research, write and check what we publish.</p>
      </div>
      <div class="team">
<?php foreach ($authors as $au): ?>
        <article class="member">
          <h3><?php if (!empty($au['url'])): ?><a href="<?= e($au['url']) ?>"><?= e($au['name']) ?></a><?php else: ?><?= e($au['name']) ?><?php endif; ?></h3>
          <p class="member-role"><?= e($au['role'] ?? '') ?></p>
          <p><?= e($au['bio'] ?? '') ?></p>
        </article>
<?php endforeach; ?>
      </div>
<?php else: ?>
      <div class="section-head">
        <h2 id="editorial-title">How we research our content</h2>
        <p>The standards we aim to meet for every guide and explainer we publish.</p>
      </div>
<?php endif; ?>
      <div class="process">
        <div>
          <h3>Start from official sources</h3>
          <p>Legal and licensing points are checked against regulators such as ACMA and the relevant state and territory authorities, and we link to them so you can verify them.</p>
        </div>
        <div>
          <h3>Dated and corrected</h3>
          <p>Every article shows when it was published and last updated. If you spot a mistake, <a href="/contact/">tell us</a> and we will fix it.</p>
        </div>
        <div>
          <h3>Method and disclosure</h3>
          <p>Our <a href="/online-casino-reviews/">review method</a> is published, and our <a href="/about/#disclosure">affiliate disclosure</a> explains how the site is funded.</p>
        </div>
      </div>
    </div>
  </section>

  <!-- Responsible gambling resources -->
  <section class="rg-band" aria-labelledby="rg-title">
    <div class="wrap rg-band-in">
      <div>
        <h2 id="rg-title">Responsible gambling resources</h2>
        <p>Gambling carries real risk and can be addictive. If it is causing you or someone close to you harm, free and confidential help is available around the clock.</p>
      </div>
      <ul class="rg-list">
        <li><strong>Gambling Help Online</strong> 1800 858 858, or <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a></li>
        <li><strong>BetStop</strong> national self-exclusion register for licensed wagering: <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a></li>
        <li><strong>Our tools guide</strong> <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Limits, time-outs and self-exclusion explained</a></li>
        <li><strong>More support</strong> <a href="/responsible-gambling/">Responsible gambling page</a></li>
      </ul>
    </div>
  </section>

  <!-- Newsletter (optional: delete this block to remove it) -->
  <section class="newsletter" id="newsletter" aria-labelledby="nl-title">
    <div class="wrap newsletter-in">
      <div>
        <h2 id="nl-title">One email when we publish something worth reading</h2>
        <p>New guides and explainers, nothing else. Unsubscribe whenever you like.</p>
      </div>
      <form class="nl-form" action="/subscribe/" method="post">
        <label class="sr" for="nl-email">Email address</label>
        <input id="nl-email" type="email" name="email" placeholder="you@example.com" autocomplete="email" maxlength="120" required>
        <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
        <button class="btn btn--ruby" type="submit">Subscribe</button>
        <p class="nl-fine">By subscribing you agree to our <a href="/privacy-policy/">privacy policy</a>. You must be 18 or over.</p>
      </form>
    </div>
  </section>

</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
