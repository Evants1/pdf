<?php
/**
 * Newsletter sign-up handler (served at /subscribe/). Stores addresses in data/subscribers.csv
 * (the data/ folder is blocked from the web by its own .htaccess). Delete the newsletter block on the homepage
 * and this file if you do not want a newsletter. For a production newsletter, connect a proper email service.
 */
require __DIR__ . '/includes/functions.php';

$state = 'form';   // form | ok | error
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim((string) ($_POST['email'] ?? ''));
    if (!empty($_POST['website'])) {
        $state = 'ok';   // honeypot: pretend success
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) || strlen($email) > 120) {
        $state = 'error';
        $message = 'That email address does not look right. Please check it and try again.';
    } else {
        $file = __DIR__ . '/data/subscribers.csv';
        $existing = is_readable($file) ? file_get_contents($file) : '';
        if (stripos((string) $existing, '"' . strtolower($email) . '"') !== false) {
            $state = 'ok';   // already subscribed
        } else {
            $line = '"' . strtolower(str_replace('"', '', $email)) . '","' . gmdate('c') . '"' . "\n";
            if (@file_put_contents($file, $line, FILE_APPEND | LOCK_EX) !== false) {
                $state = 'ok';
            } else {
                $state = 'error';
                $message = 'Sorry, we could not save your sign-up just now. Please try again later.';
            }
        }
    }
}

$seo = [
    'title'       => 'Newsletter Sign-up',
    'description' => 'Subscribe to the GrandWhisper newsletter for new casino guides and explainers.',
    'path'        => '/subscribe/',
    'robots'      => 'noindex,follow',
    'body_class'  => 'is-doc',
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <div class="wrap search-page">
    <h1>Newsletter</h1>
<?php if ($state === 'ok'): ?>
    <p class="alert alert--ok" role="status">Thank you, you are on the list. We will email you when we publish something new.</p>
    <p><a href="/">Back to the magazine</a></p>
<?php else: ?>
<?php if ($state === 'error'): ?>
    <p class="alert alert--err" role="alert"><?= e($message) ?></p>
<?php endif; ?>
    <p>New guides and explainers by email, nothing else. You must be 18 or over.</p>
    <form class="form" action="/subscribe/" method="post">
      <div class="field">
        <label for="s-email">Email address</label>
        <input id="s-email" type="email" name="email" maxlength="120" autocomplete="email" required>
      </div>
      <div class="hp" aria-hidden="true"><label>Leave this empty <input type="text" name="website" tabindex="-1" autocomplete="off"></label></div>
      <button class="btn btn--ruby" type="submit">Subscribe</button>
      <p class="calc-fine">See our <a href="/privacy-policy/">privacy policy</a>.</p>
    </form>
<?php endif; ?>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>
