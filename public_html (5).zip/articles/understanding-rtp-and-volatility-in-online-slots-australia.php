<?php
/**
 * Article: Understanding RTP and Volatility in Online Slots Australia
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the "RTP and volatility together" section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('understanding-rtp-and-volatility-in-online-slots-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#how-rtp-works">How pokies RTP works</a></li>
            <li><a href="#volatility">Slot volatility explained</a></li>
            <li><a href="#together">RTP and volatility together</a></li>
            <li><a href="#australia">RTP in Australia</a></li>
            <li><a href="#check">How to check a game</a></li>
            <li><a href="#budget">Budget and limits</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#checks">Three checks before you play</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>RTP and volatility are the two figures that describe how a pokie behaves, and they measure different things. RTP (return to player) is the share of all money staked that a game is designed to pay back over the long run. Volatility describes how that money comes back: as a steady trickle of small wins, or as rare, large hits with long dry stretches in between.</p>
      <div class="vs">
        <div class="vs-col">
          <h3>RTP: how much comes back</h3>
          <ul>
            <li>The share of all money staked that a game is designed to pay back</li>
            <li>Measured over the long run</li>
          </ul>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Volatility: how it comes back</h3>
          <ul>
            <li>A steady trickle of small wins, or rare large hits</li>
            <li>A rough label, not a precise measurement</li>
          </ul>
        </div>
      </div>
      <p>Neither tells you what will happen tonight. RTP is calculated over millions of spins, and volatility is a rough label, not a precise measurement. Together, though, they let you estimate what a game costs to play on average and how hard your balance is likely to swing along the way.</p>
      <p>This guide turns the percentages into dollars per hour, shows you how to check the figure inside the game itself, and sets out where venue and online pokies sit under Australian rules. One thing up front: every pokie, at every setting, is built to keep a share of what's staked.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>The house edge is 100% minus the RTP.</strong> At 96% RTP and $1,000 of total bets, the average cost is $40.</li>
          <li><strong>Volatility sets the swings,</strong> not the average cost. High volatility can empty a budget fast.</li>
          <li><strong>Check the RTP in the game's own info screen.</strong> The same pokie can run at several settings.</li>
          <li><strong>Set a loss limit and a time limit first.</strong> Every pokie is built to keep a share of what's staked.</li>
        </ul>
      </div>

      <h2 id="how-rtp-works">How pokies RTP works (and what it can't tell you)</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-how-it-works', 'Casino coin beside the title How Pokies RTP Works', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>RTP is a design figure. A game's maths model lists every possible outcome, what each one pays and how likely it is. Add it all up and you get the percentage of total stakes the game returns as prizes in the long run. A random number generator picks the outcome of each spin, so the percentage only emerges across an enormous number of results.</p>
      <h3>RTP and house edge in dollars</h3>
      <p>The house edge is 100% minus the RTP. A game with a 96% RTP has a 4% house edge. As an illustration: across a very large number of spins, for every $100 staked the game pays back $96 on average and keeps $4.</p>
      <p>The word that matters is staked, not deposited. Start with $100, keep playing your wins back through the machine, and you might stake $500 or $1,000 in total before you finish. The edge applies to every dollar that passes through. At a 4% edge, $1,000 of total bets costs $40 on average, all of it coming out of that original $100. This is why a '96%' game can still empty a $100 balance in an evening.</p>
      <h3>Why your session rarely matches the percentage</h3>
      <p>RTP is measured over a very large number of spins, typically millions. A session of a few hundred spins is a tiny sample, and a small sample can land almost anywhere. You might lose your whole budget. You might finish ahead.</p>
      <p>Sessions stray from the figure for another reason. A big slice of a game's RTP is often tied up in events that rarely happen, such as top prizes and bonus features. If those don't land while you're playing, your personal return will sit below the published number, sometimes well below.</p>
      <p>So RTP tells you the long-run price of playing. It can't tell you how often you'll win, how large the wins will be or how long your balance will last. That's the job of volatility.</p>
      <p class="see-also">For how to find a higher-RTP game, see <a href="/high-rtp-slots-australia/">high-RTP slots in Australia</a>.</p>

      <h2 id="volatility">Slot volatility explained: low, medium and high</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-volatility', 'Chart with a warning mark beside the title Slot Volatility Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Volatility, sometimes called variance, describes how spread out a game's results are. Two pokies can return the same percentage overall while paying it out in completely different patterns.</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Volatility shapes how often and how big a pokie pays, not how much it returns overall.</caption>
      <thead><tr><th scope="col">Volatility</th><th scope="col">Win pattern</th><th scope="col">Balance swings</th><th scope="col">Who it suits</th></tr></thead>
      <tbody>
      <tr><th scope="row">Low</th><td>Frequent small wins, many of them close to or below your stake</td><td>Gentle. Balance tends to drift down slowly</td><td>Smaller budgets, longer sessions, players who dislike long losing runs</td></tr>
      <tr><th scope="row">Medium</th><td>Regular small wins with occasional mid-sized hits</td><td>Moderate ups and downs</td><td>Players who want some chance of a bigger feature without long droughts</td></tr>
      <tr><th scope="row">High</th><td>Long runs of losing spins, with much of the return concentrated in rare large wins</td><td>Sharp. Balance can fall fast and occasionally jump</td><td>Players with a budget they are fully prepared to lose, who accept a session may end quickly with nothing</td></tr>
      </tbody>
      </table>
      </div>
      <h3>What each level feels like on your balance</h3>
      <p>On a low-volatility game, something comes back on a good share of spins, which stretches your playing time. Watch what those wins are worth, though. A $1 spin that returns 40 cents is celebrated with lights and sound, but it is a 60-cent loss. Researchers call these 'losses disguised as wins', and low-volatility games produce plenty of them.</p>
      <p>On a high-volatility game, you can sit through dozens of spins with nothing meaningful coming back. The design relies on a bonus round or a big symbol combination to deliver most of the return, and many sessions end before that happens. The occasional large win is real, but it is funded by all the sessions that ended empty.</p>
      <h3>Hit frequency and max win: the clues behind the label</h3>
      <p>Each studio sets its own volatility labels, and there is no standard scale. One developer's 'medium' can play like another's 'high'. Some use words, others a 1 to 5 or 1 to 10 rating, and venue machines usually carry no volatility label at all. Treat the label as a hint and look for the clues behind it:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Clue</p>
          <h3>Hit frequency</h3>
          <p>How often a spin returns anything at all, where the studio publishes it. A lower hit frequency generally points to higher volatility.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Clue</p>
          <h3>Maximum win</h3>
          <p>A top prize advertised as a very large multiple of your stake means much of the return is locked up in rare outcomes.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Clue</p>
          <h3>Paytable shape</h3>
          <p>A wide gap between the top symbol and the low symbols suggests bigger swings.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Clue</p>
          <h3>Feature dependence</h3>
          <p>If the base game pays little and the bonus round carries most of the return, expect long gaps between meaningful wins.</p>
        </article>
      </div>
      <p class="see-also">Themes, paylines and features are covered in <a href="/pokies-and-slots-australia-rtp-themes-paylines/">pokies and slots in Australia: RTP, themes and paylines</a>.</p>

      <h2 id="together">How RTP and volatility work together</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-together', 'Payment list with a clock beside the title RTP and Volatility Together', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Think of RTP as the average and volatility as the spread around it. RTP sets the long-run cost of playing. Volatility decides how far any single session is likely to land from that cost, in either direction.</p>
      <h3>Same RTP, very different sessions</h3>
      <p>Picture two games with an identical RTP, one low volatility and one high. A large group of people each play 200 spins at $1.</p>
      <p>On the low-volatility game, most players finish somewhat down and results cluster in a fairly narrow band. On the high-volatility game, results scatter. Many players finish well down or run out of money early, and a small number finish well ahead. Average everyone's results and the two groups have lost a similar amount. The percentage is the same, but the experience is not.</p>
      <h3>Working out your expected cost per hour</h3>
      <p>One line of arithmetic turns RTP into a rough hourly cost:</p>
      <p><strong>Expected cost per hour = stake per spin × spins per hour × house edge</strong></p>
      <p>The examples below assume 600 spins an hour, or one every six seconds. That pace is an assumption for illustration, not a measured figure, and yours may be faster or slower.</p>
      <ul class="checks">
        <li>$1 a spin × 600 spins × 4% house edge = $24 an hour on average</li>
        <li>$1 a spin × 600 spins × 10% house edge = $60 an hour on average</li>
        <li>$2.50 a spin × 600 spins × 4% house edge = $60 an hour on average</li>
      </ul>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">At a 4% house edge</p>
          <p class="ex-sum">$1 &times; 600 &times; 4%</p>
          <p class="ex-big">$24</p><p class="ex-lbl">an hour on average</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">At a 10% house edge</p>
          <p class="ex-sum">$1 &times; 600 &times; 10%</p>
          <p class="ex-big">$60</p><p class="ex-lbl">an hour on average</p>
        </div>
      </div>
      <p>These are long-run averages across huge numbers of players and hours, not forecasts for your session. Volatility widens the range around the average without changing it. On a low-volatility game, a typical hour will usually land reasonably near the figure. On a high-volatility game, the same hour could cost several times that amount or finish in front.</p>
      <p>The formula does show which levers you control: stake, speed and time. Halve your bet and you halve the expected cost. Play for half as long and you do the same.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="australia">Return to player in Australia: venue pokies vs online</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-australia', 'Shield with a tick beside the title RTP Rules in Australia Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Minimum returns in pubs, clubs and casinos</h3>
      <p>Gaming machines in pubs, clubs and casinos are regulated by the states and territories. Each jurisdiction sets a minimum return to player that machines must be designed to meet, and machines are tested before they are approved for use. The minimum differs between jurisdictions and can differ by venue type.</p>
      <p>Figures quoted around the web range from about 85% to 90% and are often unsourced. Go to the regulator for the current number where you live. In NSW that is Liquor & Gaming NSW, in Victoria the Victorian Gambling and Casino Control Commission, and in Queensland the Office of Liquor and Gaming Regulation. Other states and territories have their own equivalents.</p>
      <p>Keep two points in mind. The minimum is a floor, so an individual machine may be set higher. And it is a long-run design figure like any other RTP, not a promise about your session. Many venue machines have an information screen with game details, though what it shows depends on state rules.</p>
      <h3>Where online pokies stand under Australian law</h3>
      <p>The Interactive Gambling Act 2001 prohibits providing online casino-style games, including online pokies, to people in Australia. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces the Act.</p>
      <p>For RTP, the practical consequence is that there is no Australian licence for online pokies. No Australian regulator sets a minimum return for them, tests them or handles complaints if a site refuses to pay. Sites offering pokies to Australians operate from overseas and sit outside Australian consumer protections.</p>
      <p>Online games are commonly advertised with RTPs in the mid-90s. That figure is a marketing claim, not something guaranteed under any Australian standard, and the same game can run at lower settings (more on that below). This article isn't legal advice. For the current legal position, go to acma.gov.au.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="check">How to check a game's actual RTP and volatility</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-check', 'Checklist card beside the title Check the Real RTP of a Game', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Finding the figure in the info or help screen</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Open the game's menu.</strong> Look for an 'i', a question mark, a three-line icon or a paytable button.</li>
          <li><strong>Scroll through the rules or help pages.</strong> The figure is usually near the end, labelled 'RTP' or 'theoretical return to player'.</li>
          <li>Note the exact number and whether more than one is listed, for example separate figures for the base game, a jackpot or a feature buy.</li>
          <li><strong>Compare it with the figure on the studio's own website.</strong> If the studio lists a range or several values, the in-game screen tells you which version you have.</li>
          <li><strong>Treat numbers on review sites as unverified.</strong> They usually quote one version of the game, which may not be the one in front of you.</li>
        </ol>
      </div>
      <p>If you can't find an RTP anywhere in the game, you have no way of knowing what you're paying to play. That is a good reason to leave it alone.</p>
      <h3>Why the same pokie can have several RTP settings</h3>
      <p>Many studios build each game in several RTP versions and let the operator choose which one to run. The versions look identical, with the same graphics, features and name. Only the maths underneath differs.</p>
      <p>A couple of percentage points sounds minor until you look at it from the house-edge side. As an illustration, dropping from 96% to 94% lifts the edge from 4% to 6%. That makes the game 50% more expensive per hour on average, and nothing on screen tells you unless you open the info panel.</p>
      <h3>Jackpots and bonus buys</h3>
      <p>Progressive jackpots are funded by a slice of every bet, and the headline RTP often includes that contribution. Because almost nobody wins the jackpot, the return most players actually experience comes from the base game alone, which is lower. Some info screens list both figures, so read carefully. Jackpot games also tend to be more volatile.</p>
      <p>Bonus buys let you pay a multiple of your stake to trigger the feature straight away. The buy option often has its own stated RTP, which can differ from the base game. The bigger issue is speed. A purchase costing many times your normal bet pushes a large stake through in seconds, so both your expected cost per minute and the size of the swings go up sharply.</p>
      <p class="see-also">More on big prizes: <a href="/jackpot-pokies-australia/">jackpot pokies in Australia</a>.</p>

      <h2 id="budget">Matching volatility to your budget and setting limits</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-budget', 'Limit sliders beside the title Match Risk to Your Budget', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Budget, bet size and session length</h3>
      <p>Start with the money you can afford to lose and work backwards. Don't start with the game.</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Count your cushion.</strong> Budget divided by bet size tells you how many straight losing spins you can absorb. With $50, that is 50 spins at $1 or 250 spins at 20 cents.</li>
          <li><strong>Size down for high volatility.</strong> Long losing runs are a normal part of these games, so the same budget needs smaller bets to last. Even then, there is no guarantee a feature will land before the money runs out.</li>
          <li><strong>Don't raise bets to recover losses.</strong> No bet size changes the house edge. Bigger bets only increase your expected cost per hour.</li>
          <li><strong>Low volatility isn't cheap.</strong> Steady small wins keep you playing longer, and more spins means more total stakes for the edge to work on.</li>
        </ul>
      </div>
      <h3>Myths: 'due' machines and hot streaks</h3>
      <p>Every spin is random and independent of the one before. A machine that hasn't paid for hours is no more likely to pay on the next spin, and one that has just paid a large prize is no less likely to pay again. 'Hot' and 'cold' are patterns people spot in hindsight.</p>
      <p>RTP is not a quota the machine works towards within a session, so it never needs to 'catch up'. Time of day, how long you've been sitting there, stopping the reels early and switching machines make no difference to the odds.</p>
      <h3>Responsible gambling: 18+, limits and where to get help</h3>
      <div class="rg-card">
      <p>You must be 18 or over to gamble in Australia. Pokies are entertainment with a built-in cost, not a way to make money. Before you play:</p>
      <ul class="checks">
        <li>Set a money limit and a time limit, and stop when you hit either one.</li>
        <li>Only use money you can afford to lose. Never use rent, bill money or borrowed funds.</li>
        <li>Don't chase losses, and take regular breaks.</li>
        <li>Ask your venue about self-exclusion and limit-setting tools, which vary by state.</li>
      </ul>
      <p>If gambling is causing stress for you or someone close to you, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support 24 hours a day on <a href="tel:1800858858">1800 858 858</a>. <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, covers licensed Australian online and phone wagering providers. It does not cover venue pokies or offshore casino sites.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">RTP and volatility FAQ</h2>
      <div class="faq">
        <details>
          <summary>What is a good RTP for pokies?</summary>
          <p>There's no official benchmark. Higher is cheaper on average: a 96% game has a 4% house edge, a 90% game has 10%. What matters is the figure shown in the info screen of the version you're actually playing, compared with the alternatives available to you. Every setting still favours the house.</p>
        </details>
        <details>
          <summary>Is high volatility better than low volatility?</summary>
          <p>Neither is better. At the same RTP they cost the same on average. High volatility offers a small chance of a large win and a strong chance of losing your budget quickly. Low volatility gives steadier play with smaller wins. Choose by how much swing your budget and temperament can handle.</p>
        </details>
        <details>
          <summary>Does a higher RTP mean I'm more likely to win?</summary>
          <p>Not in any one session. A higher RTP lowers the average cost of each dollar staked over a very large number of spins. It doesn't tell you how often wins land or whether you'll finish ahead tonight. Short-term results are driven mostly by chance and by the game's volatility.</p>
        </details>
        <details>
          <summary>Do online pokies pay more than pub and club pokies?</summary>
          <p>You can't assume so. Venue pokies must meet a minimum return set by each state or territory. Online pokies can't lawfully be offered to people in Australia, so no Australian rule sets or checks their RTP, and the same game may run at different settings. Advertised figures aren't guaranteed.</p>
        </details>
        <details>
          <summary>Where can I find a pokie's RTP and volatility?</summary>
          <p>Open the game's info, help or paytable screen and look for 'theoretical return to player' or 'RTP'. The volatility rating, if the studio publishes one, is usually there or on the studio's own website. Venue machines generally show no volatility label. Treat figures on review sites as unverified.</p>
        </details>
      </div>

      <h2 id="checks">Three checks to make before you play</h2>
      <figure class="shot"><?= gw_img('articles/rtp26-checks', 'Dice and chips beside the title Three Checks Before You Play', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Read the RTP in the info screen.</strong> Use the number in the game itself, not one from a review. Subtract it from 100% to get the house edge, then run the cost-per-hour sum at your stake.</li>
          <li><strong>Note the volatility and what it means for your budget.</strong> Look past the label to the max win, paytable and features. The higher the volatility, the smaller your bet needs to be for the same budget, and the more likely a session ends with nothing.</li>
          <li><strong>Set a loss limit and a time limit first.</strong> Decide both before the first spin, while your head is clear, and walk away when you reach either.</li>
        </ol>
      </div>
      <p>RTP and volatility tell you the price and the pattern of a game. They can't tilt it in your favour. Every pokie is built to keep a share of the money staked, so the decisions that matter most are how much you stake, how long you play and when you stop.</p>
      <p><strong>Related reading:</strong> <a href="/high-rtp-slots-australia/">Top 10 High-RTP Slots Australia for Big Wins: What RTP Really Means</a>, <a href="/pokies-and-slots-australia-rtp-themes-paylines/">Best Pokies &amp; Slots Australia 2026: RTP, Themes &amp; Paylines Explained</a>, <a href="/jackpot-pokies-australia/">Pokies Australia 2026: Best Jackpot Slots &amp; Themes Explained</a>, <a href="/australian-players-top-10-casino-games-2026/">Australian Players’ Top 10 Casino Games 2026: Ten Popular Games Explained</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
