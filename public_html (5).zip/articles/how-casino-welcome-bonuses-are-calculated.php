<?php
/**
 * Article: How Casino Welcome Bonuses Are Calculated
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('how-casino-welcome-bonuses-are-calculated');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#match">Step 1: the bonus amount</a></li>
          <li><a href="#turnover">Step 2: the turnover you must bet</a></li>
          <li><a href="#cost">Step 3: the expected cost of betting it</a></li>
          <li><a href="#contribution">Step 4: game contribution</a></li>
          <li><a href="#mistakes">Common mistakes</a></li>
          <li><a href="#faq">Quick answers</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>The numbers in a welcome bonus advert are simple, but the numbers that decide its value are not shown. This guide walks through the arithmetic step by step with worked examples in Australian dollars. All figures are invented to keep the sums clear, and they do not describe any real casino or offer.</p>
      <p>How casino bonuses are calculated, the bonus percentage match and the wagering requirement calculation are three steps, and bonus value explained is the result.</p>

      <aside class="note">
      <p><strong>Australian readers.</strong> Online casino games cannot lawfully be offered to people in Australia under the Interactive Gambling Act 2001, and an offshore casino sits outside Australian dispute schemes. This is a maths explainer, not a recommendation to claim any bonus. See our guide to <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>
      </aside>

      <h2 id="match">Step 1: the bonus amount</h2>
      <p>A match bonus multiplies your deposit by a percentage, usually up to a maximum. A 100% match on a A$50 deposit gives a A$50 bonus. A 50% match on a A$100 deposit also gives A$50. If your deposit is above the maximum, only the capped amount is matched.</p>

      <h2 id="turnover">Step 2: the turnover you must bet</h2>
      <p>The wagering requirement is a multiple, and the base it applies to changes the answer. Turnover equals the multiple times the base.</p>
      <ul>
      <li><strong>Bonus only:</strong> multiple x bonus.</li>
      <li><strong>Deposit plus bonus:</strong> multiple x (deposit + bonus).</li>
      </ul>

      <h2 id="cost">Step 3: the expected cost of betting it</h2>
      <p>Every game keeps a small share of each bet over time, called the house edge, which is 100% minus the return to player (RTP). Expected cost is the turnover multiplied by that edge. Using a 4% edge, which means a 96% RTP, purely for illustration:</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Three hypothetical welcome bonuses</caption>
      <thead><tr><th scope="col">Offer</th><th scope="col">Bonus</th><th scope="col">Rollover and base</th><th scope="col">Turnover</th><th scope="col">Cost at 4%</th><th scope="col">Bonus minus cost</th></tr></thead>
      <tbody>
      <tr><th scope="row">A</th><td>A$50 (100% of A$50)</td><td>30x bonus</td><td>A$1,500</td><td>A$60</td><td>−A$10</td></tr>
      <tr><th scope="row">B</th><td>A$50 (100% of A$50)</td><td>30x deposit plus bonus (A$100)</td><td>A$3,000</td><td>A$120</td><td>−A$70</td></tr>
      <tr><th scope="row">C</th><td>A$50 (50% of A$100)</td><td>20x bonus</td><td>A$1,000</td><td>A$40</td><td>+A$10</td></tr>
      </tbody>
      </table>
      </div>
      <p>Offers A and B look identical in an advert, yet B asks for twice the betting and costs A$70 more on average. A short rule helps: with a bonus-only rollover, break-even is roughly 1 divided by the house edge, which is 25x at a 4% edge. Anything above that has a negative average value. The rule assumes full game contribution and no cash-out cap.</p>

      <h2 id="contribution">Step 4: game contribution</h2>
      <p>Not every bet counts in full. If pokies count 100% and table games count 10%, each A$10 table bet adds only A$1 towards the requirement. A A$1,500 requirement would then take A$15,000 of table betting, ten times the effort. Always check the contribution list for the games you play.</p>

      <h2 id="mistakes">Common mistakes</h2>
      <ul>
      <li>Comparing multiples without checking what they apply to.</li>
      <li>Ignoring expiry, so the requirement cannot be finished in time.</li>
      <li>Forgetting the maximum cash-out, which caps the best case.</li>
      <li>Treating an average as a promise. Real sessions vary widely around the average.</li>
      </ul>
      <p>Our <a href="/online-casino-bonuses/">bonuses guide</a> has a calculator that does steps 1 to 3 for you, and <a href="/how-casino-welcome-bonuses-work/">how casino welcome bonuses work</a> explains the terms in plain language. RTP is covered in <a href="/understanding-rtp-and-volatility-in-online-slots/">our RTP and volatility guide</a>.</p>

      <h2 id="faq">Quick answers</h2>
      <h3>Does a higher RTP game lower the cost?</h3>
      <p>Yes, on average. At a 98% RTP the edge is 2%, so the same A$1,500 turnover costs about A$30 instead of A$60. See <a href="/high-rtp-slots-australia/">high-RTP slots in Australia</a> for what RTP does and does not tell you.</p>
      <h3>Is a positive result a profit?</h3>
      <p>No. A positive average value is a smaller expected cost, not guaranteed winnings, and you still may not clear the requirement.</p>
      <p><strong>Related reading:</strong> <a href="/australian-casino-welcome-bonuses-comparison/">Australian Casino Welcome Bonuses 2026 Comparison: How the Main Types Compare</a>, <a href="/best-casino-bonuses-for-australian-players/">Best Bonuses for Australian Players 2026: Choosing One That Suits You</a>, <a href="/no-deposit-bonuses-australia/">No-Deposit Bonuses Australia: What “Free Money to Play” Really Costs</a>, <a href="/best-no-deposit-casino-offers-australia/">Best No-Deposit Casino Offers Australia Right Now: How to Spot a Good One</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
