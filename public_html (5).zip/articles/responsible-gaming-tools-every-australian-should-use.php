<?php
/**
 * Article: Responsible Gaming Tools Every Australian Should Use
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('responsible-gaming-tools-every-australian-should-use');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#table">The toolkit at a glance</a></li>
          <li><a href="#bank">Use your bank</a></li>
          <li><a href="#devices">Use your devices</a></li>
          <li><a href="#exclusion">Use the schemes that exist</a></li>
          <li><a href="#people">Use people</a></li>
          <li><a href="#plan">A one-evening plan</a></li>
          <li><a href="#faq">Quick answers</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>Most advice about responsible gambling points to the tools a casino provides. Those are useful, but they depend on the operator. This guide covers the tools you control yourself, which work whatever site or venue you use. It complements our guide to <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools, limits and self-exclusion</a>.</p>
      <p>Responsible gaming tools, gambling help tools Australia, a reality check tool and gambling blocking software sit in a toolkit that does not depend on any casino.</p>

      <aside class="note">
      <p><strong>Australian readers.</strong> Online casino games cannot lawfully be offered to people in Australia under the Interactive Gambling Act 2001, and an offshore casino sits outside Australian dispute schemes. Confirm every phone number and website below on the official sites, since services can change. See our guide to <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>
      </aside>

      <h2 id="table">The toolkit at a glance</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Tools you control, and what each does</caption>
      <thead><tr><th scope="col">Tool</th><th scope="col">What it does</th><th scope="col">Where</th></tr></thead>
      <tbody>
      <tr><th scope="row">Gambling Help Online</th><td>Free, confidential counselling and chat, for you or someone close to you</td><td>1800 858 858, gamblinghelponline.org.au</td></tr>
      <tr><th scope="row">BetStop</th><td>Self-exclusion from licensed Australian online and phone wagering</td><td>betstop.gov.au</td></tr>
      <tr><th scope="row">Bank gambling block</th><td>Blocks gambling-related payments, with lower transfer limits</td><td>Your banking app or branch</td></tr>
      <tr><th scope="row">Blocking software</th><td>Stops access to gambling websites and apps on your devices</td><td>App stores and software providers</td></tr>
      <tr><th scope="row">Budgeting help</th><td>Plans your spending and tracks it</td><td>ASIC's Moneysmart, moneysmart.gov.au</td></tr>
      <tr><th scope="row">Financial counselling</th><td>Free help with debt</td><td>National Debt Helpline, 1800 007 007</td></tr>
      <tr><th scope="row">Lifeline</th><td>Crisis support, 24 hours</td><td>13 11 14</td></tr>
      <tr><th scope="row">Peer support</th><td>Meetings with others who have been through it</td><td>Gamblers Anonymous Australia</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="bank">Use your bank</h2>
      <p>Your bank is the strongest tool you control. Ask about a gambling transaction block, a lower daily transfer limit including PayID, and alerts on every payment. Keeping entertainment money in a separate account makes a limit physical, not just a setting. Step-by-step help is in <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>.</p>

      <h2 id="devices">Use your devices</h2>
      <ul>
      <li>Install blocking software that covers gambling sites and apps.</li>
      <li>Delete casino apps, remove saved cards from your browser and phone wallet, and turn off marketing notifications.</li>
      <li>Use your phone's screen time settings to limit certain apps at night.</li>
      </ul>

      <h2 id="exclusion">Use the schemes that exist</h2>
      <p>BetStop and venue exclusion cover specific services, and neither covers offshore casinos. Our <a href="/self-exclusion-australia-guide/">self-exclusion guide</a> explains what each one reaches and how to combine them.</p>

      <h2 id="people">Use people</h2>
      <p>Gambling often grows in secret. Telling someone you trust, or speaking to a counsellor, breaks that cycle. Family and friends can also use these services to protect their own finances and wellbeing, and you do not need to wait for a crisis. If you are in distress, call Lifeline on 13 11 14, or 000 in an emergency. See also our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="plan">A one-evening plan</h2>
      <ol>
      <li>Call or chat with Gambling Help Online if you want to talk it through.</li>
      <li>Set up a gambling block and a lower transfer limit with your bank.</li>
      <li>Install blocking software and delete saved cards and apps.</li>
      <li>Register with BetStop if you bet with licensed Australian wagering providers.</li>
      <li>Tell one person you trust.</li>
      </ol>

      <h2 id="faq">Quick answers</h2>
      <h3>Which tool should I start with?</h3>
      <p>Call or chat with Gambling Help Online, and set up your bank's gambling block. Both take minutes.</p>
      <h3>Do casino limits count?</h3>
      <p>They help, but they depend on the operator, which is why the tools above matter. See <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools</a>.</p>
      <p><strong>Related reading:</strong> <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">Responsible Gambling Tools, Limits &amp; Self-Exclusion Australia</a>, <a href="/how-to-set-deposit-and-loss-limits-australia/">How to Set Deposit &amp; Loss Limits in Australian Casinos</a>, <a href="/self-exclusion-australia-guide/">Responsible Gambling Self-Exclusion Australia Guide</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
