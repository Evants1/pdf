<?php
/**
 * Article: Responsible Gambling Self-Exclusion Australia Guide
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('self-exclusion-australia-guide');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#betstop">BetStop: the national register</a></li>
          <li><a href="#venue">Venue exclusion</a></li>
          <li><a href="#operator">Operator-level exclusion</a></li>
          <li><a href="#table">What each option covers</a></li>
          <li><a href="#extra">Extra steps that help</a></li>
          <li><a href="#support">Support while you are excluded</a></li>
          <li><a href="#end">When an exclusion ends</a></li>
          <li><a href="#faq">Quick answers</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>Self-exclusion means asking to be stopped from gambling for a set time. It is a strong step, and in Australia there is no single scheme that covers everything. This guide explains the main options, what each one covers and what it does not, so you can combine them. For the wider picture, see <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools, limits and self-exclusion</a>.</p>
      <p>Self-exclusion Australia, BetStop and how to self-exclude from gambling are the questions this gambling self-exclusion guide answers.</p>

      <aside class="note">
      <p><strong>Australian readers.</strong> BetStop covers licensed Australian online and phone wagering. It does not cover online casino games or other services provided illegally in Australia, so offshore casinos need separate steps. Free, confidential support is on 1800 858 858.</p>
      </aside>

      <h2 id="betstop">BetStop: the national register</h2>
      <p>BetStop is a free Australian Government register. When you register, licensed Australian online and phone wagering providers must stop opening accounts for you, taking bets from you and sending you direct marketing for the period you choose, which ranges from three months up to permanent. Registration is done at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, and you may need to verify your identity.</p>
      <p><strong>Limit:</strong> it does not cover venue pokies or offshore casino websites.</p>

      <h2 id="venue">Venue exclusion</h2>
      <p>Pubs, clubs and casinos run exclusion programs that vary by state and territory. You can ask the venue or the state regulator how to enrol. These cover the venues in the program, not online services.</p>

      <h2 id="operator">Operator-level exclusion</h2>
      <p>Many online services, including offshore casinos, offer their own self-exclusion tool in account settings. These apply only to that one operator, depend on the operator keeping its promise and may not stop a second account elsewhere. Look for a site that makes the tool easy to find, and treat one that keeps contacting you after exclusion as a serious warning sign.</p>

      <h2 id="table">What each option covers</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Self-exclusion options compared</caption>
      <thead><tr><th scope="col">Option</th><th scope="col">Covers</th><th scope="col">Does not cover</th></tr></thead>
      <tbody>
      <tr><th scope="row">BetStop</th><td>Licensed Australian online and phone wagering</td><td>Venue pokies, offshore casinos</td></tr>
      <tr><th scope="row">Venue exclusion</th><td>The venues in the program</td><td>Online services, other venues</td></tr>
      <tr><th scope="row">Operator exclusion</th><td>That single operator</td><td>Other operators</td></tr>
      <tr><th scope="row">Bank gambling block</th><td>Card payments the bank can identify as gambling</td><td>Methods the bank cannot tell apart</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="extra">Extra steps that help</h2>
      <ul>
      <li><strong>Ask your bank</strong> about gambling transaction blocks and a lower daily transfer limit.</li>
      <li><strong>Use blocking software</strong> on your phone and computer.</li>
      <li><strong>Remove saved cards and apps,</strong> and unsubscribe from marketing.</li>
      <li><strong>Tell someone you trust,</strong> or contact a counsellor.</li>
      </ul>
      <p>Our guide to <a href="/how-to-set-deposit-and-loss-limits-australia/">setting deposit and loss limits</a> covers the bank steps in detail.</p>

      <h2 id="support">Support while you are excluded</h2>
      <p>Gambling Help Online offers free, confidential counselling and chat at gamblinghelponline.org.au and on 1800 858 858, 24 hours a day, including for family and friends. If you are in distress, Lifeline is on 13 11 14. Our <a href="/responsible-gambling/">responsible gambling page</a> lists support in one place.</p>

      <h2 id="end">When an exclusion ends</h2>
      <p>Think ahead about what you will do when the period finishes. Many people extend the exclusion, keep their bank block in place or speak to a counsellor first. If you choose to return to gambling at all, set limits before you play and tell someone you trust. Our guide to <a href="/how-to-set-deposit-and-loss-limits-australia/">setting deposit and loss limits</a> can help.</p>

      <h2 id="faq">Quick answers</h2>
      <h3>Does BetStop stop me using an offshore casino?</h3>
      <p>No. It covers licensed Australian wagering only, so use the extra steps above.</p>
      <h3>Can I end an exclusion early?</h3>
      <p>Schemes differ. Check the rules of the scheme before you enrol, and choose a period you can commit to.</p>
      <p><strong>Related reading:</strong> <a href="/responsible-gaming-tools-every-australian-should-use/">Responsible Gaming Tools Every Australian Should Use</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion-australia/">Responsible Gambling Tools, Limits &amp; Self-Exclusion Australia</a>, <a href="/how-to-set-deposit-and-loss-limits-australia/">How to Set Deposit &amp; Loss Limits in Australian Casinos</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
