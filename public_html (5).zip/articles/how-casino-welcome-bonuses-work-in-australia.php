<?php
/**
 * Article: How Casino Welcome Bonuses Work in Australia
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the wagering section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('how-casino-welcome-bonuses-work-in-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#how-it-works">How a welcome bonus works</a></li>
            <li><a href="#legal">Are bonuses legal in Australia?</a></li>
            <li><a href="#types">Types of welcome offers</a></li>
            <li><a href="#wagering">Wagering: the maths in AUD</a></li>
            <li><a href="#fine-print">The fine print</a></li>
            <li><a href="#judge">How to judge a bonus</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>A casino welcome bonus is extra funds or free spins credited when you make your first deposit at an online casino. It is not cash. It sits behind wagering requirements and other terms that decide whether you can ever withdraw the winnings. If you searched “casino welcome bonus Australia” and got pages of ranked offers with big headline amounts, this guide covers what those pages tend to skip: the mechanics, the maths in AUD and the law.</p>
      <p>One thing first. Under the Interactive Gambling Act 2001, providers are banned from offering online casino games to people in Australia. The offers you see come from offshore operators, and nothing here should be read as saying that playing with them is legal or safe. Gambling is for adults aged 18 and over, and no bonus guarantees a win.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>A welcome bonus is not cash.</strong> It sits behind wagering requirements that decide whether you can withdraw.</li>
          <li><strong>Every online casino offer comes from an offshore operator,</strong> because providers are banned from offering casino games to people in Australia.</li>
          <li><strong>Turn the multiplier into dollars:</strong> in the example, 35x on a $100 bonus is $3,500 of bets, or $7,000 if it applies to deposit plus bonus.</li>
          <li><strong>Declining the bonus is allowed,</strong> and it removes the bonus restrictions altogether.</li>
        </ul>
      </div>

      <h2 id="how-it-works">How a Casino Welcome Bonus in Australia Actually Works</h2>
      <figure class="shot"><?= gw_img('articles/welcome-how-it-works', 'Gift box beside the title How a Welcome Bonus Works', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Most welcome offers are match deposit bonuses. The operator adds a percentage of your first deposit as bonus funds, up to a stated cap. To illustrate, a 100% match on a $100 deposit adds $100 in bonus funds, so you start with $200 to play. A 50% match on the same deposit adds $50. You only reach the headline “up to” figure by depositing the maximum, and that is rarely a good reason to choose a deposit size.</p>
      <h3>From sign-up to bonus balance: the usual steps</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Register.</strong> You create an account with your name, date of birth and contact details.</li>
          <li><strong>Opt in.</strong> Depending on the site, you tick a box, select the offer in the cashier or enter a code. Miss this step and the bonus may not be added afterwards.</li>
          <li><strong>Make a qualifying deposit.</strong> It has to meet the minimum amount and use a payment method the offer accepts.</li>
          <li><strong>Receive the bonus.</strong> It is credited automatically or after you activate it. The terms state whether the expiry clock starts at crediting, activation or your first bet.</li>
          <li><strong>Play through the wagering.</strong> Bonus funds convert to withdrawable cash only once the requirement is met.</li>
        </ol>
      </div>
      <h3>Bonus money versus real money in your account</h3>
      <div class="vs">
        <div class="vs-col">
          <h3>Real money balance</h3>
          <ul>
            <li>Holds your deposits</li>
            <li>Holds winnings not tied to a bonus</li>
          </ul>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Bonus balance</h3>
          <ul>
            <li>Holds promotional funds</li>
            <li>Holds winnings they generate while wagering is open</li>
          </ul>
        </div>
      </div>
      <p>Your account will normally show two balances. The real money (or cash) balance holds your deposits and any winnings not tied to a bonus. The bonus balance holds promotional funds and, while wagering is still open, the winnings they generate.</p>
      <p>The terms set which balance is spent first, and that order matters a great deal (see sticky versus non-sticky below). Until wagering is complete, the bonus balance cannot be withdrawn, and asking for a withdrawal usually forfeits the bonus along with any winnings attached to it. A screen showing $200 does not mean you can take out $200.</p>
      <p>That is how welcome bonuses work in outline. What an offer is really worth depends on the details in the sections below.</p>

      <h2 id="legal">Are Online Casino Bonuses Legal in Australia?</h2>
      <figure class="shot"><?= gw_img('articles/welcome-legal', 'Shield with a tick beside the title Are Bonuses Legal in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act bans</h3>
      <p>The Interactive Gambling Act 2001 makes it illegal for providers to offer online casino-style games, such as online pokies, roulette and blackjack, to people in Australia. There is no Australian licence for online casinos, so a site calling itself an “Australian licensed casino” is misdescribing itself. AUD accounts, PayID deposits and local branding do not change that. Neither does a licence from an offshore jurisdiction. Online betting on sport and racing through providers licensed in an Australian state or territory is a separate, regulated category.</p>
      <p>The Act is generally described as targeting operators rather than individual players. That does not make playing legal or protected, and this article is not legal advice. The Australian Communications and Media Authority (ACMA) is the regulator and has the final word.</p>
      <h3>What that means if a dispute goes wrong</h3>
      <p>This is the practical risk. ACMA warns that people who use illegal offshore gambling services may not get their money back, and Australian regulators cannot recover it for them. If an operator voids your winnings over a bonus term, stalls a withdrawal or closes your account, no Australian body can order it to pay. You are left with the operator's own complaints process and whatever overseas licensing body it names. Don't count on either. The operator writes the bonus terms, and the operator interprets them.</p>
      <h3>How to check a site with ACMA</h3>
      <p>ACMA publishes two resources on <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a>: a register of licensed interactive wagering providers, and a list of illegal gambling services it has investigated and asked internet providers to block. Search the service's name in both. A site that is not on the blocked list is not legal for that reason alone, and an online casino will not appear on the wagering register at all. The rules are amended from time to time, so treat ACMA's pages as the current position.</p>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a> and <a href="/understanding-australian-online-gambling-regulations/">who regulates what in Australian online gambling</a>.</p>

      <h2 id="types">Types of Welcome Offers You Will See</h2>
      <figure class="shot"><?= gw_img('articles/welcome-types', 'Review card with a magnifying glass beside the title Welcome Offer Types Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Offers fall into a handful of types. The table shows how each is credited and the first thing to check. Amounts are left out on purpose, because they vary by operator and change often.</p>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Offer type</th><th scope="col">How it is credited</th><th scope="col">Main catch to check</th></tr></thead>
      <tbody>
      <tr><th scope="row">Match deposit bonus</th><td>Bonus funds equal to a percentage of your deposit, up to a cap</td><td>Whether wagering applies to the bonus only or to deposit plus bonus</td></tr>
      <tr><th scope="row">Multi-deposit package</th><td>Separate bonuses across your first several deposits</td><td>The headline total needs every deposit at the maximum; each stage has its own terms</td></tr>
      <tr><th scope="row">Free spins</th><td>A set number of spins on named pokies at a fixed stake, sometimes released in batches</td><td>Stake per spin, wagering on the winnings and any win cap</td></tr>
      <tr><th scope="row">No deposit bonus</th><td>A small credit or spins on registration or verification</td><td>Win cap, wagering and whether a deposit is needed before withdrawal</td></tr>
      <tr><th scope="row">Cashback</th><td>A percentage of net losses returned over a set period</td><td>Whether it is paid as cash or bonus funds, and how “net loss” is defined</td></tr>
      </tbody>
      </table>
      </div>
      <h3>Match deposit bonuses and multi-deposit packages</h3>
      <p>A single match bonus is the simplest to assess: one deposit, one bonus, one set of terms. Packages spread the offer over several deposits, and the advertised total assumes you make every one at the maximum. Each stage normally carries its own wagering and expiry, and you may need to finish or forfeit one stage before claiming the next. Judge a package on the first deposit alone, since that is the only part you are committing to.</p>
      <h3>Free spins, no deposit offers and cashback</h3>
      <p>Free spins are worth the number of spins multiplied by the stake per spin, which the terms should state. Winnings usually land in the bonus balance with wagering attached. No deposit offers let you try a site without paying in, but they tend to carry the tightest win caps and may still require a deposit and ID check before any withdrawal. Cashback returns part of your net losses, so check whether it arrives as cash or as more bonus funds.</p>
      <p class="see-also">Compare structures in <a href="/australian-casino-welcome-bonuses-comparison/">welcome bonuses compared</a>, read about <a href="/no-deposit-bonuses-australia/">no-deposit bonuses in Australia</a>, and match an offer to how you play in <a href="/best-casino-bonuses-for-australian-players/">best bonuses for Australian players</a>.</p>

      <h2 id="wagering">Welcome Bonus Wagering: The Maths in AUD</h2>
      <figure class="shot"><?= gw_img('articles/welcome-wagering', 'Casino coin beside the title Wagering Maths in AUD', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Welcome bonus wagering, also called playthrough or rollover, is the total amount you must bet before bonus funds and their winnings become withdrawable. It is written as a multiplier, such as 35x. That figure is turnover, not a loss. A $1 spin that wins $1 still counts as $1 wagered, and the same dollars can be bet many times.</p>
      <p>Wagering requirements multiply your bonus into the total you must bet before you can withdraw.</p>
      <h3>Bonus-only versus deposit-plus-bonus wagering</h3>
      <p>The multiplier means nothing until you know what it multiplies. Take a purely illustrative offer: a $100 deposit, a 100% match and 35x wagering.</p>
      <ul class="checks">
        <li>Bonus-only: 35 × $100 bonus = $3,500 in bets.</li>
        <li>Deposit plus bonus: 35 × $200 = $7,000 in bets.</li>
      </ul>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Bonus-only</p>
          <p class="ex-sum">35 &times; $100</p>
          <p class="ex-big">$3,500</p><p class="ex-lbl">in bets</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Deposit plus bonus</p>
          <p class="ex-sum">35 &times; $200</p>
          <p class="ex-big">$7,000</p><p class="ex-lbl">in bets: double the turnover</p>
        </div>
      </div>
      <p>Same headline, double the turnover. A lower multiplier can also be the harder offer: 25x on deposit plus bonus is $5,000 here, while 40x on the bonus alone is $4,000.</p>
      <h3>Game contribution: why pokies and table games count differently</h3>
      <p>Not every bet counts in full. The terms include a contribution table giving the percentage of each stake that counts toward wagering, by game type. Pokies commonly count in full. Table games, live dealer games and video poker often count at a reduced rate or not at all, and individual pokies can be excluded. Operators do this because games with a lower house edge would otherwise make the requirement cheaper to clear.</p>
      <p>As a hypothetical, if a game contributed 10%, a $10 bet would count as $1, and the $3,500 requirement above would take $35,000 in actual stakes.</p>
      <h3>Estimating what the wagering is likely to cost you</h3>
      <p>You can put a rough dollar figure on a requirement. Open the game's info or help screen and find its return to player (RTP). The house edge is 100% minus that figure, and the expected cost is roughly turnover multiplied by the house edge.</p>
      <p>Assume, only for the sake of the sum, that the info screen shows 96%. The house edge would be 4%, so $3,500 of turnover has an expected cost of about $140 and $7,000 about $280, against a $100 bonus. Use the figure shown in the game you actually play, because the same title can be configured differently from site to site.</p>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">Expected cost of $3,500</p>
          <p class="ex-sum">$3,500 &times; 4%</p>
          <p class="ex-big">about $140</p><p class="ex-lbl">against a $100 bonus</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">Expected cost of $7,000</p>
          <p class="ex-sum">$7,000 &times; 4%</p>
          <p class="ex-big">about $280</p><p class="ex-lbl">against a $100 bonus</p>
        </div>
      </div>
      <p>This is a long-run average, not a prediction. In a single session you might finish ahead or lose the whole balance well before the wagering is done, and high-volatility pokies widen that range. What the estimate does show is that a bonus does not improve your odds. The house edge applies to every bet, and a bonus simply means more bets.</p>
      <p class="see-also">To run the numbers on a real offer, use the calculator in our <a href="/online-casino-bonuses/">casino bonuses guide</a>, or see <a href="/how-casino-welcome-bonuses-are-calculated/">how casino welcome bonuses are calculated</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="fine-print">The Fine Print That Decides Whether You Can Withdraw</h2>
      <figure class="shot"><?= gw_img('articles/welcome-fine-print', 'Document with a magnifying glass beside the title The Fine Print That Decides', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>These clauses sit in the bonus or promotion terms, usually linked from the offer itself, and in the site's general terms and conditions. Read both. The general terms often hold the bonus abuse and withdrawal rules.</p>
      <h3>Maximum bet, time limits and win caps</h3>
      <div class="mini3">
        <div><h3>Maximum bet</h3><p>While a bonus is active there is a ceiling on the stake per spin or hand. A single bet above it can be enough for the operator to void the bonus and all winnings, and the breach is often raised only when your withdrawal is reviewed. Check whether feature buys or gamble features are restricted as well.</p></div>
        <div><h3>Time limits</h3><p>There is usually one deadline to claim the offer and another to finish the wagering. When the second expires, the bonus and attached winnings are removed. Divide the turnover by the days allowed to see what pace it demands.</p></div>
        <div><h3>Win caps</h3><p>A maximum cashout limits how much of your bonus winnings can convert to real money. Anything above it is deleted. Caps are especially common on free spins and no deposit offers.</p></div>
      </div>
      <h3>Sticky versus non-sticky bonuses</h3>
      <div class="vs">
        <div class="vs-col">
          <h3>Non-sticky</h3>
          <p>With a non-sticky bonus, your real money is played first and stays separate. If you win before your deposit runs out, you can usually cancel the bonus and withdraw, free of wagering. The bonus and its conditions only come into play once your own money is gone.</p>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Sticky</h3>
          <p>With a sticky bonus, deposit and bonus are locked together from the first bet, and nothing can be withdrawn until wagering is complete. In some versions the bonus amount itself is never withdrawable and is deducted at cashout. Sites use these labels inconsistently, so look for the clause describing the order in which balances are used and what happens if you withdraw early.</p>
        </div>
      </div>
      <h3>Payment method exclusions and ID checks</h3>
      <p>Offers often exclude certain deposit methods. Australians are typically shown PayID, cards, Neosurf vouchers and cryptocurrency, but no method is accepted or bonus-eligible everywhere, so check that yours qualifies before you deposit. Using an excluded method generally means no bonus. Also check how withdrawals are paid, since a voucher cannot receive money back. Card rules for licensed Australian wagering services are a separate matter and tell you nothing about an offshore site.</p>
      <p>Expect identity checks before a first withdrawal: photo ID, proof of address and proof you own the payment method. Mismatched names, a second account in the same household or VPN use are commonly listed as grounds to void winnings. Remember, too, that you are sending identity documents to a business outside Australian oversight.</p>
      <p class="see-also">More detail: <a href="/kyc-verification-at-online-casinos-australia/">KYC verification at online casinos in Australia</a>, <a href="/online-casino-payment-methods/">payment methods compared</a> and <a href="/how-casino-withdrawals-work-speed-and-limits/">how casino withdrawals work</a>.</p>

      <h2 id="judge">How to Judge a Sign Up Bonus Before You Deposit</h2>
      <figure class="shot"><?= gw_img('articles/welcome-checklist', 'Checklist card beside the title Judge a Sign Up Bonus', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>A seven-point terms checklist</h3>
      <p>The same seven questions work on any casino sign up bonus. Answer them from the written terms, not the banner.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Wagering base.</strong> Does the multiplier apply to the bonus only, or to deposit plus bonus?</li>
          <li><strong>Multiplier.</strong> Multiply it by the base to get total turnover in dollars.</li>
          <li><strong>Expiry.</strong> How many days do you have, and when does the clock start?</li>
          <li><strong>Maximum bet.</strong> What is the stake limit per spin or hand while the bonus is active?</li>
          <li><strong>Game contribution.</strong> Do the games you actually play count, and at what percentage?</li>
          <li><strong>Win cap.</strong> Is there a ceiling on what you can cash out from the bonus?</li>
          <li><strong>Withdrawal rules.</strong> Is the bonus sticky or non-sticky, which payment methods qualify, and what verification and withdrawal limits apply?</li>
        </ol>
      </div>
      <p>If the terms do not answer one of these clearly, count that as a reason not to claim. Screenshot the terms on the day you opt in, because they can be changed later.</p>
      <h3>When declining the bonus is the better call</h3>
      <p>Deposit without a bonus and your balance is real money from the start. None of the bonus restrictions apply: no maximum bet, no excluded games, no win cap and no wagering multiplier standing between you and a withdrawal. Check whether the site still requires deposits to be played through once, and expect ID checks regardless.</p>
      <p>Declining tends to make sense if you prefer table games that barely contribute, plan a short session, usually bet above the maximum bet, or would need to stake far more than you intended to finish the wagering. A bonus buys longer play on restricted terms. It does not change the odds of the games.</p>

      <h2 id="faq">Casino Welcome Bonus FAQ</h2>
      <div class="faq">
        <details>
          <summary>Can I withdraw a casino welcome bonus straight away?</summary>
          <p>No. Bonus funds stay locked until you complete the wagering within the time limit, and requesting a withdrawal early usually forfeits the bonus and any winnings tied to it. The partial exception is a non-sticky bonus, where you may be able to give up the bonus and withdraw real-money winnings before it is touched. Either way, expect an ID check before the first payout, and confirm the details in the offer's own terms.</p>
        </details>
        <details>
          <summary>What does 40x wagering mean in dollars?</summary>
          <p>Multiply 40 by whatever the terms say it applies to. As an illustration, a $50 bonus with 40x on the bonus alone means $2,000 in total bets. If the 40x applies to a $50 deposit plus the $50 bonus, it is $4,000. That is turnover, not losses, and games that contribute less than 100% push the real figure higher. Always check the wagering base before the multiplier.</p>
        </details>
        <details>
          <summary>Do Australian betting sites offer sign up bonuses?</summary>
          <p>People searching “sign up bonus Australia” often mean sports or racing betting, not casinos. Licensed Australian wagering providers are understood to be restricted, under national consumer protection rules, from offering inducements to open an account, although existing customers may still see promotions. These rules change, so confirm the current position with ACMA or your state or territory gambling regulator. If a betting site is advertising a sign-up bonus to Australians, check it against ACMA's register first.</p>
        </details>
        <details>
          <summary>Are casino bonus winnings taxed in Australia?</summary>
          <p>There is no one-line answer we can safely give. How winnings are treated depends on your circumstances, and the position of someone having an occasional punt may differ from that of someone gambling in a systematic, business-like way. Check the Australian Taxation Office's guidance at <a href="https://www.ato.gov.au" rel="noopener">ato.gov.au</a> or ask a registered tax agent. Do not rely on a casino, an affiliate site or a forum for tax advice. Keep records of deposits and withdrawals in any case.</p>
        </details>
      </div>

      <h2 id="next-step">Your Next Step: Set Limits Before You Look at Any Offer</h2>
      <figure class="shot"><?= gw_img('articles/welcome-limits', 'Limit sliders beside the title Set Limits Before Any Offer', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Do three things, in this order, before a headline amount has a chance to set your budget:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Set your limits.</strong> Decide the most you can afford to lose and how long you will play, and treat that deposit as spent the moment you make it.</li>
          <li><strong>Check ACMA.</strong> Search the service on <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> and read what the regulator says about offshore gambling sites.</li>
          <li><strong>Run the checklist.</strong> Convert the wagering to dollars and compare the expected cost with the bonus.</li>
        </ol>
      </div>
      <div class="rg-card">
      <p>Gambling is for people aged 18 and over, and no bonus guarantees winnings. If gambling is causing you stress or you are chasing losses, Gambling Help Online offers free, confidential support around the clock on <a href="tel:1800858858">1800 858 858</a> and at gamblinghelponline.org.au. BetStop, the National Self-Exclusion Register at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, covers licensed Australian online and phone wagering providers. It is not understood to extend to offshore casinos, which is one more protection you go without on those sites.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>
      <p><strong>Related reading:</strong> <a href="/how-casino-welcome-bonuses-are-calculated/">How Casino Welcome Bonuses Are Calculated</a>, <a href="/australian-casino-welcome-bonuses-comparison/">Australian Casino Welcome Bonuses 2026 Comparison: How the Main Types Compare</a>, <a href="/best-casino-bonuses-for-australian-players/">Best Bonuses for Australian Players 2026: Choosing One That Suits You</a>, <a href="/no-deposit-bonuses-australia/">No Deposit Bonus Australia: What You Actually Get</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
