<?php
/**
 * Article: Responsible gambling tools in Australia: what exists and what each one covers
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTES
 * 1. The "Top casino of the month" banner is OFF on this page (see the $showPromo switch just below these notes)
 *    because the page is for people who want to cut back or stop gambling, and a casino promotion beside it works
 *    against that purpose. Change false to true on the switch line to show the banner above the table of contents
 *    (and inside the article on phones).
 * 2. These details were supplied as text and could not be independently verified when the page was built, so
 *    re-check them on betstop.gov.au, acma.gov.au and the state sites: the number of providers (about 150), the
 *    limit of five nominated support people, BetStop's removal process, the NSW minimum exclusion periods
 *    (6 and 12 months), and the opening hours of the support lines.
 *
 * Layout notes:
 * - The left rail holds the table of contents (with the banner above it when $showPromo is true). It stays in view
 *   while you scroll. The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
$showPromo = false;

require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('responsible-gambling-tools-limits-and-self-exclusion-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php if ($showPromo) { gw_promo(); } ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#short-answer">The short answer</a></li>
            <li><a href="#coverage">Coverage table</a></li>
            <li><a href="#limits">Limits on licensed accounts</a></li>
            <li><a href="#betstop">BetStop</a></li>
            <li><a href="#venues">Venue self-exclusion</a></li>
            <li><a href="#blocks">Bank blocks and device blockers</a></li>
            <li><a href="#offshore">Offshore casino sites</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#help">Free help and your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <h2 id="short-answer">The short answer</h2>
      <figure class="shot"><?= gw_img('articles/rgt-short-answer', 'Limit sliders beside the title Responsible Gambling Tools', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The main responsible gambling tools Australia offers are deposit limits on licensed betting accounts, BetStop (the national self-exclusion register for online and phone betting), state-run self-exclusion from pokies venues, casinos and TAB outlets, gambling blocks from your bank, and blocking software for your devices. No single tool covers every kind of gambling. Most people need two or three working together.</p>
      <p>Which one to set up first depends on where the money is going:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">If this is you</p>
          <h3>You bet online and want to stay in control</h3>
          <p>Set a deposit limit on every account, then add a bank block as a backstop.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If this is you</p>
          <h3>You want to stop betting online or by phone</h3>
          <p>Register with BetStop.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If this is you</p>
          <h3>The pokies, a casino or the TAB counter is the problem</h3>
          <p>Use your state or territory's venue self-exclusion program.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">If this is you</p>
          <h3>You've been using offshore casino sites</h3>
          <p>Australian limits and registers don't reach them, so a bank block and a device blocker matter most.</p>
        </article>
      </div>
      <p>This guide is for adults aged 18 and over, and for partners and family looking on someone's behalf. The tools run from the lightest step to the strongest. Rules change, so treat the Australian Communications and Media Authority (ACMA) and your state regulator as the final word.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>No single tool covers every kind of gambling.</strong> Most people need two or three working together.</li>
          <li><strong>BetStop</strong> covers licensed online and phone betting, not pokies venues, casinos or offshore sites.</li>
          <li><strong>Bank blocks and device blockers</strong> matter most for gambling that Australian registers can't reach.</li>
          <li><strong>Free, confidential help</strong> is available any hour on 1800 858 858.</li>
        </ul>
      </div>


      <h2 id="coverage">Coverage table: tool, what it blocks, what it misses, where to set it</h2>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Tool</th><th scope="col">What it blocks</th><th scope="col">What it misses</th><th scope="col">Where to set it</th></tr></thead>
      <tbody>
      <tr><th scope="row">Deposit limit</th><td>Deposits above your chosen amount on one licensed betting account</td><td>Your other betting accounts, venues, offshore sites</td><td>In each provider's app or website</td></tr>
      <tr><th scope="row">BetStop</th><td>Betting with all licensed Australian online and phone wagering providers, plus their marketing to you</td><td>Venue pokies, land-based casinos, retail outlets, offshore sites</td><td><a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a></td></tr>
      <tr><th scope="row">Venue self-exclusion</th><td>Entry to, or gambling at, the venues you nominate</td><td>Online betting, venues you didn't nominate, other states</td><td>At the venue, through a counsellor, or your state's program</td></tr>
      <tr><th scope="row">Bank gambling block</th><td>Card payments your bank identifies as gambling</td><td>Cash, other banks' cards, some transfers and wrongly coded merchants</td><td>Your banking app or by phone</td></tr>
      <tr><th scope="row">Device blocker</th><td>Access to gambling sites and apps on that device</td><td>Other devices, venues, phone betting</td><td>Installed on each phone, tablet and computer</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="limits">Gambling limits on licensed betting accounts: deposit limits, statements and breaks</h2>
      <figure class="shot"><?= gw_img('articles/rgt-limits', 'Payment list with a clock beside the title Limits on Licensed Accounts', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>How deposit limits work under the national framework</h3>
      <p>Licensed online wagering providers operate under the National Consumer Protection Framework for Online Wagering, a set of minimum standards agreed by the Commonwealth, states and territories. Under it, providers must offer you a deposit limit when you open an account and prompt you to review it from time to time.</p>
      <p>Lowering a limit applies straight away. Raising one doesn't, because a cooling-off period has to pass first. Check your provider's terms for the exact wait. Separately, federal rules restrict the use of credit cards for online wagering. ACMA's website sets out the current scope and any exemptions.</p>
      <p>To find the setting in most betting apps:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Log in and open the account or profile menu.</li>
          <li>Look for Safer gambling, Responsible gambling or Deposit limit.</li>
          <li>Choose a period (daily, weekly or monthly) and an amount.</li>
          <li>Confirm, then take a screenshot for your records.</li>
        </ol>
      </div>
      <p>A limit applies to that one account only. If you have three betting apps, you need three limits. Or fewer apps.</p>
      <h3>Choosing a limit you will actually keep</h3>
      <p>Start from your budget, not your betting history. After rent or mortgage, bills, food and debts, pick an amount you could lose completely without it touching anything else. If that's $50 a week (an example only, not a recommendation), set a $50 weekly limit.</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Set it when you're calm, not straight after a loss.</li>
          <li>Pick the shorter period. A weekly cap is harder to burn through in one night than a monthly one.</li>
          <li>If you keep several accounts, split the one total across them.</li>
        </ul>
      </div>
      <h3>Using activity statements as a reality check</h3>
      <p>The framework also requires providers to send regular activity statements showing deposits, withdrawals and your net result. Read the net figure first and compare it with what you thought you'd spent. Wins tend to stick in the memory better than losses. The statement has no such bias.</p>
      <p>If the number surprises you, lower your limit or move to a stronger step. Many providers also offer short breaks or time-outs from the same menu. They suit a pause of days or weeks, but they only cover that one provider.</p>
      <p class="see-also">Step by step: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>.</p>

      <h2 id="betstop">BetStop: self-exclusion from Australian online and phone betting</h2>
      <figure class="shot"><?= gw_img('articles/rgt-betstop', 'Shield with a tick beside the title BetStop Explained Simply', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What happens when you register</h3>
      <p>BetStop is the National Self-Exclusion Register, overseen by ACMA. It is free, and the official site is betstop.gov.au. Be wary of lookalike addresses. You register online or by phone, confirm your identity and choose how long you want to be excluded.</p>
      <p>BetStop lets you self-exclude from all licensed Australian online and phone betting in one step.</p>
      <p>Once you're on the register, every licensed Australian online and phone wagering provider must refuse to let you bet, must not open a new account for you, and must stop sending you marketing. ACMA puts the number of providers at around 150 and keeps a current list on its website. Existing accounts are to be closed. If you had money sitting in one, ask the provider how the balance will be returned.</p>
      <p>You can also nominate support people, such as a partner, friend or counsellor, to be kept informed. BetStop has allowed up to five, so confirm the current number when you register.</p>
      <h3>How long it lasts and how removal works</h3>
      <p>You choose a period from a minimum of three months up to lifetime. You can extend it at any time, but you cannot shorten it. That's the point of the register: the decision you make on a clear-headed day holds on the bad ones.</p>
      <p>ACMA says removal is only possible once the three-month minimum has passed, and that it requires a statutory declaration confirming you've had counselling or professional advice. The process may be updated, so read the current rules on <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> before you pick a period.</p>
      <h3>What BetStop does not reach</h3>
      <p>BetStop is easy to mistake for a blanket ban. It isn't one. It does not cover:</p>
      <div class="vs-col vs-col--bad">
        <h3>BetStop does not cover</h3>
        <ul>
        <li>pokies in pubs, clubs and hotels</li>
        <li>land-based casinos</li>
        <li>betting in person at retail outlets, such as the counter at a TAB</li>
        <li>offshore gambling sites that aren't licensed in Australia</li>
        </ul>
      </div>
      <p>It is also separate from state venue programs and from any exclusion you set up directly with one provider. For self-exclusion Australia-wide across every form of gambling, you need BetStop plus the tools in the next sections.</p>
      <p class="see-also">More in our <a href="/self-exclusion-australia-guide/">self-exclusion in Australia guide</a>.</p>

      <h2 id="venues">Self-excluding from pokies venues, casinos and TAB outlets</h2>
      <figure class="shot"><?= gw_img('articles/rgt-venues', 'Dotted circles beside the title Venue Exclusion by State', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Why each state and territory runs its own program</h3>
      <p>Pokies, casinos and retail betting are licensed by states and territories, not the Commonwealth. Each one therefore has its own self-exclusion program, with its own forms, minimum periods and rules about how many venues one application can cover. An exclusion in one state generally won't follow you across the border.</p>
      <p>Several states also have, or are trialling, pre-commitment and carded-play schemes that let or require pokies players to set limits on a card. These reforms are still changing, so check your state regulator for what applies in your local venues now.</p>
      <h3>How to start: venue, counsellor or online</h3>
      <p>There are usually three ways in:</p>
      <div class="mini3">
        <div><h3>At the venue</h3><p>Ask for the gaming manager or the staff member responsible for self-exclusion. Venues are expected to handle the request discreetly.</p></div>
        <div><h3>Through a gambling counsellor</h3><p>Often the easiest route, because a counsellor can help you exclude from several venues at once and talk through what else might help.</p></div>
        <div><h3>Online</h3><p>Where your state offers it.</p></div>
      </div>
      <p>New South Wales is one example. GambleAware NSW explains that you can self-exclude from multiple venues, with a minimum of six months for clubs and pubs and 12 months for casinos and TAB. Those are NSW's rules only, so don't assume they apply elsewhere, and check GambleAware NSW for the current periods.</p>
      <p>Expect to show ID, and in most programs to provide a photo so staff can recognise you.</p>
      <h3>Finding your state regulator's page</h3>
      <p>Search for your state or territory name plus gambling self-exclusion and choose the result ending in .gov.au. It will usually be the liquor and gaming regulator or the state gambling help service. If that feels like too much right now, call Gambling Help Online on <a href="tel:1800858858">1800 858 858</a>. The line connects you with your state's service, and a counsellor can start the paperwork with you.</p>

      <?php if ($showPromo): ?><div class="story-promo-m"><?php gw_promo(); ?></div><?php endif; ?>

      <h2 id="blocks">Bank gambling blocks and device blockers: stopping the money and the access</h2>
      <figure class="shot"><?= gw_img('articles/rgt-blocks', 'Wallet with payment cards beside the title Bank Blocks and Device Blockers', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Card and account blocks from your bank</h3>
      <p>Many Australian banks now let you block gambling transactions on your cards. Features differ between banks and change often, so check with your own bank instead of trusting a list. To find out:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Open your banking app and look under card settings or card controls for a gambling block.</li>
          <li>If it's not there, call or message the bank and ask: Can you block gambling transactions on my debit card, and is there a waiting period to remove the block?</li>
          <li>Ask about lower daily card and transfer limits at the same time.</li>
        </ol>
      </div>
      <p>Blocks generally work by recognising the merchant type on a card payment. They are strongest on debit card purchases and may not catch PayID payments, bank transfers, cash withdrawals or merchants coded as something else. Treat a block as a speed bump, not a wall. If money is already tight, tell the bank you're in financial hardship. Banks have teams for exactly that.</p>
      <h3>Blocking software on phones and computers</h3>
      <p>Gambling-blocking apps stop a device from opening gambling websites and apps. Some are free and some charge a subscription. Gambling Help Online and state help services can point you to current options. Install the blocker on every device you use, and consider having someone you trust hold the password.</p>
      <p>These two layers matter most for the gambling BetStop can't reach. An offshore site will ignore an Australian register, but it can't take a payment your bank refuses or load on a device that blocks it.</p>
      <p class="see-also">More tools: <a href="/responsible-gaming-tools-every-australian-should-use/">responsible gaming tools every Australian should use</a>.</p>

      <h2 id="offshore">Offshore casino sites: why safer gambling tools can't be relied on there</h2>
      <figure class="shot"><?= gw_img('articles/rgt-offshore', 'Casino chips beside the title Offshore Sites and Safer Tools', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act means for online pokies and casino games</h3>
      <p>Under the Interactive Gambling Act 2001, online casino-style games and online pokies may not be offered to people in Australia. Licensed online wagering, meaning betting on racing and sport with an Australian-licensed provider, is regulated and permitted. Online casinos are not. No online casino holds an Australian licence, whatever a site's footer or an affiliate review claims.</p>
      <p>When it comes to safer gambling, Australia's protections stop at the border. An offshore site might show a deposit limit or a self-exclusion button, but nobody here enforces it. The operator sits outside the national framework and isn't connected to BetStop. It can reopen your account or email you a bonus the next day. If it withholds your funds, there's no local regulator to back your dispute. ACMA investigates these services and can ask internet providers to block them, but new addresses keep appearing.</p>
      <p>If offshore sites are where your money is going, rely on the bank block, the device blocker and a counsellor, not on the site's own promises.</p>
      <h3>How to check a provider on ACMA's register</h3>
      <p>ACMA publishes a register of licensed interactive wagering providers. Go to <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a>, search for the page on checking whether a gambling operator is legal, and look up the provider's name. If it isn't listed, it isn't licensed to offer online betting here, and none of the tools in this guide will bind it. ACMA has the final word on what is and isn't permitted.</p>
      <p class="see-also">For the legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="faq">FAQ: limits and self-exclusion in Australia</h2>
      <div class="faq">
        <details>
          <summary>Does BetStop cover pokies and casinos?</summary>
          <p>No. BetStop covers licensed Australian online and phone wagering providers only. It does not exclude you from pokies in pubs and clubs, land-based casinos, in-person betting at retail outlets, or offshore sites. For venues you need your state or territory's self-exclusion program as well. Check the current coverage list at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> and your state regulator's site for venue programs.</p>
        </details>
        <details>
          <summary>Can I cancel BetStop early?</summary>
          <p>You can't shorten the period you chose, and nothing can be undone inside the three-month minimum. ACMA says removal after that point requires a statutory declaration confirming you've received counselling or professional advice. You can extend at any time. The process may be updated, so read the removal rules on <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a> before you register and choose your period.</p>
        </details>
        <details>
          <summary>How quickly does a deposit limit change take effect?</summary>
          <p>A decrease applies immediately with licensed Australian wagering providers. An increase does not. Under the National Consumer Protection Framework a cooling-off period must pass first, so you can't lift your limit in the middle of a losing session. Your provider's terms should state the exact wait. The framework itself is published by the Department of Social Services.</p>
        </details>
        <details>
          <summary>Can a family member exclude someone else from gambling?</summary>
          <p>Not through BetStop, because only the person themselves can register. Some states and territories have third-party or family exclusion arrangements for venues, but these are not national and the rules differ widely. Family members can still get free counselling for themselves and advice on protecting shared finances. Ask your state gambling help service or regulator what applies where you live.</p>
        </details>
        <details>
          <summary>Is self-exclusion confidential?</summary>
          <p>The programs are designed to share your details only as far as needed to enforce the exclusion. With BetStop, wagering providers check the register so they can refuse your custom, and support people are told only if you nominate them. Venue programs give staff your photo so they can recognise you. Read BetStop's privacy policy at <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, or ask your state program how it handles your information.</p>
        </details>
      </div>

      <h2 id="help">Free help and your next step today</h2>
      <figure class="shot"><?= gw_img('articles/rgt-help', 'Checklist card beside the title Free Help and Your Next Step', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Free, confidential support lines</h3>
      <p>You don't need to be in crisis to call, and you don't need to have decided to quit.</p>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Gambling Help Online:</strong> <a href="tel:1800858858">1800 858 858</a>. Free, confidential counselling by phone, plus online chat at gamblinghelponline.org.au. Open to family and friends too.</li>
          <li><strong>National Debt Helpline:</strong> <a href="tel:1800007007">1800 007 007</a>. Free financial counsellors who can help with gambling debts, hardship arrangements and dealing with creditors. Check opening hours at ndh.org.au.</li>
          <li><strong>Lifeline:</strong> <a href="tel:131114">13 11 14</a>. Crisis support at any hour if you're feeling overwhelmed or unsafe. In an emergency, call 000.</li>
        </ul>
      </div>
      <p>Numbers and hours can change, so confirm them on each service's website.</p>
      <p>A note on responsible gambling: gambling is for adults aged 18 and over. Set your limits before you place a bet, not during a session. Gambling is paid entertainment in which the odds favour the operator. It is not a way to make money or win back losses. No tool in this guide can guarantee anyone will stop, but each one makes the next bet harder to place, and that can buy you time to make a different choice.</p>
      <h3>A 15-minute action plan</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Minutes 1 to 5:</strong> set a limit. Open each betting app and set or lower a deposit limit. Delete the apps you don't need.</li>
          <li><strong>Minutes 5 to 8:</strong> turn on a bank block. Check your banking app's card controls, or message your bank and ask for a gambling block.</li>
          <li><strong>Minutes 8 to 12:</strong> register with BetStop if limits haven't held. Go to <a href="https://www.betstop.gov.au" rel="noopener">betstop.gov.au</a>, choose a period and nominate a support person.</li>
          <li><strong>Minutes 12 to 15:</strong> call <a href="tel:1800858858">1800 858 858</a>. Ask about venue self-exclusion in your state, blocking software and ongoing counselling.</li>
        </ol>
      </div>
      <p>If you're reading this for someone else, steps one to three are theirs to take, but step four is open to you right now. Pick the first step that fits and do it before you close this page.</p>
      <p><strong>Related reading:</strong> <a href="/how-to-set-deposit-and-loss-limits-australia/">How to Set Deposit &amp; Loss Limits in Australian Casinos</a>, <a href="/self-exclusion-australia-guide/">Responsible Gambling Self-Exclusion Australia Guide</a>, <a href="/responsible-gaming-tools-every-australian-should-use/">Responsible Gaming Tools Every Australian Should Use</a>, <a href="/responsible-gambling-tools-limits-and-self-exclusion/">Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
