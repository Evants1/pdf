<?php
/**
 * Article: How Casino Welcome Bonuses Work, and What to Check First
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('how-casino-welcome-bonuses-work');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#types">The common types of welcome bonus</a></li>
          <li><a href="#wagering">Wagering requirements, with an example</a></li>
          <li><a href="#terms">The terms that change the value</a></li>
          <li><a href="#expected-cost">Why wagering costs you something</a></li>
          <li><a href="#checklist">A pre-claim checklist</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>A welcome bonus is a marketing tool. It can be good value, but only if you understand the conditions attached to it. This guide explains the common structures and shows how to work out what a bonus is actually worth. We do not list current offers here, because terms change often and the figures that matter are always in the operator's own terms.</p>

      <aside class="note">
      <p><strong>Australian readers.</strong> Licensed Australian wagering providers are generally not allowed to offer sign-up inducements to open an account. Large welcome offers are mainly found on offshore sites, which operate outside Australian consumer protections. See <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>
      </aside>

      <h2 id="types">The common types of welcome bonus</h2>
      <h3>Match deposit bonus</h3>
      <p>The casino adds bonus funds based on your deposit, for example a 100% match on a deposit up to a stated limit. Deposit 100 and receive 100 in bonus funds, for 200 in total to play with, subject to the terms.</p>
      <h3>Free spins</h3>
      <p>A set number of spins on one or more named slots, usually at a fixed stake per spin. Winnings from free spins are often credited as bonus funds with their own wagering requirement and a cap on how much can be withdrawn.</p>
      <h3>No-deposit bonus</h3>
      <p>Bonus funds or spins awarded without a deposit. These tend to carry strict wagering requirements and low maximum cash-outs, which is how operators control the cost.</p>
      <h3>Cashback</h3>
      <p>A percentage of net losses returned over a period. Check whether it is paid as cash or as bonus funds, because bonus funds usually carry wagering requirements of their own.</p>

      <h2 id="wagering">Wagering requirements, with an example</h2>
      <p>The wagering requirement, sometimes called playthrough, is the amount you must bet before bonus-related funds can be withdrawn. It is expressed as a multiple. Here is an illustrative example, not a real offer:</p>
      <div class="table-wrap">
      <table class="data">
      <caption>Illustrative wagering arithmetic for a 100 deposit and 100% match</caption>
      <thead><tr><th scope="col">Rule</th><th scope="col">Calculation</th><th scope="col">Total you must bet</th></tr></thead>
      <tbody>
      <tr><th scope="row">35x on the bonus only</th><td>100 bonus x 35</td><td>3,500</td></tr>
      <tr><th scope="row">35x on deposit plus bonus</th><td>200 x 35</td><td>7,000</td></tr>
      </tbody>
      </table>
      </div>
      <p>The same headline multiple can mean very different workloads depending on what it applies to. Always check whether it is calculated on the bonus alone or on deposit plus bonus.</p>

      <h2 id="terms">The terms that change the value</h2>
      <ul>
      <li><strong>Game contribution.</strong> Slots often count 100% towards wagering while table games and live dealer games count less or nothing.</li>
      <li><strong>Maximum bet.</strong> Many bonuses limit your stake per spin or hand while wagering. Exceeding it can void the bonus.</li>
      <li><strong>Time limit.</strong> Bonuses expire. A big requirement with a short deadline is hard to complete.</li>
      <li><strong>Maximum cash-out.</strong> Some bonuses cap the winnings you can withdraw.</li>
      <li><strong>Sticky or non-sticky.</strong> A sticky bonus cannot be withdrawn and is removed from your balance when you cash out. A non-sticky bonus lets you play with cash first.</li>
      <li><strong>Excluded payment methods.</strong> Some e-wallets or methods may not qualify for a bonus.</li>
      <li><strong>Country restrictions.</strong> Offers can differ by region.</li>
      </ul>

      <h2 id="expected-cost">Why wagering costs you something</h2>
      <p>Every game has a house edge, which means that over time a portion of what you bet is kept by the casino. The long-run figure for a slot is expressed as return to player, covered in <a href="/understanding-rtp-and-volatility-in-online-slots/">our RTP guide</a>. If a slot has an RTP of 96%, the average long-run cost is 4% of everything you bet. Wagering 3,500 at that rate has an average expected cost of 140, which is more than the 100 bonus in our example. Results vary enormously in the short term, but the arithmetic shows why a high wagering requirement can make a bonus worth less than it looks.</p>

      <h2 id="checklist">A pre-claim checklist</h2>
      <ol>
      <li>Find the full bonus terms, not the promotional summary.</li>
      <li>Note the wagering multiple and what it applies to.</li>
      <li>Check the expiry period, maximum bet and maximum cash-out.</li>
      <li>Check that your payment method and the games you like qualify.</li>
      <li>Decide whether you would still deposit if there were no bonus. If not, skip it.</li>
      </ol>
      <p>It is always acceptable to decline a bonus. Most casinos let you opt out at deposit, and doing so can make withdrawals simpler. For a broader view of how bonuses fit into choosing an operator, see <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a> and our permanent <a href="/online-casino-bonuses/">online casino bonuses guide</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
