<?php
/**
 * Article: Crypto Casinos Australia: Bitcoin Gambling Guide
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTE: the section "How Bitcoin gambling works, from AUD to a bet and back" and the "How to vet a Bitcoin
 * casino" checklist describe, step by step, how to fund and test an offshore casino. They are supplied text,
 * framed as harm reduction. Get an Australian lawyer's view on whether that level of practical detail is acceptable
 * on an affiliate site, because it sits next to statements that these services cannot lawfully be offered here.
 * Also re-check the ATO, AUSTRAC and 11 June 2024 statements against the official sources before publishing.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the "from AUD to a bet and back" section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('crypto-casinos-australia-bitcoin-gambling-guide');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#law">What the law says</a></li>
            <li><a href="#journey">From AUD to a bet and back</a></li>
            <li><a href="#risks">Risks toplists skip</a></li>
            <li><a href="#vetting">How to vet a Bitcoin casino</a></li>
            <li><a href="#tax">Crypto gambling and tax</a></li>
            <li><a href="#control">Staying in control</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#next-step">Your next step</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>If you're looking for a crypto casino Australia licenses and regulates, there isn't one. Casino-style games can't lawfully be offered online to people in Australia, so no online casino holds an Australian licence, whatever it accepts as payment. Every site on a 'bitcoin casino Australia' toplist is an offshore service operating outside Australian law and outside Australian consumer protection.</p>
      <p>The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> enforces those rules and has the final word on what is legal. This bitcoin gambling guide doesn't rank sites or quote bonuses. It covers the law, how money moves from AUD to Bitcoin and back, where punters lose money without placing a bad bet, how tax fits in, and where to get help. It is general information for adults 18+, not legal or tax advice.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>No online casino holds an Australian licence,</strong> whatever it accepts as payment. Crypto changes nothing legally.</li>
          <li><strong>Crypto transfers are irreversible,</strong> and the AUD value of a balance can move while you play.</li>
          <li><strong>“No KYC” and VPN promises are warning signs,</strong> not features.</li>
          <li><strong>Keep records and set your own limits</strong> outside the casino. Offshore sites aren't bound by Australian harm-minimisation rules.</li>
        </ul>
      </div>

      <h2 id="law">Crypto casino Australia: what the law actually says</h2>
      <figure class="shot"><?= gw_img('articles/cry26-law', 'Shield with a tick beside the title Crypto and the Law in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act 2001 prohibits</h3>
      <p>The Interactive Gambling Act 2001 makes it an offence to provide or advertise certain online gambling services to people in Australia. That covers online casinos, online pokies and casino-style table games such as roulette and blackjack. Online wagering on sport and racing is allowed only through operators licensed in an Australian state or territory.</p>
      <p>ACMA investigates breaches, issues warnings and penalties, and asks Australian internet service providers to block illegal sites. The payment method changes nothing. A casino that takes Bitcoin is treated the same as one that takes cards.</p>
      <div class="vs">
        <div class="vs-col">
          <h3>Licensed Australian wagering</h3>
          <ul>
            <li>Barred from accepting digital currency since 11 June 2024</li>
            <li>Also barred from accepting credit cards</li>
          </ul>
        </div>
        <div class="vs-col vs-col--bad">
          <h3>Offshore online casinos</h3>
          <ul>
            <li>Already prohibited from being offered here by the Act</li>
            <li>Accepting Bitcoin changes nothing</li>
          </ul>
        </div>
      </div>
      <p>Crypto is also off the table at the legal end of the market. Since 11 June 2024, licensed Australian online and phone wagering operators have been barred from accepting digital currency, alongside credit cards. That ban applies to licensed wagering. It isn't what makes offshore casinos illegal to offer here, because the Act already did that.</p>
      <h3>What that means for you as a player</h3>
      <p>The Act's offences target the businesses that provide and advertise these services, not individual punters. That doesn't make playing legal or safe, and ACMA is the body to ask about your own situation. The practical consequence is clear, though. ACMA warns that people using illegal offshore services aren't protected by Australian law if something goes wrong, such as an operator withholding winnings.</p>
      <h3>How to check a site against ACMA's register and blocked list</h3>
      <p>ACMA publishes two lists on <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a>: a register of licensed interactive wagering services, and a list of illegal gambling websites it has asked ISPs to block. The blocked list keeps growing, so check it directly instead of trusting a number quoted elsewhere.</p>
      <p>A site offering online pokies or casino games to Australians won't be on the register. Absence from the blocked list doesn't mean approval either. The site may simply not have been investigated yet.</p>
      <p class="see-also">For more, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="journey">How Bitcoin gambling works, from AUD to a bet and back</h2>
      <figure class="shot"><?= gw_img('articles/cry26-journey', 'Casino coin beside the title From AUD to a Bet and Back', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>The mechanics matter because many avoidable losses happen in transit, not at the table.</p>
      <h3>Buying crypto with AUD through an AUSTRAC-registered exchange</h3>
      <p>The journey starts in dollars. You open an account with a digital currency exchange, verify your identity and deposit AUD, commonly by PayID or bank transfer. Exchanges operating in Australia must be registered with AUSTRAC, the financial intelligence regulator, and you can confirm a registration with AUSTRAC. Registration relates to anti-money-laundering obligations. It doesn't guarantee your funds.</p>
      <p>Two things to know before you start. Some banks limit, delay or block payments to crypto exchanges, and their policies change, so check with your own bank. And the exchange knows who you are. Your purchases are linked to your verified identity from the first step.</p>
      <h3>Depositing, playing and withdrawing: what happens on-chain</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Buy.</strong> Convert AUD to your chosen coin on the exchange, paying its spread or trading fee.</li>
          <li><strong>Get a deposit address.</strong> The casino's cashier generates an address for a specific coin on a specific network.</li>
          <li><strong>Send.</strong> Withdraw from the exchange, or your own wallet, to that address. The coin and the network must match exactly. Send the wrong coin, or use the wrong network, and the funds can be gone for good.</li>
          <li><strong>Wait for confirmations.</strong> The casino credits your balance once the network has confirmed the transaction. The cashier lists required confirmations and minimum deposits.</li>
          <li><strong>Play.</strong> Some sites keep your balance in the coin. Others convert it to a display currency. Check which, because it changes your exposure to price movements.</li>
          <li><strong>Withdraw.</strong> You request a payout to an address you control. The casino may hold it for manual review or identity checks before sending.</li>
          <li><strong>Cash out.</strong> Send the coin back to your exchange, sell it for AUD and withdraw to your bank account.</li>
        </ol>
      </div>
      <p>Each leg has a cost: exchange fees, network fees and sometimes casino withdrawal fees. None are fixed. Look them up in the exchange's fee schedule and the casino's cashier and terms before you commit, not after.</p>
      <h3>Bitcoin vs stablecoins vs other coins</h3>
      <figure class="shot"><?= gw_img('articles/cry26-coins', 'Wallet with payment cards beside the title Bitcoin vs Stablecoins vs Others', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Coin</th><th scope="col">Price volatility against AUD</th><th scope="col">Network fee behaviour</th><th scope="col">Wrong-network risk</th></tr></thead>
      <tbody>
      <tr><th scope="row">Bitcoin (BTC)</th><td>High; the AUD value can move noticeably within a day</td><td>Varies with congestion and rises when the network is busy</td><td>Lower on the main Bitcoin network, but some exchanges offer BTC over other networks, so still check</td></tr>
      <tr><th scope="row">Stablecoin such as USDT</th><td>Low against the US dollar, but still moves against AUD with the exchange rate; carries issuer risk</td><td>Depends entirely on which network it is sent over</td><td>High; the same token exists on several networks, sometimes with identical-looking addresses</td></tr>
      <tr><th scope="row">Litecoin (LTC) or Ether (ETH)</th><td>High, similar in kind to Bitcoin</td><td>LTC is generally modest; ETH varies widely with network demand</td><td>Lower for LTC; higher for ETH, because several compatible networks share the same address format</td></tr>
      </tbody>
      </table>
      </div>
      <p>No coin is the 'safest'. Stablecoins reduce price swings but depend on the issuer maintaining the peg, and they add network choices you can get wrong. Bitcoin is simpler to send, but its AUD value moves while it sits in a casino balance.</p>
      <p class="see-also">For a beginner glossary of these terms, see <a href="/crypto-casinos-explained-benefits-and-risks/">crypto casinos explained: benefits and risks</a> and <a href="/bitcoin-casinos-australia-why-crypto/">why Aussies look to crypto</a>.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="risks">The risks of crypto gambling in Australia that toplists skip</h2>
      <figure class="shot"><?= gw_img('articles/cry26-risks', 'Chart with a warning mark beside the title The Risks Toplists Skip', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Search 'crypto gambling Australia' and you'll mostly find lists of sites and bonuses. Here is what those lists tend to leave out.</p>
      <h3>No Australian consumer protection or dispute body</h3>
      <p>With a licensed Australian bookmaker, you have a state or territory regulator to complain to and rules covering things like self-exclusion. With an offshore casino, you have the operator's own support team and, at best, a complaints process run by a licensor in another country with no power in Australia. ACMA can act against an operator for offering the service here. It can't recover your balance.</p>
      <h3>Irreversible payments and price swings</h3>
      <p>Card payments can sometimes be disputed through your bank. Crypto transfers can't. Once a transaction is confirmed, nobody can reverse it: not the exchange, not your bank, not a regulator. If the casino doesn't credit it, or you paste the wrong address, recovery depends on the goodwill of whoever controls the receiving wallet.</p>
      <p>Volatility adds a second bet on top of the first. Say you deposit $500 worth of Bitcoin and break even on the games. If Bitcoin's AUD price falls while your balance sits there, you cash out less than $500 anyway. It can go the other way too, but your result is no longer only about the games.</p>
      <h3>'No KYC' promises, VPNs and blocked domains</h3>
      <p>Toplists sell 'no KYC' and 'anonymous' play as features. Treat them as warning signs. Sites' terms commonly reserve the right to demand identity documents at any time, and the request often arrives when you try to withdraw, not when you deposit. If you can't or won't comply, the balance stays with them. Crypto isn't anonymous either. Transactions sit on a public ledger, and your exchange has tied your purchases to your identity.</p>
      <p>VPNs are a similar trap. A casino may list Australia as a restricted country in its terms while still accepting sign-ups from people masking their location. Playing from a restricted location is a common ground for voiding winnings, so the site keeps your deposits and has a ready-made reason not to pay.</p>
      <p>When ACMA has a domain blocked, operators often reappear on a mirror address. A link that keeps changing isn't a workaround. It is a sign the regulator has already acted against the service.</p>

      <h2 id="vetting">How to vet a Bitcoin casino before you send a cent</h2>
      <figure class="shot"><?= gw_img('articles/cry26-vetting', 'Checklist card beside the title Vet a Site Before You Send a Cent', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>This checklist is harm reduction, not endorsement. Passing every check doesn't make a site legal to offer in Australia and doesn't guarantee you will be paid. Failing any one of them is a reason to walk away.</p>
      <p>Check the licence, withdrawal terms and fairness proof before you send any Bitcoin.</p>
      <h3>Verify the licence on the licensor's own register</h3>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>Find the licence claim, usually in the site footer. Note the licensor, the licence number and the company name.</li>
          <li>Go to the licensor's official website yourself and search its public register for that company and domain. Don't trust a seal or badge on the casino's page, which can link to a look-alike.</li>
          <li>Know what the licence covers. An offshore licence from Curaçao, Anjouan or similar means the operator answers to that authority's rules. It gives you no rights under Australian law and no Australian body to complain to. Check whether the licensor accepts player complaints at all, and how.</li>
        </ol>
      </div>
      <h3>Read the withdrawal, bonus and restricted-country terms</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Restricted countries.</strong> If Australia is listed, any payout is at the operator's discretion. Stop there.</li>
          <li><strong>Withdrawals.</strong> Look for minimum and maximum amounts, daily, weekly or monthly caps, fees, pending periods and the point at which ID is required.</li>
          <li><strong>Bonuses.</strong> Wagering requirements, maximum bet rules, excluded games and caps on bonus winnings are where many disputes start. If you can't find or follow the terms, don't take the bonus.</li>
          <li><strong>Dormancy and closure.</strong> Check what happens to your balance if the account goes inactive or the operator closes it.</li>
        </ul>
      </div>
      <h3>Test 'provably fair' claims and make a small test withdrawal</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Run the verification yourself.</strong> For a game labelled provably fair, the site should show you a hashed seed before you bet and reveal the seed afterwards. Check a few rounds, ideally with an independent verifier. This usually applies to a site's in-house games only, not third-party pokies.</li>
          <li>Deposit the smallest amount the cashier allows, then withdraw it before you play seriously. You'll learn whether identity checks appear, how long a payout really takes and what fees come out. No review can verify that for you.</li>
          <li><strong>Save screenshots of the terms as they stood on the day you signed up.</strong> Terms change.</li>
        </ul>
      </div>
      <p class="see-also">For a fuller evaluation method, see <a href="/crypto-casinos-australia-2026-how-to-evaluate/">how to evaluate a crypto casino</a>.</p>

      <h2 id="tax">Crypto gambling and tax: what the ATO looks at</h2>
      <figure class="shot"><?= gw_img('articles/cry26-tax', 'Payment list with a clock beside the title Crypto Gambling and Tax', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Gambling winnings vs disposing of a crypto asset</h3>
      <p>Two separate ideas meet here, and it helps to keep them apart. First, the ATO treats crypto as a capital gains tax (CGT) asset, not as money. Disposing of it can trigger a CGT event, with a gain or loss measured against what you paid. Disposal includes selling it for AUD, swapping it for another coin or using it to pay for something.</p>
      <p>Second, winnings from recreational gambling are generally not treated as assessable income in Australia, and losses aren't deductible, unless you are effectively running a gambling business. Under the CGT rules, a gain or loss that comes directly from gambling is generally disregarded.</p>
      <p>The overlap is where it gets messy. Your gambling result is one question. The change in your coin's value between buying it and disposing of it is another. Sources differ on exactly when a disposal happens around a casino deposit, so don't rely on a blog, including this one, for your outcome. Read the ATO's crypto guidance at <a href="https://www.ato.gov.au" rel="noopener">ato.gov.au</a> or speak to a registered tax agent. Bear in mind that the ATO runs a data-matching program covering crypto exchanges.</p>
      <h3>Records worth keeping</h3>
      <div class="rg-card">
        <ul class="checks">
          <li>The date, amount, AUD value and fees for every crypto purchase and sale</li>
          <li>Transaction IDs for every transfer to and from a casino</li>
          <li>The AUD value of the coin at the time of each deposit and withdrawal</li>
          <li>Screenshots or exports of your casino transaction history</li>
          <li>The wallet addresses you used</li>
        </ul>
      </div>
      <p>Download exchange transaction exports regularly. They're much harder to reconstruct later.</p>

      <h2 id="control">Staying in control: limits, self-exclusion and where to get help</h2>
      <figure class="shot"><?= gw_img('articles/cry26-control', 'Limit sliders beside the title Set Your Own Limits and Get Help', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Gambling is for adults 18 and over, and it is paid entertainment, not a way to earn. The games are built so the house wins over time, and no coin, system or bonus changes that.</p>
      <h3>Limits you set yourself when the site won't</h3>
      <p>Offshore sites aren't bound by Australian harm-minimisation rules, and crypto never closes, so set your limits outside the casino:</p>
      <div class="rg-card">
        <ul class="checks">
          <li>Decide a weekly or monthly loss limit in AUD and buy only that much crypto.</li>
          <li>Set a time limit per session and use a phone timer.</li>
          <li>Don't leave a spare balance on the exchange 'for next time'.</li>
          <li>Ask your bank what its gambling block covers. Many apply to card payments and may not stop a transfer to an exchange.</li>
          <li>Never chase losses or gamble with borrowed money.</li>
        </ul>
      </div>
      <h3>What BetStop does and doesn't cover</h3>
      <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, lets you block yourself from all licensed Australian online and phone wagering providers in one free registration. It doesn't reach offshore casinos, which aren't part of the scheme. If gambling is causing you or someone close to you harm, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support around the clock on <a href="tel:1800858858">1800 858 858</a>.</p>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a>, <a href="/self-exclusion-australia-guide/">self-exclusion in Australia</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Crypto casino FAQ for Australian players</h2>
      <div class="faq">
        <details>
          <summary>Can Australian-licensed betting sites accept Bitcoin?</summary>
          <p>No. Since 11 June 2024, licensed Australian online and phone wagering operators have been prohibited from accepting digital currency or credit cards. Be suspicious of any site that calls itself Australian-licensed while taking Bitcoin deposits, and check the operator on ACMA's register at acma.gov.au.</p>
        </details>
        <details>
          <summary>Can I get in trouble for playing at an offshore crypto casino?</summary>
          <p>The Interactive Gambling Act's offences are aimed at those who provide and advertise prohibited services, not at individual punters. That doesn't make playing legal, safe or risk-free. You have no Australian protection if funds are withheld, and you may be breaching the site's own terms. This isn't legal advice, so check the current position with ACMA.</p>
        </details>
        <details>
          <summary>Does BetStop block crypto casinos?</summary>
          <p>No. BetStop covers licensed Australian online and phone wagering providers only. Offshore crypto casinos won't check the register, so self-excluding won't stop you opening an account with them. For a broader barrier, ask Gambling Help Online on <a href="tel:1800858858">1800 858 858</a> about blocking software and other options.</p>
        </details>
        <details>
          <summary>What does 'provably fair' mean?</summary>
          <p>It is a cryptographic method that lets you check an individual game result wasn't altered after you bet. The casino commits to a hidden seed in advance, combines it with a seed from your side, then reveals it so you can verify the outcome. It typically covers a site's own games only and says nothing about whether the operator will pay withdrawals.</p>
        </details>
        <details>
          <summary>What can I do if a crypto casino won't pay out?</summary>
          <p>Your options are limited. Gather evidence: transaction IDs, chat logs and screenshots of the terms. Complain in writing to the casino, then to its licensor if it runs a complaints process. No Australian body can order an offshore operator to pay. You can report the site to ACMA, which may investigate and block it, but that won't recover your funds.</p>
        </details>
      </div>

      <h2 id="next-step">Before you deposit: your next step</h2>
      <p>Do one thing before any money moves: look the site up on ACMA's list of blocked gambling websites at acma.gov.au. If it's there, the regulator has already acted against it, so close the tab.</p>
      <p>If you're still weighing it up, decide the most you're prepared to lose in AUD, write that figure down somewhere you'll see it, and buy no more crypto than that. Then ask yourself honestly whether a licensed Australian option would give you the same entertainment with a regulator behind it. That could be a regulated bookmaker for sport and racing, or a land-based venue for pokies and table games. For many punters, the answer makes the Bitcoin question irrelevant.</p>
      <p><strong>Related reading:</strong> <a href="/bitcoin-casinos-australia-why-crypto/">Bitcoin Casinos Australia – Why Aussies Love Crypto: The Appeal and the Catch</a>, <a href="/crypto-casinos-australia-2026-how-to-evaluate/">Best Crypto Casinos Australia 2026: Bitcoin &amp; More, and How to Evaluate One</a>, <a href="/crypto-casinos-explained-benefits-and-risks/">Crypto Casinos Explained: Benefits and Risks</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
