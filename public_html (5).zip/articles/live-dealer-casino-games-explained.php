<?php
/**
 * Article: Live Dealer Casino Games Explained
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 *
 * OWNER NOTE: the text names three live-game studios (Evolution, Pragmatic Play Live, Playtech), two land-based
 * casinos (Crown, The Star) and the NSW Independent Casino Commission, as supplied. The page already says that
 * naming a studio implies nothing about its licences or legality in Australia; re-check the names and wording
 * before publishing.
 *
 * Layout notes:
 * - The left rail holds the "Top casino of the month" banner (gw_promo()) ABOVE the table of contents. Both stay in
 *   view together while you scroll. On phones the rail banner is hidden and the same banner is shown inside the
 *   article instead (after the blackjack section).
 * - The small <style> block in head_extra and the small script at the bottom only serve this rail.
 */
require __DIR__ . '/../includes/functions.php';
require __DIR__ . '/../includes/comparison.php';   // provides gw_promo()

$a   = gw_article('live-dealer-casino-games-explained');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
    'head_extra'  => '<style>
.story-side{position:sticky;top:calc(var(--head-h,72px) + 1rem);align-self:start;display:grid;gap:1.4rem;max-height:calc(100vh - var(--head-h,72px) - 2rem);overflow-y:auto;padding:.9rem .25rem .5rem;scrollbar-width:thin}
.story-side .toc{position:static}
.story-promo-m{display:none}
@media (max-width:960px){.story-side{position:static;max-height:none;overflow:visible;padding:0}.story-side .promo{display:none}.story-promo-m{display:block;margin:2rem 0 0}}
</style>',
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <div class="story-side">
        <?php gw_promo(); ?>
        <nav class="toc" aria-label="In this article">
          <h2>In this article</h2>
          <ol>
            <li><a href="#what-are">What live dealer games are</a></li>
            <li><a href="#studio">From studio to your screen</a></li>
            <li><a href="#blackjack">Live dealer blackjack</a></li>
            <li><a href="#other-tables">Roulette, baccarat and game shows</a></li>
            <li><a href="#legal">Are they legal in Australia?</a></li>
            <li><a href="#fairness">Fairness, pace and costs</a></li>
            <li><a href="#faq">FAQ</a></li>
            <li><a href="#takeaway">The takeaway</a></li>
          </ol>
        </nav>
      </div>
    </aside>

    <div class="story-body prose">
      <p>Live dealer casino games are real table games, such as blackjack, roulette and baccarat, run by a human dealer in a studio and streamed by video to players who bet through on-screen software. The cards, wheel and dealer are physical. The betting, record-keeping and payouts are digital. Think of it as a real table watched remotely, with software in place of chips.</p>
      <p>Australian readers need one fact up front. The <a href="https://www.acma.gov.au" rel="noopener">Australian Communications and Media Authority (ACMA)</a> lists online casinos among the services that providers must not offer to people in Australia under the Interactive Gambling Act 2001. Live dealer tables streamed online fall into that category.</p>
      <p>Most pages that promise live casino games explained turn out to be ranked lists of sites. This one has no rankings and no bonus offers. It covers how a round travels from studio to screen, how a hand of live dealer blackjack plays out, what the other tables look like, where the law stands and what to check on any live table.</p>

      <div class="formula tldr" role="note" aria-label="Short summary">
        <p class="formula-label">In short</p>
        <ul class="checks">
          <li><strong>Live dealer is a delivery format,</strong> not a different game: real cards, wheels and dice, streamed by video.</li>
          <li><strong>Scanners and sensors turn each result into data,</strong> and software settles every bet automatically.</li>
          <li><strong>Check each table's rules panel</strong> for payouts, soft 17, side bets and disconnection rules.</li>
          <li><strong>Online casino services, live dealer included, can't be offered to people in Australia.</strong> Licensed land-based casinos are lawful for adults.</li>
        </ul>
      </div>

      <h2 id="what-are">What Live Dealer Casino Games Are (and How They Differ From RNG Games)</h2>
      <figure class="shot"><?= gw_img('articles/ldg-what-are', 'Live dealer table with cards and chips beside the title Live Dealer Games Explained', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>The short answer</h3>
      <p>Live dealer is a delivery format. The games are the ones you already know: blackjack is still blackjack and roulette is still roulette. What changes is where the result comes from and how you see it.</p>
      <p>In a standard online table game, a random number generator (RNG) produces every outcome, and the cards or wheel on screen are animations. In a live dealer game, the outcome comes from physical equipment: a shoe of real cards, a real wheel, real dice. A dealer runs the game on camera, technology reads the result, and software handles your bets.</p>
      <p>If you've played at a table at Crown or The Star, the game itself will look familiar. The differences are in pace, interaction and, in Australia, who is allowed to offer it.</p>
      <h3>Live dealer vs RNG vs a land-based table</h3>
      <div class="table-wrap">
      <table class="data">
      <thead><tr><th scope="col">Feature</th><th scope="col">Live dealer (online)</th><th scope="col">RNG table game (online)</th><th scope="col">Land-based casino table</th></tr></thead>
      <tbody>
      <tr><th scope="row">Outcome source</th><td>Physical cards, wheel or dice, read by scanners and sensors</td><td>Software random number generator</td><td>Physical cards, wheel or dice</td></tr>
      <tr><th scope="row">Pace</th><td>Set by the dealer and a betting timer; slower than RNG</td><td>As fast as you click</td><td>Set by the dealer and the other players</td></tr>
      <tr><th scope="row">Minimum bets</th><td>Vary by table; often higher than RNG, since a studio and staff have to be paid for</td><td>Vary; often the lowest of the three</td><td>Vary by venue, table and time of day</td></tr>
      <tr><th scope="row">Interaction</th><td>Typed chat; the dealer replies aloud</td><td>None</td><td>Face to face with the dealer and other players</td></tr>
      <tr><th scope="row">Availability in Australia</th><td>Providers must not offer it online to people in Australia</td><td>Providers must not offer it online to people in Australia</td><td>Licensed casinos, for adults 18 and over</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="studio">How Live Dealer Games Work, From Studio to Your Screen</h2>
      <figure class="shot"><?= gw_img('articles/ldg-studio', 'Payment list with a clock beside the title From Studio to Your Screen', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>The studio, dealer and cameras</h3>
      <p>Most live tables are filmed in purpose-built studios run by specialist companies. Evolution, Pragmatic Play Live and Playtech are studio names you may see on a game's loading screen. Naming them here says nothing about their licences or whether their games may be offered in Australia. Some tables are streamed from the floor of a land-based casino instead.</p>
      <p>The dealer is a trained employee who deals to camera, not to a crowd. A monitor out of shot shows them the players' typed chat and prompts from the software. Several cameras cover each table, usually a wide shot plus close-ups of the cards or wheel, and the view switches as the round progresses.</p>
      <h3>How cards and spins become data</h3>
      <p>Software can't pay a bet until it knows the result, so every table needs a way to turn physical events into data:</p>
      <div class="mini3">
        <div><h3>Card scanning</h3><p>Cards typically carry barcodes that are read as they leave the shoe or pass a scanner in the table. Some setups use optical character recognition (OCR), where a camera reads the card face.</p></div>
        <div><h3>Wheel and dice sensors</h3><p>On roulette, sensors in the wheel detect the winning pocket. Dice games use cameras or sensors to read the roll.</p></div>
        <div><h3>Game control unit (GCU)</h3><p>A small device fixed to each table that encodes the video and links it to the game data. It keeps the stream, the on-screen result and your bet tied to the same round.</p></div>
      </div>
      <h3>The betting window, 'no more bets' and automatic payouts</h3>
      <p>Here is one round, in order:</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li><strong>Betting opens.</strong> A short timed window starts and you place chips on a digital layout.</li>
          <li><strong>No more bets.</strong> The dealer calls it and the software locks the layout. A bet that hasn't reached the server by then doesn't count.</li>
          <li><strong>The deal or spin.</strong> The dealer draws cards or spins the wheel as they would at a physical table. On roulette, the ball is often already spinning as the window closes.</li>
          <li><strong>Result capture.</strong> Scanners or sensors register the outcome and the GCU passes it to the game software.</li>
          <li><strong>Automatic settlement.</strong> The software works out every player's result and updates balances. The dealer never handles payouts.</li>
          <li><strong>Logging.</strong> The round is recorded with its own ID and the next betting window opens.</li>
        </ol>
      </div>
      <p>Video takes time to encode and travel, so what you see runs slightly behind the studio. The server's clock, not your picture, decides when betting closes. On a slow or unstable connection the delay grows, your time to act shrinks and late bets are rejected.</p>
      <p>A steady NBN connection or a strong mobile signal therefore matters more here than for RNG games. If you drop out mid-round, bets already accepted normally stand and the round finishes under the table's disconnection rules. Read those in advance.</p>
      <p class="see-also">For the technology in more depth, see <a href="/live-dealer-casino-games-how-they-work/">how live dealer games work</a> and <a href="/live-casino-australia-how-real-dealers-work/">how real dealers actually work</a>.</p>

      <h2 id="blackjack">Live Dealer Blackjack: How a Hand Plays Out</h2>
      <figure class="shot"><?= gw_img('articles/ldg-blackjack', 'Casino chips beside the title Live Dealer Blackjack Hand Play', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Blackjack is the live game with the most player decisions, so it shows the format best. Here is one hand, using an illustrative $10 bet:</p>
      <p>A live dealer blackjack hand follows the same steps as a table game, streamed in real time.</p>
      <div class="rg-card checklist-card">
        <ol class="checks checks--num">
          <li>You take a seat and place your $10 during the betting window.</li>
          <li>The dealer deals from the shoe: two cards face up to each seat and one face up to themselves, plus a face-down card under some rules. Each card is scanned and your total appears on screen.</li>
          <li>Play moves from seat to seat. On your turn, buttons for hit, stand, double and split appear beside a countdown timer. If the timer runs out, the software usually stands for you, so a lagging connection can cost you a decision.</li>
          <li>Once every seat has acted, the dealer plays their own hand to the table's fixed rules. They have no discretion.</li>
          <li>The software compares hands and settles. A standard win pays even money, a tie returns your stake, and a blackjack pays at the table's stated rate.</li>
        </ol>
      </div>
      <h3>Seven-seat tables, bet-behind and unlimited-seat formats</h3>
      <p>Seven-seat tables copy a casino table: one player per seat, and popular tables fill up. Bet-behind lets you wager on a seated player's hand while you wait. They make the decisions and you share the outcome. Unlimited-seat formats deal one starting hand to everyone, then let each player make their own choices, with the software tracking each result separately.</p>
      <p>Rules often differ between these formats, even within the same studio. Don't assume one table's rules carry over to the next.</p>
      <h3>Rules worth checking before you sit: blackjack payout, soft 17, side bets</h3>
      <p>Small rule changes matter more than which seat you take. Open the table's rules panel and look for:</p>
      <div class="bcards">
        <article class="bc">
          <p class="opt-tag">Check</p>
          <h3>Blackjack payout</h3>
          <p>3:2 or 6:5. On an illustrative $10 bet, a blackjack wins $15 at 3:2 and $12 at 6:5.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Check</p>
          <h3>Soft 17</h3>
          <p>Whether the dealer hits or stands on a hand such as ace-six. Standing is better for players.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Check</p>
          <h3>Doubling and splitting</h3>
          <p>Which totals you can double on, whether you can double after a split, and how many times you can split.</p>
        </article>
        <article class="bc">
          <p class="opt-tag">Check</p>
          <h3>Side bets</h3>
          <p>Options such as Perfect Pairs or 21+3 settle separately from your main hand and, as a rule, carry a larger house advantage.</p>
        </article>
      </div>
      <div class="example" role="group" aria-label="The numbers in the example">
        <div class="ex-col">
          <p class="ex-title">3:2 blackjack payout</p>
          <p class="ex-sum">$10 bet</p>
          <p class="ex-big">$15</p><p class="ex-lbl">won on a blackjack</p>
        </div>
        <div class="ex-col ex-col--hot">
          <p class="ex-title">6:5 blackjack payout</p>
          <p class="ex-sum">$10 bet</p>
          <p class="ex-big">$12</p><p class="ex-lbl">won on a blackjack</p>
        </div>
      </div>
      <p>We haven't quoted house-edge figures because they shift with every combination of these rules. The rules or help panel on each table lists its payouts and, where published, its theoretical return.</p>

      <div class="story-promo-m"><?php gw_promo(); ?></div>

      <h2 id="other-tables">Roulette, Baccarat and Game Shows: Other Live Tables Explained</h2>
      <figure class="shot"><?= gw_img('articles/ldg-other-tables', 'Roulette wheel beside the title Roulette Baccarat and Game Shows', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>Live roulette</h3>
      <p>A dealer spins a real wheel while you bet on a digital layout, with a close-up camera on the ball as it lands. Check whether the wheel has a single zero or a double zero, because that changes the odds on every bet. Some tables are automated, with a mechanical wheel and no dealer, which makes rounds quicker.</p>
      <p>Multiplier variants add randomly boosted payouts on selected numbers. They usually fund those boosts by paying less on an ordinary straight-up win, so the payout table differs from standard roulette.</p>
      <h3>Live baccarat and other card and dice tables</h3>
      <p>Baccarat suits the format because players make no decisions after betting. You back Player, Banker or a tie, and the dealer draws to fixed rules. Live versions add scoreboards of past results, which don't predict anything, and slow 'squeeze' card reveals. Commission and no-commission versions pay Banker wins differently.</p>
      <p>You may also see dragon tiger, sic bo, craps and casino poker games such as three card poker and casino hold'em. Most deal one hand or make one roll for everyone, so any number of players can bet on the same result.</p>
      <h3>Game-show and wheel formats</h3>
      <p>These were designed for streaming from the start. A presenter spins a large money wheel or runs a dice or board game, often with bonus rounds and multipliers. Outcomes swing widely: long stretches of small results, with an occasional large multiplier.</p>
      <p>Parts of the result, such as which multiplier applies, may be chosen by an RNG instead of physical equipment. The rules panel should say which, and should set out the payout for each segment.</p>
      <p class="see-also">For game-by-game rules and variants, see <a href="/live-dealer-casino-australia/">live dealer casino in Australia: how to judge sites for real games</a>.</p>

      <h2 id="legal">Are Live Dealer Games Legal in Australia?</h2>
      <figure class="shot"><?= gw_img('articles/ldg-legal', 'Shield with a tick beside the title Is Live Play Legal in Australia', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>What the Interactive Gambling Act says about online casino services</h3>
      <p>The Interactive Gambling Act 2001 is federal law, enforced by ACMA. ACMA's guidance lists online casinos, along with online pokies, among the services that gambling providers must not offer to people in Australia. No Australian licence allows a company to offer real-money online casino games to people here. Any website doing so is operating outside Australian law, usually from offshore, whatever its marketing says.</p>
      <p>Legal commentators generally describe the Act as aimed at providers, not individual players. That describes how the offences are framed. It is not legal advice, and it doesn't make an offshore site lawful or safe. ACMA warns that illegal services are unlikely to offer the consumer protections Australians expect, and that Australian law may not help if a provider withholds your money. ACMA also asks internet service providers to block illegal gambling websites, so a site can disappear without notice.</p>
      <p>Some websites promote sweepstakes or 'social' casinos as a legal alternative. Don't take that on a promoter's word. Ask ACMA.</p>
      <h3>Where Australians can lawfully play dealer-run table games</h3>
      <p>Dealer-run blackjack, roulette and baccarat are lawfully offered at licensed land-based casinos, each supervised by a state or territory regulator, for adults aged 18 and over. Rules, table limits and any electronic versions of table games differ from venue to venue, so ask on the floor how a particular game works.</p>
      <h3>How to check with ACMA</h3>
      <p>Go to <a href="https://www.acma.gov.au" rel="noopener">acma.gov.au</a> and search for its pages on illegal gambling services. ACMA explains which services are prohibited, keeps a register of licensed interactive wagering providers (that register covers betting services, not casino games) and takes complaints about illegal sites.</p>
      <p>The guidance is updated as the Act is amended, including on advertising and enforcement, so rely on the current page over any article, this one included. For questions about a land-based casino, contact your state or territory regulator, such as the Victorian Gambling and Casino Control Commission or the NSW Independent Casino Commission.</p>
      <p class="see-also">For the wider legal picture, see <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>

      <h2 id="fairness">Fairness, Pace and Costs: What to Check on Any Live Table</h2>
      <figure class="shot"><?= gw_img('articles/ldg-fairness', 'Document with a magnifying glass beside the title Fairness Pace and Costs', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <h3>How fairness is supposed to be assured, and its limits</h3>
      <p>Live games rely on procedure. Shuffles and shoe changes happen in view, cameras cover every table, supervisors watch the floor, and each round is logged with an ID you can look up in the game history. Where an operator and studio are licensed, regulators and independent test labs are meant to check the equipment and procedures.</p>
      <p>As a viewer you can't verify any of this yourself, and a logo in a website footer proves nothing. No Australian regulator stands behind a site that is offered here illegally. Fairness is only as strong as the licence and oversight behind the table.</p>
      <h3>Table limits, round speed and data use</h3>
      <div class="rg-card">
        <ul class="checks">
          <li><strong>Rules panel:</strong> usually behind an 'i', '?' or menu icon. It should list payouts, dealer rules and any published return information. If you can't find one, treat that as a warning.</li>
          <li><strong>Limits:</strong> minimum and maximum bets are shown on the table itself and vary widely. Side bets often have their own limits.</li>
          <li><strong>Round speed:</strong> the timer keeps rounds coming. More rounds per hour means more money wagered per hour.</li>
          <li><strong>Disconnection rules:</strong> know what happens to a live bet if your connection drops.</li>
          <li><strong>Data use:</strong> continuous video uses far more data than an RNG game. On a mobile plan, lower the stream quality.</li>
        </ul>
      </div>
      <h3>Setting limits before you play</h3>
      <div class="rg-card">
      <p>Gambling in Australia is for adults aged 18 and over. The house has an advantage on every game described here, and no strategy, seat or variant guarantees a win. Before any session, at a venue or anywhere else, decide how much you can afford to lose and how long you'll play. As an illustration, that might be $50 and 45 minutes. Stop when either runs out.</p>
      <p>If gambling stops being fun or you find yourself chasing losses, <a href="https://www.gamblinghelponline.org.au" rel="noopener">Gambling Help Online</a> offers free, confidential support 24 hours a day on <a href="tel:1800858858">1800 858 858</a>. <a href="https://www.betstop.gov.au" rel="noopener">BetStop</a>, the National Self-Exclusion Register, covers licensed Australian online and phone wagering providers. It does not extend to offshore casino sites.</p>
      </div>
      <p class="see-also">Practical steps: <a href="/how-to-set-deposit-and-loss-limits-australia/">how to set deposit and loss limits</a> and our <a href="/responsible-gambling/">responsible gambling page</a>.</p>

      <h2 id="faq">Live Dealer Casino Games FAQ</h2>
      <div class="faq">
        <details>
          <summary>Are live dealer games rigged?</summary>
          <p>The format isn't designed to be. Results come from physical cards and wheels, and the house earns its margin through the rules, not tampering. Whether a particular table is run honestly depends on who operates it and who oversees them. You can't confirm that from your screen, which is why licensing matters.</p>
        </details>
        <details>
          <summary>Can the dealer see or hear me?</summary>
          <p>No. In the standard format the dealer has a monitor showing screen names and typed chat messages, and answers out loud. They can't see or hear you through your camera or microphone. Chat is usually moderated and logged, so treat anything you type as public.</p>
        </details>
        <details>
          <summary>Can I play live dealer games for free?</summary>
          <p>Rarely. Live tables cost money to staff and stream, so demo modes are uncommon. RNG games, by contrast, often have a play-money version. Some operators let account holders watch without betting. None of this changes the legal position on online casino services in Australia.</p>
        </details>
        <details>
          <summary>Is live dealer blackjack the same as blackjack in a casino?</summary>
          <p>The core rules are the same, but details differ. Online tables use a decision timer, may add bet-behind or shared-hand formats, and settle bets by software. Payouts, soft 17 rules and side bets vary from table to table, online and in venues, so check each one.</p>
        </details>
        <details>
          <summary>Is it legal to play live dealer games online in Australia?</summary>
          <p>Providers must not offer online casino services, including live dealer games, to people in Australia under the Interactive Gambling Act 2001. The Act is generally described as aimed at providers, but that doesn't make online play lawful or safe. Check ACMA for the current position. Dealer-run tables at licensed land-based casinos are lawful for adults.</p>
        </details>
      </div>

      <h2 id="takeaway">The Takeaway: Know the Format and the Law Before You Play</h2>
      <figure class="shot"><?= gw_img('articles/ldg-takeaway', 'Limit sliders beside the title Know the Format and the Law', ['sizes' => '(min-width: 960px) 700px, 100vw']) ?></figure>
      <p>Live dealer casino games are ordinary table games with cameras, scanners and settlement software added. The technology doesn't change the house advantage, and it doesn't change the law. Online casino services can't be offered to people in Australia, and dealer-run tables are lawfully available at licensed land-based casinos.</p>
      <p>Before you trust any site's claims about legality, read ACMA's current guidance. Wherever you do sit at a table, open the rules panel first to check payouts and limits, and set a money and time limit in advance.</p>
      <p><strong>Related reading:</strong> <a href="/live-casinos-australia-what-to-check/">Top 10 Live Casinos Australia for Real Dealers: 10 Things to Check</a>, <a href="/live-dealer-casino-australia/">Live Dealer Casino Australia: How to Judge Sites for Real Games</a>, <a href="/live-casino-australia-how-real-dealers-work/">Live Casino Australia – How Real Dealers Actually Work</a>, <a href="/live-dealer-casino-games-how-they-work/">Live Dealer Casino Games: How They Work</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
<script>
/* keeps the highlighted contents link in view inside the sticky sidebar (the banner above it makes the box scrollable on short screens) */
(function(){var box=document.querySelector('.story-side'),toc=document.querySelector('.story-side .toc');if(!box||!toc||!window.MutationObserver)return;
function keep(){var a=toc.querySelector('a.is-active');if(!a||box.scrollHeight<=box.clientHeight)return;var ar=a.getBoundingClientRect(),br=box.getBoundingClientRect();if(ar.top<br.top+8||ar.bottom>br.bottom-8){box.scrollTop+=ar.top-br.top-box.clientHeight/2;}}
new MutationObserver(keep).observe(toc,{subtree:true,attributes:true,attributeFilter:['class']});})();
</script>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
