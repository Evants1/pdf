<?php
/**
 * Article: Understanding Australian Online Gambling Regulations
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('understanding-australian-online-gambling-regulations');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#map">Who regulates what</a></li>
          <li><a href="#acma">ACMA online gambling enforcement</a></li>
          <li><a href="#states">State and territory regulators</a></li>
          <li><a href="#finance">Money and data</a></li>
          <li><a href="#where">Where to take what</a></li>
          <li><a href="#scenarios">How a complaint travels</a></li>
          <li><a href="#limits">The limits of regulation</a></li>
          <li><a href="#faq">Quick answers</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>Australia has no single gambling regulator. Responsibilities are split between federal agencies and state and territory authorities, and each covers different ground. This guide maps who regulates what in Australian online gambling regulations, from ACMA online gambling enforcement to AUSTRAC, so you know where a question or complaint belongs. For the law itself, see <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a>.</p>

      <aside class="note">
      <p><strong>Australian readers.</strong> This is general information, not legal advice. Roles and powers change, so confirm details on each regulator's own website.</p>
      </aside>

      <h2 id="map">Who regulates what</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>The main bodies and their roles</caption>
      <thead><tr><th scope="col">Body</th><th scope="col">Role</th></tr></thead>
      <tbody>
      <tr><th scope="row">ACMA</th><td>Enforces the Interactive Gambling Act, including action on illegal offshore services and blocking, and runs BetStop</td></tr>
      <tr><th scope="row">State and territory regulators</th><td>License and oversee venues, casinos, pokies and licensed wagering providers in their jurisdictions</td></tr>
      <tr><th scope="row">AUSTRAC</th><td>Supervises anti-money-laundering and counter-terrorism financing obligations, and registers digital currency exchanges</td></tr>
      <tr><th scope="row">OAIC</th><td>Handles privacy complaints under the Privacy Act where it applies</td></tr>
      <tr><th scope="row">ACCC and state fair trading bodies</th><td>Consumer law, including misleading conduct</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="acma">ACMA online gambling enforcement</h2>
      <p>ACMA enforces the Act's prohibitions on offering and advertising prohibited online gambling services. Its tools include investigations, warnings and working with internet providers to block sites. It does not resolve individual payout disputes or recover money, so a blocked site is not a safety rating and an unblocked one is not an approval.</p>

      <h2 id="states">State and territory regulators</h2>
      <p>Licensed wagering and venue gambling are overseen by state and territory authorities. For example, the Northern Territory Racing Commission licenses a number of corporate bookmakers. These licences cover sports and racing betting and do not extend to online casino games.</p>

      <h2 id="finance">Money and data</h2>
      <ul>
      <li><strong>AUSTRAC</strong> covers financial crime obligations for regulated businesses and registers digital currency exchanges.</li>
      <li><strong>The OAIC</strong> deals with privacy complaints, but its reach over an overseas operator is limited.</li>
      <li><strong>Your bank</strong> sits outside this list but is often the practical route for a disputed payment.</li>
      </ul>

      <h2 id="where">Where to take what</h2>
      <ul>
      <li>An illegal gambling website or advertisement: ACMA.</li>
      <li>A scam: Scamwatch, and your bank.</li>
      <li>A licensed wagering dispute: the provider, then its licensing authority.</li>
      <li>A privacy concern: the organisation first, then the OAIC.</li>
      </ul>
      <p>More on recourse is in <a href="/safe-and-trusted-online-casinos/">safe and trusted online casinos</a>.</p>

      <h2 id="scenarios">How a complaint travels</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Three scenarios (general, not legal advice)</caption>
      <thead><tr><th scope="col">Situation</th><th scope="col">Where to start</th></tr></thead>
      <tbody>
      <tr><th scope="row">You see an advert for an online casino aimed at Australians</th><td>ACMA's complaints process</td></tr>
      <tr><th scope="row">A licensed betting provider closes your account unfairly</th><td>The provider, then its state or territory regulator</td></tr>
      <tr><th scope="row">An offshore casino refuses a payout</th><td>Your bank, Scamwatch and the operator's complaints process, though recovery is uncertain</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="limits">The limits of regulation</h2>
      <ul>
      <li>Australian regulators have no licensing power over an overseas casino.</li>
      <li>Consumer and privacy laws exist, but enforcing them against an overseas company is difficult.</li>
      <li>Enforcement focuses on stopping the service, not on recovering your money.</li>
      </ul>

      <h2 id="faq">Quick answers</h2>
      <h3>Is there one national gambling regulator?</h3>
      <p>No. See the table above for how roles are split.</p>
      <h3>Where do I check current rules?</h3>
      <p>ACMA and the Federal Register of Legislation. See <a href="/online-gambling-laws-in-australia-2026/">online gambling laws in Australia 2026</a>.</p>
      <p><strong>Related reading:</strong> <a href="/online-casinos-australia-pros-cons-legality/">Online Casinos Australia – Pros, Cons &amp; Legality</a>, <a href="/kyc-verification-at-online-casinos/">KYC Verification at Online Casinos: What to Expect</a>, <a href="/kyc-verification-at-online-casinos-australia/">KYC Verification at Online Casinos Australia</a>, <a href="/online-gambling-laws-in-australia/">Online Gambling Laws in Australia: What Players Should Know</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
