<?php
/**
 * Article: Online Gambling Laws in Australia: What Players Should Know
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('online-gambling-laws-in-australia');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#two-things">Wagering and casino games are treated differently</a></li>
          <li><a href="#iga">The Interactive Gambling Act</a></li>
          <li><a href="#who">Who regulates what</a></li>
          <li><a href="#protections">Protections for licensed wagering</a></li>
          <li><a href="#tax">What about tax?</a></li>
          <li><a href="#checking">How to check where you stand</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>Australia treats two things very differently: online <strong>wagering</strong> (sports and racing betting) and online <strong>casino games</strong> such as pokies, blackjack and roulette. Understanding the difference is the starting point for any Australian reader. This is general information, not legal advice, and the rules change, so confirm details with the regulators named below.</p>

      <h2 id="two-things">Wagering and casino games are treated differently</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>The basic position for people in Australia</caption>
      <thead><tr><th scope="col">Activity</th><th scope="col">Position</th><th scope="col">Who oversees it</th></tr></thead>
      <tbody>
      <tr><th scope="row">Online sports and racing betting</th><td>Can be offered by operators licensed in Australia</td><td>A state or territory regulator, plus national rules</td></tr>
      <tr><th scope="row">Online casino games (pokies, table games)</th><td>The Interactive Gambling Act 2001 prohibits offering them to people in Australia</td><td>The Australian Communications and Media Authority (ACMA)</td></tr>
      <tr><th scope="row">Pokies and casinos in physical venues</th><td>Legal and licensed by each state or territory</td><td>State and territory gambling regulators</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="iga">The Interactive Gambling Act</h2>
      <p>The Interactive Gambling Act 2001 is a Commonwealth law. It is aimed mainly at the businesses that provide prohibited interactive gambling services to people in Australia, not at individual players. ACMA enforces it, including by issuing warnings and asking internet providers to block offending websites. A casino site holding a licence from another country, for example Malta or Curaçao, does not give that operator permission to offer casino games to people in Australia.</p>
      <p>For players this has a practical consequence. Even where playing is not itself an offence, an offshore casino that is not authorised in Australia sits outside Australian consumer protections, Australian dispute processes and Australian safer gambling schemes. If a withdrawal is refused, there may be no regulator in Australia that can help.</p>

      <h2 id="who">Who regulates what</h2>
      <ul>
      <li><strong>ACMA</strong> enforces the Interactive Gambling Act and publishes information on illegal gambling services.</li>
      <li><strong>State and territory regulators</strong> license wagering operators and venues. Examples include the Victorian Gambling and Casino Control Commission, the NSW Independent Liquor and Gaming Authority and the Northern Territory Racing Commission.</li>
      <li><strong>AUSTRAC</strong> supervises anti-money-laundering and counter-terrorism financing obligations for reporting entities, which is why identity checks exist. See <a href="/kyc-verification-at-online-casinos/">our KYC guide</a>.</li>
      </ul>

      <h2 id="protections">Protections for licensed wagering</h2>
      <p>Under national consumer protection measures, licensed Australian online wagering providers are subject to rules that include:</p>
      <ul>
      <li><strong>BetStop</strong>, the national self-exclusion register, which lets you exclude yourself from all licensed online and phone wagering providers in one step.</li>
      <li><strong>Identity verification</strong> within a set period of account opening.</li>
      <li><strong>No credit for gambling.</strong> Since 11 June 2024, credit cards cannot be used for online wagering with licensed providers.</li>
      <li><strong>Restrictions on sign-up inducements.</strong> Licensed providers generally cannot offer bonuses to entice people to open an account. That is one reason large welcome offers are mostly associated with offshore sites. See <a href="/how-casino-welcome-bonuses-work/">how welcome bonuses work</a>.</li>
      </ul>
      <p>These protections apply to licensed Australian wagering. They do not follow you to an offshore casino.</p>

      <h2 id="tax">What about tax?</h2>
      <p>As we understand it, gambling winnings are generally not treated as taxable income for people who gamble recreationally in Australia, but the position can differ for someone who gambles as a business. Check the Australian Taxation Office guidance or ask a registered tax adviser about your circumstances.</p>

      <h2 id="checking">How to check where you stand</h2>
      <ol>
      <li>Ask whether the product is wagering or a casino-style game. They are regulated very differently.</li>
      <li>For wagering, confirm the operator's Australian licence on the relevant state or territory regulator's website and check that it participates in BetStop.</li>
      <li>For anything else, read what ACMA says about illegal gambling services and consider the lack of local protections before you deposit.</li>
      <li>If in doubt, take advice from a legal professional.</li>
      </ol>
      <p>If you would like help setting limits or taking a break, see <a href="/responsible-gambling-tools-limits-and-self-exclusion/">our responsible gambling tools guide</a> and our <a href="/responsible-gambling/">responsible gambling page</a>. For the wider checklist, read <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a> and <a href="/safe-and-trusted-online-casinos/">how to identify a safe and trusted operator</a>.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
