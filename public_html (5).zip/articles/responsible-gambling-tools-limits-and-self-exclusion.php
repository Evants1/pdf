<?php
/**
 * Article: Responsible Gambling Tools: Limits, Time-Outs and Self-Exclusion
 * Metadata (title, description, dates) comes from includes/content.php.
 * The article text below is this page's own content: edit it freely.
 */
require __DIR__ . '/../includes/functions.php';

$a   = gw_article('responsible-gambling-tools-limits-and-self-exclusion');
$cat = gw_category($a['category']);
$url = '/' . $a['slug'] . '/';

$seo = [
    'title'       => $a['seo_title'],
    'description' => $a['description'],
    'path'        => $url,
    'og_type'     => 'article',
    'image'       => 'articles/' . $a['slug'] . '.jpg',
    'image_alt'   => $a['alt'],
    'published'   => $a['date'],
    'modified'    => $a['updated'],
    'section'     => $cat['label'],
    'body_class'  => 'is-article',
    'breadcrumbs' => [['Home', '/'], [$cat['label'], $cat['path']], [$a['title'], $url]],
    'schema'      => [gw_article_schema($a)],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
<article class="story">
  <header class="story-head wrap">
    <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
    <p class="tag tag--<?= e($a['category']) ?>"><a href="<?= e($cat['path']) ?>"><?= e($cat['label']) ?></a></p>
    <h1><?= e($a['title']) ?></h1>
    <p class="story-dek"><?= e($a['excerpt']) ?></p>
    <p class="story-meta">
      <span>By <?= e(SITE_NAME) ?> Editorial</span>
      <span>Published <time datetime="<?= e($a['date']) ?>"><?= e(gw_date($a['date'])) ?></time></span>
      <?php if ($a['updated'] !== $a['date']): ?><span>Updated <time datetime="<?= e($a['updated']) ?>"><?= e(gw_date($a['updated'])) ?></time></span><?php endif; ?>
      <span><?= (int) $a['minutes'] ?> min read</span>
    </p>
  </header>

  <figure class="story-hero wrap">
    <?= gw_img('articles/' . $a['slug'], $a['alt'], ['eager' => true, 'sizes' => '(min-width: 1180px) 1140px, 100vw']) ?>
  </figure>

  <div class="story-layout wrap">
    <aside class="story-rail">
      <nav class="toc" aria-label="In this article">
        <h2>In this article</h2>
        <ol>
          <li><a href="#before">Before you play</a></li>
          <li><a href="#tools">The main tools</a></li>
          <li><a href="#self-exclusion">Self-exclusion in more detail</a></li>
          <li><a href="#signs">Warning signs</a></li>
          <li><a href="#help">Where to find independent help</a></li>
          <li><a href="#choosing">Choosing a casino that supports you</a></li>
        </ol>
      </nav>
    </aside>

    <div class="story-body prose">
      <p>Gambling should be entertainment that you pay for, in money and time you can afford. Licensed casinos provide tools to help you stay within your own limits. They work best when you set them up before you start playing, not after a bad session. This guide explains what each tool does and where to find independent help.</p>

      <h2 id="before">Before you play</h2>
      <ul>
      <li>Decide how much you can afford to lose, treating it as the cost of entertainment.</li>
      <li>Never gamble with money needed for rent, bills, food or debts.</li>
      <li>Do not gamble to make money, to recover losses or to escape stress.</li>
      <li>Decide a time limit as well as a money limit.</li>
      </ul>

      <h2 id="tools">The main tools</h2>
      <div class="table-wrap">
      <table class="data">
      <caption>Common safer gambling tools and what they do</caption>
      <thead><tr><th scope="col">Tool</th><th scope="col">What it does</th><th scope="col">Good to know</th></tr></thead>
      <tbody>
      <tr><th scope="row">Deposit limit</th><td>Caps how much you can deposit per day, week or month</td><td>Lowering a limit usually takes effect immediately, while raising one is often delayed</td></tr>
      <tr><th scope="row">Loss limit</th><td>Caps your net losses over a period</td><td>Useful for avoiding chasing losses</td></tr>
      <tr><th scope="row">Wager limit</th><td>Caps the total you can stake in a period</td><td>Not offered by every operator</td></tr>
      <tr><th scope="row">Session time limit</th><td>Ends or warns you when a set time has passed</td><td>Pair with a money limit</td></tr>
      <tr><th scope="row">Reality check</th><td>Pop-up reminders showing how long you have played</td><td>Choose a short interval and do not dismiss it automatically</td></tr>
      <tr><th scope="row">Time-out or cool-off</th><td>Blocks your account for a short, fixed period</td><td>Typically from 24 hours to several weeks</td></tr>
      <tr><th scope="row">Self-exclusion</th><td>Blocks your account for a long period, often six months or more</td><td>Usually cannot be reversed early</td></tr>
      </tbody>
      </table>
      </div>

      <h2 id="self-exclusion">Self-exclusion in more detail</h2>
      <p>Self-exclusion is a formal agreement to stay away from gambling for a fixed period. In Australia, <strong>BetStop</strong> (betstop.gov.au) is the national self-exclusion register for licensed online and phone wagering providers. Register once and all licensed wagering operators must close your accounts and stop sending you marketing. You can choose to exclude for a period or permanently.</p>
      <p>BetStop does not cover pokies in venues, which have their own state and territory venue exclusion programs, and it does not cover offshore casino websites. Some people also use website-blocking software, and many Australian banks offer gambling transaction blocks on request.</p>

      <h2 id="signs">Warning signs</h2>
      <p>Consider taking a break and getting support if you notice that you:</p>
      <ul>
      <li>Spend more money or time than you planned, often.</li>
      <li>Chase losses by increasing bets or depositing again.</li>
      <li>Borrow money, sell belongings or hide your gambling.</li>
      <li>Feel anxious, irritable or low when you are not gambling.</li>
      <li>Neglect work, family or other responsibilities.</li>
      </ul>

      <h2 id="help">Where to find independent help</h2>
      <p>These services are free and confidential. Please verify contact details on each organisation's website, because they can change.</p>
      <ul>
      <li><strong>Gambling Help Online:</strong> 1800 858 858, 24 hours a day, plus online chat and counselling at gamblinghelponline.org.au.</li>
      <li><strong>BetStop:</strong> betstop.gov.au, to exclude yourself from licensed online wagering.</li>
      <li><strong>Lifeline:</strong> 13 11 14 for crisis support.</li>
      <li>In an emergency, call 000.</li>
      </ul>

      <h2 id="choosing">Choosing a casino that supports you</h2>
      <p>A good operator makes these tools easy to find, applies them immediately and does not push promotions at players who have asked for a break. Check the account settings before you register, as we recommend in <a href="/how-to-choose-a-real-money-online-casino/">how to choose a real-money online casino</a>. Our <a href="/responsible-gambling/">responsible gambling page</a> sets out the standards we hold ourselves to. If you are 18 or over and gambling feels out of control, please talk to someone today.</p>

      <aside class="rg-note" aria-label="Responsible gambling reminder">
        <p><strong>Play responsibly.</strong> 18+ only. Gambling can be addictive and there is no guaranteed way to win. Only stake what you can afford to lose. Free, confidential help is available from Gambling Help Online on 1800 858 858. See our <a href="/responsible-gambling/">responsible gambling page</a>. Some links on this site may be affiliate links: see our <a href="/about/#disclosure">disclosure</a>.</p>
      </aside>
    </div>
  </div>

  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Keep reading</h2>
      <div class="related-grid">
<?php foreach ($a['related'] as $slug): $r = gw_article($slug); if ($r) { echo gw_card($r, 'std'); } endforeach; ?>
      </div>
    </div>
  </section>
</article>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
