<?php

function gw_operator(): array
{
    return [
    'name'    => 'the GrandWhisper editorial team, an online publishing team',
    'abn'     => '',
    'address' => 'operated online from Your Country',
    ];
}

function gw_operator_line(): string
{
    $o = gw_operator();
    if (empty($o['name'])) {
        return '';
    }
    $line = 'GrandWhisper is published by ' . $o['name'];
    if (!empty($o['abn']))     { $line .= ' (ABN ' . $o['abn'] . ')'; }
    if (!empty($o['address'])) { $line .= ', ' . $o['address']; }
    return $line . '.';
}