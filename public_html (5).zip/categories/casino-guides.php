<?php
/** Category page: Casino Guides (served at /category/casino-guides/). */
require __DIR__ . '/../includes/functions.php';

$cat  = gw_category('casino-guides');
$list = gw_articles('casino-guides');

$seo = [
    'title'       => 'Casino Guides: Bonuses, Withdrawals and Safety',
    'description' => 'Practical online casino guides covering how to choose a casino, welcome bonuses, withdrawal speed, ID checks, slot RTP and responsible gambling tools.',
    'path'        => $cat['path'],
    'image'       => 'pages/casino-guides.jpg',
    'image_alt'   => $cat['alt'],
    'body_class'  => 'is-category',
    'breadcrumbs' => [['Home', '/'], ['Casino Guides', $cat['path']]],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
  <header class="cat-head">
    <div class="wrap cat-head-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <h1>Casino Guides</h1>
        <p class="lead">Step-by-step help for the questions that come up before, during and after you sign up: what bonus terms really mean, why a withdrawal stalls, how game maths works, and how to stay in control.</p>
      </div>
      <?= gw_img('pages/casino-guides', $cat['alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 460px, 100vw']) ?>
    </div>
  </header>

  <div class="wrap cat-grid">
<?php foreach ($list as $i => $a) { echo gw_card($a, $i === 0 ? 'feature' : 'std', 2); } ?>
  </div>

  <div class="wrap cat-other">
    <p>Want the bigger picture? Read our permanent guides to <a href="/best-online-casinos/">the best online casinos</a> and <a href="/online-casino-bonuses/">online casino bonuses</a>, or browse <a href="/category/casino-news/">casino news and explainers</a>.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
