<?php
/** Category page: Casino News (served at /category/casino-news/). */
require __DIR__ . '/../includes/functions.php';

$cat  = gw_category('casino-news');
$list = gw_articles('casino-news');

$seo = [
    'title'       => 'Casino News and Explainers',
    'description' => 'Explainers and analysis on how online casino technology, payments and regulation work, from crypto and live dealer games to mobile play and licensing.',
    'path'        => $cat['path'],
    'image'       => 'pages/casino-news.jpg',
    'image_alt'   => $cat['alt'],
    'body_class'  => 'is-category',
    'breadcrumbs' => [['Home', '/'], ['Casino News', $cat['path']]],
];
require __DIR__ . '/../includes/header.php';
?>
<main id="main">
  <header class="cat-head">
    <div class="wrap cat-head-grid">
      <div>
        <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
        <h1>Casino News</h1>
        <p class="lead">How the technology, payments and rules behind online casinos are changing, explained without hype. We focus on what a development means for players, not on press releases or offers.</p>
      </div>
      <?= gw_img('pages/casino-news', $cat['alt'], ['eager' => true, 'sizes' => '(min-width: 960px) 460px, 100vw']) ?>
    </div>
  </header>

  <div class="wrap cat-grid">
<?php foreach ($list as $i => $a) { echo gw_card($a, $i === 0 ? 'feature' : 'std', 2); } ?>
  </div>

  <div class="wrap cat-other">
    <p>Looking for how-to advice instead? Browse our <a href="/category/casino-guides/">casino guides</a>, or start with <a href="/safe-and-trusted-online-casinos/">how to identify a safe and trusted casino</a>.</p>
  </div>
</main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
