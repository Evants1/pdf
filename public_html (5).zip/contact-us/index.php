<?php
$pageTitle = "Contact Us | Next Draw Logic";
$metaDesc = "Get in touch with the Next Draw Logic team. Report a bug, ask a question about our ticket checker, or inquire about partnerships.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

// Basic form handling logic (For demonstration - you can connect this to your mailer later)
$formSubmitted = false;
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    // In a real environment, you would use mail() or PHPMailer here.
    $formSubmitted = true;
}
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Structured Data for SEO Trust -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ContactPage",
      "mainEntity": {
        "@type": "Organization",
        "name": "Next Draw Logic",
        "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>",
        "contactPoint": {
          "@type": "ContactPoint",
          "email": "support@nextdrawlogic.co.za",
          "contactType": "customer support",
          "availableLanguage": "English"
        }
      }
    }
    </script>

    <style>
        /* Modern Wrapper & Layout */
        .contact-wrapper {
            padding: 60px 20px;
            background-color: #f8fafc;
            min-height: calc(100vh - 200px);
        }

        .contact-grid {
            max-width: 1200px;
            margin: 0 auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 40px;
            align-items: start;
        }

        /* Typography */
        .page-header {
            grid-column: 1 / -1;
            text-align: center;
            margin-bottom: 20px;
        }

        .page-header h1 {
            font-size: 2.8rem;
            color: #0f172a;
            margin: 0 0 16px 0;
            font-weight: 800;
            letter-spacing: -0.03em;
        }
        
        .page-header {
    position: unset !important;
    z-index: unset !important;
}


        .page-header p {
            font-size: 1.15rem;
            color: #64748b;
            max-width: 600px;
            margin: 0 auto;
            line-height: 1.6;
        }

        /* Left Column: Info & FAQs */
        .info-card {
            background: #ffffff;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
        }

        .contact-method {
            display: flex;
            align-items: center;
            gap: 16px;
            margin-bottom: 32px;
            padding-bottom: 24px;
            border-bottom: 1px solid #f1f5f9;
        }

        .icon-circle {
            width: 56px;
            height: 56px;
            background: #e0e7ff;
            color: var(--primary, #4f46e5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            flex-shrink: 0;
        }

        .method-details h3 {
            margin: 0 0 4px 0;
            font-size: 1.1rem;
            color: #0f172a;
        }

        .method-details a {
            color: var(--primary, #4f46e5);
            font-weight: 700;
            text-decoration: none;
            font-size: 1.05rem;
        }

        .method-details p {
            margin: 4px 0 0 0;
            font-size: 0.9rem;
            color: #64748b;
        }

        /* Trust Notice */
        .trust-notice {
            background: #fffbeb;
            border-left: 4px solid #f59e0b;
            padding: 20px;
            border-radius: 0 12px 12px 0;
            margin-bottom: 32px;
        }
        
        .trust-notice strong { color: #b45309; display: block; margin-bottom: 8px; font-size: 1.05rem;}
        .trust-notice p { margin: 0; color: #78350f; font-size: 0.95rem; line-height: 1.5; }

        /* FAQs */
        .faq-block h2 {
            font-size: 1.4rem;
            color: #0f172a;
            margin-bottom: 20px;
            font-weight: 800;
        }

        .faq-item {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            margin-bottom: 16px;
        }

        .faq-item h4 {
            margin: 0 0 8px 0;
            color: #1e293b;
            font-size: 1.05rem;
        }

        .faq-item p {
            margin: 0;
            color: #475569;
            font-size: 0.95rem;
            line-height: 1.5;
        }

        /* Right Column: Form */
        .form-card {
            background: #ffffff;
            border-radius: 24px;
            padding: 40px;
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05);
            border: 1px solid #e2e8f0;
            position: sticky;
            top: 100px; /* Sticks the form on desktop scrolling */
        }

        .form-card h2 {
            margin: 0 0 24px 0;
            font-size: 1.6rem;
            color: #0f172a;
            font-weight: 800;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #334155;
            font-size: 0.95rem;
        }

        .form-control {
            width: 100%;
            padding: 14px 16px;
            border: 2px solid #e2e8f0;
            border-radius: 12px;
            font-size: 1rem;
            font-family: inherit;
            color: #0f172a;
            transition: all 0.2s ease;
            background: #f8fafc;
            box-sizing: border-box;
        }

        .form-control:focus {
            outline: none;
            border-color: var(--primary, #4f46e5);
            background: #ffffff;
            box-shadow: 0 0 0 4px rgba(79, 70, 229, 0.1);
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .btn-submit {
            width: 100%;
            background: linear-gradient(135deg, var(--primary, #4f46e5), #4338ca);
            color: white;
            border: none;
            padding: 16px;
            border-radius: 12px;
            font-size: 1.1rem;
            font-weight: 800;
            cursor: pointer;
            transition: all 0.2s ease;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(79, 70, 229, 0.3);
        }

        .success-message {
            background: #ecfdf5;
            border: 1px solid #a7f3d0;
            color: #065f46;
            padding: 24px;
            border-radius: 12px;
            text-align: center;
        }
        
        .success-message h3 { margin: 0 0 8px 0; font-size: 1.3rem;}
        .success-message p { margin: 0; font-size: 1rem; }

        /* Mobile Responsiveness */
        @media (max-width: 900px) {
            .contact-grid { grid-template-columns: 1fr; }
            .form-card { position: static; order: -1; } /* Form moves to top on mobile */
            .contact-wrapper { padding: 40px 15px; }
            .info-card, .form-card { padding: 30px 20px; }
            .page-header h1 { font-size: 2.2rem; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../static/nav.php'; ?>

    <div class="contact-wrapper">
        <div class="contact-grid">
            
            <header class="page-header">
                <h1>Get in Touch</h1>
                <p>Have a question about our ticket checker, found a bug, or want to partner with us? Fill out the form or use our direct contact info below.</p>
            </header>

            <!-- Left Column: Trust Info & FAQs -->
            <div class="info-card">
                
                <div class="contact-method">
                    <div class="icon-circle">📧</div>
                    <div class="method-details">
                        <h3>Email Support</h3>
                        <a href="mailto:support@nextdrawlogic.co.za">support@nextdrawlogic.co.za</a>
                        <p>We aim to reply within 24-48 hours.</p>
                    </div>
                </div>

                <div class="trust-notice">
                    <strong>⚠️ Important Notice</strong>
                    <p>Next Draw Logic is an independent data and analytics portal. <strong>We do not sell lottery tickets</strong> and we cannot help you claim lost tickets or prizes. Please contact Ithuba directly for official claims.</p>
                </div>

                <div class="faq-block">
                    <h2>Frequently Asked Questions</h2>
                    
                    <div class="faq-item">
                        <h4>Can I buy tickets on this site?</h4>
                        <p>No. We only provide results and data analysis. To buy tickets, visit the official National Lottery website or an authorized retailer.</p>
                    </div>
                    
                    <div class="faq-item">
                        <h4>Is the ticket checker free?</h4>
                        <p>Yes, all our tools, including the Fafi Dream Guide and the 100-Draw Ticket Checker, are 100% free to use.</p>
                    </div>

                    <div class="faq-item">
                        <h4>My numbers matched, how do I claim?</h4>
                        <p>Congratulations! If our tool verified a match, please take your physical ticket or digital receipt to an approved lottery retailer or Ithuba office to officially claim your prize.</p>
                    </div>
                </div>

            </div>

            <!-- Right Column: Modern Form -->
            <div class="form-card">
                <?php if ($formSubmitted): ?>
                    <div class="success-message">
                        <h3>✅ Message Sent!</h3>
                        <p>Thank you for reaching out. Our team has received your message and will get back to you shortly.</p>
                    </div>
                <?php else: ?>
                    <h2>Send us a Message</h2>
                    <form method="POST" action="">
                        
                        <div class="form-group">
                            <label class="form-label" for="name">Full Name</label>
                            <input type="text" id="name" name="name" class="form-control" required placeholder="John Doe">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="email">Email Address</label>
                            <input type="email" id="email" name="email" class="form-control" required placeholder="john@example.com">
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="subject">Reason for Contact</label>
                            <select id="subject" name="subject" class="form-control" required>
                                <option value="" disabled selected>Select a topic...</option>
                                <option value="Bug Report">Report a Bug / Tool Issue</option>
                                <option value="Feature Request">Suggest a Feature</option>
                                <option value="Partnership">Partnership Inquiry</option>
                                <option value="Other">Other Question</option>
                            </select>
                        </div>

                        <div class="form-group">
                            <label class="form-label" for="message">Your Message</label>
                            <textarea id="message" name="message" class="form-control" required placeholder="How can we help you?"></textarea>
                        </div>

                        <button type="submit" name="submit_contact" class="btn-submit">
                            Send Message
                        </button>
                        
                        <p style="font-size: 0.85rem; color: #64748b; text-align: center; margin-top: 16px;">
                            By submitting this form, you agree to our <a href="/privacy-policy/" style="color: var(--primary, #4f46e5);">Privacy Policy</a>.
                        </p>
                    </form>
                <?php endif; ?>
            </div>

        </div>
    </div>

    <?php include __DIR__ . '/../static/footer.php'; ?>
</body>
</html>