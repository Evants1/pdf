<?php
/**
 * Privacy policy (served at /privacy-policy/).
 *
 * OWNER NOTES (read before publishing). A privacy policy must describe what the website REALLY does.
 * 1. THE OPERATOR: fill in includes/operator.php with the real legal entity (name, ABN, address). Use real details only. If the
 *    site is run by an individual or a company outside Australia, say so accurately. Do not invent an Australian company.
 * 2. PROVIDERS AND LOCATIONS: fill in $providers and $storageCountries only after you have confirmed them with your
 *    host and email provider. While they are empty, the policy stays general.
 * 3. WHAT THIS CODEBASE DOES: a contact form emails a mailbox; the newsletter form only STORES an address and a
 *    timestamp in data/subscribers.csv (it sends nothing and has no unsubscribe tool); the host keeps standard server
 *    logs; /contact/ sets one session cookie. The site loads no analytics, ads, pixels or external scripts. If you add
 *    ANY of those, or start sending newsletters, UPDATE THIS PAGE FIRST. Sending marketing email also requires consent,
 *    a clear sender identity and a working unsubscribe process (Spam Act 2003).
 * 4. Check: the data/ folder is not publicly reachable, how long your host keeps logs, the session cookie's expiry on the
 *    live site, and that you have a real process for access, correction, deletion and newsletter-removal requests.
 * 5. Whether the Privacy Act 1988 / Australian Privacy Principles (or GDPR) legally apply to you depends on your
 *    circumstances. Have this reviewed by a qualified Australian lawyer.
 */
require __DIR__ . '/includes/functions.php';
require __DIR__ . '/includes/operator.php';

$updated = '2026-11-10';

$operator = gw_operator();   // fill in includes/operator.php (shared with the About page)
$providers = [
    'hosting' => '',   // e.g. the name of your web host, once confirmed
    'email'   => '',   // e.g. the name of your email provider, once confirmed
];
$storageCountries = ''; // e.g. 'Our hosting provider stores data in X.' once confirmed. Leave empty if unsure.

$seo = [
    'title'       => 'Privacy Policy',
    'description' => 'How GrandWhisper collects, uses, stores and protects personal information, including contact messages, newsletter sign-ups, cookies and server logs.',
    'path'        => '/privacy-policy/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Privacy Policy', '/privacy-policy/']],
    'schema'      => [[
        '@type'        => 'WebPage',
        '@id'          => gw_abs('/privacy-policy/') . '#webpage',
        'url'          => gw_abs('/privacy-policy/'),
        'name'         => 'Privacy Policy',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="doc-head">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Privacy Policy</h1>
      <p class="lead">What personal information we collect, why we collect it, where it goes, and the choices you have.</p>
    </div>
  </header>

  <div class="wrap">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time></p>

      <div class="see-also">
        <p><strong>In short.</strong> We collect very little. We receive what you choose to send us (a contact message, a newsletter sign-up), our web host keeps standard server logs, and the contact page sets one security cookie. We do not currently use advertising or analytics cookies, and we do not sell personal information. Newsletter sign-ups are stored, but the sign-up system does not itself send emails.</p>
      </div>

      <h2>Who we are</h2>
      <p><?= e(SITE_NAME) ?> (<?= e(SITE_URL) ?>) is an online casino magazine for Australian readers. This policy explains how we handle personal information when you use the site.</p>
<?php if (!empty($operator['name'])): ?>
      <p>The site is operated by <strong><?= e($operator['name']) ?></strong><?= !empty($operator['abn']) ? ' (ABN ' . e($operator['abn']) . ')' : '' ?><?= !empty($operator['address']) ? ', ' . e($operator['address']) : '' ?>.</p>
<?php endif; ?>
      <p>For privacy questions and requests, email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a> or use our <a href="/contact/">contact page</a>.</p>

      <h2>Australian privacy law</h2>
      <p>We aim to handle personal information transparently and responsibly. The Privacy Act 1988 and the Australian Privacy Principles apply to organisations that are covered by the Act. Whether the Act applies to this website's operator depends on its business structure, activities and applicable exemptions. We aim to follow relevant Australian privacy principles as a standard of good practice, whether or not the operator is legally required to comply with every provision.</p>

      <h2>What personal information we collect</h2>
      <h3>Messages you send us</h3>
      <p>If you use the contact form, we receive your name, email address, the topic you choose and your message, so that we can reply. The message is delivered to our mailbox. Please do not include sensitive information such as identity document numbers or payment details.</p>
      <h3>Spam-protection records</h3>
      <p>To limit abuse of the contact form, our site keeps a short-lived record of recent submission attempts. It holds a scrambled (hashed) form of your IP address and the time of each attempt, not your name, email or message. This may still count as personal information. We use it only to limit repeated attempts and delete it within about an hour.</p>
      <h3>Newsletter sign-ups</h3>
      <p>If you subscribe, we store your email address and the date and time of your sign-up in our website's subscriber list. The current sign-up system stores these details but does not automatically send newsletters or process unsubscribe requests. If we introduce a newsletter delivery service, we will update this policy to explain how that service handles your information.</p>
      <h3>Server logs</h3>
      <p>Our web hosting provider may automatically record technical information when someone visits the site. This can include IP address, browser and device information, requested pages, referring URLs and access times. We use this information for website security, troubleshooting, abuse prevention and service reliability. IP addresses and other technical details may constitute personal information where they can identify, or reasonably be linked to, an individual.</p>
      <h3>Site search</h3>
      <p>Terms you type into our search box are used only to show you results. Our site does not store them or build profiles from them.</p>
      <h3>What we do not collect</h3>
      <p>We do not ask you to create an account, and we do not collect payment details, government identifiers or other sensitive information through this site. We do not knowingly collect personal information from anyone under 18.</p>

      <h2>Cookies</h2>
      <p>We do not currently use advertising or analytics cookies. The contact page uses a temporary session cookie for form security. This cookie helps protect the form against forged submissions and is not used to build advertising profiles. It normally expires when you close your browser.</p>
      <p>You can manage or block cookies through your browser settings. Blocking this cookie may prevent the contact form from working correctly.</p>
      <p>If we introduce analytics, advertising or other tracking technologies, we will update this policy and provide any notices or consent controls required by applicable law.</p>

      <h2>Why we use your information</h2>
      <ul>
        <li><strong>To reply to your messages</strong> and to fix mistakes you report.</li>
        <li><strong>To keep a newsletter subscriber list,</strong> if you have signed up. This is based on your consent, which you can withdraw at any time.</li>
        <li><strong>To keep the site secure and working,</strong> including preventing spam and misuse, for example by limiting repeated contact-form submissions.</li>
        <li><strong>To meet legal obligations,</strong> where the law requires us to keep or disclose information.</li>
      </ul>
      <p>We do not use your information for automated decision-making, and we do not sell it.</p>

      <h2>Who we share it with</h2>
      <p>We do not sell or rent personal information. We share information only where necessary to operate the website:</p>
      <ul>
        <li><strong>Web hosting provider<?= !empty($providers['hosting']) ? ' (' . e($providers['hosting']) . ')' : '' ?>:</strong> stores the website, subscriber list and server logs, and provides the infrastructure needed to operate the site.</li>
        <li><strong>Email provider<?= !empty($providers['email']) ? ' (' . e($providers['email']) . ')' : '' ?>:</strong> receives and stores contact-form messages in our designated mailbox.</li>
        <li><strong>Professional advisers and authorities:</strong> information may be disclosed where reasonably necessary for legal compliance, professional advice or the protection of our rights.</li>
      </ul>

      <h2>Where data is stored</h2>
      <p>Personal information is stored using our website hosting and email service providers. Depending on the services and infrastructure they use, information may be processed or stored in Australia or other countries. We will update this section if our data-storage arrangements change.</p>
<?php if (!empty($storageCountries)): ?>
      <p><?= e($storageCountries) ?></p>
<?php endif; ?>

      <h2>Links and affiliate links</h2>
      <p>Some pages link to other websites, and some links may be affiliate links, which means we may earn a commission if you sign up with a service. See our <a href="/about/#disclosure">affiliate disclosure</a>. Once you leave our site, that website may set its own cookies and collect information under its own privacy policy, and we do not control it. Please read the policy of any site you visit.</p>

      <h2>How we protect information</h2>
      <p>The site is served over HTTPS. The newsletter list is stored in a folder that the web server blocks from public access, contact messages are delivered to a private mailbox, and the contact form uses a security token to resist forgery. No method of storage or transmission is completely secure, so we cannot guarantee absolute security.</p>
      <p>If we become aware of a data breach, we will investigate it and take reasonable steps to contain and address the incident. Where the Notifiable Data Breaches scheme applies and its notification requirements are met, we will notify affected individuals and the Office of the Australian Information Commissioner as required by law.</p>

      <h2>How long we keep information</h2>
      <p>We retain personal information only for as long as reasonably necessary for the purpose for which it was collected, or where retention is required by law.</p>
      <ul>
        <li><strong>Contact messages:</strong> retained while we handle the enquiry and for a reasonable period afterwards in case further communication is needed.</li>
        <li><strong>Newsletter sign-ups:</strong> retained in our subscriber list until you request removal or the list is no longer required.</li>
        <li><strong>Server logs:</strong> retained according to the security and retention settings of our hosting provider.</li>
        <li><strong>Spam-protection records:</strong> deleted within about an hour.</li>
        <li><strong>Security records:</strong> retained where reasonably necessary to investigate abuse, protect the website or address legal issues.</li>
      </ul>
      <p>When personal information is no longer required, we take reasonable steps to delete or de-identify it, subject to applicable legal and operational requirements.</p>

      <h2>Your privacy choices and requests</h2>
      <p>You can contact us to ask what personal information we hold about you, request access to it, ask us to correct inaccurate information or request its deletion. We will consider each request and explain if we need to retain information for legal, security or legitimate business reasons.</p>
      <p>You can also withdraw your consent to optional communications, including newsletter subscriptions, at any time. If we introduce a newsletter delivery service, we will provide a clear unsubscribe method.</p>
      <p>To make a request, email <a href="mailto:<?= e(CONTACT_EMAIL) ?>"><?= e(CONTACT_EMAIL) ?></a>. We may need to verify your identity before responding. We aim to respond within 30 days, although the time required may depend on the nature and complexity of your request.</p>

      <h2>Privacy complaints</h2>
      <p>If you have a privacy concern, please contact us first using the details on this page. We will review your complaint and try to resolve it.</p>
      <p>If you are not satisfied with our response, you may be able to lodge a complaint with the Office of the Australian Information Commissioner (OAIC), depending on whether the Privacy Act 1988 applies to the organisation and the circumstances of your complaint. Visit <a href="https://www.oaic.gov.au" rel="noopener">oaic.gov.au</a> for information about the complaint process.</p>

      <h2>Children</h2>
      <p>This site is intended for adults. Gambling is for people aged 18 and over, and we do not knowingly collect personal information from anyone under 18. If you believe a child has sent us information, please contact us and we will delete it.</p>

      <h2>Changes to this policy</h2>
      <p>We may update this policy from time to time, for example if we add a new feature or service. The date at the top shows when it last changed. If we make a significant change, we will make that clear on this page.</p>
    </div>
  </div>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>