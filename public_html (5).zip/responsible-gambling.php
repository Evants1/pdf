<?php
/**
 * Responsible gambling page (served at /responsible-gambling/).
 * Teal hero: a different feel from the rest of the site on purpose.
 *
 * OWNER NOTE: people may rely on this page when they need help, so check every phone number and link regularly
 * (Gambling Help Online, BetStop, Lifeline, Gamblers Anonymous). When you have checked them, set $supportChecked below
 * to that date; the "Support details last checked" line only appears when it is set. Do not set it unless you checked.
 */
require __DIR__ . '/includes/functions.php';

$updated        = '2026-11-10';
$supportChecked = null;   // e.g. '2026-12-01'

$seo = [
    'title'       => 'Responsible Gambling and Support in Australia',
    'description' => 'Understand gambling risks, recognise warning signs of harm, learn about self-exclusion and find free, confidential gambling support in Australia.',
    'path'        => '/responsible-gambling/',
    'body_class'  => 'is-doc',
    'breadcrumbs' => [['Home', '/'], ['Responsible Gambling', '/responsible-gambling/']],
    'schema'      => [[
        '@type'        => 'WebPage',
        '@id'          => gw_abs('/responsible-gambling/') . '#webpage',
        'url'          => gw_abs('/responsible-gambling/'),
        'name'         => 'Responsible Gambling and Support in Australia',
        'dateModified' => $updated,
        'inLanguage'   => 'en-AU',
        'isPartOf'     => ['@id' => gw_abs('/') . '#website'],
    ]],
];
require __DIR__ . '/includes/header.php';
?>
<main id="main">
  <header class="rg-hero on-dark">
    <div class="wrap">
      <?= gw_breadcrumbs($seo['breadcrumbs']) ?>
      <h1>Responsible Gambling</h1>
      <p class="lead">Gambling involves financial risk and can cause harm. It should never be a way to make money, recover losses or cope with difficult feelings. If gambling is affecting you or someone close to you, free support is available.</p>
    </div>
  </header>

  <div class="wrap">
    <div class="doc">
      <p class="doc-updated">Last updated: <time datetime="<?= e($updated) ?>"><?= e(gw_date($updated)) ?></time><?php if ($supportChecked): ?> &middot; Support details last checked: <time datetime="<?= e($supportChecked) ?>"><?= e(gw_date($supportChecked)) ?></time><?php endif; ?></p>

      <div class="rg-help" id="help-now">
        <h2 style="margin-top:0">Need help now?</h2>
        <p style="margin-bottom:.6rem"><strong>Gambling Help Online:</strong> <a href="tel:1800858858">1800 858 858</a>, free and confidential, 24 hours a day, 7 days a week. This is also for family and friends.</p>
        <p style="margin-bottom:.6rem"><strong>Lifeline</strong> (crisis support): <a href="tel:131114">13 11 14</a>, 24 hours a day.</p>
        <p>If you or someone else is in immediate danger, call <a href="tel:000">000</a>.</p>
      </div>

      <h2>Understanding gambling risks</h2>
      <p>Gambling outcomes are uncertain. Casino games are generally designed with a mathematical house edge, meaning the operator has an advantage over time. A previous win or loss does not guarantee what will happen next.</p>
      <p>There is no betting system or strategy that guarantees a profit or removes the financial risks of gambling. Chasing losses, borrowing money to gamble or increasing stakes to recover money can make financial problems worse.</p>

      <h2>Safer gambling principles</h2>
      <p>These suggestions do not remove the risks of gambling or guarantee that harm will be avoided. If you choose to gamble where it is lawful, consider the following:</p>
      <ul>
        <li>Only take part if you meet the legal age requirement (18 or over) and the activity is lawful where you live.</li>
        <li>Set a firm spending limit before you start, and never go beyond money you can afford to lose.</li>
        <li>Never use money needed for rent, food, bills, savings or debt repayments.</li>
        <li>Set a time limit and take regular breaks.</li>
        <li>Never chase losses or borrow money to continue gambling.</li>
        <li>Avoid gambling when upset, stressed, tired or under the influence of alcohol or other substances.</li>
        <li>Keep gambling separate from your work, relationships and other interests.</li>
        <li>Stop if gambling is causing financial, emotional or relationship problems.</li>
      </ul>

      <h2>Warning signs of gambling harm</h2>
      <p>Gambling harm can develop gradually. It does not always involve large losses, and it can affect people from different backgrounds and financial circumstances.</p>
      <p>Consider seeking support if you or someone close to you:</p>
      <ul>
        <li>Regularly spends more money or time gambling than intended.</li>
        <li>Feels the need to gamble with larger amounts or more often.</li>
        <li>Tries to win back money that has already been lost.</li>
        <li>Borrows money, sells possessions or uses essential funds to gamble.</li>
        <li>Hides gambling activity or lies about money spent.</li>
        <li>Feels anxious, restless or irritable when trying to reduce or stop gambling.</li>
        <li>Neglects work, study, family responsibilities or relationships.</li>
        <li>Uses gambling to escape stress, loneliness, anxiety or other difficult feelings.</li>
      </ul>
      <p>You do not need to wait until these problems become severe before asking for help.</p>

      <h2>Limits, time-outs and self-exclusion</h2>
      <p>Depending on the gambling service and the laws that apply, some providers offer tools such as deposit limits, spending limits, session reminders, time-outs and self-exclusion. Banks may also offer gambling transaction blocks.</p>
      <p>These tools vary between services and do not guarantee protection from gambling harm. They should not be treated as proof that an operator is safe, properly regulated or authorised to offer its services in Australia. Online casino games are prohibited from being offered to people in Australia, and our guide to <a href="/online-gambling-laws-in-australia/">online gambling laws in Australia</a> explains the difference between these and licensed wagering.</p>
      <p>Our guide to <a href="/responsible-gambling-tools-limits-and-self-exclusion/">responsible gambling tools, limits and self-exclusion</a> explains how these measures work and where they fall short.</p>

      <h2>Free and confidential gambling support in Australia</h2>
      <p>You can ask for help for yourself or for someone else's gambling. You do not have to manage the situation alone, and you do not need to wait for a crisis before contacting a support service.</p>

      <div class="rg-help">
        <h3>National Gambling Helpline and Gambling Help Online</h3>
        <p>Call <strong><a href="tel:1800858858">1800 858 858</a></strong> for free, confidential gambling support, available 24 hours a day, seven days a week.</p>
        <p>You can also use online counselling, live chat and other support resources at <a href="https://www.gamblinghelponline.org.au" rel="noopener">gamblinghelponline.org.au</a>.</p>
        <p>Support is available to people experiencing gambling harm and to those concerned about a family member or friend.</p>
      </div>

      <div class="rg-help">
        <h3>BetStop: the National Self-Exclusion Register</h3>
        <p><a href="https://www.betstop.gov.au" rel="noopener">BetStop</a> is a free Australian Government register that lets people exclude themselves from all Australian-licensed online and phone wagering providers in one step.</p>
        <p>Exclusion periods range from three months to a lifetime. If you register, covered wagering providers must not open new accounts for you, accept bets from you or send you direct marketing.</p>
        <p><strong>Important limitation:</strong> BetStop does not cover online casino games or other gambling services illegally provided in Australia. It is not a universal self-exclusion service for every gambling website.</p>
      </div>

      <div class="rg-help">
        <h3>Lifeline</h3>
        <p>If you are experiencing emotional distress or need crisis support, call <strong><a href="tel:131114">13 11 14</a></strong>. Lifeline provides confidential support 24 hours a day. Visit <a href="https://www.lifeline.org.au" rel="noopener">lifeline.org.au</a> for other ways to get support.</p>
      </div>

      <div class="rg-help">
        <h3>Gamblers Anonymous Australia</h3>
        <p>Peer support can help people share experiences and support one another in addressing gambling problems. Find information about meetings and support groups at <a href="https://www.gamblersanonymous.org.au" rel="noopener">gamblersanonymous.org.au</a>.</p>
      </div>

      <p>If you or someone else is in immediate danger, call <strong><a href="tel:000">000</a></strong>. Organisations and contact details can change, so please check each website for the latest information.</p>

      <h2>Betting and gambling exclusions</h2>
      <p>Self-exclusion arrangements differ depending on the type of gambling and the state or territory. Land-based gambling venues, such as pubs and clubs with pokies, and licensed wagering providers operate separate exclusion processes.</p>
      <p>BetStop only covers the Australian-licensed online and phone wagering services included in its register. It does not replace venue-based exclusion schemes, and it does not provide protection from offshore online casino services. To limit access to those, use each site's own tools, ask your bank about blocking gambling transactions, and consider blocking software on your devices.</p>

      <h2>Support for family and friends</h2>
      <p>Gambling harm can affect partners, children, relatives, friends and other people close to someone who gambles. You can seek help even if the person gambling does not want support or does not recognise that there is a problem.</p>
      <p>The National Gambling Helpline can give information and support to people affected by someone else's gambling. You can also ask about counselling, financial support and ways to protect your own wellbeing.</p>

      <h2>Our commitment</h2>
      <p>GrandWhisper aims to explain gambling risks clearly, to avoid presenting gambling as a source of income, and to make support information easy to find.</p>
      <p>We do not encourage underage gambling or suggest that any strategy can guarantee winnings. We also aim to distinguish between gambling services that are lawful in Australia and services that are prohibited.</p>
      <p>Our content is informational and is not a substitute for professional counselling, financial advice or legal advice. If you believe anything on this site is inaccurate or could be clearer about gambling risks, please <a href="/contact/">contact us</a>.</p>
    </div>
  </div>
  <section class="related" aria-labelledby="related-title">
    <div class="wrap">
      <h2 id="related-title">Related guides</h2>
      <div class="related-grid">
<?php foreach (['how-to-set-deposit-and-loss-limits-australia', 'self-exclusion-australia-guide', 'responsible-gaming-tools-every-australian-should-use'] as $slug) { if ($r = gw_article($slug)) { echo gw_card($r, 'std'); } } ?>
      </div>
    </div>
  </section>
</main>
<?php require __DIR__ . '/includes/footer.php'; ?>