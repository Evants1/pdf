<?php
// Set Timezone
date_default_timezone_set('Africa/Johannesburg');

// Connect to Database
require_once $_SERVER['DOCUMENT_ROOT'] . '/db.php';

// 🔥 1 & 2. Optimized Title & Meta Description
$pageTitle = "Daily Lotto Hot & Cold Numbers Today (South Africa) + Generator";
$metaDesc = "Get Daily Lotto hot and cold numbers for today in South Africa. View most drawn numbers, overdue picks, and generate lucky numbers instantly using real draw data.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

// Dynamic Dates & Freshness Signals
$updateTime = date('F j, Y \a\t g:i A');
$todayDateString = date('l, F j, Y');
$lastDrawDateStr = date('d F Y', strtotime('-1 day')); 
$slug = ""; // For dynamic internal linking

// ==========================================
// DATA PROCESSING: Fetch Last 100 Draws
// ==========================================
$stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5 FROM daily_lotto_results ORDER BY draw_date DESC LIMIT 100");
$recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($recentDraws)) {
    $lastDrawDateStr = date('d F Y', strtotime($recentDraws[0]['draw_date']));
    $slug = strtolower(date('d-F-Y', strtotime($recentDraws[0]['draw_date'])));
}

// Calculate Frequencies
$frequencies = array_fill(1, 36, 0); 
foreach ($recentDraws as $draw) {
    foreach (['ball_1', 'ball_2', 'ball_3', 'ball_4', 'ball_5'] as $ballKey) {
        $num = (int)$draw[$ballKey];
        if ($num >= 1 && $num <= 36) {
            $frequencies[$num]++;
        }
    }
}

// Sort to find Hot and Cold
arsort($frequencies); 
$allNumbersSorted = array_keys($frequencies);

// Segment the Data
$hotNumbers = array_slice($allNumbersSorted, 0, 5);         // Top 5
$trendingNumbers = array_slice($allNumbersSorted, 5, 5);    // 6th to 10th
$coldNumbers = array_slice($allNumbersSorted, -5, 5);       // Bottom 5

// JS Data for Generator
$jsHotData = json_encode($hotNumbers);
$jsColdData = json_encode($coldNumbers);
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <!-- 🔥 11. Hidden SEO Weapon -->
    <meta name="robots" content="index, follow, max-image-preview:large">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- 🔥 6. Combined Software & FAQ Schema -->
    <script type="application/ld+json">
    [
      {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "Daily Lotto Smart Generator",
        "applicationCategory": "UtilitiesApplication",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "ZAR" }
      },
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What are hot numbers in Daily Lotto?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Hot numbers are numbers that appear frequently in recent Daily Lotto draws. Our system calculates these based on the last 100 official South African draws."
            }
          },
          {
            "@type": "Question",
            "name": "Do hot and cold numbers increase chances of winning?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "No, all numbers have an equal mathematical probability of being drawn. Hot and cold numbers are used purely for strategy, pattern spotting, and entertainment."
            }
          }
        ]
      }
    ]
    </script>

    <style>
        /* Modern Dotted Background & Base */
        body {
            background-color: #fafbfc;
            background-image: radial-gradient(#e2e8f0 1px, transparent 1px);
            background-size: 24px 24px;
            color: #334155;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        /* Two-Column Layout Grid */
        .layout-wrapper {
            max-width: 1280px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 40px;
            align-items: start;
        }

        /* --- LEFT COLUMN: MAIN CONTENT --- */
        .breadcrumb { font-size: 0.9rem; color: #64748b; margin-bottom: 24px; }
        .breadcrumb a { color: #64748b; text-decoration: none; }
        .breadcrumb a:hover { color: #2563eb; }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #ecfdf5;
            color: #059669;
            padding: 6px 16px;
            border-radius: 99px;
            font-size: 0.85rem;
            font-weight: 700;
            border: 1px solid #a7f3d0;
            margin-bottom: 20px;
        }
        .status-dot { width: 8px; height: 8px; background: #10b981; border-radius: 50%; box-shadow: 0 0 8px rgba(16,185,129,0.5); }

        .page-title { font-size: 2.4rem; color: #0f172a; margin: 0 0 16px 0; font-weight: 800; letter-spacing: -0.02em; }
        .today-date { font-size: 1.05rem; color: #ea580c; font-weight: 700; margin-bottom: 16px; display: block; }
        .intro-text { font-size: 1.1rem; color: #475569; line-height: 1.7; margin-bottom: 24px; }

        /* Trust Alert Box */
        .auth-box {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-left: 4px solid #10b981;
            border-radius: 8px;
            padding: 20px 24px;
            display: flex;
            gap: 16px;
            margin-bottom: 32px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .auth-icon { font-size: 1.5rem; }
        .auth-text { font-size: 0.95rem; line-height: 1.6; }

        /* 3-Column Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 24px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }
        .stat-card h2 { font-size: 1.05rem; margin: 0 0 20px 0; color: #0f172a; display: flex; align-items: center; gap: 8px; font-weight: 800; }
        .ball-row { display: flex; gap: 10px; flex-wrap: wrap; }
        
        /* Outline Style Balls */
        .o-ball {
            width: 38px; height: 38px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 1rem; background: #ffffff;
        }
        .hot-card .o-ball { border: 2px solid #ef4444; color: #ef4444; }
        .cold-card .o-ball { border: 2px solid #3b82f6; color: #3b82f6; }
        .trend-card .o-ball { border: 2px solid #eab308; color: #d97706; }

        /* Generator Interface */
        .generator-tool {
            background: #ffffff; border-radius: 16px; padding: 40px;
            border: 1px solid #e2e8f0; text-align: center; margin-bottom: 40px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
        }
        .generator-tool h2 { font-size: 1.6rem; color: #1e293b; margin: 0 0 24px 0; font-weight: 800; }
        .result-balls { display: flex; justify-content: center; gap: 16px; margin-bottom: 32px; min-height: 70px;}
        .g-ball {
            width: 65px; height: 65px; background: linear-gradient(135deg, #2563eb, #1e40af);
            color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 1.6rem; font-weight: 800; box-shadow: 0 8px 16px rgba(37, 99, 235, 0.3);
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .g-ball.animate { transform: scale(1.15) rotate(10deg); }
        .gen-controls { display: flex; justify-content: center; gap: 16px; flex-wrap: wrap; }
        .mode-select { padding: 14px 20px; border-radius: 8px; border: 2px solid #e2e8f0; font-size: 1rem; outline: none; }
        .btn-generate { background: #2563eb; color: white; border: none; padding: 14px 28px; border-radius: 8px; font-size: 1.05rem; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn-generate:hover { background: #1d4ed8; transform: translateY(-2px); }

        /* SEO Content Block */
        .content-block { background: #ffffff; border-radius: 12px; padding: 32px 40px; border: 1px solid #e2e8f0; line-height: 1.8; margin-bottom: 40px;}
        .content-block h2 { font-size: 1.6rem; color: #0f172a; margin-top: 32px; margin-bottom: 16px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 800;}
        .content-block h2:first-child { margin-top: 0; }
        .content-block h3 { font-size: 1.2rem; color: #1e293b; margin-top: 24px; font-weight: 700;}
        .content-block p { margin-bottom: 16px; }
        .content-block ul { padding-left: 20px; margin-bottom: 24px; }
        .content-block li { margin-bottom: 8px; }
        .content-block a { color: #2563eb; font-weight: 600; text-decoration: none; }
        .content-block a:hover { text-decoration: underline; }

        /* --- RIGHT COLUMN: SIDEBAR PANEL --- */
        .sidebar { background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; position: sticky; top: 40px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .sidebar-header { background: #2563eb; color: #ffffff; padding: 20px 24px; font-size: 1.1rem; font-weight: 800; letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 16px 24px; border-bottom: 1px solid #f1f5f9; color: #475569; text-decoration: none; font-weight: 600; transition: all 0.2s; }
        .sidebar-menu li a:hover { background: #f8fafc; color: #2563eb; padding-left: 28px; }
        .sidebar-menu li.active a { border-left: 4px solid #2563eb; color: #2563eb; background: #eff6ff; }
        .sidebar-menu li.highlight a { color: #ea580c; } 

        /* Mobile */
        @media (max-width: 992px) {
            .layout-wrapper { grid-template-columns: 1fr; padding: 0 15px;}
            .stats-grid { grid-template-columns: 1fr; }
            .sidebar { position: static; margin-top: 40px; }
            .page-title { font-size: 2rem; }
            .content-block { padding: 24px 20px; }
        }
    </style>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/nav.php'; ?>

    <div class="layout-wrapper">
        
        <!-- MAIN CONTENT AREA -->
        <main class="main-content">
            
            <div class="breadcrumb">
                <a href="/">Home</a> › <a href="/results/daily-lotto/">Daily Lotto</a> › Hot & Cold Numbers
            </div>

            <div class="status-pill">
                <div class="status-dot"></div>
                Data Updated: <?php echo $updateTime; ?>
            </div>

            <!-- 🔥 3 & 8. Optimized H1 and Freshness Signal -->
            <span class="today-date">📅 Today: <?php echo $todayDateString; ?></span>
            <h1 class="page-title">Daily Lotto Hot and Cold Numbers Today (South Africa)</h1>
            
            <p class="intro-text">
                Welcome to South Africa's premier resource for tracking <strong>Daily Lotto number trends</strong>. Whether you are aiming to play the most frequent lotto numbers, strategizing around overdue digits, or looking for a smart generated quick-pick, our data engine provides the ultimate edge.
            </p>

            <div class="auth-box">
                <div class="auth-icon">📊</div>
                <div class="auth-text">
                    <strong>Data Source Authenticity:</strong> This frequency analysis is dynamically generated directly from the <strong>last 100 official SA Daily Lotto draws</strong>. It was last updated after the draw on <?php echo $lastDrawDateStr; ?>.
                </div>
            </div>

            <!-- 🔥 4. Secondary H2s Integrated into the Grid -->
            <div class="stats-grid">
                <div class="stat-card hot-card">
                    <h2>🔥 Daily Lotto Most Frequent Numbers</h2>
                    <div class="ball-row">
                        <?php foreach($hotNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="stat-card cold-card">
                    <h2>❄️ Overdue Daily Lotto Numbers Today</h2>
                    <div class="ball-row">
                        <?php foreach($coldNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="stat-card trend-card">
                    <h2>📈 Trending Numbers (Last 100 Draws)</h2>
                    <div class="ball-row">
                        <?php foreach($trendingNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- GENERATOR TOOL -->
            <div class="generator-tool">
                <h2>🎯 Daily Lotto Number Generator (Smart Picks)</h2>
                
                <div class="result-balls" id="ballsContainer">
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                </div>

                <div class="gen-controls">
                    <select id="generationMode" class="mode-select">
                        <option value="smart">Mix: Hot + Cold + Random</option>
                        <option value="hot">Trending Focus (Hot Numbers)</option>
                        <option value="random">Standard Quick Pick</option>
                    </select>
                    <button class="btn-generate" onclick="generateNewNumbers()">
                        Generate Lucky Pick
                    </button>
                </div>
            </div>

            <!-- 🔥 7. Massive SEO Content Depth & Internal Linking -->
            <div class="content-block">
                
                <h2>Best Strategy for Daily Lotto Numbers in SA</h2>
                <p>When playing the South African Daily Lotto, many players wonder if there is a mathematical secret to winning. While every single draw is completely random, utilizing data-driven strategies can help you pick numbers more deliberately than relying entirely on quick picks.</p>
                
                <p>The most popular strategy among seasoned SA players is the <strong>balanced mix</strong>. Instead of picking all odd, all even, or sequential numbers, players use our generator to combine frequent (hot) numbers with a few overdue (cold) numbers, topped off with a random selection. This ensures your ticket covers a wide spread of statistical probabilities.</p>

                <!-- 🔥 5. Internal SEO Links -->
                <p>To verify these trends yourself, you can always check the <a href="/results/daily-lotto/<?php echo $slug; ?>">latest Daily Lotto results</a> or browse our comprehensive <a href="/results/daily-lotto/history/">full draw history</a> to analyze the winning patterns over the past year.</p>

                <h2>How Daily Lotto Numbers Are Drawn</h2>
                <p>The Daily Lotto draw takes place every single evening at 21:00 SAST. Ithuba, the official operator of the National Lottery in South Africa, uses highly secure, certified Random Number Generator (RNG) machines for this specific game. Because it operates on a 5/36 matrix (you pick 5 numbers from a pool of 36), the odds of winning the jackpot are significantly better than the standard Lotto or PowerBall.</p>

                <p>Because there are only 36 numbers in the pool, hot and cold trends become visible much faster, making tools like our 100-draw frequency analyzer highly relevant for daily players.</p>

                <h2>Understanding Hot and Cold Numbers</h2>
                <h3>What does it mean when a number is "Hot"?</h3>
                <p>A "Hot" number is simply a digit that has been drawn more frequently than the mathematical average over a recent timeframe (in our case, the last 100 draws). Trend followers believe that mechanical or algorithm quirks can temporarily favor these numbers.</p>

                <h3>What makes a number "Cold" or "Overdue"?</h3>
                <p>Conversely, a "Cold" number has appeared the least frequently. Players who follow the Law of Averages believe that because every number must eventually equal out in frequency over infinite time, these cold numbers are "overdue" and highly likely to be drawn soon to correct the mathematical balance.</p>
                
                <p style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #f1f5f9; font-size: 0.9rem; color: #64748b;">
                    <em>Disclaimer: This generator and data analysis tool is provided for entertainment and statistical insight only. Playing the lottery involves significant financial risk. Always gamble responsibly.</em>
                </p>
            </div>

        </main>

        <!-- SIDEBAR PANEL -->
        <aside class="sidebar">
            <div class="sidebar-header">DAILY LOTTO PANEL</div>
            <ul class="sidebar-menu">
                <li><a href="/results/daily-lotto/">Latest Results</a></li>
                <li><a href="/results/daily-lotto/history/">Draw History</a></li>
                <li class="active"><a href="/hot-and-cold-numbers/daily-lotto/">Hot & Cold Numbers</a></li>
                <li><a href="/check-tickets/">Check Tickets</a></li>
                <li><a href="/predictions/daily-lotto/">Smart Predictions</a></li>
                <li><a href="/how-to-play/daily-lotto/">How to Play</a></li>
                <li class="highlight"><a href="/play-online/" rel="nofollow">Play Online →</a></li>
            </ul>
        </aside>

    </div>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>

    <!-- CLIENT SIDE GENERATOR LOGIC -->
    <script>
        const hotData = <?php echo $jsHotData; ?>;
        const coldData = <?php echo $jsColdData; ?>;
        
        function generateNewNumbers() {
            const mode = document.getElementById('generationMode').value;
            const container = document.getElementById('ballsContainer');
            let result = [];
            let pool = Array.from({length: 36}, (_, i) => i + 1);

            if (mode === 'smart') {
                let tempHot = [...hotData];
                let tempCold = [...coldData];
                result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                result.push(tempCold.splice(Math.floor(Math.random()*tempCold.length), 1)[0]);
                
                let remainingPool = pool.filter(n => !result.includes(n));
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);

            } else if (mode === 'hot') {
                let tempHot = [...hotData];
                for(let i=0; i<4; i++) {
                    if(tempHot.length > 0) result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                }
                let remainingPool = pool.filter(n => !result.includes(n));
                result.push(remainingPool[Math.floor(Math.random()*remainingPool.length)]);

            } else {
                let remainingPool = [...pool];
                for(let i=0; i<5; i++) {
                    result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                }
            }

            result.sort((a, b) => a - b);
            container.innerHTML = '';
            
            result.forEach((num, index) => {
                setTimeout(() => {
                    let ball = document.createElement('div');
                    ball.className = 'g-ball animate';
                    ball.innerText = String(num).padStart(2, '0');
                    container.appendChild(ball);
                    setTimeout(() => ball.classList.remove('animate'), 300);
                }, index * 100); 
            });
        }
        
        // Auto-run once on page load
        window.onload = generateNewNumbers;
    </script>
</body>
</html>