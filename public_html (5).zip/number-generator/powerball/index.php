<?php
// Set Timezone
date_default_timezone_set('Africa/Johannesburg');

// Connect to Database
require_once $_SERVER['DOCUMENT_ROOT'] . '/db.php';

// 🔥 Optimized Title & Meta Description
$pageTitle = "SA PowerBall Hot & Cold Numbers Today (South Africa) + Generator";
$metaDesc = "Get SA PowerBall hot and cold numbers for today. View most drawn numbers, overdue picks, and generate lucky 5/50 + 1/20 numbers instantly using real draw data.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

// Dynamic Dates & Freshness Signals
$updateTime = date('F j, Y \a\t g:i A');
$todayDateString = date('l, F j, Y');
$lastDrawDateStr = date('d F Y', strtotime('-1 day')); 
$slug = ""; 

// ==========================================
// DATA PROCESSING: Fetch Last 100 Draws
// ==========================================
// PowerBall draws 5 main balls + 1 PowerBall
$stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5, powerball FROM powerball_results ORDER BY draw_date DESC LIMIT 100");
$recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($recentDraws)) {
    $lastDrawDateStr = date('d F Y', strtotime($recentDraws[0]['draw_date']));
    $slug = strtolower(date('d-F-Y', strtotime($recentDraws[0]['draw_date'])));
}

// Calculate Frequencies
$freqMain = array_fill(1, 50, 0); // Main numbers 1-50
$freqPB = array_fill(1, 20, 0);   // PowerBall 1-20

foreach ($recentDraws as $draw) {
    // Process Main Balls
    foreach (['ball_1', 'ball_2', 'ball_3', 'ball_4', 'ball_5'] as $ballKey) {
        $num = (int)$draw[$ballKey];
        if ($num >= 1 && $num <= 50) {
            $freqMain[$num]++;
        }
    }
    // Process PowerBall
    $pbNum = (int)$draw['powerball'];
    if ($pbNum >= 1 && $pbNum <= 20) {
        $freqPB[$pbNum]++;
    }
}

// Sort to find Hot and Cold
arsort($freqMain); 
arsort($freqPB);

$sortedMain = array_keys($freqMain);
$sortedPB = array_keys($freqPB);

// Segment the Data (5 Main + 1 PB per card)
$hotMain = array_slice($sortedMain, 0, 5);
$coldMain = array_slice($sortedMain, -5, 5);
$trendMain = array_slice($sortedMain, 5, 5);

$hotPB = $sortedPB[0]; // Hottest PB
$coldPB = end($sortedPB); // Coldest PB
$trendPB = $sortedPB[1]; // 2nd Hottest PB

// JS Data for Generator
$jsHotMain = json_encode($hotMain);
$jsColdMain = json_encode($coldMain);
$jsHotPB = json_encode(array_slice($sortedPB, 0, 3)); // Top 3 PBs for smart mix
$jsColdPB = json_encode(array_slice($sortedPB, -3, 3)); // Bottom 3 PBs
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <!-- Hidden SEO Weapon -->
    <meta name="robots" content="index, follow, max-image-preview:large">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Combined Software & FAQ Schema -->
    <script type="application/ld+json">
    [
      {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "SA PowerBall Smart Generator",
        "applicationCategory": "UtilitiesApplication",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "ZAR" }
      },
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "How does the SA PowerBall draw work?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "The South African PowerBall uses two separate draw machines. First, 5 main numbers are drawn from a pool of 1 to 50. Then, a single PowerBall is drawn from a separate pool of 1 to 20."
            }
          },
          {
            "@type": "Question",
            "name": "What are hot and cold PowerBall numbers?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Hot numbers have appeared most frequently in recent draws, while cold numbers are overdue. Because the PowerBall is drawn from a separate pool, it has its own unique hot and cold statistical trends separate from the main numbers."
            }
          }
        ]
      }
    ]
    </script>

    <style>
        /* Modern Dotted Background & Base */
        body {
            background-color: #fafbfc;
            background-image: radial-gradient(#e2e8f0 1px, transparent 1px);
            background-size: 24px 24px;
            color: #334155;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        /* Two-Column Layout Grid */
        .layout-wrapper {
            max-width: 1280px; margin: 40px auto; padding: 0 20px;
            display: grid; grid-template-columns: 1fr 320px; gap: 40px; align-items: start;
        }

        /* --- LEFT COLUMN: MAIN CONTENT --- */
        .breadcrumb { font-size: 0.9rem; color: #64748b; margin-bottom: 24px; }
        .breadcrumb a { color: #64748b; text-decoration: none; }
        .breadcrumb a:hover { color: #2563eb; }

        .status-pill {
            display: inline-flex; align-items: center; gap: 8px;
            background: #ecfdf5; color: #059669; padding: 6px 16px;
            border-radius: 99px; font-size: 0.85rem; font-weight: 700;
            border: 1px solid #a7f3d0; margin-bottom: 20px;
        }
        .status-dot { width: 8px; height: 8px; background: #10b981; border-radius: 50%; box-shadow: 0 0 8px rgba(16,185,129,0.5); }

        .page-title { font-size: 2.4rem; color: #0f172a; margin: 0 0 16px 0; font-weight: 800; letter-spacing: -0.02em; }
        .today-date { font-size: 1.05rem; color: #ea580c; font-weight: 700; margin-bottom: 16px; display: block; }
        .intro-text { font-size: 1.1rem; color: #475569; line-height: 1.7; margin-bottom: 24px; }

        /* Trust Alert Box */
        .auth-box {
            background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #10b981;
            border-radius: 8px; padding: 20px 24px; display: flex; gap: 16px; margin-bottom: 32px;
        }
        .auth-icon { font-size: 1.5rem; }
        .auth-text { font-size: 0.95rem; line-height: 1.6; }

        /* 3-Column Stats Grid */
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 40px; }
        .stat-card { background: #ffffff; border-radius: 12px; padding: 24px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .stat-card h2 { font-size: 1.05rem; margin: 0 0 20px 0; color: #0f172a; display: flex; align-items: center; gap: 8px; font-weight: 800; }
        .ball-row { display: flex; gap: 6px; flex-wrap: wrap; align-items: center; }
        
        /* Outline Style Balls */
        .o-ball {
            width: 34px; height: 34px; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 0.95rem; background: #ffffff;
        }
        .hot-card .o-ball { border: 2px solid #ef4444; color: #ef4444; }
        .cold-card .o-ball { border: 2px solid #3b82f6; color: #3b82f6; }
        .trend-card .o-ball { border: 2px solid #eab308; color: #d97706; }
        
        /* Special PowerBall Styles */
        .pb-separator { color: #cbd5e1; font-weight: 300; font-size: 1.5rem; margin: 0 2px; }
        .o-ball.pb-style { background: #fff7ed !important; color: #ea580c !important; border: 2px solid #ea580c !important; }

        /* Generator Interface */
        .generator-tool {
            background: #ffffff; border-radius: 16px; padding: 40px; border: 1px solid #e2e8f0; 
            text-align: center; margin-bottom: 40px; box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
        }
        .generator-tool h2 { font-size: 1.6rem; color: #1e293b; margin: 0 0 24px 0; font-weight: 800; }
        .result-balls { display: flex; justify-content: center; align-items: center; gap: 12px; margin-bottom: 32px; min-height: 70px;}
        
        .g-ball {
            width: 60px; height: 60px; background: linear-gradient(135deg, #2563eb, #1e40af);
            color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; font-weight: 800; box-shadow: 0 8px 16px rgba(37, 99, 235, 0.3);
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .g-ball.pb-style { background: linear-gradient(135deg, #ea580c, #c2410c); box-shadow: 0 8px 16px rgba(234, 88, 12, 0.3); }
        .g-ball.animate { transform: scale(1.15) rotate(10deg); }
        
        .gen-controls { display: flex; justify-content: center; gap: 16px; flex-wrap: wrap; }
        .mode-select { padding: 14px 20px; border-radius: 8px; border: 2px solid #e2e8f0; font-size: 1rem; outline: none; }
        .btn-generate { background: #2563eb; color: white; border: none; padding: 14px 28px; border-radius: 8px; font-size: 1.05rem; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn-generate:hover { background: #1d4ed8; transform: translateY(-2px); }

        /* SEO Content Block */
        .content-block { background: #ffffff; border-radius: 12px; padding: 32px 40px; border: 1px solid #e2e8f0; line-height: 1.8; margin-bottom: 40px;}
        .content-block h2 { font-size: 1.6rem; color: #0f172a; margin-top: 32px; margin-bottom: 16px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 800;}
        .content-block h2:first-child { margin-top: 0; }
        .content-block h3 { font-size: 1.2rem; color: #1e293b; margin-top: 24px; font-weight: 700;}
        .content-block p { margin-bottom: 16px; }
        .content-block a { color: #2563eb; font-weight: 600; text-decoration: none; }
        .content-block a:hover { text-decoration: underline; }

        /* --- RIGHT COLUMN: SIDEBAR PANEL --- */
        .sidebar { background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; position: sticky; top: 40px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .sidebar-header { background: #2563eb; color: #ffffff; padding: 20px 24px; font-size: 1.1rem; font-weight: 800; letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 16px 24px; border-bottom: 1px solid #f1f5f9; color: #475569; text-decoration: none; font-weight: 600; transition: all 0.2s; }
        .sidebar-menu li a:hover { background: #f8fafc; color: #2563eb; padding-left: 28px; }
        .sidebar-menu li.active a { border-left: 4px solid #2563eb; color: #2563eb; background: #eff6ff; }
        .sidebar-menu li.highlight a { color: #ea580c; } 

        /* Mobile */
        @media (max-width: 992px) {
            .layout-wrapper { grid-template-columns: 1fr; padding: 0 15px;}
            .stats-grid { grid-template-columns: 1fr; }
            .sidebar { position: static; margin-top: 40px; }
            .page-title { font-size: 2rem; }
            .content-block { padding: 24px 20px; }
            .g-ball { width: 48px; height: 48px; font-size: 1.2rem; }
        }
    </style>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/nav.php'; ?>

    <div class="layout-wrapper">
        
        <!-- MAIN CONTENT AREA -->
        <main class="main-content">
            
            <div class="breadcrumb">
                <a href="/">Home</a> › <a href="/results/powerball/">PowerBall</a> › Hot & Cold Numbers
            </div>

            <div class="status-pill">
                <div class="status-dot"></div>
                Data Updated: <?php echo $updateTime; ?>
            </div>

            <!-- Freshness Signal -->
            <span class="today-date">📅 Today: <?php echo $todayDateString; ?></span>
            <h1 class="page-title">SA PowerBall Hot and Cold Numbers Today (South Africa)</h1>
            
            <p class="intro-text">
                Welcome to South Africa's ultimate resource for tracking <strong>PowerBall number trends</strong>. Because the PowerBall is drawn from an independent second machine, our dual-engine tracks the 5/50 main numbers and the 1/20 bonus balls separately to give you the most mathematically accurate data possible.
            </p>

            <div class="auth-box">
                <div class="auth-icon">📊</div>
                <div class="auth-text">
                    <strong>Data Source Authenticity:</strong> This frequency analysis is dynamically generated directly from the <strong>last 100 official Tuesday and Friday SA PowerBall draws</strong>. It was last updated after the draw on <?php echo $lastDrawDateStr; ?>.
                </div>
            </div>

            <!-- Secondary H2s Integrated into the Grid -->
            <div class="stats-grid">
                <div class="stat-card hot-card">
                    <h2>🔥 Most Frequent PowerBall Numbers</h2>
                    <div class="ball-row">
                        <?php foreach($hotMain as $num): ?><div class="o-ball"><?php echo $num; ?></div><?php endforeach; ?>
                        <span class="pb-separator">+</span>
                        <div class="o-ball pb-style" title="Hottest PowerBall"><?php echo $hotPB; ?></div>
                    </div>
                </div>

                <div class="stat-card cold-card">
                    <h2>❄️ Overdue PowerBall Numbers Today</h2>
                    <div class="ball-row">
                        <?php foreach($coldMain as $num): ?><div class="o-ball"><?php echo $num; ?></div><?php endforeach; ?>
                        <span class="pb-separator">+</span>
                        <div class="o-ball pb-style" title="Coldest PowerBall"><?php echo $coldPB; ?></div>
                    </div>
                </div>

                <div class="stat-card trend-card">
                    <h2>📈 Trending Numbers (Last 100 Draws)</h2>
                    <div class="ball-row">
                        <?php foreach($trendMain as $num): ?><div class="o-ball"><?php echo $num; ?></div><?php endforeach; ?>
                        <span class="pb-separator">+</span>
                        <div class="o-ball pb-style" title="Trending PowerBall"><?php echo $trendPB; ?></div>
                    </div>
                </div>
            </div>

            <!-- GENERATOR TOOL -->
            <div class="generator-tool">
                <h2>🎯 SA PowerBall Number Generator (Smart Picks)</h2>
                
                <div class="result-balls" id="ballsContainer">
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <span class="pb-separator">+</span>
                    <div class="g-ball pb-style">PB</div>
                </div>

                <div class="gen-controls">
                    <select id="generationMode" class="mode-select">
                        <option value="smart">Mix: Hot + Cold + Random</option>
                        <option value="hot">Trending Focus (Hot Numbers)</option>
                        <option value="random">Standard Quick Pick</option>
                    </select>
                    <button class="btn-generate" onclick="generateNewNumbers()">
                        Generate Lucky Pick
                    </button>
                </div>
            </div>

            <!-- SEO Content Depth & Internal Linking -->
            <div class="content-block">
                
                <h2>Best Strategy for SA PowerBall Numbers</h2>
                <p>The South African PowerBall offers the biggest jackpots in the country, but it also features the steepest odds. Because players must match 5 main numbers out of 50, plus 1 PowerBall out of 20, relying solely on random quick picks can be frustrating.</p>
                
                <p>A leading strategy among lottery data analysts is the <strong>split-ticket approach</strong>. Using our dual-engine generator, players can combine mathematically frequent (hot) main numbers with historically overdue (cold) numbers. More importantly, because the PowerBall decides the jackpot, analyzing the 1/20 standalone drum separately is crucial for an optimized ticket.</p>

                <!-- Internal SEO Links -->
                <p>To verify these dual-drum trends yourself, review the <a href="/results/powerball/<?php echo $slug; ?>">latest SA PowerBall results</a> or check our complete <a href="/results/powerball/history/">full draw history</a> to track exactly how the machines behave over time.</p>

                <h2>How the PowerBall Numbers Are Drawn</h2>
                <p>The SA PowerBall draw takes place every Tuesday and Friday night at 21:00 SAST. Ithuba uses two highly secure, separate mechanical draw machines:</p>
                <ul style="margin-top: 10px;">
                    <li><strong>Machine 1 (Main Numbers):</strong> Contains balls numbered 1 through 50. Exactly 5 balls are drawn from this drum.</li>
                    <li><strong>Machine 2 (The PowerBall):</strong> Contains balls numbered 1 through 20. Only 1 ball is drawn from this drum.</li>
                </ul>

                <p>Because the PowerBall is drawn from an entirely separate drum, a number that is "Hot" in the main drum might be completely absent from the PowerBall drum. This is why our tool separates the frequency analysis between the two.</p>

                <h2>Understanding Hot and Cold Trends</h2>
                <h3>Why play "Hot" numbers?</h3>
                <p>A "Hot" number is a digit that has been drawn with abnormal frequency. Players chasing hot numbers believe that slight, microscopic variances in the physical balls (such as slight weight differences from ink) or the mechanical arms may temporarily favor certain numbers.</p>

                <h3>Why play "Cold" or "Overdue" numbers?</h3>
                <p>A "Cold" number has shown up the least over our tracked 100-draw timeframe. Strategy players who favor cold numbers rely on the Law of Averages—believing that because every ball should theoretically equal out over an infinite period, cold numbers are "overdue" to be drawn to restore mathematical equilibrium.</p>
                
                <p style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #f1f5f9; font-size: 0.9rem; color: #64748b;">
                    <em>Disclaimer: This generator and data analysis tool is provided for educational and entertainment purposes only. The National Lottery is a game of chance and no mathematical system can guarantee a jackpot win. Always gamble responsibly.</em>
                </p>
            </div>

        </main>

        <!-- SIDEBAR PANEL -->
        <aside class="sidebar">
            <div class="sidebar-header">POWERBALL PANEL</div>
            <ul class="sidebar-menu">
                <li><a href="/results/powerball/">Latest Results</a></li>
                <li><a href="/results/powerball/history/">Draw History</a></li>
                <li class="active"><a href="/hot-and-cold-numbers/powerball/">Hot & Cold Numbers</a></li>
                <li><a href="/check-tickets/">Check Tickets</a></li>
                <li><a href="/predictions/powerball/">Smart Predictions</a></li>
                <li><a href="/how-to-play/powerball/">How to Play</a></li>
                <li class="highlight"><a href="/play-online/" rel="nofollow">Play Online →</a></li>
            </ul>
        </aside>

    </div>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>

    <!-- CLIENT SIDE GENERATOR LOGIC (UPDATED FOR 5/50 + 1/20 POWERBALL) -->
    <script>
        const hotMain = <?php echo $jsHotMain; ?>;
        const coldMain = <?php echo $jsColdMain; ?>;
        const hotPB = <?php echo $jsHotPB; ?>;
        const coldPB = <?php echo $jsColdPB; ?>;
        
        function generateNewNumbers() {
            const mode = document.getElementById('generationMode').value;
            const container = document.getElementById('ballsContainer');
            
            let resultMain = [];
            let resultPB = 0;
            
            let poolMain = Array.from({length: 50}, (_, i) => i + 1);
            let poolPB = Array.from({length: 20}, (_, i) => i + 1);

            if (mode === 'smart') {
                // Main: 2 Hot, 1 Cold, 2 Random
                let tempHot = [...hotMain];
                let tempCold = [...coldMain];
                
                if(tempHot.length >= 2) {
                    resultMain.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                    resultMain.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                }
                
                if(tempCold.length >= 1) {
                    resultMain.push(tempCold.splice(Math.floor(Math.random()*tempCold.length), 1)[0]);
                }
                
                let remainingPool = poolMain.filter(n => !resultMain.includes(n));
                resultMain.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                resultMain.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                
                // PB: 50% chance Hot PB, 50% chance Random PB
                if(Math.random() > 0.5 && hotPB.length > 0) {
                    resultPB = hotPB[Math.floor(Math.random()*hotPB.length)];
                } else {
                    resultPB = poolPB[Math.floor(Math.random()*poolPB.length)];
                }

            } else if (mode === 'hot') {
                // Main: 4 Hot, 1 Random
                let tempHot = [...hotMain];
                for(let i=0; i<4; i++) {
                    if(tempHot.length > 0) resultMain.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                }
                let remainingPool = poolMain.filter(n => !resultMain.includes(n));
                resultMain.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                
                // PB: Always Hot
                resultPB = hotPB[0] || poolPB[Math.floor(Math.random()*poolPB.length)];

            } else {
                // Main: Completely Random (5 numbers from 1-50)
                let remainingPool = [...poolMain];
                for(let i=0; i<5; i++) {
                    resultMain.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                }
                // PB: Random (1-20)
                resultPB = poolPB[Math.floor(Math.random()*poolPB.length)];
            }

            resultMain.sort((a, b) => a - b);
            
            // Build UI
            container.innerHTML = '';
            
            // Render Main Balls
            resultMain.forEach((num, index) => {
                setTimeout(() => {
                    let ball = document.createElement('div');
                    ball.className = 'g-ball animate';
                    ball.innerText = String(num).padStart(2, '0');
                    container.appendChild(ball);
                    setTimeout(() => ball.classList.remove('animate'), 300);
                }, index * 100); 
            });
            
            // Render Separator and PowerBall
            setTimeout(() => {
                let sep = document.createElement('span');
                sep.className = 'pb-separator';
                sep.innerText = '+';
                container.appendChild(sep);
                
                let pbBall = document.createElement('div');
                pbBall.className = 'g-ball pb-style animate';
                pbBall.innerText = String(resultPB).padStart(2, '0');
                container.appendChild(pbBall);
                setTimeout(() => pbBall.classList.remove('animate'), 300);
            }, 600);
        }
        
        // Auto-run once on page load
        window.onload = generateNewNumbers;
    </script>
</body>
</html>