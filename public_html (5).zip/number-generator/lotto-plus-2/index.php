<?php
// Set Timezone
date_default_timezone_set('Africa/Johannesburg');

// Connect to Database
require_once $_SERVER['DOCUMENT_ROOT'] . '/db.php';

// 🔥 Optimized Title & Meta Description
$pageTitle = "SA Lotto Plus 2 Hot & Cold Numbers Today (South Africa) + Generator";
$metaDesc = "Get SA Lotto Plus 2 hot and cold numbers for today. View most drawn numbers, overdue picks, and generate lucky 6/52 numbers instantly using real draw data.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

// Dynamic Dates & Freshness Signals
$updateTime = date('F j, Y \a\t g:i A');
$todayDateString = date('l, F j, Y');
$lastDrawDateStr = date('d F Y', strtotime('-1 day')); 
$slug = ""; // For dynamic internal linking

// ==========================================
// DATA PROCESSING: Fetch Last 100 Draws
// ==========================================
// Lotto Plus 2 draws 6 main balls
$stmt = $pdo->query("SELECT draw_date, ball_1, ball_2, ball_3, ball_4, ball_5, ball_6 FROM lotto_plus_2_results ORDER BY draw_date DESC LIMIT 100");
$recentDraws = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!empty($recentDraws)) {
    $lastDrawDateStr = date('d F Y', strtotime($recentDraws[0]['draw_date']));
    $slug = strtolower(date('d-F-Y', strtotime($recentDraws[0]['draw_date'])));
}

// Calculate Frequencies (Lotto Plus 2 is 1 to 52)
$frequencies = array_fill(1, 52, 0); 
foreach ($recentDraws as $draw) {
    foreach (['ball_1', 'ball_2', 'ball_3', 'ball_4', 'ball_5', 'ball_6'] as $ballKey) {
        $num = (int)$draw[$ballKey];
        if ($num >= 1 && $num <= 52) {
            $frequencies[$num]++;
        }
    }
}

// Sort to find Hot and Cold
arsort($frequencies); 
$allNumbersSorted = array_keys($frequencies);

// Segment the Data (6 balls for Lotto Plus 2)
$hotNumbers = array_slice($allNumbersSorted, 0, 6);         // Top 6 Hottest
$trendingNumbers = array_slice($allNumbersSorted, 6, 6);    // 7th to 12th
$coldNumbers = array_slice($allNumbersSorted, -6, 6);       // Bottom 6 Coldest

// JS Data for Generator
$jsHotData = json_encode($hotNumbers);
$jsColdData = json_encode($coldNumbers);
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <!-- Hidden SEO Weapon -->
    <meta name="robots" content="index, follow, max-image-preview:large">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Combined Software & FAQ Schema -->
    <script type="application/ld+json">
    [
      {
        "@context": "https://schema.org",
        "@type": "SoftwareApplication",
        "name": "SA Lotto Plus 2 Smart Generator",
        "applicationCategory": "UtilitiesApplication",
        "offers": { "@type": "Offer", "price": "0", "priceCurrency": "ZAR" }
      },
      {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
          {
            "@type": "Question",
            "name": "What are hot numbers in SA Lotto Plus 2?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Hot numbers are the digits from 1 to 52 that have appeared most frequently in recent SA Lotto Plus 2 draws. We calculate this data directly from the last 100 official draws."
            }
          },
          {
            "@type": "Question",
            "name": "Are Lotto Plus 2 trends different from the main Lotto?",
            "acceptedAnswer": {
              "@type": "Answer",
              "text": "Yes. Even though Lotto Plus 2 uses the same 6/52 format, it is the third independent draw of the night. It generates entirely unique statistical patterns and requires its own set of hot and cold data tracking."
            }
          }
        ]
      }
    ]
    </script>

    <style>
        /* Modern Dotted Background & Base */
        body {
            background-color: #fafbfc;
            background-image: radial-gradient(#e2e8f0 1px, transparent 1px);
            background-size: 24px 24px;
            color: #334155;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }

        /* Two-Column Layout Grid */
        .layout-wrapper {
            max-width: 1280px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 40px;
            align-items: start;
        }

        /* --- LEFT COLUMN: MAIN CONTENT --- */
        .breadcrumb { font-size: 0.9rem; color: #64748b; margin-bottom: 24px; }
        .breadcrumb a { color: #64748b; text-decoration: none; }
        .breadcrumb a:hover { color: #2563eb; }

        .status-pill {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            background: #ecfdf5;
            color: #059669;
            padding: 6px 16px;
            border-radius: 99px;
            font-size: 0.85rem;
            font-weight: 700;
            border: 1px solid #a7f3d0;
            margin-bottom: 20px;
        }
        .status-dot { width: 8px; height: 8px; background: #10b981; border-radius: 50%; box-shadow: 0 0 8px rgba(16,185,129,0.5); }

        .page-title { font-size: 2.4rem; color: #0f172a; margin: 0 0 16px 0; font-weight: 800; letter-spacing: -0.02em; }
        .today-date { font-size: 1.05rem; color: #ea580c; font-weight: 700; margin-bottom: 16px; display: block; }
        .intro-text { font-size: 1.1rem; color: #475569; line-height: 1.7; margin-bottom: 24px; }

        /* Trust Alert Box */
        .auth-box {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-left: 4px solid #10b981;
            border-radius: 8px;
            padding: 20px 24px;
            display: flex;
            gap: 16px;
            margin-bottom: 32px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.02);
        }
        .auth-icon { font-size: 1.5rem; }
        .auth-text { font-size: 0.95rem; line-height: 1.6; }

        /* 3-Column Stats Grid */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-bottom: 40px;
        }
        .stat-card {
            background: #ffffff;
            border-radius: 12px;
            padding: 24px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05);
        }
        .stat-card h2 { font-size: 1.05rem; margin: 0 0 20px 0; color: #0f172a; display: flex; align-items: center; gap: 8px; font-weight: 800; }
        .ball-row { display: flex; gap: 8px; flex-wrap: wrap; }
        
        /* Outline Style Balls */
        .o-ball {
            width: 36px; height: 36px; border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-weight: 700; font-size: 0.95rem; background: #ffffff;
        }
        .hot-card .o-ball { border: 2px solid #ef4444; color: #ef4444; }
        .cold-card .o-ball { border: 2px solid #3b82f6; color: #3b82f6; }
        .trend-card .o-ball { border: 2px solid #eab308; color: #d97706; }

        /* Generator Interface */
        .generator-tool {
            background: #ffffff; border-radius: 16px; padding: 40px;
            border: 1px solid #e2e8f0; text-align: center; margin-bottom: 40px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
        }
        .generator-tool h2 { font-size: 1.6rem; color: #1e293b; margin: 0 0 24px 0; font-weight: 800; }
        .result-balls { display: flex; justify-content: center; gap: 12px; margin-bottom: 32px; min-height: 70px;}
        .g-ball {
            width: 60px; height: 60px; background: linear-gradient(135deg, #2563eb, #1e40af);
            color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center;
            font-size: 1.5rem; font-weight: 800; box-shadow: 0 8px 16px rgba(37, 99, 235, 0.3);
            transition: transform 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        .g-ball.animate { transform: scale(1.15) rotate(10deg); }
        .gen-controls { display: flex; justify-content: center; gap: 16px; flex-wrap: wrap; }
        .mode-select { padding: 14px 20px; border-radius: 8px; border: 2px solid #e2e8f0; font-size: 1rem; outline: none; }
        .btn-generate { background: #2563eb; color: white; border: none; padding: 14px 28px; border-radius: 8px; font-size: 1.05rem; font-weight: 700; cursor: pointer; transition: all 0.2s; }
        .btn-generate:hover { background: #1d4ed8; transform: translateY(-2px); }

        /* SEO Content Block */
        .content-block { background: #ffffff; border-radius: 12px; padding: 32px 40px; border: 1px solid #e2e8f0; line-height: 1.8; margin-bottom: 40px;}
        .content-block h2 { font-size: 1.6rem; color: #0f172a; margin-top: 32px; margin-bottom: 16px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 800;}
        .content-block h2:first-child { margin-top: 0; }
        .content-block h3 { font-size: 1.2rem; color: #1e293b; margin-top: 24px; font-weight: 700;}
        .content-block p { margin-bottom: 16px; }
        .content-block ul { padding-left: 20px; margin-bottom: 24px; }
        .content-block li { margin-bottom: 8px; }
        .content-block a { color: #2563eb; font-weight: 600; text-decoration: none; }
        .content-block a:hover { text-decoration: underline; }

        /* --- RIGHT COLUMN: SIDEBAR PANEL --- */
        .sidebar { background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; position: sticky; top: 40px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .sidebar-header { background: #2563eb; color: #ffffff; padding: 20px 24px; font-size: 1.1rem; font-weight: 800; letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 16px 24px; border-bottom: 1px solid #f1f5f9; color: #475569; text-decoration: none; font-weight: 600; transition: all 0.2s; }
        .sidebar-menu li a:hover { background: #f8fafc; color: #2563eb; padding-left: 28px; }
        .sidebar-menu li.active a { border-left: 4px solid #2563eb; color: #2563eb; background: #eff6ff; }
        .sidebar-menu li.highlight a { color: #ea580c; } 

        /* Mobile */
        @media (max-width: 992px) {
            .layout-wrapper { grid-template-columns: 1fr; padding: 0 15px;}
            .stats-grid { grid-template-columns: 1fr; }
            .sidebar { position: static; margin-top: 40px; }
            .page-title { font-size: 2rem; }
            .content-block { padding: 24px 20px; }
            .g-ball { width: 48px; height: 48px; font-size: 1.2rem; }
        }
    </style>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/nav.php'; ?>

    <div class="layout-wrapper">
        
        <!-- MAIN CONTENT AREA -->
        <main class="main-content">
            
            <div class="breadcrumb">
                <a href="/">Home</a> › <a href="/results/lotto-plus-2/">Lotto Plus 2</a> › Hot & Cold Numbers
            </div>

            <div class="status-pill">
                <div class="status-dot"></div>
                Data Updated: <?php echo $updateTime; ?>
            </div>

            <!-- Freshness Signal -->
            <span class="today-date">📅 Today: <?php echo $todayDateString; ?></span>
            <h1 class="page-title">SA Lotto Plus 2 Hot and Cold Numbers Today (South Africa)</h1>
            
            <p class="intro-text">
                Welcome to South Africa's leading platform for tracking <strong>Lotto Plus 2 number trends</strong>. As the final draw of the evening, Lotto Plus 2 carries its own unique statistical variance. Dive into the most frequent lotto numbers, monitor overdue 6/52 combinations, and utilize our data-driven smart generator.
            </p>

            <div class="auth-box">
                <div class="auth-icon">📊</div>
                <div class="auth-text">
                    <strong>Data Source Authenticity:</strong> This frequency analysis is dynamically generated directly from the <strong>last 100 official SA Lotto Plus 2 draws</strong>. It was last updated after the draw on <?php echo $lastDrawDateStr; ?>.
                </div>
            </div>

            <!-- Secondary H2s Integrated into the Grid -->
            <div class="stats-grid">
                <div class="stat-card hot-card">
                    <h2>🔥 Lotto Plus 2 Most Frequent Numbers</h2>
                    <div class="ball-row">
                        <?php foreach($hotNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="stat-card cold-card">
                    <h2>❄️ Overdue Lotto Plus 2 Numbers Today</h2>
                    <div class="ball-row">
                        <?php foreach($coldNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="stat-card trend-card">
                    <h2>📈 Trending Numbers (Last 100 Draws)</h2>
                    <div class="ball-row">
                        <?php foreach($trendingNumbers as $num): ?>
                            <div class="o-ball"><?php echo $num; ?></div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- GENERATOR TOOL -->
            <div class="generator-tool">
                <h2>🎯 SA Lotto Plus 2 Number Generator (Smart Picks)</h2>
                
                <div class="result-balls" id="ballsContainer">
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                    <div class="g-ball">?</div>
                </div>

                <div class="gen-controls">
                    <select id="generationMode" class="mode-select">
                        <option value="smart">Mix: Hot + Cold + Random</option>
                        <option value="hot">Trending Focus (Hot Numbers)</option>
                        <option value="random">Standard Quick Pick</option>
                    </select>
                    <button class="btn-generate" onclick="generateNewNumbers()">
                        Generate Lucky Pick
                    </button>
                </div>
            </div>

            <!-- SEO Content Depth & Internal Linking -->
            <div class="content-block">
                
                <h2>Best Strategy for SA Lotto Plus 2 Numbers</h2>
                <p>Lotto Plus 2 is the third and final opportunity to win during the Wednesday and Saturday draws. While it shares the exact same 6/52 matrix as the main Lotto and Lotto Plus 1, your strategy needs to be adjusted to reflect its separate draw dynamics.</p>
                
                <p>South African lottery enthusiasts frequently rely on a <strong>balanced ticket strategy</strong>. Instead of guessing entirely random digits, they utilize our generator to merge mathematically frequent (hot) numbers from the Plus 2 database with a selection of historically overdue (cold) numbers. The tool then fills any remaining gaps randomly, creating a ticket that covers multiple angles of statistical probability.</p>

                <!-- Internal SEO Links -->
                <p>To verify these specific 6/52 patterns yourself, browse the <a href="/results/lotto-plus-2/<?php echo $slug; ?>">latest SA Lotto Plus 2 results</a> or dive deep into our comprehensive <a href="/results/lotto-plus-2/history/">full draw history</a> to observe machine trends over the last few quarters.</p>

                <h2>How the Lotto Plus 2 Numbers Are Drawn</h2>
                <p>The Lotto Plus 2 draw happens twice a week—Wednesday and Saturday nights—following the completion of the main Lotto and Lotto Plus 1 draws. Ithuba, the National Lottery operator, uses independent, certified mechanical draw machines for this game. 6 main balls are selected from a pool of 52, immediately followed by the crucial 7th Bonus Ball.</p>

                <p>Because Lotto Plus 2 is a separate physical event, it maintains entirely independent statistical tendencies. A number currently dominating the main Lotto draw may be completely absent from the Plus 2 draws, making an isolated 100-draw frequency analyzer vital for accurate strategy.</p>

                <h2>Understanding Hot and Cold Trends</h2>
                <h3>Why play "Hot" numbers?</h3>
                <p>A "Hot" number is a digit that has surfaced with unusual frequency across the last 100 Lotto Plus 2 draws. Players chasing hot numbers operate on the theory that microscopic physical variables in the draw machines may be temporarily leaning toward certain balls.</p>

                <h3>Why play "Cold" or "Overdue" numbers?</h3>
                <p>A "Cold" number has shown up the least over our tracked timeframe. Strategy players who favor cold numbers rely on the Law of Averages. Given that the draw is completely random, every ball should theoretically equal out over an infinite period. Therefore, cold numbers are viewed as "overdue" for a draw to restore mathematical equilibrium.</p>
                
                <p style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #f1f5f9; font-size: 0.9rem; color: #64748b;">
                    <em>Disclaimer: This generator and data analysis tool is provided for educational and entertainment purposes only. The National Lottery is a game of chance and no mathematical system can guarantee a jackpot win. Always gamble responsibly.</em>
                </p>
            </div>

        </main>

        <!-- SIDEBAR PANEL -->
        <aside class="sidebar">
            <div class="sidebar-header">LOTTO PLUS 2 PANEL</div>
            <ul class="sidebar-menu">
                <li><a href="/results/lotto-plus-2/">Latest Results</a></li>
                <li><a href="/results/lotto-plus-2/history/">Draw History</a></li>
                <li class="active"><a href="/hot-and-cold-numbers/lotto-plus-2/">Hot & Cold Numbers</a></li>
                <li><a href="/check-tickets/">Check Tickets</a></li>
                <li><a href="/predictions/lotto-plus-2/">Smart Predictions</a></li>
                <li><a href="/how-to-play/lotto/">How to Play</a></li>
                <li class="highlight"><a href="/play-online/" rel="nofollow">Play Online →</a></li>
            </ul>
        </aside>

    </div>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>

    <!-- CLIENT SIDE GENERATOR LOGIC (UPDATED FOR 6/52 LOTTO) -->
    <script>
        const hotData = <?php echo $jsHotData; ?>;
        const coldData = <?php echo $jsColdData; ?>;
        
        function generateNewNumbers() {
            const mode = document.getElementById('generationMode').value;
            const container = document.getElementById('ballsContainer');
            let result = [];
            let pool = Array.from({length: 52}, (_, i) => i + 1);

            if (mode === 'smart') {
                // 2 Hot, 2 Cold, 2 Random
                let tempHot = [...hotData];
                let tempCold = [...coldData];
                
                if(tempHot.length >= 2) {
                    result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                    result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                }
                
                if(tempCold.length >= 2) {
                    result.push(tempCold.splice(Math.floor(Math.random()*tempCold.length), 1)[0]);
                    result.push(tempCold.splice(Math.floor(Math.random()*tempCold.length), 1)[0]);
                }
                
                let remainingPool = pool.filter(n => !result.includes(n));
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);

            } else if (mode === 'hot') {
                // 4 Hot, 2 Random
                let tempHot = [...hotData];
                for(let i=0; i<4; i++) {
                    if(tempHot.length > 0) result.push(tempHot.splice(Math.floor(Math.random()*tempHot.length), 1)[0]);
                }
                let remainingPool = pool.filter(n => !result.includes(n));
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);

            } else {
                // Completely Random (6 numbers from 1-52)
                let remainingPool = [...pool];
                for(let i=0; i<6; i++) {
                    result.push(remainingPool.splice(Math.floor(Math.random()*remainingPool.length), 1)[0]);
                }
            }

            result.sort((a, b) => a - b);
            container.innerHTML = '';
            
            result.forEach((num, index) => {
                setTimeout(() => {
                    let ball = document.createElement('div');
                    ball.className = 'g-ball animate';
                    ball.innerText = String(num).padStart(2, '0');
                    container.appendChild(ball);
                    setTimeout(() => ball.classList.remove('animate'), 300);
                }, index * 100); 
            });
        }
        
        // Auto-run once on page load
        window.onload = generateNewNumbers;
    </script>
</body>
</html>