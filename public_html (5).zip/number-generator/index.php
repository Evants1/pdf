<?php
// Set Timezone
date_default_timezone_set('Africa/Johannesburg');

// 🔥 Optimized Title & Meta Description for the Hub Page
$pageTitle = "SA Lottery Number Generators & Hot/Cold Picks | South Africa";
$metaDesc = "Access free, data-driven number generators for the SA Daily Lotto, PowerBall, and Lotto. Build your strategy using hot and cold numbers from the last 100 draws.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    
    <!-- Hidden SEO Weapon -->
    <meta name="robots" content="index, follow, max-image-preview:large">
    
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- ItemList Schema for SEO -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "ItemList",
      "itemListElement": [
        { "@type": "ListItem", "position": 1, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/daily-lotto/", "name": "Daily Lotto Generator" },
        { "@type": "ListItem", "position": 2, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/powerball/", "name": "PowerBall Generator" },
        { "@type": "ListItem", "position": 3, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/powerball-plus/", "name": "PowerBall Plus Generator" },
        { "@type": "ListItem", "position": 4, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/lotto/", "name": "SA Lotto Generator" },
        { "@type": "ListItem", "position": 5, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/lotto-plus-1/", "name": "Lotto Plus 1 Generator" },
        { "@type": "ListItem", "position": 6, "url": "https://<?php echo $_SERVER['HTTP_HOST']; ?>/number-generator/lotto-plus-2/", "name": "Lotto Plus 2 Generator" }
      ]
    }
    </script>

    <style>
        /* Modern Dotted Background & Base */
        body {
            background-color: #fafbfc;
            background-image: radial-gradient(#e2e8f0 1px, transparent 1px);
            background-size: 24px 24px;
            color: #334155;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
        }
        
        .hub-header {
    background: rgb(250 251 252) !important;
    border: unset !important;
    position: unset !important;
            
        }

        /* Two-Column Layout Grid */
        .layout-wrapper {
            max-width: 1280px;
            margin: 40px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: 1fr 320px;
            gap: 40px;
            align-items: start;
        }

        /* --- LEFT COLUMN: MAIN CONTENT --- */
        .hub-header {
            margin-bottom: 40px;
        }

        .hub-header h1 {
            font-size: 2.8rem;
            color: #0f172a;
            margin: 0 0 16px 0;
            font-weight: 800;
            letter-spacing: -0.02em;
        }

        .hub-header p {
            font-size: 1.15rem;
            color: #475569;
            line-height: 1.7;
            margin: 0;
        }

        /* Tool Cards Grid */
        .tools-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 24px;
            margin-bottom: 40px;
        }

        /* Individual Tool Card */
        .tool-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 24px;
            border: 1px solid #e2e8f0;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            text-decoration: none;
            display: flex;
            flex-direction: column;
            position: relative;
            overflow: hidden;
        }

        .tool-card:hover {
            transform: translateY(-6px);
            box-shadow: 0 20px 40px -10px rgba(0,0,0,0.1);
            border-color: #cbd5e1;
        }

        /* Card Top Accents */
        .tool-card::before {
            content: ''; position: absolute; top: 0; left: 0; right: 0; height: 5px;
        }
        .card-daily::before { background: linear-gradient(90deg, #10b981, #059669); }
        .card-powerball::before { background: linear-gradient(90deg, #ea580c, #c2410c); }
        .card-lotto::before { background: linear-gradient(90deg, #2563eb, #1d4ed8); }

        /* Card Content */
        .card-badge {
            display: inline-block; padding: 4px 10px; border-radius: 6px;
            font-size: 0.75rem; font-weight: 800; letter-spacing: 0.5px;
            text-transform: uppercase; margin-bottom: 16px; align-self: flex-start;
        }
        .card-daily .card-badge { background: #ecfdf5; color: #059669; }
        .card-powerball .card-badge { background: #fff7ed; color: #c2410c; }
        .card-lotto .card-badge { background: #eff6ff; color: #1d4ed8; }

        .tool-card h2 { font-size: 1.3rem; color: #0f172a; margin: 0 0 8px 0; font-weight: 800; }
        .tool-card p { font-size: 0.95rem; color: #64748b; margin: 0 0 20px 0; line-height: 1.6; flex-grow: 1; }

        /* Interactive Button inside Card */
        .card-btn {
            display: flex; align-items: center; justify-content: space-between;
            background: #f8fafc; padding: 12px 16px; border-radius: 8px;
            font-weight: 700; font-size: 0.95rem; color: #334155; transition: background 0.2s;
        }
        .tool-card:hover .card-btn { background: #f1f5f9; }
        .card-btn span.arrow { color: #2563eb; font-size: 1.1rem; transition: transform 0.2s; }
        .tool-card:hover .card-btn span.arrow { transform: translateX(5px); }

        /* SEO Content Block */
        .content-block { background: #ffffff; border-radius: 12px; padding: 32px 40px; border: 1px solid #e2e8f0; line-height: 1.8; margin-bottom: 40px;}
        .content-block h2 { font-size: 1.6rem; color: #0f172a; margin-top: 32px; margin-bottom: 16px; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-weight: 800;}
        .content-block h2:first-child { margin-top: 0; }
        .content-block h3 { font-size: 1.2rem; color: #1e293b; margin-top: 24px; font-weight: 700;}
        .content-block p { margin-bottom: 16px; }
        .content-block ul { padding-left: 20px; margin-bottom: 24px; }
        .content-block li { margin-bottom: 8px; }

        /* --- RIGHT COLUMN: SIDEBAR PANEL --- */
        .sidebar { background: #ffffff; border-radius: 12px; border: 1px solid #e2e8f0; overflow: hidden; position: sticky; top: 40px; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.05); }
        .sidebar-header { background: #0f172a; color: #ffffff; padding: 20px 24px; font-size: 1.1rem; font-weight: 800; letter-spacing: 0.5px; }
        .sidebar-menu { list-style: none; padding: 0; margin: 0; }
        .sidebar-menu li a { display: block; padding: 16px 24px; border-bottom: 1px solid #f1f5f9; color: #475569; text-decoration: none; font-weight: 600; transition: all 0.2s; }
        .sidebar-menu li a:hover { background: #f8fafc; color: #2563eb; padding-left: 28px; }
        .sidebar-menu li.active a { border-left: 4px solid #2563eb; color: #2563eb; background: #eff6ff; }
        .sidebar-menu li.highlight a { color: #ea580c; } 

        /* Mobile */
        @media (max-width: 992px) {
            .layout-wrapper { grid-template-columns: 1fr; padding: 0 15px;}
            .sidebar { position: static; margin-top: 40px; }
            .hub-header h1 { font-size: 2.2rem; }
            .content-block { padding: 24px 20px; }
        }
    </style>
</head>
<body>
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/nav.php'; ?>

    <div class="layout-wrapper">
        
        <!-- MAIN CONTENT AREA -->
        <main class="main-content">
            
            <!-- HEADER ZONE -->
            <header class="hub-header">
                <h1>South African Lottery Number Generators</h1>
                <p>Access our suite of free, data-driven number generators. Stop guessing and start building your ticket strategies using historical hot, cold, and trending data from the last 100 official SA draws.</p>
            </header>

            <!-- TOOLS GRID -->
            <div class="tools-grid">
                
                <!-- Daily Lotto -->
                <a href="/number-generator/daily-lotto/" class="tool-card card-daily">
                    <span class="card-badge">Play 5/36</span>
                    <h2>Daily Lotto</h2>
                    <p>Generate smart combinations. View the most frequent and overdue numbers to build your ticket.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

                <!-- PowerBall -->
                <a href="/number-generator/powerball/" class="tool-card card-powerball">
                    <span class="card-badge">Play 5/50 + 1/20</span>
                    <h2>PowerBall</h2>
                    <p>Track main balls and PowerBall frequencies separately for the ultimate winning strategy.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

                <!-- PowerBall Plus -->
                <a href="/number-generator/powerball-plus/" class="tool-card card-powerball">
                    <span class="card-badge">Play 5/50 + 1/20</span>
                    <h2>PowerBall Plus</h2>
                    <p>Analyze trends specifically for the Tuesday and Friday Plus draws to generate your 6-number line.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

                <!-- Lotto Main -->
                <a href="/number-generator/lotto/" class="tool-card card-lotto">
                    <span class="card-badge">Play 6/52</span>
                    <h2>SA Lotto</h2>
                    <p>Build a balanced ticket for the main Wednesday and Saturday draws using our analyzer.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

                <!-- Lotto Plus 1 -->
                <a href="/number-generator/lotto-plus-1/" class="tool-card card-lotto">
                    <span class="card-badge">Play 6/52</span>
                    <h2>Lotto Plus 1</h2>
                    <p>Explore hot and cold numbers exclusive to the Lotto Plus 1 draw machines.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

                <!-- Lotto Plus 2 -->
                <a href="/number-generator/lotto-plus-2/" class="tool-card card-lotto">
                    <span class="card-badge">Play 6/52</span>
                    <h2>Lotto Plus 2</h2>
                    <p>Generate unique number combinations tailored specifically for the statistical variances of Plus 2.</p>
                    <div class="card-btn">Open Tool <span class="arrow">→</span></div>
                </a>

            </div>

            <!-- SEO CONTENT BLOCK -->
            <article class="content-block">
                <h2>Why Use a Data-Driven Number Generator?</h2>
                <p>Every South African National Lottery draw is completely random. Whether you are playing the Daily Lotto or chasing the massive PowerBall jackpots, every single ball has an equal mathematical probability of being drawn.</p>
                <p>So, why use a generator instead of a standard quick pick at your local retailer? <strong>Strategy and Control.</strong> Our generators do not just spit out random numbers; they parse through the latest 100 official draws in our database to categorize numbers into "Hot" (frequently drawn) and "Cold" (rarely drawn or overdue).</p>

                <h3>The "Smart Pick" Strategy</h3>
                <p>Instead of relying blindly on a terminal or playing sequential numbers (which drastically increases your chance of sharing a jackpot if you win), our tools offer a "Smart Mix" mode. This algorithm builds a ticket that combines:</p>
                <ul>
                    <li><strong>Hot Numbers:</strong> Catching the current trend of the mechanical draw machines.</li>
                    <li><strong>Cold Numbers:</strong> Leveraging the Law of Averages for digits that are statistically overdue.</li>
                    <li><strong>Random Elements:</strong> Adding unpredictability to ensure your ticket remains unique.</li>
                </ul>

                <h2>Completely Free & Always Updated</h2>
                <p>All of our generators and statistical tools are 100% free to use. Furthermore, our systems automatically update every single night immediately following the official Ithuba draws. This means whether you are checking the Daily Lotto on a Monday or preparing for a massive Friday PowerBall, the hot and cold data you see is absolute, real-time reality.</p>

                <p style="margin-top: 32px; padding-top: 16px; border-top: 1px solid #f1f5f9; font-size: 0.95rem; color: #64748b; text-align: center;">
                    <em>Disclaimer: Lottery games are games of chance. Our tools analyze historical data for entertainment and strategic planning. They do not guarantee a winning ticket. Always gamble responsibly.</em>
                </p>
            </article>

        </main>

        <!-- SIDEBAR PANEL -->
        <aside class="sidebar">
            <div class="sidebar-header">LOTTERY TOOLS</div>
            <ul class="sidebar-menu">
                <li class="active"><a href="/number-generator/">Smart Generators</a></li>
                <li><a href="/check-tickets/">Check Tickets</a></li>
                <li><a href="/results/daily-lotto/">Daily Lotto Results</a></li>
                <li><a href="/results/powerball/">PowerBall Results</a></li>
                <li><a href="/results/lotto/">SA Lotto Results</a></li>
                <li><a href="/predictions/">Predictions Hub</a></li>
                <li class="highlight"><a href="/play-online/" rel="nofollow">Play Online →</a></li>
            </ul>
        </aside>

    </div>

    <?php include $_SERVER['DOCUMENT_ROOT'] . '/static/footer.php'; ?>
</body>
</html>