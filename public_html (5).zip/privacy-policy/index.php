<?php
$pageTitle = "Privacy Policy – How We Protect Your Data | Next Draw Logic South Africa";
$metaDesc = "Learn how Next Draw Logic protects your data, uses cookies, and complies with South African privacy laws (POPIA). No personal data required to use our lotto tools.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">
    <link rel="stylesheet" href="/style/style.css">
    
    <!-- Structured Data for SEO Trust -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "WebPage",
      "name": "Privacy Policy",
      "description": "Privacy policy explaining how Next Draw Logic handles user data, cookies, and local storage.",
      "publisher": {
        "@type": "Organization",
        "name": "Next Draw Logic"
      }
    }
    </script>

    <style>
    
        /* Modern Legal Page Container */
        .legal-wrapper {
            padding: 60px 20px;
            background-color: #f8fafc; /* Subtle off-white background behind the card */
            min-height: 100vh;
        }
        
        .page-header {
    position: unset !important;
    z-index: unset !important;
}

        .legal-container { 
            max-width: 1200px; /* 850px is the optimal modern reading width for text */
            margin: 0 auto; 
            padding: 50px 60px; 
            background: #ffffff; 
            border-radius: 24px; 
            box-shadow: 0 20px 40px -15px rgba(0,0,0,0.05); 
            border: 1px solid #e2e8f0; 
            line-height: 1.8; 
            color: #475569; 
            font-size: 1.05rem;
        }

        /* Modern Typography & Header */
        .page-header {
            text-align: center;
            margin-bottom: 40px;
            padding-bottom: 30px;
            border-bottom: 2px solid #f1f5f9;
        }

        .legal-container h1 { 
            font-size: 2.8rem; 
            color: #0f172a; 
            margin: 0 0 16px 0; 
            font-weight: 800; 
            letter-spacing: -0.03em;
        }

        .last-updated {
            display: inline-block;
            background: #f1f5f9;
            color: #64748b;
            padding: 6px 16px;
            border-radius: 99px;
            font-size: 0.9rem;
            font-weight: 600;
        }

        .legal-container h2 { 
            font-size: 1.4rem; 
            color: #0f172a; 
            margin: 40px 0 16px 0; 
            font-weight: 800;
            display: flex;
            align-items: center;
            gap: 12px;
        }

        /* Accent dash before H2 tags */
        .legal-container h2::before {
            content: '';
            display: block;
            width: 24px;
            height: 4px;
            background: var(--primary, #4f46e5);
            border-radius: 4px;
        }

        .legal-container p {
            margin-bottom: 20px;
        }

        /* Modern Links */
        .legal-container a { 
            color: var(--primary, #4f46e5); 
            text-decoration: none; 
            font-weight: 600; 
            position: relative;
        }
        
        .legal-container a::after {
            content: '';
            position: absolute;
            width: 100%;
            height: 2px;
            bottom: -2px;
            left: 0;
            background-color: var(--primary, #4f46e5);
            visibility: hidden;
            transform: scaleX(0);
            transition: all 0.2s ease-in-out;
        }

        .legal-container a:hover::after {
            visibility: visible;
            transform: scaleX(1);
        }

        /* Trust Block UI Component */
        .trust-block { 
            background: linear-gradient(to right, #f0fdf4, #ffffff); 
            padding: 20px 24px; 
            border-left: 4px solid #10b981; 
            border-radius: 0 12px 12px 0; 
            margin: 32px 0; 
            color: #0f172a; 
            font-size: 1.05rem; 
            box-shadow: 0 4px 6px rgba(0,0,0,0.02);
        }

        /* Custom Modern List Styling */
        .legal-container ul {
            list-style: none;
            padding: 0;
            margin: 24px 0;
            display: flex;
            flex-direction: column;
            gap: 12px;
        }

        .legal-container ul li {
            background: #f8fafc;
            border: 1px solid #e2e8f0;
            padding: 16px 20px;
            border-radius: 12px; /* Smoother border radius */
            display: flex;
            align-items: center;
            color: #1e293b;
            font-weight: 600;
            font-size: 1.05rem;
            transition: all 0.2s ease;
        }

        .legal-container ul li:hover {
            border-color: var(--primary, #4f46e5); 
            box-shadow: 0 4px 12px rgba(79, 70, 229, 0.08);
            transform: translateX(4px); 
        }

        .legal-container ul li::before {
            content: '✓';
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 28px;
            height: 28px;
            background: #e0e7ff;
            color: var(--primary, #4f46e5);
            border-radius: 50%;
            margin-right: 16px;
            font-weight: 800;
            font-size: 0.9rem;
            flex-shrink: 0;
        }

        /* Mobile Responsiveness */
        @media (max-width: 768px) {
            .legal-wrapper { padding: 20px 10px; }
            .legal-container { padding: 30px 20px; border-radius: 16px; }
            .legal-container h1 { font-size: 2.2rem; }
            .legal-container h2 { font-size: 1.25rem; }
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../static/nav.php'; ?>

    <div class="legal-wrapper">
        <main class="legal-container">
            
            <header class="page-header">
                <h1>Privacy Policy</h1>
                <span class="last-updated">Updated: <?php echo date("F Y"); ?></span>
            </header>
            
            <p>At Next Draw Logic, accessible from <a href="/">nextdrawlogic.co.za</a>, one of our main priorities is the privacy of our visitors. You can use tools like our <a href="/check-tickets/">ticket checker</a> without submitting personal data. This Privacy Policy document contains types of information that is collected and recorded by Next Draw Logic and how we use it.</p>

            <div class="trust-block">
                <strong>🔒 Privacy First:</strong> You can use all our lotto tools without creating an account or sharing personal data.
            </div>

            <h2>1. Information We Collect</h2>
            <p>We do not require you to create an account to use our site. We do not collect Personally Identifiable Information (PII) such as your name, address, or ID number unless you voluntarily provide it by contacting us via email.</p>

            <h2>2. Ticket Checker & Local Storage</h2>
            <p>When you use our Ticket Checker tools, the lottery numbers you input may be temporarily saved to your browser's "Local Storage." This is done solely to improve your user experience (so you don't have to re-type your numbers if you refresh the page). This data is stored locally on your device, not on our servers.</p>

            <h2>3. Log Files</h2>
            <p>Next Draw Logic follows a standard procedure of using log files. These files log visitors when they visit websites. The information collected by log files includes internet protocol (IP) addresses, browser type, Internet Service Provider (ISP), date and time stamp, referring/exit pages, and possibly the number of clicks.</p>

            <h2>4. Cookies and Web Beacons</h2>
            <p>Like any other website, Next Draw Logic uses "cookies". These cookies are used to store information including visitors' preferences, and the pages on the website that the visitor accessed or visited. We use this information to optimize the users' experience by customizing our web page content based on visitors' browser type.</p>

            <h2>5. Third-Party Links</h2>
            <p>Our website may contain links to external sites (such as sports betting or official lottery platforms) that are not operated by us. If you click on a third-party link, you will be directed to that third party's site. We strongly advise you to review the Privacy Policy of every site you visit.</p>

            <h2>6. Your Privacy Rights (POPIA & GDPR)</h2>
            <p>If you are located in South Africa, your data is protected under the Protection of Personal Information Act (POPIA).</p>
            <p>You have the right to:</p>
            <ul>
                <li>Request access to your data</li>
                <li>Request correction or deletion</li>
                <li>Withdraw consent for data usage</li>
            </ul>
            <p>Since we do not store personal data on our servers, most requests are inherently fulfilled by design.</p>

            <h2>7. Affiliate Disclosure</h2>
            <p>Next Draw Logic may contain affiliate links to third-party platforms. If you click and register through these links, we may earn a commission at no additional cost to you. These links help support the operation of our free tools.</p>

            <h2>8. Contact Us</h2>
            <p>If you have any questions about this Privacy Policy, you can contact us at:</p>
            <p><strong>Email:</strong> <a href="mailto:support@nextdrawlogic.co.za">support@nextdrawlogic.co.za</a></p>

        </main>
    </div>

    <?php include __DIR__ . '/../static/footer.php'; ?>
</body>
</html>