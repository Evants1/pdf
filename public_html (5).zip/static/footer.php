<footer class="modern-footer">
    <div class="container footer-content">
        <div class="footer-brand">
            <strong>Next Draw Logic</strong>
            <p>Independent South African lottery journalism since 2025. We analyse every draw so you don’t have to. Real insights. Real stories. Real edge for everyday players.</p>
            
            <p class="footer-trust" style="margin-top: 16px; font-size: 0.85rem; color: #94a3b8; font-style: italic; line-height: 1.5;">
                Data sourced from public draw data and verified against official Ithuba Holdings (National Lottery) publications. All analysis is independent and strictly for informational purposes.
            </p>
        </div>
        
        <div class="footer-links-wrap">
            <div class="footer-col">
                <strong>Explore More</strong>
                <a href="/">Today's Daily Lotto Results</a>
                <a href="/results/daily-lotto/history/">All Daily Lotto Results History (South Africa)</a>
                <a href="/hot-and-cold-numbers/">Hot & Cold Numbers</a>
                <a href="/predictions/">Lotto Predictions</a>
                <!--<a href="/blog/">Lottery News &amp; Stories</a>-->
            </div>
            <div class="footer-col">
                <strong>Company & Legal</strong>
                <a href="/about-us/">About US</a>
                <a href="/contact-us/">Contact US</a>
                <a href="/privacy-policy/">Privacy Policy</a>
                <a href="/terms-of-service/">Terms of Service</a>
                <a href="/responsible-gambling/">Responsible Gambling</a>
            </div>
        </div>
    </div>
    <div class="container footer-bottom">
        &copy; <?php echo date("Y"); ?> NextDrawLogic • Independent analysis only. Not affiliated with <a href="https://ithubalottery.co.za/" target="_blank" rel="noopener nofollow">Ithuba Holdings</a> or the <a href="https://www.national-lottery.co.za" target="_blank" rel="noopener nofollow">South African National Lottery</a>. <a href="https://www.responsiblegambling.org.za" target="_blank" rel="noopener nofollow" style="text-decoration: underline; color: inherit;">Play responsibly.</a>
    </div>
</footer>