<?php
// Set timezone
date_default_timezone_set('Africa/Johannesburg');

// --- SEO METADATA ---
$pageTitle = "SA Lottery Hot & Cold Numbers Hub | South Africa Lotto Stats";
$metaDesc = "Access complete Hot and Cold number analytics for all major South African lotteries. View the most frequently drawn numbers for PowerBall, Lotto, and Daily Lotto based on 100-draw data.";
$currentUrl = "https://" . $_SERVER['HTTP_HOST'] . explode('?', $_SERVER['REQUEST_URI'])[0];

$breadcrumbs = [
    ["name" => "Home", "url" => "https://" . $_SERVER['HTTP_HOST'] . "/"],
    ["name" => "Hot & Cold Numbers", "url" => $currentUrl]
];

// --- PAGE SPECIFIC FAQs FOR SEO ---
$pageFaqs = [
    [
        "question" => "What exactly is a 'Hot Number' in SA lotteries?",
        "answer" => "A 'Hot Number' is a specific lottery ball that has been drawn more frequently than average over a recent period. Our algorithm tracks the last 100 official draws for every South African game to identify these mathematically trending numbers."
    ],
    [
        "question" => "What does it mean when a number is 'Cold'?",
        "answer" => "A 'Cold Number' is a ball that has rarely appeared in recent draws. Some players believe these numbers are statistically 'overdue' to be drawn, while others avoid them, preferring to ride the momentum of hot numbers."
    ],
    [
        "question" => "How often is this statistical data updated?",
        "answer" => "Our database dynamically updates immediately after every official Ithuba draw (20:30 for Daily Lotto, and 21:00 for Lotto and PowerBall draws). The frequency charts on our site are always perfectly synced with the latest results."
    ],
    [
        "question" => "Does playing hot numbers guarantee a win?",
        "answer" => "No. Lottery draws use certified Random Number Generators (RNG) or physical ball machines, meaning every draw is an independent event. Statistical frequency helps players make data-driven choices rather than random guesses, but it does not guarantee a jackpot."
    ]
];
?>
<!DOCTYPE html>
<html lang="en-ZA">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $pageTitle; ?></title>
    <meta name="description" content="<?php echo $metaDesc; ?>">
    <meta name="keywords" content="south africa hot numbers, cold numbers, lottery statistics, powerball hot numbers, lotto hot numbers, daily lotto trends, sa lotto frequency, overdue lottery numbers">
    
    <meta name="robots" content="index, follow">
    <link rel="canonical" href="<?php echo $currentUrl; ?>">

    <meta property="og:title" content="<?php echo $pageTitle; ?>">
    <meta property="og:description" content="<?php echo $metaDesc; ?>">
    <meta property="og:type" content="website">
    <meta property="og:url" content="<?php echo $currentUrl; ?>">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    
    <style>
        /* Base site styles */
        <?php 
        $stylePath = $_SERVER['DOCUMENT_ROOT'] . '/style/style.css';
        if(file_exists($stylePath)) { echo file_get_contents($stylePath); } 
        ?>
        
        /* --- CENTERING & LAYOUT --- */
        .container { max-width: 1323px; margin: 0 auto; padding: 0 20px; width: 100%; box-sizing: border-box; }
        .layout-with-sidebar { display: grid; grid-template-columns: minmax(0, 1fr) 280px; gap: 40px; align-items: start; margin-top: 24px; }
        .content-area { min-width: 0; width: 100%; }

        /* --- SIDEBAR STYLES --- */
        .lotto-sidebar { position: sticky; top: 100px; z-index: 10; }
        .sidebar-menu { background: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0,0,0,0.1); border: 1px solid #e2e8f0; }
        .sidebar-menu-header { background: linear-gradient(135deg, #1e293b, #0f172a); color: #ffffff; padding: 20px 24px; font-weight: 800; font-size: 1.1rem; text-transform: uppercase; letter-spacing: 0.5px; }
        .sidebar-links { list-style: none; margin: 0; padding: 0; }
        .sidebar-links li { border-bottom: 1px solid #f1f5f9; }
        .sidebar-links a { display: flex; align-items: center; padding: 16px 24px; color: #64748b; font-weight: 600; font-size: 0.95rem; border-left: 4px solid transparent; transition: all 0.2s ease; background: #ffffff; text-decoration: none; }
        .sidebar-links a:hover { background: #f8fafc; color: #0f172a; border-left-color: #94a3b8; }
        .sidebar-links a.active { background: #f8fafc; color: #3b82f6; border-left-color: #3b82f6; font-weight: 800; }
        .sidebar-links a.highlight { color: #d97706; font-weight: 700; }

        /* --- HUB HEADER --- */
        .hub-header { margin-bottom: 40px; }
        .hub-header h1 { font-size: 2.4rem; font-weight: 800; color: #0f172a; margin-top: 0; margin-bottom: 16px; line-height: 1.2; }
        .hub-header p { font-size: 1.1rem; color: #475569; line-height: 1.6; margin: 0; }

        /* --- MODERN UL GRID CARDS --- */
        .hot-cold-hub-list { 
            list-style: none; 
            padding: 0; 
            margin: 0 0 48px 0; 
            display: grid; 
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); 
            gap: 20px; 
        }

        .hub-card {
            background: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 20px;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 16px;
            text-decoration: none;
            color: inherit;
            box-shadow: 0 2px 4px -1px rgba(0,0,0,0.02);
            position: relative;
            overflow: hidden;
        }

        .hub-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgba(0,0,0,0.08), 0 4px 6px -2px rgba(0,0,0,0.04);
            border-color: #cbd5e1;
        }

        .game-icon {
            width: 54px; 
            height: 54px; 
            border-radius: 12px; 
            display: flex; 
            align-items: center; 
            justify-content: center; 
            font-size: 1.4rem; 
            font-weight: 800; 
            color: white;
            flex-shrink: 0;
            z-index: 2;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        /* Color Themes */
        .dl-bg { background: linear-gradient(135deg, #f59e0b, #d97706); } /* Gold */
        .pb-bg { background: linear-gradient(135deg, #e11d48, #9f1239); } /* Red */
        .pbp-bg { background: linear-gradient(135deg, #be123c, #881337); } /* Dark Red */
        .lt-bg { background: linear-gradient(135deg, #10b981, #047857); } /* Green */
        .lt1-bg { background: linear-gradient(135deg, #059669, #065f46); } /* Dark Green */
        .lt2-bg { background: linear-gradient(135deg, #047857, #064e3b); } /* Darker Green */

        .card-content { z-index: 2; }
        .card-content h2 { margin: 0 0 4px 0; font-size: 1.15rem; font-weight: 800; color: #0f172a; }
        .card-content p { margin: 0; font-size: 0.85rem; color: #64748b; line-height: 1.4; }
        
        .arrow { 
            margin-left: auto; 
            color: #cbd5e1; 
            font-size: 1.3rem; 
            transition: transform 0.3s ease, color 0.3s ease; 
            z-index: 2;
            font-weight: bold;
        }
        .hub-card:hover .arrow { 
            color: #0f172a; 
            transform: translateX(4px); 
        }

        /* --- SEO CONTENT SECTIONS --- */
        .seo-content-box { background: #ffffff; padding: 32px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 40px; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
        .seo-content-box h2 { margin-top: 0; font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 20px; }
        .seo-content-box h3 { font-size: 1.2rem; font-weight: 700; color: #1e293b; margin-top: 24px; margin-bottom: 12px; }
        .seo-content-box p { color: #475569; line-height: 1.7; font-size: 1.05rem; margin-bottom: 16px; }
        .seo-content-box ul { color: #475569; line-height: 1.7; font-size: 1.05rem; padding-left: 20px; }
        .seo-content-box li { margin-bottom: 8px; }

        /* --- FAQ SECTION --- */
        .faq-section { margin-bottom: 40px; }
        .faq-header { font-size: 1.6rem; font-weight: 800; color: #0f172a; margin-bottom: 24px; padding-left: 14px; border-left: 5px solid #3b82f6; line-height: 1.2; }
        .faq-item { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; margin-bottom: 14px; overflow: hidden; transition: box-shadow 0.2s ease; }
        .faq-question { width: 100%; text-align: left; background: transparent; border: none; padding: 20px 24px; font-size: 1.05rem; font-weight: 700; color: #1e293b; cursor: pointer; display: flex; justify-content: space-between; align-items: center; font-family: inherit; }
        .faq-icon { color: #3b82f6; font-size: 1.6rem; line-height: 1; font-weight: 400; transition: transform 0.3s ease; }
        .faq-answer { max-height: 0; overflow: hidden; transition: max-height 0.3s ease, padding 0.3s ease; background: #ffffff; }
        .faq-answer-inner { padding: 0 24px 20px 24px; color: #475569; font-size: 0.95rem; line-height: 1.6; }
        .faq-item.active .faq-icon { transform: rotate(45deg); }
        .faq-item.active .faq-answer { max-height: 500px; }

        @media(max-width: 1024px) {
            .layout-with-sidebar { grid-template-columns: 1fr; }
            .lotto-sidebar { position: relative; top: 0; }
        }
        @media(max-width: 768px) {
            .hub-header h1 { font-size: 2rem; }
            .hot-cold-hub-list { grid-template-columns: 1fr; }
        }
        
        
    </style>

    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        <?php foreach ($pageFaqs as $index => $faq): ?>
        {
          "@type": "Question",
          "name": "<?php echo addslashes($faq['question']); ?>",
          "acceptedAnswer": {
            "@type": "Answer",
            "text": "<?php echo addslashes($faq['answer']); ?>"
          }
        }<?php echo $index < count($pageFaqs) - 1 ? ',' : ''; ?>
        <?php endforeach; ?>
      ]
    }
    </script>
</head>
<body>

    <?php include __DIR__ . '/../static/nav.php'; ?>

    <main class="container">
        
        <nav class="breadcrumb" style="margin-top: 20px;">
            <ul class="breadcrumb-list">
                <?php foreach ($breadcrumbs as $index => $crumb): ?>
                    <li class="breadcrumb-item">
                        <?php if ($index !== array_key_last($breadcrumbs)): ?>
                            <a href="<?php echo $crumb['url']; ?>" class="breadcrumb-link"><?php echo $crumb['name']; ?></a>
                        <?php else: ?>
                            <span class="breadcrumb-current"><?php echo $crumb['name']; ?></span>
                        <?php endif; ?>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <div class="layout-with-sidebar">
            <div class="content-area">

                <header class="hub-header">
                    <h1>South African Lottery Hot & Cold Numbers</h1>
                    <p>Select your game below. Our data engine actively scans the last 100 official draws to map out statistical frequency, hot pairs, and cold, overdue numbers.</p>
                </header>

                <ul class="hot-cold-hub-list">
                    
                    <li>
                        <a href="/hot-and-cold-numbers/daily-lotto/" class="hub-card">
                            <div class="game-icon dl-bg">DL</div>
                            <div class="card-content">
                                <h2>Daily Lotto</h2>
                                <p>Analyze 36-ball frequency from daily draws.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/hot-and-cold-numbers/powerball/" class="hub-card">
                            <div class="game-icon pb-bg">PB</div>
                            <div class="card-content">
                                <h2>PowerBall</h2>
                                <p>Track the hottest numbers in the dual-matrix system.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/hot-and-cold-numbers/powerball-plus/" class="hub-card">
                            <div class="game-icon pbp-bg">P+</div>
                            <div class="card-content">
                                <h2>PowerBall Plus</h2>
                                <p>View separate analytics for the Plus draw machine.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/hot-and-cold-numbers/lotto/" class="hub-card">
                            <div class="game-icon lt-bg">LT</div>
                            <div class="card-content">
                                <h2>Lotto</h2>
                                <p>Explore hot numbers for the classic 52-ball game.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/hot-and-cold-numbers/lotto-plus-1/" class="hub-card">
                            <div class="game-icon lt1-bg">L1</div>
                            <div class="card-content">
                                <h2>Lotto Plus 1</h2>
                                <p>Check the latest statistical trends for Plus 1.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                    <li>
                        <a href="/hot-and-cold-numbers/lotto-plus-2/" class="hub-card">
                            <div class="game-icon lt2-bg">L2</div>
                            <div class="card-content">
                                <h2>Lotto Plus 2</h2>
                                <p>Discover frequent pairs and cold numbers for Plus 2.</p>
                            </div>
                            <div class="arrow">&rarr;</div>
                        </a>
                    </li>

                </ul>

                <section class="seo-content-box">
                    <h2>Advanced Statistical Analysis for SA Lotteries</h2>
                    <p>Building a smarter lottery ticket requires moving beyond quick picks and family birthdays. Professional lottery tracking relies on understanding the mathematical variance found within recent draw histories. By utilizing our Hot and Cold number matrices, players can view exactly how the certified RNG systems and ball machines are behaving over a 100-draw rolling window.</p>
                    
                    <h3>The Dual-Matrix Rule</h3>
                    <p>Games like PowerBall operate on two distinct machines. It is a critical mathematical error to blend the main 50-ball pool with the 20-ball PowerBall pool. Our systems meticulously separate these databases, ensuring that your frequency tracking is strictly comparing apples to apples.</p>

                    <h3>How to use this data:</h3>
                    <ul>
                        <li><strong>Momentum Strategy:</strong> Select heavily from the "Hot" pool, assuming that physical ball weights or machine dynamics are favoring specific numbers.</li>
                        <li><strong>The Overdue Strategy:</strong> Select from the "Cold" pool, relying on the Law of Large Numbers, which suggests all balls must eventually equal out in frequency over time.</li>
                        <li><strong>The Balanced Approach:</strong> A hybrid ticket utilizing 2 Hot numbers, 1 Cold number, and 2 mid-range numbers alongside our Odd/Even balance checks.</li>
                    </ul>
                </section>

                <section class="faq-section">
                    <h2 class="faq-header">Frequently Asked Questions</h2>
                    <div class="faq-list">
                        <?php foreach($pageFaqs as $faq): ?>
                        <div class="faq-item">
                            <button class="faq-question">
                                <?php echo htmlspecialchars($faq['question']); ?>
                                <span class="faq-icon">+</span>
                            </button>
                            <div class="faq-answer">
                                <div class="faq-answer-inner">
                                    <p><?php echo htmlspecialchars($faq['answer']); ?></p>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </section>

            </div>

            <aside class="lotto-sidebar">
                <nav class="sidebar-menu" aria-label="Lottery Tools Navigation">
                    <div class="sidebar-menu-header">Lottery Tools</div>
                    <ul class="sidebar-links">
                        <li><a href="/">Latest Live Results</a></li>
                        <li><a href="/hot-and-cold-numbers/" class="active">Hot & Cold Hub</a></li>
                        <li><a href="/predictions/">Smart Predictions</a></li>
                        <li><a href="/check-tickets/">Ticket Checker</a></li>
                        <!--<li><a href="https://affiliates.hollywoodbets.net/" class="highlight" target="_blank" rel="noopener nofollow">Play Online Now &rarr;</a></li>-->
                    </ul>
                </nav>
            </aside>

        </div>
    </main>

    <?php include __DIR__ . '/../static/footer.php'; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // FAQ Accordion Logic
            const faqQuestions = document.querySelectorAll('.faq-question');
            faqQuestions.forEach(question => {
                question.addEventListener('click', () => {
                    const faqItem = question.parentElement;
                    
                    // Close others
                    document.querySelectorAll('.faq-item').forEach(item => {
                        if (item !== faqItem) item.classList.remove('active');
                    });
                    
                    // Toggle clicked
                    faqItem.classList.toggle('active');
                });
            });
        });
    </script>
</body>
</html>