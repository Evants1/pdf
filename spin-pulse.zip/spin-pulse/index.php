<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

get_header();
?>

<main id="primary" class="site-main min-h-screen bg-white">

    <section class="sp-single-hero-wrapper py-12 border-b border-slate-100 bg-slate-50">
        <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
            <header class="sp-index-header">
                <?php if ( is_home() && ! is_front_page() ) : ?>
                    <h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-4">
                        <?php single_post_title(); ?>
                    </h1>
                    <p class="sp-index-subtitle text-lg text-slate-600 max-w-2xl">
                        <?php esc_html_e( 'Explore our latest articles, guides, and expert reviews.', 'spin-pulse' ); ?>
                    </p>
                <?php else : ?>
                    <h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-4">
                        <?php esc_html_e( 'Latest News & Articles', 'spin-pulse' ); ?>
                    </h1>
                <?php endif; ?>
            </header>
        </div>
    </section>

    <div class="sp-index-main-wrapper py-12">
        <div class="max-w-[1200px] mx-auto px-4 sm:px-6">
            
            <div class="sp-index-content">
                <?php if ( have_posts() ) : ?>
                    
                    <div class="flex flex-col gap-8 mb-12">
                        <?php
                        /* Start the Loop */
                        while ( have_posts() ) :
                            the_post();

                            /*
                             * Include the Post-Type-specific template for the content.
                             * This will pull the beautiful card UI we built in content.php!
                             */
                            get_template_part( 'template-parts/content', get_post_type() );

                        endwhile;
                        ?>
                    </div>

                    <div class="sp-index-pagination mt-8">
                        <?php 
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            // THEMEFOREST FIX: Escaped properly and replaced HTML entities with Unicode
                            'prev_text' => esc_html__( '← Previous', 'spin-pulse' ),
                            'next_text' => esc_html__( 'Next →', 'spin-pulse' ),
                        ) ); 
                        ?>
                    </div>

                <?php else : ?>

                    <?php get_template_part( 'template-parts/content', 'none' ); ?>

                <?php endif; ?>
            </div>

        </div>
    </div>

</main>

<?php get_footer(); ?>