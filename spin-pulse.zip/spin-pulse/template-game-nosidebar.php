<?php
/**
 * Template Name: SP Game - No Sidebar
 * Template Post Type: casino_game
 *
 * @package SpinPulse
 */

get_header();

// Fetch data
$rating = get_post_meta(get_the_ID(), 'sp_review_rating', true) ?: '5.0';
$bonus = get_post_meta(get_the_ID(), 'sp_review_bonus', true) ?: 'Exclusive Offer';
$play_link = get_post_meta(get_the_ID(), 'sp_review_link', true) ?: '#';

// Author Data
$current_author_id = get_post_field('post_author', get_the_ID());
$current_author_name = get_the_author_meta('display_name', $current_author_id);
$author_url = esc_url(get_author_posts_url($current_author_id));

// Social Links
$tw_url = get_the_author_meta('twitter', $current_author_id);
$fb_url = get_the_author_meta('facebook', $current_author_id);
$ig_url = get_the_author_meta('instagram', $current_author_id);
$li_url = get_the_author_meta('linkedin', $current_author_id);
?>

<main class="site-main min-h-screen bg-white">

    <section class="bg-slate-900 py-12 md:py-20 relative overflow-hidden border-b-4 border-[#00d67d]">
        <div class="absolute inset-0 opacity-5 pointer-events-none"
            style="background-image: radial-gradient(#ffffff 1px, transparent 1px); background-size: 20px 20px;"></div>

        <div class="max-w-[1200px] mx-auto px-6 relative z-10">
            <div class="text-sm text-slate-400 mb-8 font-medium">
                <a href="<?php echo home_url(); ?>" class="text-[#00d67d] hover:underline">Home</a> &raquo;
                <span class="text-slate-500">Games</span> &raquo;
                <span class="text-slate-500"><?php the_title(); ?></span>
            </div>

            <div class="flex flex-col md:flex-row items-center md:items-start gap-10">
                <div
                    class="w-40 h-40 md:w-56 md:h-56 bg-white rounded-3xl p-4 shadow-2xl flex-shrink-0 flex items-center justify-center border-4 border-slate-800">
                    <?php if (has_post_thumbnail()): ?>
                        <?php the_post_thumbnail('medium', ['class' => 'max-w-full max-h-full object-contain']); ?>
                    <?php else: ?>
                        <span class="text-slate-400 font-bold text-xl uppercase text-center"><?php the_title(); ?></span>
                    <?php endif; ?>
                </div>

                <div class="flex-grow text-center md:text-left flex flex-col justify-center">
                    <div class="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-4">
                        <span
                            class="bg-slate-800 text-white text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full border border-slate-700">Verified
                            Game</span>
                        <div class="flex text-[#ffcc00] text-lg">
                            <?php
                            $solid_stars = floor($rating);
                            $has_half = ($rating - $solid_stars) >= 0.5 ? 1 : 0;
                            $empty_stars = 5 - $solid_stars - $has_half;
                            for ($i = 0; $i < $solid_stars; $i++)
                                echo '★';
                            if ($has_half)
                                echo '⯨';
                            for ($i = 0; $i < $empty_stars; $i++)
                                echo '☆';
                            ?>
                        </div>
                        <span class="text-[#00d67d] font-bold text-lg"><?php echo esc_html($rating); ?> / 5.0</span>
                    </div>

                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white mb-4">
                        <?php the_title(); ?>
                    </h1>

                    <p class="text-xl md:text-2xl font-bold text-slate-300 mb-8 max-w-2xl">
                        <span class="text-[#00d67d]">Offer:</span> <?php echo esc_html($bonus); ?>
                    </p>

                    <div
                        class="flex flex-wrap items-center justify-center md:justify-start mt-4 pt-6 border-t border-slate-800">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo $author_url; ?>" class="block">
                                <?php echo get_avatar($current_author_id, 46, '', '', array('class' => 'rounded-full border-2 border-slate-600 hover:border-[#00d67d] transition-colors')); ?>
                            </a>
                            <div class="flex flex-col text-left">
                                <span class="text-slate-400 text-sm">Authored By <a href="<?php echo $author_url; ?>"
                                        class="text-white font-bold hover:text-[#00d67d] transition-colors"><?php echo esc_html($current_author_name); ?></a></span>
                                <span class="text-slate-500 text-xs mt-0.5">Last Updated:
                                    <?php the_modified_date('F j, Y'); ?></span>
                            </div>
                        </div>

                        <?php if ($tw_url || $fb_url || $ig_url || $li_url): ?>
                            <div class="hidden sm:block w-px h-10 bg-slate-700 mx-16"></div>
                            <div class="flex items-center gap-2">
                                <?php if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" target="_blank"
                                        rel="noopener noreferrer"
                                        class="w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center text-slate-400 hover:bg-white hover:text-[#0f1419] hover:border-white transition-all shadow-sm"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path
                                                d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z">
                                            </path>
                                        </svg></a><?php endif; ?>
                                <?php if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" target="_blank"
                                        rel="noopener noreferrer"
                                        class="w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center text-slate-400 hover:bg-[#1877F2] hover:text-white hover:border-[#1877F2] transition-all shadow-sm"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path>
                                        </svg></a><?php endif; ?>
                                <?php if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" target="_blank"
                                        rel="noopener noreferrer"
                                        class="w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center text-slate-400 hover:bg-[#E1306C] hover:text-white hover:border-[#E1306C] transition-all shadow-sm"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect>
                                            <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path>
                                            <line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line>
                                        </svg></a><?php endif; ?>
                                <?php if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" target="_blank"
                                        rel="noopener noreferrer"
                                        class="flex items-center justify-center w-10 h-10 rounded-full border border-slate-700 flex items-center justify-center text-slate-400 hover:bg-[#0A66C2] hover:text-white hover:border-[#0A66C2] transition-all shadow-sm"><svg
                                            xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24"
                                            fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"
                                            stroke-linejoin="round">
                                            <path
                                                d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z">
                                            </path>
                                            <rect x="2" y="9" width="4" height="12"></rect>
                                            <circle cx="4" cy="4" r="2"></circle>
                                        </svg></a><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="max-w-[1078px] mx-auto px-6 py-16 w-full">
        <?php if (have_posts()):
            while (have_posts()):
                the_post(); ?>

                <article id="post-<?php the_ID(); ?>" <?php post_class('sp-single-article'); ?>>
                    <div class="prose prose-slate prose-lg sp-single-content max-w-none">
                        <?php
                        the_content();

                        wp_link_pages(array(
                            'before' => '<div class="page-links mt-8">' . esc_html__('Pages:', 'spin-pulse'),
                            'after' => '</div>',
                        ));
                        ?>
                    </div>
                </article>

                <?php
                // --- COMMENTS SECTION ADDED HERE ---
                if (comments_open() || get_comments_number()):
                    echo '<div class="mt-12">';
                    comments_template();
                    echo '</div>';
                endif;
                ?>

            <?php endwhile;
            wp_reset_postdata(); 
        else: ?>
            <p><?php esc_html_e('No content found.', 'spin-pulse'); ?></p>
        <?php endif; ?>
    </div>

</main>

<?php get_footer(); ?>