<?php
/**
 * Template part for displaying posts
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('sp-post-article mb-12 pb-12 border-b border-slate-100 last:border-0'); ?>>
	<header class="entry-header mb-6">
		<?php
		if ( is_singular() ) :
			the_title( '<h1 class="entry-title text-4xl md:text-5xl font-black text-slate-900 tracking-tight mb-4">', '</h1>' );
		else :
			the_title( '<h2 class="entry-title text-2xl md:text-3xl font-black text-slate-900 mb-3 leading-tight"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark" class="hover:text-[#00d67d] transition-colors">', '</a></h2>' );
		endif;

		if ( 'post' === get_post_type() ) :
			?>
			<div class="entry-meta flex flex-wrap items-center gap-3 text-sm text-slate-500 font-medium">
				<?php
                // THEMEFOREST FIX: Defensive programming checks
                if ( function_exists( 'spin_pulse_posted_on' ) ) {
				    spin_pulse_posted_on();
                }
                if ( function_exists( 'spin_pulse_posted_by' ) ) {
				    spin_pulse_posted_by();
                }
				?>
			</div><?php endif; ?>
	</header><?php 
    if ( function_exists( 'spin_pulse_post_thumbnail' ) ) {
        spin_pulse_post_thumbnail(); 
    }
    ?>

	<div class="entry-content prose prose-slate prose-lg max-w-none">
		<?php
		the_content(
			sprintf(
				wp_kses(
					/* translators: %s: Name of current post. Only visible to screen readers */
					__( 'Continue reading<span class="screen-reader-text"> "%s"</span>', 'spin-pulse' ),
					array(
						'span' => array(
							'class' => array(), // Allowed class attribute for screen-reader text
						),
					)
				),
				wp_kses_post( get_the_title() )
			)
		);

		wp_link_pages(
			array(
				'before' => '<div class="page-links mt-8 font-medium text-slate-700">' . esc_html__( 'Pages:', 'spin-pulse' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><footer class="entry-footer pt-6 mt-8 flex flex-wrap gap-2 text-sm text-slate-500">
		<?php 
        if ( function_exists( 'spin_pulse_entry_footer' ) ) {
            spin_pulse_entry_footer(); 
        }
        ?>
	</footer></article>