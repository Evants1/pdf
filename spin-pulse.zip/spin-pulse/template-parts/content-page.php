<?php
/**
 * Template part for displaying page content in page.php
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('sp-single-article'); ?>>
	<header class="entry-header mb-8">
		<?php the_title( '<h1 class="entry-title text-3xl md:text-4xl font-black text-slate-900 tracking-tight mb-4">', '</h1>' ); ?>
	</header><?php 
    // THEMEFOREST FIX: Defensive programming check
    if ( function_exists( 'spin_pulse_post_thumbnail' ) ) {
        spin_pulse_post_thumbnail(); 
    }
    ?>

	<div class="entry-content prose prose-slate prose-lg max-w-none">
		<?php
		the_content();

		wp_link_pages(
			array(
				'before' => '<div class="page-links mt-8 font-medium text-slate-700">' . esc_html__( 'Pages:', 'spin-pulse' ),
				'after'  => '</div>',
			)
		);
		?>
	</div><?php if ( get_edit_post_link() ) : ?>
		<footer class="entry-footer mt-12 pt-6 border-t border-slate-200">
			<?php
			edit_post_link(
				sprintf(
					wp_kses(
						/* translators: %s: Name of current post. Only visible to screen readers */
						__( 'Edit <span class="screen-reader-text">%s</span>', 'spin-pulse' ),
						array(
							'span' => array(
								'class' => array(),
							),
						)
					),
					wp_kses_post( get_the_title() )
				),
				// THEMEFOREST FIX: Styled the admin edit button so it looks professional on the frontend
				'<span class="edit-link inline-block bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-4 py-2 rounded-lg text-sm transition-colors">',
				'</span>'
			);
			?>
		</footer><?php endif; ?>
</article>