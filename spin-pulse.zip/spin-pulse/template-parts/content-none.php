<?php
/**
 * Template part for displaying a message that posts cannot be found
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

?>

<section class="sp-no-results bg-slate-50 p-10 text-center rounded-xl border border-slate-200 my-12 max-w-[1200px] mx-auto">
	<header class="page-header mb-6">
        <svg class="w-16 h-16 mx-auto text-slate-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
		<h1 class="text-3xl md:text-4xl font-black text-slate-800 tracking-tight"><?php esc_html_e( 'Nothing Found', 'spin-pulse' ); ?></h1>
	</header><div class="page-content text-lg text-slate-600 max-w-2xl mx-auto flex flex-col items-center">
		<?php
		if ( is_home() && current_user_can( 'publish_posts' ) ) :

			printf(
				'<p>' . wp_kses(
					/* translators: 1: link to WP admin new post page. */
					__( 'Ready to publish your first post? <a href="%1$s" class="text-[#00d67d] hover:underline font-bold">Get started here</a>.', 'spin-pulse' ),
					array(
						'a' => array(
							'href'  => array(),
                            'class' => array(), // THEMEFOREST FIX: Allow the class attribute so Tailwind styles the link
						),
					)
				) . '</p>',
				esc_url( admin_url( 'post-new.php' ) )
			);

		elseif ( is_search() ) :
			?>

			<p class="mb-8"><?php esc_html_e( 'Sorry, but nothing matched your search terms. Please try again with some different keywords.', 'spin-pulse' ); ?></p>
			
            <div class="w-full max-w-md">
                <?php get_search_form(); ?>
            </div>

		<?php else : ?>

			<p class="mb-8"><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'spin-pulse' ); ?></p>
			
            <div class="w-full max-w-md">
                <?php get_search_form(); ?>
            </div>

		<?php endif; ?>
	</div></section>