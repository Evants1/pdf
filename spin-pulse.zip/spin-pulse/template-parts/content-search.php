<?php
/**
 * Template part for displaying results in search pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('sp-search-result-item bg-white border border-slate-200 rounded-2xl p-6 md:p-8 mb-8 shadow-sm transition-shadow hover:shadow-md'); ?>>
	<header class="entry-header mb-4">
		<?php the_title( sprintf( '<h2 class="entry-title text-2xl md:text-3xl font-black tracking-tight text-slate-900 mb-3"><a href="%s" rel="bookmark" class="hover:text-[#00d67d] transition-colors">', esc_url( get_permalink() ) ), '</a></h2>' ); ?>

		<?php if ( 'post' === get_post_type() ) : ?>
		<div class="entry-meta flex flex-wrap items-center gap-3 text-sm text-slate-500 font-medium">
			<?php
            // THEMEFOREST FIX: Defensive programming checks added
            if ( function_exists( 'spin_pulse_posted_on' ) ) {
			    spin_pulse_posted_on();
            }
            if ( function_exists( 'spin_pulse_posted_by' ) ) {
			    spin_pulse_posted_by();
            }
			?>
		</div><?php endif; ?>
	</header><?php 
    if ( function_exists( 'spin_pulse_post_thumbnail' ) ) {
        spin_pulse_post_thumbnail(); 
    }
    ?>

	<div class="entry-summary text-slate-600 text-lg leading-relaxed mb-6">
		<?php the_excerpt(); ?>
	</div><footer class="entry-footer pt-5 border-t border-slate-100 flex flex-wrap gap-2 text-sm text-slate-500">
		<?php 
        if ( function_exists( 'spin_pulse_entry_footer' ) ) {
            spin_pulse_entry_footer(); 
        }
        ?>
	</footer></article>