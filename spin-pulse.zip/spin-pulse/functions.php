<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if (!defined('_S_VERSION')) {
    define('_S_VERSION', filemtime(get_template_directory() . '/style.css') ?: '1.0.0');
}

/**
 * 1. THEME SETUP
 */
function spin_pulse_setup()
{
    load_theme_textdomain('spin-pulse', get_template_directory() . '/languages');
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'menu-1' => esc_html__('Primary Menu', 'spin-pulse'),
        'footer-menu' => esc_html__('Footer Menu', 'spin-pulse'),
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    add_theme_support('custom-logo', array('height' => 250, 'width' => 250, 'flex-width' => true, 'flex-height' => true));
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'spin_pulse_setup');

/**
 * 2. ASSETS ENQUEUE
 */
function spin_pulse_enqueue_assets()
{
    wp_enqueue_style('spin-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    wp_enqueue_style('spin-pulse-style', get_stylesheet_uri(), array(), _S_VERSION);

    if (file_exists(get_template_directory() . '/js/navigation.js')) {
        wp_enqueue_script('spin-pulse-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_assets');

/**
 * 3. CUSTOM WALKER (Badges & Colors)
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu
{
    // 1. Dropdown Wrapper (The Ul)
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
        $indent = str_repeat("\t", $depth);
        // Added: shadow-2xl, border-white/5 for a glass-morphism feel, and refined padding
        $output .= "\n$indent<ul class=\"sub-menu absolute left-0 top-[calc(100%-2px)] hidden group-hover:block w-60 border-t-2 border-purple-500 shadow-2xl py-3 z-50 rounded-b-xl animate-slide-down\" style=\"background-color: {$sub_bg};\">\n";
    }

    // 2. Individual Items
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $classes = empty($item->classes) ? array() : (array) $item->classes;

        // Check if item has children
        $has_children = in_array('menu-item-has-children', $classes);

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $output .= '<li class="' . esc_attr($class_names) . ' relative group">';

        $title = apply_filters('the_title', $item->title, $item->ID);

        // Badge Logic
        $badges = ['{New}' => 'bg-emerald-500', '{Top}' => 'bg-rose-500', '{Best}' => 'bg-amber-500'];
        foreach ($badges as $tag => $bg_class) {
            if (strpos($title, $tag) !== false) {
                $clean_tag = str_replace(['{', '}'], '', $tag);
                $badge_html = '<span class="absolute -top-1 left-4 px-1.5 py-0.5 rounded text-[9px] font-black uppercase ' . $bg_class . ' text-white shadow-sm z-10">' . $clean_tag . '</span>';
                $title = str_replace($tag, '', $title) . $badge_html;
            }
        }

        // Dropdown Arrow (Only for top-level items with children)
        $arrow = ($depth === 0 && $has_children) ? '<svg class="w-4 h-4 ml-1.5 opacity-60 group-hover:rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>' : '';

        $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
        $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
        $attributes = !empty($item->url) ? ' href="' . esc_url($item->url) . '"' : '';

        if ($depth > 0) {
            // Sub-menu links: Added hover translate effect
            $link_style = "color: {$sub_text};";
            $link_class = 'block px-6 py-2.5 text-[13px] font-medium hover:bg-white/5 hover:pl-7 transition-all duration-200 sub-menu-link';
        } else {
            // Main-menu links
            $link_style = "color: {$h_text};";
            $link_class = 'flex items-center font-bold px-4 py-5 transition-colors main-menu-link';
        }

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . ' class="' . $link_class . '" style="' . $link_style . '">';
        $item_output .= $args->link_before . $title . $arrow . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * 4. DYNAMIC CUSTOMIZER CSS
 */
function spin_pulse_dynamic_css()
{
    // Keep these for sub-menus and footer
    $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
    $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
    $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
    $sub_hover = get_theme_mod('spin_pulse_submenu_hover_color', '#a855f7');
    $f_bg = get_theme_mod('spin_pulse_footer_bg_color', '#0B0F1A');
    $f_text = get_theme_mod('spin_pulse_footer_text_color', '#ffffff');

    ?>
    <style type="text/css">
        /* Removed #masthead background-color to allow Tailwind classes to work */
        .main-menu-link,
        .site-title a {
            color:
                <?php echo esc_attr($h_text); ?>
                !important;
        }

        .sub-menu {
            background-color:
                <?php echo esc_attr($sub_bg); ?>
                !important;
        }

        .sub-menu-link {
            color:
                <?php echo esc_attr($sub_text); ?>
                !important;
        }

        .sub-menu-link:hover {
            color:
                <?php echo esc_attr($sub_hover); ?>
                !important;
        }

        #colophon.site-footer {
            background-color:
                <?php echo esc_attr($f_bg); ?>
                !important;
            color:
                <?php echo esc_attr($f_text); ?>
                !important;
        }

        #masthead button svg {
            color:
                <?php echo esc_attr($h_text); ?>
            ;
        }
    </style>
    <?php
}
add_action('wp_head', 'spin_pulse_dynamic_css', 100);

/**
 * 5. TAILWIND ADMIN OPTIONS PAGE
 */
add_action('admin_menu', 'spin_pulse_register_options_menu');
function spin_pulse_register_options_menu()
{
    add_menu_page('Spin Pulse', 'Spin Pulse', 'manage_options', 'spin-pulse-options', 'spin_pulse_hero_page_html', 'dashicons-admin-appearance', 59);
}

function spin_pulse_enqueue_options_scripts($hook)
{
    if ('toplevel_page_spin-pulse-options' !== $hook)
        return;
    wp_enqueue_script('tailwind-cdn', 'https://cdn.tailwindcss.com', array(), null, false);
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_add_inline_script('wp-color-picker', 'jQuery(document).ready(function($){ $(".spin-pulse-color-picker").wpColorPicker(); });');
}
add_action('admin_enqueue_scripts', 'spin_pulse_enqueue_options_scripts');


function spin_pulse_admin_media_scripts($hook) {
    if ('toplevel_page_spin-pulse-options' !== $hook) {
        return;
    }

    // Enqueue media scripts
    wp_enqueue_media();

    // Enqueue your custom script
    wp_enqueue_script(
        'spin-pulse-admin-media',
        get_template_directory_uri() . '/js/admin-media.js',
        array('jquery'), // Dependencies
        '1.0',
        true // Load in footer
    );
}
add_action('admin_enqueue_scripts', 'spin_pulse_admin_media_scripts');


function spin_pulse_hex_to_rgba($color, $opacity = 1.0) {
    $color = ltrim($color, '#');
    if (strlen($color) == 3) {
        $r = hexdec(str_repeat(substr($color, 0, 1), 2));
        $g = hexdec(str_repeat(substr($color, 1, 1), 2));
        $b = hexdec(str_repeat(substr($color, 2, 1), 2));
    } else {
        $r = hexdec(substr($color, 0, 2));
        $g = hexdec(substr($color, 2, 2));
        $b = hexdec(substr($color, 4, 2));
    }
    return 'rgba(' . $r . ',' . $g . ',' . $b . ',' . $opacity . ')';
}

function spin_pulse_hero_page_html()
{
    if (!current_user_can('manage_options'))
        return;
    ?>
    <div class="wrap mt-8 pr-8">
        <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-8 max-w-7xl">
            <header class="mb-10 border-b border-slate-100 pb-6">
                <h1 class="text-3xl font-black text-slate-900 mb-2">Spin Pulse Theme Settings</h1>
                <p class="text-slate-500 text-lg">Manage your modern homepage hero and global styles.</p>
            </header>

            <form action="options.php" method="post" class="space-y-12">
                <?php
                settings_fields('spin_pulse_hero_group');
                global $wp_settings_sections;
                $page = 'hero-settings-page';

                if (isset($wp_settings_sections[$page])) {
                    foreach ((array) $wp_settings_sections[$page] as $section) {
                        $is_card = strpos($section['id'], 'card') !== false;
                        echo '<section class="' . ($is_card ? 'bg-slate-50 p-6 rounded-xl border border-slate-100' : '') . ' mb-8">';
                        if ($section['title']) {
                            echo '<h2 class="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                                  <span class="w-1.5 h-6 bg-indigo-600 rounded-full"></span>' . esc_html($section['title']) . '</h2>';
                        }
                        $grid_class = $is_card ? 'space-y-4' : 'grid grid-cols-1 md:grid-cols-2 gap-8';
                        if ($section['id'] === 'hero_main_section')
                            $grid_class = 'space-y-6 max-w-3xl';

                        echo '<div class="' . ($is_card ? '' : $grid_class) . '">';
                        do_settings_fields($page, $section['id']);
                        echo '</div></section>';
                    }
                }
                submit_button('Save Theme Settings', 'primary', 'submit', true, array('class' => 'bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-3 rounded-lg font-bold border-none shadow-lg transition-all cursor-pointer'));
                ?>
            </form>
        </div>
    </div>
    <?php
}

/**
 * 6. FIELD CALLBACKS (Tailwind Style)
 */
function spin_pulse_text_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : '';
    echo '<div class="flex flex-col gap-1.5">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" 
          class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-sm" />';
    if (!empty($args['desc']))
        echo '<p class="text-xs text-slate-400 italic">' . esc_html($args['desc']) . '</p>';
    echo '</div>';
}

function spin_pulse_textarea_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_textarea($options[$args['id']]) : '';
    echo '<div class="flex flex-col gap-1.5">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<textarea id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" rows="4" 
          class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm">' . $value . '</textarea>';
    echo '</div>';
}

function spin_pulse_color_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : $args['default'];
    echo '<div class="flex flex-col gap-2 p-4 bg-white border border-slate-200 rounded-xl">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" class="spin-pulse-color-picker" data-default-color="' . esc_attr($args['default']) . '" />';
    echo '</div>';
}

function spin_pulse_media_field_callback($args) {
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : '';
    ?>
    <div class="flex flex-col gap-1.5">
        <label class="text-sm font-bold text-slate-700"><?php echo esc_html($args['label_name']); ?></label>
        <div class="flex items-center gap-2">
            <input type="text" 
                   id="<?php echo esc_attr($args['id']); ?>" 
                   name="<?php echo esc_attr($args['group']); ?>[<?php echo esc_attr($args['id']); ?>]" 
                   value="<?php echo $value; ?>" 
                   class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-sm" 
                   placeholder="https://example.com/image.jpg" />
            <button type="button" 
                    class="upload-image-button bg-indigo-100 text-indigo-700 px-4 py-2.5 rounded-lg hover:bg-indigo-200 transition-all font-medium text-sm border border-indigo-300"
                    data-target="<?php echo esc_attr($args['id']); ?>">
                Upload
            </button>
        </div>
        <?php if (!empty($args['desc'])): ?>
            <p class="text-xs text-slate-400 italic"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Number field (for opacity)
 */
function spin_pulse_number_field_callback($args) {
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? floatval($options[$args['id']]) : $args['default'];
    ?>
    <div class="flex flex-col gap-1.5">
        <label class="text-sm font-bold text-slate-700"><?php echo esc_html($args['label_name']); ?></label>
        <input type="number" 
               id="<?php echo esc_attr($args['id']); ?>" 
               name="<?php echo esc_attr($args['group']); ?>[<?php echo esc_attr($args['id']); ?>]" 
               value="<?php echo $value; ?>" 
               step="<?php echo esc_attr($args['step']); ?>" 
               min="<?php echo esc_attr($args['min']); ?>" 
               max="<?php echo esc_attr($args['max']); ?>" 
               class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-sm" />
        <?php if (!empty($args['desc'])): ?>
            <p class="text-xs text-slate-400 italic"><?php echo esc_html($args['desc']); ?></p>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * 7. REGISTER SETTINGS
 */
add_action('admin_init', 'spin_pulse_register_settings');
function spin_pulse_register_settings()
{
    register_setting('spin_pulse_hero_group', 'spin_pulse_hero_settings', 'spin_pulse_sanitize_hero_settings');

    add_settings_section('hero_main_section', 'Hero Content & Brand Colors', '__return_empty_string', 'hero-settings-page');

    // Add Background Image & Overlay settings
    add_settings_field(
        'hero_bg_image',
        '',
        'spin_pulse_media_field_callback',
        'hero-settings-page',
        'hero_main_section',
        [
            'id' => 'hero_bg_image',
            'group' => 'spin_pulse_hero_settings',
            'label_name' => 'Background Image',
            'desc' => 'Upload or select an image. Leave empty to use the gradient.'
        ]
    );

    add_settings_field(
        'hero_bg_overlay_color',
        '',
        'spin_pulse_color_field_callback',
        'hero-settings-page',
        'hero_main_section',
        [
            'id' => 'hero_bg_overlay_color',
            'group' => 'spin_pulse_hero_settings',
            'label_name' => 'Overlay Color',
            'default' => '#000000'
        ]
    );

    add_settings_field(
        'hero_bg_overlay_opacity',
        '',
        'spin_pulse_number_field_callback',
        'hero-settings-page',
        'hero_main_section',
        [
            'id' => 'hero_bg_overlay_opacity',
            'group' => 'spin_pulse_hero_settings',
            'label_name' => 'Overlay Opacity',
            'desc' => 'Value between 0 (transparent) and 1 (solid), e.g. 0.5',
            'default' => '0.5',
            'min' => 0,
            'max' => 1,
            'step' => 0.1
        ]
    );

    add_settings_field(
        'hero_heading',
        '',
        'spin_pulse_text_field_callback',
        'hero-settings-page',
        'hero_main_section',
        ['id' => 'hero_heading', 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Main Heading']
    );
    add_settings_field(
        'hero_description',
        '',
        'spin_pulse_textarea_field_callback',
        'hero-settings-page',
        'hero_main_section',
        ['id' => 'hero_description', 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Hero Description']
    );

    $hero_colors = [
        'hero_bg_start' => ['label' => 'Background Start', 'default' => '#1e293b'],
        'hero_bg_end' => ['label' => 'Background End', 'default' => '#0B0F1A'],
        'hero_text' => ['label' => 'Text Color', 'default' => '#FFFFFF'],
    ];

    foreach ($hero_colors as $id => $data) {
        add_settings_field(
            $id,
            '',
            'spin_pulse_color_field_callback',
            'hero-settings-page',
            'hero_main_section',
            ['id' => $id, 'group' => 'spin_pulse_hero_settings', 'label_name' => $data['label'], 'default' => $data['default']]
        );
    }

    for ($i = 1; $i <= 4; $i++) {
        $sid = "hero_card_{$i}_section";
        add_settings_section($sid, "Feature Card $i", '__return_empty_string', 'hero-settings-page');

        // Badge Text
        add_settings_field(
            "card{$i}_badge",
            '',
            'spin_pulse_text_field_callback',
            'hero-settings-page',
            $sid,
            ['id' => "card{$i}_badge", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Badge Text (Hot, New)']
        );

        // NEW: Badge Background Color
        add_settings_field(
            "card{$i}_badge_bg",
            '',
            'spin_pulse_color_field_callback',
            'hero-settings-page',
            $sid,
            ['id' => "card{$i}_badge_bg", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Badge Color', 'default' => '#7c3aed']
        );

        add_settings_field("card{$i}_title", '', 'spin_pulse_text_field_callback', 'hero-settings-page', $sid, ['id' => "card{$i}_title", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Card Title']);
        add_settings_field("card{$i}_link", '', 'spin_pulse_text_field_callback', 'hero-settings-page', $sid, ['id' => "card{$i}_link", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Link URL']);
    }

}

function spin_pulse_sanitize_hero_settings($input) {
    $sanitized = [];
    foreach ((array)$input as $key => $value) {
        
        // 1. Check for Image URL specifically FIRST
        if ($key === 'hero_bg_image') {
            $sanitized[$key] = esc_url_raw($value);
        }
        // 2. Then check for Opacity (float)
        elseif ($key === 'hero_bg_overlay_opacity') {
            $sanitized[$key] = min(1, max(0, floatval($value)));
        }
        // 3. Then check for Links
        elseif (strpos($key, 'link') !== false) {
            $sanitized[$key] = esc_url_raw($value);
        }
        // 4. Finally, check for Colors (Hex)
        // We added a check to ensure we don't accidentally sanitize the image again if logic changes
        elseif (strpos($key, 'color') !== false || strpos($key, 'bg') !== false) {
            $sanitized[$key] = sanitize_hex_color($value);
        } 
        // 5. Default text sanitization
        else {
            $sanitized[$key] = sanitize_text_field($value);
        }
    }
    return $sanitized;
}

function spin_pulse_enqueue_scripts()
{
    // CSS
    wp_enqueue_style('spin-pulse-main', get_template_directory_uri() . '/style.css', array(), '1.0.0');

    // JS - Ensure the path matches your folder structure exactly
    wp_enqueue_script('spin-pulse-compare', get_template_directory_uri() . '/js/casino-compare.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_scripts');


function spin_pulse_enqueue_faq_assets()
{
    // Enqueue CSS (adjust path if you put it in style.css instead)
    wp_enqueue_style('spin-pulse-faq-styles', get_template_directory_uri() . '/style.css', array(), '1.0.0');

    // Enqueue JS (loads in footer for better performance)
    wp_enqueue_script('spin-pulse-faq-toggle', get_template_directory_uri() . '/js/faq-toggle.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_faq_assets');


function sp_add_back_to_top_button()
{
    // Unique ID and Class prefixed with sp-
    echo '<button id="sp-back-to-top" class="sp-scroll-button" title="Go to top">↑</button>';
}
add_action('wp_footer', 'sp_add_back_to_top_button');


/**
 * Enqueue Spin Pulse Table Expansion Script
 */
function sp_enqueue_table_scripts() {
    // Determine the path relative to your theme directory
    // This assumes your JS folder is inside your active theme folder
    wp_enqueue_script(
        'sp-table-expand', 
        get_template_directory_uri() . '/js/sp-table-expand.js', 
        array(), // Dependencies (none required for vanilla JS)
        '1.0.0', 
        true // Load in footer for better performance
    );
}
add_action('wp_enqueue_scripts', 'sp_enqueue_table_scripts');



/**
 * Enqueue Spin Pulse scripts.
 */
function sp_theme_scripts()
{
    // This loads the JS file you just created
    wp_enqueue_script(
        'sp-custom-js',
        get_template_directory_uri() . '/js/sp-scripts.js',
        array(),
        '1.0.0',
        true // This loads it in the footer for better performance
    );
}
add_action('wp_enqueue_scripts', 'sp_theme_scripts');


function spin_pulse_admin_style_fix()
{
    echo '<style>#wpbody { background: #f0f2f5; }</style>';
}
add_action('admin_head', 'spin_pulse_admin_style_fix');


/* ==========================================================================
   SpinPulse: Limit Default Pages Widget
   ========================================================================== */

function sp_limit_widget_pages( $args ) {
    // Change '5' to whatever limit you want for your sidebar
    $args['number'] = 5; 
    
    // Optional: Sort them by date created instead of alphabetical
    // $args['sort_column'] = 'post_date'; 
    // $args['sort_order'] = 'DESC';

    return $args;
}
add_filter( 'widget_pages_args', 'sp_limit_widget_pages' );



/**
 * Register widget areas.
 */
function spin_pulse_widgets_init() {
    // Left Sidebar
    register_sidebar(
        array(
            'name'          => esc_html__( 'Left Sidebar', 'spin-pulse' ),
            'id'            => 'sidebar-left',
            'description'   => esc_html__( 'Add widgets here to appear in your left sidebar.', 'spin-pulse' ),
            'before_widget' => '<section id="%1$s" class="widget sp-left-sidebar-widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title sp-left-sidebar-title">',
            'after_title'   => '</h2>',
        )
    );

    // Right Sidebar
    register_sidebar(
        array(
            'name'          => esc_html__( 'Right Sidebar', 'spin-pulse' ),
            'id'            => 'sidebar-right',
            'description'   => esc_html__( 'Add widgets here to appear in your right sidebar.', 'spin-pulse' ),
            'before_widget' => '<section id="%1$s" class="widget sp-right-sidebar-widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title sp-right-sidebar-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action( 'widgets_init', 'spin_pulse_widgets_init' );





/* ==========================================================================
   SpinPulse: User Profile Additions (Social Media & Custom Avatar)
   ========================================================================== */

// 1. Add Social Media Fields to "Contact Info" section
function sp_custom_user_social_fields( $contactmethods ) {
    $contactmethods['twitter']   = esc_html__( 'X (Twitter) Profile URL', 'spin-pulse' );
    $contactmethods['facebook']  = esc_html__( 'Facebook Profile URL', 'spin-pulse' );
    $contactmethods['instagram'] = esc_html__( 'Instagram Profile URL', 'spin-pulse' );
    $contactmethods['linkedin']  = esc_html__( 'LinkedIn Profile URL', 'spin-pulse' );
    $contactmethods['youtube']   = esc_html__( 'YouTube Channel URL', 'spin-pulse' );
    
    return $contactmethods;
}
add_filter( 'user_contactmethods', 'sp_custom_user_social_fields' );


// 2. Display the Custom Avatar Upload Section
function sp_custom_user_avatar_field( $user ) {
    // Only allow users with permission to see this
    if ( ! current_user_can( 'edit_user', $user->ID ) ) {
        return;
    }

    $avatar_url = get_user_meta( $user->ID, 'sp_custom_avatar', true );
    ?>
    <h3><?php esc_html_e( 'Custom Avatar', 'spin-pulse' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="sp_custom_avatar"><?php esc_html_e( 'Profile Picture', 'spin-pulse' ); ?></label></th>
            <td>
                <div class="sp-avatar-preview" style="margin-bottom: 15px;">
                    <img src="<?php echo esc_url( $avatar_url ? $avatar_url : get_avatar_url( $user->ID ) ); ?>" 
                         style="width: 96px; height: 96px; border-radius: 50%; object-fit: cover; border: 2px solid #e0ddd5;" 
                         id="sp-avatar-image-preview" alt="Avatar Preview" />
                </div>
                
                <input type="hidden" name="sp_custom_avatar" id="sp_custom_avatar" value="<?php echo esc_attr( $avatar_url ); ?>" />
                
                <button type="button" class="button button-secondary" id="sp-upload-avatar-btn">
                    <?php esc_html_e( 'Upload / Select Image', 'spin-pulse' ); ?>
                </button>
                <button type="button" class="button button-link-delete" id="sp-remove-avatar-btn" style="<?php echo empty( $avatar_url ) ? 'display:none;' : ''; ?>">
                    <?php esc_html_e( 'Remove Custom Avatar', 'spin-pulse' ); ?>
                </button>
                
                <p class="description"><?php esc_html_e( 'Upload a custom image to override the default Gravatar. Recommended size: 250x250 pixels.', 'spin-pulse' ); ?></p>
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'sp_custom_user_avatar_field' );
add_action( 'edit_user_profile', 'sp_custom_user_avatar_field' );


// 3. Save the Custom Avatar Field
function sp_save_custom_user_avatar_field( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) {
        return false;
    }

    if ( isset( $_POST['sp_custom_avatar'] ) ) {
        update_user_meta( $user_id, 'sp_custom_avatar', esc_url_raw( $_POST['sp_custom_avatar'] ) );
    }
}
add_action( 'personal_options_update', 'sp_save_custom_user_avatar_field' );
add_action( 'edit_user_profile_update', 'sp_save_custom_user_avatar_field' );


// 4. Force WordPress to use our Custom Avatar across the site
function sp_override_get_avatar_url( $args, $id_or_email ) {
    $user_id = 0;

    // Determine the User ID based on what WordPress passes to the function
    if ( is_numeric( $id_or_email ) ) {
        $user_id = (int) $id_or_email;
    } elseif ( is_string( $id_or_email ) && ( $user = get_user_by( 'email', $id_or_email ) ) ) {
        $user_id = $user->ID;
    } elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) {
        $user_id = (int) $id_or_email->user_id;
    }

    // If we found a user, check for our custom avatar
    if ( $user_id ) {
        $custom_avatar = get_user_meta( $user_id, 'sp_custom_avatar', true );
        if ( $custom_avatar ) {
            $args['url'] = $custom_avatar;
        }
    }

    return $args;
}
add_filter( 'get_avatar_data', 'sp_override_get_avatar_url', 10, 2 );


// 5. Load JavaScript to handle the Media Uploader inside the Profile screen
function sp_enqueue_avatar_uploader_script( $hook ) {
    // Only load this script on the profile edit pages
    if ( 'profile.php' !== $hook && 'user-edit.php' !== $hook ) {
        return;
    }

    wp_enqueue_media(); // Load WP Media Library

    wp_add_inline_script( 'media-upload', '
        jQuery(document).ready(function($){
            var mediaUploader;
            
            // Handle Upload Button
            $("#sp-upload-avatar-btn").on("click", function(e){
                e.preventDefault();
                if(mediaUploader){ 
                    mediaUploader.open(); 
                    return; 
                }
                
                mediaUploader = wp.media.frames.file_frame = wp.media({
                    title: "Choose a Profile Picture",
                    button: { text: "Use this image" },
                    multiple: false
                });
                
                mediaUploader.on("select", function(){
                    var attachment = mediaUploader.state().get("selection").first().toJSON();
                    $("#sp_custom_avatar").val(attachment.url);
                    $("#sp-avatar-image-preview").attr("src", attachment.url);
                    $("#sp-remove-avatar-btn").show();
                });
                
                mediaUploader.open();
            });
            
            // Handle Remove Button
            $("#sp-remove-avatar-btn").on("click", function(e){
                e.preventDefault();
                $("#sp_custom_avatar").val("");
                // Hide the preview image or reset to a blank placeholder if desired
                $("#sp-avatar-image-preview").attr("src", ""); 
                $(this).hide();
            });
        });
    ' );
}
add_action( 'admin_enqueue_scripts', 'sp_enqueue_avatar_uploader_script' );


/* ==========================================================================
   SpinPulse: Track Post Views Automatically
   ========================================================================== */
function sp_set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count == ''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}

// Hook it into the header so it counts every time the page loads
function sp_track_post_views($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) {
        global $post;
        $post_id = $post->ID;    
    }
    sp_set_post_views($post_id);
}
add_action( 'wp_head', 'sp_track_post_views');




// ==========================================================================
// SpinPulse: Affiliate Custom Post Types & Dynamic Slugs (Permalinks Page)
// ==========================================================================

function spin_pulse_register_affiliate_cpts() {
    
    // Custom Spade Icon
    $spade_icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48cGF0aCBkPSJNMjU2IDBDMTYwLjUgMTUwLjcgOTYuMSAyMDMuNiA5Ni4xIDI4NS41YzAgNTkuOSA0NS42IDEwOC41IDEwMS45IDEwOC41IDI2LjUgMCA1MC43LTEwLjYgNjgtMjguMyA0LjggMTkuNCAxMS40IDQ5IDE4LjEgNzQuM2g1MS44Yy02LjctMjUuMy0xMy4zLTU0LjktMTguMS03NC4zIDE3LjMgMTcuNyA0MS41IDI4LjMgNjggMjguMyA1Ni4zIDAgMTAxLjktNDguNiAxMDEuOS0xMDguNUM0MTUuOSAyMDMuNiAzNTEuNSAxNTAuNyAyNTYgMHoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPg==';

    // --- GET DYNAMIC SLUGS ---
    $review_slug = get_option( 'sp_casino_review_slug', 'casino-reviews' );
    $review_slug = empty($review_slug) ? 'casino-reviews' : $review_slug;

    $game_slug = get_option( 'sp_casino_game_slug', 'casino-games' );
    $game_slug = empty($game_slug) ? 'casino-games' : $game_slug;

    $bonus_slug = get_option( 'sp_casino_bonus_slug', 'casino-bonuses' );
    $bonus_slug = empty($bonus_slug) ? 'casino-bonuses' : $bonus_slug;

    // 1. Register "Casino Reviews"
    $review_labels = array(
        'name'                  => _x( 'Casino Reviews', 'Post type general name', 'spin-pulse' ),
        'singular_name'         => _x( 'Casino Review', 'Post type singular name', 'spin-pulse' ),
        'menu_name'             => _x( 'Casino Reviews', 'Admin Menu text', 'spin-pulse' ),
        'add_new'               => __( 'Add New Review', 'spin-pulse' ),
        'add_new_item'          => __( 'Add New Casino Review', 'spin-pulse' ),
        'edit_item'             => __( 'Edit Review', 'spin-pulse' ),
        'all_items'             => __( 'All Reviews', 'spin-pulse' ),
    );
    register_post_type( 'casino_review', array(
        'labels'              => $review_labels,
        'public'              => true,
        'has_archive'         => true,
        'menu_position'       => 5, 
        'menu_icon'           => $spade_icon,
        'show_in_rest'        => true, 
        'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions' ),
        'rewrite'             => array( 'slug' => sanitize_title($review_slug), 'with_front' => false ),
    ));

    // 2. Register "Casino Games"
    $game_labels = array(
        'name'                  => _x( 'Casino Games', 'Post type general name', 'spin-pulse' ),
        'singular_name'         => _x( 'Casino Game', 'Post type singular name', 'spin-pulse' ),
        'menu_name'             => _x( 'Casino Games', 'Admin Menu text', 'spin-pulse' ),
        'add_new'               => __( 'Add New Game', 'spin-pulse' ),
        'add_new_item'          => __( 'Add New Casino Game', 'spin-pulse' ),
        'all_items'             => __( 'All Games', 'spin-pulse' ),
    );
    register_post_type( 'casino_game', array(
        'labels'              => $game_labels,
        'public'              => true,
        'has_archive'         => true,
        'menu_position'       => 6, 
        'menu_icon'           => $spade_icon,
        'show_in_rest'        => true,
        'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'rewrite'             => array( 'slug' => sanitize_title($game_slug), 'with_front' => false ),
    ));

    // 3. Register "Casino Bonuses"
    $bonus_labels = array(
        'name'                  => _x( 'Casino Bonuses', 'Post type general name', 'spin-pulse' ),
        'singular_name'         => _x( 'Casino Bonus', 'Post type singular name', 'spin-pulse' ),
        'menu_name'             => _x( 'Casino Bonuses', 'Admin Menu text', 'spin-pulse' ),
        'add_new'               => __( 'Add New Bonus', 'spin-pulse' ),
        'add_new_item'          => __( 'Add New Casino Bonus', 'spin-pulse' ),
        'all_items'             => __( 'All Bonuses', 'spin-pulse' ),
    );
    register_post_type( 'casino_bonus', array(
        'labels'              => $bonus_labels,
        'public'              => true,
        'has_archive'         => true,
        'menu_position'       => 7, 
        'menu_icon'           => $spade_icon,
        'show_in_rest'        => true,
        'supports'            => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields' ),
        'rewrite'             => array( 'slug' => sanitize_title($bonus_slug), 'with_front' => false ),
    ));

    // 4. Register Custom Taxonomies (Categories specifically for Reviews)
    register_taxonomy('review_category', array('casino_review'), array(
        'hierarchical'      => true,
        'labels'            => array(
            'name'          => _x( 'Review Categories', 'Taxonomy General Name', 'spin-pulse' ),
            'singular_name' => _x( 'Review Category', 'Taxonomy Singular Name', 'spin-pulse' ),
            'menu_name'     => __( 'Categories', 'spin-pulse' ),
        ),
        'show_ui'           => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
        'rewrite'           => array( 'slug' => 'review-category' ),
    ));
}
add_action( 'init', 'spin_pulse_register_affiliate_cpts' );


// ==========================================================================
// Add Dynamic Slug Settings directly to WP Permalinks Page
// ==========================================================================
function sp_add_all_cpt_slug_settings() {
    // Add Fields to Settings > Permalinks ('optional' section)
    add_settings_field( 'sp_casino_review_slug', __( 'Casino Reviews Base', 'spin-pulse' ), 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_review_slug', 'default' => 'casino-reviews') );
    add_settings_field( 'sp_casino_game_slug', __( 'Casino Games Base', 'spin-pulse' ), 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_game_slug', 'default' => 'casino-games') );
    add_settings_field( 'sp_casino_bonus_slug', __( 'Casino Bonuses Base', 'spin-pulse' ), 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_bonus_slug', 'default' => 'casino-bonuses') );
    
    // Save the settings when the Permalinks page is saved
    if ( isset( $_POST['sp_casino_review_slug'] ) ) update_option( 'sp_casino_review_slug', sanitize_title_with_dashes( $_POST['sp_casino_review_slug'] ) );
    if ( isset( $_POST['sp_casino_game_slug'] ) ) update_option( 'sp_casino_game_slug', sanitize_title_with_dashes( $_POST['sp_casino_game_slug'] ) );
    if ( isset( $_POST['sp_casino_bonus_slug'] ) ) update_option( 'sp_casino_bonus_slug', sanitize_title_with_dashes( $_POST['sp_casino_bonus_slug'] ) );
}
add_action( 'admin_init', 'sp_add_all_cpt_slug_settings' );

function sp_slug_input_cb($args) {
    $value = get_option( $args['id'], $args['default'] );
    echo '<input type="text" value="' . esc_attr( $value ) . '" name="' . esc_attr($args['id']) . '" id="' . esc_attr($args['id']) . '" class="regular-text" />';
    echo '<p class="description">Default URL: <code>/' . esc_html($args['default']) . '/</code></p>';
}




// ==========================================================================
// SpinPulse: Casino Review Meta Boxes (Backend Inputs)
// ==========================================================================

function sp_add_casino_review_meta_boxes() {
    add_meta_box( 'sp_casino_review_data', 'Casino Review Details', 'sp_render_casino_review_meta_box', 'casino_review', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'sp_add_casino_review_meta_boxes' );

function sp_render_casino_review_meta_box( $post ) {
    wp_nonce_field( 'sp_save_casino_review_data', 'sp_casino_review_meta_nonce' );

    // Retrieve existing values
    $rating = get_post_meta( $post->ID, 'sp_review_rating', true );
    $bonus = get_post_meta( $post->ID, 'sp_review_bonus', true );
    $link = get_post_meta( $post->ID, 'sp_review_link', true );
    $pros = get_post_meta( $post->ID, 'sp_review_pros', true );
    $cons = get_post_meta( $post->ID, 'sp_review_cons', true );
    ?>
    <style>
        .sp-meta-row { margin-bottom: 20px; }
        .sp-meta-row label { display: block; font-weight: bold; margin-bottom: 5px; color: #1e293b; }
        .sp-meta-row input[type="text"], .sp-meta-row input[type="number"], .sp-meta-row textarea { width: 100%; max-width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 4px; }
        .sp-meta-row textarea { height: 100px; }
        .sp-meta-desc { font-size: 12px; color: #64748b; margin-top: 4px; display: block; }
    </style>
    
    <div class="sp-meta-row">
        <label for="sp_review_rating">Star Rating (Out of 5)</label>
        <input type="number" id="sp_review_rating" name="sp_review_rating" value="<?php echo esc_attr( $rating ); ?>" step="0.1" min="1" max="5" placeholder="e.g. 4.8" />
    </div>

    <div class="sp-meta-row">
        <label for="sp_review_bonus">Main Bonus Offer Highlight</label>
        <input type="text" id="sp_review_bonus" name="sp_review_bonus" value="<?php echo esc_attr( $bonus ); ?>" placeholder="e.g. 100% up to $500 + 200 Free Spins" />
    </div>

    <div class="sp-meta-row">
        <label for="sp_review_link">Affiliate 'Play Now' Link</label>
        <input type="url" id="sp_review_link" name="sp_review_link" value="<?php echo esc_url( $link ); ?>" placeholder="https://..." />
    </div>

    <div class="sp-meta-row" style="display:flex; gap: 20px;">
        <div style="flex:1;">
            <label for="sp_review_pros">Pros (One per line)</label>
            <textarea id="sp_review_pros" name="sp_review_pros" placeholder="Instant payouts&#10;Great live casino&#10;24/7 Support"><?php echo esc_textarea( $pros ); ?></textarea>
            <span class="sp-meta-desc">Hit 'Enter' to create a new bullet point.</span>
        </div>
        <div style="flex:1;">
            <label for="sp_review_cons">Cons (One per line)</label>
            <textarea id="sp_review_cons" name="sp_review_cons" placeholder="High wagering requirements&#10;No phone support"><?php echo esc_textarea( $cons ); ?></textarea>
            <span class="sp-meta-desc">Hit 'Enter' to create a new bullet point.</span>
        </div>
    </div>
    <?php
}

function sp_save_casino_review_meta_box( $post_id ) {
    if ( ! isset( $_POST['sp_casino_review_meta_nonce'] ) || ! wp_verify_nonce( $_POST['sp_casino_review_meta_nonce'], 'sp_save_casino_review_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['sp_review_rating'] ) ) update_post_meta( $post_id, 'sp_review_rating', sanitize_text_field( $_POST['sp_review_rating'] ) );
    if ( isset( $_POST['sp_review_bonus'] ) ) update_post_meta( $post_id, 'sp_review_bonus', sanitize_text_field( $_POST['sp_review_bonus'] ) );
    if ( isset( $_POST['sp_review_link'] ) ) update_post_meta( $post_id, 'sp_review_link', esc_url_raw( $_POST['sp_review_link'] ) );
    if ( isset( $_POST['sp_review_pros'] ) ) update_post_meta( $post_id, 'sp_review_pros', sanitize_textarea_field( $_POST['sp_review_pros'] ) );
    if ( isset( $_POST['sp_review_cons'] ) ) update_post_meta( $post_id, 'sp_review_cons', sanitize_textarea_field( $_POST['sp_review_cons'] ) );
}
add_action( 'save_post_casino_review', 'sp_save_casino_review_meta_box' );



require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';





// ==========================================================================
// SpinPulse: Custom Admin Columns (Logo & Item ID)
// ==========================================================================

// 1. Generic Logo Column Inserter (For Posts, Games, and Bonuses)
function sp_add_generic_admin_logo_column( $columns ) {
    $new_columns = array();
    foreach ( $columns as $key => $title ) {
        if ( $key == 'title' ) {
            $new_columns['sp_logo_column'] = __( 'Logo', 'spin-pulse' );
        }
        $new_columns[$key] = $title;
    }
    return $new_columns;
}

// 2. EXACT Column Layout ONLY for Casino Reviews (Matches your screenshot)
function sp_casino_review_custom_columns( $columns ) {
    $new_columns = array(
        'cb'                       => $columns['cb'], // Checkbox
        'sp_logo_column'           => __( 'Logo', 'spin-pulse' ),
        'title'                    => __( 'Title', 'spin-pulse' ),
        'sp_item_id'               => __( 'Item ID', 'spin-pulse' ), // New Item ID Column
        'author'                   => __( 'Author', 'spin-pulse' ),
        'taxonomy-review_category' => __( 'Categories', 'spin-pulse' ), // Custom Taxonomy
        'comments'                 => $columns['comments'],
        'date'                     => __( 'Date', 'spin-pulse' )
    );
    return $new_columns;
}
add_filter( 'manage_casino_review_posts_columns', 'sp_casino_review_custom_columns' );

// Make the new Item ID column sortable
function sp_casino_review_sortable_columns( $columns ) {
    $columns['sp_item_id'] = 'ID';
    return $columns;
}
add_filter( 'manage_edit-casino_review_sortable_columns', 'sp_casino_review_sortable_columns' );

// 3. Render the content for our Custom Columns (Logo & Item ID)
function sp_render_all_admin_custom_columns( $column_name, $post_id ) {
    // Output the Logo
    if ( 'sp_logo_column' === $column_name ) {
        if ( has_post_thumbnail( $post_id ) ) {
            echo get_the_post_thumbnail( $post_id, 'thumbnail', array( 'class' => 'sp-admin-logo-img' ) );
        } else {
            echo '<div class="sp-admin-logo-placeholder"><span class="dashicons dashicons-format-image"></span></div>';
        }
    }
    // Output the Item ID
    if ( 'sp_item_id' === $column_name ) {
        echo '<strong>' . esc_html( $post_id ) . '</strong>';
    }
}

// Apply the rendering logic to all relevant post types
$sp_target_post_types = array( 'post', 'casino_review', 'casino_game', 'casino_bonus' );

foreach ( $sp_target_post_types as $post_type ) {
    // Attach the renderer to all
    add_action( "manage_{$post_type}_posts_custom_column", 'sp_render_all_admin_custom_columns', 10, 2 );
    
    // Attach the generic logo inserter ONLY to the others (since Review has its own strict layout above)
    if ( $post_type !== 'casino_review' ) {
        add_filter( "manage_{$post_type}_posts_columns", 'sp_add_generic_admin_logo_column' );
    }
}

// 4. Style the Admin Columns for a polished look
function sp_admin_columns_css() {
    echo '<style>
        /* Logo Column Styling */
        th.column-sp_logo_column { width: 90px !important; text-align: center; }
        td.column-sp_logo_column { text-align: center; vertical-align: middle !important; }
        
        .sp-admin-logo-img {
            width: 70px;
            height: 70px;
            object-fit: contain;
            background-color: #ffffff;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 6px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.05);
            display: inline-block;
            vertical-align: middle;
        }
        .sp-admin-logo-placeholder {
            width: 70px;
            height: 70px;
            background-color: #f8fafc;
            border: 1px dashed #cbd5e1;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #94a3b8;
            margin: 0 auto;
        }

        /* Item ID Column Styling */
        th.column-sp_item_id { width: 80px !important; text-align: center; }
        td.column-sp_item_id { text-align: center; vertical-align: middle !important; font-size: 14px; color: #0f172a; }
    </style>';
}
add_action( 'admin_head', 'sp_admin_columns_css' );