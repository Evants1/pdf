<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if ( ! defined( '_S_VERSION' ) ) {
    // Use file modification time for better cache busting (ThemeForest appreciates this)
    define( '_S_VERSION', filemtime( get_template_directory() . '/style.css' ) ?: '1.0.0' );
}

/**
 * Sets up theme defaults and registers support for various WordPress features.
 */
function spin_pulse_setup() {
    // Make theme available for translation
    load_theme_textdomain( 'spin-pulse', get_template_directory() . '/languages' );

    // Add default posts and comments RSS feed links to head
    add_theme_support( 'automatic-feed-links' );

    // Let WordPress manage the document title
    add_theme_support( 'title-tag' );

    // Enable support for Post Thumbnails on posts and pages
    add_theme_support( 'post-thumbnails' );

    // Register Navigation Menus
    register_nav_menus(
        array(
            'menu-1'      => esc_html__( 'Primary Menu', 'spin-pulse' ),
            'footer-menu' => esc_html__( 'Footer Menu', 'spin-pulse' ),
        )
    );

    // Switch default core markup to output valid HTML5
    add_theme_support( 'html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
        'style',
        'script',
        'navigation-widgets',
    ) );

    // Set up the WordPress core custom background feature
    add_theme_support( 'custom-background', apply_filters( 'spin_pulse_custom_background_args', array(
        'default-color' => 'ffffff',
        'default-image' => '',
    ) ) );

    // Add theme support for selective refresh for widgets
    add_theme_support( 'customize-selective-refresh-widgets' );

    // Add support for core custom logo
    add_theme_support( 'custom-logo', array(
        'height'      => 250,
        'width'       => 250,
        'flex-width'  => true,
        'flex-height' => true,
    ) );

    // Add support for responsive embeds
    add_theme_support( 'responsive-embeds' );

    // Add support for editor styles
    add_theme_support( 'editor-styles' );
    add_editor_style( 'style.css' ); // Point to the compiled Tailwind file
}
add_action( 'after_setup_theme', 'spin_pulse_setup' );

/**
 * Set the content width in pixels.
 */
function spin_pulse_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'spin_pulse_content_width', 1200 );
}
add_action( 'after_setup_theme', 'spin_pulse_content_width', 0 );

/**
 * Register widget area.
 */
function spin_pulse_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'spin-pulse' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'spin-pulse' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'spin_pulse_widgets_init' );

/**
 * Enqueue scripts and styles (single unified function)
 */
function spin_pulse_enqueue_assets() {
    // Google Fonts - Inter (professional typography)
    wp_enqueue_style(
        'spin-pulse-fonts',
        'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap',
        array(),
        null
    );

    // Main compiled Tailwind stylesheet (should contain all generated utilities)
    wp_enqueue_style(
        'spin-pulse-style',
        get_stylesheet_uri(),  // Loads /style.css - where Tailwind output should go
        array(),
        _S_VERSION
    );

    // Navigation and Mobile Menu JS (only if the file exists)
    if ( file_exists( get_template_directory() . '/js/navigation.js' ) ) {
        wp_enqueue_script(
            'spin-pulse-navigation',
            get_template_directory_uri() . '/js/navigation.js',
            array(),
            _S_VERSION,
            true
        );
    }

    // Comment reply script on singular pages when needed
    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'spin_pulse_enqueue_assets' );

/**
 * Custom Walker for Badges: {New}, {Top}, {Best} with Improved Accessibility
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu {
    // Start Level: The <ul> that wraps the sub-menu
    function start_lvl( &$output, $depth = 0, $args = null ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"absolute left-0 top-full hidden group-hover:block w-56 bg-white border-t-2 border-casino-blue shadow-menu py-2 z-50 rounded-b-lg animate-slide-down overflow-hidden\">\n";
    }

    // Start Element: The <li> and <a>
    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $has_children = in_array('menu-item-has-children', $classes);
        
        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $output .= '<li class="' . esc_attr( $class_names ) . ' relative group">';

        $title = apply_filters( 'the_title', $item->title, $item->ID );
        
        // Handle Badges {New}, {Top}, {Best} with better positioning
        $badges = [
            '{New}'  => 'bg-badge-green text-green-700',
            '{Top}'  => 'bg-badge-red text-red-700',
            '{Best}' => 'bg-badge-gray text-slate-700',
        ];

        foreach ( $badges as $tag => $color_class ) {
            if ( strpos( $title, $tag ) !== false ) {
                $clean_tag = str_replace( ['{','}'], '', $tag );
                $badge_html = '<span class="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide ' . $color_class . ' shadow-sm">' . $clean_tag . '</span>';
                $title = str_replace( $tag, '', $title ) . $badge_html;
            }
        }

        // Add Chevron if has children with smoother transition
        if ( $has_children && $depth === 0 ) {
            $title .= ' <svg class="w-4 h-4 ml-1 opacity-50 group-hover:rotate-180 group-focus:rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>';
        }

        $attributes = ! empty( $item->url ) ? ' href="' . esc_url( $item->url ) . '"' : '';
        
        $item_output = $args->before;
        $link_class = ( $depth > 0 ) 
            ? 'block px-5 py-3 text-sm text-nav-text hover:bg-slate-50 hover:text-casino-blue focus:bg-slate-50 focus:text-casino-blue transition-colors duration-200' 
            : 'flex items-center text-nav-text font-semibold text-base hover:text-casino-blue focus:text-casino-blue transition-colors duration-200 px-4 py-2 focus:outline-none focus:ring-2 focus:ring-focus-ring rounded';
            
        $item_output .= '<a' . $attributes . ' class="' . $link_class . '">';
        $item_output .= $args->link_before . $title . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
    }
}

/**
 * Helper: Get social media links with icons.
 */
function spin_pulse_get_social_links() {
    $socials = array(
        'facebook'  => array(
            'url'  => get_theme_mod( 'spin_pulse_social_facebook', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>',
            'color' => '#1877f2',
            'hover_color' => '#166fe5',
        ),
        'twitter'   => array(
            'url'  => get_theme_mod( 'spin_pulse_social_twitter', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.657l-5.214-6.81L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>',
            'color' => '#000000',
            'hover_color' => '#333333',
        ),
        'instagram' => array(
            'url'  => get_theme_mod( 'spin_pulse_social_instagram', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-7.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
            'color' => '#e4405f',
            'hover_color' => '#c1354f',
        ),
        'youtube'   => array(
            'url'  => get_theme_mod( 'spin_pulse_social_youtube', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 4-8 4z"/></svg>',
            'color' => '#ff0000',
            'hover_color' => '#cc0000',
        ),
        'linkedin'  => array(
            'url'  => get_theme_mod( 'spin_pulse_social_linkedin', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M4.98 3.5c0 1.381-1.11 2.5-2.48 2.5s-2.48-1.119-2.48-2.5c0-1.38 1.11-2.5 2.48-2.5s2.48 1.12 2.48 2.5zm.02 4.5h-5v16h5v-16zm7.982 0H8.14v16h4.84v-8.61c0-4.67 5.89-5.03 5.89 0v8.61h4.85v-12.91c0-6.8-7.735-6.55-10.745-3.1v.01z"/></svg>',
            'color' => '#0a66c2',
            'hover_color' => '#084d99',
        ),
        'pinterest' => array(
            'url'  => get_theme_mod( 'spin_pulse_social_pinterest', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12 0c-6.627 0-12 5.372-12 12 0 5.084 3.163 9.426 7.627 11.174-.105-.949-.2-2.405.042-3.441.218-.937 1.407-5.965 1.407-5.965s-.359-.719-.359-1.782c0-1.668.967-2.914 2.171-2.914 1.023 0 1.518.769 1.518 1.69 0 1.029-.653 2.567-.99 3.992-.276 1.197.597 2.174 1.774 2.174 2.128 0 3.768-2.245 3.768-5.487 0-2.871-2.063-4.877-5.008-4.877-3.4 0-5.399 2.554-5.399 5.199 0 1.029.394 2.133.892 2.734.091.106.112.141.126.224.048.288.155.946-.034 1.315-.041.073-.154.14-.277.14-1.022 0-1.858-1.047-1.858-2.383 0-3.875 2.805-7.413 8.111-7.413 4.26 0 7.568 3.04 7.568 7.104 0 4.24-2.668 7.646-6.372 7.646-1.243 0-2.41-.646-2.811-1.411l-.766 2.924c-.278 1.07-1.049 2.347-1.562 3.146 1.143.351 2.354.54 3.628.54 6.627 0 12-5.373 12-12 0-6.628-5.373-12-12-12z"/></svg>',
            'color' => '#e60023',
            'hover_color' => '#b3001b',
        ),
        'tiktok'    => array(
            'url'  => get_theme_mod( 'spin_pulse_social_tiktok', '' ),
            'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.79-.68-1.8-1.03-2.84-1.01-.81.02-1.63.3-2.3.85-.99.81-1.5 2.07-1.43 3.33.05 1.03.62 2.03 1.47 2.63.85.61 1.98.79 3.02.61 1.2-.21 2.3-1.05 2.8-2.16.58-1.26.69-2.64.69-3.98 0-2.87.02-5.74-.02-11.48 1.01.22 2.02.5 2.98.9 1.06.43 2.07.86 3.11 1.29V6.93c-1.77-.17-3.38-.75-4.73-1.94-1.26-1.11-1.76-2.7-1.8-4.23-.02-1.15.02-2.3.02-3.46zm0 0"/></svg>',
            'color' => '#000000',
            'hover_color' => '#333333',
        ),
    );

    $output = '';
    foreach ( $socials as $key => $social ) {
        if ( ! empty( $social['url'] ) ) {
            $output .= '<a href="' . esc_url( $social['url'] ) . '" target="_blank" rel="noopener noreferrer" class="text-[' . $social['color'] . '] hover:text-[' . $social['hover_color'] . '] transition-colors" aria-label="' . esc_attr( ucfirst( $key ) ) . '">';
            $output .= $social['icon'];
            $output .= '</a>';
        }
    }

    return $output;
}

/**
 * Output Customizer CSS to the head.
 */
function spin_pulse_customizer_css() {
    ?>
    <style type="text/css">
        #main-header { background-color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_header_bg_color', '#f2f3f6' ) ); ?>; }
        #top-bar { background-color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_bg_color', '#f2f3f6' ) ); ?>; color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_text_color', '#1e293b' ) ); ?>; }
        #top-bar a { color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_text_color', '#1e293b' ) ); ?>; }
        #top-bar a:hover { color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_hover_color', '#0f172a' ) ); ?>; }
        .main-navigation a { color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_menu_link_color', '#334155' ) ); ?>; }
        .main-navigation ul ul { background-color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_submenu_bg_color', '#ffffff' ) ); ?>; }
    </style>
    <?php
}
add_action( 'wp_head', 'spin_pulse_customizer_css' );

/**
 * Force full-width page template as default for pages (if no template selected)
 */
function spin_pulse_default_page_template( $template ) {
    if ( is_page() && ! is_page_template() ) {
        $new_template = locate_template( array( 'page-fullwidth.php' ) );
        if ( '' !== $new_template ) {
            return $new_template;
        }
    }
    return $template;
}
add_filter( 'template_include', 'spin_pulse_default_page_template' );

/**
 * Required files
 */
require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';