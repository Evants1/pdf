<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if ( ! defined( '_S_VERSION' ) ) {
    define( '_S_VERSION', filemtime( get_template_directory() . '/style.css' ) ?: '1.0.0' );
}

/**
 * Sets up theme defaults.
 */
function spin_pulse_setup() {
    load_theme_textdomain( 'spin-pulse', get_template_directory() . '/languages' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    register_nav_menus( array(
        'menu-1'      => esc_html__( 'Primary Menu', 'spin-pulse' ),
        'footer-menu' => esc_html__( 'Footer Menu', 'spin-pulse' ),
    ) );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
    add_theme_support( 'custom-background', apply_filters( 'spin_pulse_custom_background_args', array( 'default-color' => 'ffffff', 'default-image' => '' ) ) );
    add_theme_support( 'customize-selective-refresh-widgets' );
    add_theme_support( 'custom-logo', array( 'height' => 250, 'width' => 250, 'flex-width' => true, 'flex-height' => true ) );
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );
    add_editor_style( 'style.css' );
}
add_action( 'after_setup_theme', 'spin_pulse_setup' );

function spin_pulse_content_width() {
    $GLOBALS['content_width'] = apply_filters( 'spin_pulse_content_width', 1200 );
}
add_action( 'after_setup_theme', 'spin_pulse_content_width', 0 );

function spin_pulse_widgets_init() {
    register_sidebar( array(
        'name'          => esc_html__( 'Sidebar', 'spin-pulse' ),
        'id'            => 'sidebar-1',
        'description'   => esc_html__( 'Add widgets here.', 'spin-pulse' ),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget'  => '</section>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ) );
}
add_action( 'widgets_init', 'spin_pulse_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function spin_pulse_enqueue_assets() {
    wp_enqueue_style( 'spin-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null );
    wp_enqueue_style( 'spin-pulse-style', get_stylesheet_uri(), array(), _S_VERSION );

    if ( file_exists( get_template_directory() . '/js/navigation.js' ) ) {
        wp_enqueue_script( 'spin-pulse-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true );
    }

    if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
        wp_enqueue_script( 'comment-reply' );
    }
}
add_action( 'wp_enqueue_scripts', 'spin_pulse_enqueue_assets' );

/**
 * Custom Walker for Badges.
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu {
    function start_lvl( &$output, $depth = 0, $args = null ) {
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"absolute left-0 top-full hidden group-hover:block w-56 bg-white border-t-2 border-casino-blue shadow-menu py-2 z-50 rounded-b-lg animate-slide-down overflow-hidden\">\n";
    }

    function start_el( &$output, $item, $depth = 0, $args = null, $id = 0 ) {
        $classes = empty( $item->classes ) ? array() : (array) $item->classes;
        $has_children = in_array('menu-item-has-children', $classes);
        $class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item, $args ) );
        $output .= '<li class="' . esc_attr( $class_names ) . ' relative group">';

        $title = apply_filters( 'the_title', $item->title, $item->ID );
        $badges = [ '{New}' => 'bg-badge-green text-green-700', '{Top}' => 'bg-badge-red text-red-700', '{Best}' => 'bg-badge-gray text-slate-700' ];

        foreach ( $badges as $tag => $color_class ) {
            if ( strpos( $title, $tag ) !== false ) {
                $clean_tag = str_replace( ['{','}'], '', $tag );
                $badge_html = '<span class="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wide ' . $color_class . ' shadow-sm">' . $clean_tag . '</span>';
                $title = str_replace( $tag, '', $title ) . $badge_html;
            }
        }

        if ( $has_children && $depth === 0 ) {
            $title .= ' <svg class="w-4 h-4 ml-1 opacity-50 group-hover:rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>';
        }

        $attributes = ! empty( $item->url ) ? ' href="' . esc_url( $item->url ) . '"' : '';
        $link_class = ( $depth > 0 ) ? 'block px-5 py-3 text-sm text-nav-text hover:bg-slate-50' : 'flex items-center text-nav-text font-semibold px-4 py-2';
        $output .= '<a' . $attributes . ' class="' . $link_class . '">' . $args->link_before . $title . $args->link_after . '</a>';
    }
}

/**
 * Helper: Social Links.
 */
function spin_pulse_get_social_links() {
    $socials = array(
        'facebook' => ['url' => get_theme_mod('spin_pulse_social_facebook'), 'color' => '#1877f2', 'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z"/></svg>'],
        'twitter'  => ['url' => get_theme_mod('spin_pulse_social_twitter'), 'color' => '#000000', 'icon' => '<svg class="w-5 h-5" fill="currentColor" viewBox="0 0 24 24"><path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24h-6.657l-5.214-6.81L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/></svg>'],
    );
    $output = '';
    foreach ( $socials as $key => $social ) {
        if ( ! empty( $social['url'] ) ) {
            $output .= '<a href="' . esc_url( $social['url'] ) . '" class="text-[' . $social['color'] . ']">' . $social['icon'] . '</a>';
        }
    }
    return $output;
}

/**
 * Customizer CSS.
 */
function spin_pulse_customizer_css() {
    ?>
    <style type="text/css">
        #main-header { background-color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_header_bg_color', '#f2f3f6' ) ); ?>; }
        #top-bar { background-color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_bg_color', '#f2f3f6' ) ); ?>; color: <?php echo esc_attr( get_theme_mod( 'spin_pulse_topbar_text_color', '#1e293b' ) ); ?>; }
    </style>
    <?php
}
add_action( 'wp_head', 'spin_pulse_customizer_css' );

require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';

/**
 * --- SPIN PULSE OPTIONS PAGE ---
 */

add_action('admin_menu', 'spin_pulse_register_options_menu');
function spin_pulse_register_options_menu() {
    add_menu_page('Spin Pulse Options', 'Spin Pulse Options', 'manage_options', 'spin-pulse-options', 'spin_pulse_options_page_html', 'dashicons-admin-appearance', 59);
    add_submenu_page('spin-pulse-options', 'Hero Settings', 'Homepage Hero', 'manage_options', 'spin-pulse-options', 'spin_pulse_options_page_html');
}

function spin_pulse_options_page_html() {
    if (!current_user_can('manage_options')) return;
    settings_errors('spin_pulse_messages');
    ?>
    <div class="wrap">
        <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('spin_pulse_options_group');
            do_settings_sections('spin-pulse-options');
            submit_button('Save Hero Settings');
            ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'spin_pulse_register_settings');
function spin_pulse_register_settings() {
    register_setting('spin_pulse_options_group', 'spin_pulse_hero_settings', 'spin_pulse_sanitize_hero_settings');

    add_settings_section('hero_section', 'Hero Content Settings', 'spin_pulse_hero_section_callback', 'spin-pulse-options');

    add_settings_field('hero_heading', 'Main Heading', 'spin_pulse_text_field_callback', 'spin-pulse-options', 'hero_section', ['id' => 'hero_heading']);

    add_settings_field('hero_description', 'Description', 'spin_pulse_textarea_field_callback', 'spin-pulse-options', 'hero_section', ['id' => 'hero_description']);
    add_settings_field('hero_badge_text', 'Card Badge Text', 'spin_pulse_text_field_callback', 'spin-pulse-options', 'hero_section', ['id' => 'hero_badge_text']);

    // Colors
    $colors = [
        'hero_bg_start'      => ['label' => 'Gradient Start', 'default' => '#7c3aed'],
        'hero_bg_mid'        => ['label' => 'Gradient Middle', 'default' => '#6d28d9'],
        'hero_bg_end'        => ['label' => 'Gradient End', 'default' => '#5b21b6'],
        'hero_text_color'    => ['label' => 'Description Color', 'default' => '#f3e8ff'],
        'badge_bg_color'     => ['label' => 'Card Badge Background', 'default' => '#f97316'], // New
        'badge_text_color'   => ['label' => 'Card Badge Text Color', 'default' => '#ffffff'], // New
    ];
    foreach($colors as $id => $data) {
        add_settings_field($id, $data['label'], 'spin_pulse_color_field_callback', 'spin-pulse-options', 'hero_section', ['id' => $id, 'default' => $data['default']]);
    }

        // Dynamic Cards - Add a Badge Text field for each card
    for ($i = 1; $i <= 4; $i++) {
        add_settings_section("hero_card_{$i}_section", "Card $i Settings", '__return_empty_string', 'spin-pulse-options');
        
        // New: Unique Badge Text for each card
        add_settings_field("hero_card{$i}_badge", "Card $i Badge Text", 'spin_pulse_text_field_callback', 'spin-pulse-options', "hero_card_{$i}_section", ['id' => "hero_card{$i}_badge", 'desc' => 'Leave empty to hide badge']);
        
        add_settings_field("hero_card{$i}_title", "Card $i Title", 'spin_pulse_text_field_callback', 'spin-pulse-options', "hero_card_{$i}_section", ['id' => "hero_card{$i}_title"]);
        add_settings_field("hero_card{$i}_link", "Card $i Link", 'spin_pulse_text_field_callback', 'spin-pulse-options', "hero_card_{$i}_section", ['id' => "hero_card{$i}_link"]);
    }

    // Dynamic Cards
    for ($i = 1; $i <= 4; $i++) {
        add_settings_section("hero_card_{$i}_section", "Card $i Settings", '__return_empty_string', 'spin-pulse-options');
        add_settings_field("hero_card{$i}_title", "Card $i Title", 'spin_pulse_text_field_callback', 'spin-pulse-options', "hero_card_{$i}_section", ['id' => "hero_card{$i}_title"]);
        add_settings_field("hero_card{$i}_link", "Card $i Link", 'spin_pulse_text_field_callback', 'spin-pulse-options', "hero_card_{$i}_section", ['id' => "hero_card{$i}_link"]);
    }
}

function spin_pulse_hero_section_callback() { echo '<p>Edit your homepage hero content and colors.</p>'; }

function spin_pulse_text_field_callback($args) {
    $options = get_option('spin_pulse_hero_settings', []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : '';
    $desc = !empty($args['desc']) ? '<p class="description">' . esc_html($args['desc']) . '</p>' : '';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="spin_pulse_hero_settings[' . esc_attr($args['id']) . ']" value="' . $value . '" class="regular-text" />' . $desc;
}

function spin_pulse_textarea_field_callback($args) {
    $options = get_option('spin_pulse_hero_settings', []);
    $value = isset($options[$args['id']]) ? esc_textarea($options[$args['id']]) : '';
    echo '<textarea id="' . esc_attr($args['id']) . '" name="spin_pulse_hero_settings[' . esc_attr($args['id']) . ']" rows="5" class="large-text">' . $value . '</textarea>';
}

function spin_pulse_color_field_callback($args) {
    $options = get_option('spin_pulse_hero_settings', []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : $args['default'];
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="spin_pulse_hero_settings[' . esc_attr($args['id']) . ']" value="' . $value . '" class="spin-pulse-color-picker" data-default-color="' . esc_attr($args['default']) . '" />';
}

function spin_pulse_sanitize_hero_settings($input) {
    $sanitized = [];
    foreach ($input as $key => $value) {
        if (strpos($key, 'color') !== false) $sanitized[$key] = sanitize_hex_color($value);
        elseif ($key === 'hero_description') $sanitized[$key] = wp_kses_post($value);
        elseif (strpos($key, 'link') !== false) $sanitized[$key] = esc_url_raw($value);
        else $sanitized[$key] = sanitize_text_field($value);
    }
    return $sanitized;
}

add_action('admin_enqueue_scripts', 'spin_pulse_enqueue_options_scripts');
function spin_pulse_enqueue_options_scripts($hook) {
    if ('toplevel_page_spin-pulse-options' !== $hook) return;
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_add_inline_script('wp-color-picker', 'jQuery(document).ready(function($){ $(".spin-pulse-color-picker").wpColorPicker(); });');
}