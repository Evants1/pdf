<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if (!defined('_S_VERSION')) {
    define('_S_VERSION', filemtime(get_template_directory() . '/style.css') ?: '1.0.0');
}

/**
 * 1. THEME SETUP
 */
function spin_pulse_setup()
{
    load_theme_textdomain('spin-pulse', get_template_directory() . '/languages');
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'menu-1' => esc_html__('Primary Menu', 'spin-pulse'),
        'footer-menu' => esc_html__('Footer Menu', 'spin-pulse'),
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    add_theme_support('custom-logo', array('height' => 250, 'width' => 250, 'flex-width' => true, 'flex-height' => true));
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'spin_pulse_setup');

/**
 * 2. ASSETS ENQUEUE
 */
function spin_pulse_enqueue_assets()
{
    wp_enqueue_style('spin-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    wp_enqueue_style('spin-pulse-style', get_stylesheet_uri(), array(), _S_VERSION);

    if (file_exists(get_template_directory() . '/js/navigation.js')) {
        wp_enqueue_script('spin-pulse-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_assets');

/**
 * 3. CUSTOM WALKER (Badges & Colors)
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu
{
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
        $indent = str_repeat("\t", $depth);
        $output .= "\n$indent<ul class=\"sub-menu absolute left-0 top-[calc(100%-2px)] hidden group-hover:block w-60 border-t-2 border-purple-500 shadow-2xl py-3 z-50 rounded-b-xl animate-slide-down\" style=\"background-color: {$sub_bg};\">\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $has_children = in_array('menu-item-has-children', $classes);
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $output .= '<li class="' . esc_attr($class_names) . ' relative group">';

        $title = apply_filters('the_title', $item->title, $item->ID);

        $badges = ['{New}' => 'bg-emerald-500', '{Top}' => 'bg-rose-500', '{Best}' => 'bg-amber-500'];
        foreach ($badges as $tag => $bg_class) {
            if (strpos($title, $tag) !== false) {
                $clean_tag = str_replace(['{', '}'], '', $tag);
                $badge_html = '<span class="absolute -top-1 left-4 px-1.5 py-0.5 rounded text-[9px] font-black uppercase ' . $bg_class . ' text-white shadow-sm z-10">' . $clean_tag . '</span>';
                $title = str_replace($tag, '', $title) . $badge_html;
            }
        }

        $arrow = ($depth === 0 && $has_children) ? '<svg class="w-4 h-4 ml-1.5 opacity-60 group-hover:rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>' : '';

        $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
        $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
        $attributes = !empty($item->url) ? ' href="' . esc_url($item->url) . '"' : '';

        if ($depth > 0) {
            $link_style = "color: {$sub_text};";
            $link_class = 'block px-6 py-2.5 text-[13px] font-medium hover:bg-white/5 hover:pl-7 transition-all duration-200 sub-menu-link';
        } else {
            $link_style = "color: {$h_text};";
            $link_class = 'flex items-center font-bold px-4 py-5 transition-colors main-menu-link';
        }

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . ' class="' . $link_class . '" style="' . $link_style . '">';
        $item_output .= $args->link_before . $title . $arrow . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * 4. DYNAMIC CUSTOMIZER CSS
 */
function spin_pulse_dynamic_css()
{
    $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
    $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
    $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
    $sub_hover = get_theme_mod('spin_pulse_submenu_hover_color', '#a855f7');
    $f_bg = get_theme_mod('spin_pulse_footer_bg_color', '#0B0F1A');
    $f_text = get_theme_mod('spin_pulse_footer_text_color', '#ffffff');
    ?>
    <style type="text/css">
        .main-menu-link, .site-title a { color: <?php echo esc_attr($h_text); ?> !important; }
        .sub-menu { background-color: <?php echo esc_attr($sub_bg); ?> !important; }
        .sub-menu-link { color: <?php echo esc_attr($sub_text); ?> !important; }
        .sub-menu-link:hover { color: <?php echo esc_attr($sub_hover); ?> !important; }
        #colophon.site-footer { background-color: <?php echo esc_attr($f_bg); ?> !important; color: <?php echo esc_attr($f_text); ?> !important; }
        #masthead button svg { color: <?php echo esc_attr($h_text); ?>; }
    </style>
    <?php
}
add_action('wp_head', 'spin_pulse_dynamic_css', 100);

/**
 * Main Scripts & Styles Enqueue
 */
function spin_pulse_enqueue_scripts()
{
    wp_enqueue_style('spin-pulse-main', get_template_directory_uri() . '/style.css', array(), '1.0.0');
    wp_enqueue_script('spin-pulse-compare', get_template_directory_uri() . '/js/casino-compare.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_scripts');

function spin_pulse_enqueue_faq_assets()
{
    wp_enqueue_style('spin-pulse-faq-styles', get_template_directory_uri() . '/style.css', array(), '1.0.0');
    wp_enqueue_script('spin-pulse-faq-toggle', get_template_directory_uri() . '/js/faq-toggle.js', array(), '1.0', true);
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_faq_assets');

function sp_add_back_to_top_button()
{
    echo '<button id="sp-back-to-top" class="sp-scroll-button" title="Go to top">↑</button>';
}
add_action('wp_footer', 'sp_add_back_to_top_button');

function sp_enqueue_table_scripts() {
    wp_enqueue_script('sp-table-expand', get_template_directory_uri() . '/js/sp-table-expand.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'sp_enqueue_table_scripts');

function sp_theme_scripts()
{
    wp_enqueue_script('sp-custom-js', get_template_directory_uri() . '/js/sp-scripts.js', array(), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'sp_theme_scripts');

function spin_pulse_admin_style_fix()
{
    echo '<style>#wpbody { background: #f0f2f5; }</style>';
}
add_action('admin_head', 'spin_pulse_admin_style_fix');

/* ==========================================================================
   SpinPulse: Limit Default Pages Widget
   ========================================================================== */
function sp_limit_widget_pages( $args ) {
    $args['number'] = 5; 
    return $args;
}
add_filter( 'widget_pages_args', 'sp_limit_widget_pages' );

/**
 * Register widget areas.
 */
function spin_pulse_widgets_init() {
    register_sidebar(
        array(
            'name'          => esc_html__( 'Left Sidebar', 'spin-pulse' ),
            'id'            => 'sidebar-left',
            'description'   => esc_html__( 'Add widgets here to appear in your left sidebar.', 'spin-pulse' ),
            'before_widget' => '<section id="%1$s" class="widget sp-left-sidebar-widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title sp-left-sidebar-title">',
            'after_title'   => '</h2>',
        )
    );
    register_sidebar(
        array(
            'name'          => esc_html__( 'Right Sidebar', 'spin-pulse' ),
            'id'            => 'sidebar-right',
            'description'   => esc_html__( 'Add widgets here to appear in your right sidebar.', 'spin-pulse' ),
            'before_widget' => '<section id="%1$s" class="widget sp-right-sidebar-widget %2$s">',
            'after_widget'  => '</section>',
            'before_title'  => '<h2 class="widget-title sp-right-sidebar-title">',
            'after_title'   => '</h2>',
        )
    );
}
add_action( 'widgets_init', 'spin_pulse_widgets_init' );

/* ==========================================================================
   SpinPulse: User Profile Additions (Social Media & Custom Avatar)
   ========================================================================== */
function sp_custom_user_social_fields( $contactmethods ) {
    $contactmethods['twitter']   = esc_html__( 'X (Twitter) Profile URL', 'spin-pulse' );
    $contactmethods['facebook']  = esc_html__( 'Facebook Profile URL', 'spin-pulse' );
    $contactmethods['instagram'] = esc_html__( 'Instagram Profile URL', 'spin-pulse' );
    $contactmethods['linkedin']  = esc_html__( 'LinkedIn Profile URL', 'spin-pulse' );
    $contactmethods['youtube']   = esc_html__( 'YouTube Channel URL', 'spin-pulse' );
    return $contactmethods;
}
add_filter( 'user_contactmethods', 'sp_custom_user_social_fields' );

function sp_custom_user_avatar_field( $user ) {
    if ( ! current_user_can( 'edit_user', $user->ID ) ) { return; }
    $avatar_url = get_user_meta( $user->ID, 'sp_custom_avatar', true );
    ?>
    <h3><?php esc_html_e( 'Custom Avatar', 'spin-pulse' ); ?></h3>
    <table class="form-table">
        <tr>
            <th><label for="sp_custom_avatar"><?php esc_html_e( 'Profile Picture', 'spin-pulse' ); ?></label></th>
            <td>
                <div class="sp-avatar-preview" style="margin-bottom: 15px;">
                    <img src="<?php echo esc_url( $avatar_url ? $avatar_url : get_avatar_url( $user->ID ) ); ?>" 
                         style="width: 96px; height: 96px; border-radius: 50%; object-fit: cover; border: 2px solid #e0ddd5;" 
                         id="sp-avatar-image-preview" alt="Avatar Preview" />
                </div>
                <input type="hidden" name="sp_custom_avatar" id="sp_custom_avatar" value="<?php echo esc_attr( $avatar_url ); ?>" />
                <button type="button" class="button button-secondary" id="sp-upload-avatar-btn">
                    <?php esc_html_e( 'Upload / Select Image', 'spin-pulse' ); ?>
                </button>
                <button type="button" class="button button-link-delete" id="sp-remove-avatar-btn" style="<?php echo empty( $avatar_url ) ? 'display:none;' : ''; ?>">
                    <?php esc_html_e( 'Remove Custom Avatar', 'spin-pulse' ); ?>
                </button>
                <p class="description"><?php esc_html_e( 'Upload a custom image to override the default Gravatar. Recommended size: 250x250 pixels.', 'spin-pulse' ); ?></p>
            </td>
        </tr>
    </table>
    <?php
}
add_action( 'show_user_profile', 'sp_custom_user_avatar_field' );
add_action( 'edit_user_profile', 'sp_custom_user_avatar_field' );

function sp_save_custom_user_avatar_field( $user_id ) {
    if ( ! current_user_can( 'edit_user', $user_id ) ) return false;
    if ( isset( $_POST['sp_custom_avatar'] ) ) { update_user_meta( $user_id, 'sp_custom_avatar', esc_url_raw( $_POST['sp_custom_avatar'] ) ); }
}
add_action( 'personal_options_update', 'sp_save_custom_user_avatar_field' );
add_action( 'edit_user_profile_update', 'sp_save_custom_user_avatar_field' );

function sp_override_get_avatar_url( $args, $id_or_email ) {
    $user_id = 0;
    if ( is_numeric( $id_or_email ) ) { $user_id = (int) $id_or_email; } 
    elseif ( is_string( $id_or_email ) && ( $user = get_user_by( 'email', $id_or_email ) ) ) { $user_id = $user->ID; } 
    elseif ( is_object( $id_or_email ) && ! empty( $id_or_email->user_id ) ) { $user_id = (int) $id_or_email->user_id; }

    if ( $user_id ) {
        $custom_avatar = get_user_meta( $user_id, 'sp_custom_avatar', true );
        if ( $custom_avatar ) { $args['url'] = $custom_avatar; }
    }
    return $args;
}
add_filter( 'get_avatar_data', 'sp_override_get_avatar_url', 10, 2 );

function sp_enqueue_avatar_uploader_script( $hook ) {
    if ( 'profile.php' !== $hook && 'user-edit.php' !== $hook ) { return; }
    wp_enqueue_media(); 
    wp_add_inline_script( 'media-upload', '
        jQuery(document).ready(function($){
            var mediaUploader;
            $("#sp-upload-avatar-btn").on("click", function(e){
                e.preventDefault();
                if(mediaUploader){ mediaUploader.open(); return; }
                mediaUploader = wp.media.frames.file_frame = wp.media({ title: "Choose a Profile Picture", button: { text: "Use this image" }, multiple: false });
                mediaUploader.on("select", function(){
                    var attachment = mediaUploader.state().get("selection").first().toJSON();
                    $("#sp_custom_avatar").val(attachment.url);
                    $("#sp-avatar-image-preview").attr("src", attachment.url);
                    $("#sp-remove-avatar-btn").show();
                });
                mediaUploader.open();
            });
            $("#sp-remove-avatar-btn").on("click", function(e){
                e.preventDefault();
                $("#sp_custom_avatar").val("");
                $("#sp-avatar-image-preview").attr("src", ""); 
                $(this).hide();
            });
        });
    ' );
}
add_action( 'admin_enqueue_scripts', 'sp_enqueue_avatar_uploader_script' );

/* ==========================================================================
   SpinPulse: Track Post Views Automatically
   ========================================================================== */
function sp_set_post_views($postID) {
    $count_key = 'post_views_count';
    $count = get_post_meta($postID, $count_key, true);
    if($count == ''){
        $count = 0;
        delete_post_meta($postID, $count_key);
        add_post_meta($postID, $count_key, '0');
    } else {
        $count++;
        update_post_meta($postID, $count_key, $count);
    }
}
function sp_track_post_views($post_id) {
    if ( !is_single() ) return;
    if ( empty ( $post_id) ) { global $post; $post_id = $post->ID; }
    sp_set_post_views($post_id);
}
add_action( 'wp_head', 'sp_track_post_views');

// ==========================================================================
// SpinPulse: Affiliate Custom Post Types & Dynamic Slugs
// ==========================================================================
function spin_pulse_register_affiliate_cpts() {
    $spade_icon = 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCA1MTIgNTEyIj48cGF0aCBkPSJNMjU2IDBDMTYwLjUgMTUwLjcgOTYuMSAyMDMuNiA5Ni4xIDI4NS41YzAgNTkuOSA0NS42IDEwOC41IDEwMS45IDEwOC41IDI2LjUgMCA1MC43LTEwLjYgNjgtMjguMyA0LjggMTkuNCAxMS40IDQ5IDE4LjEgNzQuM2g1MS44Yy02LjctMjUuMy0xMy4zLTU0LjktMTguMS03NC4zIDE3LjMgMTcuNyA0MS41IDI4LjMgNjggMjguMyA1Ni4zIDAgMTAxLjktNDguNiAxMDEuOS0xMDguNUM0MTUuOSAyMDMuNiAzNTEuNSAxNTAuNyAyNTYgMHoiIGZpbGw9ImN1cnJlbnRDb2xvciIvPjwvc3ZnPg==';

    $review_slug = get_option( 'sp_casino_review_slug', 'casino-reviews' );
    $review_slug = empty($review_slug) ? 'casino-reviews' : $review_slug;
    $game_slug = get_option( 'sp_casino_game_slug', 'casino-games' );
    $game_slug = empty($game_slug) ? 'casino-games' : $game_slug;
    $bonus_slug = get_option( 'sp_casino_bonus_slug', 'casino-bonuses' );
    $bonus_slug = empty($bonus_slug) ? 'casino-bonuses' : $bonus_slug;

    register_post_type( 'casino_review', array(
        'labels' => array('name' => 'Casino Reviews', 'singular_name' => 'Casino Review', 'menu_name' => 'Casino Reviews'),
        'public' => true, 'has_archive' => true, 'menu_position' => 5, 'menu_icon' => $spade_icon, 'show_in_rest' => true, 
        'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'revisions', 'comments' ),
        'rewrite' => array( 'slug' => sanitize_title($review_slug), 'with_front' => false ),
    ));

    register_post_type( 'casino_game', array(
        'labels' => array('name' => 'Casino Games', 'singular_name' => 'Casino Game', 'menu_name' => 'Casino Games'),
        'public' => true, 'has_archive' => true, 'menu_position' => 6, 'menu_icon' => $spade_icon, 'show_in_rest' => true,
        'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments' ),
        'rewrite' => array( 'slug' => sanitize_title($game_slug), 'with_front' => false ),
    ));

    register_post_type( 'casino_bonus', array(
        'labels' => array('name' => 'Casino Bonuses', 'singular_name' => 'Casino Bonus', 'menu_name' => 'Casino Bonuses'),
        'public' => true, 'has_archive' => true, 'menu_position' => 7, 'menu_icon' => $spade_icon, 'show_in_rest' => true,
        'supports' => array( 'title', 'editor', 'thumbnail', 'excerpt', 'custom-fields', 'comments' ),
        'rewrite' => array( 'slug' => sanitize_title($bonus_slug), 'with_front' => false ),
    ));

    register_taxonomy('review_category', array('casino_review'), array(
        'hierarchical' => true, 'labels' => array('name' => 'Review Categories', 'singular_name' => 'Review Category', 'menu_name' => 'Categories'),
        'show_ui' => true, 'show_admin_column' => true, 'show_in_rest' => true, 'rewrite' => array( 'slug' => 'review-category' ),
    ));
}
add_action( 'init', 'spin_pulse_register_affiliate_cpts' );

function sp_add_all_cpt_slug_settings() {
    add_settings_field( 'sp_casino_review_slug', 'Casino Reviews Base', 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_review_slug', 'default' => 'casino-reviews') );
    add_settings_field( 'sp_casino_game_slug', 'Casino Games Base', 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_game_slug', 'default' => 'casino-games') );
    add_settings_field( 'sp_casino_bonus_slug', 'Casino Bonuses Base', 'sp_slug_input_cb', 'permalink', 'optional', array('id' => 'sp_casino_bonus_slug', 'default' => 'casino-bonuses') );
    
    if ( isset( $_POST['sp_casino_review_slug'] ) ) update_option( 'sp_casino_review_slug', sanitize_title_with_dashes( $_POST['sp_casino_review_slug'] ) );
    if ( isset( $_POST['sp_casino_game_slug'] ) ) update_option( 'sp_casino_game_slug', sanitize_title_with_dashes( $_POST['sp_casino_game_slug'] ) );
    if ( isset( $_POST['sp_casino_bonus_slug'] ) ) update_option( 'sp_casino_bonus_slug', sanitize_title_with_dashes( $_POST['sp_casino_bonus_slug'] ) );
}
add_action( 'admin_init', 'sp_add_all_cpt_slug_settings' );

function sp_slug_input_cb($args) {
    $value = get_option( $args['id'], $args['default'] );
    echo '<input type="text" value="' . esc_attr( $value ) . '" name="' . esc_attr($args['id']) . '" id="' . esc_attr($args['id']) . '" class="regular-text" />';
    echo '<p class="description">Default URL: <code>/' . esc_html($args['default']) . '/</code></p>';
}

// ==========================================================================
// SpinPulse: Casino Review Meta Boxes
// ==========================================================================
function sp_add_casino_review_meta_boxes() {
    add_meta_box( 'sp_casino_review_data', 'Casino Review Details & Ratings', 'sp_render_casino_review_meta_box', 'casino_review', 'normal', 'high' );
}
add_action( 'add_meta_boxes', 'sp_add_casino_review_meta_boxes' );

function sp_render_casino_review_meta_box( $post ) {
    wp_nonce_field( 'sp_save_casino_review_data', 'sp_casino_review_meta_nonce' );
    $rating = get_post_meta( $post->ID, 'sp_review_rating', true );
    $bonus = get_post_meta( $post->ID, 'sp_review_bonus', true );
    $link = get_post_meta( $post->ID, 'sp_review_link', true );
    $pros = get_post_meta( $post->ID, 'sp_review_pros', true );
    $cons = get_post_meta( $post->ID, 'sp_review_cons', true );
    
    $r_cashout = get_post_meta( $post->ID, 'sp_rating_cashout', true );
    $r_offers  = get_post_meta( $post->ID, 'sp_rating_offers', true );
    $r_secure  = get_post_meta( $post->ID, 'sp_rating_secure', true );
    $r_games   = get_post_meta( $post->ID, 'sp_rating_games', true );
    $r_support = get_post_meta( $post->ID, 'sp_rating_support', true );
    ?>
    <style>
        .sp-meta-row { margin-bottom: 20px; }
        .sp-meta-row label { display: block; font-weight: bold; margin-bottom: 5px; color: #1e293b; }
        .sp-meta-row input[type="text"], .sp-meta-row input[type="number"], .sp-meta-row input[type="url"], .sp-meta-row textarea { width: 100%; max-width: 100%; padding: 8px; border: 1px solid #cbd5e1; border-radius: 4px; }
        .sp-meta-row textarea { height: 100px; }
        .sp-meta-desc { font-size: 12px; color: #64748b; margin-top: 4px; display: block; }
        .sp-rating-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 15px; background: #f8fafc; padding: 15px; border: 1px solid #e2e8f0; border-radius: 8px; margin-bottom: 20px;}
    </style>
    
    <div class="sp-meta-row"><label for="sp_review_rating">Main Star Rating (Out of 5)</label><input type="number" id="sp_review_rating" name="sp_review_rating" value="<?php echo esc_attr( $rating ); ?>" step="0.1" min="1" max="5" placeholder="e.g. 4.8" /></div>
    <div class="sp-meta-row"><label for="sp_review_bonus">Main Bonus Offer Highlight</label><input type="text" id="sp_review_bonus" name="sp_review_bonus" value="<?php echo esc_attr( $bonus ); ?>" placeholder="e.g. 100% up to $500 + 200 Free Spins" /></div>
    <div class="sp-meta-row"><label for="sp_review_link">Affiliate 'Play Now' Link</label><input type="url" id="sp_review_link" name="sp_review_link" value="<?php echo esc_url( $link ); ?>" placeholder="https://..." /></div>

    <div class="sp-meta-row">
        <label>Performance Ratings (0 - 100%)</label>
        <div class="sp-rating-grid">
            <div><label>Cashout Speed</label><input type="number" name="sp_rating_cashout" value="<?php echo esc_attr($r_cashout); ?>" min="0" max="100" placeholder="98"></div>
            <div><label>Bonuses & Offers</label><input type="number" name="sp_rating_offers" value="<?php echo esc_attr($r_offers); ?>" min="0" max="100" placeholder="95"></div>
            <div><label>Security</label><input type="number" name="sp_rating_secure" value="<?php echo esc_attr($r_secure); ?>" min="0" max="100" placeholder="99"></div>
            <div><label>Software & Games</label><input type="number" name="sp_rating_games" value="<?php echo esc_attr($r_games); ?>" min="0" max="100" placeholder="92"></div>
            <div><label>Support</label><input type="number" name="sp_rating_support" value="<?php echo esc_attr($r_support); ?>" min="0" max="100" placeholder="90"></div>
        </div>
    </div>

    <div class="sp-meta-row" style="display:flex; gap: 20px;">
        <div style="flex:1;"><label for="sp_review_pros">Pros (One per line)</label><textarea id="sp_review_pros" name="sp_review_pros" placeholder="Instant payouts&#10;Great live casino&#10;24/7 Support"><?php echo esc_textarea( $pros ); ?></textarea><span class="sp-meta-desc">Hit 'Enter' to create a new bullet point.</span></div>
        <div style="flex:1;"><label for="sp_review_cons">Cons (One per line)</label><textarea id="sp_review_cons" name="sp_review_cons" placeholder="High wagering requirements&#10;No phone support"><?php echo esc_textarea( $cons ); ?></textarea><span class="sp-meta-desc">Hit 'Enter' to create a new bullet point.</span></div>
    </div>
    <?php
}

function sp_save_casino_review_meta_box( $post_id ) {
    if ( ! isset( $_POST['sp_casino_review_meta_nonce'] ) || ! wp_verify_nonce( $_POST['sp_casino_review_meta_nonce'], 'sp_save_casino_review_data' ) ) return;
    if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
    if ( ! current_user_can( 'edit_post', $post_id ) ) return;

    if ( isset( $_POST['sp_review_rating'] ) ) update_post_meta( $post_id, 'sp_review_rating', sanitize_text_field( $_POST['sp_review_rating'] ) );
    if ( isset( $_POST['sp_review_bonus'] ) ) update_post_meta( $post_id, 'sp_review_bonus', sanitize_text_field( $_POST['sp_review_bonus'] ) );
    if ( isset( $_POST['sp_review_link'] ) ) update_post_meta( $post_id, 'sp_review_link', esc_url_raw( $_POST['sp_review_link'] ) );
    if ( isset( $_POST['sp_review_pros'] ) ) update_post_meta( $post_id, 'sp_review_pros', sanitize_textarea_field( $_POST['sp_review_pros'] ) );
    if ( isset( $_POST['sp_review_cons'] ) ) update_post_meta( $post_id, 'sp_review_cons', sanitize_textarea_field( $_POST['sp_review_cons'] ) );
    
    if ( isset( $_POST['sp_rating_cashout'] ) ) update_post_meta( $post_id, 'sp_rating_cashout', absint( $_POST['sp_rating_cashout'] ) );
    if ( isset( $_POST['sp_rating_offers'] ) ) update_post_meta( $post_id, 'sp_rating_offers', absint( $_POST['sp_rating_offers'] ) );
    if ( isset( $_POST['sp_rating_secure'] ) ) update_post_meta( $post_id, 'sp_rating_secure', absint( $_POST['sp_rating_secure'] ) );
    if ( isset( $_POST['sp_rating_games'] ) ) update_post_meta( $post_id, 'sp_rating_games', absint( $_POST['sp_rating_games'] ) );
    if ( isset( $_POST['sp_rating_support'] ) ) update_post_meta( $post_id, 'sp_rating_support', absint( $_POST['sp_rating_support'] ) );
}
add_action( 'save_post_casino_review', 'sp_save_casino_review_meta_box' );

function sp_casino_cards_shortcode($atts) {
    $atts = shortcode_atts(array('limit' => 3, 'category' => ''), $atts);
    $args = array('post_type' => 'casino_review', 'posts_per_page' => intval($atts['limit']), 'post_status' => 'publish');
    if (!empty($atts['category'])) { $args['tax_query'] = array(array('taxonomy' => 'review_category', 'field' => 'slug', 'terms' => sanitize_title($atts['category']))); }
    $query = new WP_Query($args);
    if (!$query->have_posts()) { return ''; }

    ob_start();
    ?>
    <div class="sp-casino-cards-wrapper">
        <div class="sp-casino-cards-container">
            <div class="sp-casino-cards-grid">
                <?php while ($query->have_posts()) : $query->the_post(); 
                    $post_id = get_the_ID();
                    $play_link = get_post_meta($post_id, 'sp_review_link', true) ?: '#';
                    $ratings = [
                        'Cashout speed'    => get_post_meta($post_id, 'sp_rating_cashout', true) ?: 98,
                        'Bonuses & Offers' => get_post_meta($post_id, 'sp_rating_offers', true) ?: 95,
                        'Security'         => get_post_meta($post_id, 'sp_rating_secure', true) ?: 99,
                        'Software & Games' => get_post_meta($post_id, 'sp_rating_games', true) ?: 92,
                        'Support'          => get_post_meta($post_id, 'sp_rating_support', true) ?: 90,
                    ];
                ?>
                    <div class="sp-cc-card">
                        <div class="sp-cc-header">
                            <div class="sp-cc-logo">
                                <?php if (has_post_thumbnail()) { the_post_thumbnail('thumbnail'); } else { echo '<div style="width:100%;height:100%;background:#e2e8f0;"></div>'; } ?>
                            </div>
                            <h3 class="sp-cc-title"><?php the_title(); ?></h3>
                        </div>
                        <div class="sp-cc-ratings">
                            <?php foreach($ratings as $label => $score): ?>
                                <div class="sp-cc-rating-item sp-rating-item">
                                    <span class="sp-cc-rating-label"><?php echo esc_html($label); ?></span>
                                    <div class="sp-cc-rating-bar-wrap">
                                        <div class="sp-cc-rating-bar-fill sp-progress-bar-fill" data-width="<?php echo esc_attr($score); ?>%"></div>
                                    </div>
                                    <span class="sp-cc-rating-score sp-progress-number" data-target="<?php echo esc_attr($score); ?>">0%</span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="sp-cc-buttons">
                            <a href="<?php the_permalink(); ?>" class="sp-cc-btn-review"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>Review</a>
                            <a href="<?php echo esc_url($play_link); ?>" target="_blank" rel="noopener nofollow" class="sp-cc-btn-play"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polygon points="10 8 16 12 10 16 10 8"></polygon></svg>Play Now</a>
                        </div>
                    </div>
                <?php endwhile; wp_reset_postdata(); ?>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('sp_casino_cards', 'sp_casino_cards_shortcode');

function sp_enqueue_progress_bar_script() { wp_enqueue_script('sp-progress-bar-js', get_template_directory_uri() . '/js/progress-bar.js', array(), '1.0.0', true); }
add_action( 'wp_enqueue_scripts', 'sp_enqueue_progress_bar_script' );

function sp_enqueue_arrow_script() { wp_enqueue_script('sp-arrow-scripts', get_template_directory_uri() . '/js/sp-arrow-scripts.js', array(), '1.0.0', true); }
add_action( 'wp_enqueue_scripts', 'sp_enqueue_arrow_script' );

function sp_lock_homepage_template( $templates, $theme, $post, $post_type ) {
    $front_page_id = get_option( 'page_on_front' );
    if ( $post && $post->ID == $front_page_id ) { return array(); }
    return $templates;
}
add_filter( 'theme_page_templates', 'sp_lock_homepage_template', 10, 4 );

// ==========================================================================
// NEW MODERN HERO SETTINGS DASHBOARD (WITH COLORS)
// ==========================================================================
add_action('admin_menu', 'sp_hero_admin_menu');
function sp_hero_admin_menu() {
    add_menu_page('Spin Pulse Homepage Hero Settings', 'Spin Pulse Hero', 'manage_options', 'spin-pulse-hero', 'sp_hero_settings_page', 'dashicons-superhero', 59);
}

function sp_hero_settings_page() {
    if (isset($_POST['sp_hero_save']) && check_admin_referer('sp_hero_nonce')) {
        $options = array(
            'heading'         => sanitize_text_field($_POST['heading']),
            'subtitle'        => sanitize_textarea_field($_POST['subtitle']),
            'bg_img'          => esc_url_raw($_POST['bg_img']),
            'gift_img'        => esc_url_raw($_POST['gift_img']),
            'author_1_name'   => sanitize_text_field($_POST['author_1_name']),
            'author_1_title'  => sanitize_text_field($_POST['author_1_title']),
            'author_1_img'    => esc_url_raw($_POST['author_1_img']),
            'author_1_date'   => sanitize_text_field($_POST['author_1_date']),
            'a1_fb'           => esc_url_raw($_POST['a1_fb']),
            'a1_tw'           => esc_url_raw($_POST['a1_tw']),
            'a1_ig'           => esc_url_raw($_POST['a1_ig']),
            'a1_li'           => esc_url_raw($_POST['a1_li']),
            'a1_yt'           => esc_url_raw($_POST['a1_yt']),
            'author_2_name'   => sanitize_text_field($_POST['author_2_name']),
            'author_2_title'  => sanitize_text_field($_POST['author_2_title']),
            'author_2_img'    => esc_url_raw($_POST['author_2_img']),
            'author_2_date'   => sanitize_text_field($_POST['author_2_date']),
            'a2_fb'           => esc_url_raw($_POST['a2_fb']),
            'a2_tw'           => esc_url_raw($_POST['a2_tw']),
            'a2_ig'           => esc_url_raw($_POST['a2_ig']),
            'a2_li'           => esc_url_raw($_POST['a2_li']),
            'a2_yt'           => esc_url_raw($_POST['a2_yt']),
            'feat_1_icon'     => sanitize_text_field($_POST['feat_1_icon']),
            'feat_1_title'    => sanitize_text_field($_POST['feat_1_title']),
            'feat_1_desc'     => sanitize_text_field($_POST['feat_1_desc']),
            'feat_2_icon'     => sanitize_text_field($_POST['feat_2_icon']),
            'feat_2_title'    => sanitize_text_field($_POST['feat_2_title']),
            'feat_2_desc'     => sanitize_text_field($_POST['feat_2_desc']),
            'feat_3_icon'     => sanitize_text_field($_POST['feat_3_icon']),
            'feat_3_title'    => sanitize_text_field($_POST['feat_3_title']),
            'feat_3_desc'     => sanitize_text_field($_POST['feat_3_desc']),
            'feat_4_icon'     => sanitize_text_field($_POST['feat_4_icon']),
            'feat_4_title'    => sanitize_text_field($_POST['feat_4_title']),
            'feat_4_desc'     => sanitize_text_field($_POST['feat_4_desc']),
            'badge_1_text'    => sanitize_text_field($_POST['badge_1_text']),
            'badge_2_text'    => sanitize_text_field($_POST['badge_2_text']),
            'badge_3_text'    => sanitize_text_field($_POST['badge_3_text']),
            'badge_4_text'    => sanitize_text_field($_POST['badge_4_text']),
            'offer_badge'     => sanitize_text_field($_POST['offer_badge']),
            'offer_logo'      => esc_url_raw($_POST['offer_logo']),
            'offer_title'     => sanitize_text_field($_POST['offer_title']),
            'offer_details'   => sanitize_text_field($_POST['offer_details']),
            'offer_btn_text'  => sanitize_text_field($_POST['offer_btn_text']),
            'offer_btn_link'  => esc_url_raw($_POST['offer_btn_link']),
            'offer_footer'    => sanitize_text_field($_POST['offer_footer']),
            // Custom Colors added
            'color_heading'   => sanitize_hex_color($_POST['color_heading']),
            'color_subtitle'  => sanitize_hex_color($_POST['color_subtitle']),
            'color_btn_bg'    => sanitize_hex_color($_POST['color_btn_bg']),
            'color_btn_hover' => sanitize_hex_color($_POST['color_btn_hover']),
            'color_btn_text'  => sanitize_hex_color($_POST['color_btn_text']),
        );
        update_option('spin_pulse_homepage_hero', $options);
        echo '<div class="notice notice-success is-dismissible" style="margin-top:20px; border-radius:8px;"><p>All Hero Settings Saved Successfully!</p></div>';
    }

    $opts = get_option('spin_pulse_homepage_hero', array());
    
    // Safely extract variables to avoid IDE ?? warnings
    $heading = isset($opts['heading']) ? $opts['heading'] : '';
    $subtitle = isset($opts['subtitle']) ? $opts['subtitle'] : '';
    $bg_img = isset($opts['bg_img']) ? $opts['bg_img'] : '';
    $gift_img = isset($opts['gift_img']) ? $opts['gift_img'] : '';

    $a1_name = isset($opts['author_1_name']) ? $opts['author_1_name'] : '';
    $a1_title = isset($opts['author_1_title']) ? $opts['author_1_title'] : '';
    $a1_img = isset($opts['author_1_img']) ? $opts['author_1_img'] : '';
    $a1_date = isset($opts['author_1_date']) ? $opts['author_1_date'] : '';
    $a1_fb = isset($opts['a1_fb']) ? $opts['a1_fb'] : '';
    $a1_tw = isset($opts['a1_tw']) ? $opts['a1_tw'] : '';
    $a1_ig = isset($opts['a1_ig']) ? $opts['a1_ig'] : '';
    $a1_li = isset($opts['a1_li']) ? $opts['a1_li'] : '';
    $a1_yt = isset($opts['a1_yt']) ? $opts['a1_yt'] : '';

    $a2_name = isset($opts['author_2_name']) ? $opts['author_2_name'] : '';
    $a2_title = isset($opts['author_2_title']) ? $opts['author_2_title'] : '';
    $a2_img = isset($opts['author_2_img']) ? $opts['author_2_img'] : '';
    $a2_date = isset($opts['author_2_date']) ? $opts['author_2_date'] : '';
    $a2_fb = isset($opts['a2_fb']) ? $opts['a2_fb'] : '';
    $a2_tw = isset($opts['a2_tw']) ? $opts['a2_tw'] : '';
    $a2_ig = isset($opts['a2_ig']) ? $opts['a2_ig'] : '';
    $a2_li = isset($opts['a2_li']) ? $opts['a2_li'] : '';
    $a2_yt = isset($opts['a2_yt']) ? $opts['a2_yt'] : '';

    $f1_icon = isset($opts['feat_1_icon']) ? $opts['feat_1_icon'] : '';
    $f1_title = isset($opts['feat_1_title']) ? $opts['feat_1_title'] : '';
    $f1_desc = isset($opts['feat_1_desc']) ? $opts['feat_1_desc'] : '';
    $f2_icon = isset($opts['feat_2_icon']) ? $opts['feat_2_icon'] : '';
    $f2_title = isset($opts['feat_2_title']) ? $opts['feat_2_title'] : '';
    $f2_desc = isset($opts['feat_2_desc']) ? $opts['feat_2_desc'] : '';
    $f3_icon = isset($opts['feat_3_icon']) ? $opts['feat_3_icon'] : '';
    $f3_title = isset($opts['feat_3_title']) ? $opts['feat_3_title'] : '';
    $f3_desc = isset($opts['feat_3_desc']) ? $opts['feat_3_desc'] : '';
    $f4_icon = isset($opts['feat_4_icon']) ? $opts['feat_4_icon'] : '';
    $f4_title = isset($opts['feat_4_title']) ? $opts['feat_4_title'] : '';
    $f4_desc = isset($opts['feat_4_desc']) ? $opts['feat_4_desc'] : '';

    $b1 = isset($opts['badge_1_text']) ? $opts['badge_1_text'] : '';
    $b2 = isset($opts['badge_2_text']) ? $opts['badge_2_text'] : '';
    $b3 = isset($opts['badge_3_text']) ? $opts['badge_3_text'] : '';
    $b4 = isset($opts['badge_4_text']) ? $opts['badge_4_text'] : '';

    $offer_badge = isset($opts['offer_badge']) ? $opts['offer_badge'] : '';
    $offer_logo = isset($opts['offer_logo']) ? $opts['offer_logo'] : '';
    $offer_title = isset($opts['offer_title']) ? $opts['offer_title'] : '';
    $offer_details = isset($opts['offer_details']) ? $opts['offer_details'] : '';
    $offer_btn_text = isset($opts['offer_btn_text']) ? $opts['offer_btn_text'] : '';
    $offer_btn_link = isset($opts['offer_btn_link']) ? $opts['offer_btn_link'] : '';
    $offer_footer = isset($opts['offer_footer']) ? $opts['offer_footer'] : '';

    // Color Defaults setup (Matches your current theme)
    $c_heading = isset($opts['color_heading']) && $opts['color_heading'] !== '' ? $opts['color_heading'] : '#0A1F44';
    $c_subtitle = isset($opts['color_subtitle']) && $opts['color_subtitle'] !== '' ? $opts['color_subtitle'] : '#000000';
    $c_btn_bg = isset($opts['color_btn_bg']) && $opts['color_btn_bg'] !== '' ? $opts['color_btn_bg'] : '#0A1F44';
    $c_btn_hover = isset($opts['color_btn_hover']) && $opts['color_btn_hover'] !== '' ? $opts['color_btn_hover'] : '#051024';
    $c_btn_text = isset($opts['color_btn_text']) && $opts['color_btn_text'] !== '' ? $opts['color_btn_text'] : '#ffffff';
    ?>
    <style>
        .sp-admin-wrap { max-width: 1050px; margin: 30px 20px 20px 0; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
        .sp-admin-header { background: #ffffff; padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); margin-bottom: 25px; }
        .sp-admin-header h1 { margin: 0 0 8px 0; font-size: 26px; font-weight: 800; color: #0f172a; display: flex; align-items: center; gap: 10px; }
        .sp-admin-header p { margin: 0; color: #64748b; font-size: 15px; }
        .sp-admin-card { background: #ffffff; padding: 30px; border-radius: 12px; border: 1px solid #e2e8f0; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05); margin-bottom: 25px; }
        .sp-admin-card h3 { margin: 0 0 20px 0; border-bottom: 2px solid #f1f5f9; padding-bottom: 12px; font-size: 18px; font-weight: 700; color: #1e293b; }
        .sp-admin-card table.form-table { margin: 0; }
        .sp-admin-card table.form-table th { width: 220px; font-weight: 600; color: #475569; padding: 15px 10px 15px 0; vertical-align: top; }
        .sp-admin-card table.form-table td { padding: 10px 10px 10px 0; }
        .sp-admin-card input[type="text"], .sp-admin-card input[type="url"], .sp-admin-card textarea { width: 100%; border: 1px solid #cbd5e1; border-radius: 6px; padding: 10px 14px; font-size: 14px; color: #334155; background-color: #f8fafc; transition: all 0.2s ease; box-shadow: inset 0 1px 2px rgba(0,0,0,0.02); }
        .sp-admin-card input:focus, .sp-admin-card textarea:focus { border-color: #3b82f6; outline: none; background-color: #ffffff; box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.15); }
        .sp-admin-card input[type="color"] { cursor: pointer; border: 1px solid #cbd5e1; border-radius: 6px; padding: 2px; width: 60px; height: 35px; }
        .sp-admin-card .small-text { width: 220px !important; margin-right: 10px; }
        .sp-save-btn { background: #4f46e5; color: #ffffff; border: none; padding: 14px 30px; border-radius: 8px; font-size: 16px; font-weight: 700; cursor: pointer; transition: background 0.2s ease, transform 0.1s ease; box-shadow: 0 4px 12px rgba(79, 70, 229, 0.3); }
        .sp-save-btn:hover { background: #4338ca; transform: translateY(-1px); }
        .sp-save-btn:active { transform: translateY(0); }
    </style>

    <div class="sp-admin-wrap">
        <div class="sp-admin-header">
            <h1><span class="dashicons dashicons-superhero" style="font-size:30px; width:30px; height:30px; color:#4f46e5;"></span> Spin Pulse Homepage Hero Configurations</h1>
            <p>Update your hero section below. Any fields left blank will automatically use their defaults.</p>
        </div>

        <form method="post" action="">
            <?php wp_nonce_field('sp_hero_nonce'); ?>
            
            <div class="sp-admin-card">
                <h3>1. General & Background Images</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Main Heading</label></th><td><input name="heading" type="text" value="<?php echo esc_attr($heading); ?>" placeholder="Global Online Casino 2026"></td></tr>
                    <tr><th scope="row"><label>Subtitle</label></th><td><textarea name="subtitle" rows="3" placeholder="Our guide focuses on what international players need: secure payment methods, huge game variety, transparent terms, and above all—verifiable game fairness and player security."><?php echo esc_textarea($subtitle); ?></textarea></td></tr>
                    <tr><th scope="row"><label>Background Image URL</label></th><td><input name="bg_img" type="url" value="<?php echo esc_attr($bg_img); ?>" placeholder="/wp-content/uploads/2026/03/background.jpg"></td></tr>
                    <tr><th scope="row"><label>Gift Icon URL</label></th><td><input name="gift_img" type="url" value="<?php echo esc_attr($gift_img); ?>" placeholder="/wp-content/uploads/2026/03/gift.webp"></td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>2. Author 1 (Authored By)</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Name</label></th><td><input name="author_1_name" type="text" value="<?php echo esc_attr($a1_name); ?>" placeholder="Sarah Sterling"></td></tr>
                    <tr><th scope="row"><label>Title</label></th><td><input name="author_1_title" type="text" value="<?php echo esc_attr($a1_title); ?>" placeholder="Casino Review Specialist"></td></tr>
                    <tr><th scope="row"><label>Image URL</label></th><td><input name="author_1_img" type="url" value="<?php echo esc_attr($a1_img); ?>" placeholder="/wp-content/uploads/2026/03/author2.webp"></td></tr>
                    <tr><th scope="row"><label>Date Text</label></th><td><input name="author_1_date" type="text" value="<?php echo esc_attr($a1_date); ?>" placeholder="Published: March 10, 2026"></td></tr>
                    <tr><th scope="row"><label>Facebook Link</label></th><td><input name="a1_fb" type="url" value="<?php echo esc_attr($a1_fb); ?>" placeholder="https://facebook.com/..."></td></tr>
                    <tr><th scope="row"><label>Twitter Link</label></th><td><input name="a1_tw" type="url" value="<?php echo esc_attr($a1_tw); ?>" placeholder="https://twitter.com/..."></td></tr>
                    <tr><th scope="row"><label>Instagram Link</label></th><td><input name="a1_ig" type="url" value="<?php echo esc_attr($a1_ig); ?>" placeholder="https://instagram.com/..."></td></tr>
                    <tr><th scope="row"><label>LinkedIn Link</label></th><td><input name="a1_li" type="url" value="<?php echo esc_attr($a1_li); ?>" placeholder="https://linkedin.com/..."></td></tr>
                    <tr><th scope="row"><label>YouTube Link</label></th><td><input name="a1_yt" type="url" value="<?php echo esc_attr($a1_yt); ?>" placeholder="https://youtube.com/..."></td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>3. Author 2 (Reviewed By)</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Name</label></th><td><input name="author_2_name" type="text" value="<?php echo esc_attr($a2_name); ?>" placeholder="Deric Clarke"></td></tr>
                    <tr><th scope="row"><label>Title</label></th><td><input name="author_2_title" type="text" value="<?php echo esc_attr($a2_title); ?>" placeholder="Fair Play Auditor"></td></tr>
                    <tr><th scope="row"><label>Image URL</label></th><td><input name="author_2_img" type="url" value="<?php echo esc_attr($a2_img); ?>" placeholder="/wp-content/uploads/2026/03/author1.jpg"></td></tr>
                    <tr><th scope="row"><label>Date Text</label></th><td><input name="author_2_date" type="text" value="<?php echo esc_attr($a2_date); ?>" placeholder="Updated: March 12, 2026"></td></tr>
                    <tr><th scope="row"><label>Facebook Link</label></th><td><input name="a2_fb" type="url" value="<?php echo esc_attr($a2_fb); ?>" placeholder="https://facebook.com/..."></td></tr>
                    <tr><th scope="row"><label>Twitter Link</label></th><td><input name="a2_tw" type="url" value="<?php echo esc_attr($a2_tw); ?>" placeholder="https://twitter.com/..."></td></tr>
                    <tr><th scope="row"><label>Instagram Link</label></th><td><input name="a2_ig" type="url" value="<?php echo esc_attr($a2_ig); ?>" placeholder="https://instagram.com/..."></td></tr>
                    <tr><th scope="row"><label>LinkedIn Link</label></th><td><input name="a2_li" type="url" value="<?php echo esc_attr($a2_li); ?>" placeholder="https://linkedin.com/..."></td></tr>
                    <tr><th scope="row"><label>YouTube Link</label></th><td><input name="a2_yt" type="url" value="<?php echo esc_attr($a2_yt); ?>" placeholder="https://youtube.com/..."></td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>4. Features Grid (FontAwesome Icons)</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Feature 1</label></th><td style="display:flex; gap:10px;"><input name="feat_1_icon" type="text" value="<?php echo esc_attr($f1_icon); ?>" placeholder="fas fa-map-marked-alt" class="small-text"> <input name="feat_1_title" type="text" value="<?php echo esc_attr($f1_title); ?>" placeholder="Global Casino Guide"> <input name="feat_1_desc" type="text" value="<?php echo esc_attr($f1_desc); ?>" placeholder="Multi-Currency Support"></td></tr>
                    <tr><th scope="row"><label>Feature 2</label></th><td style="display:flex; gap:10px;"><input name="feat_2_icon" type="text" value="<?php echo esc_attr($f2_icon); ?>" placeholder="fas fa-search-dollar" class="small-text"> <input name="feat_2_title" type="text" value="<?php echo esc_attr($f2_title); ?>" placeholder="Comprehensive Reviews"> <input name="feat_2_desc" type="text" value="<?php echo esc_attr($f2_desc); ?>" placeholder="100+ Brands Analyzed"></td></tr>
                    <tr><th scope="row"><label>Feature 3</label></th><td style="display:flex; gap:10px;"><input name="feat_3_icon" type="text" value="<?php echo esc_attr($f3_icon); ?>" placeholder="fas fa-chart-line" class="small-text"> <input name="feat_3_title" type="text" value="<?php echo esc_attr($f3_title); ?>" placeholder="Game Odds Analytics"> <input name="feat_3_desc" type="text" value="<?php echo esc_attr($f3_desc); ?>" placeholder="RTP & Volatility Reports"></td></tr>
                    <tr><th scope="row"><label>Feature 4</label></th><td style="display:flex; gap:10px;"><input name="feat_4_icon" type="text" value="<?php echo esc_attr($f4_icon); ?>" placeholder="fas fa-gift" class="small-text"> <input name="feat_4_title" type="text" value="<?php echo esc_attr($f4_title); ?>" placeholder="Exclusive Offers Hub"> <input name="feat_4_desc" type="text" value="<?php echo esc_attr($f4_desc); ?>" placeholder="Updated Daily Bonuses"></td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>5. Trust Badges</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Badges (Text)</label></th><td style="display:flex; flex-direction:column; gap:10px;">
                        <input name="badge_1_text" type="text" value="<?php echo esc_attr($b1); ?>" placeholder="Licensed Solutions">
                        <input name="badge_2_text" type="text" value="<?php echo esc_attr($b2); ?>" placeholder="Proven Fairness">
                        <input name="badge_3_text" type="text" value="<?php echo esc_attr($b3); ?>" placeholder="Player Privacy">
                        <input name="badge_4_text" type="text" value="<?php echo esc_attr($b4); ?>" placeholder="Global Casino Advisory">
                    </td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>6. Offer Card (Right Column)</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Badge Text</label></th><td><input name="offer_badge" type="text" value="<?php echo esc_attr($offer_badge); ?>" placeholder="Exclusive Network Access"></td></tr>
                    <tr><th scope="row"><label>Offer Title</label></th><td><input name="offer_title" type="text" value="<?php echo esc_attr($offer_title); ?>" placeholder="Premium Gaming Starter Kit"></td></tr>
                    <tr><th scope="row"><label>Offer Details</label></th><td><input name="offer_details" type="text" value="<?php echo esc_attr($offer_details); ?>" placeholder="Includes Deposit Boosts & Free Spins"></td></tr>
                    <tr><th scope="row"><label>Casino Logo URL</label></th><td><input name="offer_logo" type="url" value="<?php echo esc_attr($offer_logo); ?>" placeholder="/wp-content/uploads/2026/03/sample-logo-hero.png"></td></tr>
                    <tr><th scope="row"><label>Button Text</label></th><td><input name="offer_btn_text" type="text" value="<?php echo esc_attr($offer_btn_text); ?>" placeholder="Unlock My Welcome Package"></td></tr>
                    <tr><th scope="row"><label>Button Link</label></th><td><input name="offer_btn_link" type="url" value="<?php echo esc_attr($offer_btn_link); ?>" placeholder="https://..."></td></tr>
                    <tr><th scope="row"><label>Footer Text</label></th><td><input name="offer_footer" type="text" value="<?php echo esc_attr($offer_footer); ?>" placeholder="Data Privacy Certified & Audited"></td></tr>
                </table>
            </div>

            <div class="sp-admin-card">
                <h3>7. Theme Colors</h3>
                <table class="form-table" role="presentation">
                    <tr><th scope="row"><label>Main Heading Color</label></th><td><input name="color_heading" type="color" value="<?php echo esc_attr($c_heading); ?>"></td></tr>
                    <tr><th scope="row"><label>Subtitle Color</label></th><td><input name="color_subtitle" type="color" value="<?php echo esc_attr($c_subtitle); ?>"></td></tr>
                    <tr><th scope="row"><label>Button Background</label></th><td><input name="color_btn_bg" type="color" value="<?php echo esc_attr($c_btn_bg); ?>"></td></tr>
                    <tr><th scope="row"><label>Button Hover Background</label></th><td><input name="color_btn_hover" type="color" value="<?php echo esc_attr($c_btn_hover); ?>"></td></tr>
                    <tr><th scope="row"><label>Button Text Color</label></th><td><input name="color_btn_text" type="color" value="<?php echo esc_attr($c_btn_text); ?>"></td></tr>
                </table>
            </div>
            
            <p class="submit" style="margin-bottom: 50px;">
                <input type="submit" name="sp_hero_save" id="submit" class="sp-save-btn" value="Save Hero Changes">
            </p>
        </form>
    </div>
    <?php
}

require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';

// ==========================================================================
// SpinPulse: Custom Admin Columns (Logo & Item ID)
// ==========================================================================
function sp_add_generic_admin_logo_column( $columns ) {
    $new_columns = array();
    foreach ( $columns as $key => $title ) {
        if ( $key == 'title' ) { $new_columns['sp_logo_column'] = __( 'Logo', 'spin-pulse' ); }
        $new_columns[$key] = $title;
    }
    return $new_columns;
}

function sp_casino_review_custom_columns( $columns ) {
    $new_columns = array(
        'cb'                       => $columns['cb'], 
        'sp_logo_column'           => __( 'Logo', 'spin-pulse' ),
        'title'                    => __( 'Title', 'spin-pulse' ),
        'sp_item_id'               => __( 'Item ID', 'spin-pulse' ), 
        'author'                   => __( 'Author', 'spin-pulse' ),
        'taxonomy-review_category' => __( 'Categories', 'spin-pulse' ), 
        'comments'                 => $columns['comments'],
        'date'                     => __( 'Date', 'spin-pulse' )
    );
    return $new_columns;
}
add_filter( 'manage_casino_review_posts_columns', 'sp_casino_review_custom_columns' );

function sp_casino_review_sortable_columns( $columns ) {
    $columns['sp_item_id'] = 'ID';
    return $columns;
}
add_filter( 'manage_edit-casino_review_sortable_columns', 'sp_casino_review_sortable_columns' );

function sp_render_all_admin_custom_columns( $column_name, $post_id ) {
    if ( 'sp_logo_column' === $column_name ) {
        if ( has_post_thumbnail( $post_id ) ) { echo get_the_post_thumbnail( $post_id, 'thumbnail', array( 'class' => 'sp-admin-logo-img' ) ); } 
        else { echo '<div class="sp-admin-logo-placeholder"><span class="dashicons dashicons-format-image"></span></div>'; }
    }
    if ( 'sp_item_id' === $column_name ) { echo '<strong>' . esc_html( $post_id ) . '</strong>'; }
}

$sp_target_post_types = array( 'post', 'casino_review', 'casino_game', 'casino_bonus' );
foreach ( $sp_target_post_types as $post_type ) {
    add_action( "manage_{$post_type}_posts_custom_column", 'sp_render_all_admin_custom_columns', 10, 2 );
    if ( $post_type !== 'casino_review' ) { add_filter( "manage_{$post_type}_posts_columns", 'sp_add_generic_admin_logo_column' ); }
}

function sp_admin_columns_css() {
    echo '<style>
        th.column-sp_logo_column { width: 90px !important; text-align: center; }
        td.column-sp_logo_column { text-align: center; vertical-align: middle !important; }
        .sp-admin-logo-img { width: 70px; height: 70px; object-fit: contain; background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.05); display: inline-block; vertical-align: middle; }
        .sp-admin-logo-placeholder { width: 70px; height: 70px; background-color: #f8fafc; border: 1px dashed #cbd5e1; border-radius: 8px; display: flex; align-items: center; justify-content: center; color: #94a3b8; margin: 0 auto; }
        th.column-sp_item_id { width: 80px !important; text-align: center; }
        td.column-sp_item_id { text-align: center; vertical-align: middle !important; font-size: 14px; color: #0f172a; }
    </style>';
}
add_action( 'admin_head', 'sp_admin_columns_css' );