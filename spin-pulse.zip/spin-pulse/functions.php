<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if (!defined('_S_VERSION')) {
    define('_S_VERSION', filemtime(get_template_directory() . '/style.css') ?: '1.0.0');
}

/**
 * Sets up theme defaults.
 */
function spin_pulse_setup()
{
    load_theme_textdomain('spin-pulse', get_template_directory() . '/languages');
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'menu-1' => esc_html__('Primary Menu', 'spin-pulse'),
        'footer-menu' => esc_html__('Footer Menu', 'spin-pulse'),
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    add_theme_support('custom-background', apply_filters('spin_pulse_custom_background_args', array('default-color' => 'ffffff', 'default-image' => '')));
    add_theme_support('customize-selective-refresh-widgets');
    add_theme_support('custom-logo', array('height' => 250, 'width' => 250, 'flex-width' => true, 'flex-height' => true));
    add_theme_support('responsive-embeds');
    add_theme_support('editor-styles');
    add_editor_style('style.css');
}
add_action('after_setup_theme', 'spin_pulse_setup');

function spin_pulse_content_width()
{
    $GLOBALS['content_width'] = apply_filters('spin_pulse_content_width', 1200);
}
add_action('after_setup_theme', 'spin_pulse_content_width', 0);

function spin_pulse_widgets_init()
{
    register_sidebar(array(
        'name' => esc_html__('Sidebar', 'spin-pulse'),
        'id' => 'sidebar-1',
        'description' => esc_html__('Add widgets here.', 'spin-pulse'),
        'before_widget' => '<section id="%1$s" class="widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title' => '</h2>',
    ));
}
add_action('widgets_init', 'spin_pulse_widgets_init');

/**
 * Enqueue scripts and styles.
 */
function spin_pulse_enqueue_assets()
{
    wp_enqueue_style('spin-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    wp_enqueue_style('spin-pulse-style', get_stylesheet_uri(), array(), _S_VERSION);

    if (file_exists(get_template_directory() . '/js/navigation.js')) {
        wp_enqueue_script('spin-pulse-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    }

    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_assets');

/**
 * Custom Walker for Badges.
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu
{
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $indent = str_repeat("\t", $depth);
        // Changed bg-white to bg-[#111827] to fix the issue in your screenshot
        $output .= "\n$indent<ul class=\"sub-menu absolute left-0 top-full hidden group-hover:block w-56 bg-[#111827] border-t-2 border-purple-500 shadow-xl py-2 z-50 rounded-b-lg animate-slide-down overflow-hidden\">\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $has_children = in_array('menu-item-has-children', $classes);
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $output .= '<li class="' . esc_attr($class_names) . ' relative group">';

        $title = apply_filters('the_title', $item->title, $item->ID);
        
        // High-contrast badges for dark background
        $badges = ['{New}' => 'bg-emerald-500 text-white', '{Top}' => 'bg-rose-500 text-white', '{Best}' => 'bg-amber-500 text-white'];

        foreach ($badges as $tag => $color_class) {
            if (strpos($title, $tag) !== false) {
                $clean_tag = str_replace(['{', '}'], '', $tag);
                $badge_html = '<span class="absolute -top-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ' . $color_class . ' shadow-sm">' . $clean_tag . '</span>';
                $title = str_replace($tag, '', $title) . $badge_html;
            }
        }

        if ($has_children && $depth === 0) {
            $title .= ' <svg class="w-4 h-4 ml-1 opacity-70 group-hover:rotate-180 transition-transform duration-300 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>';
        }

        $attributes = !empty($item->url) ? ' href="' . esc_url($item->url) . '"' : '';
        
        // Link logic: depth > 0 is the submenu link; depth 0 is the main top nav
        $link_class = ($depth > 0) 
            ? 'block px-5 py-3 text-sm text-white hover:bg-white/5 transition-colors' 
            : 'flex items-center text-white hover:text-purple-400 font-semibold px-4 py-2 transition-colors';
            
        $output .= '<a' . $attributes . ' class="' . $link_class . '">' . $args->link_before . $title . $args->link_after . '</a>';
    }
}

/**
 * Social Links Helper (Matches Customizer Social Media Section)
 */
function spin_pulse_get_social_links()
{
    $platforms = ['facebook', 'twitter', 'instagram', 'youtube', 'linkedin', 'pinterest', 'tiktok'];
    $output = '';

    foreach ($platforms as $platform) {
        $url = get_theme_mod("spin_pulse_social_{$platform}");
        if ($url) {
            $output .= sprintf(
                '<a href="%s" class="social-icon-%s hover:opacity-80 transition-opacity" target="_blank" rel="noopener">',
                esc_url($url),
                esc_attr($platform)
            );
            // Dynamic SVG selection or generic icon if font-awesome is used
            $output .= '<span class="sr-only">' . ucfirst($platform) . '</span>';
            $output .= '</a>';
        }
    }
    return $output;
}

/**
 * Customizer Dynamic CSS.
 */
/**
 * Customizer Dynamic CSS.
 */
function spin_pulse_dynamic_css()
{
    // Header & Submenu variables (Existing)
    $h_bg = get_theme_mod('spin_pulse_header_bg_color', '#111827');
    $h_text = get_theme_mod('spin_pulse_menu_link_color', '#334155');
    $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#ffffff');
    $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#334155');
    $sub_hover = get_theme_mod('spin_pulse_submenu_hover_color', '#1e40af');

    // Footer variables (New)
    $f_bg = get_theme_mod('spin_pulse_footer_bg_color', '#000000');
    $f_text = get_theme_mod('spin_pulse_footer_text_color', '#ffffff');
    $f_link = get_theme_mod('spin_pulse_footer_link_color', '#ffffff');
    $f_hover = get_theme_mod('spin_pulse_footer_hover_color', '#fbbf24');

    ?>
    <style type="text/css">
        /* Header Logic */
        #masthead {
            background-color:
                <?php echo esc_attr($h_bg); ?>
                !important;
        }

        .main-menu-link,
        .site-title a {
            color:
                <?php echo esc_attr($h_text); ?>
                !important;
        }

        .sub-menu {
            background-color:
                <?php echo esc_attr($sub_bg); ?>
                !important;
        }

        .sub-menu-link {
            color:
                <?php echo esc_attr($sub_text); ?>
                !important;
        }

        .sub-menu-link:hover {
            color:
                <?php echo esc_attr($sub_hover); ?>
                !important;
        }

        /* Footer Logic - Overriding Tailwind classes */
        #colophon.site-footer {
            background-color:
                <?php echo esc_attr($f_bg); ?>
                !important;
            color:
                <?php echo esc_attr($f_text); ?>
                !important;
            border-top-color: rgba(255, 255, 255, 0.1);
        }

        #colophon.site-footer a,
        #colophon.site-footer .footer-navigation span {
            color:
                <?php echo esc_attr($f_link); ?>
                !important;
        }

        #colophon.site-footer a:hover,
        #colophon.site-footer .footer-navigation span:hover {
            color:
                <?php echo esc_attr($f_hover); ?>
                !important;
        }
    </style>
    <?php
}
add_action('wp_head', 'spin_pulse_dynamic_css', 100);


require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';

/**
 * --- SPIN PULSE OPTIONS PAGE ---
 */
add_action('admin_menu', 'spin_pulse_register_options_menu');
function spin_pulse_register_options_menu()
{
    add_menu_page('Spin Pulse', 'Spin Pulse', 'manage_options', 'spin-pulse-options', 'spin_pulse_hero_page_html', 'dashicons-admin-appearance', 59);
    add_submenu_page('spin-pulse-options', 'Hero Settings', 'Homepage Hero', 'manage_options', 'spin-pulse-options', 'spin_pulse_hero_page_html');
}

function spin_pulse_hero_page_html()
{
    if (!current_user_can('manage_options'))
        return;
    ?>
    <div class="wrap">
        <h1>Homepage Hero Settings</h1>
        <form action="options.php" method="post">
            <?php
            settings_fields('spin_pulse_hero_group');
            do_settings_sections('hero-settings-page');
            submit_button();
            ?>
        </form>
    </div>
    <?php
}

add_action('admin_init', 'spin_pulse_register_settings');
function spin_pulse_register_settings()
{
    register_setting('spin_pulse_hero_group', 'spin_pulse_hero_settings', 'spin_pulse_sanitize_hero_settings');
    add_settings_section('hero_main_section', 'Hero Content & Colors', '__return_empty_string', 'hero-settings-page');

    add_settings_field('hero_heading', 'Main Heading', 'spin_pulse_text_field_callback', 'hero-settings-page', 'hero_main_section', ['id' => 'hero_heading', 'group' => 'spin_pulse_hero_settings']);
    add_settings_field('hero_description', 'Description', 'spin_pulse_textarea_field_callback', 'hero-settings-page', 'hero_main_section', ['id' => 'hero_description', 'group' => 'spin_pulse_hero_settings']);

    $hero_colors = [
        'hero_bg_start' => ['label' => 'Hero Background Color', 'default' => '#1e293b'], // Slate Start
        'hero_bg_mid' => ['label' => 'Hero Background Middle', 'default' => '#0B0F1A'], // Deep Navy Center
        'hero_bg_end' => ['label' => 'Hero Background End', 'default' => '#1e293b'],    // Slate End
        'hero_text_color' => ['label' => 'Hero Text Color', 'default' => '#FFFFFF'],
    ];

    foreach ($hero_colors as $id => $data) {
        add_settings_field($id, $data['label'], 'spin_pulse_color_field_callback', 'hero-settings-page', 'hero_main_section', [
            'id' => $id,
            'group' => 'spin_pulse_hero_settings',
            'default' => $data['default']
        ]);
    }

    for ($i = 1; $i <= 4; $i++) {
        $section_id = "hero_card_{$i}_section";
        add_settings_section($section_id, "Card $i Settings", '__return_empty_string', 'hero-settings-page');
        add_settings_field("hero_card{$i}_badge", "Card $i Badge", 'spin_pulse_text_field_callback', 'hero-settings-page', $section_id, ['id' => "hero_card{$i}_badge", 'group' => 'spin_pulse_hero_settings', 'desc' => 'e.g. HOT']);
        add_settings_field("hero_card{$i}_title", "Card $i Title", 'spin_pulse_text_field_callback', 'hero-settings-page', $section_id, ['id' => "hero_card{$i}_title", 'group' => 'spin_pulse_hero_settings']);
        add_settings_field("hero_card{$i}_link", "Card $i Link", 'spin_pulse_text_field_callback', 'hero-settings-page', $section_id, ['id' => "hero_card{$i}_link", 'group' => 'spin_pulse_hero_settings']);
    }
}

function spin_pulse_text_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : '';
    $desc = !empty($args['desc']) ? '<p class="description">' . esc_html($args['desc']) . '</p>' : '';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" class="regular-text" />';
    echo $desc;
}

function spin_pulse_textarea_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_textarea($options[$args['id']]) : '';
    echo '<textarea id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" rows="5" class="large-text">' . $value . '</textarea>';
}

function spin_pulse_color_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : $args['default'];
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" class="spin-pulse-color-picker" data-default-color="' . esc_attr($args['default']) . '" />';
}

function spin_pulse_sanitize_hero_settings($input)
{
    $sanitized = [];
    if (!is_array($input))
        return $sanitized;
    foreach ($input as $key => $value) {
        if (strpos($key, 'color') !== false)
            $sanitized[$key] = sanitize_hex_color($value);
        elseif ($key === 'hero_description')
            $sanitized[$key] = wp_kses_post($value);
        elseif (strpos($key, 'link') !== false)
            $sanitized[$key] = esc_url_raw($value);
        else
            $sanitized[$key] = sanitize_text_field($value);
    }
    return $sanitized;
}

add_action('admin_enqueue_scripts', 'spin_pulse_enqueue_options_scripts');
function spin_pulse_enqueue_options_scripts($hook)
{
    if ('toplevel_page_spin-pulse-options' !== $hook)
        return;
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_add_inline_script('wp-color-picker', 'jQuery(document).ready(function($){ $(".spin-pulse-color-picker").wpColorPicker(); });');
}