<?php
/**
 * The template for displaying comments – Casino style
 *
 * @package Spin_Pulse
 */

if ( post_password_required() ) {
	return;
}
?>

<div id="comments" class="sp-comments-area">

	<?php if ( have_comments() ) : ?>
		<h2 class="sp-comments-title">
			<?php
			$comment_count = get_comments_number();
			if ( '1' === $comment_count ) {
				esc_html_e( '1 Discussion', 'spin-pulse' );
			} else {
				printf(
					esc_html( _nx( '%s Discussion', '%s Discussions', $comment_count, 'comments title', 'spin-pulse' ) ),
					number_format_i18n( $comment_count )
				);
			}
			?>
		</h2>

		<?php the_comments_navigation(); ?>

		<ol class="comment-list">
			<?php
			wp_list_comments( array(
				'style'       => 'ol',
				'short_ping'  => true,
				'avatar_size' => 60,
				'reply_text'  => __( 'Reply', 'spin-pulse' ),
			) );
			?>
		</ol>

		<?php
		the_comments_navigation();
		if ( ! comments_open() ) : ?>
			<p class="no-comments"><?php esc_html_e( 'Comments are closed.', 'spin-pulse' ); ?></p>
		<?php endif; ?>

	<?php endif; ?>

	<?php
	comment_form( array(
		'class_form'           => 'sp-comment-form',
		'title_reply_before'   => '<h2 id="reply-title" class="comment-reply-title">',
		'title_reply_after'    => '</h2>',
		'submit_button'        => '<button name="%1$s" type="submit" id="%2$s" class="%3$s">%4$s</button>',
		'submit_field'         => '<p class="form-submit">%1$s %2$s</p>',
		'comment_notes_before' => '<p class="comment-notes">' . esc_html__( 'Your email address will not be published.', 'spin-pulse' ) . '</p>',
	) );
	?>

</div>