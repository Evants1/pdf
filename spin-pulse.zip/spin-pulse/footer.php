<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Spin_Pulse
 */
?>

	</div><footer id="colophon" class="site-footer bg-[#0B0F1A] text-white/70 py-10 border-t border-white/5">
        <div class="max-w-main mx-auto px-6 lg:px-12">
            <div class="flex flex-col md:flex-row items-center justify-between text-sm gap-6">
                <div class="text-center md:text-left">
                    <?php echo function_exists('spin_pulse_get_footer_copyright') ? wp_kses_post(spin_pulse_get_footer_copyright()) : sprintf(esc_html__('&copy; %s %s', 'spin-pulse'), date('Y'), get_bloginfo('name')); ?>
                </div>

                <nav class="footer-navigation">
                    <?php wp_nav_menu( array(
                        'theme_location' => 'footer-menu',
                        'container'      => false,
                        'menu_class'     => 'flex flex-wrap justify-center md:justify-end gap-x-8 gap-y-3 font-semibold uppercase tracking-widest text-[11px]',
                        'fallback_cb'    => '__return_false',
                        'depth'          => 1,
                        'link_before'    => '<span class="hover:text-brand-gold transition-colors duration-300">',
                        'link_after'     => '</span>',
                    ) ); ?>
                </nav>
            </div>
        </div>
    </footer>

</div><?php wp_footer(); ?>
</body>
</html>