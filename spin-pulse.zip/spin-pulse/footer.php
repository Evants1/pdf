<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Spin_Pulse
 */
?>

	<footer id="colophon" class="site-footer bg-casino-navy text-white/90 py-10 border-t border-slate-700">
		<div class="max-w-[1600px] mx-auto px-6 lg:px-8">

			<div class="flex flex-col md:flex-row items-center justify-between text-sm gap-6">

				<!-- Left side: Dynamic Copyright from Customizer -->
				<div class="text-center md:text-left">
					<?php echo spin_pulse_get_footer_copyright(); ?>
				</div>

				<!-- Right side: Dynamic Footer Menu (created in WP Admin → Appearance → Menus) -->
				<nav class="footer-navigation" aria-label="<?php esc_attr_e( 'Footer Menu', 'spin-pulse' ); ?>">
					<?php
					wp_nav_menu( array(
						'theme_location'  => 'footer-menu',
						'container'       => false,
						'menu_class'      => 'flex flex-wrap justify-center md:justify-end gap-x-8 gap-y-3',
						'fallback_cb'     => '__return_false', // Don't show anything if no menu is assigned
						'depth'           => 1,
						'link_before'     => '<span class="hover:text-casino-gold transition-colors duration-200">',
						'link_after'      => '</span>',
					) );
					?>
				</nav>

			</div><!-- .flex -->

		</div><!-- .container -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<?php wp_footer(); ?>

</body>
</html>