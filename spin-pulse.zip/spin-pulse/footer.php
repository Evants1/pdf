<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @package Spin_Pulse
 */

// Fetch Dynamic Options from your backend dashboard
$f_opts = get_option('spin_pulse_footer_settings', array());

// Fetch dynamic column titles (with fallback defaults) - THEMEFOREST FIX: Added translation functions
$col1_title = !empty($f_opts['footer_col_1_title']) ? $f_opts['footer_col_1_title'] : esc_html__('About us', 'spin-pulse');
$col2_title = !empty($f_opts['footer_col_2_title']) ? $f_opts['footer_col_2_title'] : esc_html__('Casino reviews', 'spin-pulse');
$col3_title = !empty($f_opts['footer_col_3_title']) ? $f_opts['footer_col_3_title'] : esc_html__('Game guides', 'spin-pulse');
$col4_title = !empty($f_opts['footer_col_4_title']) ? $f_opts['footer_col_4_title'] : esc_html__('News', 'spin-pulse');
$col5_title = !empty($f_opts['footer_col_5_title']) ? $f_opts['footer_col_5_title'] : esc_html__('Resources', 'spin-pulse');

// Defaults matching the Casino.org style screenshot
$f_logo = isset($f_opts['footer_logo']) && !empty($f_opts['footer_logo']) ? $f_opts['footer_logo'] : ''; 
$f_desc = isset($f_opts['footer_desc']) && !empty($f_opts['footer_desc']) ? $f_opts['footer_desc'] : esc_html__("Spin Pulse is a trusted online gaming site offering casino news, reviews, and guides since 2004.", 'spin-pulse');
$addr_title = isset($f_opts['address_title']) && !empty($f_opts['address_title']) ? $f_opts['address_title'] : esc_html__('Correspondence Addresses', 'spin-pulse');

// THEMEFOREST FIX: Use wp_kses to allow the <br> tags in the default translation string
$addr_1 = isset($f_opts['address_1']) && !empty($f_opts['address_1']) ? nl2br($f_opts['address_1']) : wp_kses("27 Willowbank Road,<br>Glasgow,<br>EH12 9DQ, G12 8XY, United Kingdom", array('br' => array()));
$addr_2 = isset($f_opts['address_2']) && !empty($f_opts['address_2']) ? nl2br($f_opts['address_2']) : wp_kses("742 Evergreen Terrace,<br>Suite 210, Springfield,<br>IL 62704, United States", array('br' => array()));

// Capture Menu Outputs to check if they are empty
$menu1_html = wp_nav_menu(array('theme_location' => 'footer-menu-1', 'container' => false, 'menu_class' => 'sp-footer-menu', 'echo' => false, 'fallback_cb' => '__return_false'));
$menu2_html = wp_nav_menu(array('theme_location' => 'footer-menu-2', 'container' => false, 'menu_class' => 'sp-footer-menu', 'echo' => false, 'fallback_cb' => '__return_false'));
$menu3_html = wp_nav_menu(array('theme_location' => 'footer-menu-3', 'container' => false, 'menu_class' => 'sp-footer-menu', 'echo' => false, 'fallback_cb' => '__return_false'));
$menu5_html = wp_nav_menu(array('theme_location' => 'footer-menu-5', 'container' => false, 'menu_class' => 'sp-footer-menu', 'echo' => false, 'fallback_cb' => '__return_false'));

// Capture News Post Data
$news_query = new WP_Query(array('post_type' => 'post', 'posts_per_page' => 5, 'post_status' => 'publish'));
$has_news = $news_query->have_posts();

// Calculate Active Columns to adjust the grid layout perfectly
$active_cols = 0;
if (!empty($menu1_html)) $active_cols++;
if (!empty($menu2_html)) $active_cols++;
if (!empty($menu3_html)) $active_cols++;
if ($has_news) $active_cols++;
if (!empty($menu5_html)) $active_cols++;

$grid_cols = $active_cols > 0 ? $active_cols : 1; // Fallback to 1 to prevent CSS errors

// Fetch Trust Badges
$badges = array();
for ($i = 1; $i <= 6; $i++) {
    if (!empty($f_opts["footer_badge_$i"])) {
        $badges[] = $f_opts["footer_badge_$i"];
    }
}
?>

    </div><footer id="colophon" class="sp-footer-wrapper">
        <div class="sp-footer-container">
            
            <?php if ($active_cols > 0) : ?>
            <div class="sp-footer-top-grid" style="grid-template-columns: repeat(<?php echo esc_attr($grid_cols); ?>, 1fr);">
                
                <?php if (!empty($menu1_html)): ?>
                <div class="sp-footer-col">
                    <h4 class="sp-footer-heading"><?php echo esc_html($col1_title); ?></h4>
                    <?php echo wp_kses_post($menu1_html); ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($menu2_html)): ?>
                <div class="sp-footer-col">
                    <h4 class="sp-footer-heading"><?php echo esc_html($col2_title); ?></h4>
                    <?php echo wp_kses_post($menu2_html); ?>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($menu3_html)): ?>
                <div class="sp-footer-col">
                    <h4 class="sp-footer-heading"><?php echo esc_html($col3_title); ?></h4>
                    <?php echo wp_kses_post($menu3_html); ?>
                </div>
                <?php endif; ?>
                
                <?php if ($has_news): ?>
                <div class="sp-footer-col">
                    <h4 class="sp-footer-heading"><?php echo esc_html($col4_title); ?></h4>
                    <ul class="sp-footer-menu">
                        <?php 
                        while ($news_query->have_posts()) : $news_query->the_post(); ?>
                            <li><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
                        <?php
                        endwhile;
                        wp_reset_postdata();
                        ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if (!empty($menu5_html)): ?>
                <div class="sp-footer-col">
                    <h4 class="sp-footer-heading"><?php echo esc_html($col5_title); ?></h4>
                    <?php echo wp_kses_post($menu5_html); ?>
                </div>
                <?php endif; ?>
            </div>
            
            <div class="sp-footer-divider"></div>
            <?php endif; ?>

            <div class="sp-footer-bottom-grid">
                
                <div class="sp-footer-brand">
                    <?php if ($f_logo): ?>
                        <img src="<?php echo esc_url($f_logo); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?> Logo" class="sp-footer-logo">
                    <?php else: ?>
                        <h2 class="sp-footer-logo-text" style="margin:0; font-weight:800; font-size:24px; color:inherit;"><?php echo esc_html(get_bloginfo('name')); ?></h2>
                    <?php endif; ?>
                </div>

                <div class="sp-footer-about">
                    <p class="sp-footer-desc"><?php echo esc_html($f_desc); ?></p>
                    <div class="sp-footer-socials">
                        <?php if(!empty($f_opts['social_tw'])): ?><a href="<?php echo esc_url($f_opts['social_tw']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-x-twitter"></i></a><?php endif; ?>
                        <?php if(!empty($f_opts['social_fb'])): ?><a href="<?php echo esc_url($f_opts['social_fb']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                        <?php if(!empty($f_opts['social_yt'])): ?><a href="<?php echo esc_url($f_opts['social_yt']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-youtube"></i></a><?php endif; ?>
                        <?php if(!empty($f_opts['social_ig'])): ?><a href="<?php echo esc_url($f_opts['social_ig']); ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram"></i></a><?php endif; ?>
                        <?php if(!empty($f_opts['social_blog'])): ?><a href="<?php echo esc_url($f_opts['social_blog']); ?>" target="_blank" rel="noopener noreferrer" class="sp-social-blog-icon"><i class="fas fa-list-alt"></i> <span><?php esc_html_e('BLOG', 'spin-pulse'); ?></span></a><?php endif; ?>
                    </div>
                </div>

                <div class="sp-footer-address-block">
                    <h4 class="sp-footer-address-title"><i class="fas fa-envelope"></i> <?php echo esc_html($addr_title); ?></h4>
                    <div class="sp-footer-address-cols">
                        <div class="sp-footer-address"><?php echo wp_kses_post($addr_1); ?></div>
                        <div class="sp-footer-address"><?php echo wp_kses_post($addr_2); ?></div>
                    </div>
                </div>

            </div>

            <div class="sp-footer-divider" style="margin-top: 40px; margin-bottom: 20px;"></div>

            <?php if (!empty($badges)): ?>
            <div class="sp-footer-badges-row">
                <?php foreach ($badges as $badge_url): ?>
                    <img src="<?php echo esc_url($badge_url); ?>" alt="<?php esc_attr_e('Compliance Badge', 'spin-pulse'); ?>" class="sp-footer-badge-img">
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <div class="sp-footer-copyright-row">
                <div class="sp-footer-copy-text">
                    <?php echo function_exists('spin_pulse_get_footer_copyright') ? wp_kses_post(spin_pulse_get_footer_copyright()) : sprintf(esc_html__('&copy; %1$s %2$s', 'spin-pulse'), date('Y'), get_bloginfo('name')); ?>
                </div>
            </div>

        </div>
    </footer>

</div><?php wp_footer(); ?>
</body>
</html>