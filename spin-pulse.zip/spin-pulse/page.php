<?php
/**
 * The template for displaying all pages
 *
 * Optimized for Spin Pulse (Casino Affiliate)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-white">

    <?php
    while ( have_posts() ) :
        the_post();
        ?>

        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
            
            <?php /** 1. Professional Page Header (Hero Section) **/ ?>
            <header class="entry-header bg-slate-900 py-16 mb-12 border-b border-casino-gold/20">
                <div class="container mx-auto px-4">
                    <div class="max-w-4xl mx-auto text-center lg:text-left">
                        <?php the_title( '<h1 class="entry-title text-4xl lg:text-5xl font-extrabold text-white tracking-tight mb-4 leading-tight">', '</h1>' ); ?>
                        
                        <?php if ( has_excerpt() ) : ?>
                            <div class="entry-excerpt text-xl text-slate-300 leading-relaxed font-medium">
                                <?php the_excerpt(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </header>

            <?php /** 2. Content Area **/ ?>
            <div class="entry-content container mx-auto px-4 pb-16">
                <div class="max-w-5xl mx-auto prose prose-slate prose-lg lg:prose-xl prose-headings:font-bold prose-a:text-casino-blue hover:prose-a:text-casino-gold transition-all">
                    <?php
                    the_content();

                    // ThemeForest Requirement: Pagination for split posts
                    wp_link_pages(
                        array(
                            'before' => '<div class="page-links mt-8 py-4 border-t border-slate-100 font-semibold">' . esc_html__( 'Pages:', 'spin-pulse' ),
                            'after'  => '</div>',
                        )
                    );
                    ?>
                </div>
            </div>

            <?php /** 3. Comments Section **/ ?>
            <?php if ( comments_open() || get_comments_number() ) : ?>
                <footer class="entry-footer bg-slate-50 py-16 border-t border-slate-200">
                    <div class="container mx-auto px-4 max-w-4xl">
                        <?php comments_template(); ?>
                    </div>
                </footer>
            <?php endif; ?>

        </article>

    <?php endwhile; ?>

</main>

<?php
get_footer();