<?php
/**
 * The template for displaying all pages
 */
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-slate-50">
	<?php if (is_front_page()):
		$options = get_option('spin_pulse_hero_settings', []);

		// Logic & Fallbacks
		$heading = !empty($options['hero_heading']) ? $options['hero_heading'] : 'Find the best';
		$description = !empty($options['hero_description']) ? $options['hero_description'] : "Since 1995...";
		$badge_text = !empty($options['hero_badge_text']) ? $options['hero_badge_text'] : 'FREE';

		// Colors
		$bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#7c3aed';
		$bg_mid = !empty($options['hero_bg_mid']) ? $options['hero_bg_mid'] : '#6d28d9';
		$bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#5b21b6';
		$text_color = !empty($options['hero_text_color']) ? $options['hero_text_color'] : '#f3e8ff';

		// Badge Colors
		$badge_bg = !empty($options['badge_bg_color']) ? $options['badge_bg_color'] : '#f97316';
		$badge_txt = !empty($options['badge_text_color']) ? $options['badge_text_color'] : '#ffffff';
		?>

		<section class="w-full py-16 md:py-24 lg:py-32"
			style="background: linear-gradient(to right, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_mid); ?>, <?php echo esc_attr($bg_end); ?>);">
			<div class="max-w-7xl mx-auto px-6 lg:px-8">
				<div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

					<div>
						<h1 class="text-4xl md:text-5xl font-extrabold text-white leading-tight">
							<?php echo esc_html($heading); ?>
						</h1>
						<p class="mt-6 text-lg max-w-xl" style="color: <?php echo esc_attr($text_color); ?>;">
							<?php echo wp_kses_post(nl2br($description)); ?>
						</p>
					</div>

					<div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
						<?php for ($i = 1; $i <= 4; $i++):
							// Fetch specific data for this card
							$c_title = !empty($options["hero_card{$i}_title"]) ? $options["hero_card{$i}_title"] : "Card $i";
							$c_link = !empty($options["hero_card{$i}_link"]) ? $options["hero_card{$i}_link"] : "#";
							$c_badge = !empty($options["hero_card{$i}_badge"]) ? $options["hero_card{$i}_badge"] : ""; // Individual badge
							?>
							<a href="<?php echo esc_url($c_link); ?>"
								class="group bg-indigo-950/40 backdrop-blur-sm border border-white/10 rounded-2xl p-6 shadow-lg hover:bg-indigo-900/50 transition duration-300">
								<div class="flex items-center justify-between">
									<div>
										<?php
										// Only render the badge if the user typed something in the backend
										if (!empty($c_badge)): ?>
											<span
												class="inline-block text-[10px] font-black px-2 py-1 rounded mb-3 uppercase tracking-wider"
												style="background-color: <?php echo esc_attr($badge_bg); ?>; color: <?php echo esc_attr($badge_txt); ?>;">
												<?php echo esc_html($c_badge); ?>
											</span>
										<?php endif; ?>

										<span class="text-white font-semibold text-lg block">
											<?php echo esc_html($c_title); ?>
										</span>
									</div>
									<span
										class="text-white text-2xl group-hover:translate-x-2 transition-transform duration-300">→</span>
								</div>
							</a>
						<?php endfor; ?>
					</div>
				</div>
			</div>
		</section>
	<?php endif; ?>

</main>