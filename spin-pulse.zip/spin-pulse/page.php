<?php
/**
 * The template for displaying all static pages
 *
 * @package SpinPulse
 */

get_header();

// --- Dynamic Calculations ---
$current_post_id = get_queried_object_id();
$sp_content = get_post_field('post_content', $current_post_id);
$sp_word_count = str_word_count(strip_tags($sp_content));
$sp_reading_time = max(1, ceil($sp_word_count / 200));

$sp_views = get_post_meta($current_post_id, 'post_views_count', true) ?: '0';

$current_author_id = get_post_field('post_author', $current_post_id);
$current_author_name = get_the_author_meta('display_name', $current_author_id);
?>

<main id="primary" class="site-main min-h-screen bg-white">
    
    <?php if (is_front_page()): 
        $options = get_option('spin_pulse_hero_settings', array());

        $heading = !empty($options['hero_heading']) ? $options['hero_heading'] : esc_html__('Find the best', 'spin-pulse');
        $description = !empty($options['hero_description']) ? $options['hero_description'] : esc_html__('Since 1995...', 'spin-pulse');
        $bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
        $bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
        $h_color = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
        $desc_color = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

        $bg_image = !empty($options['hero_bg_image']) ? $options['hero_bg_image'] : '';
        $overlay_color = !empty($options['hero_bg_overlay_color']) ? $options['hero_bg_overlay_color'] : '#000000';
        $overlay_opacity = isset($options['hero_bg_overlay_opacity']) ? floatval($options['hero_bg_overlay_opacity']) : 0.5;
        $avatar_url = get_avatar_url($current_author_id, array('size' => 96));
    ?>
	
<section class="sp-hp-hero-section">
    <div class="sp-hp-hero-container">
        
        <div class="sp-hp-hero-content-column">
            <h1>Global Online Casino 2026</h1>
            <p class="sp-hp-hero-subtitle">Our guide focuses on what international players need: secure payment methods, huge game variety, transparent terms, and above all—verifiable game fairness and player security.</p>
            
            <div class="sp-hp-hero-authors-container">
                
                <div class="sp-hp-hero-authors-container">
    
    <div class="sp-hp-hero-author-card">
        <div class="sp-hp-hero-avatar-wrapper">
            <img src="/wp-content/uploads/2026/03/author2.webp" alt="Sarah Sterling">
            <div class="sp-hp-hero-status-dot">
                <span class="sp-hp-hero-status-ping"></span>
            </div>
        </div>

        <div class="sp-hp-hero-author-info">
            <p class="sp-hp-hero-label">Authored By</p>
            
            <p class="sp-hp-hero-name">
                Sarah Sterling
                <span class="sp-hp-hero-verified-badge">Verified</span>
            </p>
            
            <p class="sp-hp-hero-title">Casino Review Specialist</p>
            <p class="sp-hp-hero-date">Published: March 10, 2026</p>
			<div class="sp-hp-hero-socials">
            <a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-facebook-f"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-x-twitter"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-instagram"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-linkedin-in"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-youtube"></i></a>
        </div>
        </div>
    </div>

    <div class="sp-hp-hero-author-card">
        <div class="sp-hp-hero-avatar-wrapper">
            <img src="https://navajowhite-ibis-659787.hostingersite.com/wp-content/uploads/2026/03/author1.jpg" alt="Deric Clarke">
            <div class="sp-hp-hero-status-dot">
                <span class="sp-hp-hero-status-ping"></span>
            </div>
        </div>

        <div class="sp-hp-hero-author-info">
            <p class="sp-hp-hero-label">Reviewed By</p>
            
            <p class="sp-hp-hero-name">
                Deric Clarke
                <span class="sp-hp-hero-verified-badge">Verified</span>
            </p>
            
            <p class="sp-hp-hero-title">Fair Play Auditor</p>
            <p class="sp-hp-hero-date">Updated: March 12, 2026</p>
			<div class="sp-hp-hero-socials">
            <a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-facebook-f"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-x-twitter"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-instagram"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-linkedin-in"></i></a>
			<a href="#" class="sp-hp-hero-social-icon"><i class="fab fa-youtube"></i></a>
        </div>
        </div>
    </div>

</div>

            </div>

            <div class="sp-hp-hero-features-grid">
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container">
                        <i class="fas fa-map-marked-alt"></i>
                    </div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title">Global Casino Guide</p>
                        <p class="sp-hp-hero-feature-desc">Multi-Currency Support</p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container">
                        <i class="fas fa-search-dollar"></i>
                    </div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title">Comprehensive Reviews</p>
                        <p class="sp-hp-hero-feature-desc">100+ Brands Analyzed</p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container">
                        <i class="fas fa-chart-line"></i>
                    </div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title">Game Odds Analytics</p>
                        <p class="sp-hp-hero-feature-desc">RTP & Volatility Reports</p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container">
                        <i class="fas fa-gift"></i>
                    </div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title">Exclusive Offers Hub</p>
                        <p class="sp-hp-hero-feature-desc">Updated Daily Bonuses</p>
                    </div>
                </div>
            </div>

            <div class="sp-hp-hero-trust-badges">
                <div class="sp-hp-hero-trust-badge-item">
                    <i class="fas fa-check-circle"></i>
                    <span>Licensed Solutions</span>
                </div>
                <div class="sp-hp-hero-trust-badge-item">
                    <i class="fas fa-check-circle"></i>
                    <span>Proven Fairness</span>
                </div>
                <div class="sp-hp-hero-trust-badge-item">
                    <i class="fas fa-check-circle"></i>
                    <span>Player Privacy</span>
                </div>
                <div class="sp-hp-hero-trust-badge-item">
                    <i class="fas fa-check-circle"></i>
                    <span>Global Casino Advisory</span>
                </div>
            </div>
        </div>

        <div class="sp-hp-hero-card-column">
            
            <div class="sp-hp-hero-offer-card">
                <div class="sp-hp-hero-offer-card-header">
                    <div class="sp-hp-hero-offer-badge">Exclusive Network Access</div>
                    <div class="sp-hp-hero-offer-value">UP to $8,000</div>
                </div>
                
                <div class="sp-hp-hero-card-logo-area">
                    <img src="/wp-content/uploads/2026/03/sample-logo-hero.png" alt="Casino Logo Placeholder" class="sp-hp-hero-card-logo-placeholder">
                    <p class="sp-hp-hero-card-offer-title">Premium Gaming Starter Kit</p>
                    <p class="sp-hp-hero-card-offer-details">Includes Deposit Boosts & Free Spins</p>
                </div>
                
                <a href="#" class="sp-hp-hero-cta-button">Unlock My Welcome Package</a>
                <p class="sp-hp-hero-card-footer-text"><i class="fas fa-lock" style="margin-right: 5px;"></i> Data Privacy Certified & Audited</p>
            </div>
        </div>
        
    </div>
</section>
	
	
        <section class="w-full py-10 md:py-8 lg:py-12 relative overflow-hidden">
            <?php if (!empty($bg_image)): ?>
                <div class="absolute inset-0 z-0 bg-cover bg-center" style="background-image: url('<?php echo esc_url($bg_image); ?>');"></div>
                <?php if ($overlay_opacity > 0): ?>
                    <div class="absolute inset-0 z-0" style="background-color: <?php echo esc_attr(spin_pulse_hex_to_rgba($overlay_color, $overlay_opacity)); ?>;"></div>
                <?php endif; ?>
            <?php else: ?>
                <div class="absolute inset-0 z-0" style="background: linear-gradient(135deg, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_end); ?>);"></div>
            <?php endif; ?>

            <div class="max-w-[1200px] mx-auto px-6 relative z-10">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    
                    <div class="flex flex-col">
                        <div class="flex items-center space-x-4 mb-8 group cursor-default">
                            <div class="relative">
                                <img src="<?php echo esc_url($avatar_url); ?>" alt="<?php echo esc_attr($current_author_name); ?>" class="w-14 h-14 rounded-full border-2 border-white/20 object-cover shadow-lg group-hover:border-purple-500 transition-colors duration-300">
                                <div class="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1e293b] rounded-full">
                                    <span class="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
                                </div>
                            </div>
                            <div class="flex flex-col space-y-1">
                                <div class="flex items-center gap-2">
                                    <span class="text-white font-bold text-base tracking-tight"><?php echo esc_html($current_author_name); ?></span>
                                    <span class="bg-white/10 text-white/60 text-[10px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider border border-white/5">
                                        <?php esc_html_e('Verified', 'spin-pulse'); ?>
                                    </span>
                                </div>
                                <div class="flex items-center text-white/50 text-xs font-medium space-x-2">
                                    <span><?php printf(esc_html__('Updated: %s', 'spin-pulse'), get_the_modified_date('M j, Y')); ?></span>
                                </div>
                            </div>
                        </div>

                        <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold leading-tight tracking-tight drop-shadow-sm" style="color: <?php echo esc_attr($h_color); ?>;">
                            <?php echo esc_html($heading); ?>
                        </h1>
                        <p class="mt-6 text-lg md:text-xl leading-relaxed max-w-xl font-normal opacity-90" style="color: <?php echo esc_attr($desc_color); ?>;">
                            <?php echo wp_kses_post(nl2br($description)); ?>
                        </p>
                    </div>
                    
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <?php for ($i = 1; $i <= 4; $i++):
                            $c_title = !empty($options["card{$i}_title"]) ? $options["card{$i}_title"] : sprintf(esc_html__('Card %d', 'spin-pulse'), $i);
                            $c_link = !empty($options["card{$i}_link"]) ? $options["card{$i}_link"] : "#";
                            $c_badge = !empty($options["card{$i}_badge"]) ? $options["card{$i}_badge"] : "";
                            $c_badge_bg = !empty($options["card{$i}_badge_bg"]) ? $options["card{$i}_badge_bg"] : '#7c3aed';
                        ?>
                            <a href="<?php echo esc_url($c_link); ?>" class="group relative overflow-hidden transition-all duration-500 rounded-3xl p-6 md:p-8 bg-slate-800/40 border border-white/5 hover:border-purple-500/50 hover:bg-slate-800/60 shadow-2xl backdrop-blur-sm flex flex-col">
                                <div class="flex flex-col h-full">
                                    <div class="flex-grow">
                                        <?php if (!empty($c_badge)): ?>
                                            <span class="inline-block text-[10px] font-black px-3 py-1 rounded-full mb-3 uppercase tracking-[0.1em] shadow-lg" style="background-color: <?php echo esc_attr($c_badge_bg); ?>; color: #ffffff;">
                                                <?php echo esc_html($c_badge); ?>
                                            </span>
                                        <?php endif; ?>
                                        <p class="text-white font-bold text-xl group-hover:text-purple-300 transition-colors leading-snug">
                                            <?php echo esc_html($c_title); ?>
                                        </p>
                                    </div>
                                    <div class="mt-6 flex items-center text-white/30 group-hover:text-purple-400 transition-colors">
                                        <span class="text-xs font-black uppercase tracking-widest"><?php esc_html_e('Learn More', 'spin-pulse'); ?></span>
                                        <svg class="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                                    </div>
                                </div>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </section>

    <?php else: ?>
        <section class="sp-single-hero-wrapper py-12 border-b border-slate-100 bg-slate-50">
            <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
                <div class="sp-hero-breadcrumbs mb-4 text-sm text-gray-500">
                    <a href="<?php echo home_url(); ?>" class="hover:underline">Home</a> &raquo; 
                    <span class="sp-hero-current-crumb text-gray-800"><?php the_title(); ?></span>
                </div>
                <h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-8 text-slate-900"><?php the_title(); ?></h1>
                
                <div class="sp-hero-author-box flex flex-wrap items-center gap-6">
                    <div class="flex items-center gap-4">
                        <div class="sp-hero-author-avatar">
                            <?php echo get_avatar($current_author_id, 56, '', '', array('class' => 'rounded-full border-2 border-white shadow-md')); ?>
                        </div>
                        <div class="sp-hero-author-details flex flex-col justify-center">
                            <div class="sp-hero-author-name text-slate-600">Authored By <em class="not-italic font-bold text-slate-900"><?php echo esc_html($current_author_name); ?></em></div>
                            <div class="sp-hero-author-date text-sm text-slate-500">Last Updated: <?php the_modified_date('F j, Y'); ?></div>
                        </div>
                    </div>

                    <?php
                    $tw_url = get_the_author_meta('twitter', $current_author_id);
                    $fb_url = get_the_author_meta('facebook', $current_author_id);
                    $ig_url = get_the_author_meta('instagram', $current_author_id);
                    $li_url = get_the_author_meta('linkedin', $current_author_id);
                    $yt_url = get_the_author_meta('youtube', $current_author_id);
                    ?>

                    <?php if ($tw_url || $fb_url || $ig_url || $li_url || $yt_url): ?>
                        <div class="sp-hero-author-socials ml-0 sm:ml-4 sm:pl-6 sm:border-l border-slate-300 flex items-center gap-3">
                            <?php if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #0f1419;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg></a><?php endif; ?>
                            <?php if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #1877F2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></a><?php endif; ?>
                            <?php if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #E1306C;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></a><?php endif; ?>
                            <?php if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #0A66C2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></a><?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="sp-hero-info-row flex flex-wrap gap-8 mt-8 pt-8 border-t border-slate-200">
                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                                <line x1="7" y1="7" x2="7.01" y2="7"></line>
                            </svg></div>
                        <div class="text-sm text-slate-600">Categories: <strong class="text-slate-900"><?php echo get_the_category_list(', ') ?: 'None'; ?></strong></div>
                    </div>

                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path>
                                <circle cx="12" cy="12" r="3"></circle>
                            </svg></div>
                        <div class="text-sm text-slate-600">Views: <strong class="text-slate-900"><?php echo esc_html($sp_views); ?></strong></div>
                    </div>

                    <div class="flex items-center gap-3">
                        <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg></div>
                        <div class="text-sm text-slate-600">Read Time: <strong class="text-slate-900"><?php echo esc_html($sp_reading_time); ?> min</strong></div>
                    </div>
                </div>

            </div>
        </section>
    <?php endif; ?>

    <div class="py-16">
        <div class="max-w-[1200px] mx-auto px-6 w-full">
            <?php if (have_posts()): while (have_posts()): the_post(); ?>
                
                <article id="post-<?php the_ID(); ?>" <?php post_class('prose prose-slate prose-lg sp-single-content max-w-none'); ?>>
                    <?php 
                        the_content(); 
                        
                        wp_link_pages( array(
                            'before' => '<div class="page-links mt-8">' . esc_html__( 'Pages:', 'spin-pulse' ),
                            'after'  => '</div>',
                        ) );
                    ?>
                </article>
                
                <?php 
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;
                ?>

            <?php endwhile; wp_reset_postdata(); else: ?>
                <p><?php esc_html_e('No content found.', 'spin-pulse'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <?php if (get_the_author_meta('description', $current_author_id)): ?>
        <div class="sp-author-bio-wrapper">
            <div class="sp-author-bio-container">
                <div class="sp-author-bio-avatar">
                    <?php echo get_avatar($current_author_id, 120, '', '', array('class' => 'sp-author-avatar-img')); ?>
                </div>
                <div class="sp-author-bio-content">
                    <h3 class="sp-author-bio-title">
                        <span class="sp-author-bio-greeting"><?php esc_html_e('Written by', 'spin-pulse'); ?></span>
                        <?php echo esc_html($current_author_name); ?>
                    </h3>
                    <div class="sp-author-bio-text">
                        <?php echo wp_kses_post(wpautop(get_the_author_meta('description', $current_author_id))); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <section class="sp-recent-post-full-wrapper">
        <div class="sp-recent-post-container">
            <div class="sp-recent-post-main">
                <div class="sp-recent-post-header">
                    <h2 class="sp-recent-post-title-main"><?php esc_html_e('Recent Posts', 'spin-pulse'); ?></h2>
                    <div class="sp-recent-post-categories">
                        <?php
                        $all_cats = get_categories(array('hide_empty' => true));
                        if (!empty($all_cats)) {
                            foreach ($all_cats as $cat) {
                                echo '<a href="' . esc_url(get_category_link($cat->term_id)) . '" class="sp-recent-post-cat-link">' . esc_html($cat->name) . '</a>';
                            }
                        }
                        ?>
                    </div>
                </div>

                <div class="sp-recent-post-list">
                    <?php
                    $recent_args = array('post_type' => 'post', 'posts_per_page' => 4, 'post_status' => 'publish', 'post__not_in' => array($current_post_id));
                    $recent_query = new WP_Query($recent_args);
                    if ($recent_query->have_posts()):
                        while ($recent_query->have_posts()):
                            $recent_query->the_post();

                            $post_content = get_post_field('post_content', get_the_ID());
                            $reading_time = max(1, ceil(str_word_count(strip_tags($post_content)) / 200));
                            $cats = get_the_category();
                            $cat_name = !empty($cats) ? $cats[0]->name : 'News';
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                            ?>
                            <div class="sp-recent-post-item">
                                <a href="<?php the_permalink(); ?>" class="sp-recent-post-thumb">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('medium_large');
                                    } else {
                                        echo '<div class="sp-recent-post-placeholder"></div>';
                                    } ?>
                                </a>
                                <div class="sp-recent-post-info">
                                    <div class="sp-recent-post-meta-top">
                                        <span class="sp-recent-post-cat-name"><?php echo esc_html($cat_name); ?></span>
                                        <span class="sp-recent-post-date"><?php echo get_the_date('M j, Y'); ?></span>
                                    </div>
                                    <h3 class="sp-recent-post-heading">
                                        <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                    </h3>
                                    <div class="sp-recent-post-author-row">
                                        <a href="<?php echo $author_url; ?>">
                                            <?php echo get_avatar($author_id, 24, '', '', array('class' => 'sp-recent-post-author-avatar')); ?>
                                        </a>
                                        <a href="<?php echo $author_url; ?>"
                                            class="sp-recent-post-author-name"><?php the_author(); ?></a>
                                        <span class="sp-recent-post-dot">&bull;</span>
                                        <span><?php echo $reading_time; ?> min read</span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata(); endif; ?>
                </div>
            </div>

            <div class="sp-recent-post-sidebar-wrapper">
                <h3 class="sp-recent-post-sidebar-title"><?php esc_html_e('Discover our blogs', 'spin-pulse'); ?></h3>
                <div class="sp-recent-post-sidebar-list">
                    <?php
                    $discover_args = array('post_type' => 'post', 'posts_per_page' => 3, 'offset' => 3, 'post_status' => 'publish', 'post__not_in' => array($current_post_id));
                    $discover_query = new WP_Query($discover_args);
                    if ($discover_query->have_posts()):
                        while ($discover_query->have_posts()):
                            $discover_query->the_post();
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                            ?>
                            <div class="sp-recent-post-sidebar-item">
                                <a href="<?php the_permalink(); ?>" class="sp-recent-post-sidebar-thumb">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('thumbnail');
                                    } else {
                                        echo '<div class="sp-recent-post-placeholder"></div>';
                                    } ?>
                                </a>
                                <div class="sp-recent-post-sidebar-info">
                                    <h4 class="sp-recent-post-sidebar-heading"><a
                                            href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 8, '...'); ?></a>
                                    </h4>
                                    <div class="sp-recent-post-sidebar-excerpt">
                                        <?php echo wp_trim_words(get_the_excerpt(), 8, '...'); ?>
                                    </div>
                                    <div class="sp-recent-post-sidebar-meta">
                                        <div class="sp-recent-post-sidebar-author-row">
                                            <a href="<?php echo $author_url; ?>">
                                                <?php echo get_avatar($author_id, 16, '', '', array('class' => 'sp-recent-post-sidebar-avatar')); ?>
                                            </a>
                                            <a
                                                href="<?php echo $author_url; ?>"><?php echo wp_trim_words(get_the_author(), 2, ''); ?></a>
                                            <span>&bull;</span>
                                            <span><?php echo get_the_date('M j, Y'); ?></span>
                                        </div>
                                        <a href="<?php the_permalink(); ?>" class="sp-recent-post-sidebar-readlink"><?php esc_html_e('Read', 'spin-pulse'); ?> &rarr;</a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata(); endif; ?>
                </div>
            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>