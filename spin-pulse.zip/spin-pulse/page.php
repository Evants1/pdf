<?php
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-slate-50">
    <?php
    while ( have_posts() ) :
        the_post();

        // No max-w-7xl here → content can now go edge-to-edge
        get_template_part( 'template-parts/content', 'page' );

        if ( comments_open() || get_comments_number() ) :
            ?>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- constrain only comments -->
                <section class="mt-12 bg-white rounded-lg shadow-md p-6">
                    <?php comments_template(); ?>
                </section>
            </div>
            <?php
        endif;

    endwhile;
    ?>
</main>

<?php get_footer(); ?>