<?php
/**
 * The template for displaying all static pages
 *
 * @package SpinPulse
 */

get_header();

// --- Dynamic Calculations ---
$current_post_id = get_queried_object_id();
$sp_content = get_post_field('post_content', $current_post_id);
$sp_word_count = str_word_count(strip_tags($sp_content));
$sp_reading_time = max(1, ceil($sp_word_count / 200));

$sp_views = get_post_meta($current_post_id, 'post_views_count', true) ?: '0';

$current_author_id = get_post_field('post_author', $current_post_id);
$current_author_name = get_the_author_meta('display_name', $current_author_id);
$current_author_url = get_author_posts_url($current_author_id);
?>

<main id="primary" class="site-main min-h-screen bg-white">
    
    <?php if (is_front_page()): 
        $options = get_option('spin_pulse_hero_settings', array());

        $heading = !empty($options['hero_heading']) ? $options['hero_heading'] : esc_html__('Find the best', 'spin-pulse');
        $description = !empty($options['hero_description']) ? $options['hero_description'] : esc_html__('Since 1995...', 'spin-pulse');
        $bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
        $bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
        $h_color = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
        $desc_color = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

        $bg_image = !empty($options['hero_bg_image']) ? $options['hero_bg_image'] : '';
        $overlay_color = !empty($options['hero_bg_overlay_color']) ? $options['hero_bg_overlay_color'] : '#000000';
        $overlay_opacity = isset($options['hero_bg_overlay_opacity']) ? floatval($options['hero_bg_overlay_opacity']) : 0.5;
        $avatar_url = get_avatar_url($current_author_id, array('size' => 96));
    
        $o = get_option('spin_pulse_homepage_hero', array());

        // THEMEFOREST FIX: Routed default images to the local assets folder
        $sp_heading = !empty($o['heading']) ? $o['heading'] : esc_html__('Global Online Casino 2026', 'spin-pulse');
        $sp_subtitle = !empty($o['subtitle']) ? $o['subtitle'] : esc_html__('Our guide focuses on what international players need: secure payment methods, huge game variety, transparent terms, and above all—verifiable game fairness and player security.', 'spin-pulse');
        $sp_bg_img = !empty($o['bg_img']) ? $o['bg_img'] : esc_url( get_template_directory_uri() . '/assets/images/background.webp' );
        $sp_gift_img = !empty($o['gift_img']) ? $o['gift_img'] : esc_url( get_template_directory_uri() . '/assets/images/gift.webp' );

        // Defaults - Author 1
        $sp_a1_name = !empty($o['author_1_name']) ? $o['author_1_name'] : esc_html__('Sarah Sterling', 'spin-pulse');
        $sp_a1_title = !empty($o['author_1_title']) ? $o['author_1_title'] : esc_html__('Casino Review Specialist', 'spin-pulse');
        $sp_a1_img = !empty($o['author_1_img']) ? $o['author_1_img'] : esc_url( get_template_directory_uri() . '/assets/images/author2.webp' );
        $sp_a1_date = !empty($o['author_1_date']) ? $o['author_1_date'] : esc_html__('Published: March 10, 2026', 'spin-pulse');
        $sp_a1_url = !empty($o['author_1_url']) ? $o['author_1_url'] : ''; 
        
        // Defaults - Author 2
        $sp_a2_name = !empty($o['author_2_name']) ? $o['author_2_name'] : esc_html__('Deric Clarke', 'spin-pulse');
        $sp_a2_title = !empty($o['author_2_title']) ? $o['author_2_title'] : esc_html__('Fair Play Auditor', 'spin-pulse');
        $sp_a2_img = !empty($o['author_2_img']) ? $o['author_2_img'] : esc_url( get_template_directory_uri() . '/assets/images/author1.webp' );
        $sp_a2_date = !empty($o['author_2_date']) ? $o['author_2_date'] : esc_html__('Updated: March 12, 2026', 'spin-pulse');
        $sp_a2_url = !empty($o['author_2_url']) ? $o['author_2_url'] : ''; 

        // Defaults - Features
        $f1_icon = !empty($o['feat_1_icon']) ? $o['feat_1_icon'] : 'fas fa-map-marked-alt';
        $f1_title = !empty($o['feat_1_title']) ? $o['feat_1_title'] : esc_html__('Global Casino Guide', 'spin-pulse');
        $f1_desc = !empty($o['feat_1_desc']) ? $o['feat_1_desc'] : esc_html__('Multi-Currency Support', 'spin-pulse');
        
        $f2_icon = !empty($o['feat_2_icon']) ? $o['feat_2_icon'] : 'fas fa-search-dollar';
        $f2_title = !empty($o['feat_2_title']) ? $o['feat_2_title'] : esc_html__('Comprehensive Reviews', 'spin-pulse');
        $f2_desc = !empty($o['feat_2_desc']) ? $o['feat_2_desc'] : esc_html__('100+ Brands Analyzed', 'spin-pulse');

        $f3_icon = !empty($o['feat_3_icon']) ? $o['feat_3_icon'] : 'fas fa-chart-line';
        $f3_title = !empty($o['feat_3_title']) ? $o['feat_3_title'] : esc_html__('Game Odds Analytics', 'spin-pulse');
        $f3_desc = !empty($o['feat_3_desc']) ? $o['feat_3_desc'] : esc_html__('RTP & Volatility Reports', 'spin-pulse');

        $f4_icon = !empty($o['feat_4_icon']) ? $o['feat_4_icon'] : 'fas fa-gift';
        $f4_title = !empty($o['feat_4_title']) ? $o['feat_4_title'] : esc_html__('Exclusive Offers Hub', 'spin-pulse');
        $f4_desc = !empty($o['feat_4_desc']) ? $o['feat_4_desc'] : esc_html__('Updated Daily Bonuses', 'spin-pulse');

        // Defaults - Badges
        $b1 = !empty($o['badge_1_text']) ? $o['badge_1_text'] : esc_html__('Licensed Solutions', 'spin-pulse');
        $b2 = !empty($o['badge_2_text']) ? $o['badge_2_text'] : esc_html__('Proven Fairness', 'spin-pulse');
        $b3 = !empty($o['badge_3_text']) ? $o['badge_3_text'] : esc_html__('Player Privacy', 'spin-pulse');
        $b4 = !empty($o['badge_4_text']) ? $o['badge_4_text'] : esc_html__('Global Casino Advisory', 'spin-pulse');

        // Defaults - Offer Card
        $sp_offer_badge = !empty($o['offer_badge']) ? $o['offer_badge'] : esc_html__('Exclusive Network Access', 'spin-pulse');
        $sp_offer_logo = !empty($o['offer_logo']) ? $o['offer_logo'] : esc_url( get_template_directory_uri() . '/assets/images/sample-logo-hero.webp' );
        $sp_offer_title = !empty($o['offer_title']) ? $o['offer_title'] : esc_html__('Premium Gaming Starter Kit', 'spin-pulse');
        $sp_offer_desc = !empty($o['offer_details']) ? $o['offer_details'] : esc_html__('Includes Deposit Boosts & Free Spins', 'spin-pulse');
        $sp_offer_btn = !empty($o['offer_btn_text']) ? $o['offer_btn_text'] : esc_html__('Unlock My Welcome Package', 'spin-pulse');
        $sp_offer_url = !empty($o['offer_btn_link']) ? $o['offer_btn_link'] : '#';
        $sp_offer_footer = !empty($o['offer_footer']) ? $o['offer_footer'] : esc_html__('Data Privacy Certified & Audited', 'spin-pulse');
        
        $hero_bg_style = "background-image: linear-gradient(rgba(249, 249, 249, 0.85), rgba(249, 249, 249, 0.85)), url('" . esc_url($sp_bg_img) . "');";
    ?>
    
<section class="sp-hp-hero-section" style="<?php echo esc_attr($hero_bg_style); ?>">
    <div class="sp-hp-hero-container">
        
        <div class="sp-hp-hero-content-column">
            <h1><?php echo esc_html($sp_heading); ?></h1>
            <p class="sp-hp-hero-subtitle"><?php echo esc_html($sp_subtitle); ?></p>
            
            <div class="sp-hp-hero-authors-container">
    
    <div class="sp-hp-hero-author-card">
        <div class="sp-hp-hero-avatar-wrapper">
            <?php if (!empty($sp_a1_url)): ?><a href="<?php echo esc_url($sp_a1_url); ?>"><?php endif; ?>
            <img src="<?php echo esc_url($sp_a1_img); ?>" alt="<?php echo esc_attr($sp_a1_name); ?>">
            <?php if (!empty($sp_a1_url)): ?></a><?php endif; ?>
            <div class="sp-hp-hero-status-dot">
                <span class="sp-hp-hero-status-ping"></span>
            </div>
        </div>

        <div class="sp-hp-hero-author-info">
            <p class="sp-hp-hero-label"><?php esc_html_e('Authored By', 'spin-pulse'); ?></p>
            <p class="sp-hp-hero-name">
                <?php if (!empty($sp_a1_url)): ?><a href="<?php echo esc_url($sp_a1_url); ?>" style="color: inherit; text-decoration: none;"><?php endif; ?>
                <?php echo esc_html($sp_a1_name); ?>
                <?php if (!empty($sp_a1_url)): ?></a><?php endif; ?>
                <span class="sp-hp-hero-verified-badge"><?php esc_html_e('Verified', 'spin-pulse'); ?></span>
            </p>
            <p class="sp-hp-hero-title"><?php echo esc_html($sp_a1_title); ?></p>
            <p class="sp-hp-hero-date"><?php echo esc_html($sp_a1_date); ?></p>
            
            <div class="sp-hp-hero-socials">
                <?php if (!empty($o['a1_fb'])): ?><a href="<?php echo esc_url($o['a1_fb']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                <?php if (!empty($o['a1_tw'])): ?><a href="<?php echo esc_url($o['a1_tw']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-x-twitter"></i></a><?php endif; ?>
                <?php if (!empty($o['a1_ig'])): ?><a href="<?php echo esc_url($o['a1_ig']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-instagram"></i></a><?php endif; ?>
                <?php if (!empty($o['a1_li'])): ?><a href="<?php echo esc_url($o['a1_li']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-linkedin-in"></i></a><?php endif; ?>
                <?php if (!empty($o['a1_yt'])): ?><a href="<?php echo esc_url($o['a1_yt']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-youtube"></i></a><?php endif; ?>
            </div>
        </div>
    </div>

    <div class="sp-hp-hero-author-card">
        <div class="sp-hp-hero-avatar-wrapper">
            <?php if (!empty($sp_a2_url)): ?><a href="<?php echo esc_url($sp_a2_url); ?>"><?php endif; ?>
            <img src="<?php echo esc_url($sp_a2_img); ?>" alt="<?php echo esc_attr($sp_a2_name); ?>">
            <?php if (!empty($sp_a2_url)): ?></a><?php endif; ?>
            <div class="sp-hp-hero-status-dot">
                <span class="sp-hp-hero-status-ping"></span>
            </div>
        </div>

        <div class="sp-hp-hero-author-info">
            <p class="sp-hp-hero-label"><?php esc_html_e('Reviewed By', 'spin-pulse'); ?></p>
            <p class="sp-hp-hero-name">
                <?php if (!empty($sp_a2_url)): ?><a href="<?php echo esc_url($sp_a2_url); ?>" style="color: inherit; text-decoration: none;"><?php endif; ?>
                <?php echo esc_html($sp_a2_name); ?>
                <?php if (!empty($sp_a2_url)): ?></a><?php endif; ?>
                <span class="sp-hp-hero-verified-badge"><?php esc_html_e('Verified', 'spin-pulse'); ?></span>
            </p>
            <p class="sp-hp-hero-title"><?php echo esc_html($sp_a2_title); ?></p>
            <p class="sp-hp-hero-date"><?php echo esc_html($sp_a2_date); ?></p>
            
            <div class="sp-hp-hero-socials">
                <?php if (!empty($o['a2_fb'])): ?><a href="<?php echo esc_url($o['a2_fb']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-facebook-f"></i></a><?php endif; ?>
                <?php if (!empty($o['a2_tw'])): ?><a href="<?php echo esc_url($o['a2_tw']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-x-twitter"></i></a><?php endif; ?>
                <?php if (!empty($o['a2_ig'])): ?><a href="<?php echo esc_url($o['a2_ig']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-instagram"></i></a><?php endif; ?>
                <?php if (!empty($o['a2_li'])): ?><a href="<?php echo esc_url($o['a2_li']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-linkedin-in"></i></a><?php endif; ?>
                <?php if (!empty($o['a2_yt'])): ?><a href="<?php echo esc_url($o['a2_yt']); ?>" target="_blank" class="sp-hp-hero-social-icon"><i class="fab fa-youtube"></i></a><?php endif; ?>
            </div>
        </div>
    </div>

</div>

            <div class="sp-hp-hero-features-grid">
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container"><i class="<?php echo esc_attr($f1_icon); ?>"></i></div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title"><?php echo esc_html($f1_title); ?></p>
                        <p class="sp-hp-hero-feature-desc"><?php echo esc_html($f1_desc); ?></p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container"><i class="<?php echo esc_attr($f2_icon); ?>"></i></div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title"><?php echo esc_html($f2_title); ?></p>
                        <p class="sp-hp-hero-feature-desc"><?php echo esc_html($f2_desc); ?></p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container"><i class="<?php echo esc_attr($f3_icon); ?>"></i></div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title"><?php echo esc_html($f3_title); ?></p>
                        <p class="sp-hp-hero-feature-desc"><?php echo esc_html($f3_desc); ?></p>
                    </div>
                </div>
                <div class="sp-hp-hero-feature-item">
                    <div class="sp-hp-hero-feature-icon-container"><i class="<?php echo esc_attr($f4_icon); ?>"></i></div>
                    <div class="sp-hp-hero-feature-text">
                        <p class="sp-hp-hero-feature-title"><?php echo esc_html($f4_title); ?></p>
                        <p class="sp-hp-hero-feature-desc"><?php echo esc_html($f4_desc); ?></p>
                    </div>
                </div>
            </div>

            <div class="sp-hp-hero-trust-badges">
                <div class="sp-hp-hero-trust-badge-item"><i class="fas fa-check-circle"></i><span><?php echo esc_html($b1); ?></span></div>
                <div class="sp-hp-hero-trust-badge-item"><i class="fas fa-check-circle"></i><span><?php echo esc_html($b2); ?></span></div>
                <div class="sp-hp-hero-trust-badge-item"><i class="fas fa-check-circle"></i><span><?php echo esc_html($b3); ?></span></div>
                <div class="sp-hp-hero-trust-badge-item"><i class="fas fa-check-circle"></i><span><?php echo esc_html($b4); ?></span></div>
            </div>
        </div>

        <div class="sp-hp-hero-card-column">
            
    <div class="sp-hp-hero-offer-card">
        <div class="sp-hp-hero-offer-card-header">
            <div class="sp-hp-hero-offer-badge"><?php echo esc_html($sp_offer_badge); ?></div>
            <a href="<?php echo esc_url($sp_offer_url); ?>" target="_blank" rel="noopener nofollow sponsored">
                <img src="<?php echo esc_url($sp_gift_img); ?>" alt="<?php esc_attr_e('Gift', 'spin-pulse'); ?>" width="45" height="38" class="sp-hp-hero-gift-icon">
            </a>
        </div>
        
        <div class="sp-hp-hero-card-logo-area">
            <img src="<?php echo esc_url($sp_offer_logo); ?>" alt="<?php esc_attr_e('Casino Logo', 'spin-pulse'); ?>" class="sp-hp-hero-card-logo-placeholder">
            <p class="sp-hp-hero-card-offer-title"><?php echo esc_html($sp_offer_title); ?></p>
            <p class="sp-hp-hero-card-offer-details"><?php echo esc_html($sp_offer_desc); ?></p>
        </div>
        
        <a href="<?php echo esc_url($sp_offer_url); ?>" class="sp-hp-hero-cta-button"><?php echo esc_html($sp_offer_btn); ?></a>
        <p class="sp-hp-hero-card-footer-text"><i class="fas fa-lock" style="margin-right: 5px;"></i> <?php echo esc_html($sp_offer_footer); ?></p>
    </div>

        </div>
    </div>
</section>
        

    <?php else: ?>
        <section class="sp-single-hero-wrapper py-12 border-b sp-article-hero-bg sp-article-hero-border-b">
            <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
                
                <div class="sp-hero-breadcrumbs mb-4 text-sm sp-article-hero-text opacity-80">
                    <a href="<?php echo esc_url(home_url()); ?>" class="hover:underline"><?php esc_html_e('Home', 'spin-pulse'); ?></a> &raquo; 
                    <span class="sp-hero-current-crumb sp-article-hero-title"><?php the_title(); ?></span>
                </div>
                
                <h1 class="sp-hero-title text-4xl md:text-5xl lg:text-6xl font-black tracking-tight mb-8 sp-article-hero-title"><?php the_title(); ?></h1>

                <div class="sp-hero-author-box flex flex-wrap items-center gap-6">
                    <div class="flex items-center gap-4">
                        <div class="sp-hero-author-avatar">
                            <a href="<?php echo esc_url($current_author_url); ?>">
                                <?php echo get_avatar($current_author_id, 56, '', '', array('class' => 'rounded-full border-2 sp-article-hero-border shadow-md hover:opacity-80 transition-opacity')); ?>
                            </a>
                        </div>
                        <div class="sp-hero-author-details flex flex-col justify-center">
                            <div class="sp-hero-author-name sp-article-hero-text"><?php esc_html_e('Authored By', 'spin-pulse'); ?> 
                                <a href="<?php echo esc_url($current_author_url); ?>" class="not-italic font-bold sp-article-hero-link">
                                    <?php echo esc_html($current_author_name); ?>
                                </a>
                            </div>
                            <div class="sp-hero-author-date text-sm sp-article-hero-text opacity-80 mt-1 flex flex-wrap gap-2 items-center">
                                <span><?php echo esc_html(sprintf(__('Published: %s', 'spin-pulse'), get_the_date('M j, Y'))); ?></span>
                                <span class="opacity-50">&bull;</span>
                                <span><?php echo esc_html(sprintf(__('Last Updated: %s', 'spin-pulse'), get_the_modified_date('M j, Y'))); ?></span>
                            </div>
                        </div>
                    </div>

                    <?php
                    $tw_url = get_the_author_meta('twitter', $current_author_id);
                    $fb_url = get_the_author_meta('facebook', $current_author_id);
                    $ig_url = get_the_author_meta('instagram', $current_author_id);
                    $li_url = get_the_author_meta('linkedin', $current_author_id);
                    $yt_url = get_the_author_meta('youtube', $current_author_id);
                    ?>

                    <?php if ($tw_url || $fb_url || $ig_url || $li_url || $yt_url): ?>
                        <div class="sp-hero-author-socials ml-0 sm:ml-4 sm:pl-6 sm:border-l border-slate-300/30 flex items-center gap-3">
                            <?php if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" target="_blank" rel="noopener noreferrer" class="sp-article-hero-social-link flex items-center justify-center w-10 h-10 rounded-full shadow-sm border sp-article-hero-card" style="color: #0f1419;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg></a><?php endif; ?>
                            <?php if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" target="_blank" rel="noopener noreferrer" class="sp-article-hero-social-link flex items-center justify-center w-10 h-10 rounded-full shadow-sm border sp-article-hero-card" style="color: #1877F2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></a><?php endif; ?>
                            <?php if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" target="_blank" rel="noopener noreferrer" class="sp-article-hero-social-link flex items-center justify-center w-10 h-10 rounded-full shadow-sm border sp-article-hero-card" style="color: #E1306C;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></a><?php endif; ?>
                            <?php if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" target="_blank" rel="noopener noreferrer" class="sp-article-hero-social-link flex items-center justify-center w-10 h-10 rounded-full shadow-sm border sp-article-hero-card" style="color: #0A66C2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></a><?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
        </section>
    <?php endif; ?>

    <div class="py-0">
        <div class="max-w-[1200px] mx-auto px-6 w-full">
            <?php if (have_posts()): while (have_posts()): the_post(); ?>
                
                <article id="post-<?php the_ID(); ?>" <?php post_class('prose prose-slate prose-lg sp-single-content max-w-none'); ?>>
                    <?php 
                        the_content(); 
                        
                        wp_link_pages( array(
                            'before' => '<div class="page-links mt-8">' . esc_html__( 'Pages:', 'spin-pulse' ),
                            'after'  => '</div>',
                        ) );
                    ?>
                </article>
                
                <?php 
                if ( comments_open() || get_comments_number() ) :
                    comments_template();
                endif;
                ?>

            <?php endwhile; wp_reset_postdata(); else: ?>
                <p><?php esc_html_e('No content found.', 'spin-pulse'); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <?php if (get_the_author_meta('description', $current_author_id)): ?>
        <div class="sp-author-bio-wrapper">
            <div class="sp-author-bio-container">
                <div class="sp-author-bio-avatar">
                    <a href="<?php echo esc_url($current_author_url); ?>">
                        <?php echo get_avatar($current_author_id, 120, '', '', array('class' => 'sp-author-avatar-img hover:opacity-80 transition-opacity')); ?>
                    </a>
                </div>
                <div class="sp-author-bio-content">
                    <h3 class="sp-author-bio-title">
                        <span class="sp-author-bio-greeting"><?php esc_html_e('Written by', 'spin-pulse'); ?></span>
                        <a href="<?php echo esc_url($current_author_url); ?>" class="hover:text-[#00d67d] transition-colors">
                            <?php echo esc_html($current_author_name); ?>
                        </a>
                    </h3>
                    <div class="sp-author-bio-text">
                        <?php echo wp_kses_post(wpautop(get_the_author_meta('description', $current_author_id))); ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <section class="sp-recent-post-full-wrapper">
        <div class="sp-recent-post-container">
            <div class="sp-recent-post-main">
                <div class="sp-recent-post-header">
                    <h2 class="sp-recent-post-title-main"><?php esc_html_e('Recent Posts', 'spin-pulse'); ?></h2>
                    <div class="sp-recent-post-categories">
                        <?php
                        $all_cats = get_categories(array('hide_empty' => true));
                        if (!empty($all_cats)) {
                            foreach ($all_cats as $cat) {
                                echo '<a href="' . esc_url(get_category_link($cat->term_id)) . '" class="sp-recent-post-cat-link">' . esc_html($cat->name) . '</a>';
                            }
                        }
                        ?>
                    </div>
                </div>

                <div class="sp-recent-post-list">
                    <?php
                    $recent_args = array('post_type' => 'post', 'posts_per_page' => 4, 'post_status' => 'publish', 'post__not_in' => array($current_post_id));
                    $recent_query = new WP_Query($recent_args);
                    if ($recent_query->have_posts()):
                        while ($recent_query->have_posts()):
                            $recent_query->the_post();

                            $post_content = get_post_field('post_content', get_the_ID());
                            $reading_time = max(1, ceil(str_word_count(strip_tags($post_content)) / 200));
                            $cats = get_the_category();
                            $cat_name = !empty($cats) ? $cats[0]->name : esc_html__('News', 'spin-pulse');
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                            ?>
                            <div class="sp-recent-post-item">
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="sp-recent-post-thumb">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('medium_large');
                                    } else {
                                        echo '<div class="sp-recent-post-placeholder"></div>';
                                    } ?>
                                </a>
                                <div class="sp-recent-post-info">
                                    <div class="sp-recent-post-meta-top">
                                        <span class="sp-recent-post-cat-name"><?php echo esc_html($cat_name); ?></span>
                                        <span class="sp-recent-post-date"><?php echo esc_html(get_the_date('M j, Y')); ?></span>
                                    </div>
                                    <h3 class="sp-recent-post-heading">
                                        <a href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html(get_the_title()); ?></a>
                                    </h3>
                                    <div class="sp-recent-post-author-row">
                                        <a href="<?php echo esc_url($author_url); ?>">
                                            <?php echo get_avatar($author_id, 24, '', '', array('class' => 'sp-recent-post-author-avatar')); ?>
                                        </a>
                                        <a href="<?php echo esc_url($author_url); ?>"
                                            class="sp-recent-post-author-name"><?php echo esc_html(get_the_author()); ?></a>
                                        <span class="sp-recent-post-dot">&bull;</span>
                                        <span><?php echo esc_html($reading_time); ?> <?php esc_html_e('min read', 'spin-pulse'); ?></span>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata(); endif; ?>
                </div>
            </div>

            <div class="sp-recent-post-sidebar-wrapper">
                <h3 class="sp-recent-post-sidebar-title"><?php esc_html_e('Discover our blogs', 'spin-pulse'); ?></h3>
                <div class="sp-recent-post-sidebar-list">
                    <?php
                    $discover_args = array('post_type' => 'post', 'posts_per_page' => 3, 'offset' => 3, 'post_status' => 'publish', 'post__not_in' => array($current_post_id));
                    $discover_query = new WP_Query($discover_args);
                    if ($discover_query->have_posts()):
                        while ($discover_query->have_posts()):
                            $discover_query->the_post();
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                            ?>
                            <div class="sp-recent-post-sidebar-item">
                                <a href="<?php echo esc_url(get_permalink()); ?>" class="sp-recent-post-sidebar-thumb">
                                    <?php if (has_post_thumbnail()) {
                                        the_post_thumbnail('thumbnail');
                                    } else {
                                        echo '<div class="sp-recent-post-placeholder"></div>';
                                    } ?>
                                </a>
                                <div class="sp-recent-post-sidebar-info">
                                    <h4 class="sp-recent-post-sidebar-heading"><a
                                            href="<?php echo esc_url(get_permalink()); ?>"><?php echo esc_html(wp_trim_words(get_the_title(), 8, '...')); ?></a>
                                    </h4>
                                    <div class="sp-recent-post-sidebar-excerpt">
                                        <?php echo esc_html(wp_trim_words(get_the_excerpt(), 8, '...')); ?>
                                    </div>
                                    <div class="sp-recent-post-sidebar-meta">
                                        <div class="sp-recent-post-sidebar-author-row">
                                            <a href="<?php echo esc_url($author_url); ?>">
                                                <?php echo get_avatar($author_id, 16, '', '', array('class' => 'sp-recent-post-sidebar-avatar')); ?>
                                            </a>
                                            <a
                                                href="<?php echo esc_url($author_url); ?>"><?php echo esc_html(wp_trim_words(get_the_author(), 2, '')); ?></a>
                                            <span>&bull;</span>
                                            <span><?php echo esc_html(get_the_date('M j, Y')); ?></span>
                                        </div>
                                        <a href="<?php echo esc_url(get_permalink()); ?>" class="sp-recent-post-sidebar-readlink"><?php esc_html_e('Read', 'spin-pulse'); ?> &rarr;</a>
                                    </div>
                                </div>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata(); endif; ?>
                </div>
            </div>

        </div>
    </section>

</main>

<?php get_footer(); ?>