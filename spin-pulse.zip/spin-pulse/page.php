<?php
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-slate-50">
    <?php if (is_front_page()) : ?>
        <?php
        $hero_opts = get_option('spin_pulse_hero_settings', []);

        $heading      = !empty($hero_opts['hero_heading']) ? esc_html($hero_opts['hero_heading']) : get_the_title(); // fallback to page title
        $description  = !empty($hero_opts['hero_description']) ? wp_kses_post($hero_opts['hero_description']) : 'Since 1995, we\'ve been helping players find their perfect casinos. Explore our expert reviews, smart tools, and trusted guides, and play with confidence.';
        $accent_color = !empty($hero_opts['hero_accent_color']) ? esc_attr($hero_opts['hero_accent_color']) : '#f97316';
        $bg_start     = !empty($hero_opts['hero_bg_start'])     ? esc_attr($hero_opts['hero_bg_start'])     : '#7c3aed';
        $bg_mid       = !empty($hero_opts['hero_bg_mid'])       ? esc_attr($hero_opts['hero_bg_mid'])       : '#6d28d9';
        $bg_end       = !empty($hero_opts['hero_bg_end'])       ? esc_attr($hero_opts['hero_bg_end'])       : '#5b21b6';
        $text_color   = !empty($hero_opts['hero_text_color'])   ? esc_attr($hero_opts['hero_text_color'])   : '#f3e8ff';

        // Cards (dynamic)
        $card1_title = !empty($hero_opts['hero_card1_title']) ? esc_html($hero_opts['hero_card1_title']) : 'Free casino games';
        $card1_link  = !empty($hero_opts['hero_card1_link'])  ? esc_url($hero_opts['hero_card1_link'])   : '#';
        $card2_title = !empty($hero_opts['hero_card2_title']) ? esc_html($hero_opts['hero_card2_title']) : 'Casino reviews';
        $card2_link  = !empty($hero_opts['hero_card2_link'])  ? esc_url($hero_opts['hero_card2_link'])   : '#';
        $card3_title = !empty($hero_opts['hero_card3_title']) ? esc_html($hero_opts['hero_card3_title']) : 'Latest news';
        $card3_link  = !empty($hero_opts['hero_card3_link'])  ? esc_url($hero_opts['hero_card3_link'])   : '#';
        $card4_title = !empty($hero_opts['hero_card4_title']) ? esc_html($hero_opts['hero_card4_title']) : 'Top ZA casinos';
        $card4_link  = !empty($hero_opts['hero_card4_link'])  ? esc_url($hero_opts['hero_card4_link'])   : '#';
        ?>

        <section class="w-full bg-gradient-to-r py-16 md:py-24 lg:py-32" 
                 style="background: linear-gradient(to right, <?php echo $bg_start; ?>, <?php echo $bg_mid; ?>, <?php echo $bg_end; ?>);">
            <div class="max-w-7xl mx-auto px-6 lg:px-8">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <!-- Left: Heading + description -->
                    <div>
                        <h1 class="text-4xl md:text-5xl font-extrabold text-white leading-tight">
                            <?php echo $heading; ?><br>
                            <span style="color: <?php echo $accent_color; ?>;">safe casinos</span>
                        </h1>
                        <p class="mt-6 text-lg max-w-xl" style="color: <?php echo $text_color; ?>;">
                            <?php echo nl2br($description); ?>
                        </p>
                    </div>

                    <!-- Right: Cards -->
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <!-- Card 1 -->
                        <a href="<?php echo $card1_link; ?>" class="group bg-indigo-950 rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                            <div class="flex items-center justify-between">
                                <div>
                                    <span class="inline-block bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded mb-3">
                                        FREE
                                    </span>
                                    <h3 class="text-white font-semibold text-lg">
                                        <?php echo $card1_title; ?>
                                    </h3>
                                </div>
                                <span class="text-white text-2xl group-hover:translate-x-1 transition">→</span>
                            </div>
                        </a>
                        <!-- Card 2 -->
                        <a href="<?php echo $card2_link; ?>" class="group bg-indigo-950 rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                            <div class="flex items-center justify-between">
                                <h3 class="text-white font-semibold text-lg">
                                    <?php echo $card2_title; ?>
                                </h3>
                                <span class="text-white text-2xl group-hover:translate-x-1 transition">→</span>
                            </div>
                        </a>
                        <!-- Card 3 -->
                        <a href="<?php echo $card3_link; ?>" class="group bg-indigo-950 rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                            <div class="flex items-center justify-between">
                                <h3 class="text-white font-semibold text-lg">
                                    <?php echo $card3_title; ?>
                                </h3>
                                <span class="text-white text-2xl group-hover:translate-x-1 transition">→</span>
                            </div>
                        </a>
                        <!-- Card 4 -->
                        <a href="<?php echo $card4_link; ?>" class="group bg-indigo-950 rounded-2xl p-6 shadow-lg hover:shadow-xl transition">
                            <div class="flex items-center justify-between">
                                <h3 class="text-white font-semibold text-lg">
                                    <?php echo $card4_title; ?>
                                </h3>
                                <span class="text-white text-2xl group-hover:translate-x-1 transition">→</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </section>
    <?php endif; ?>

    <?php
    while ( have_posts() ) :
        the_post();

        // No max-w-7xl here → content can now go edge-to-edge
        get_template_part( 'template-parts/content', 'page' );

        if ( comments_open() || get_comments_number() ) :
            ?>
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"> <!-- constrain only comments -->
                <section class="mt-12 bg-white rounded-lg shadow-md p-6">
                    <?php comments_template(); ?>
                </section>
            </div>
            <?php
        endif;

    endwhile;
    ?>
</main>

<?php get_footer(); ?>