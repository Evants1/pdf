<?php
/**
 * The template for displaying all pages
 */
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-white">
    <?php if (is_front_page()): 
        $options = get_option('spin_pulse_hero_settings', []);

        // Logic & Fallbacks
        $heading = !empty($options['hero_heading']) ? $options['hero_heading'] : 'Find the best';
        $description = !empty($options['hero_description']) ? $options['hero_description'] : "Since 1995...";
        $bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
        $bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
        $h_color = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
        $desc_color = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

        // Author Data
        $author_id = get_post_field('post_author', get_the_ID());
        $author_name = get_the_author_meta('display_name', $author_id);
        $avatar = get_avatar_url($author_id, ['size' => 96]);
        $has_avatar = !strpos($avatar, 'mysteryman') && !strpos($avatar, 'blank') && !strpos($avatar, 'gravatar');
        ?>

        <section class="w-full py-16 md:py-24 lg:py-32"
            style="background: linear-gradient(135deg, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_end); ?>);">
            <div class="w-full px-6 lg:px-12"> <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    
                    <div class="flex flex-col">
                        <div class="flex items-center space-x-4 mb-8 group cursor-default">
                            <div class="relative">
                                <?php if ($has_avatar): ?>
                                    <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($author_name); ?>"
                                        class="w-14 h-14 rounded-full border-2 border-white/20 object-cover shadow-lg group-hover:border-purple-500 transition-colors duration-300">
                                <?php else: ?>
                                    <div class="w-14 h-14 rounded-full border-2 border-white/20 bg-white/10 flex items-center justify-center shadow-lg group-hover:border-purple-500 transition-colors duration-300">
                                        <svg class="w-7 h-7 text-white/70" fill="currentColor" viewBox="0 0 24 24">
                                            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
                                        </svg>
                                    </div>
                                <?php endif; ?>
                                <div class="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1e293b] rounded-full">
                                    <span class="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
                                </div>
                            </div>

                            <div class="flex flex-col space-y-1">
                                <div class="flex items-center gap-2">
                                    <span class="text-white font-bold text-base tracking-tight"><?php echo esc_html($author_name); ?></span>
                                    <span class="bg-white/10 text-white/60 text-[10px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider border border-white/5">Verified</span>
                                </div>
                                <div class="flex items-center text-white/50 text-xs font-medium space-x-2">
                                    <span>Updated: <?php echo get_the_modified_date('M j, Y'); ?></span>
                                </div>
                            </div>
                        </div>

                        <h1 class="text-4xl md:text-6xl font-black leading-[1.1] tracking-[-0.04em]"
                            style="color: <?php echo esc_attr($h_color); ?>;">
                            <?php echo esc_html($heading); ?>
                        </h1>

                        <p class="mt-6 text-lg md:text-xl leading-relaxed max-w-xl font-medium opacity-90 tracking-tight"
                            style="color: <?php echo esc_attr($desc_color); ?>;">
                            <?php echo wp_kses_post(nl2br($description)); ?>
                        </p>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <?php for ($i = 1; $i <= 4; $i++):
                            $c_title = !empty($options["card{$i}_title"]) ? $options["card{$i}_title"] : "Card $i";
                            $c_link = !empty($options["card{$i}_link"]) ? $options["card{$i}_link"] : "#";
                            $c_badge = !empty($options["card{$i}_badge"]) ? $options["card{$i}_badge"] : "";
                            $c_badge_bg = !empty($options["card{$i}_badge_bg"]) ? $options["card{$i}_badge_bg"] : '#7c3aed';
                            ?>
                            <a href="<?php echo esc_url($c_link); ?>"
                                class="group relative overflow-hidden transition-all duration-500 rounded-3xl p-8 bg-slate-800/40 border border-white/5 hover:border-purple-500/50 hover:bg-slate-800/60 shadow-2xl backdrop-blur-sm">
                                <div class="flex flex-col h-full justify-between">
                                    <div>
                                        <?php if (!empty($c_badge)): ?>
                                            <span class="inline-block text-[10px] font-black px-3 py-1 rounded-full mb-4 uppercase tracking-[0.1em] shadow-lg"
                                                style="background-color: <?php echo esc_attr($c_badge_bg); ?>; color: #ffffff;">
                                                <?php echo esc_html($c_badge); ?>
                                            </span>
                                        <?php endif; ?>
                                        <h3 class="text-white font-bold text-xl group-hover:text-purple-300 transition-colors leading-snug">
                                            <?php echo esc_html($c_title); ?>
                                        </h3>
                                    </div>
                                    <div class="mt-8 flex items-center text-white/30 group-hover:text-purple-400 transition-colors">
                                        <span class="text-xs font-black uppercase tracking-widest">Learn More</span>
                                        <svg class="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform duration-300"
                                            fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M17 8l4 4m0 0l-4 4m4-4H3"></path>
                                        </svg>
                                    </div>
                                </div>
                            </a>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="w-full py-12 bg-white">
            <div class="w-full px-6 lg:px-12">
                <?php while ( have_posts() ) : the_post(); the_content(); endwhile; ?>
            </div>
        </section>

    <?php else: ?>

        <section class="w-full py-16 md:py-24 bg-white">
            <div class="w-full px-6 lg:px-12">
                <?php 
                if ( have_posts() ) : 
                    while ( have_posts() ) : the_post(); ?>
                        <header class="mb-12">
                            <h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tight">
                                <?php the_title(); ?>
                            </h1>
                        </header>
                        
                        <article class="prose prose-slate prose-lg max-w-none w-full">
                            <?php the_content(); ?>
                        </article>
                    <?php endwhile; 
                else : ?>
                    <p>No content found.</p>
                <?php endif; ?>
            </div>
        </section>

    <?php endif; ?>
</main>

<?php get_footer(); ?>