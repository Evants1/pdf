<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
    
<body <?php body_class( 'bg-white text-slate-900 antialiased font-sans' ); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site min-h-screen flex flex-col">

    <header id="masthead" class="fixed top-0 left-0 w-full z-50 bg-[#1E293B] shadow-md transition-shadow duration-300">
        <div id="main-header" class="h-16 border-b border-white/5">
            <div class="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between">
                
                <div class="flex items-center">
                    <?php if ( has_custom_logo() ) : ?>
                        <div class="brightness-0 invert"><?php the_custom_logo(); ?></div>
                    <?php else : ?>
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-2xl font-bold tracking-tight text-white uppercase hover:text-[#00d67d] transition-colors duration-200">
                            <?php echo esc_html( get_bloginfo( 'name' ) ); ?>
                        </a>
                    <?php endif; ?>
                </div>

                <nav class="hidden lg:flex items-center space-x-6 font-medium text-sm uppercase tracking-wider">
                    <?php 
                    if ( has_nav_menu( 'menu-1' ) ) {
                        wp_nav_menu( array( 
                            'theme_location' => 'menu-1', 
                            'container'      => false, 
                            'menu_class'     => 'flex items-center space-x-6 text-white', 
                            'walker'         => new Spin_Pulse_Walker_Nav_Menu(),
                        ) ); 
                    }
                    ?>
                </nav>

                <div class="flex items-center space-x-4">
                    <button id="search-menu-toggle" class="text-white hover:text-[#00d67d] transition-colors duration-200 p-2" aria-label="<?php esc_attr_e( 'Search', 'spin-pulse' ); ?>">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                    </button>
                    <button id="mobile-menu-toggle" class="lg:hidden text-white hover:text-[#00d67d] transition-colors duration-200 p-2" aria-label="<?php esc_attr_e( 'Menu', 'spin-pulse' ); ?>">
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                    </button>
                </div>
            </div>
        </div>

        <div id="search-dropdown" class="sp-search-bar-dropdown hidden">
            <div class="sp-search-bar-container">
                <form role="search" method="get" class="sp-search-bar-form" action="<?php echo esc_url( home_url( '/' ) ); ?>">
                    <input type="search" id="header-search-input" class="sp-search-bar-input" placeholder="<?php esc_attr_e( 'Search articles, reviews...', 'spin-pulse' ); ?>" value="<?php echo get_search_query(); ?>" name="s" />
                    <button type="submit" class="sp-search-bar-submit"><?php esc_html_e( 'Search', 'spin-pulse' ); ?></button>
                </form>
            </div>
        </div>

        <div id="mobile-menu" class="hidden lg:hidden bg-[#111827] border-t border-white/5 shadow-lg absolute w-full left-0 top-full transition-all duration-300 ease-in-out">
            <?php 
            if ( has_nav_menu( 'menu-1' ) ) {
                wp_nav_menu( array(
                    'theme_location' => 'menu-1', 
                    'container'      => false, 
                    'menu_class'     => 'flex flex-col p-6 space-y-4 font-medium text-white uppercase tracking-wider', 
                    'walker'         => new Spin_Pulse_Walker_Nav_Menu(),
                ) ); 
            }
            ?>
        </div>
    </header>

    <div id="content" class="site-content flex-grow pt-16">