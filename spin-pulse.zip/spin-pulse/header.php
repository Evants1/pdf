<?php
/**
 * The header for our theme
 * * Optimized for Spin Pulse (Casino Affiliate) with ThemeForest-standard escaping.
 *
 * @package Spin_Pulse
 */
?>
<!doctype html>
<html <?php language_attributes(); ?>>

<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class('bg-slate-50 text-slate-900 antialiased'); ?>>
    <?php wp_body_open(); ?>

    <div id="page" class="site">
        <?php
        $header_style = get_theme_mod('spin_pulse_header_style', 'style2'); // Default to professional gold style
        $topbar_enabled = get_theme_mod('spin_pulse_topbar_enable', true);
        ?>

        <header id="masthead" class="fixed top-0 left-0 w-full z-50 transition-all duration-300">

            <?php if ('style2' === $header_style): ?>

                <div id="top-bar" class="bg-[#C9B16B] py-6">
                    <div class="max-w-[1600px] mx-auto w-full px-6 flex justify-between items-center">

                        <div class="w-1/3 flex items-center space-x-3">
                            <?php if (function_exists('spin_pulse_get_social_links')): ?>
                                <div class="header-socials flex items-center gap-2">
                                    <?php echo spin_pulse_get_social_links(); ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="w-1/3 flex justify-center">
                            <?php if (has_custom_logo()):
                                the_custom_logo(); else: ?>
                                <a href="<?php echo esc_url(home_url('/')); ?>"
                                    class="text-4xl md:text-5xl font-black tracking-widest text-white uppercase italic drop-shadow-md">
                                    <?php bloginfo('name'); ?>
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="w-1/3 flex justify-end">
                            <button class="text-white hover:text-black transition-colors p-2"
                                aria-label="<?php esc_attr_e('Search', 'spin-pulse'); ?>">
                                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                    stroke-width="2.5">
                                    <path stroke-linecap="round" stroke-linejoin="round"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="bg-[#0dcaf0] h-[2px] w-full shadow-sm"></div>

                <div id="main-header" class="bg-[#C9B16B] border-b border-black/5">
                    <div class="max-w-[1600px] mx-auto px-6 flex justify-center">
                        <nav id="site-navigation" class="hidden lg:flex items-center h-14">
                            <?php wp_nav_menu(array(
                                'theme_location' => 'menu-1',
                                'container' => false,
                                'menu_id' => 'primary-menu',
                                'menu_class' => 'flex items-center space-x-10 h-full font-bold text-black uppercase text-sm tracking-wider',
                                'walker' => new Spin_Pulse_Walker_Nav_Menu()
                            )); ?>
                        </nav>

                        <button id="mobile-menu-toggle-alt" class="lg:hidden py-3 text-white">
                            <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M4 6h16M4 12h16m-7 6h7"></path>
                            </svg>
                        </button>
                    </div>
                </div>

            <?php else: ?>

                <div id="main-header" class="bg-white h-20 shadow-sm border-b border-slate-100">
                    <div class="max-w-[1600px] mx-auto h-full px-6 flex items-center justify-between">
                        <div class="flex items-center">
                            <?php if (has_custom_logo()):
                                the_custom_logo(); else: ?>
                                <a href="<?php echo esc_url(home_url('/')); ?>"
                                    class="text-3xl font-black tracking-tighter text-slate-900 uppercase"><?php bloginfo('name'); ?></a>
                            <?php endif; ?>
                        </div>
                        <nav class="hidden lg:flex justify-center h-full">
                            <?php wp_nav_menu(array('theme_location' => 'menu-1', 'container' => false, 'menu_class' => 'flex items-center space-x-10 h-full font-semibold', 'walker' => new Spin_Pulse_Walker_Nav_Menu())); ?>
                        </nav>
                        <div class="flex items-center space-x-4">
                            <button class="text-slate-400 hover:text-casino-blue p-2"><svg class="w-6 h-6" fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                                </svg></button>
                            <button id="mobile-menu-toggle" class="lg:hidden p-2"><svg class="w-8 h-8 text-slate-900"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 6h16M4 12h16m-7 6h7"></path>
                                </svg></button>
                        </div>
                    </div>
                </div>

            <?php endif; ?>

            <div id="mobile-menu"
                class="hidden lg:hidden bg-white border-t border-slate-100 shadow-2xl absolute w-full left-0 animate-fade-in-down">
                <?php wp_nav_menu(array('theme_location' => 'menu-1', 'container' => false, 'menu_class' => 'flex flex-col p-8 space-y-6 font-black text-xl text-slate-900 uppercase italic', 'walker' => new Spin_Pulse_Walker_Nav_Menu())); ?>
            </div>

            <?php if (is_front_page()): ?>
                <section class="homepage-hero bg-[#001f3f] py-12 lg:py-16 text-white">
                    <div class="container mx-auto px-4 text-center">
                        <h1 class="text-3xl lg:text-4xl font-bold mb-4">Compare the best online casinos in Canada 2026</h1>
                        <p class="text-base lg:text-lg mb-8 max-w-4xl mx-auto leading-relaxed">
                            Use Casino.ca to find the best online casino in Canada. With 10 years online, we've reviewed
                            120+ regulated casinos to find sites you can trust. Our thorough review process looks for
                            licensing from top regulators like the Kahnawake Gaming Commission and iGaming Ontario.
                        </p>
                        <div class="flex flex-wrap justify-center gap-4">
                            <a href="/casino-reviews"
                                class="bg-green-400 text-white px-6 py-3 rounded font-semibold hover:bg-green-500 transition">Casino
                                reviews →</a>
                            <a href="/bonus-offers"
                                class="bg-green-400 text-white px-6 py-3 rounded font-semibold hover:bg-green-500 transition">Bonus
                                offers →</a>
                            <a href="/free-games"
                                class="bg-green-400 text-white px-6 py-3 rounded font-semibold hover:bg-green-500 transition">Free
                                games →</a>
                            <a href="/real-money-casinos"
                                class="bg-green-400 text-white px-6 py-3 rounded font-semibold hover:bg-green-500 transition">Real
                                money casinos →</a>
                        </div>
                    </div>
                </section>
            <?php endif; ?>

        </header>

        <div id="content"
            class="site-content <?php echo ('style2' === $header_style) ? 'pt-[180px]' : 'pt-20'; ?> <?php echo is_front_page() ? 'pt-0' : ''; ?>">