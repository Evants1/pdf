<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @package Spin_Pulse
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class( 'bg-casino-dark text-white' ); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site">
    <a class="skip-link screen-reader-text" href="#primary"><?php esc_html_e( 'Skip to content', 'spin-pulse' ); ?></a>

    <header id="masthead" class="fixed top-0 left-0 w-full z-50 bg-casino-dark/95 backdrop-blur-sm border-b border-white/10">
        <div class="container mx-auto px-4 h-20 flex items-center justify-between">
            
            <div class="flex items-center">
                <div class="site-branding">
                    <?php if ( has_custom_logo() ) : ?>
                        <div class="max-w-[180px]">
                            <?php the_custom_logo(); ?>
                        </div>
                    <?php else : ?>
                        <div class="text-2xl font-black uppercase tracking-tighter">
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home" class="bg-gold-gradient bg-clip-text text-transparent">
                                <?php bloginfo( 'name' ); ?>
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <nav id="site-navigation" class="hidden lg:block main-navigation">
                <?php
                wp_nav_menu(
                    array(
                        'theme_location' => 'menu-1',
                        'menu_id'        => 'primary-menu',
                        'container'      => false,
                        'menu_class'     => 'flex space-x-8 text-sm font-bold uppercase tracking-widest text-gray-300 hover:children:text-casino-gold transition-colors',
                        'fallback_cb'    => false,
                    )
                );
                ?>
            </nav>

            <div class="hidden md:flex items-center space-x-4">
                <a href="<?php echo esc_url( home_url( '/top-bonuses' ) ); ?>" class="bg-gold-gradient text-black px-6 py-2.5 rounded-full font-bold text-sm uppercase shadow-[0_0_15px_rgba(212,175,55,0.3)] hover:scale-105 transition-transform">
                    <?php esc_html_e( 'Best Bonuses', 'spin-pulse' ); ?>
                </a>
            </div>

            <button id="mobile-menu-toggle" class="lg:hidden text-white focus:outline-none" aria-controls="primary-menu" aria-expanded="false">
                <span class="screen-reader-text"><?php esc_html_e( 'Menu', 'spin-pulse' ); ?></span>
                <svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
            </button>
        </div>

        <div id="mobile-menu" class="hidden lg:hidden bg-slate-900 border-t border-white/10 p-4">
            <?php
            wp_nav_menu(
                array(
                    'theme_location' => 'menu-1',
                    'container'      => false,
                    'menu_class'     => 'flex flex-col space-y-4 font-bold uppercase py-4',
                )
            );
            ?>
        </div>
    </header>

    <div id="content" class="site-content pt-20">