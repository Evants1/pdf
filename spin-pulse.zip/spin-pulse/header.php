<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>

<body <?php body_class( 'bg-white text-slate-900 antialiased font-sans' ); ?>>
<?php wp_body_open(); ?>

<div id="page" class="site min-h-screen flex flex-col">
    <?php 
    $header_style = get_theme_mod( 'spin_pulse_header_style', 'style1' );
    $topbar_enabled = get_theme_mod( 'spin_pulse_topbar_enable', true );
    ?>

    <?php /* NOTE: bg-brand-dark (#0B0F1A) matches your Hero. 
       If you want the header transparent to show the gradient, use 'bg-transparent'.
    */ ?>
    <header id="masthead" class="fixed top-0 left-0 w-full z-50 bg-[#0B0F1A] shadow-md transition-shadow duration-300">
        
        <?php if ( 'style2' === $header_style ) : ?>
            <?php if ( $topbar_enabled ) : ?>
                <div id="top-bar" class="py-2 bg-[#111827] border-b border-white/5">
                    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-between items-center">
                        <div class="flex items-center space-x-4 text-white">
                            <?php echo spin_pulse_get_social_links(); ?>
                        </div>

                        <div class="flex justify-center">
                            <?php if ( has_custom_logo() ) : ?>
                                <div class="brightness-0 invert"><?php the_custom_logo(); ?></div>
                            <?php else : ?>
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-2xl font-bold tracking-tight text-white uppercase hover:text-purple-400 transition-colors duration-200">
                                    <?php bloginfo( 'name' ); ?>
                                </a>
                            <?php endif; ?>
                        </div>

                        <div class="flex justify-end">
                            <button class="text-white hover:text-purple-400 transition-colors duration-200 p-2" aria-label="Search">
                                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endif; ?>

            <div id="main-header" class="h-16">
                <div class="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex justify-center items-center">
                    <nav id="site-navigation" class="hidden lg:flex h-full">
                        <?php wp_nav_menu( array(
                            'theme_location' => 'menu-1',
                            'container'      => false,
                            'menu_class'     => 'flex items-center space-x-6 h-full font-medium text-sm uppercase tracking-wider text-white',
                            'walker'         => new Spin_Pulse_Walker_Nav_Menu(),
                        ) ); ?>
                    </nav>
                </div>
            </div>

        <?php else : // style1 ?>
            <div id="main-header" class="h-16 border-b border-white/5">
                <div class="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between">
                    <div class="flex items-center">
                        <?php if ( has_custom_logo() ) : ?>
                            <div class="brightness-0 invert"><?php the_custom_logo(); ?></div>
                        <?php else : ?>
                            <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="text-2xl font-bold tracking-tight text-white uppercase hover:text-purple-400 transition-colors duration-200">
                                <?php bloginfo( 'name' ); ?>
                            </a>
                        <?php endif; ?>
                    </div>
                    <nav class="hidden lg:flex items-center space-x-6 font-medium text-sm uppercase tracking-wider">
                        <?php wp_nav_menu( array( 
                            'theme_location' => 'menu-1', 
                            'container' => false, 
                            'menu_class' => 'flex items-center space-x-6 text-white', 
                            'walker' => new Spin_Pulse_Walker_Nav_Menu(),
                        ) ); ?>
                    </nav>
                    <div class="flex items-center space-x-4">
                        <button class="text-white hover:text-purple-400 transition-colors duration-200 p-2" aria-label="Search">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        </button>
                        <button id="mobile-menu-toggle" class="lg:hidden text-white hover:text-purple-400 transition-colors duration-200 p-2">
                            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path></svg>
                        </button>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <div id="mobile-menu" class="hidden lg:hidden bg-[#111827] border-t border-white/5 shadow-lg absolute w-full left-0 top-full transition-all duration-300 ease-in-out">
            <?php wp_nav_menu( array(
                'theme_location' => 'menu-1', 
                'container' => false, 
                'menu_class' => 'flex flex-col p-6 space-y-4 font-medium text-white uppercase tracking-wider', 
                'walker' => new Spin_Pulse_Walker_Nav_Menu(),
            ) ); ?>
        </div>
    </header>

    <div id="content" class="site-content flex-grow <?php echo ('style2' === $header_style && $topbar_enabled) ? 'pt-28' : 'pt-16'; ?>">