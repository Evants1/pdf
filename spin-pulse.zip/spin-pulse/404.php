<?php
/**
 * The template for displaying 404 pages (not found)
 * @package Spin_Pulse
 */

get_header();
?>

<main id="primary" class="site-main sp-404-wrapper">
    <section class="error-404 not-found">
        
        <header class="sp-404-header">
            <div class="sp-404-visual">
                <svg width="120" height="120" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            </div>
            <h1 class="sp-404-title"><?php esc_html_e( '404', 'spin-pulse' ); ?></h1>
            <h2 class="sp-404-subtitle"><?php esc_html_e( 'Lost in the Game?', 'spin-pulse' ); ?></h2>
            <p class="sp-404-text"><?php esc_html_e( 'The page you’re looking for has moved or no longer exists.', 'spin-pulse' ); ?></p>
            <div class="sp-404-actions">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="sp-btn-primary">Return Home</a>
            </div>
        </header>

        <div class="sp-404-content">
            <div class="sp-404-search">
                <p>Try a quick search instead:</p>
                <?php get_search_form(); ?>
            </div>

            <hr class="sp-divider">

            <div class="sp-404-grid">
                <div class="sp-404-widget">
                    <h3>Recent Hits</h3>
                    <?php the_widget( 'WP_Widget_Recent_Posts', array('number' => 5) ); ?>
                </div>

                <div class="sp-404-widget">
                    <h3>Categories</h3>
                    <ul>
                        <?php wp_list_categories(array('orderby'=>'count','order'=>'DESC','show_count'=>1,'title_li'=>'','number'=>6)); ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</main>

<?php
get_footer();