<?php
/**
 * Template for displaying Single Casino Reviews (No Sidebar Default)
 *
 * @package SpinPulse
 */

get_header();

// Fetch the custom review data we saved in the backend
$rating = get_post_meta(get_the_ID(), 'sp_review_rating', true) ?: '5.0';
$bonus = get_post_meta(get_the_ID(), 'sp_review_bonus', true) ?: esc_html__('Exclusive Welcome Bonus', 'spin-pulse');
$play_link = get_post_meta(get_the_ID(), 'sp_review_link', true) ?: '#';
$pros_raw = get_post_meta(get_the_ID(), 'sp_review_pros', true);
$cons_raw = get_post_meta(get_the_ID(), 'sp_review_cons', true);

$pros = !empty($pros_raw) ? array_filter(array_map('trim', explode("\n", $pros_raw))) : [];
$cons = !empty($cons_raw) ? array_filter(array_map('trim', explode("\n", $cons_raw))) : [];

// Fetch Ratings (THEMEFOREST FIX: Translated Array Keys)
$ratings_data = [
    esc_html__('Cashout Speed', 'spin-pulse') => get_post_meta(get_the_ID(), 'sp_rating_cashout', true) ?: 98,
    esc_html__('Bonuses & Offers', 'spin-pulse') => get_post_meta(get_the_ID(), 'sp_rating_offers', true) ?: 95,
    esc_html__('Security', 'spin-pulse') => get_post_meta(get_the_ID(), 'sp_rating_secure', true) ?: 99,
    esc_html__('Software & Games', 'spin-pulse') => get_post_meta(get_the_ID(), 'sp_rating_games', true) ?: 92,
    esc_html__('Support', 'spin-pulse') => get_post_meta(get_the_ID(), 'sp_rating_support', true) ?: 90,
];

// Author Data
$current_author_id = get_post_field('post_author', get_the_ID());
$current_author_name = get_the_author_meta('display_name', $current_author_id);
$author_url = esc_url(get_author_posts_url($current_author_id));

// Social Links
$tw_url = get_the_author_meta('twitter', $current_author_id);
$fb_url = get_the_author_meta('facebook', $current_author_id);
$ig_url = get_the_author_meta('instagram', $current_author_id);
$li_url = get_the_author_meta('linkedin', $current_author_id);

// --- DYNAMIC HERO COLORS (The Fix) ---
$sp_hero_opts = get_option('spin_pulse_hero_settings', array());
$r_bg     = !empty($sp_hero_opts['review_bg_color']) ? $sp_hero_opts['review_bg_color'] : '#0f172a'; // Dark Slate
$r_border = !empty($sp_hero_opts['review_border_color']) ? $sp_hero_opts['review_border_color'] : '#00d67d'; // Emerald Green
$r_text   = !empty($sp_hero_opts['review_text_color']) ? $sp_hero_opts['review_text_color'] : '#ffffff'; // White Text
$r_accent = !empty($sp_hero_opts['review_accent_color']) ? $sp_hero_opts['review_accent_color'] : '#00d67d'; // Emerald Accent
?>

<main class="site-main min-h-screen bg-white">

    <style>
        .sp-custom-review-hero {
            background-color: <?php echo esc_attr($r_bg); ?>;
            border-bottom: 4px solid <?php echo esc_attr($r_border); ?>;
            color: <?php echo esc_attr($r_text); ?>;
        }
        .sp-custom-review-hero .sp-review-hero-text,
        .sp-custom-review-hero .sp-review-hero-title {
            color: <?php echo esc_attr($r_text); ?> !important;
        }
        .sp-custom-review-hero .sp-review-hero-accent {
            color: <?php echo esc_attr($r_accent); ?> !important;
        }
    </style>

    <section class="sp-custom-review-hero py-12 md:py-20 relative overflow-hidden">
        <div class="absolute inset-0 opacity-5 pointer-events-none" style="background-image: radial-gradient(#ffffff 1px, transparent 1px); background-size: 20px 20px;"></div>
        
        <div class="max-w-[1200px] mx-auto px-6 relative z-10">
            
            <div class="text-sm sp-review-hero-text mb-8 font-medium">
                <a href="<?php echo esc_url(home_url('/')); ?>" class="sp-review-hero-accent hover:underline"><?php esc_html_e('Home', 'spin-pulse'); ?></a> &raquo; 
                <?php 
                $review_cats = get_the_terms(get_the_ID(), 'review_category');
                if ($review_cats && !is_wp_error($review_cats)) {
                    echo '<a href="' . esc_url(get_term_link($review_cats[0])) . '" class="sp-review-hero-accent hover:underline">' . esc_html($review_cats[0]->name) . '</a> &raquo; ';
                }
                ?>
                <span class="sp-review-hero-text opacity-75"><?php the_title(); ?></span>
            </div>

            <div class="flex flex-col md:flex-row items-center md:items-start gap-10">
                
                <div class="w-40 h-40 md:w-56 md:h-56 bg-white rounded-3xl p-4 shadow-2xl flex-shrink-0 flex items-center justify-center border-4 border-slate-800">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('medium', ['class' => 'max-w-full max-h-full object-contain']); ?>
                    <?php else : ?>
                        <span class="sp-review-hero-text !text-slate-800 font-bold text-xl uppercase text-center"><?php the_title(); ?></span>
                    <?php endif; ?>
                </div>

                <div class="flex-grow text-center md:text-left flex flex-col justify-center">
                    <div class="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-4">
                        <span class="sp-review-hero-badge text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full border border-white/10" style="color: <?php echo esc_attr($r_text); ?>;"><?php esc_html_e('Verified Review', 'spin-pulse'); ?></span>
                        <div class="flex text-[#ffcc00] text-lg">
                            <?php 
                            $solid_stars = floor($rating);
                            $has_half = ($rating - $solid_stars) >= 0.5 ? 1 : 0;
                            $empty_stars = 5 - $solid_stars - $has_half;
                            for($i=0; $i<$solid_stars; $i++) echo '★';
                            if($has_half) echo '⯨';
                            for($i=0; $i<$empty_stars; $i++) echo '☆';
                            ?>
                        </div>
                        <span class="sp-review-hero-accent font-bold text-lg"><?php echo esc_html($rating); ?> / 5.0</span>
                    </div>

                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight sp-review-hero-title mb-4">
                        <?php printf( esc_html__( '%s Review', 'spin-pulse' ), get_the_title() ); ?>
                    </h1>
                    
                    <p class="text-xl md:text-2xl font-bold sp-review-hero-title opacity-90 mb-8 max-w-2xl">
                        <span class="sp-review-hero-accent"><?php esc_html_e('Bonus:', 'spin-pulse'); ?></span> <?php echo esc_html($bonus); ?>
                    </p>

                    <div class="flex flex-wrap items-center justify-center md:justify-start mt-4 pt-6 border-t border-white/10">
                        <div class="flex items-center gap-3">
                            <a href="<?php echo esc_url($author_url); ?>" class="block hover:opacity-80 transition-opacity">
                                <?php echo get_avatar($current_author_id, 46, '', '', array('class' => 'rounded-full border-2 border-white/20 transition-colors')); ?>
                            </a>
                            <div class="flex flex-col text-left">
                                <span class="sp-review-hero-text text-sm"><?php esc_html_e('Authored By', 'spin-pulse'); ?> <a href="<?php echo esc_url($author_url); ?>" class="sp-review-hero-title font-bold sp-review-hero-link"><?php echo esc_html($current_author_name); ?></a></span>
                                <span class="sp-review-hero-text text-xs mt-0.5 opacity-80"><?php printf( esc_html__( 'Last Updated: %s', 'spin-pulse' ), get_the_modified_date('F j, Y') ); ?></span>
                            </div>
                        </div>

                        <?php if ($tw_url || $fb_url || $ig_url || $li_url): ?>
                            <div class="hidden sm:block w-px h-10 bg-white/10 mx-16"></div>
                            <div class="flex items-center gap-2 mt-4 sm:mt-0">
                                <?php if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center sp-review-hero-text hover:bg-white hover:!text-[#0f1419] hover:border-white transition-all shadow-sm" aria-label="<?php esc_attr_e('X (Twitter)', 'spin-pulse'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg></a><?php endif; ?>
                                <?php if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center sp-review-hero-text hover:bg-[#1877F2] hover:!text-white hover:border-[#1877F2] transition-all shadow-sm" aria-label="<?php esc_attr_e('Facebook', 'spin-pulse'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></a><?php endif; ?>
                                <?php if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center sp-review-hero-text hover:bg-[#E1306C] hover:!text-white hover:border-[#E1306C] transition-all shadow-sm" aria-label="<?php esc_attr_e('Instagram', 'spin-pulse'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></a><?php endif; ?>
                                <?php if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" target="_blank" rel="noopener noreferrer" class="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center sp-review-hero-text hover:bg-[#0A66C2] hover:!text-white hover:border-[#0A66C2] transition-all shadow-sm" aria-label="<?php esc_attr_e('LinkedIn', 'spin-pulse'); ?>"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></a><?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <div class="max-w-[1200px] mx-auto px-6 py-16">
        
        <?php if (!empty($pros) || !empty($cons)): ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                <?php if (!empty($pros)): ?>
                <div class="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 md:p-8">
                    <h3 class="text-xl font-extrabold text-emerald-900 mb-6 flex items-center gap-2">
                        <span class="bg-emerald-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-lg shadow-sm">✓</span> <?php esc_html_e('What we like', 'spin-pulse'); ?>
                    </h3>
                    <ul class="space-y-4 m-0 p-0 list-none">
                        <?php foreach($pros as $pro): ?>
                            <li class="flex items-start gap-3 text-emerald-800 font-medium text-[15px] m-0 before:content-none leading-snug">
                                <svg class="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path></svg>
                                <?php echo esc_html($pro); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <?php if (!empty($cons)): ?>
                <div class="bg-rose-50 border border-rose-100 rounded-2xl p-6 md:p-8">
                    <h3 class="text-xl font-extrabold text-rose-900 mb-6 flex items-center gap-2">
                        <span class="bg-rose-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-lg shadow-sm">✕</span> <?php esc_html_e('Room for improvement', 'spin-pulse'); ?>
                    </h3>
                    <ul class="space-y-4 m-0 p-0 list-none">
                        <?php foreach($cons as $con): ?>
                            <li class="flex items-start gap-3 text-rose-800 font-medium text-[15px] m-0 before:content-none leading-snug">
                                <svg class="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M6 18L18 6M6 6l12 12"></path></svg>
                                <?php echo esc_html($con); ?>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <div class="bg-slate-50 border border-slate-200 rounded-2xl p-6 md:p-8 mb-12 shadow-sm">
            <h3 class="text-xl font-extrabold text-slate-900 mb-6 border-b border-slate-200 pb-4"><?php esc_html_e('Performance Ratings', 'spin-pulse'); ?></h3>
            <div class="flex flex-col gap-5">
                <?php foreach($ratings_data as $label => $score): ?>
                    <div class="sp-rating-item">
                        <div class="flex justify-between items-end mb-2">
                            <span class="font-bold text-slate-800 text-[15px]"><?php echo esc_html($label); ?></span>
                            <span class="sp-progress-number font-bold text-[#00d67d] text-[15px]" data-target="<?php echo esc_attr($score); ?>">0%</span>
                        </div>
                        <div class="w-full bg-slate-200 rounded-full h-2.5 overflow-hidden">
                            <div class="sp-progress-bar-fill h-full bg-[#00d67d] rounded-full transition-all duration-[1500ms] ease-out" data-width="<?php echo esc_attr($score); ?>%" style="width: 0%;"></div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <article class="sp-single-article">
            <div class="sp-single-content prose prose-slate prose-lg max-w-none">
                <?php 
                the_content(); 
                
                // THEMEFOREST FIX: Added pagination links for single post content
                wp_link_pages( array(
                    'before' => '<div class="page-links mt-8">' . esc_html__( 'Pages:', 'spin-pulse' ),
                    'after'  => '</div>',
                ) );
                ?>
            </div>
        </article>

        <div class="mt-16 bg-slate-900 rounded-2xl p-8 text-center border-4 border-slate-800 shadow-xl">
            <h2 class="text-2xl font-black text-white mb-2"><?php printf( esc_html__( 'Ready to play at %s?', 'spin-pulse' ), get_the_title() ); ?></h2>
            <p class="text-slate-400 mb-6 font-medium"><?php printf( esc_html__( 'Claim your %s today!', 'spin-pulse' ), esc_html($bonus) ); ?></p>
            <a href="<?php echo esc_url($play_link); ?>" target="_blank" rel="noopener nofollow" class="inline-block bg-[#00d67d] hover:bg-[#00b368] text-slate-900 font-black px-10 py-4 rounded-xl uppercase tracking-widest transition-transform transform hover:-translate-y-1 shadow-[0_10px_20px_-10px_rgba(0,214,125,0.5)]">
                <?php esc_html_e('Claim Bonus & Play Now', 'spin-pulse'); ?>
            </a>
        </div>

        <?php 
        if ( comments_open() || get_comments_number() ) :
            echo '<div class="mt-12">';
            comments_template();
            echo '</div>';
        endif;
        ?>

    </div>

    <section class="w-full bg-[#f8fafc] py-16 border-t border-slate-200 sp-review-recommendations">
        <div class="max-w-[1200px] mx-auto px-6">
            <h2 class="text-2xl md:text-3xl font-extrabold text-slate-900 mb-8 text-center"><?php esc_html_e('More Recommendations', 'spin-pulse'); ?></h2>
            
            <?php 
            $r_cat_slug = '';
            if (isset($review_cats) && !is_wp_error($review_cats) && !empty($review_cats)) {
                $r_cat_slug = $review_cats[0]->slug;
            }
            
            // Output the Dynamic Grid Shortcode exactly as configured
            echo do_shortcode('[sp_casino_cards limit="3" exclude="' . get_the_ID() . '" category="' . esc_attr($r_cat_slug) . '"]'); 
            ?>
        </div>
    </section>

</main>

<?php get_footer(); ?>