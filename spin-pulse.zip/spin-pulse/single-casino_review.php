<?php
/**
 * Template for displaying Single Casino Reviews
 *
 * @package SpinPulse
 */

get_header();

// Fetch the custom review data we saved in the backend
$rating = get_post_meta(get_the_ID(), 'sp_review_rating', true) ?: '5.0';
$bonus = get_post_meta(get_the_ID(), 'sp_review_bonus', true) ?: 'Exclusive Welcome Bonus';
$play_link = get_post_meta(get_the_ID(), 'sp_review_link', true) ?: '#';
$pros_raw = get_post_meta(get_the_ID(), 'sp_review_pros', true);
$cons_raw = get_post_meta(get_the_ID(), 'sp_review_cons', true);

// Convert pros/cons text areas into arrays
$pros = !empty($pros_raw) ? array_filter(array_map('trim', explode("\n", $pros_raw))) : [];
$cons = !empty($cons_raw) ? array_filter(array_map('trim', explode("\n", $cons_raw))) : [];
?>

<main class="site-main min-h-screen bg-white">

    <section class="bg-slate-900 py-16 md:py-24 relative overflow-hidden border-b-4 border-[#00d67d]">
        <div class="absolute inset-0 opacity-5 pointer-events-none" style="background-image: radial-gradient(#ffffff 1px, transparent 1px); background-size: 20px 20px;"></div>
        
        <div class="max-w-[1200px] mx-auto px-6 relative z-10">
            <div class="flex flex-col md:flex-row items-center md:items-start gap-10">
                
                <div class="w-40 h-40 md:w-56 md:h-56 bg-white rounded-3xl p-4 shadow-2xl flex-shrink-0 flex items-center justify-center border-4 border-slate-800">
                    <?php if (has_post_thumbnail()) : ?>
                        <?php the_post_thumbnail('medium', ['class' => 'max-w-full max-h-full object-contain']); ?>
                    <?php else : ?>
                        <span class="text-slate-400 font-bold text-xl uppercase text-center"><?php the_title(); ?></span>
                    <?php endif; ?>
                </div>

                <div class="flex-grow text-center md:text-left flex flex-col justify-center">
                    <div class="flex flex-wrap items-center justify-center md:justify-start gap-4 mb-4">
                        <span class="bg-slate-800 text-white text-xs font-black uppercase tracking-widest px-3 py-1 rounded-full border border-slate-700">Verified Review</span>
                        <div class="flex text-[#ffcc00] text-lg">
                            <?php 
                            $solid_stars = floor($rating);
                            $has_half = ($rating - $solid_stars) >= 0.5 ? 1 : 0;
                            $empty_stars = 5 - $solid_stars - $has_half;
                            for($i=0; $i<$solid_stars; $i++) echo '★';
                            if($has_half) echo '⯨'; // Half star symbol
                            for($i=0; $i<$empty_stars; $i++) echo '☆';
                            ?>
                        </div>
                        <span class="text-[#00d67d] font-bold text-lg"><?php echo esc_html($rating); ?> / 5.0</span>
                    </div>

                    <h1 class="text-4xl md:text-5xl lg:text-6xl font-black tracking-tight text-white mb-4">
                        <?php the_title(); ?> Review
                    </h1>
                    
                    <p class="text-xl md:text-2xl font-bold text-slate-300 mb-8 max-w-2xl">
                        <span class="text-[#00d67d]">Bonus:</span> <?php echo esc_html($bonus); ?>
                    </p>

                    <div class="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
                        <a href="<?php echo esc_url($play_link); ?>" target="_blank" rel="noopener nofollow" class="bg-[#00d67d] hover:bg-[#00b368] text-slate-900 font-black text-lg px-10 py-4 rounded-xl uppercase tracking-widest transition-transform transform hover:-translate-y-1 shadow-[0_10px_20px_-10px_rgba(0,214,125,0.5)] flex items-center gap-3">
                            Play Now
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M14 5l7 7m0 0l-7 7m7-7H3"></path></svg>
                        </a>
                        <span class="text-slate-500 text-xs">T&Cs Apply. 18+ Only.</span>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <div class="sp-right-sidebar-main-wrapper py-16">
        <div class="sp-right-sidebar-container">
            
            <div class="sp-right-sidebar-content w-full md:w-2/3">
                
                <?php if (!empty($pros) || !empty($cons)): ?>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                        
                        <?php if (!empty($pros)): ?>
                        <div class="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 md:p-8">
                            <h3 class="text-xl font-extrabold text-emerald-900 mb-6 flex items-center gap-2">
                                <span class="bg-emerald-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-lg shadow-sm">✓</span> 
                                What we like
                            </h3>
                            <ul class="space-y-4 m-0 p-0 list-none">
                                <?php foreach($pros as $pro): ?>
                                    <li class="flex items-start gap-3 text-emerald-800 font-medium text-[15px] m-0 before:content-none leading-snug">
                                        <svg class="w-5 h-5 text-emerald-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"></path></svg>
                                        <?php echo esc_html($pro); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                        <?php if (!empty($cons)): ?>
                        <div class="bg-rose-50 border border-rose-100 rounded-2xl p-6 md:p-8">
                            <h3 class="text-xl font-extrabold text-rose-900 mb-6 flex items-center gap-2">
                                <span class="bg-rose-500 text-white w-8 h-8 rounded-full flex items-center justify-center text-lg shadow-sm">✕</span> 
                                Room for improvement
                            </h3>
                            <ul class="space-y-4 m-0 p-0 list-none">
                                <?php foreach($cons as $con): ?>
                                    <li class="flex items-start gap-3 text-rose-800 font-medium text-[15px] m-0 before:content-none leading-snug">
                                        <svg class="w-5 h-5 text-rose-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M6 18L18 6M6 6l12 12"></path></svg>
                                        <?php echo esc_html($con); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                        <?php endif; ?>

                    </div>
                <?php endif; ?>

                <article class="sp-single-article">
                    <div class="sp-single-content prose prose-slate prose-lg max-w-none">
                        <?php the_content(); ?>
                    </div>
                </article>

                <div class="mt-16 bg-slate-900 rounded-2xl p-8 text-center border-4 border-slate-800 shadow-xl">
                    <h2 class="text-2xl font-black text-white mb-2">Ready to play at <?php the_title(); ?>?</h2>
                    <p class="text-slate-400 mb-6 font-medium">Claim your <?php echo esc_html($bonus); ?> today!</p>
                    <a href="<?php echo esc_url($play_link); ?>" target="_blank" rel="noopener nofollow" class="inline-block bg-[#00d67d] hover:bg-[#00b368] text-slate-900 font-black px-10 py-4 rounded-xl uppercase tracking-widest transition-transform transform hover:-translate-y-1 shadow-[0_10px_20px_-10px_rgba(0,214,125,0.5)]">
                        Claim Bonus & Play Now
                    </a>
                </div>
                
            </div>

            <aside class="sp-right-sidebar-sidebar w-full md:w-1/3">
                <?php if (is_active_sidebar('sidebar-right')) : ?>
                    <?php dynamic_sidebar('sidebar-right'); ?>
                <?php else : ?>
                    <p class="text-gray-500 italic"><?php esc_html_e('Add widgets to "Right Sidebar" in Appearance > Widgets.', 'spin-pulse'); ?></p>
                <?php endif; ?>
            </aside>

        </div>
    </div>
</main>

<?php get_footer(); ?>