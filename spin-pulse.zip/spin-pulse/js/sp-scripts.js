/**
 * Namespace: sp-
 */
document.addEventListener('DOMContentLoaded', function() {
    var spScrollBtn = document.getElementById("sp-back-to-top");

    if (spScrollBtn) {
        window.onscroll = function() {
            if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
                spScrollBtn.style.display = "block";
            } else {
                spScrollBtn.style.display = "none";
            }
        };

        spScrollBtn.addEventListener("click", function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }
});