'use strict';

document.addEventListener('DOMContentLoaded', function() {
    
    /* ==========================================================================
       1. BACK TO TOP BUTTON
       ========================================================================== */
    const spScrollBtn = document.getElementById("sp-back-to-top");

    if (spScrollBtn) {
        // Use addEventListener instead of onscroll to avoid conflicts with plugins
        window.addEventListener('scroll', function() {
            if (document.body.scrollTop > 400 || document.documentElement.scrollTop > 400) {
                spScrollBtn.style.display = "block";
            } else {
                spScrollBtn.style.display = "none";
            }
        });

        spScrollBtn.addEventListener("click", function() {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    /* ==========================================================================
       2. HEADER SEARCH TOGGLE
       ========================================================================== */
    const searchToggle = document.getElementById('search-menu-toggle');
    const searchDropdown = document.getElementById('search-dropdown');
    const searchInput = document.getElementById('header-search-input');

    // Toggle Search Dropdown
    if (searchToggle && searchDropdown) {
        searchToggle.addEventListener('click', function(e) {
            e.preventDefault();
            searchDropdown.classList.toggle('hidden');
            
            // If the dropdown is opened, automatically focus the cursor in the input box
            if (!searchDropdown.classList.contains('hidden') && searchInput) {
                setTimeout(() => searchInput.focus(), 50);
            }
        });
    }

    // Close search if user clicks outside of it
    document.addEventListener('click', function(e) {
        if (searchToggle && searchDropdown && !searchToggle.contains(e.target) && !searchDropdown.contains(e.target) && !searchDropdown.classList.contains('hidden')) {
            searchDropdown.classList.add('hidden');
        }
    });

});