/**
 * File navigation.js.
 *
 * Handles toggling the navigation menu for small screens and enables keyboard
 * navigation support for dropdown menus.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        const siteNavigation = document.getElementById('masthead');
        const mobileToggle = document.getElementById('mobile-menu-toggle');
        const mobileMenu = document.getElementById('mobile-menu');

        // 1. Mobile Menu Logic
        if (mobileToggle && mobileMenu) {
            mobileToggle.addEventListener('click', function() {
                const isExpanded = mobileToggle.getAttribute('aria-expanded') === 'true';
                
                // Toggle accessibility attributes
                mobileToggle.setAttribute('aria-expanded', !isExpanded);
                mobileMenu.classList.toggle('hidden');
                
                // Optional: Toggle a class on body to prevent scrolling when menu is open
                document.body.classList.toggle('mobile-menu-open');
            });

            // Close mobile menu when clicking outside
            document.addEventListener('click', function(event) {
                // Safety check: ensure siteNavigation exists before checking .contains()
                if (siteNavigation) {
                    const isClickInside = siteNavigation.contains(event.target);
                    if (!isClickInside && !mobileMenu.classList.contains('hidden')) {
                        mobileMenu.classList.add('hidden');
                        mobileToggle.setAttribute('aria-expanded', 'false');
                    }
                }
            });
        }

        // 2. Keyboard Accessibility (Crucial for ThemeForest Approval)
        // Note: Fallback to querying the 'ul' inside the nav if 'primary-menu' ID isn't found
        const menu = document.getElementById('primary-menu') || document.querySelector('nav ul');
        if (!menu) return;

        const links = menu.getElementsByTagName('a');

        // Toggle focus class for keyboard users
        for (const link of links) {
            link.addEventListener('focus', toggleFocus, true);
            link.addEventListener('blur', toggleFocus, true);
        }

        /**
         * Sets or removes .focus class on an element for dropdown visibility.
         */
        function toggleFocus() {
            let self = this;
            
            // Move up through the ancestors safely
            while (self && self.nodeType === 1) { // Ensure it is an Element node
                // Stop traversing when we hit the main nav container
                if (self.tagName.toLowerCase() === 'nav') {
                    break;
                }
                
                if (self.tagName.toLowerCase() === 'li') {
                    self.classList.toggle('focus');
                }
                self = self.parentNode;
            }
        }

        /**
         * Touch support for sub-menus
         */
        const linksWithChildren = menu.querySelectorAll('.menu-item-has-children > a');
        for (const link of linksWithChildren) {
            link.addEventListener('touchstart', function(e) {
                const menuItem = this.parentNode;
                if (!menuItem.classList.contains('focus')) {
                    e.preventDefault();
                    // Close other open sub-menus
                    for (const sibling of menuItem.parentNode.children) {
                        if (menuItem !== sibling) {
                            sibling.classList.remove('focus');
                        }
                    }
                    menuItem.classList.add('focus');
                }
            }, { passive: false }); // Best practice for touch event listeners
        }
    });
})();