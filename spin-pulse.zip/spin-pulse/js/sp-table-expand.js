'use strict';

document.addEventListener('DOMContentLoaded', function() {
    // Select all "Read More" buttons
    const expandButtons = document.querySelectorAll('.sp-read-more-btn');

    if (expandButtons.length > 0) {
        expandButtons.forEach(function(btn) {
            btn.addEventListener('click', function(e) {
                e.preventDefault();
                
                // Find the closest parent row and then the expanded content div within it
                const triggerDiv = this.parentElement;
                
                // Safety check: ensure triggerDiv exists
                if (!triggerDiv) return;
                
                const contentDiv = triggerDiv.nextElementSibling;
                
                // Safety check: ensure the content div wasn't deleted from the HTML
                if (!contentDiv) return;
                
                // Toggle visibility
                if (contentDiv.style.display === 'block') {
                    contentDiv.style.display = 'none';
                    this.classList.remove('active');
                    
                    // ThemeForest Fix: Avoid .innerHTML to bypass automated security flags
                    this.textContent = 'Read More ';
                    const arrow = document.createElement('span');
                    arrow.className = 'sp-arrow';
                    arrow.textContent = '▼';
                    this.appendChild(arrow);
                    
                } else {
                    contentDiv.style.display = 'block';
                    this.classList.add('active');
                    
                    // ThemeForest Fix: Avoid .innerHTML
                    this.textContent = 'Read Less ';
                    const arrow = document.createElement('span');
                    arrow.className = 'sp-arrow';
                    arrow.textContent = '▲';
                    this.appendChild(arrow);
                }
            });
        });
    }
});