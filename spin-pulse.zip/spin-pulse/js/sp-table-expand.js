document.addEventListener('DOMContentLoaded', function() {
    // Select all "Read More" buttons
    const expandButtons = document.querySelectorAll('.sp-read-more-btn');

    expandButtons.forEach(function(btn) {
        btn.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Find the closest parent row and then the expanded content div within it
            // This ensures we only toggle the specific card clicked
            const triggerDiv = this.parentElement;
            const contentDiv = triggerDiv.nextElementSibling;
            
            // Toggle visibility
            if (contentDiv.style.display === 'block') {
                contentDiv.style.display = 'none';
                this.classList.remove('active');
                this.innerHTML = 'Read More <span class="sp-arrow">▼</span>';
            } else {
                contentDiv.style.display = 'block';
                this.classList.add('active');
                this.innerHTML = 'Read Less <span class="sp-arrow">▲</span>';
            }
        });
    });
});