'use strict';

document.addEventListener("DOMContentLoaded", function() {
    // Target the parent wrapper of each rating
    const ratingItems = document.querySelectorAll('.sp-rating-item');
    
    // Only initialize the observer if there are items to animate on the page
    if (ratingItems.length > 0) {
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const item = entry.target;
                    const bar = item.querySelector('.sp-progress-bar-fill');
                    const numberEl = item.querySelector('.sp-progress-number');
                    
                    // Safety Check: Ensure both elements exist before trying to read their attributes
                    if (bar && numberEl) {
                        const targetWidth = bar.getAttribute('data-width') || '0%';
                        const targetNumber = parseInt(numberEl.getAttribute('data-target'), 10) || 0;
                        
                        // 1. Animate the Bar
                        setTimeout(() => {
                            bar.style.width = targetWidth;
                        }, 100);
                        
                        // 2. Animate the Number Count Up
                        let startTimestamp = null;
                        const duration = 1500; // 1.5 seconds to match the CSS animation speed
                        
                        const step = (timestamp) => {
                            if (!startTimestamp) startTimestamp = timestamp;
                            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                            
                            // Easing function to slow down smoothly at the end
                            const easeOutCubic = 1 - Math.pow(1 - progress, 3); 
                            
                            const currentNum = Math.floor(easeOutCubic * targetNumber);
                            numberEl.textContent = currentNum + '%';
                            
                            if (progress < 1) {
                                window.requestAnimationFrame(step);
                            } else {
                                numberEl.textContent = targetNumber + '%'; // Lock in the final number perfectly
                            }
                        };
                        
                        setTimeout(() => {
                            window.requestAnimationFrame(step);
                        }, 100);
                    }

                    // Stop observing once animated (even if it failed the safety check, we don't want to keep trying)
                    observer.unobserve(item); 
                }
            });
        }, { threshold: 0.1 });

        ratingItems.forEach(item => {
            observer.observe(item);
        });
    }
});