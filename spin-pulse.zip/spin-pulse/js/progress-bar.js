document.addEventListener("DOMContentLoaded", function() {
    // Target the parent wrapper of each rating
    const ratingItems = document.querySelectorAll('.sp-rating-item');
    
    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const item = entry.target;
                const bar = item.querySelector('.sp-progress-bar-fill');
                const numberEl = item.querySelector('.sp-progress-number');
                
                const targetWidth = bar.getAttribute('data-width');
                const targetNumber = parseInt(numberEl.getAttribute('data-target'), 10);
                
                // 1. Animate the Bar
                setTimeout(() => {
                    bar.style.width = targetWidth;
                }, 100);
                
                // 2. Animate the Number Count Up
                let startTimestamp = null;
                const duration = 1500; // 1.5 seconds to match the CSS animation speed
                
                const step = (timestamp) => {
                    if (!startTimestamp) startTimestamp = timestamp;
                    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                    
                    // Easing function to slow down smoothly at the end
                    const easeOutCubic = 1 - Math.pow(1 - progress, 3); 
                    
                    const currentNum = Math.floor(easeOutCubic * targetNumber);
                    numberEl.innerText = currentNum + '%';
                    
                    if (progress < 1) {
                        window.requestAnimationFrame(step);
                    } else {
                        numberEl.innerText = targetNumber + '%'; // Lock in the final number perfectly
                    }
                };
                
                setTimeout(() => {
                    window.requestAnimationFrame(step);
                }, 100);

                // Stop observing once animated
                observer.unobserve(item); 
            }
        });
    }, { threshold: 0.1 });

    ratingItems.forEach(item => {
        observer.observe(item);
    });
});