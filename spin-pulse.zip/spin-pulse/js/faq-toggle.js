document.querySelectorAll('.spin-pulse-faq-question').forEach(item => {
    item.addEventListener('click', () => {
        const parent = item.parentElement;
        parent.classList.toggle('active');
        const toggle = item.querySelector('.spin-pulse-faq-toggle');
        toggle.textContent = parent.classList.contains('active') ? '-' : '+';
    });
});