'use strict';

document.addEventListener('DOMContentLoaded', function() {
    const faqQuestions = document.querySelectorAll('.spin-pulse-faq-question');

    // Only run if FAQs actually exist on the page
    if (faqQuestions.length > 0) {
        faqQuestions.forEach(function(item) {
            item.addEventListener('click', function() {
                const parent = item.parentElement;
                
                // Safety check: ensure parent exists
                if (parent) {
                    parent.classList.toggle('active');
                    
                    const toggle = item.querySelector('.spin-pulse-faq-toggle');
                    // Safety check: ensure the toggle span wasn't deleted by the user
                    if (toggle) {
                        toggle.textContent = parent.classList.contains('active') ? '-' : '+';
                    }
                }
            });
        });
    }
});