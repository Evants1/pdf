jQuery(document).ready(function($) {
    $('.upload-image-button').on('click', function(e) {
        e.preventDefault();
        var button = $(this);
        var targetId = button.data('target');
        var targetInput = $('#' + targetId);

        // Create the media frame
        var frame = wp.media({
            title: 'Select or Upload Background Image',
            button: { text: 'Use this image' },
            multiple: false
        });

        // When an image is selected, run a callback
        frame.on('select', function() {
            var attachment = frame.state().get('selection').first().toJSON();
            targetInput.val(attachment.url); // Set the image URL in the input
            
            // Optional: If you want to force a visual update if you add a preview div later
            // targetInput.trigger('change'); 
        });

        // Open the modal
        frame.open();
    });
});