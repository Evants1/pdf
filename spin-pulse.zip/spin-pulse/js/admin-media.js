'use strict';

jQuery(document).ready(function($) {
    // Cache the media frame so it's not recreated on every click (ThemeForest requirement)
    var spMediaFrame;

    $('.upload-image-button').on('click', function(e) {
        e.preventDefault();
        
        var button = $(this);
        var targetId = button.data('target');
        var targetInput = $('#' + targetId);

        // Safety check: ensure wp.media API loaded properly
        if (typeof wp === 'undefined' || !wp.media) {
            console.error('Spin Pulse: WordPress media uploader is not available.');
            return;
        }

        // If the frame already exists, just open it (prevents memory leaks)
        if (spMediaFrame) {
            spMediaFrame.open();
            return;
        }

        // Set up translation variables (falls back to English if PHP localization is missing)
        var frameTitle = (typeof spAdminMedia !== 'undefined' && spAdminMedia.title) ? spAdminMedia.title : 'Select or Upload Image';
        var buttonText = (typeof spAdminMedia !== 'undefined' && spAdminMedia.buttonText) ? spAdminMedia.buttonText : 'Use this image';

        // Create the media frame
        spMediaFrame = wp.media({
            title: frameTitle,
            button: { text: buttonText },
            multiple: false
        });

        // When an image is selected, run a callback
        spMediaFrame.on('select', function() {
            var attachment = spMediaFrame.state().get('selection').first().toJSON();
            
            if (targetInput.length) {
                targetInput.val(attachment.url); // Set the image URL in the input
                targetInput.trigger('change');   // Good practice to trigger change for other scripts listening
            }
        });

        // Open the modal
        spMediaFrame.open();
    });
});