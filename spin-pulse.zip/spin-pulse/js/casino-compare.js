(function() {
    "use strict";

    const initCompare = () => {
        console.log("Spin Pulse: Comparison engine initialized.");

        const checkboxes = document.querySelectorAll('.sp-compare-checkbox');
        const compareBar = document.getElementById('compareBar');
        const compareCount = document.getElementById('compareCount');
        const compareBtn = document.getElementById('compareBtn');

        if (!compareBar) {
            console.error("Spin Pulse: Element #compareBar not found in HTML.");
            return;
        }

        // Handle Checkbox Changes
        const updateBar = () => {
            const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
            const count = checked.length;

            if (count > 2) {
                alert('Maximum 2 brands for comparison.');
                return false;
            }

            // FORCE VISIBILITY VIA JS (Bypasses CSS issues)
            if (count > 0) {
                compareBar.style.transform = "translateY(0)";
                compareBar.style.display = "flex";
                compareBar.classList.add('active');
            } else {
                compareBar.style.transform = "translateY(100%)";
                compareBar.classList.remove('active');
            }

            if (compareCount) compareCount.textContent = count;
            if (compareBtn) compareBtn.disabled = (count !== 2);
        };

        // Attach listeners
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('sp-compare-checkbox')) {
                if (updateBar() === false) {
                    e.target.checked = false;
                }
            }
        });

        // Toggle "Read Facts"
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('sp-toggle-btn')) {
                const row = e.target.closest('tr').nextElementSibling;
                if (row && row.classList.contains('sp-expand-row')) {
                    const content = row.querySelector('.sp-expand-content');
                    content.style.display = (content.style.display === 'grid') ? 'none' : 'grid';
                    e.target.textContent = (content.style.display === 'grid') ? 'Hide Facts ▲' : 'Read Facts ▼';
                }
            }
        });
    };

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initCompare);
    } else {
        initCompare();
    }
})();