(function() {
    "use strict";

    // Wait for DOM to be fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initSpinPulseCompare);
    } else {
        initSpinPulseCompare();
    }

    function initSpinPulseCompare() {
        const els = {
            checkboxes: document.querySelectorAll('.sp-compare-checkbox'),
            bar: document.getElementById('sp-compare-bar'),
            count: document.getElementById('sp-compare-count'),
            btn: document.getElementById('sp-compare-btn'),
            clear: document.getElementById('sp-clear-compare'),
            modal: document.getElementById('sp-compare-modal'),
            modalContainer: document.getElementById('sp-modal-container'),
            modalContent: document.getElementById('sp-modal-content'),
            closeBtn: document.getElementById('sp-close-modal-btn'),
            closeBg: document.getElementById('sp-close-modal-bg')
        };

        // 1. Toggle "Read Facts" logic with event delegation
        document.addEventListener('click', (e) => {
            const toggleBtn = e.target.closest('.sp-toggle-btn');
            if (toggleBtn) {
                e.preventDefault();
                const row = toggleBtn.closest('tr');
                if (!row || !row.nextElementSibling) return;
                
                const expandRow = row.nextElementSibling;
                const content = expandRow.querySelector('.sp-expand-content');
                if (!content) return;
                
                const icon = toggleBtn.querySelector('i');
                const isActive = content.classList.contains('active');
                
                content.classList.toggle('active');
                if (icon) {
                    icon.textContent = isActive ? '▼' : '▲';
                }
            }
        });

        // 2. Update Comparison UI State
        const updateUI = () => {
            const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
            const count = checked.length;

            if (els.bar) {
                if (count > 0) {
                    els.bar.classList.remove('hidden');
                    // Force reflow for animation
                    void els.bar.offsetWidth;
                    els.bar.style.transform = 'translateX(-50%) translateY(0)';
                } else {
                    els.bar.style.transform = 'translateX(-50%) translateY(100px)';
                    setTimeout(() => {
                        els.bar.classList.add('hidden');
                    }, 300);
                }
            }
            
            if (els.count) els.count.textContent = count;
            if (els.btn) els.btn.disabled = (count !== 2);
        };

        // 3. Handle checkbox selection
        const handleCheckboxChange = (e) => {
            const checkbox = e.target;
            if (checkbox.classList.contains('sp-compare-checkbox')) {
                const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
                if (checked.length > 2) {
                    checkbox.checked = false;
                    // Show a nicer alert
                    const alertDiv = document.createElement('div');
                    alertDiv.innerHTML = `
                        <div class="fixed top-4 left-1/2 -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg z-[99999] animate-slide-down">
                            <div class="flex items-center gap-2">
                                <svg class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                                    <path fill-rule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clip-rule="evenodd"/>
                                </svg>
                                <span class="font-bold text-sm">Maximum 2 casinos can be compared at once</span>
                            </div>
                        </div>
                    `;
                    document.body.appendChild(alertDiv);
                    setTimeout(() => alertDiv.remove(), 3000);
                }
                updateUI();
            }
        };

        // 4. Generate Comparison Data
        const openComparison = () => {
            const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
            if (checked.length !== 2) return;
            
            const brands = Array.from(checked).map(cb => ({
                name: cb.dataset.name,
                logo: cb.dataset.logo,
                bonus: cb.dataset.bonus,
                payout: cb.dataset.payout,
                games: cb.dataset.games,
                license: cb.dataset.license,
                link: cb.dataset.link
            }));

            let html = `<div class="grid grid-cols-2 gap-8 p-4">`;
            
            brands.forEach((brand, index) => {
                html += `
                    <div class="flex flex-col items-center text-center space-y-4 p-6 rounded-xl ${index === 0 ? 'bg-slate-50' : ''}">
                        <img src="${brand.logo}" class="h-16 w-auto object-contain mb-2">
                        <h4 class="font-bold text-lg text-slate-900">${brand.name}</h4>
                        <div class="w-full space-y-3">
                            <div class="flex justify-between items-center border-b border-slate-200 pb-2">
                                <span class="text-sm text-slate-500">Bonus</span>
                                <span class="font-bold text-emerald-600">${brand.bonus}</span>
                            </div>
                            <div class="flex justify-between items-center border-b border-slate-200 pb-2">
                                <span class="text-sm text-slate-500">Payout</span>
                                <span class="font-bold text-emerald-600">${brand.payout}</span>
                            </div>
                            <div class="flex justify-between items-center border-b border-slate-200 pb-2">
                                <span class="text-sm text-slate-500">Games</span>
                                <span class="font-bold">${brand.games}</span>
                            </div>
                            <div class="flex justify-between items-center border-b border-slate-200 pb-2">
                                <span class="text-sm text-slate-500">License</span>
                                <span class="font-bold">${brand.license}</span>
                            </div>
                        </div>
                        <a href="${brand.link}" class="w-full bg-slate-900 text-white py-3 rounded-xl font-bold uppercase text-xs hover:bg-slate-800 transition-colors mt-4">Visit Casino</a>
                    </div>`;
            });

            html += `</div>`;
            els.modalContent.innerHTML = html;
            
            // Show modal with animation
            els.modal.classList.remove('opacity-0', 'pointer-events-none');
            els.modalContainer.classList.remove('scale-95');
            els.modalContainer.classList.add('scale-100');
            
            // Prevent body scroll
            document.body.style.overflow = 'hidden';
        };

        // 5. Close modal function
        const closeModal = () => {
            els.modal.classList.add('opacity-0', 'pointer-events-none');
            els.modalContainer.classList.remove('scale-100');
            els.modalContainer.classList.add('scale-95');
            
            // Restore body scroll
            document.body.style.overflow = '';
        };

        // Event Listeners
        document.addEventListener('change', handleCheckboxChange);
        
        if (els.btn) {
            els.btn.addEventListener('click', openComparison);
        }
        
        if (els.closeBtn) {
            els.closeBtn.addEventListener('click', closeModal);
        }
        
        if (els.closeBg) {
            els.closeBg.addEventListener('click', closeModal);
        }
        
        if (els.clear) {
            els.clear.addEventListener('click', () => {
                document.querySelectorAll('.sp-compare-checkbox:checked').forEach(c => {
                    c.checked = false;
                });
                updateUI();
            });
        }

        // Close modal on ESC key
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && !els.modal.classList.contains('opacity-0')) {
                closeModal();
            }
        });

        // Initialize UI
        updateUI();
    }
})();