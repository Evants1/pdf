(function() {
    "use strict";

    const initSpinPulseCompare = () => {
        // THEMEFOREST REQUIREMENT: Use namespaced IDs (sp-*) to prevent conflicts
        const els = {
            bar: document.getElementById('sp-compare-bar'),
            count: document.getElementById('sp-compare-count'),
            btn: document.getElementById('sp-compare-btn'),
            clear: document.getElementById('sp-clear-compare'),
            modal: document.getElementById('sp-compare-modal'),
            modalContainer: document.getElementById('sp-modal-container'),
            alert: document.getElementById('sp-alert'),
            alertText: document.getElementById('sp-alert-text'),
            closeBtn: document.getElementById('sp-close-modal-btn'),
            closeBg: document.getElementById('sp-close-modal-bg')
        };

        // --- CUSTOM ALERT TOAST ---
        const showAlert = (msg) => {
            if (!els.alert || !els.alertText) return;

            els.alertText.textContent = msg;
            
            // We use inline styles here for the toast pop-up animation
            els.alert.style.transform = "translateX(-50%) translateY(0)";
            els.alert.style.opacity = "1";

            setTimeout(() => {
                els.alert.style.transform = "translateX(-50%) translateY(-20px)";
                els.alert.style.opacity = "0";
            }, 3000);
        };

        // --- UI STATE MANAGER ---
        const updateUI = () => {
            // Select all checkboxes
            const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
            const count = checked.length;

            // 1. Toggle Bar Visibility using CSS Classes
            // We use 'is-active' instead of manual JS styling to respect the CSS animations
            if (els.bar) {
                if (count > 0) {
                    els.bar.classList.add('is-active');
                } else {
                    els.bar.classList.remove('is-active');
                }
            }
            
            // 2. Update Counter
            if (els.count) els.count.textContent = count;
            
            // 3. Enable/Disable Compare Button (Strictly 2 items required)
            if (els.btn) {
                els.btn.disabled = (count !== 2);
                // Add a pulse animation class if ready
                if (count === 2) {
                    els.btn.classList.add('sp-pulse-animate');
                } else {
                    els.btn.classList.remove('sp-pulse-animate');
                }
            }
        };

        // --- EVENT HANDLERS ---

        // Open Modal
        if (els.btn) {
            els.btn.addEventListener('click', () => {
                if (!els.modal || !els.modalContainer) return;

                // Show Modal
                els.modal.classList.remove('opacity-0', 'pointer-events-none');
                els.modalContainer.style.transform = "scale(1)";

                // Hide the sticky bar while modal is open to prevent clutter
                if (els.bar) els.bar.classList.remove('is-active');
            });
        }

        // Close Modal
        const closeModal = () => {
            if (!els.modal || !els.modalContainer) return;

            els.modal.classList.add('opacity-0', 'pointer-events-none');
            els.modalContainer.style.transform = "scale(0.95)";
            
            // Re-check UI to see if we need to show the bar again
            updateUI(); 
        };

        if (els.closeBtn) els.closeBtn.onclick = closeModal;
        if (els.closeBg) els.closeBg.onclick = closeModal;

        // Checkbox Logic (Event Delegation)
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('sp-compare-checkbox')) {
                const checked = document.querySelectorAll('.sp-compare-checkbox:checked');
                
                // Enforce Limit
                if (checked.length > 2) {
                    showAlert("Maximum 2 brands allowed for comparison");
                    e.target.checked = false; // Undo selection
                }
                
                updateUI();
            }
        });

        // Clear All Logic
        if (els.clear) {
            els.clear.onclick = (e) => {
                e.preventDefault(); // Prevent jump
                document.querySelectorAll('.sp-compare-checkbox:checked').forEach(cb => cb.checked = false);
                updateUI();
            };
        }
    };

    // Safe Loading: Works even if script is in <head> or footer
    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", initSpinPulseCompare);
    } else {
        initSpinPulseCompare();
    }
})();