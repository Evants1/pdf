document.addEventListener('DOMContentLoaded', function() {
    const checkboxes = document.querySelectorAll('.compare-check');
    const modal = document.getElementById('compareModal');
    const closeBtn = document.getElementById('closeModal');
    const content = document.getElementById('comparisonContent');
    const readMoreTriggers = document.querySelectorAll('.read-more-trigger');

    // Toggle Modal
    function showComparison(selected) {
        content.innerHTML = ''; 
        selected.forEach(input => {
            const card = input.closest('.casino-card-wrapper');
            const d = card.dataset;
            content.innerHTML += `
                <div class="p-10 text-center space-y-6">
                    <img src="${d.img}" class="w-20 h-20 mx-auto rounded-full bg-[#f3f0eb] p-2 border border-slate-100">
                    <h4 class="text-2xl font-black text-slate-800">${d.name}</h4>
                    <div class="bg-slate-50 p-6 rounded-3xl text-left space-y-4">
                        <div class="flex justify-between border-b pb-2"><span class="text-[10px] font-bold text-slate-400">Bonus</span><span class="text-xs font-bold">${d.bonus}</span></div>
                        <div class="flex justify-between"><span class="text-[10px] font-bold text-slate-400">Speed</span><span class="text-xs font-bold text-emerald-600">${d.speed}</span></div>
                    </div>
                    <a href="#" class="block w-full bg-black text-white font-bold py-4 rounded-full text-[10px] uppercase tracking-widest">Visit Site</a>
                </div>`;
        });
        modal.classList.remove('hidden');
        modal.classList.add('flex');
        document.body.style.overflow = 'hidden';
    }

    checkboxes.forEach(box => {
        box.addEventListener('change', function() {
            const checked = document.querySelectorAll('.compare-check:checked');
            if (checked.length === 2) showComparison(checked);
            else if (checked.length > 2) { this.checked = false; alert("Choose 2 brands."); }
        });
    });

    closeBtn.onclick = () => {
        modal.classList.add('hidden');
        document.body.style.overflow = 'auto';
        checkboxes.forEach(b => b.checked = false);
    };

    // Toggle Read More Panel
    readMoreTriggers.forEach(btn => {
        btn.onclick = function() {
            const panel = this.closest('.casino-card-wrapper').querySelector('.extra-panel');
            panel.classList.toggle('hidden');
            this.innerHTML = panel.classList.contains('hidden') ? 'Read More &darr;' : 'Show Less &uarr;';
        };
    });
});