'use strict';

document.addEventListener("DOMContentLoaded", function() {
    
    // --- Helper: Escape HTML to prevent XSS (ThemeForest Requirement) ---
    function escapeHTML(str) {
        if (!str) return '';
        return str.toString().replace(/[&<>'"]/g, function(tag) {
            const charsToReplace = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                "'": '&#39;',
                '"': '&quot;'
            };
            return charsToReplace[tag] || tag;
        });
    }

    // --- 1. ACCORDION LOGIC (Details Collapse/Expand) ---
    const readMoreBtns = document.querySelectorAll('.sp-read-more-toggle');
    
    if (readMoreBtns.length > 0) {
        readMoreBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const parentRow = this.closest('.sp-table2-row');
                if (!parentRow) return; // Safety check
                
                const panel = parentRow.querySelector('.sp-table2-expanded-panel');
                if (!panel) return; // Safety check
                
                this.classList.toggle('active');
                
                if (panel.style.display === 'block') {
                    panel.style.display = 'none';
                } else {
                    panel.style.display = 'block';
                }
            });
        });
    }

    // --- 2. COMPARE LOGIC (Checkbox tracking and Modal rendering) ---
    const checkboxes = document.querySelectorAll('.sp-compare-checkbox');
    const compareBar = document.getElementById('sp-compare-bar');
    const compareCount = document.getElementById('sp-compare-count');
    const clearBtn = document.getElementById('sp-clear-compare');
    const compareBtn = document.getElementById('sp-compare-btn');
    
    const modal = document.getElementById('sp-compare-modal');
    const modalContainer = document.getElementById('sp-modal-container');
    const modalContent = document.getElementById('sp-modal-content');
    const closeModalBtn = document.getElementById('sp-close-modal-btn');
    const closeModalBg = document.getElementById('sp-close-modal-bg');

    let selectedCasinos = []; // Array to hold the data objects

    // Function to update the floating bar UI safely
    function updateCompareUI() {
        if (compareCount) {
            compareCount.textContent = selectedCasinos.length;
        }

        if (compareBar) {
            if (selectedCasinos.length > 0) {
                compareBar.classList.remove('hidden');
            } else {
                compareBar.classList.add('hidden');
            }
        }

        if (compareBtn) {
            if (selectedCasinos.length >= 2) {
                compareBtn.removeAttribute('disabled');
            } else {
                compareBtn.setAttribute('disabled', 'disabled');
            }
        }
    }

    // Listen to checkbox changes safely
    if (checkboxes.length > 0) {
        checkboxes.forEach(box => {
            box.addEventListener('change', function() {
                if (this.checked) {
                    if (selectedCasinos.length >= 4) {
                        this.checked = false;
                        alert("You can only compare a maximum of 4 casinos.");
                        return;
                    }
                    
                    // Add to array by reading and ESCAPING the HTML data attributes
                    selectedCasinos.push({
                        name: escapeHTML(this.dataset.name),
                        logo: escapeHTML(this.dataset.logo),
                        bonus: escapeHTML(this.dataset.bonus),
                        payout: escapeHTML(this.dataset.payout),
                        games: escapeHTML(this.dataset.games),
                        license: escapeHTML(this.dataset.license)
                    });
                } else {
                    // Remove from array if unchecked
                    const safeName = escapeHTML(this.dataset.name);
                    selectedCasinos = selectedCasinos.filter(casino => casino.name !== safeName);
                }
                updateCompareUI();
            });
        });
    }

    // Clear Button Logic safely
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            checkboxes.forEach(box => box.checked = false);
            selectedCasinos = [];
            updateCompareUI();
        });
    }

    // --- 3. MODAL LOGIC (Opening and building the grid) ---
    if (compareBtn && modalContent && modal && modalContainer) {
        compareBtn.addEventListener('click', function() {
            
            let html = `<div class="sp-modal-compare-grid" style="grid-template-columns: repeat(${selectedCasinos.length}, 1fr);">`;
            
            selectedCasinos.forEach(casino => {
                // The casino data is already escaped when pushed to the array
                html += `
                    <div class="sp-modal-col">
                        <div class="sp-modal-logo"><img src="${casino.logo}" alt="${casino.name}"></div>
                        <div class="sp-modal-name">${casino.name}</div>
                        
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Welcome Bonus</span>
                            <span class="sp-modal-stat-value text-emerald-600">${casino.bonus}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Payout Rate</span>
                            <span class="sp-modal-stat-value">${casino.payout}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Total Games</span>
                            <span class="sp-modal-stat-value">${casino.games}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">License</span>
                            <span class="sp-modal-stat-value">${casino.license}</span>
                        </div>
                        
                        <a href="#" class="sp-modal-play-btn">Play Now</a>
                    </div>
                `;
            });
            html += `</div>`;
            
            modalContent.innerHTML = html;
            modal.style.opacity = '1';
            modal.style.pointerEvents = 'auto';
            modalContainer.style.transform = 'scale(1)';
            document.body.style.overflow = 'hidden'; 
        });
    }

    // Close Modal Logic safely
    function closeModal() {
        if (modal && modalContainer) {
            modal.style.opacity = '0';
            modal.style.pointerEvents = 'none';
            modalContainer.style.transform = 'scale(0.95)';
            document.body.style.overflow = ''; 
        }
    }

    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (closeModalBg) closeModalBg.addEventListener('click', closeModal);
});