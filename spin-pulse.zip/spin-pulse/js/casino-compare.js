document.addEventListener("DOMContentLoaded", function() {
    
    // --- 1. ACCORDION LOGIC (Details Collapse/Expand) ---
    const readMoreBtns = document.querySelectorAll('.sp-read-more-toggle');
    
    readMoreBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            // Find the panel specifically inside this button's row
            const parentRow = this.closest('.sp-table2-row');
            const panel = parentRow.querySelector('.sp-table2-expanded-panel');
            
            // Toggle the active class on the button (flips the arrow)
            this.classList.toggle('active');
            
            // Toggle the display of the panel
            if (panel.style.display === 'block') {
                panel.style.display = 'none';
            } else {
                panel.style.display = 'block';
            }
        });
    });


    // --- 2. COMPARE LOGIC (Checkbox tracking and Modal rendering) ---
    const checkboxes = document.querySelectorAll('.sp-compare-checkbox');
    const compareBar = document.getElementById('sp-compare-bar');
    const compareCount = document.getElementById('sp-compare-count');
    const clearBtn = document.getElementById('sp-clear-compare');
    const compareBtn = document.getElementById('sp-compare-btn');
    
    const modal = document.getElementById('sp-compare-modal');
    const modalContainer = document.getElementById('sp-modal-container');
    const modalContent = document.getElementById('sp-modal-content');
    const closeModalBtn = document.getElementById('sp-close-modal-btn');
    const closeModalBg = document.getElementById('sp-close-modal-bg');

    let selectedCasinos = []; // Array to hold the data objects

    // Function to update the floating bar UI
    function updateCompareUI() {
        compareCount.textContent = selectedCasinos.length;

        // Show bar if 1 or more selected
        if (selectedCasinos.length > 0) {
            compareBar.classList.remove('hidden');
        } else {
            compareBar.classList.add('hidden');
        }

        // Enable Compare Button if 2 or more selected
        if (selectedCasinos.length >= 2) {
            compareBtn.removeAttribute('disabled');
        } else {
            compareBtn.setAttribute('disabled', 'disabled');
        }
    }

    // Listen to checkbox changes
    checkboxes.forEach(box => {
        box.addEventListener('change', function() {
            if (this.checked) {
                // If checking makes it more than 4, stop them.
                if (selectedCasinos.length >= 4) {
                    this.checked = false;
                    alert("You can only compare a maximum of 4 casinos.");
                    return;
                }
                // Add to array by reading the HTML data attributes
                selectedCasinos.push({
                    name: this.dataset.name,
                    logo: this.dataset.logo,
                    bonus: this.dataset.bonus,
                    payout: this.dataset.payout,
                    games: this.dataset.games,
                    license: this.dataset.license
                });
            } else {
                // Remove from array if unchecked
                selectedCasinos = selectedCasinos.filter(casino => casino.name !== this.dataset.name);
            }
            updateCompareUI();
        });
    });

    // Clear Button Logic
    if (clearBtn) {
        clearBtn.addEventListener('click', function() {
            checkboxes.forEach(box => box.checked = false);
            selectedCasinos = [];
            updateCompareUI();
        });
    }

    // --- 3. MODAL LOGIC (Opening and building the grid) ---
    if (compareBtn) {
        compareBtn.addEventListener('click', function() {
            // Build the HTML for the comparison grid dynamically
            let html = `<div class="sp-modal-compare-grid" style="grid-template-columns: repeat(${selectedCasinos.length}, 1fr);">`;
            
            selectedCasinos.forEach(casino => {
                html += `
                    <div class="sp-modal-col">
                        <div class="sp-modal-logo"><img src="${casino.logo}" alt="${casino.name}"></div>
                        <div class="sp-modal-name">${casino.name}</div>
                        
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Welcome Bonus</span>
                            <span class="sp-modal-stat-value text-emerald-600">${casino.bonus}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Payout Rate</span>
                            <span class="sp-modal-stat-value">${casino.payout}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">Total Games</span>
                            <span class="sp-modal-stat-value">${casino.games}</span>
                        </div>
                        <div class="sp-modal-stat-row">
                            <span class="sp-modal-stat-label">License</span>
                            <span class="sp-modal-stat-value">${casino.license}</span>
                        </div>
                        
                        <a href="#" class="sp-modal-play-btn">Play Now</a>
                    </div>
                `;
            });
            html += `</div>`;
            
            // Inject into modal and show it
            modalContent.innerHTML = html;
            modal.style.opacity = '1';
            modal.style.pointerEvents = 'auto';
            modalContainer.style.transform = 'scale(1)';
            document.body.style.overflow = 'hidden'; // Prevent background scrolling
        });
    }

    // Close Modal Logic
    function closeModal() {
        modal.style.opacity = '0';
        modal.style.pointerEvents = 'none';
        modalContainer.style.transform = 'scale(0.95)';
        document.body.style.overflow = ''; // Restore scrolling
    }

    if (closeModalBtn) closeModalBtn.addEventListener('click', closeModal);
    if (closeModalBg) closeModalBg.addEventListener('click', closeModal);
});
