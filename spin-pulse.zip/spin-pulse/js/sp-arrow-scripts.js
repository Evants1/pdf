'use strict';

document.addEventListener('DOMContentLoaded', function() {
    const carousels = document.querySelectorAll('.sp-games2-carousel-wrapper');

    // Global safety check: only run the loop if carousels exist on the page
    if (carousels.length === 0) return;

    carousels.forEach(wrapper => {
        const container = wrapper.querySelector('.sp-games2-scrollable');
        const prevBtn = wrapper.querySelector('.sp-games2-prev');
        const nextBtn = wrapper.querySelector('.sp-games2-next');

        // Excellent safety check!
        if(!container || !prevBtn || !nextBtn) return;

        // Scroll amount is roughly one card width + gap
        const scrollAmount = 240; 

        // Update arrow visibility based on scroll position
        const updateArrows = () => {
            if (container.scrollLeft <= 0) {
                prevBtn.classList.add('hidden');
            } else {
                prevBtn.classList.remove('hidden');
            }

            // Math.ceil deals with fractional pixel scrolling issues on some screens
            if (Math.ceil(container.scrollLeft + container.clientWidth) >= container.scrollWidth) {
                nextBtn.classList.add('hidden');
            } else {
                nextBtn.classList.remove('hidden');
            }
        };

        nextBtn.addEventListener('click', () => {
            container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });

        prevBtn.addEventListener('click', () => {
            container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });

        // ThemeForest Performance Fix: Use passive event listeners for scroll and resize
        container.addEventListener('scroll', updateArrows, { passive: true });
        window.addEventListener('resize', updateArrows, { passive: true });
        
        // Initial check
        updateArrows();
    });
});