document.addEventListener('DOMContentLoaded', function() {
    const carousels = document.querySelectorAll('.sp-games2-carousel-wrapper');

    carousels.forEach(wrapper => {
        const container = wrapper.querySelector('.sp-games2-scrollable');
        const prevBtn = wrapper.querySelector('.sp-games2-prev');
        const nextBtn = wrapper.querySelector('.sp-games2-next');

        if(!container || !prevBtn || !nextBtn) return;

        // Scroll amount is roughly one card width + gap
        const scrollAmount = 240; 

        // Update arrow visibility based on scroll position
        const updateArrows = () => {
            if (container.scrollLeft <= 0) {
                prevBtn.classList.add('hidden');
            } else {
                prevBtn.classList.remove('hidden');
            }

            // Math.ceil deals with fractional pixel scrolling issues on some screens
            if (Math.ceil(container.scrollLeft + container.clientWidth) >= container.scrollWidth) {
                nextBtn.classList.add('hidden');
            } else {
                nextBtn.classList.remove('hidden');
            }
        };

        nextBtn.addEventListener('click', () => {
            container.scrollBy({ left: scrollAmount, behavior: 'smooth' });
        });

        prevBtn.addEventListener('click', () => {
            container.scrollBy({ left: -scrollAmount, behavior: 'smooth' });
        });

        container.addEventListener('scroll', updateArrows);
        
        // Initial check
        updateArrows();
        // Recalculate on window resize
        window.addEventListener('resize', updateArrows);
    });
});