<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Spin_Pulse
 */

// THEMEFOREST FIX: Match the ID registered in functions.php
if ( ! is_active_sidebar( 'sidebar-right' ) ) {
	return;
}
?>

<aside id="secondary" class="widget-area sp-right-sidebar-sidebar">
	<?php dynamic_sidebar( 'sidebar-right' ); ?>
</aside>