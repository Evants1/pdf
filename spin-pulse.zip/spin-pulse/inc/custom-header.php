<?php
/**
 * Sample implementation of the Custom Header feature
 *
 * You can add an optional custom header image to header.php like so ...
 *
 * <?php the_header_image_tag(); ?>
 *
 * @link https://developer.wordpress.org/themes/functionality/custom-headers/
 *
 * @package Spin_Pulse
 */

/**
 * Set up the WordPress core custom header feature.
 *
 * @uses spin_pulse_header_inline_style()
 */
function spin_pulse_custom_header_setup() {
	add_theme_support(
		'custom-header',
		apply_filters(
			'spin_pulse_custom_header_args',
			array(
				'default-image'      => '',
				'default-text-color' => '000000',
				'width'              => 1000,
				'height'             => 250,
				'flex-height'        => true,
                // THEMEFOREST FIX: Removed 'wp-head-callback' in favor of modern inline styles below
			)
		)
	);
}
add_action( 'after_setup_theme', 'spin_pulse_custom_header_setup' );

if ( ! function_exists( 'spin_pulse_header_inline_style' ) ) :
	/**
	 * Styles the header image and text displayed on the blog.
     * THEMEFOREST FIX: Uses wp_add_inline_style instead of echoing <style> tags.
	 */
	function spin_pulse_header_inline_style() {
		$header_text_color = get_header_textcolor();

		/*
		 * If no custom options for text are set, let's bail.
		 */
		if ( get_theme_support( 'custom-header', 'default-text-color' ) === $header_text_color ) {
			return;
		}

		$custom_css = '';

		// Has the text been hidden?
		if ( ! display_header_text() ) {
			$custom_css .= '
			.site-title,
			.site-description {
				position: absolute;
				clip: rect(1px, 1px, 1px, 1px);
			}';
		} else {
            // If the user has set a custom color for the text use that.
            // THEMEFOREST FIX: Added sanitize_hex_color_no_hash() for maximum security
			$custom_css .= '
			.site-title a,
			.site-description {
				color: #' . sanitize_hex_color_no_hash( $header_text_color ) . ';
			}';
		}

        // Attach this dynamic CSS to your main theme stylesheet
        wp_add_inline_style( 'spin-pulse-style', $custom_css );
	}
endif;
add_action( 'wp_enqueue_scripts', 'spin_pulse_header_inline_style' );