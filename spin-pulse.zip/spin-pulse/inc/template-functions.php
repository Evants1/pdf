<?php
/**
 * Functions which enhance the theme by hooking into WordPress
 *
 * @package Spin_Pulse
 */

/**
 * Adds custom classes to the array of body classes.
 *
 * @param array $classes Classes for the body element.
 * @return array
 */
function spin_pulse_body_classes( $classes ) {
	// Adds a class of hfeed to non-singular pages.
	if ( ! is_singular() ) {
		$classes[] = 'hfeed';
	}

	// THEMEFOREST FIX: Updated to check your actual registered sidebars instead of the default 'sidebar-1'
	if ( ! is_active_sidebar( 'sidebar-right' ) && ! is_active_sidebar( 'sidebar-left' ) ) {
		$classes[] = 'no-sidebar';
	}

	return $classes;
}
add_filter( 'body_class', 'spin_pulse_body_classes' );

/**
 * Add a pingback url auto-discovery header for single posts, pages, or attachments.
 */
function spin_pulse_pingback_header() {
	if ( is_singular() && pings_open() ) {
        // THEMEFOREST FIX: Already perfectly escaped. Excellent!
		printf( '<link rel="pingback" href="%s">', esc_url( get_bloginfo( 'pingback_url' ) ) );
	}
}
add_action( 'wp_head', 'spin_pulse_pingback_header' );