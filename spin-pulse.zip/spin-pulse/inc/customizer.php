<?php
/**
 * Spin Pulse Theme Customizer
 *
 * @package Spin_Pulse
 */

function spin_pulse_customize_register( $wp_customize ) {

    // Core settings
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial(
            'blogname',
            array(
                'selector'        => '.site-title a',
                'render_callback' => 'spin_pulse_customize_partial_blogname',
            )
        );
        $wp_customize->selective_refresh->add_partial(
            'blogdescription',
            array(
                'selector'        => '.site-description',
                'render_callback' => 'spin_pulse_customize_partial_blogdescription',
            )
        );
    }

    // === Custom Header Section ===
    $wp_customize->add_section( 'spin_pulse_header_section', array(
        'title'       => esc_html__( 'Header Settings', 'spin-pulse' ),
        'description' => esc_html__( 'Choose header style and customize colors.', 'spin-pulse' ),
        'priority'    => 120,
    ) );

    // Header Style Selection
    $wp_customize->add_setting( 'spin_pulse_header_style', array(
        'default'           => 'style1',
        'sanitize_callback' => 'sanitize_key',
    ) );

    $wp_customize->add_control( 'spin_pulse_header_style', array(
        'label'    => esc_html__( 'Header Style', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
        'type'     => 'select',
        'choices'  => array(
            'style1' => esc_html__( 'Style 1: Logo Left', 'spin-pulse' ),
            'style2' => esc_html__( 'Style 2: Centered Logo', 'spin-pulse' ),
        ),
    ) );

    // Top Bar Toggle
    $wp_customize->add_setting( 'spin_pulse_topbar_enable', array(
        'default'           => true,
        'sanitize_callback' => 'spin_pulse_sanitize_checkbox',
    ) );

    $wp_customize->add_control( 'spin_pulse_topbar_enable', array(
        'label'    => esc_html__( 'Enable Top Bar (Style 2)', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
        'type'     => 'checkbox',
    ) );

    // --- NEW: Navigation & Header Colors ---

    // Header Background
    $wp_customize->add_setting( 'spin_pulse_header_bg_color', array(
        'default'           => '#0B0F1A',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_header_bg_color', array(
        'label'    => esc_html__( 'Header Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Main Menu Link Color
    $wp_customize->add_setting( 'spin_pulse_menu_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_menu_link_color', array(
        'label'    => esc_html__( 'Main Menu Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Background Color
    $wp_customize->add_setting( 'spin_pulse_submenu_bg_color', array(
        'default'           => '#111827',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_bg_color', array(
        'label'    => esc_html__( 'Submenu Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Link Color
    $wp_customize->add_setting( 'spin_pulse_submenu_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_link_color', array(
        'label'    => esc_html__( 'Submenu Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Hover Accent Color
    $wp_customize->add_setting( 'spin_pulse_submenu_hover_color', array(
        'default'           => '#a855f7',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_hover_color', array(
        'label'    => esc_html__( 'Submenu Hover/Accent Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );


    // === Social Media Section ===
    $wp_customize->add_section( 'spin_pulse_social_section', array(
        'title'    => esc_html__( 'Social Media Settings', 'spin-pulse' ),
        'priority' => 150,
    ) );

    $social_platforms = array(
        'facebook'  => esc_html__( 'Facebook URL', 'spin-pulse' ),
        'twitter'   => esc_html__( 'Twitter/X URL', 'spin-pulse' ),
        'instagram' => esc_html__( 'Instagram URL', 'spin-pulse' ),
        'youtube'   => esc_html__( 'YouTube URL', 'spin-pulse' ),
        'linkedin'  => esc_html__( 'LinkedIn URL', 'spin-pulse' ),
        'pinterest' => esc_html__( 'Pinterest URL', 'spin-pulse' ),
        'tiktok'    => esc_html__( 'TikTok URL', 'spin-pulse' ),
    );

    $priority = 10;
    foreach ( $social_platforms as $key => $label ) {
        $wp_customize->add_setting( "spin_pulse_social_{$key}", array(
            'default'           => '',
            'sanitize_callback' => 'esc_url_raw',
            'transport'         => 'postMessage',
        ) );

        $wp_customize->add_control( "spin_pulse_social_{$key}", array(
            'label'    => $label,
            'section'  => 'spin_pulse_social_section',
            'type'     => 'url',
            'priority' => $priority++,
        ) );
    }

    // === Custom Footer Section ===
    $wp_customize->add_section( 'spin_pulse_footer_section', array(
        'title'    => esc_html__( 'Footer Settings', 'spin-pulse' ),
        'priority' => 155,
    ) );

    // Footer Background Color
    $wp_customize->add_setting( 'spin_pulse_footer_bg_color', array(
        'default'           => '#0B0F1A',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_bg_color', array(
        'label'    => esc_html__( 'Footer Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Text Color
    $wp_customize->add_setting( 'spin_pulse_footer_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_text_color', array(
        'label'    => esc_html__( 'Footer Text Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Link Color
    $wp_customize->add_setting( 'spin_pulse_footer_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_link_color', array(
        'label'    => esc_html__( 'Footer Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Link Hover Color
    $wp_customize->add_setting( 'spin_pulse_footer_hover_color', array(
        'default'           => '#fbbf24',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_hover_color', array(
        'label'    => esc_html__( 'Footer Link Hover Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Copyright Text
    $wp_customize->add_setting( 'spin_pulse_footer_copyright', array(
        'default'           => esc_html__( '© Copyright {year} ' . get_bloginfo( 'name' ) . ' | All Rights Reserved.', 'spin-pulse' ),
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'spin_pulse_footer_copyright', array(
        'label'   => esc_html__( 'Footer Copyright Text', 'spin-pulse' ),
        'section' => 'spin_pulse_footer_section',
        'type'    => 'textarea',
    ) );

    // Powered By Toggle
    $wp_customize->add_setting( 'spin_pulse_show_powered_by', array(
        'default'           => true,
        'sanitize_callback' => 'spin_pulse_sanitize_checkbox',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'spin_pulse_show_powered_by', array(
        'label'   => esc_html__( 'Display "Powered by"', 'spin-pulse' ),
        'section' => 'spin_pulse_footer_section',
        'type'    => 'checkbox',
    ) );

}
add_action( 'customize_register', 'spin_pulse_customize_register' );

/**
 * Render Callbacks and Sanitization Functions
 */
function spin_pulse_customize_partial_blogname() {
    bloginfo( 'name' );
}

function spin_pulse_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

function spin_pulse_sanitize_checkbox( $input ) {
    return ( isset( $input ) && true === $input ) ? true : false;
}

function spin_pulse_get_footer_copyright() {
    $copyright = get_theme_mod( 'spin_pulse_footer_copyright', '© Copyright {year} ' . get_bloginfo( 'name' ) . ' | All Rights Reserved.' );
    $copyright = str_replace( '{year}', date( 'Y' ), $copyright );
    if ( get_theme_mod( 'spin_pulse_show_powered_by', true ) ) {
        $copyright .= ' | Powered by <a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
    }
    return wp_kses_post( $copyright );
}

function spin_pulse_customize_preview_js() {
    wp_enqueue_script( 'spin-pulse-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), _S_VERSION, true );
}
add_action( 'customize_preview_init', 'spin_pulse_customize_preview_js' );