<?php
/**
 * Spin Pulse Theme Customizer
 *
 * @package Spin_Pulse
 */

function spin_pulse_customize_register( $wp_customize ) {

    // Core settings
    $wp_customize->get_setting( 'blogname' )->transport         = 'postMessage';
    $wp_customize->get_setting( 'blogdescription' )->transport  = 'postMessage';
    $wp_customize->get_setting( 'header_textcolor' )->transport = 'postMessage';

    if ( isset( $wp_customize->selective_refresh ) ) {
        $wp_customize->selective_refresh->add_partial(
            'blogname',
            array(
                'selector'        => '.site-title a',
                'render_callback' => 'spin_pulse_customize_partial_blogname',
            )
        );
        $wp_customize->selective_refresh->add_partial(
            'blogdescription',
            array(
                'selector'        => '.site-description',
                'render_callback' => 'spin_pulse_customize_partial_blogdescription',
            )
        );
    }

    // === Custom Header Section ===
    $wp_customize->add_section( 'spin_pulse_header_section', array(
        'title'       => esc_html__( 'Header Settings', 'spin-pulse' ),
        'description' => esc_html__( 'Customize your header colors.', 'spin-pulse' ),
        'priority'    => 120,
    ) );

    // --- Navigation & Header Colors ---

    // Header Background
    $wp_customize->add_setting( 'spin_pulse_header_bg_color', array(
        'default'           => '#0B0F1A',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_header_bg_color', array(
        'label'    => esc_html__( 'Header Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Main Menu Link Color
    $wp_customize->add_setting( 'spin_pulse_menu_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_menu_link_color', array(
        'label'    => esc_html__( 'Main Menu Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Background Color
    $wp_customize->add_setting( 'spin_pulse_submenu_bg_color', array(
        'default'           => '#111827',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_bg_color', array(
        'label'    => esc_html__( 'Submenu Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Link Color
    $wp_customize->add_setting( 'spin_pulse_submenu_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_link_color', array(
        'label'    => esc_html__( 'Submenu Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );

    // Submenu Hover Accent Color
    $wp_customize->add_setting( 'spin_pulse_submenu_hover_color', array(
        'default'           => '#a855f7',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_submenu_hover_color', array(
        'label'    => esc_html__( 'Submenu Hover/Accent Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_header_section',
    ) ) );


    // === Custom Footer Section ===
    $wp_customize->add_section( 'spin_pulse_footer_section', array(
        'title'    => esc_html__( 'Footer Settings', 'spin-pulse' ),
        'priority' => 155,
    ) );

    // Footer Background Color
    $wp_customize->add_setting( 'spin_pulse_footer_bg_color', array(
        'default'           => '#0B0F1A',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_bg_color', array(
        'label'    => esc_html__( 'Footer Background Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Text Color
    $wp_customize->add_setting( 'spin_pulse_footer_text_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_text_color', array(
        'label'    => esc_html__( 'Footer Text Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Link Color
    $wp_customize->add_setting( 'spin_pulse_footer_link_color', array(
        'default'           => '#ffffff',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_link_color', array(
        'label'    => esc_html__( 'Footer Link Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Footer Link Hover Color
    $wp_customize->add_setting( 'spin_pulse_footer_hover_color', array(
        'default'           => '#fbbf24',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, 'spin_pulse_footer_hover_color', array(
        'label'    => esc_html__( 'Footer Link Hover Color', 'spin-pulse' ),
        'section'  => 'spin_pulse_footer_section',
    ) ) );

    // Copyright Text
    // THEMEFOREST FIX: Removed variables from translation string and used sprintf
    $default_copyright = sprintf( esc_html__( '&copy; Copyright {year} %s | All Rights Reserved.', 'spin-pulse' ), get_bloginfo( 'name' ) );
    $wp_customize->add_setting( 'spin_pulse_footer_copyright', array(
        'default'           => $default_copyright,
        'sanitize_callback' => 'wp_kses_post',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'spin_pulse_footer_copyright', array(
        'label'   => esc_html__( 'Footer Copyright Text', 'spin-pulse' ),
        'section' => 'spin_pulse_footer_section',
        'type'    => 'textarea',
    ) );

    // Powered By Toggle
    $wp_customize->add_setting( 'spin_pulse_show_powered_by', array(
        'default'           => true,
        'sanitize_callback' => 'spin_pulse_sanitize_checkbox',
        'transport'         => 'postMessage',
    ) );

    $wp_customize->add_control( 'spin_pulse_show_powered_by', array(
        'label'   => esc_html__( 'Display "Powered by"', 'spin-pulse' ),
        'section' => 'spin_pulse_footer_section',
        'type'    => 'checkbox',
    ) );

}
add_action( 'customize_register', 'spin_pulse_customize_register' );

/**
 * Render Callbacks and Sanitization Functions
 */
function spin_pulse_customize_partial_blogname() {
    bloginfo( 'name' );
}

function spin_pulse_customize_partial_blogdescription() {
    bloginfo( 'description' );
}

// THEMEFOREST FIX: Adjusted to use loose equality for Customizer checkbox saving
function spin_pulse_sanitize_checkbox( $input ) {
    return ( isset( $input ) && true == $input ) ? true : false;
}

function spin_pulse_get_footer_copyright() {
    // THEMEFOREST FIX: Re-structured this output to be fully translation compliant
    $default_copyright = sprintf( esc_html__( '&copy; Copyright {year} %s | All Rights Reserved.', 'spin-pulse' ), get_bloginfo( 'name' ) );
    $copyright = get_theme_mod( 'spin_pulse_footer_copyright', $default_copyright );
    
    // Replace {year} dynamic token
    $copyright = str_replace( '{year}', date( 'Y' ), $copyright );
    
    if ( get_theme_mod( 'spin_pulse_show_powered_by', true ) ) {
        // Build the link safely, then inject it via sprintf
        $powered_link = '<a href="' . esc_url( home_url( '/' ) ) . '">' . esc_html( get_bloginfo( 'name' ) ) . '</a>';
        $copyright .= ' | ' . sprintf( esc_html__( 'Powered by %s', 'spin-pulse' ), $powered_link );
    }
    
    return wp_kses_post( $copyright );
}

function spin_pulse_customize_preview_js() {
    wp_enqueue_script( 'spin-pulse-customizer', get_template_directory_uri() . '/js/customizer.js', array( 'customize-preview' ), _S_VERSION, true );
}
add_action( 'customize_preview_init', 'spin_pulse_customize_preview_js' );