<?php
/**
 * The template for displaying all pages
 */
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-white">
	<?php if (is_front_page()):
		// 1. Fetch Hero Settings
		$options = get_option('spin_pulse_hero_settings', []);

		// 2. Logic & Fallbacks
		$heading = !empty($options['hero_heading']) ? $options['hero_heading'] : 'Find the best';
		$description = !empty($options['hero_description']) ? $options['hero_description'] : "Since 1995...";
		$bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
		$bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
		$h_color = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
		$desc_color = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

		// 3. Author Data
		$author_id = get_post_field('post_author', get_the_ID());
		$author_name = get_the_author_meta('display_name', $author_id);
		$avatar = get_avatar_url($author_id, ['size' => 96]);
		$has_avatar = !strpos($avatar, 'mysteryman') && !strpos($avatar, 'blank') && !strpos($avatar, 'gravatar');
		?>

		<section class="w-full py-16 md:py-24 lg:py-32"
			style="background: linear-gradient(135deg, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_end); ?>);">
			<div class="w-full px-6 lg:px-12">
				<div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

					<div class="flex flex-col">

						<div class="flex items-center space-x-4 mb-8 group cursor-default mt-8">
							<div class="relative">
								<?php if ($has_avatar): ?>
									<img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($author_name); ?>"
										class="w-14 h-14 rounded-full border-2 border-white/20 object-cover shadow-lg group-hover:border-purple-500 transition-colors duration-300">
								<?php else: ?>
									<div
										class="w-14 h-14 rounded-full border-2 border-white/20 bg-white/10 flex items-center justify-center shadow-lg group-hover:border-purple-500 transition-colors duration-300">
										<svg class="w-7 h-7 text-white/70" fill="currentColor" viewBox="0 0 24 24">
											<path
												d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" />
										</svg>
									</div>
								<?php endif; ?>
								<div
									class="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1e293b] rounded-full">
									<span
										class="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
								</div>
							</div>

							<div class="flex flex-col space-y-1">
								<div class="flex items-center gap-2">
									<span
										class="text-white font-bold text-base tracking-tight"><?php echo esc_html($author_name); ?></span>
									<span
										class="bg-white/10 text-white/60 text-[10px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider border border-white/5">Verified</span>
								</div>
								<div class="flex items-center text-white/50 text-xs font-medium space-x-2">
									<span>Updated: <?php echo get_the_modified_date('M j, Y'); ?></span>
								</div>
							</div>
						</div>

						<h1 class="text-4xl md:text-6xl lg:text-7xl font-black leading-[1.1] tracking-[-0.04em]"
							style="color: <?php echo esc_attr($h_color); ?>;">
							<?php echo esc_html($heading); ?>
						</h1>

						<p class="mt-6 text-lg md:text-xl leading-relaxed max-w-3xl font-medium opacity-90 tracking-tight"
							style="color: <?php echo esc_attr($desc_color); ?>;">
							<?php echo wp_kses_post(nl2br($description)); ?>
						</p>


					</div>

					<div class="flex flex-col gap-6 w-full mt-12 lg:mt-0">
						<?php for ($i = 1; $i <= 4; $i++):
							$c_title = !empty($options["card{$i}_title"]) ? $options["card{$i}_title"] : "";
							$c_link = !empty($options["card{$i}_link"]) ? $options["card{$i}_link"] : "#";
							$c_badge = !empty($options["card{$i}_badge"]) ? $options["card{$i}_badge"] : "";
							$c_badge_bg = !empty($options["card{$i}_badge_bg"]) ? $options["card{$i}_badge_bg"] : '#7c3aed';

							// Only show the row if the user has actually entered a Title in the admin
							if (!empty($c_title)): ?>

								<div
									class="group bg-white rounded-3xl border border-slate-200 shadow-sm p-2 hover:shadow-xl transition-all duration-300">
									<div class="flex flex-col md:flex-row items-center p-4">

										<div class="flex items-center gap-6 md:w-1/4 w-full mb-4 md:mb-0">
											<span class="text-2xl font-black text-indigo-600 ml-4"><?php echo $i; ?></span>
											<div
												class="w-32 h-20 bg-slate-50 rounded-2xl flex items-center justify-center border border-slate-100 font-black italic text-slate-300 tracking-tighter">
												CASINO
											</div>
										</div>

										<div class="flex-1 text-center md:text-left py-2 md:py-0 md:px-6">
											<?php if (!empty($c_badge)): ?>
												<span class="text-[10px] font-black uppercase tracking-widest px-2 py-0.5 rounded"
													style="background-color: <?php echo esc_attr($c_badge_bg); ?>20; color: <?php echo esc_attr($c_badge_bg); ?>;">
													<?php echo esc_html($c_badge); ?>
												</span>
											<?php endif; ?>
											<h3 class="text-2xl font-black text-slate-900 mt-1">
												<?php echo esc_html($c_title); ?>
											</h3>
										</div>

										<div class="flex flex-col gap-2 md:w-1/4 w-full">
											<a href="<?php echo esc_url($c_link); ?>"
												class="bg-emerald-500 hover:bg-emerald-600 text-white text-center py-4 rounded-2xl font-black shadow-lg shadow-emerald-100 transition-all uppercase tracking-wider text-sm">
												Play Now
											</a>
										</div>

									</div>
								</div>

							<?php endif;
						endfor; ?>
					</div>

				</div>
			</div>
		</section>

		<section class="py-16 bg-white w-full">
			<div class="w-full px-6 lg:px-12"> <?php while (have_posts()):
				the_post(); ?>
					<article class="prose prose-slate prose-lg max-w-none w-full">
						<?php the_content(); ?>
					</article>
				<?php endwhile; ?>
			</div>
		</section>

	<?php else: ?>

		<section class="py-16 md:py-24 bg-white w-full">
			<div class="w-full px-6 lg:px-12"> <?php while (have_posts()):
				the_post(); ?>
					<header class="mb-12">
						<h1 class="text-4xl md:text-6xl font-bold text-slate-900 tracking-tight">
							<?php the_title(); ?>
						</h1>
					</header>

					<article class="prose prose-slate prose-lg max-w-none w-full">
						<?php the_content(); ?>
					</article>
				<?php endwhile; ?>
			</div>
		</section>

	<?php endif; ?>
</main>

<?php get_footer(); ?>