<?php
/**
 * Spin Pulse functions and definitions
 *
 * @package Spin_Pulse
 */

if (!defined('_S_VERSION')) {
    define('_S_VERSION', filemtime(get_template_directory() . '/style.css') ?: '1.0.0');
}

/**
 * 1. THEME SETUP
 */
function spin_pulse_setup()
{
    load_theme_textdomain('spin-pulse', get_template_directory() . '/languages');
    add_theme_support('automatic-feed-links');
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    register_nav_menus(array(
        'menu-1' => esc_html__('Primary Menu', 'spin-pulse'),
        'footer-menu' => esc_html__('Footer Menu', 'spin-pulse'),
    ));
    add_theme_support('html5', array('search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script', 'navigation-widgets'));
    add_theme_support('custom-logo', array('height' => 250, 'width' => 250, 'flex-width' => true, 'flex-height' => true));
    add_theme_support('responsive-embeds');
}
add_action('after_setup_theme', 'spin_pulse_setup');

/**
 * 2. ASSETS ENQUEUE
 */
function spin_pulse_enqueue_assets()
{
    wp_enqueue_style('spin-pulse-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap', array(), null);
    wp_enqueue_style('spin-pulse-style', get_stylesheet_uri(), array(), _S_VERSION);

    if (file_exists(get_template_directory() . '/js/navigation.js')) {
        wp_enqueue_script('spin-pulse-navigation', get_template_directory_uri() . '/js/navigation.js', array(), _S_VERSION, true);
    }
}
add_action('wp_enqueue_scripts', 'spin_pulse_enqueue_assets');

/**
 * 3. CUSTOM WALKER (Badges & Colors)
 */
class Spin_Pulse_Walker_Nav_Menu extends Walker_Nav_Menu
{
    // 1. Dropdown Wrapper (The Ul)
    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
        $indent = str_repeat("\t", $depth);
        // Added: shadow-2xl, border-white/5 for a glass-morphism feel, and refined padding
        $output .= "\n$indent<ul class=\"sub-menu absolute left-0 top-[calc(100%-2px)] hidden group-hover:block w-60 border-t-2 border-purple-500 shadow-2xl py-3 z-50 rounded-b-xl animate-slide-down\" style=\"background-color: {$sub_bg};\">\n";
    }

    // 2. Individual Items
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $classes = empty($item->classes) ? array() : (array) $item->classes;

        // Check if item has children
        $has_children = in_array('menu-item-has-children', $classes);

        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $output .= '<li class="' . esc_attr($class_names) . ' relative group">';

        $title = apply_filters('the_title', $item->title, $item->ID);

        // Badge Logic
        $badges = ['{New}' => 'bg-emerald-500', '{Top}' => 'bg-rose-500', '{Best}' => 'bg-amber-500'];
        foreach ($badges as $tag => $bg_class) {
            if (strpos($title, $tag) !== false) {
                $clean_tag = str_replace(['{', '}'], '', $tag);
                $badge_html = '<span class="absolute -top-1 left-4 px-1.5 py-0.5 rounded text-[9px] font-black uppercase ' . $bg_class . ' text-white shadow-sm z-10">' . $clean_tag . '</span>';
                $title = str_replace($tag, '', $title) . $badge_html;
            }
        }

        // Dropdown Arrow (Only for top-level items with children)
        $arrow = ($depth === 0 && $has_children) ? '<svg class="w-4 h-4 ml-1.5 opacity-60 group-hover:rotate-180 transition-transform duration-300" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path></svg>' : '';

        $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
        $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
        $attributes = !empty($item->url) ? ' href="' . esc_url($item->url) . '"' : '';

        if ($depth > 0) {
            // Sub-menu links: Added hover translate effect
            $link_style = "color: {$sub_text};";
            $link_class = 'block px-6 py-2.5 text-[13px] font-medium hover:bg-white/5 hover:pl-7 transition-all duration-200 sub-menu-link';
        } else {
            // Main-menu links
            $link_style = "color: {$h_text};";
            $link_class = 'flex items-center font-bold px-4 py-5 transition-colors main-menu-link';
        }

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . ' class="' . $link_class . '" style="' . $link_style . '">';
        $item_output .= $args->link_before . $title . $arrow . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * 4. DYNAMIC CUSTOMIZER CSS
 */
function spin_pulse_dynamic_css()
{
    // Keep these for sub-menus and footer
    $h_text = get_theme_mod('spin_pulse_menu_link_color', '#ffffff');
    $sub_bg = get_theme_mod('spin_pulse_submenu_bg_color', '#111827');
    $sub_text = get_theme_mod('spin_pulse_submenu_link_color', '#ffffff');
    $sub_hover = get_theme_mod('spin_pulse_submenu_hover_color', '#a855f7');
    $f_bg = get_theme_mod('spin_pulse_footer_bg_color', '#0B0F1A');
    $f_text = get_theme_mod('spin_pulse_footer_text_color', '#ffffff');

    ?>
    <style type="text/css">
        /* Remove !important from main links to let Tailwind utility classes work */
        .main-menu-link,
        .site-title a {
            color:
                <?php echo esc_attr($h_text); ?>
            ;
        }

        /* Keep !important only for sub-menus and footer where you want strict Customizer control */
        .sub-menu {
            background-color:
                <?php echo esc_attr($sub_bg); ?>
                !important;
        }

        .sub-menu-link {
            color:
                <?php echo esc_attr($sub_text); ?>
                !important;
        }

        .sub-menu-link:hover {
            color:
                <?php echo esc_attr($sub_hover); ?>
                !important;
        }

        #colophon.site-footer {
            background-color:
                <?php echo esc_attr($f_bg); ?>
                !important;
            color:
                <?php echo esc_attr($f_text); ?>
                !important;
        }

        #masthead button svg {
            color:
                <?php echo esc_attr($h_text); ?>
            ;
        }
    </style>
    <?php
}
add_action('wp_head', 'spin_pulse_dynamic_css', 100);

/**
 * 5. TAILWIND ADMIN OPTIONS PAGE
 */
add_action('admin_menu', 'spin_pulse_register_options_menu');
function spin_pulse_register_options_menu()
{
    add_menu_page('Spin Pulse', 'Spin Pulse', 'manage_options', 'spin-pulse-options', 'spin_pulse_hero_page_html', 'dashicons-admin-appearance', 59);
}

function spin_pulse_enqueue_options_scripts($hook)
{
    if ('toplevel_page_spin-pulse-options' !== $hook)
        return;
    wp_enqueue_script('tailwind-cdn', 'https://cdn.tailwindcss.com', array(), null, false);
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');
    wp_add_inline_script('wp-color-picker', 'jQuery(document).ready(function($){ $(".spin-pulse-color-picker").wpColorPicker(); });');
}
add_action('admin_enqueue_scripts', 'spin_pulse_enqueue_options_scripts');

function spin_pulse_hero_page_html()
{
    if (!current_user_can('manage_options'))
        return;
    ?>
    <div class="wrap mt-8 pr-8">
        <div class="bg-white border border-slate-200 rounded-xl shadow-sm p-8 max-w-7xl">
            <header class="mb-10 border-b border-slate-100 pb-6">
                <h1 class="text-3xl font-black text-slate-900 mb-2">Spin Pulse Theme Settings</h1>
                <p class="text-slate-500 text-lg">Manage your modern homepage hero and global styles.</p>
            </header>

            <form action="options.php" method="post" class="space-y-12">
                <?php
                settings_fields('spin_pulse_hero_group');
                global $wp_settings_sections;
                $page = 'hero-settings-page';

                if (isset($wp_settings_sections[$page])) {
                    foreach ((array) $wp_settings_sections[$page] as $section) {
                        $is_card = strpos($section['id'], 'card') !== false;
                        echo '<section class="' . ($is_card ? 'bg-slate-50 p-6 rounded-xl border border-slate-100' : '') . ' mb-8">';
                        if ($section['title']) {
                            echo '<h2 class="text-xl font-bold text-slate-800 mb-6 flex items-center gap-2">
                                  <span class="w-1.5 h-6 bg-indigo-600 rounded-full"></span>' . esc_html($section['title']) . '</h2>';
                        }
                        $grid_class = $is_card ? 'space-y-4' : 'grid grid-cols-1 md:grid-cols-2 gap-8';
                        if ($section['id'] === 'hero_main_section')
                            $grid_class = 'space-y-6 max-w-3xl';

                        echo '<div class="' . ($is_card ? '' : $grid_class) . '">';
                        do_settings_fields($page, $section['id']);
                        echo '</div></section>';
                    }
                }
                submit_button('Save Theme Settings', 'primary', 'submit', true, array('class' => 'bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-3 rounded-lg font-bold border-none shadow-lg transition-all cursor-pointer'));
                ?>
            </form>
        </div>
    </div>
    <?php
}

/**
 * 6. FIELD CALLBACKS (Tailwind Style)
 */
function spin_pulse_text_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : '';
    echo '<div class="flex flex-col gap-1.5">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" 
          class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-sm" />';
    if (!empty($args['desc']))
        echo '<p class="text-xs text-slate-400 italic">' . esc_html($args['desc']) . '</p>';
    echo '</div>';
}

function spin_pulse_textarea_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_textarea($options[$args['id']]) : '';
    echo '<div class="flex flex-col gap-1.5">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<textarea id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" rows="4" 
          class="w-full px-4 py-2.5 bg-white border border-slate-300 rounded-lg focus:ring-2 focus:ring-indigo-500 outline-none shadow-sm">' . $value . '</textarea>';
    echo '</div>';
}

function spin_pulse_color_field_callback($args)
{
    $options = get_option($args['group'], []);
    $value = isset($options[$args['id']]) ? esc_attr($options[$args['id']]) : $args['default'];
    echo '<div class="flex flex-col gap-2 p-4 bg-white border border-slate-200 rounded-xl">';
    echo '<label class="text-sm font-bold text-slate-700">' . esc_html($args['label_name']) . '</label>';
    echo '<input type="text" id="' . esc_attr($args['id']) . '" name="' . esc_attr($args['group']) . '[' . esc_attr($args['id']) . ']" value="' . $value . '" class="spin-pulse-color-picker" data-default-color="' . esc_attr($args['default']) . '" />';
    echo '</div>';
}

/**
 * 7. REGISTER SETTINGS
 */
add_action('admin_init', 'spin_pulse_register_settings');
function spin_pulse_register_settings()
{
    register_setting('spin_pulse_hero_group', 'spin_pulse_hero_settings', 'spin_pulse_sanitize_hero_settings');

    add_settings_section('hero_main_section', 'Hero Content & Brand Colors', '__return_empty_string', 'hero-settings-page');

    add_settings_field(
        'hero_heading',
        '',
        'spin_pulse_text_field_callback',
        'hero-settings-page',
        'hero_main_section',
        ['id' => 'hero_heading', 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Main Heading']
    );
    add_settings_field(
        'hero_description',
        '',
        'spin_pulse_textarea_field_callback',
        'hero-settings-page',
        'hero_main_section',
        ['id' => 'hero_description', 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Hero Description']
    );

    $hero_colors = [
        'hero_bg_start' => ['label' => 'Background Start', 'default' => '#1e293b'],
        'hero_bg_end' => ['label' => 'Background End', 'default' => '#0B0F1A'],
        'hero_text' => ['label' => 'Text Color', 'default' => '#FFFFFF'],
    ];

    foreach ($hero_colors as $id => $data) {
        add_settings_field(
            $id,
            '',
            'spin_pulse_color_field_callback',
            'hero-settings-page',
            'hero_main_section',
            ['id' => $id, 'group' => 'spin_pulse_hero_settings', 'label_name' => $data['label'], 'default' => $data['default']]
        );
    }

    for ($i = 1; $i <= 4; $i++) {
        $sid = "hero_card_{$i}_section";
        add_settings_section($sid, "Feature Card $i", '__return_empty_string', 'hero-settings-page');

        // Badge Text
        add_settings_field(
            "card{$i}_badge",
            '',
            'spin_pulse_text_field_callback',
            'hero-settings-page',
            $sid,
            ['id' => "card{$i}_badge", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Badge Text (Hot, New)']
        );

        // NEW: Badge Background Color
        add_settings_field(
            "card{$i}_badge_bg",
            '',
            'spin_pulse_color_field_callback',
            'hero-settings-page',
            $sid,
            ['id' => "card{$i}_badge_bg", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Badge Color', 'default' => '#7c3aed']
        );

        add_settings_field("card{$i}_title", '', 'spin_pulse_text_field_callback', 'hero-settings-page', $sid, ['id' => "card{$i}_title", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Card Title']);
        add_settings_field("card{$i}_link", '', 'spin_pulse_text_field_callback', 'hero-settings-page', $sid, ['id' => "card{$i}_link", 'group' => 'spin_pulse_hero_settings', 'label_name' => 'Link URL']);
    }
}

function spin_pulse_sanitize_hero_settings($input)
{
    $sanitized = [];
    foreach ((array) $input as $key => $value) {
        // Sanitize Hex Colors
        if (strpos($key, 'color') !== false || strpos($key, 'bg') !== false) {
            $sanitized[$key] = sanitize_hex_color($value);
        } elseif (strpos($key, 'link') !== false) {
            $sanitized[$key] = esc_url_raw($value);
        } else {
            $sanitized[$key] = sanitize_text_field($value);
        }
    }
    return $sanitized;
}


function spin_pulse_admin_style_fix()
{
    echo '<style>#wpbody { background: #f0f2f5; }</style>';
}
add_action('admin_head', 'spin_pulse_admin_style_fix');

require get_template_directory() . '/inc/template-tags.php';
require get_template_directory() . '/inc/template-functions.php';
require get_template_directory() . '/inc/customizer.php';