<?php
/**
 * The template for displaying all pages
 */
get_header();
?>

<main id="primary" class="site-main w-full min-h-screen bg-white">
    <?php if (is_front_page()): 
        // 1. Fetch Hero Settings
        $options = get_option('spin_pulse_hero_settings', []);

        // 2. Logic & Fallbacks
        $heading = !empty($options['hero_heading']) ? $options['hero_heading'] : 'Top Casino Reviews & Bonuses';
        $description = !empty($options['hero_description']) ? $options['hero_description'] : "We analyze hundreds of online casinos to bring you the safest, highest-paying sites for 2026.";
        $bg_start = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
        $bg_end = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
        $h_color = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
        $desc_color = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

        // 3. Author Data
        $author_id = get_post_field('post_author', get_the_ID());
        $author_name = get_the_author_meta('display_name', $author_id);
        $avatar = get_avatar_url($author_id, ['size' => 96]);
        $has_avatar = !strpos($avatar, 'mysteryman') && !strpos($avatar, 'blank') && !strpos($avatar, 'gravatar');
    ?>

        <section class="w-full py-16 md:py-24 lg:py-32" style="background: linear-gradient(135deg, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_end); ?>);">
            <div class="w-full px-6 lg:px-12">
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
                    <div class="flex flex-col">
                        <h1 class="text-4xl md:text-6xl lg:text-7xl font-black leading-[1.1] tracking-[-0.04em]" style="color: <?php echo esc_attr($h_color); ?>;">
                            <?php echo esc_html($heading); ?>
                        </h1>
                        <p class="mt-6 text-lg md:text-xl leading-relaxed max-w-3xl font-medium opacity-90" style="color: <?php echo esc_attr($desc_color); ?>;">
                            <?php echo wp_kses_post(nl2br($description)); ?>
                        </p>
                        
                        <div class="flex items-center space-x-4 mb-8 mt-10 group cursor-default">
                            <div class="relative">
                                <?php if ($has_avatar): ?>
                                    <img src="<?php echo esc_url($avatar); ?>" alt="<?php echo esc_attr($author_name); ?>" class="w-14 h-14 rounded-full border-2 border-white/20 object-cover shadow-lg">
                                <?php else: ?>
                                    <div class="w-14 h-14 rounded-full border-2 border-white/20 bg-white/10 flex items-center justify-center"><svg class="w-7 h-7 text-white/70" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z" /></svg></div>
                                <?php endif; ?>
                                <div class="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1e293b] rounded-full">
                                    <span class="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
                                </div>
                            </div>
                            <div class="flex flex-col">
                                <span class="text-white font-bold"><?php echo esc_html($author_name); ?></span>
                                <span class="text-white/50 text-xs">Certified Industry Expert</span>
                            </div>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        <?php for ($i = 1; $i <= 4; $i++): 
                             $c_title = !empty($options["card{$i}_title"]) ? $options["card{$i}_title"] : "Premium Offer $i";
                             $c_badge = !empty($options["card{$i}_badge"]) ? $options["card{$i}_badge"] : "New Bonus";
                        ?>
                            <div class="group relative rounded-3xl p-8 bg-slate-800/40 border border-white/5 hover:bg-slate-800/60 transition-all shadow-2xl backdrop-blur-sm">
                                <span class="inline-block text-[10px] font-black px-3 py-1 rounded-full mb-4 uppercase bg-indigo-500 text-white"><?php echo esc_html($c_badge); ?></span>
                                <h3 class="text-white font-bold text-xl lg:text-2xl group-hover:text-purple-300 transition-colors"><?php echo esc_html($c_title); ?></h3>
                                <div class="mt-8 flex items-center text-white/30 group-hover:text-purple-400 transition-colors">
                                    <span class="text-xs font-black uppercase">Claim Now</span>
                                    <svg class="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-12 bg-slate-50 w-full">
            <div class="w-full px-6 lg:px-12">
                <div class="mb-10 flex items-end justify-between border-b border-slate-200 pb-6">
                    <div>
                        <h2 class="text-3xl font-black text-slate-900 tracking-tight uppercase italic">Top Recommended Casinos</h2>
                        <p class="text-slate-500 font-medium italic">Hand-picked by SpinPulse Experts</p>
                    </div>
                </div>

                <div class="w-full bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden mb-6">
                    <div class="flex flex-col md:flex-row items-stretch md:items-center">
                        <div class="p-6 md:w-1/5 flex items-center justify-center border-b md:border-b-0 md:border-r border-slate-100 bg-slate-50/30">
                            <div class="w-32 h-20 bg-white rounded-xl flex items-center justify-center border border-slate-200 font-black italic text-slate-300">LOGO</div>
                        </div>
                        <div class="p-8 md:w-2/5">
                            <h3 class="text-3xl font-black text-slate-900">100% UP TO $2,000</h3>
                            <p class="text-slate-500 font-bold">+ 200 FREE SPINS</p>
                        </div>
                        <div class="p-8 md:w-1/5 hidden lg:block border-l border-slate-50">
                            <span class="text-[10px] font-black uppercase text-slate-400">Payout Speed</span>
                            <p class="text-emerald-600 font-bold">Instant Payouts</p>
                        </div>
                        <div class="p-8 md:w-1/5 flex flex-col gap-2">
                            <a href="#" class="bg-emerald-500 text-white text-center py-4 rounded-xl font-black shadow-lg">PLAY NOW</a>
                            <a href="#" class="text-slate-400 text-center text-xs font-bold uppercase">T&Cs Apply</a>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <section class="py-16 bg-white w-full">
            <div class="w-full px-6 lg:px-12">
                <?php while (have_posts()): the_post(); ?>
                    <article class="prose prose-slate prose-lg max-w-none w-full">
                        <?php the_content(); ?>
                    </article>
                <?php endwhile; ?>
            </div>
        </section>

    <?php else: ?>
        <section class="py-16 md:py-24 bg-white w-full">
            <div class="w-full px-6 lg:px-12">
                <?php while (have_posts()): the_post(); ?>
                    <header class="mb-12">
                        <h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter italic uppercase"><?php the_title(); ?></h1>
                    </header>
                    <article class="prose prose-slate prose-lg max-w-none w-full">
                        <?php the_content(); ?>
                    </article>
                <?php endwhile; ?>
            </div>
        </section>
    <?php endif; ?>
</main>

<?php get_footer(); ?>