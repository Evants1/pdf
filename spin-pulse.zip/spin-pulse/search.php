<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Spin_Pulse
 */

get_header();
global $wp_query; // Needed to get the total number of results found
?>

<main id="primary" class="site-main min-h-screen bg-white">

    <section class="sp-single-hero-wrapper py-12 border-b border-slate-100 bg-slate-50">
        <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
            
            <div class="sp-hero-breadcrumbs mb-4 text-sm text-gray-500">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="hover:underline"><?php esc_html_e('Home', 'spin-pulse'); ?></a> &raquo; 
                <span class="sp-hero-current-crumb text-gray-800"><?php esc_html_e('Search', 'spin-pulse'); ?></span>
            </div>

            <header class="sp-search-header">
                <h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-4">
                    <?php 
                    /* translators: %s: search query. */
                    // THEMEFOREST FIX: Removed inline style attribute and used Tailwind class
                    printf( esc_html__( 'Search Results for: %s', 'spin-pulse' ), '<span class="text-[#00d67d]">&ldquo;' . get_search_query() . '&rdquo;</span>' ); 
                    ?>
                </h1>
                
                <p class="sp-search-subtitle text-lg text-slate-600 max-w-2xl mb-8">
                    <?php 
                    if ( $wp_query->found_posts > 0 ) {
                        printf( esc_html( _n( 'We found %s result for your search.', 'We found %s results for your search.', $wp_query->found_posts, 'spin-pulse' ) ), number_format_i18n( $wp_query->found_posts ) );
                    } else {
                        esc_html_e( 'Unfortunately, we couldn\'t find any matching results. Please try another search.', 'spin-pulse' );
                    }
                    ?>
                </p>

                <div class="sp-hero-search-box max-w-xl">
                    <?php get_search_form(); ?>
                </div>
            </header>

        </div>
    </section>

    <div class="sp-search-main-wrapper py-12">
        <div class="max-w-[1200px] mx-auto px-4 sm:px-6">
            
            <div class="sp-search-content">
                <?php if ( have_posts() ) : ?>
                    
                    <div class="sp-search-card-list">
                        <?php while ( have_posts() ) : the_post(); ?>
                            
                            <article id="post-<?php the_ID(); ?>" <?php post_class('sp-search-card'); ?>>
                                
                                <a href="<?php echo esc_url( get_permalink() ); ?>" class="sp-search-card-image-wrap">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'large', array( 'class' => 'sp-search-card-image' ) ); ?>
                                    <?php else: ?>
                                        <div class="sp-search-card-placeholder">
                                            <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="sp-search-card-badges">
                                        <?php 
                                        $post_type = get_post_type();
                                        $badges = [];
                                        
                                        if ( $post_type === 'post' ) {
                                            $categories = get_the_category();
                                            if ( ! empty( $categories ) ) {
                                                foreach ( $categories as $cat ) {
                                                    $badges[] = $cat->name;
                                                }
                                            }
                                        } elseif ( $post_type === 'casino_review' ) {
                                            $terms = get_the_terms( get_the_ID(), 'review_category' );
                                            if ( $terms && ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                                                foreach ( $terms as $term ) {
                                                    $badges[] = $term->name;
                                                }
                                            } else {
                                                $badges[] = 'Review';
                                            }
                                        } else {
                                            $badges[] = str_replace( '_', ' ', ucfirst( $post_type ) );
                                        }
                                        
                                        foreach ( $badges as $badge ) {
                                            echo '<span class="sp-search-badge">' . esc_html( $badge ) . '</span>';
                                        }
                                        ?>
                                    </div>
                                </a>

                                <div class="sp-search-card-content">
                                    <div class="sp-search-card-meta">
                                        <span class="sp-search-card-date"><?php echo esc_html( get_the_date('M j, Y') ); ?></span>
                                        <span class="sp-search-card-dot"></span>
                                        <span class="sp-search-card-author"><?php echo esc_html( get_the_author() ); ?></span>
                                    </div>
                                    
                                    <h2 class="sp-search-card-title">
                                        <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php the_title(); ?></a>
                                    </h2>
                                    
                                    <div class="sp-search-card-excerpt">
                                        <?php echo esc_html( wp_trim_words( get_the_excerpt(), 20, '...' ) ); ?>
                                    </div>
                                    
                                    <div class="sp-search-card-footer">
                                        <a href="<?php echo esc_url( get_permalink() ); ?>" class="sp-search-card-readmore">
                                            <?php esc_html_e( 'Read Article', 'spin-pulse' ); ?>
                                            <span class="sp-search-card-icon">
                                                <svg fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                                            </span>
                                        </a>
                                    </div>
                                </div>

                            </article>

                        <?php endwhile; ?>
                    </div>

                    <div class="sp-search-pagination mt-8">
                        <?php 
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => esc_html__( '← Previous', 'spin-pulse' ),
                            'next_text' => esc_html__( 'Next →', 'spin-pulse' ),
                        ) ); 
                        ?>
                    </div>

                <?php else : ?>
                    <div class="sp-search-no-results bg-slate-50 p-10 text-center rounded-xl border border-slate-200">
                        <svg class="w-16 h-16 mx-auto text-slate-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        <h2 class="text-2xl font-bold text-slate-800 mb-2"><?php esc_html_e( 'No Matches Found', 'spin-pulse' ); ?></h2>
                        <p class="text-slate-600"><?php esc_html_e( 'It seems we can’t find any results based on your current search terms. Try using broader keywords or checking your spelling.', 'spin-pulse' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</main>
<?php get_footer(); ?>