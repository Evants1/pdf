<?php
/**
 * The template for displaying search results pages
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/#search-result
 *
 * @package Spin_Pulse
 */

get_header();
global $wp_query; // Needed to get the total number of results found
?>

<main id="primary" class="site-main min-h-screen bg-white">

    <section class="sp-single-hero-wrapper py-12 border-b border-slate-100 bg-slate-50">
        <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
            
            <div class="sp-hero-breadcrumbs mb-4 text-sm text-gray-500">
                <a href="<?php echo home_url(); ?>" class="hover:underline">Home</a> &raquo; 
                <span class="sp-hero-current-crumb text-gray-800"><?php esc_html_e('Search', 'spin-pulse'); ?></span>
            </div>

            <header class="sp-search-header">
                <h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-4">
                    <?php 
                    /* translators: %s: search query. */
                    printf( esc_html__( 'Search Results for: %s', 'spin-pulse' ), '<span style="color: #5d6d5a;">&ldquo;' . get_search_query() . '&rdquo;</span>' ); 
                    ?>
                </h1>
                
                <p class="sp-search-subtitle text-lg text-slate-600 max-w-2xl mb-8">
                    <?php 
                    if ( $wp_query->found_posts > 0 ) {
                        printf( esc_html( _n( 'We found %s result for your search.', 'We found %s results for your search.', $wp_query->found_posts, 'spin-pulse' ) ), number_format_i18n( $wp_query->found_posts ) );
                    } else {
                        esc_html_e( 'Unfortunately, we couldn\'t find any matching results. Please try another search.', 'spin-pulse' );
                    }
                    ?>
                </p>

                <div class="sp-hero-search-box max-w-xl">
                    <?php get_search_form(); ?>
                </div>
            </header>

        </div>
    </section>

    <div class="sp-right-sidebar-main-wrapper py-12">
        <div class="sp-right-sidebar-container">
            
            <div class="sp-right-sidebar-content">
                <?php if ( have_posts() ) : ?>
                    
                    <div class="sp-search-grid">
                        <?php while ( have_posts() ) : the_post(); ?>
                            
                            <article id="post-<?php the_ID(); ?>" <?php post_class('sp-search-card group'); ?>>
                                
                                <a href="<?php the_permalink(); ?>" class="sp-search-thumbnail-link">
                                    <div class="sp-search-thumbnail relative aspect-[16/9] overflow-hidden bg-slate-100">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <?php the_post_thumbnail( 'medium_large', array( 'class' => 'sp-search-img w-full h-full object-cover transition-transform duration-500 group-hover:scale-105' ) ); ?>
                                        <?php else: ?>
                                            <div class="sp-search-img-placeholder w-full h-full flex items-center justify-center bg-slate-200 text-slate-400">
                                                <svg class="w-12 h-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="absolute top-3 left-3">
                                            <span class="sp-search-badge bg-[#0d3b66] text-white text-[10px] font-black px-2.5 py-1 rounded-sm uppercase tracking-wider shadow-sm">
                                                <?php 
                                                $post_type = get_post_type();
                                                echo esc_html( $post_type === 'post' ? 'Article' : ucfirst($post_type) ); 
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </a>

                                <div class="sp-search-content-wrap">
                                    <div class="sp-search-meta text-xs text-slate-500 font-medium mb-2 flex items-center gap-3">
                                        <span class="sp-search-date"><?php echo get_the_date('M j, Y'); ?></span>
                                        <?php if ( $post_type === 'post' ) : ?>
                                            <span class="w-1 h-1 rounded-full bg-slate-300"></span>
                                            <span class="sp-search-author"><?php the_author(); ?></span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <h2 class="sp-search-title text-xl font-bold text-slate-900 leading-snug mb-3 group-hover:text-[#8c7355] transition-colors">
                                        <a href="<?php the_permalink(); ?>" rel="bookmark"><?php the_title(); ?></a>
                                    </h2>
                                    
                                    <div class="sp-search-excerpt text-slate-600 text-sm leading-relaxed mb-4">
                                        <?php echo wp_trim_words( get_the_excerpt(), 20, '...' ); ?>
                                    </div>
                                    
                                    <a href="<?php the_permalink(); ?>" class="sp-search-read-more inline-flex items-center text-sm font-bold text-[#5d6d5a] group-hover:text-[#0d3b66] transition-colors">
                                        <?php esc_html_e( 'Read More', 'spin-pulse' ); ?>
                                        <svg class="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                                    </a>
                                </div>

                            </article>

                        <?php endwhile; ?>
                    </div>

                    <div class="sp-search-pagination">
                        <?php 
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => __( '&larr; Previous', 'spin-pulse' ),
                            'next_text' => __( 'Next &rarr;', 'spin-pulse' ),
                        ) ); 
                        ?>
                    </div>

                <?php else : ?>
                    <div class="sp-search-no-results bg-slate-50 p-10 text-center rounded-xl border border-slate-200">
                        <svg class="w-16 h-16 mx-auto text-slate-300 mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                        <h2 class="text-2xl font-bold text-slate-800 mb-2"><?php esc_html_e( 'No Matches Found', 'spin-pulse' ); ?></h2>
                        <p class="text-slate-600"><?php esc_html_e( 'It seems we can’t find any results based on your current search terms. Try using broader keywords or checking your spelling.', 'spin-pulse' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <aside class="sp-right-sidebar-sidebar">
                <?php 
                if ( is_active_sidebar( 'sidebar-right' ) ) {
                    dynamic_sidebar( 'sidebar-right' );
                } else {
                    echo '<p class="text-slate-500 italic">' . esc_html__( 'Add widgets to "Right Sidebar" in Appearance > Widgets.', 'spin-pulse' ) . '</p>';
                }
                ?>
            </aside>

        </div>
    </div>
</main>

<?php get_footer(); ?>