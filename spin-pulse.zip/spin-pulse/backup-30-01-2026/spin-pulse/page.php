<?php
/**
 * The template for displaying all pages
 * @package SpinPulse
 */

get_header();
?>

<main id="primary" class="site-main min-h-screen bg-white">
    <div class="spin-pulse-wrapper"> <?php if (is_front_page()):
            $options = get_option('spin_pulse_hero_settings', array());

            // Logic & Fallbacks
            $heading     = !empty($options['hero_heading']) ? $options['hero_heading'] : esc_html__('Find the best', 'spin-pulse');
            $description = !empty($options['hero_description']) ? $options['hero_description'] : esc_html__('Since 1995...', 'spin-pulse');
            $bg_start    = !empty($options['hero_bg_start']) ? $options['hero_bg_start'] : '#1e293b';
            $bg_end      = !empty($options['hero_bg_end']) ? $options['hero_bg_end'] : '#0B0F1A';
            $h_color     = !empty($options['hero_heading_color']) ? $options['hero_heading_color'] : '#FFFFFF';
            $desc_color  = !empty($options['hero_text']) ? $options['hero_text'] : '#CBD5E1';

            $author_id   = get_post_field('post_author', get_the_ID());
            $author_name = get_the_author_meta('display_name', $author_id);
            $avatar_url  = get_avatar_url($author_id, array('size' => 96));
            ?>

            <section class="w-full py-16 md:py-24 lg:py-20"
                style="background: linear-gradient(135deg, <?php echo esc_attr($bg_start); ?>, <?php echo esc_attr($bg_end); ?>);">

                <div class="max-w-main mx-auto px-6 lg:px-12">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">

                        <div class="flex flex-col">
                            <div class="flex items-center space-x-4 mb-8 group cursor-default">
                                <div class="relative">
                                    <img src="<?php echo esc_url($avatar_url); ?>" 
                                         alt="<?php echo esc_attr($author_name); ?>"
                                         class="w-14 h-14 rounded-full border-2 border-white/20 object-cover shadow-lg group-hover:border-purple-500 transition-colors duration-300">
                                    <div class="absolute bottom-0 right-0 w-3.5 h-3.5 bg-emerald-500 border-2 border-[#1e293b] rounded-full">
                                        <span class="absolute inset-0 rounded-full bg-emerald-500 animate-ping opacity-75"></span>
                                    </div>
                                </div>

                                <div class="flex flex-col space-y-1">
                                    <div class="flex items-center gap-2">
                                        <span class="text-white font-bold text-base tracking-tight"><?php echo esc_html($author_name); ?></span>
                                        <span class="bg-white/10 text-white/60 text-[10px] px-1.5 py-0.5 rounded font-black uppercase tracking-wider border border-white/5">
                                            <?php esc_html_e('Verified', 'spin-pulse'); ?>
                                        </span>
                                    </div>
                                    <div class="flex items-center text-white/50 text-xs font-medium space-x-2">
                                        <span><?php printf(esc_html__('Updated: %s', 'spin-pulse'), get_the_modified_date('M j, Y')); ?></span>
                                    </div>
                                </div>
                            </div>

                            <h1 class="text-4xl md:text-6xl font-black leading-[1.1] tracking-tighter-extreme"
                                style="color: <?php echo esc_attr($h_color); ?>;">
                                <?php echo esc_html($heading); ?>
                            </h1>

                            <p class="mt-6 text-lg md:text-xl leading-relaxed max-w-xl font-medium opacity-90 tracking-tight"
                                style="color: <?php echo esc_attr($desc_color); ?>;">
                                <?php echo wp_kses_post(nl2br($description)); ?>
                            </p>
                        </div>

                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                            <?php for ($i = 1; $i <= 4; $i++):
                                $c_title    = !empty($options["card{$i}_title"]) ? $options["card{$i}_title"] : sprintf(esc_html__('Card %d', 'spin-pulse'), $i);
                                $c_link     = !empty($options["card{$i}_link"]) ? $options["card{$i}_link"] : "#";
                                $c_badge    = !empty($options["card{$i}_badge"]) ? $options["card{$i}_badge"] : "";
                                $c_badge_bg = !empty($options["card{$i}_badge_bg"]) ? $options["card{$i}_badge_bg"] : '#7c3aed';
                                ?>
                                <a href="<?php echo esc_url($c_link); ?>"
                                    class="group relative overflow-hidden transition-all duration-500 rounded-3xl p-6 md:p-8 bg-slate-800/40 border border-white/5 hover:border-purple-500/50 hover:bg-slate-800/60 shadow-2xl backdrop-blur-sm flex flex-col">

                                    <div class="flex flex-col h-full">
                                        <div class="flex-grow">
                                            <?php if (!empty($c_badge)): ?>
                                                <span class="inline-block text-[10px] font-black px-3 py-1 rounded-full mb-3 uppercase tracking-[0.1em] shadow-lg"
                                                      style="background-color: <?php echo esc_attr($c_badge_bg); ?>; color: #ffffff;">
                                                    <?php echo esc_html($c_badge); ?>
                                                </span>
                                            <?php endif; ?>

                                            <p class="text-white font-bold text-xl group-hover:text-purple-300 transition-colors leading-snug">
                                                <?php echo esc_html($c_title); ?>
                                            </p>
                                        </div>

                                        <div class="mt-6 flex items-center text-white/30 group-hover:text-purple-400 transition-colors">
                                            <span class="text-xs font-black uppercase tracking-widest">
                                                <?php esc_html_e('Learn More', 'spin-pulse'); ?>
                                            </span>
                                            <svg class="w-5 h-5 ml-2 group-hover:translate-x-2 transition-transform duration-300"
                                                fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M17 8l4 4m0 0l-4 4m4-4H3"></path>
                                            </svg>
                                        </div>
                                    </div>
                                </a>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </section>

            <section class="py-12 bg-white">
                <div class="max-w-main mx-auto px-6 lg:px-12 prose prose-slate">
                    <?php while (have_posts()): the_post();
                        the_content();
                    endwhile; ?>
                </div>
            </section>

        <?php else: ?>
            <section class="py-16 md:py-24 bg-white">
                <div class="max-w-main mx-auto px-6 lg:px-12">
                    <?php if (have_posts()): while (have_posts()): the_post(); ?>
                            <header class="mb-12">
                                <h1 class="text-4xl md:text-6xl font-black text-slate-900 tracking-tight">
                                    <?php the_title(); ?>
                                </h1>
                            </header>
                            
                            <article class="prose prose-slate prose-lg">
                                <?php the_content(); ?>
                            </article>
                        <?php endwhile;
                    else: ?>
                        <p><?php esc_html_e('No content found.', 'spin-pulse'); ?></p>
                    <?php endif; ?>
                </div>
            </section>
        <?php endif; ?>

    </div> </main>

<?php get_footer(); ?>