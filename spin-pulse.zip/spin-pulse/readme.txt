=== Spin Pulse ===

Contributors: [Your Envato Username]
Tags: custom-background, custom-logo, custom-menu, featured-images, translation-ready, blog, entertainment, news
Requires at least: 6.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Spin Pulse is a premium, high-performance WordPress theme designed specifically for online gaming affiliates, casino reviews, and gaming news hubs.

== Description ==

Spin Pulse is a modern, fast, and highly converting WordPress theme built for the iGaming affiliate industry. Featuring custom review layouts, dynamic rating systems, pros & cons lists, and built-in casino card grids, Spin Pulse gives you everything you need to build a trustworthy and profitable casino directory or gaming blog. 

Built with modern coding standards, it is fully responsive, translation-ready, and optimized for SEO and Core Web Vitals.

== Installation ==

1. In your WordPress admin panel, go to Appearance > Themes and click the "Add New" button.
2. Click "Upload Theme" and Choose File, then select the `spin-pulse.zip` file. Click "Install Now".
3. Click "Activate" to use your new theme right away.
4. Follow the prompt at the top of your dashboard to install and activate the required "Spin Pulse Core" plugin for full functionality.

== Frequently Asked Questions ==

= Does this theme require any plugins? =
Yes. To utilize the custom post types (Casino Reviews, Casino Games) and custom shortcodes, the theme requires the included "Spin Pulse Core" plugin to be installed and activated.

= Is this theme translation ready? =
Yes! Spin Pulse is 100% translation-ready and contains a `.pot` file so you can easily translate it using plugins like Loco Translate or WPML.

== Changelog ==

= 1.0.0 - March 2026 =
* Initial release

== Credits ==

* Based on Underscores https://underscores.me/, (C) 2012-2020 Automattic, Inc., [GPLv2 or later](https://www.gnu.org/licenses/gpl-2.0.html)
* Tailwind CSS (Compiled), https://tailwindcss.com/, [MIT License](https://opensource.org/licenses/MIT)
* Font Awesome Free, https://fontawesome.com, Icons: CC BY 4.0, Fonts: SIL OFL 1.1, Code: MIT License
* Google Fonts (Inter), https://fonts.google.com/specimen/Inter, [SIL Open Font License, 1.1](https://scripts.sil.org/OFL)