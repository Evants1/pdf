<?php
/**
 * The template for displaying all single posts – Casino Review Style
 * with selectable sidebar and enhanced related posts.
 *
 * @package Spin_Pulse
 */

get_header();

// Get user-selected sidebar layout (default: right)
$sidebar_layout = get_post_meta( get_the_ID(), 'sp_sidebar_layout', true ) ?: 'right';
?>

<main id="primary" class="site-main min-h-screen bg-white">
    <div class="spin-pulse-wrapper"> <!-- unified wrapper from page.php -->

        <?php while ( have_posts() ) : the_post(); ?>

            <!-- FULL-WIDTH TOP SECTION (no container – full width) -->
            <header class="sp-single-top-section">

                <!-- Breadcrumb with schema.org -->
                <nav class="sp-single-breadcrumb" aria-label="breadcrumb" itemscope itemtype="https://schema.org/BreadcrumbList">
                    <span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">
                        <a href="<?php echo esc_url( home_url( '/' ) ); ?>" itemprop="item"><span itemprop="name">Home</span></a>
                        <meta itemprop="position" content="1" />
                    </span> &rsaquo;
                    <?php
                    $categories = get_the_category();
                    if ( ! empty( $categories ) ) {
                        echo '<span itemprop="itemListElement" itemscope itemtype="https://schema.org/ListItem">';
                        echo '<a href="' . esc_url( get_category_link( $categories[0]->term_id ) ) . '" itemprop="item"><span itemprop="name">' . esc_html( $categories[0]->name ) . '</span></a>';
                        echo '<meta itemprop="position" content="2" />';
                        echo '</span> &rsaquo; ';
                    }
                    ?>
                    <span class="breadcrumb-current" aria-current="page"><?php the_title(); ?></span>
                </nav>

                <!-- Category & Tag Badges -->
                <div class="sp-single-category-badges">
                    <?php
                    foreach ( $categories as $category ) {
                        echo '<a href="' . esc_url( get_category_link( $category->term_id ) ) . '" class="sp-single-badge">' . esc_html( $category->name ) . '</a>';
                    }
                    $tags = get_the_tags();
                    if ( $tags ) {
                        foreach ( $tags as $tag ) {
                            echo '<a href="' . esc_url( get_tag_link( $tag->term_id ) ) . '" class="sp-single-badge">' . esc_html( $tag->name ) . '</a>';
                        }
                    }
                    ?>
                </div>

                <!-- Article Title -->
                <?php the_title( '<h1 class="sp-single-entry-title" itemprop="headline">', '</h1>' ); ?>

                <!-- Author & Last Updated with schema.org -->
                <div class="sp-single-author-meta" itemprop="author" itemscope itemtype="https://schema.org/Person">
                    <?php echo get_avatar( get_the_author_meta( 'ID' ), 52, '', '', array( 'class' => 'sp-single-author-avatar' ) ); ?>
                    <div class="sp-single-author-info">
                        <span class="sp-single-byline">
                            by <a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" itemprop="url"><span itemprop="name"><?php the_author(); ?></span></a>
                        </span>
                        <span class="sp-single-updated">
                            <span class="dashicons dashicons-clock"></span>
                            Last Updated: <time datetime="<?php echo esc_attr( get_the_modified_date( 'c' ) ); ?>" itemprop="dateModified"><?php echo esc_html( get_the_modified_date( 'F j, Y' ) ); ?></time>
                        </span>
                    </div>
                </div>

                <!-- Hero Featured Image with schema.org -->
                <?php if ( has_post_thumbnail() ) : ?>
                    <figure class="sp-single-hero-wrapper" itemprop="image" itemscope itemtype="https://schema.org/ImageObject">
                        <?php
                        the_post_thumbnail( 'full', array(
                            'class'   => 'sp-single-hero-image',
                            'itemprop' => 'url'
                        ) );
                        ?>
                    </figure>
                <?php endif; ?>

            </header><!-- .sp-single-top-section -->

            <!-- CONTENT + SIDEBAR – uses the same max-width container as page.php -->
            <div class="max-w-main mx-auto px-6 lg:px-12">
                <div class="sp-single-container <?php echo esc_attr( 'sidebar-' . $sidebar_layout ); ?>" itemprop="mainEntity" itemscope itemtype="https://schema.org/Article">

                    <?php if ( 'left' === $sidebar_layout ) get_sidebar(); ?>

                    <div class="sp-single-content-area">

                        <article id="post-<?php the_ID(); ?>" <?php post_class( 'sp-single-article' ); ?>>

                            <div class="sp-single-entry-content" itemprop="articleBody">
                                <?php
                                the_content();

                                wp_link_pages( array(
                                    'before'      => '<div class="sp-single-page-links">' . esc_html__( 'Pages:', 'spin-pulse' ) . '</div>',
                                    'link_before' => '<span class="sp-single-page-number">',
                                    'link_after'  => '</span>',
                                ) );
                                ?>
                            </div>

                            <footer class="sp-single-entry-footer">
                                <?php spin_pulse_entry_footer(); ?>
                            </footer>

                        </article>

                        <?php
                        // Post navigation
                        the_post_navigation( array(
                            'prev_text' => '<span class="nav-subtitle">Previous:</span> <span class="nav-title">%title</span>',
                            'next_text' => '<span class="nav-subtitle">Next:</span> <span class="nav-title">%title</span>',
                        ) );

                        // Author bio (if template exists)
                        if ( 'post' === get_post_type() && locate_template( 'template-parts/author-bio.php' ) ) {
                            get_template_part( 'template-parts/author-bio' );
                        }

                        // Comments
                        if ( comments_open() || get_comments_number() ) {
                            comments_template();
                        }
                        ?>

                    </div><!-- .sp-single-content-area -->

                    <?php if ( 'right' === $sidebar_layout ) get_sidebar(); ?>

                </div><!-- .sp-single-container -->
            </div><!-- .max-w-main container -->

            <!-- 🔥 RELATED POSTS – also inside the same container -->
            <?php
            $categories = get_the_category();
            $cat_ids    = wp_list_pluck( $categories, 'term_id' );
            $tags       = get_the_tags();
            $tag_ids    = ( $tags ) ? wp_list_pluck( $tags, 'term_id' ) : array();

            $related_args = array(
                'post_type'           => 'post',
                'posts_per_page'      => 4,
                'post__not_in'        => array( get_the_ID() ),
                'orderby'             => 'date',
                'order'               => 'DESC',
                'ignore_sticky_posts' => 1,
            );

            if ( ! empty( $cat_ids ) || ! empty( $tag_ids ) ) {
                $related_args['tax_query'] = array( 'relation' => 'OR' );
                if ( ! empty( $cat_ids ) ) {
                    $related_args['tax_query'][] = array(
                        'taxonomy' => 'category',
                        'field'    => 'term_id',
                        'terms'    => $cat_ids,
                    );
                }
                if ( ! empty( $tag_ids ) ) {
                    $related_args['tax_query'][] = array(
                        'taxonomy' => 'post_tag',
                        'field'    => 'term_id',
                        'terms'    => $tag_ids,
                    );
                }
            }

            $related_query = new WP_Query( apply_filters( 'sp_related_posts_args', $related_args ) );

            if ( $related_query->have_posts() ) : ?>
                <section class="sp-single-related-section max-w-main mx-auto px-6 lg:px-12">
                    <h2 class="sp-single-related-title">🔥 Related News</h2>
                    <div class="sp-single-related-grid">
                        <?php while ( $related_query->have_posts() ) : $related_query->the_post(); ?>
                            <article class="sp-single-related-card">
                                <a href="<?php the_permalink(); ?>" class="sp-single-related-link">
                                    <?php if ( has_post_thumbnail() ) : ?>
                                        <?php the_post_thumbnail( 'medium_large', array( 'class' => 'sp-single-related-image' ) ); ?>
                                    <?php else : ?>
                                        <img src="<?php echo esc_url( get_template_directory_uri() . '/assets/images/default-related.jpg' ); ?>" alt="" class="sp-single-related-image">
                                    <?php endif; ?>
                                    <div class="sp-single-related-overlay"></div>
                                    <div class="sp-single-related-badges">
                                        <?php
                                        $post_cats = get_the_category();
                                        $count = 0;
                                        foreach ( $post_cats as $cat ) {
                                            if ( $count >= 3 ) break;
                                            echo '<span class="sp-single-badge">' . esc_html( $cat->name ) . '</span>';
                                            $count++;
                                        }
                                        ?>
                                    </div>
                                    <h3 class="sp-single-related-card-title"><?php the_title(); ?></h3>
                                </a>
                            </article>
                        <?php endwhile; ?>
                    </div>
                </section>
            <?php endif; wp_reset_postdata(); ?>

        <?php endwhile; ?>

    </div><!-- .spin-pulse-wrapper -->
</main><!-- #primary -->

<?php
get_footer();