/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php',
    './**/*.php',
    './inc/**/*.php',
    './template-parts/**/*.php',
    './page-templates/**/*.php',
    './js/**/*.js',
    './assets/**/*.js',
    './src/**/*.css',
  ],
  safelist: [
    // Only truly dynamic classes needed for JS functionality
    
    // 1. JS Modal/Comparison System
    'opacity-0',
    'opacity-100',
    'pointer-events-none',
    'pointer-events-auto',
    'scale-95',
    'scale-100',
    'animate-modal-in',
    'animate-fade-in',
    
    // 2. JS Grid Layout Changes
    'grid-cols-2',
    'grid-cols-3',
    'grid-cols-4',
    'divide-x',
    
    // 3. JS Color Changes
    'bg-emerald-500',
    'bg-emerald-600',
    
    // 4. Specific dynamic responsive classes from JS
    // (Only if your JS dynamically adds responsive prefixes)
    { pattern: /^(sm|md|lg|xl):grid-cols-[2-4]$/ },
    
    // 5. Custom animation classes from your theme extension
    'animate-modal-in',
    'animate-fade-in',
    'animate-slide-down',
    
    // 6. Custom max width utility
    'max-w-main',
    
    // 7. Custom spacing utility
    'tracking-tighter-extreme',
  ],
  theme: {
    extend: {
      colors: {
        'brand-gold': '#b8860b',
        'brand-bone': '#faf9f6',
        'brand-dark': '#1a1a1a',
        'casino-dark': '#0f172a',
        'casino-card': '#1e293b',
      },
      maxWidth: {
        'main': '80%',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      letterSpacing: {
        'tighter-extreme': '-0.04em',
      },
      keyframes: {
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
        modalFade: {
          '0%': { opacity: '0', transform: 'scale(0.95) translateY(10px)' },
          '100%': { opacity: '1', transform: 'scale(1) translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        }
      },
      animation: {
        'shimmer': 'shimmer 2s infinite',
        'modal-in': 'modalFade 0.3s ease-out forwards',
        'slide-down': 'slideDown 0.3s ease-out forwards',
        'fade-in': 'fadeIn 0.4s ease-in forwards',
      },
      backdropBlur: {
        xs: '2px',
      }
    },
  },
  plugins: [],
}