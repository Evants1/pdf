/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php',
    './**/*.php',
    './js/**/*.js',
    '!./node_modules/**/*',
    '!./vendor/**/*',
  ],
  safelist: [
    // Core / layout
    'container', 'mx-auto', 'px-4', 'px-6', 'px-8', 'py-12', 'py-16', 'py-24', 'py-32',
    'flex', 'grid', 'grid-cols-1', 'sm:grid-cols-2', 'md:grid-cols-2', 'lg:grid-cols-2', 'xl:grid-cols-3', 'grid-cols-4',
    'gap-2', 'gap-4', 'gap-6', 'gap-8', 'gap-10', 'gap-12', 'items-center', 'justify-center', 'justify-between',
    'w-full', 'w-screen', 'w-12', 'h-12', 'w-14', 'h-14', 'w-3', 'h-3', 'w-3.5', 'h-3.5', '-mx-4', '-mx-6', '-mx-8', '-mx-px',
    'relative', 'absolute', 'inset-0', 'inset-x-0', 'top-full', 'bottom-0', 'right-0', '-translate-x-1/2',
    'max-w-screen-xl', 'max-w-screen-2xl', 'max-w-none', 'max-w-7xl',

    // Layout & Spacing
    'lg:px-12', 'lg:mt-0', 'md:flex-row', 'md:w-1/4', 'md:py-0', 'md:px-6',

    // Colors for the new Casino Rows
    'text-indigo-600', 'bg-emerald-600', 'shadow-emerald-100', 'bg-slate-50',
    'border-slate-100', 'text-slate-300', 'italic',

    

    // Typography
    'text-2xl', 'tracking-tighter', 'font-black', 'uppercase',

    // Typography & colors (Updated for premium CASINO design)
    'text-3xl', 'text-4xl', 'md:text-5xl', 'md:text-6xl', 'lg:text-6xl', 'lg:text-7xl',
    'font-extrabold', 'font-bold', 'font-black', 'font-medium',
    'leading-[1.1]', 'leading-tight', 'leading-snug', 'leading-relaxed',
    'tracking-[-0.04em]', 'tracking-tight', 'tracking-wider', 'tracking-widest',
    'text-xs', 'text-sm', 'text-base', 'text-lg', 'text-xl',
    'mt-4', 'mt-6', 'mt-8', 'mt-10', 'mb-1', 'mb-3', 'mb-4', 'mb-8', 'max-w-xl', 'max-w-2xl', 'max-w-3xl',
    'bg-white', 'text-slate-900', 'text-slate-300', 'text-slate-600', 'text-white', 'text-white/70', 'text-white/60', 'text-white/50', 'text-white/30',

    // Admin & UI Specific
    'bg-indigo-600', 'bg-indigo-700', 'bg-slate-50', 'bg-slate-700', 'bg-slate-800/40', 'bg-slate-800/60', 'bg-emerald-500',
    'border-slate-100', 'border-slate-200', 'border-slate-300', 'border-slate-800', 'bg-white/10',
    'bg-[#1e293b]', 'bg-[#0B0F1A]', 'bg-[#111827]',
    'border-white/5', 'border-white/10', 'border-white/20', 'border-purple-500', 'border-purple-500/50',
    'text-purple-300', 'text-purple-400', 'bg-rose-500', 'bg-amber-500',

    // Interactions & Animations
    'rounded', 'rounded-full', 'rounded-xl', 'rounded-2xl', 'rounded-3xl', 'shadow', 'shadow-lg', 'shadow-xl', 'shadow-2xl', 'hover:shadow-2xl',
    'transition', 'transition-all', 'transition-transform', 'transition-colors', 'duration-200', 'duration-300', 'duration-500',
    'group-hover:block', 'group-hover:rotate-180', 'animate-slide-down', 'animate-fade-in', 'animate-ping',
    'group-hover:scale-105', 'group-hover:translate-x-1', 'group-hover:translate-x-2', 'group-hover:border-purple-500',
    'brightness-0', 'invert', 'backdrop-blur-sm', 'opacity-90', 'opacity-75', 'opacity-60',

    // Targeted responsive patterns
    // Transparency for dynamic badges (We used the '20' suffix for opacity)
    { pattern: /(bg|text|border)-(purple|indigo|emerald|rose|amber|blue|slate)-(500|600)\/20/ },
    { pattern: /sm:(grid-cols|px|gap|flex|hidden|block|text|mt|mb)/ },
    { pattern: /md:(grid-cols|flex|text|px|gap|mt|py|hidden|w)/ },
    { pattern: /lg:(grid-cols|flex|px|gap|hidden|w|max-w)/ },
    { pattern: /xl:(grid-cols|px|gap|max-w)/ },
    { pattern: /from-(slate|blue|gray)-(800|900|950)/ },
    { pattern: /to-(slate|blue|gray)-(800|900|950)/ },

    'min-h-[50vh]', 'min-h-screen', 'h-screen',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      // Added custom letter spacing for the "High-End" look
      letterSpacing: {
        'tighter-extreme': '-0.04em',
      },
      keyframes: {
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        }
      },
      animation: {
        'slide-down': 'slideDown 0.3s ease-out forwards',
        'fade-in': 'fadeIn 0.5s ease-in forwards',
      },
      backdropBlur: {
        xs: '2px',
      }
    },
  },
  plugins: [],
}