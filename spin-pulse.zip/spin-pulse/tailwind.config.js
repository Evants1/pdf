/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.php",
    "./inc/**/*.php",
    "./template-parts/**/*.php",
    "./js/**/*.js",
  ],
  theme: {
    extend: {
      // 1. Enhanced Animations for Sub-menus and Transitions
      animation: {
        'fade-in': 'fadeIn 0.3s ease-out',
        'slide-down': 'slideDown 0.3s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
      // 2. Refined Professional Color Palette with Accessibility in Mind
      colors: {
        'casino-navy': '#0f172a',    // Deep navy for logos/headings
        'casino-blue': '#1e40af',    // Primary blue for branding
        'casino-blue-dark': '#1e3a8a', // Darker variant for hovers
        'casino-gold': '#fbbf24',    // Gold for CTAs and accents
        'nav-text': '#334155',       // Slate for text readability (WCAG compliant)
        'badge-green': '#ecfdf5',    // Light green for "New" badges
        'badge-red': '#fef2f2',      // Light red for "Top" badges
        'badge-gray': '#f1f5f9',     // Light gray for "Best" badges
        'focus-ring': '#3b82f6',     // Blue focus ring for accessibility
      },
      // 3. Typography with Better Readability
      fontFamily: {
        'sans': ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      // 4. Box Shadows and Borders for Professional Depth
      boxShadow: {
        'menu': '0 4px 20px rgba(0, 0, 0, 0.1)',
        'cta': '0 4px 14px rgba(30, 64, 175, 0.2)',
      },
      // 5. Transitions for Smoother UX
      transitionProperty: {
        'height': 'height',
      },
    },
  },
  plugins: [
    // Optional: Add plugins if needed, but keep minimal for ThemeForest
  ],
}