/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ['./*.php', './**/*.php', './js/**/*.js', './src/**/*.css'],
  safelist: [
    // Core / layout
    'container', 'mx-auto', 'px-4', 'px-6', 'px-8', 'py-12', 'py-16', 'py-24', 'py-32',
    'flex', 'grid', 'grid-cols-1', 'sm:grid-cols-2', 'md:grid-cols-2', 'lg:grid-cols-2', 'xl:grid-cols-3', 'grid-cols-4',
    'gap-1', 'gap-2', 'gap-4', 'gap-6', 'gap-8', 'gap-10', 'gap-12', 'items-center', 'justify-center', 'justify-between',
    'w-full', 'w-screen', 'w-12', 'h-12', 'w-14', 'h-14', 'w-16', 'w-20', 'h-20', 'w-3', 'h-3', 'w-3.5', 'h-3.5', 'w-5', 'h-5',
    '-mx-4', '-mx-6', '-mx-8', '-mx-px', 'relative', 'absolute', 'inset-0', 'inset-x-0', 'top-full', 'bottom-10', 'right-0',
    'left-1/2', '-translate-x-1/2', 'translate-y-40', 'z-40', 'z-50', 'z-[60]',
    'max-w-screen-xl', 'max-w-screen-2xl', 'max-w-none', 'max-w-7xl', 'max-w-6xl', 'max-w-md', 'max-w-4xl',

    // Layout & Spacing
    'lg:px-12', 'lg:mt-0', 'md:flex-row', 'md:w-1/3', 'md:w-2/3', 'md:py-0', 'md:px-6', 'p-6', 'p-8', 'p-10', 'p-3', 'py-4', 'mr-2', 'mb-4', 'mb-8', 'space-y-6', 'space-y-4',

    // Casino Specific Brand Colors & UI (Updated for Rolling Slots & Jackpot City)
    'bg-brand-bone', 'bg-brand-gold', 'bg-brand-dark', 'text-brand-gold', 'bg-[#f3f0eb]', 'bg-[#4b0082]', 'text-[#4b0082]',
    'border-amber-200', 'text-emerald-600', 'bg-emerald-600', 'shadow-emerald-100', 'bg-slate-50', 'bg-slate-50/50',
    'border-slate-100', 'border-slate-200', 'border-slate-50', 'text-slate-300', 'italic', 'cursor-not-allowed', 'border-purple-400', 'text-purple-200',

    // ThemeForest Professional Design Additions
    'bg-[#131928]', 'hover:bg-[#1e263b]', 'bg-[#8b3d3d]', 'hover:bg-[#6e2f2f]',
    'text-rose-700', 'text-emerald-500', 'text-amber-500', 'text-amber-400',
    'max-h-12', 'object-contain', 'overflow-hidden', 'border-b', 'flex-grow', 'shrink-0', 'space-y-3', 'fill-current',

    // Typography (Removed forced Serif/Sans references in safelist to allow inheritance)
    'text-2xl', 'text-3xl', 'text-4xl', 'text-5xl', 'tracking-tighter', 'tracking-widest', 'font-black', 'uppercase',
    'font-extrabold', 'font-bold', 'font-medium', 'leading-none', 'text-xs', 'text-sm', 'text-base', 'text-lg', 'text-xl',

    // Modal & Comparison UI
    'backdrop-blur-md', 'rounded-[32px]', 'rounded-[2.5rem]', 'rounded-[3rem]', 'shadow-inner', 'animate-shimmer', 'animate-modal-in',

    // Interactions & Animations
    'rounded', 'rounded-lg', 'rounded-xl', 'rounded-2xl', 'rounded-3xl', 'rounded-full', 'shadow', 'shadow-sm', 'shadow-lg', 'shadow-xl', 'shadow-2xl', 'hover:shadow-2xl', 'hover:shadow-xl',
    'transition', 'transition-all', 'transition-transform', 'transition-colors', 'duration-200', 'duration-300', 'duration-500',
    'group-hover:block', 'group-hover:rotate-180', 'animate-slide-down', 'animate-fade-in', 'animate-ping',
    'group-hover:scale-105', 'group-hover:scale-110', 'group-hover:translate-x-1', 'transform', 'opacity-0', 'opacity-100',
    'opacity-100', 'opacity-0',
    'pointer-events-none', 'pointer-events-auto', 'cursor-pointer',
    'cursor-not-allowed', 'bg-brand-gold', 'bg-slate-700', 'text-white', 'text-slate-400',

    // Modal Backdrop & Layout
    'bg-black/80',
    'backdrop-blur-sm',
    'fixed',
    'inset-0',
    'z-[100]',
    'flex',
    'hidden',
    'items-center',
    'justify-center',

    // Dynamic JS Injected Classes
    'grid-cols-2',
    'divide-x',
    'divide-slate-100',
    'animate-modal-in',
    'animate-fade-in',
    'max-w-main',
    'mx-auto',
    'rounded-b-[2rem]',
    'scale-95',
    'scale-100',
    'bg-emerald-500',

    'justify-start',
    'flex-grow',
    'space-y-4',
    'space-y-1',
    'h-8',
    'w-auto',
    'mt-6',
    'tracking-tighter-extreme',
    'group-hover:translate-x-2',
    'text-white/30',
    'text-white/50',
    'text-white/60',


    // Comparison Table Specifics
    'bg-[#0f172a]', 'bg-[#1e293b]', 'divide-gray-800', 'border-gray-800', 'text-blue-400', 'text-green-400',
    'hover:bg-[#1e293b]/50', 'scale-105', 'backdrop-blur-sm', 'animate-modal-in',

    // Targeted responsive patterns
    { pattern: /(bg|text|border)-(purple|indigo|emerald|rose|amber|blue|slate)-(500|600)\/20/ },
    { pattern: /sm:(grid-cols|px|gap|flex|hidden|block|text|mt|mb)/ },
    { pattern: /md:(grid-cols|flex|text|px|gap|mt|py|hidden|w)/ },
    { pattern: /lg:(grid-cols|flex|px|gap|hidden|w|max-w)/ },
    { pattern: /xl:(grid-cols|px|gap|max-w)/ },

    { pattern: /grid-cols-(1|2|3|4)/ },
    { pattern: /(bg|text|border)-(emerald|blue|purple|slate|amber)-(50|100|400|500|600)/ },
    { pattern: /bg-(blue|gray|green)-(500|600|700|800|900)/ },

    'min-h-[50vh]', 'min-h-screen', 'h-screen',
  ],
  theme: {
    extend: {
      colors: {
        'brand-gold': '#b8860b',
        'brand-bone': '#faf9f6',
        'brand-dark': '#1a1a1a',
        'casino-dark': '#0f172a',
        'casino-card': '#1e293b',
      },
      maxWidth: {
        'main': '75%',
      },
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      letterSpacing: {
        'tighter-extreme': '-0.04em',
      },
      keyframes: {
        shimmer: {
          '100%': { transform: 'translateX(100%)' },
        },
        modalFade: { // This is the name used below
          '0%': { opacity: '0', transform: 'scale(0.95) translateY(10px)' },
          '100%': { opacity: '1', transform: 'scale(1) translateY(0)' },
        },
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        }
      },
      animation: {
        'shimmer': 'shimmer 2s infinite',
        'modal-in': 'modalFade 0.3s ease-out forwards',
        'slide-down': 'slideDown 0.3s ease-out forwards',
        'fade-in': 'fadeIn 0.4s ease-in forwards',
      },
      backdropBlur: {
        xs: '2px',
      }
    },
  },
  plugins: [],
}