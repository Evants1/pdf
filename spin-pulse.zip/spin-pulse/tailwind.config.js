/** @type {import('tailwindcss').Config} */
module.exports = {
  // 1. CONTENT: Tell Tailwind to scan all PHP and JS files in your theme
  content: [
    "./*.php",
    "./inc/**/*.php",
    "./template-parts/**/*.php",
    "./js/**/*.js",
  ],

  // 2. THEME: Define your Casino design system
  theme: {
    extend: {
      colors: {
        // New Clean Blue Palette
        'casino-blue': {
          DEFAULT: '#1e40af', // Royal Blue
          dark: '#1e3a8a',    // Navy Blue
          light: '#eff6ff',   // Very Light Blue (for backgrounds)
        },
        'casino-sky': '#0ea5e9', // Sky Blue for accents/links
        'casino-slate': '#64748b', // For secondary text
        'casino-white': '#ffffff',

        // Keep a "Conversion Gold" just for buttons
        'casino-gold': '#fbbf24',
        'casino-accent': '#f59e0b',
      },
      backgroundImage: {
        // A professional blue gradient instead of gold
        'blue-gradient': 'linear-gradient(to right, #1e40af, #0ea5e9)',
        'soft-blue': 'linear-gradient(180deg, #eff6ff 0%, #ffffff 100%)',
      }
    },
  },

  // 3. PLUGINS: Leave empty for now (standard for ThemeForest)
  plugins: [],
}