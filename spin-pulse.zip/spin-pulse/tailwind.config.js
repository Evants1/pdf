/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php',
    './**/*.php',
    './js/**/*.js',
    '!./node_modules/**/*',
    '!./vendor/**/*',
  ],
  safelist: [
    // Core / layout
    'container', 'mx-auto', 'px-4', 'px-6', 'px-8', 'py-12', 'py-16',
    'flex', 'grid', 'grid-cols-1', 'sm:grid-cols-2', 'md:grid-cols-2', 'lg:grid-cols-2', 'xl:grid-cols-3', 'grid-cols-4',
    'gap-4', 'gap-6', 'gap-8', 'gap-12', 'items-center', 'justify-center', 'justify-between',
    'w-full', 'w-screen', '-mx-4', '-mx-6', '-mx-8', '-mx-px',
    'relative', 'absolute', 'inset-0', 'inset-x-0', 'top-full', '-translate-x-1/2',
    'max-w-screen-xl', 'max-w-screen-2xl', 'max-w-none', 'max-w-7xl',

    // Typography & colors
    'text-3xl', 'text-4xl', 'md:text-5xl', 'lg:text-6xl', 'font-extrabold', 'font-bold', 'font-black', 'leading-tight', 'leading-snug',
    'text-lg', 'text-xl', 'mt-4', 'mt-6', 'mt-8', 'mb-6', 'max-w-xl', 'max-w-2xl', 'max-w-3xl',
    'bg-white', 'text-slate-900', 'text-slate-600', 'text-white', 

    // Admin & UI Specific
    'bg-indigo-600', 'bg-indigo-700', 'bg-slate-50', 'border-slate-100', 'border-slate-200', 'border-slate-300',
    'bg-[#1e293b]', 'bg-[#0B0F1A]', 'bg-[#111827]',
    'border-white/5', 'border-purple-500', 
    'text-purple-400', 'bg-emerald-500', 'bg-rose-500', 'bg-amber-500',

    // Interactions & Animations
    'rounded-xl', 'rounded-2xl', 'rounded-3xl', 'shadow', 'shadow-lg', 'shadow-xl', 'hover:shadow-2xl',
    'transition', 'transition-all', 'transition-transform', 'duration-300', 'duration-500', 
    'group-hover:block', 'group-hover:rotate-180', 'animate-slide-down',
    'group-hover:scale-105', 'group-hover:translate-x-1', 'brightness-0', 'invert',

    // Targeted responsive patterns
    { pattern: /sm:(grid-cols|px|gap|flex|hidden|block|text|mt|mb)/ },
    { pattern: /md:(grid-cols|flex|text|px|gap|mt|py|hidden|w)/ },
    { pattern: /lg:(grid-cols|flex|px|gap|hidden|w|max-w)/ },
    { pattern: /xl:(grid-cols|px|gap|max-w)/ },
    { pattern: /from-(slate|blue|gray)-(800|900|950)/ },
    { pattern: /to-(slate|blue|gray)-(800|900|950)/ },

    'min-h-[50vh]', 'min-h-screen', 'h-screen',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
      keyframes: {
        slideDown: {
          '0%': { opacity: '0', transform: 'translateY(-10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        }
      },
      animation: {
        'slide-down': 'slideDown 0.3s ease-out forwards',
      }
    },
  },
  plugins: [],
}