/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './*.php',
    './**/*.php',
    './js/**/*.js',
    '!./node_modules/**/*',
    '!./vendor/**/*',
  ],
  safelist: [
    // ────────────────────────────────────────────────
    // Core / layout (already good – keeping + expanding)
    // ────────────────────────────────────────────────
    'container', 'mx-auto', 'px-4', 'px-6', 'px-8', 'py-12', 'py-16',
    'flex', 'grid', 'grid-cols-1', 'sm:grid-cols-2', 'md:grid-cols-2', 'lg:grid-cols-2', 'xl:grid-cols-3',
    'gap-4', 'gap-6', 'gap-8', 'gap-12', 'items-center', 'justify-center', 'justify-between',

    // Full-width & full-bleed helpers
    'w-full', 'w-screen', '-mx-4', '-mx-6', '-mx-8', '-mx-px',
    'relative', 'absolute', 'inset-0', 'inset-x-0',

    // Wider / responsive containers
    'max-w-screen-xl', 'max-w-screen-2xl', 'max-w-none',

    // ────────────────────────────────────────────────
    // Typography & colors from your hero example
    // ────────────────────────────────────────────────
    'text-3xl', 'text-4xl', 'md:text-5xl', 'lg:text-6xl', 'font-extrabold', 'font-bold', 'leading-tight', 'leading-snug',
    'text-lg', 'text-xl', 'mt-4', 'mt-6', 'mt-8', 'mb-6', 'max-w-xl', 'max-w-2xl', 'max-w-3xl',
    'bg-gradient-to-r', 'bg-gradient-to-br',
    'text-orange-400', 'text-orange-500', 'text-purple-50', 'text-purple-100', 'text-white',

    // ────────────────────────────────────────────────
    // Cards / effects / interactions
    // ────────────────────────────────────────────────
    'rounded-xl', 'rounded-2xl', 'rounded-3xl', 'shadow', 'shadow-lg', 'shadow-xl', 'hover:shadow-2xl',
    'transition', 'transition-all', 'duration-300', 'duration-500', 'bg-emerald-500', 'bg-blue-500', 'bg-rose-500',
    'inline-block', 'block', 'bg-orange-500', 'bg-indigo-950', 'text-white', 'text-xs', 'font-bold', 'px-2', 'py-1', 'mb-3',
    'group', 'group-hover:scale-105', 'group-hover:translate-x-1', 'group-hover:shadow-xl',

    // ────────────────────────────────────────────────
    // Targeted responsive patterns (expanded a bit)
    // ────────────────────────────────────────────────
    { pattern: /sm:(grid-cols|px|gap|flex|hidden|block|text|mt|mb)/ },
    { pattern: /md:(grid-cols|flex|text|px|gap|mt|py|hidden|w)/ },
    { pattern: /lg:(grid-cols|flex|px|gap|hidden|w|max-w)/ },
    { pattern: /xl:(grid-cols|px|gap|max-w)/ },

    // ────────────────────────────────────────────────
    // ALL dynamic hero colors – explicit list + patterns
    // ────────────────────────────────────────────────
    // Explicit (from your current defaults)
    'from-purple-600', 'from-purple-700', 'from-purple-800',
    'via-purple-600', 'via-purple-700', 'via-purple-800',
    'to-purple-700', 'to-purple-800', 'to-purple-900',

    'text-orange-400', 'text-orange-500', 'text-orange-600',
    'text-purple-50', 'text-purple-100', 'text-purple-200',

    // Pattern for broader protection (if admins pick nearby shades)
    // Covers purple/indigo/orange gradients & text in 50-900 range
    { pattern: /from-(purple|indigo|orange)-(500|600|700|800)/ },
    { pattern: /via-(purple|indigo)-(600|700|800)/ },
    { pattern: /to-(purple|indigo|orange)-(700|800|900)/ },
    { pattern: /text-(orange|purple)-(50|100|200|400|500|600)/ },

    // Optional broad catch-all if you allow many custom colors later
    // { pattern: /(from|via|to|text|bg)-(purple|indigo|orange|pink|blue|amber)-(50|[1-9]00)/ },

    // ────────────────────────────────────────────────
    // Other common helpers you might use in dynamic contexts
    // ────────────────────────────────────────────────
    'min-h-[50vh]', 'min-h-screen', 'h-screen',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'ui-sans-serif', 'system-ui'],
      },
    },
  },
  plugins: [],
}