<?php
/**
 * Template Name: SP Right Sidebar
 * Template Post Type: post, page
 */

get_header();

// --- Dynamic Calculations ---
$sp_content = get_post_field('post_content', get_the_ID());
$sp_word_count = str_word_count(strip_tags($sp_content));
$sp_reading_time = ceil($sp_word_count / 200);
if ($sp_reading_time < 1) {
    $sp_reading_time = 1; 
}

$sp_views = get_post_meta(get_the_ID(), 'post_views_count', true);
$sp_views = $sp_views ? $sp_views : '0';

$current_author_id = get_post_field('post_author', get_the_ID());
$current_author_name = get_the_author_meta('display_name', $current_author_id);
?>

<main class="site-main min-h-screen bg-white">

    <section class="sp-single-hero-wrapper py-12 border-b border-slate-200 bg-slate-50">
        <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
            
            <div class="sp-hero-breadcrumbs mb-4 text-sm text-gray-500">
                <a href="<?php echo home_url(); ?>" class="hover:underline">Home</a> &raquo; 
                <span class="sp-hero-current-crumb text-gray-800"><?php the_title(); ?></span>
            </div>

            <h1 class="sp-hero-title text-4xl md:text-5xl lg:text-6xl font-black tracking-tight mb-8 text-slate-900"><?php the_title(); ?></h1>

            <div class="sp-hero-author-box flex flex-wrap items-center gap-6">
                <div class="flex items-center gap-4">
                    <div class="sp-hero-author-avatar">
                        <?php echo get_avatar($current_author_id, 56, '', '', array('class' => 'rounded-full border-2 border-white shadow-md')); ?>
                    </div>
                    <div class="sp-hero-author-details flex flex-col justify-center">
                        <div class="sp-hero-author-name text-slate-600">Authored By <em class="not-italic font-bold text-slate-900"><?php echo esc_html($current_author_name); ?></em></div>
                        <div class="sp-hero-author-date text-sm text-slate-500">Last Updated: <?php the_modified_date('F j, Y'); ?></div>
                    </div>
                </div>

                <?php
                $tw_url = get_the_author_meta('twitter', $current_author_id);
                $fb_url = get_the_author_meta('facebook', $current_author_id);
                $ig_url = get_the_author_meta('instagram', $current_author_id);
                $li_url = get_the_author_meta('linkedin', $current_author_id);
                $yt_url = get_the_author_meta('youtube', $current_author_id);
                ?>

                <?php if ($tw_url || $fb_url || $ig_url || $li_url || $yt_url): ?>
                    <div class="sp-hero-author-socials ml-0 sm:ml-4 sm:pl-6 sm:border-l border-slate-300 flex items-center gap-3">
                        <?php if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #0f1419;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M23 3a10.9 10.9 0 0 1-3.14 1.53 4.48 4.48 0 0 0-7.86 3v1A10.66 10.66 0 0 1 3 4s-4 9 5 13a11.64 11.64 0 0 1-7 2c9 5 20 0 20-11.5a4.5 4.5 0 0 0-.08-.83A7.72 7.72 0 0 0 23 3z"></path></svg></a><?php endif; ?>
                        <?php if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #1877F2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z"></path></svg></a><?php endif; ?>
                        <?php if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #E1306C;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="20" rx="5" ry="5"></rect><path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"></path><line x1="17.5" y1="6.5" x2="17.51" y2="6.5"></line></svg></a><?php endif; ?>
                        <?php if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" target="_blank" rel="noopener noreferrer" class="flex items-center justify-center w-10 h-10 rounded-full bg-white shadow-sm border border-slate-200 hover:-translate-y-1 transition-transform" style="color: #0A66C2;"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z"></path><rect x="2" y="9" width="4" height="12"></rect><circle cx="4" cy="4" r="2"></circle></svg></a><?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>

            <?php if (is_single()): ?>
            <div class="sp-hero-info-row flex flex-wrap gap-8 mt-8 pt-8 border-t border-slate-200">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path><line x1="7" y1="7" x2="7.01" y2="7"></line></svg></div>
                    <div class="text-sm text-slate-600">Categories: <strong class="text-slate-900"><?php echo get_the_category_list(', '); ?></strong></div>
                </div>
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg></div>
                    <div class="text-sm text-slate-600">Views: <strong class="text-slate-900"><?php echo esc_html($sp_views); ?></strong></div>
                </div>
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-lg bg-white shadow-sm flex items-center justify-center border border-slate-200"><svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#122331" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg></div>
                    <div class="text-sm text-slate-600">Read Time: <strong class="text-slate-900"><?php echo esc_html($sp_reading_time); ?> min</strong></div>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </section>

    <div class="sp-right-sidebar-main-wrapper py-16">
        <div class="sp-right-sidebar-container">
            <div class="sp-right-sidebar-content w-full md:w-2/3">
                <?php if (have_posts()) : while (have_posts()) : the_post(); ?>
                    <article class="sp-single-article">
                        <div class="sp-single-content prose prose-slate prose-lg max-w-none">
                            <?php the_content(); ?>
                        </div>
                    </article>
                <?php endwhile; endif; ?>
                
                <?php if (is_single() && get_the_author_meta('description', $current_author_id)): ?>
                    <div class="sp-author-bio-container mt-12 bg-slate-50 border border-slate-200 rounded-2xl p-8 flex flex-col md:flex-row items-center md:items-start gap-6 shadow-sm">
                        <div class="flex-shrink-0">
                            <?php echo get_avatar($current_author_id, 96, '', '', array('class' => 'rounded-full border-4 border-white shadow-md')); ?>
                        </div>
                        <div class="text-center md:text-left">
                            <h3 class="text-xl font-extrabold text-slate-900 mb-2">
                                <span class="block text-xs uppercase tracking-widest text-emerald-600 font-bold mb-1">Written by</span>
                                <?php echo esc_html($current_author_name); ?>
                            </h3>
                            <div class="text-slate-600 text-sm leading-relaxed mb-4">
                                <?php echo wp_kses_post(wpautop(get_the_author_meta('description', $current_author_id))); ?>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <aside class="sp-right-sidebar-sidebar w-full md:w-1/3">
                <?php if (is_active_sidebar('sidebar-right')) : ?>
                    <?php dynamic_sidebar('sidebar-right'); ?>
                <?php else : ?>
                    <p class="text-gray-500 italic"><?php esc_html_e('Please add widgets to "sidebar-right" in Appearance > Widgets.', 'spin-pulse'); ?></p>
                <?php endif; ?>
            </aside>
        </div>
    </div>
    
    <?php if (is_single()): ?>
        <section class="sp-recent-post-full-wrapper">
            <div class="sp-recent-post-container">
                
                <div class="sp-recent-post-main">
                    <div class="sp-recent-post-header">
                        <h2 class="sp-recent-post-title-main">Recent Posts</h2>
                        <div class="sp-recent-post-categories">
                            <?php 
                            $all_cats = get_categories(array('hide_empty' => true));
                            if (!empty($all_cats)) {
                                foreach($all_cats as $cat) {
                                    echo '<a href="'.esc_url(get_category_link($cat->term_id)).'" class="sp-recent-post-cat-link">'.esc_html($cat->name).'</a>';
                                }
                            }
                            ?>
                        </div>
                    </div>
                    
                    <div class="sp-recent-post-list">
                        <?php
                        $recent_args = array('post_type' => 'post', 'posts_per_page' => 4, 'post_status' => 'publish', 'post__not_in' => array(get_the_ID()));
                        $recent_query = new WP_Query($recent_args);
                        if ($recent_query->have_posts()) : while ($recent_query->have_posts()) : $recent_query->the_post(); 
                            $post_content = get_post_field('post_content', get_the_ID());
                            $reading_time = max(1, ceil(str_word_count(strip_tags($post_content)) / 200));
                            $cats = get_the_category();
                            $cat_name = !empty($cats) ? $cats[0]->name : 'News';
                            
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                        ?>
                        <div class="sp-recent-post-item">
                            <a href="<?php the_permalink(); ?>" class="sp-recent-post-thumb">
                                <?php if (has_post_thumbnail()) { the_post_thumbnail('medium_large'); } else { echo '<div class="sp-recent-post-placeholder"></div>'; } ?>
                            </a>
                            <div class="sp-recent-post-info">
                                <div class="sp-recent-post-meta-top">
                                    <span class="sp-recent-post-cat-name"><?php echo esc_html($cat_name); ?></span>
                                    <span class="sp-recent-post-date"><?php echo get_the_date('M j, Y'); ?></span>
                                </div>
                                <h3 class="sp-recent-post-heading">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h3>
                                <div class="sp-recent-post-author-row">
                                    <a href="<?php echo $author_url; ?>">
                                        <?php echo get_avatar($author_id, 24, '', '', array('class' => 'sp-recent-post-author-avatar')); ?>
                                    </a>
                                    <a href="<?php echo $author_url; ?>" class="sp-recent-post-author-name"><?php the_author(); ?></a>
                                    <span class="sp-recent-post-dot">&bull;</span>
                                    <span><?php echo $reading_time; ?> min read</span>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; wp_reset_postdata(); endif; ?>
                    </div>
                </div>

                <div class="sp-recent-post-sidebar-wrapper">
                    <h3 class="sp-recent-post-sidebar-title">Discover our blogs</h3>
                    <div class="sp-recent-post-sidebar-list">
                        <?php
                        $discover_args = array('post_type' => 'post', 'posts_per_page' => 3, 'offset' => 3, 'post_status' => 'publish', 'post__not_in' => array(get_the_ID()));
                        $discover_query = new WP_Query($discover_args);
                        if ($discover_query->have_posts()) : while ($discover_query->have_posts()) : $discover_query->the_post(); 
                            $author_id = get_the_author_meta('ID');
                            $author_url = esc_url(get_author_posts_url($author_id));
                        ?>
                        <div class="sp-recent-post-sidebar-item">
                            <a href="<?php the_permalink(); ?>" class="sp-recent-post-sidebar-thumb">
                                <?php if (has_post_thumbnail()) { the_post_thumbnail('thumbnail'); } else { echo '<div class="sp-recent-post-placeholder"></div>'; } ?>
                            </a>
                            <div class="sp-recent-post-sidebar-info">
                                <h4 class="sp-recent-post-sidebar-heading"><a href="<?php the_permalink(); ?>"><?php echo wp_trim_words(get_the_title(), 8, '...'); ?></a></h4>
                                <div class="sp-recent-post-sidebar-excerpt">
                                    <?php echo wp_trim_words(get_the_excerpt(), 8, '...'); ?>
                                </div>
                                <div class="sp-recent-post-sidebar-meta">
                                    <div class="sp-recent-post-sidebar-author-row">
                                        <a href="<?php echo $author_url; ?>">
                                            <?php echo get_avatar($author_id, 16, '', '', array('class' => 'sp-recent-post-sidebar-avatar')); ?>
                                        </a>
                                        <a href="<?php echo $author_url; ?>"><?php echo wp_trim_words(get_the_author(), 2, ''); ?></a>
                                        <span>&bull;</span>
                                        <span><?php echo get_the_date('M j, Y'); ?></span>
                                    </div>
                                    <a href="<?php the_permalink(); ?>" class="sp-recent-post-sidebar-readlink">Read &rarr;</a>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; wp_reset_postdata(); endif; ?>
                    </div>
                </div>

            </div>
        </section>
    <?php endif; ?>

</main>

<?php get_footer(); ?>