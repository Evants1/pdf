<?php
/**
 * Template Name: Left Sidebar Full Width
 *
 * @package Spin_Pulse
 */

get_header(); ?>

<div id="primary" class="content-area w-full px-4 py-12">
    <div class="flex flex-col lg:flex-row-reverse gap-0">
        <main id="main" class="site-main flex-grow lg:w-3/4">
            <?php
            while ( have_posts() ) :
                the_post();
                get_template_part( 'template-parts/content', 'page' );
            endwhile;
            ?>
        </main>

        <aside class="lg:w-1/4 bg-gray-50 p-6">
            <?php get_sidebar(); ?>
        </aside>
    </div>
</div>

<?php get_footer(); ?>