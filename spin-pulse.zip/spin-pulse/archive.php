<?php
/**
 * The template for displaying archive pages (Categories, Tags, etc.)
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Spin_Pulse
 */

get_header();
?>

<main id="primary" class="site-main min-h-screen bg-white">

    <section class="sp-single-hero-wrapper py-12 border-b border-slate-100 bg-slate-50">
        <div class="sp-single-hero-inner max-w-[1200px] mx-auto px-6">
            
            <div class="sp-hero-breadcrumbs mb-4 text-sm text-gray-500">
                <a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="hover:underline"><?php esc_html_e('Home', 'spin-pulse'); ?></a> &raquo; 
                <span class="sp-hero-current-crumb text-gray-800"><?php esc_html_e('Archives', 'spin-pulse'); ?></span>
            </div>

            <header class="sp-category-header">
                <?php
                // ThemeForest fix: Wrap the HTML around the function, do not pass HTML into it.
                if ( is_archive() ) {
                    echo '<h1 class="sp-hero-title text-4xl md:text-5xl font-black tracking-tight mb-4">';
                    the_archive_title();
                    echo '</h1>';
                    
                    if ( get_the_archive_description() ) {
                        echo '<div class="sp-category-description text-lg text-slate-600 max-w-2xl">';
                        the_archive_description();
                        echo '</div>';
                    }
                }
                ?>
            </header>

        </div>
    </section>

    <div class="sp-archive-main-wrapper py-12">
        <div class="max-w-[1200px] mx-auto px-4 sm:px-6">
            
            <div class="sp-archive-content">
                <?php if ( have_posts() ) : ?>
                    
                    <div class="flex flex-col gap-8 mb-12">
                        <?php while ( have_posts() ) : the_post(); ?>
                            
                            <article id="post-<?php the_ID(); ?>" <?php post_class('sp-category-card group flex flex-col md:flex-row bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow'); ?>>
                                
                                <a href="<?php echo esc_url( get_permalink() ); ?>" class="sp-category-thumbnail-link w-full md:w-2/5 shrink-0">
                                    <div class="sp-category-thumbnail relative aspect-[16/9] md:h-full overflow-hidden bg-slate-100">
                                        <?php if ( has_post_thumbnail() ) : ?>
                                            <?php the_post_thumbnail( 'medium_large', array( 'class' => 'sp-category-img w-full h-full object-cover transition-transform duration-500 group-hover:scale-105' ) ); ?>
                                        <?php else: ?>
                                            <div class="sp-category-img-placeholder w-full h-full flex items-center justify-center bg-slate-200 text-slate-400">
                                                <svg class="w-12 h-12 opacity-50" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <div class="absolute top-3 left-3">
                                            <span class="sp-category-badge bg-emerald-500 text-white text-[10px] font-black px-2.5 py-1 rounded-sm uppercase tracking-wider shadow-sm">
                                                <?php 
                                                $categories = get_the_category();
                                                if ( ! empty( $categories ) ) {
                                                    echo esc_html( $categories[0]->name );   
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </a>

                                <div class="sp-category-content-wrap p-6 flex flex-col justify-center flex-grow">
                                    <div class="sp-category-meta text-xs text-slate-500 font-medium mb-2 flex items-center gap-3">
                                        <span class="sp-category-date"><?php echo esc_html( get_the_date('M j, Y') ); ?></span>
                                        <span class="w-1 h-1 rounded-full bg-slate-300"></span>
                                        <span class="sp-category-author"><?php echo esc_html( get_the_author() ); ?></span>
                                    </div>
                                    
                                    <h2 class="sp-category-title text-2xl font-bold text-slate-900 leading-snug mb-3 group-hover:text-emerald-600 transition-colors">
                                        <a href="<?php echo esc_url( get_permalink() ); ?>" rel="bookmark"><?php the_title(); ?></a>
                                    </h2>
                                    
                                    <div class="sp-category-excerpt text-slate-600 text-sm leading-relaxed mb-4">
                                        <?php 
                                        echo esc_html( wp_trim_words( get_the_excerpt(), 25, '...' ) ); 
                                        ?>
                                    </div>
                                    
                                    <div class="mt-auto">
                                        <a href="<?php echo esc_url( get_permalink() ); ?>" class="sp-category-read-more inline-flex items-center text-sm font-bold text-[#0d3b66] group-hover:text-[#8c7355] transition-colors">
                                            <?php esc_html_e( 'Read Article', 'spin-pulse' ); ?>
                                            <svg class="w-4 h-4 ml-1 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3"></path></svg>
                                        </a>
                                    </div>
                                </div>

                            </article>

                        <?php endwhile; ?>
                    </div>

                    <div class="sp-category-pagination mt-8">
                        <?php 
                        the_posts_pagination( array(
                            'mid_size'  => 2,
                            'prev_text' => esc_html__( '&larr; Previous', 'spin-pulse' ),
                            'next_text' => esc_html__( 'Next &rarr;', 'spin-pulse' ),
                        ) ); 
                        ?>
                    </div>

                <?php else : ?>
                    <div class="sp-category-no-results bg-slate-50 p-10 text-center rounded-xl border border-slate-200">
                        <h2 class="text-2xl font-bold text-slate-800 mb-4"><?php esc_html_e( 'Nothing Found', 'spin-pulse' ); ?></h2>
                        <p class="text-slate-600 mb-6"><?php esc_html_e( 'It seems we can&rsquo;t find what you&rsquo;re looking for. Perhaps searching can help.', 'spin-pulse' ); ?></p>
                        <?php get_search_form(); ?>
                    </div>
                <?php endif; ?>
            </div>

        </div>
    </div>
</main>

<?php get_footer(); ?>